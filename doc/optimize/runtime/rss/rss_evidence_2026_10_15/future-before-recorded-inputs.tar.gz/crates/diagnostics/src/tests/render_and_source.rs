use super::test_support::*;

#[test]
fn fallback_diagnostic_preserves_core_fields() {
    let spec = DiagnosticSpec {
        kind: "TypeError".into(),
        message: "expected Int, got String".into(),
        primary_span: Span { start: 13, end: 23 },
        labels: vec![DiagnosticLabel {
            source_id: None,
            span: Span { start: 13, end: 23 },
            message: "binding value".into(),
            color: Some(Color::Blue),
        }],
        notes: Vec::new(),
        help: Some("The type annotation requires Int".into()),
        structured: None,
    };

    let mut buf = Vec::new();
    write_fallback_diagnostic(
        &mut buf,
        "main.srt",
        &spec,
        &io::Error::other("broken pipe"),
    )
    .expect("fallback output should succeed");

    let text = String::from_utf8(buf).expect("fallback output must be valid utf-8");
    assert!(text.contains("diagnostic rendering failed: broken pipe"));
    assert!(text.contains("TypeError: expected Int, got String"));
    assert!(text.contains("--> main.srt:13-23"));
    assert!(text.contains("= note: binding value [13-23]"));
    assert!(text.contains("= help: The type annotation requires Int"));
}

#[test]
fn fallback_diagnostic_returns_writer_error() {
    let spec = simple_error(
        "ParseError",
        "unexpected token",
        Span { start: 2, end: 5 },
        None,
    );
    let err = write_fallback_diagnostic(
        &mut FailingWriter,
        "main.srt",
        &spec,
        &io::Error::other("broken pipe"),
    )
    .expect_err("failing writer should propagate io error");

    assert_eq!(err.kind(), io::ErrorKind::Other);
}

#[test]
fn source_registry_registers_and_updates_entries() {
    let mut sources = SourceRegistry::new();
    let src_id = sources.register("main.srt", "x = 1");

    assert_eq!(sources.file_name(src_id), Some("main.srt"));
    assert_eq!(sources.source(src_id), Some("x = 1"));

    assert!(sources.update_source(src_id, "x = 2"));
    assert_eq!(sources.source(src_id), Some("x = 2"));
}

#[test]
fn source_registry_reserves_loaded_ids_without_losing_sparse_entries() {
    let mut sources = SourceRegistry::new();
    let original = sources.register("main.srt", "original");
    sources.reserve_ids_before(40);
    let live = sources.register("REPL:1", "live");

    assert_eq!(original, SourceId(0));
    assert_eq!(live, SourceId(40));
    assert_eq!(sources.entries().len(), 2);
    assert_eq!(sources.get(original).unwrap().file_name, "main.srt");
    assert_eq!(sources.get(live).unwrap().file_name, "REPL:1");
    assert!(sources.get(SourceId(1)).is_none());
    assert!(sources.get(SourceId(39)).is_none());
    assert!(!sources.update_source(SourceId(39), "must not replace live source"));
    assert!(sources.update_source(live, "updated live"));
    assert_eq!(sources.source(original), Some("original"));
    assert_eq!(sources.source(live), Some("updated live"));
    assert_eq!(
        sources.owned_context(live),
        Some(("updated live".into(), "REPL:1".into()))
    );

    sources.reserve_ids_before(3);
    let next = sources.register("REPL:2", "next");
    assert_eq!(next, SourceId(41));
    assert_eq!(sources.source(next), Some("next"));
    assert_eq!(sources.source(live), Some("updated live"));
}

#[test]
fn source_registry_restores_original_ids_in_any_order_without_replacing_sources() {
    let mut sources = SourceRegistry::new();
    for id in [40, 3, 19] {
        assert!(sources.restore(SourceEntry {
            id: SourceId(id),
            file_name: format!("loaded:{id}"),
            source: format!("source {id}"),
        }));
    }
    assert_eq!(
        sources
            .entries()
            .iter()
            .map(|entry| entry.id.0)
            .collect::<Vec<_>>(),
        vec![3, 19, 40]
    );
    for id in [3, 19, 40] {
        let entry = sources.get(SourceId(id)).expect("restored ID must exist");
        assert_eq!(entry.file_name, format!("loaded:{id}"));
        assert_eq!(entry.source, format!("source {id}"));
    }
    assert!(sources.get(SourceId(18)).is_none());

    let original = sources.get(SourceId(19)).unwrap().clone();
    assert!(sources.restore(original.clone()));
    let mut other_path = original.clone();
    other_path.file_name = "replacement.srt".into();
    let mut other_text = original.clone();
    other_text.source = "replacement source".into();
    assert!(!sources.restore(other_path));
    assert!(!sources.restore(other_text));
    assert_eq!(sources.get(SourceId(19)), Some(&original));
    assert_eq!(sources.entries().len(), 3);

    let next = sources.register("REPL:1", "next source");
    assert_eq!(next, SourceId(41));
    assert_eq!(sources.source(next), Some("next source"));
    assert_eq!(sources.get(SourceId(19)), Some(&original));
}

#[test]
fn source_registry_rejects_unallocatable_restored_id_without_advancing_registration() {
    let mut sources = SourceRegistry::new();
    assert!(!sources.restore(SourceEntry {
        id: SourceId(u32::MAX),
        file_name: "invalid.srt".into(),
        source: "invalid".into(),
    }));
    assert!(sources.entries().is_empty());
    assert!(sources.get(SourceId(u32::MAX)).is_none());
    assert_eq!(sources.register("valid.srt", "valid"), SourceId(0));
}

#[test]
fn source_registry_returns_owned_context() {
    let mut sources = SourceRegistry::new();
    let src_id = sources.register("script.srt", "print(\"ok\")");

    let context = sources
        .owned_context(src_id)
        .expect("registered source should exist");
    assert_eq!(context.0, "print(\"ok\")");
    assert_eq!(context.1, "script.srt");
}

#[test]
fn render_error_normalizes_out_of_range_span_to_keep_source_snippet() {
    let spec = simple_error(
        "TypeError",
        "expected Int, got String",
        Span {
            start: 9999,
            end: 10000,
        },
        None,
    );
    let rendered = render_error("main.srt", "bad: Int = \"x\"", &spec);
    assert!(
        rendered.contains("TypeError: expected Int, got String"),
        "expected headline in rendered diagnostic"
    );
    assert!(
        rendered.contains("main.srt"),
        "expected file label in rendered diagnostic"
    );
}

#[test]
fn render_error_normalizes_empty_span_to_single_point_label() {
    let spec = simple_error(
        "ParseError",
        "unexpected token",
        Span { start: 4, end: 4 },
        None,
    );
    let rendered = render_error("main.srt", "abcde", &spec);
    assert!(rendered.contains("ParseError: unexpected token"));
    assert!(rendered.contains("main.srt"));
}

#[test]
fn render_error_highlights_character_after_multibyte_prefix() {
    let spec = simple_error("TypeError", "unexpected x", Span { start: 1, end: 2 }, None);
    let rendered = strip_ansi(&render_error("main.srt", "あxyz", &spec));
    assert!(rendered.contains("main.srt:1:2"), "{rendered}");
}

#[test]
fn render_error_by_id_highlights_character_after_multibyte_prefix() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "あxyz");
    let spec = simple_error("TypeError", "unexpected x", Span { start: 1, end: 2 }, None);
    let rendered = strip_ansi(&render_error_by_id(&sources, source_id, &spec));
    assert!(rendered.contains("main.srt:1:2"), "{rendered}");
}

#[test]
fn render_error_by_id_places_related_label_after_multibyte_prefix() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "あxyz");
    let related_id = sources.register("related.srt", "いxyz");
    let mut spec = simple_error("TypeError", "unexpected x", Span { start: 1, end: 2 }, None);
    spec.labels.push(DiagnosticLabel {
        source_id: Some(related_id),
        span: Span { start: 1, end: 2 },
        message: "related x".into(),
        color: None,
    });

    let rendered = strip_ansi(&render_error_by_id(&sources, source_id, &spec));
    assert!(rendered.contains("main.srt:1:2"), "{rendered}");
    assert!(rendered.contains("related.srt:1:2"), "{rendered}");
    assert!(rendered.contains("related x"), "{rendered}");
}

#[test]
fn debug_report_highlights_character_after_multibyte_prefix() {
    let rendered = strip_ansi(&render_debug_report(
        "main.srt",
        "あxyz",
        "TypeError",
        "unexpected x",
        1,
        2,
        &[DebugLabel {
            span_start: 1,
            span_end: 2,
            message: "x".into(),
            color: None,
        }],
    ));
    assert!(rendered.contains("main.srt:1:2"), "{rendered}");
}

#[test]
fn serializable_report_uses_character_offsets_for_utf8_source() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "あx");
    let spec = simple_error(
        "TypeError",
        "expected Int, got String",
        Span { start: 1, end: 2 },
        None,
    );

    let report = serializable_report_by_id(&sources, source_id, "typecheck", &spec);
    assert_eq!(report.errors[0].line, 1);
    assert_eq!(report.errors[0].column, 2);
    assert_eq!(report.errors[0].span, [1, 2]);
}

#[test]
fn structured_type_diagnostic_projects_the_same_facts_to_json_and_rendering() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "guard::<Option>(value)");
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::ReturnTypeArgumentMismatch.into(),
        origin: DiagnosticOrigin::ReturnTypeArgument { ordinal: 0 },
        data: DiagnosticData::ReturnTypeArgument(ReturnTypeArgumentData {
            declared_origin: None,
            value_parameter_origin: None,
            return_origin: None,
            left_origin: None,
            right_origin: None,
            required_trait: None,
            expected_count: None,
            actual_count: None,
            callable: "guard".into(),
            ordinal: Some(0),
            expected_type: Some("Option".into()),
            actual_type: Some("List".into()),
        }),
        primary: SourceFact::typed(
            SourceRole::ReturnTypeArgument,
            source_id,
            Span { start: 7, end: 13 },
            "Option",
        ),
        related: vec![SourceFact::typed(
            SourceRole::Value,
            source_id,
            Span { start: 14, end: 19 },
            "List<Int>",
        )],
        remediation: None,
    };

    let spec = structured_type_error_spec(&input);
    let rendered = strip_ansi(&render_error_by_id(&sources, source_id, &spec));
    assert!(rendered.contains("Return type argument 0"));
    assert!(rendered.contains("ReturnTypeArgument: Option"));
    assert!(rendered.contains("Value: List<Int>"));

    let report = serializable_report_by_id(&sources, source_id, "typecheck", &spec);
    let diagnostic = &report.errors[0];
    assert_eq!(
        diagnostic.reason.as_deref(),
        Some("ReturnTypeArgumentMismatch")
    );
    assert_eq!(diagnostic.related.len(), 2);
    assert_eq!(diagnostic.data["ordinal"], 0);
    assert_eq!(diagnostic.expected.as_deref(), Some("Option"));
    assert_eq!(diagnostic.got.as_deref(), Some("List"));
}

#[test]
fn ambiguous_return_type_argument_has_a_distinct_headline() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "make()");
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::AmbiguousReturnTypeArgument.into(),
        origin: DiagnosticOrigin::ReturnTypeArgument { ordinal: 0 },
        data: DiagnosticData::ReturnTypeArgument(ReturnTypeArgumentData {
            declared_origin: None,
            value_parameter_origin: None,
            return_origin: None,
            left_origin: None,
            right_origin: None,
            required_trait: None,
            expected_count: None,
            actual_count: None,
            callable: "make".into(),
            ordinal: Some(0),
            expected_type: Some("concrete return type argument".into()),
            actual_type: Some("List<$A>".into()),
        }),
        primary: SourceFact::typed(
            SourceRole::ReturnTypeArgument,
            source_id,
            Span { start: 0, end: 6 },
            "List<$A>",
        ),
        related: Vec::new(),
        remediation: Some(Remediation::Help {
            text: "Provide an expected result type.".into(),
        }),
    };

    let spec = structured_type_error_spec(&input);
    assert_eq!(
        spec.message,
        "return type arguments for `make` cannot be inferred"
    );
    let report = serializable_report_by_id(&sources, source_id, "typecheck", &spec);
    assert_eq!(
        report.errors[0].reason.as_deref(),
        Some("AmbiguousReturnTypeArgument")
    );
}

#[test]
fn rejected_trait_candidates_preserve_structured_failure_details() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "Monad::return(1) |>= {|x| x + 1}");
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::NoApplicableTraitImplementation.into(),
        origin: DiagnosticOrigin::Operator {
            operator: "+".into(),
        },
        data: DiagnosticData::CandidateSelection(CandidateSelectionData {
            subject_type: None,
            trait_arguments: vec![],
            impl_declaration: None,
            trait_name: "Monad".into(),
            method: "bind".into(),
            failures: vec![CandidateFailureData {
                candidate_type: "Result<Int>".into(),
                detail: "right-hand side returns Int".into(),
            }],
        }),
        primary: SourceFact::typed(
            SourceRole::LeftValue,
            source_id,
            Span { start: 0, end: 34 },
            "Int",
        ),
        related: Vec::new(),
        remediation: Some(Remediation::Candidates {
            items: vec!["Result<Int>".into()],
        }),
    };

    let spec = structured_type_error_spec(&input);
    assert_eq!(
        spec.message,
        "no `Monad` candidate can satisfy `Monad::bind`"
    );
    let report = serializable_report_by_id(&sources, source_id, "typecheck", &spec);
    assert_eq!(
        report.errors[0].reason.as_deref(),
        Some("NoApplicableTraitImplementation")
    );
    assert_eq!(report.errors[0].data["kind"], "TraitDispatch");
    assert_eq!(
        report.errors[0].data["failures"][0]["detail"],
        "right-hand side returns Int"
    );
}

#[test]
fn surtr_assert_eq_template_renders_terms_through_ariadne() {
    let source =
        "print(\"あい\")\n\ntest(\"String\") {\n  it(\"bad\") { assert_eq(\"tes\", \"bad\") }\n}\n";
    let call_start = source.find("assert_eq").expect("assert_eq exists");
    let call_end = call_start + "assert_eq(\"tes\", \"bad\")".len();
    let lhs_start = source.find("\"tes\"").expect("lhs exists");
    let lhs_end = lhs_start + "\"tes\"".len();
    let rhs_start = source.find("\"bad\"").expect("rhs exists");
    let rhs_end = rhs_start + "\"bad\"".len();
    let span = |start: usize, end: usize| Span {
        start: source[..start].chars().count(),
        end: source[..end].chars().count(),
    };
    let spec = surtr_assert_eq_error_spec(
        "TestAssertionFailed",
        "expected \"tes\", got \"bad\"",
        span(call_start, call_end),
        span(lhs_start, lhs_end),
        span(rhs_start, rhs_end),
        "\"tes\"",
        "\"bad\"",
    );

    let rendered = strip_ansi(&render_surtr_code_error("main.srt", source, &spec));
    assert!(rendered.contains("TestAssertionFailed: expected \"tes\", got \"bad\""));
    assert!(rendered.contains("main.srt:4:15"));
    assert!(rendered.contains("assert_eq(\"tes\", \"bad\")"));
    assert!(rendered.contains("LHS term: \"tes\""));
    assert!(rendered.contains("RHS term: \"bad\""));
    assert!(rendered.contains("assert_eq failed: expected \"tes\", got \"bad\""));
}

#[test]
fn trait_method_type_list_preserves_path_and_both_origins() {
    use crate::{TraitMethodTypeListData, TypeListRole};
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::TraitMethodTypeListMismatch.into(),
        origin: DiagnosticOrigin::Declaration,
        data: DiagnosticData::TraitMethodTypeList(TraitMethodTypeListData {
            impl_declaration: None,
            identity: None,
            method_name: "Build::build".into(),
            role: TypeListRole::ReturnType,
            ordinal: 0,
            nested_path: vec![0],
            expected_type: Some("Box<Int>".into()),
            actual_type: Some("Box<String>".into()),
            expected_count: None,
            actual_count: None,
        }),
        primary: SourceFact::typed(
            SourceRole::Impl,
            SourceId(1),
            Span { start: 10, end: 20 },
            "Box<String>",
        ),
        related: vec![SourceFact::typed(
            SourceRole::Contract,
            SourceId(0),
            Span { start: 3, end: 9 },
            "Box<Int>",
        )],
        remediation: None,
    };
    let spec = structured_type_error_spec(&input);
    assert!(spec.message.contains("Build::build"));
    assert!(spec.message.contains("ReturnType"));
    assert!(spec.message.contains("type argument path: 0"));
    assert_eq!(spec.labels[0].source_id, Some(SourceId(1)));
    assert_eq!(spec.labels[0].message, "Impl: Box<String>");
    assert_eq!(spec.labels[1].source_id, Some(SourceId(0)));
    assert_eq!(spec.labels[1].message, "Contract: Box<Int>");
    let data = input.data.to_json_value();
    assert_eq!(data["kind"], "TraitDispatch");
    assert_eq!(data["type_list_role"], "ReturnType");
    assert_eq!(data["ordinal"], 0);
    assert_eq!(data["nested_path"], serde_json::json!([0]));
    assert_eq!(data["expected_type"], "Box<Int>");
    assert_eq!(data["actual_type"], "Box<String>");
}

#[test]
fn trait_method_constraints_preserve_expected_and_actual_sets() {
    use crate::TraitMethodConstraintData;
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::TraitMethodConstraintMismatch.into(),
        origin: DiagnosticOrigin::Declaration,
        data: DiagnosticData::TraitMethodConstraint(TraitMethodConstraintData {
            impl_declaration: None,
            identity: None,
            method_name: "Display::show".into(),
            expected_constraints: vec!["$0: Eq".into()],
            actual_constraints: vec!["$0: Compare".into()],
        }),
        primary: SourceFact::untyped(SourceRole::Impl, SourceId(0), Span { start: 0, end: 1 }),
        related: vec![],
        remediation: None,
    };
    let spec = structured_type_error_spec(&input);
    assert!(spec.message.contains("Display::show"));
    assert!(spec.message.contains("incompatible trait constraints"));
    let data = input.data.to_json_value();
    assert_eq!(data["kind"], "TraitDispatch");
    assert_eq!(data["expected_constraints"], serde_json::json!(["$0: Eq"]));
    assert_eq!(
        data["actual_constraints"],
        serde_json::json!(["$0: Compare"])
    );
}

#[test]
fn trait_method_arity_displays_expected_and_actual_counts() {
    use crate::{TraitMethodTypeListData, TypeListRole};
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::TraitMethodTypeListArityMismatch.into(),
        origin: DiagnosticOrigin::Declaration,
        data: DiagnosticData::TraitMethodTypeList(TraitMethodTypeListData {
            impl_declaration: None,
            identity: None,
            method_name: "Make::make".into(),
            role: TypeListRole::ReturnTypeArgument,
            ordinal: 0,
            nested_path: vec![],
            expected_type: None,
            actual_type: None,
            expected_count: Some(1),
            actual_count: Some(0),
        }),
        primary: SourceFact::untyped(SourceRole::Impl, SourceId(0), Span { start: 0, end: 1 }),
        related: vec![],
        remediation: None,
    };
    let spec = structured_type_error_spec(&input);
    assert!(spec.message.contains("ReturnTypeArgument"));
    assert!(spec.message.contains("expected 1, got 0"));
}

#[test]
fn structured_diagnostics_never_extract_optional_fields_from_prose() {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register("main.srt", "value");
    let input = StructuredDiagnostic {
        reason: TypeDiagnosticReason::MissingTraitCapability.into(),
        origin: DiagnosticOrigin::Call,
        data: DiagnosticData::TraitObligation(crate::TraitObligationData {
            obligation_origin: None,
            trait_arguments: vec![],
            trait_name: "Show".into(),
            subject_type: "Box<Int>".into(),
            position: Some(0),
        }),
        primary: SourceFact::typed(
            SourceRole::Value,
            source_id,
            Span { start: 0, end: 5 },
            "Box<Int>",
        ),
        related: vec![],
        remediation: None,
    };
    let mut spec = structured_type_error_spec(&input);
    spec.message = "expected Fake, got Forged".into();
    let json = serializable_report_by_id(&sources, source_id, "typecheck", &spec);
    assert_eq!(json.errors[0].expected, None);
    assert_eq!(json.errors[0].got, None);
    assert_eq!(
        json.errors[0].reason.as_deref(),
        Some("MissingTraitCapability")
    );
}

#[test]
fn pattern_failure_help_and_target_facts_survive_rendering_and_json() {
    for (context, role, caption, target_text) in [
        (
            PatternFailureContext::Callable,
            SourceRole::ReturnType,
            "Return type",
            "Identity<Int>",
        ),
        (
            PatternFailureContext::Do,
            SourceRole::DoCarrier,
            "do_carrier",
            "do",
        ),
    ] {
        let mut sources = SourceRegistry::new();
        let failure_source = sources.register("body.srt", "2 =? Ok(3)");
        let target_source = sources.register("target.srt", target_text);
        let input = StructuredDiagnostic {
            reason: match context {
                PatternFailureContext::Callable => {
                    TypeDiagnosticReason::SafeBindRequiresMonadFailTarget
                }
                PatternFailureContext::Do => TypeDiagnosticReason::NoApplicableTraitImplementation,
            }
            .into(),
            origin: DiagnosticOrigin::Intrinsic,
            data: DiagnosticData::PatternFailure(PatternFailureData {
                context,
                carrier_type: "Identity<Int>".into(),
            }),
            primary: SourceFact::untyped(
                SourceRole::Pattern,
                failure_source,
                Span { start: 2, end: 4 },
            ),
            related: vec![SourceFact::typed(
                role,
                target_source,
                Span {
                    start: 0,
                    end: target_text.len(),
                },
                "Identity<Int>",
            )],
            remediation: None,
        };
        let spec = structured_type_error_spec(&input);
        let (message, primary_caption, help) = match context {
            PatternFailureContext::Callable => (
                "MonadFail is not implemented.",
                "Requires MonadFail.",
                "Implement MonadFail for the return type to handle FailurePattern.",
            ),
            PatternFailureContext::Do => (
                "Neither MonadFail nor Alternative is implemented.",
                "Requires MonadFail or Alternative.",
                "Implement MonadFail -> preserve Error (preferred).\nImplement Alternative -> empty().",
            ),
        };
        assert_eq!(spec.message, message);
        assert_eq!(spec.labels[0].message, primary_caption);
        assert_eq!(spec.help.as_deref(), Some(help));
        let rendered = strip_ansi(&render_error_by_id(&sources, failure_source, &spec));
        assert!(rendered.contains(&format!("{caption}: Identity<Int>")));
        assert!(rendered.contains(help.lines().next().unwrap()));
        let report = serializable_report_by_id(&sources, failure_source, "typecheck", &spec);
        let diagnostic = &report.errors[0];
        assert_eq!(diagnostic.span, [2, 4]);
        assert_eq!(diagnostic.data["carrier_type"], "Identity<Int>");
        let target = diagnostic
            .related
            .iter()
            .find(|fact| fact.role == role.json_name())
            .unwrap();
        assert_eq!(target.source_id, target_source.0);
        assert_eq!(target.span, [0, target_text.len() as u32]);
        assert_eq!(target.role, role.json_name());
        assert_eq!(target.ty.as_deref(), Some("Identity<Int>"));
        assert_eq!(diagnostic.hint.as_deref(), Some(help));
    }
}
