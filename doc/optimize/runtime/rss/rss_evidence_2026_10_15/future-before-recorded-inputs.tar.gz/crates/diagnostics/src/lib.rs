mod projection;
pub use ariadne::Color;

mod data;
mod debug_render;
mod parse;
mod render;
mod repl;
mod report;
mod resolve;
mod runtime;
mod source;
mod surtr_code;
mod typecheck;

#[cfg(test)]
mod tests;

pub use data::{
    ArgumentContractData, ArgumentRelationData, BranchAssertionData, BranchForm, CallableShapeData,
    CallableSignatureData, CandidateFailureData, CandidateSelectionData, ConstraintSubjectData,
    DeclarationIdentity, DiagnosticData, DiagnosticOrigin, DiagnosticReason,
    EnumConstructorConstraintStatus, EnumConstructorTypeArgumentData, ParseDiagnosticData,
    ParseDiagnosticGuidance, ParseDiagnosticReason, PatternDiagnosticData, PatternFailureContext,
    PatternFailureData, PatternKind, PolicyData, Remediation, ReplDiagnosticData,
    ReplDiagnosticReason, ResolveDiagnosticData, ResolveDiagnosticReason, ReturnTypeArgumentData,
    RuntimeData, RuntimeDiagnosticReason, SafeBindRelationData, SourceFact, SourceRole,
    StructuredDiagnostic, TraitDependencyContext, TraitDependencyData, TraitDependencyLeafPolicy,
    TraitDependencyStep, TraitDependencyStepKind, TraitDiagnosticIdentity, TraitDispatchData,
    TraitMethodConstraintData, TraitMethodTypeListData, TraitObligationData,
    TypeConstructorCarrierData, TypeDiagnosticReason, TypeListRole, TypePolicy,
};
pub use debug_render::{render_debug_report, DebugLabel};
pub use parse::{parse_error_spec, parse_policy_error_spec};
pub use render::{
    render_error, render_error_by_id, report_error, report_error_by_id,
    serializable_diagnostic_by_id, serializable_report_by_id,
};
pub use repl::{repl_command_parse_error_spec, repl_query_parse_error_spec};
pub use report::{
    simple_error, DiagnosticLabel, DiagnosticSpec, RuntimeDiagnosticContext,
    SerializableDiagnostic, SerializableDiagnosticReport, SerializableSourceFact,
};
pub use resolve::{resolve_error_spec, resolve_related_label_color};
pub use runtime::{runtime_error_spec, runtime_error_spec_by_id, runtime_value_error_spec};
pub use source::{SourceEntry, SourceId, SourceRegistry};
pub use surtr_code::{render_surtr_code_error, surtr_assert_eq_error_spec};
pub use typecheck::{
    structured_type_error_spec, type_error_spec_from_structured, typecheck_invariant_spec,
    typecheck_invariant_spec_with_display,
};

/// Renders an error after type-directed syntax selection while preserving its producer phase.
pub fn structured_compile_error_spec(source: &str, input: &StructuredDiagnostic) -> DiagnosticSpec {
    match input.reason {
        DiagnosticReason::Parse(_) => parse::structured_parse_error_spec(source, input),
        DiagnosticReason::Resolve(_) => resolve::structured_resolve_error_spec(input),
        DiagnosticReason::Type(_) => structured_type_error_spec(input),
        _ => panic!("compile diagnostic must originate in parse, resolve, or typecheck"),
    }
}

pub fn compile_error_phase(input: &StructuredDiagnostic) -> &'static str {
    match input.reason {
        DiagnosticReason::Parse(_) => "parse",
        DiagnosticReason::Resolve(_) => "resolve",
        DiagnosticReason::Type(_) => "typecheck",
        _ => panic!("compile diagnostic must originate in parse, resolve, or typecheck"),
    }
}
