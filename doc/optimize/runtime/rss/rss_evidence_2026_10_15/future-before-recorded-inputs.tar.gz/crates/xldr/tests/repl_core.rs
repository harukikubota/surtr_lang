#![deny(dead_code)]

use std::collections::HashSet;
use std::fs;
use std::time::Duration;

use xldr::repl::logic::core::{ReplCompletionContext, ReplCompletionKind};
use xldr::repl::logic::{ReplOutput, ReplResult};
use xldr::ReplEngine;

fn engine() -> ReplEngine {
    ReplEngine::new().expect("REPL engine should bootstrap")
}

fn process_engine() -> ReplEngine {
    ReplEngine::from_script_source(
        "process_preload.srt",
        r#"
defagent MyWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def read(state: Int) -> Result<Int> { Ok(state) }

  @set
  def write(_state: Int, next: Int) -> Result<Int> { Ok(next) }

  defp hidden_value(_state: Int) -> Result<Int> { Ok(99) }
}

defgenserver MyServer {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(1) }

  @call
  def size(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }

  defp hidden_size(_state: Int) -> Result<Int> { Ok(0) }
}

defsupervisor MySup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }
}

supervisor_init {
  MyServer {}
  MySup {}
}
"#,
    )
    .expect("process preload should bootstrap")
}

fn rendered(result: &ReplResult) -> &[String] {
    match &result.output {
        ReplOutput::EvalSuccess { rendered, .. }
        | ReplOutput::EvalError { rendered, .. }
        | ReplOutput::PlainText { lines: rendered }
        | ReplOutput::StyledDoc { lines: rendered } => rendered,
        ReplOutput::Diagnostic {
            rendered,
            summary_tail: _,
        } => rendered,
        ReplOutput::DocResolved {
            symbol,
            signature,
            summary,
            source_snippet,
            details,
        } => {
            panic!(
                "expected rendered output, got doc resolved: symbol={symbol}, signature={signature:?}, summary={summary:?}, source_snippet={source_snippet:?}, details={details:?}"
            )
        }
        ReplOutput::StatusMessage(message) => {
            panic!("expected rendered output, got status: {message}")
        }
        ReplOutput::EvalStarted { idx, source } => {
            panic!("expected rendered output, got eval start: idx={idx}, source={source}")
        }
    }
}

fn rendered_text(result: &ReplResult) -> String {
    rendered(result).join("\n")
}

fn visible_text(result: &ReplResult) -> String {
    result
        .stdout
        .iter()
        .chain(rendered(result).iter())
        .cloned()
        .collect::<Vec<_>>()
        .join("\n")
}

fn doc_text(result: &ReplResult) -> String {
    match &result.output {
        ReplOutput::DocResolved {
            symbol,
            signature,
            summary,
            source_snippet,
            details,
        } => [
            symbol.clone(),
            signature.clone().unwrap_or_default(),
            summary.clone().unwrap_or_default(),
            source_snippet.clone().unwrap_or_default(),
            details.join("\n"),
        ]
        .join("\n"),
        ReplOutput::PlainText { lines: rendered } | ReplOutput::StyledDoc { lines: rendered } => {
            rendered.join("\n")
        }
        ReplOutput::Diagnostic {
            rendered,
            summary_tail,
        } => rendered
            .iter()
            .chain(summary_tail.iter())
            .cloned()
            .collect::<Vec<_>>()
            .join("\n"),
        other => panic!("expected doc output, got {}", output_kind(other)),
    }
}

fn doc_target(result: &ReplResult) -> (&str, Option<&str>) {
    match &result.output {
        ReplOutput::DocResolved {
            symbol, signature, ..
        } => (symbol.as_str(), signature.as_deref()),
        other => panic!("expected resolved doc output, got {}", output_kind(other)),
    }
}

fn signature_text(result: &ReplResult) -> String {
    match &result.output {
        ReplOutput::StyledDoc { lines } | ReplOutput::PlainText { lines } => lines.join("\n"),
        ReplOutput::Diagnostic {
            rendered,
            summary_tail,
        } => rendered
            .iter()
            .chain(summary_tail.iter())
            .cloned()
            .collect::<Vec<_>>()
            .join("\n"),
        ReplOutput::EvalError { rendered, .. } => {
            panic!(
                "expected signature output, got EvalError:\n{}",
                rendered.join("\n")
            )
        }
        other => panic!("expected signature output, got {}", output_kind(other)),
    }
}

macro_rules! repl_core_case {
    ($case:ident) => {
        (stringify!($case), $case as fn())
    };
}

const REPL_CORE_CASES: &[(&str, fn())] = &[
    repl_core_case!(core_query_commands_report_invalid_input_diagnostics),
    repl_core_case!(core_docs_do_not_borrow_same_named_or_shadowed_declarations),
    repl_core_case!(core_trait_docs_resolve_only_authored_definition_docs),
    repl_core_case!(core_captured_doc_identity_survives_shadowed_function_redeclaration),
    repl_core_case!(core_generic_capture_docs_keep_declaration_origin_and_authored_signature),
    repl_core_case!(core_string_quote_preserves_controls_across_bindings_values_and_recall),
    repl_core_case!(core_string_quote_roundtrips_arbitrary_scalars_and_literal_syntax),
    repl_core_case!(lazy_capture_guidance_survives_repl_alias_and_failed_line),
    repl_core_case!(lazy_capture_requires_signature_at_repl_line_completion),
    repl_core_case!(core_completion_returns_global_candidates_with_details),
    repl_core_case!(range_literal_used_as_operator_shows_bracket_help),
    repl_core_case!(core_completion_keeps_all_matching_candidates),
    repl_core_case!(
        core_operator_completion_shows_inferred_rhs_signature_without_operator_candidates
    ),
    repl_core_case!(core_operator_completion_shows_string_concat_rhs_signature),
    repl_core_case!(core_operator_completion_stages_function_operator_types),
    repl_core_case!(core_operator_completion_stages_specialized_function_operators),
    repl_core_case!(core_operator_completion_keeps_unknown_lhs_as_placeholder),
    repl_core_case!(core_exposes_shared_semantic_index_for_repl_and_lsp_lookup),
    repl_core_case!(core_exposes_symbol_semantic_infos_before_completion_projection),
    repl_core_case!(core_shared_repl_completion_helper_preserves_repl_visibility_and_presentation),
    repl_core_case!(core_command_completion_uses_command_use_sites),
    repl_core_case!(core_command_argument_completion_uses_command_policies),
    repl_core_case!(core_command_outputs_use_repl_scope_before_callable_families),
    repl_core_case!(core_completion_returns_type_constructors_and_type_paths),
    repl_core_case!(core_completion_shows_bare_result_constructors_and_bool_variants),
    repl_core_case!(core_completion_accepts_lowercase_bool_aliases),
    repl_core_case!(core_completion_hides_lowercase_bool_alias_when_shadowed_by_value_binding),
    repl_core_case!(core_completion_hides_lowercase_bool_alias_when_shadowed_by_import),
    repl_core_case!(core_completion_hides_lowercase_bool_alias_when_shadowed_by_live_top_level_def),
    repl_core_case!(core_completion_only_shows_unqualified_importable_functions_after_import),
    repl_core_case!(core_completion_and_sig_prefer_authored_signatures_for_imported_helpers),
    repl_core_case!(core_completion_is_enabled_inside_string_interpolation_only),
    repl_core_case!(core_completion_shows_builtin_owner_surfaces_and_hides_special_types),
    repl_core_case!(core_completion_keeps_type_owners_ahead_of_members_for_pascal_case_prefix),
    repl_core_case!(core_completion_shows_user_defined_module_owners),
    repl_core_case!(core_completion_shows_script_preload_owner_and_members_without_docs),
    repl_core_case!(core_script_top_level_defs_are_signature_and_completion_surfaces_without_docs),
    repl_core_case!(core_sig_query_uses_trait_definition_without_docs),
    repl_core_case!(core_live_repl_top_level_defs_are_signature_and_completion_surfaces),
    repl_core_case!(core_completion_hides_global_noise_for_empty_constructor_call_arguments),
    repl_core_case!(core_completion_shows_script_preload_constructor_signature_without_docs),
    repl_core_case!(core_completion_constructor_signature_follows_result_self_new_signature),
    repl_core_case!(core_completion_hides_enum_variants_until_owner_path_is_confirmed),
    repl_core_case!(core_completion_shows_tuple_variant_signature_help),
    repl_core_case!(core_completion_ranks_constructor_arguments_by_expected_parameter_type),
    repl_core_case!(core_completion_hides_trait_impl_members_from_qualified_type_paths),
    repl_core_case!(core_completion_hides_trait_impl_roots_from_expression_candidates),
    repl_core_case!(core_completion_shows_facet_path_candidates_for_type_root),
    repl_core_case!(core_completion_shows_record_enum_and_tuple_facet_segments),
    repl_core_case!(core_completion_treats_result_focus_as_ok_value_for_next_facet_segment),
    repl_core_case!(core_completion_suggests_tuple_root_placeholder_only_until_index_is_finished),
    repl_core_case!(
        core_completion_suggests_list_and_hashmap_facet_patterns_and_nests_dynamic_segments
    ),
    repl_core_case!(core_completion_shows_facet_path_candidates_for_value_root),
    repl_core_case!(core_completion_shows_facet_view_closure_candidates),
    repl_core_case!(core_completion_shows_result_focus_api_help_for_facet_paths),
    repl_core_case!(core_completion_shows_combined_list_tuple_result_help),
    repl_core_case!(core_completion_suggests_facet_path_roots_for_facet_api_first_argument),
    repl_core_case!(core_completion_suppresses_facet_api_roots_for_invalid_capture_path_argument),
    repl_core_case!(core_completion_derives_facet_segments_from_facet_binding_focus),
    repl_core_case!(core_completion_respects_shadowed_facet_api_names),
    repl_core_case!(
        core_completion_uses_argument_position_for_variable_candidates_and_signature_help
    ),
    repl_core_case!(core_completion_shows_nested_if_and_string_contains_signatures),
    repl_core_case!(core_completion_keeps_path_candidates_while_typing_if_condition_call),
    repl_core_case!(core_completion_keeps_type_candidates_while_typing_if_condition_prefix),
    repl_core_case!(core_completion_prefers_trait_surface_for_neq_helper_details),
    repl_core_case!(core_keeps_bindings_and_definitions_between_inputs),
    repl_core_case!(core_rolls_back_failed_input_without_losing_previous_state),
    repl_core_case!(core_constructor_relation_rolls_back_after_failed_input),
    repl_core_case!(core_nominal_constructor_value_survives_failed_bound_check),
    repl_core_case!(core_parameterized_monad_t_value_survives_failed_inference),
    repl_core_case!(core_rebinding_uses_latest_value_and_grows_snapshot_locals),
    repl_core_case!(core_rejects_top_level_def_capturing_session_value_binding),
    repl_core_case!(core_rejects_repl_forbidden_top_level_declarations),
    repl_core_case!(core_routes_print_side_effects_into_repl_result_lines),
    repl_core_case!(core_routes_eprint_side_effects_into_repl_stderr_lines),
    repl_core_case!(core_routes_background_prints_into_pump_result_lines),
    repl_core_case!(core_chunk_shares_cpu_budget_with_background_tasks),
    repl_core_case!(core_cpu_background_work_requests_immediate_pump),
    repl_core_case!(core_flat_map_builder_survives_runtime_error_rollback),
    repl_core_case!(core_from_script_source_exposes_preloaded_docs_and_keeps_repl_policy),
    repl_core_case!(core_from_script_file_resolves_include_and_executes_preload_before_repl),
    repl_core_case!(core_from_module_source_exposes_preloaded_module_definitions),
    repl_core_case!(core_imports_non_autoimport_trait_and_rejects_autoimport_trait),
    repl_core_case!(core_script_preload_imports_non_autoimport_trait),
    repl_core_case!(core_from_project_module_stages_exposes_compiled_project_definitions),
    repl_core_case!(core_from_project_runner_source_exposes_selected_profile_definitions),
    repl_core_case!(core_from_project_runner_source_exposes_const_only_file_by_stem_module),
    repl_core_case!(core_from_module_source_rejects_include_directive),
    repl_core_case!(core_commands_do_not_require_a_cli_process),
    repl_core_case!(core_reuses_deferred_tuple_facet_bindings_between_inputs),
    repl_core_case!(core_static_impl_methods_keep_runtime_arity_in_sync),
    repl_core_case!(core_range_bindings_keep_constructor_and_compare_fun_indices_in_sync),
    repl_core_case!(core_range_generic_helpers_survive_sig_doc_interleaving),
    repl_core_case!(core_range_generic_helpers_survive_runtime_error_rollback),
    repl_core_case!(core_renders_top_level_facet_composition_expressions_without_codegen_leak),
    repl_core_case!(core_facet_command_reports_kind_apis_segments_and_stop_points),
    repl_core_case!(core_facet_record_positional_origin_remains_visible),
    repl_core_case!(core_record_constructor_capture_keeps_local_display_name),
    repl_core_case!(core_facet_command_inspects_operations_and_kind_queries),
    repl_core_case!(core_renders_negative_and_range_list_facets),
    repl_core_case!(core_doc_reports_match_and_cond_from_bootstrap_surface),
    repl_core_case!(core_type_command_looks_up_visible_bindings_only),
    repl_core_case!(core_repl_surfaces_keep_generic_arguments_for_bindings),
    repl_core_case!(core_help_and_error_commands_return_structured_command_output),
    repl_core_case!(core_info_command_reports_queries_and_command_errors),
    repl_core_case!(core_repl_command_and_query_errors_use_diagnostics),
    repl_core_case!(core_value_recall_uses_engine_history_and_prompt_index),
    repl_core_case!(core_session_listing_commands_render_current_state),
    repl_core_case!(core_clear_command_preserves_session_state),
    repl_core_case!(core_reload_command_preserves_defs_and_discards_value_bindings),
    repl_core_case!(core_reload_defs_command_discards_live_defs),
    repl_core_case!(core_result_error_reports_diagnostic_without_exiting),
    repl_core_case!(core_stacktrace_command_controls_result_error_trace_display),
    repl_core_case!(core_stacktrace_display_is_independent_from_error_display_mode),
    repl_core_case!(core_stacktrace_full_is_reserved_until_html_viewer_exists),
    repl_core_case!(core_immediate_anonymous_callable_calls_show_binding_hint),
    repl_core_case!(core_doc_and_sig_commands_resolve_declarations_and_aliases),
    repl_core_case!(core_sig_monad_operator_lists_user_defined_box_impl),
    repl_core_case!(core_standard_monad_instances_construct_and_run),
    repl_core_case!(core_standard_monad_transformer_smoke),
    repl_core_case!(core_standard_state_get_rejects_ambiguity_and_keeps_session_alive),
    repl_core_case!(core_safebind_diagnostic_keeps_session_alive),
    repl_core_case!(core_compare_definition_query_ignores_impl_override_selection),
    repl_core_case!(core_sig_type_owner_uses_constructor_signatures),
    repl_core_case!(core_sig_record_owner_uses_record_constructor_surface),
    repl_core_case!(core_range_constructor_and_extractor_queries_use_named_declarations),
    repl_core_case!(core_sig_resolves_enum_variant_names),
    repl_core_case!(core_doc_command_resolves_closure_type_and_callable_bindings),
    repl_core_case!(core_process_doc_and_sig_support_hidden_and_concrete_surfaces),
    repl_core_case!(core_process_public_surface_respects_annotations),
    repl_core_case!(core_process_sig_owner_summary_includes_init_pid_and_messages),
    repl_core_case!(core_process_sig_worker_owner_summary_includes_init_and_messages),
    repl_core_case!(core_process_sig_pid_binding_lists_available_messages),
    repl_core_case!(core_process_type_and_info_support_singletons_and_worker_pids),
    repl_core_case!(core_sig_expression_queries_support_operator_forms),
    repl_core_case!(core_sig_preserves_polymorphic_declarations),
    repl_core_case!(core_sig_supports_closure_bindings),
    repl_core_case!(core_extractor_closure_keeps_capture_signature_and_identity_across_chunks),
    repl_core_case!(core_apply_pattern_keeps_projection_local_and_resolves_canonical_queries),
    repl_core_case!(core_extractor_module_queries_and_from_result_work_across_chunks),
    repl_core_case!(core_completion_shows_signature_for_callable_binding_calls),
    repl_core_case!(core_callable_refs_and_signature_errors_are_ui_independent),
    repl_core_case!(
        core_partial_capture_chains_preserve_capture_origin_until_a_closure_literal_appears
    ),
    repl_core_case!(core_generic_callable_capture_uses_site_signature_inside_nested_values),
    repl_core_case!(core_facet_capture_identity_survives_bindings_and_nested_fields),
    repl_core_case!(core_generic_trait_forwarding_retains_substitutions_across_submissions),
    repl_core_case!(core_repl_displays_curry_callable_inside_result_without_internal_id),
    repl_core_case!(core_callable_declaration_identity_survives_chunks),
    repl_core_case!(core_duplicate_defs_and_runtime_result_errors_keep_the_session_alive),
    repl_core_case!(core_pattern_bindings_are_displayed_in_preorder),
    repl_core_case!(core_pattern_binding_order_defers_pattern_match_as_aliases),
    repl_core_case!(core_pattern_binding_order_flattens_list_children_before_parent_alias),
    repl_core_case!(core_duplicate_pattern_diagnostic_labels_are_limited_to_five),
    repl_core_case!(core_save_writes_decodable_eldr_snapshot),
    repl_core_case!(core_eldr_sig_queries_do_not_depend_on_docs_chunk),
    repl_core_case!(core_eldr_restore_reports_partial_semantic_restore_notice),
    repl_core_case!(core_quit_command_sets_exit_without_ui_work),
    repl_core_case!(core_dbg_docs_and_signatures_resolve_from_bootstrap_source),
    repl_core_case!(core_doc_reports_tuple_surface_undocumented_types_and_scope_aware_helpers),
    repl_core_case!(core_doc_supports_qualified_inherent_impl_method_names),
    repl_core_case!(core_sig_guides_field_paths_to_info_or_facet),
    repl_core_case!(core_inspects_facet_roots_and_private_paths_without_exposing_them_to_source),
    repl_core_case!(core_operator_captures_display_trait_identity_and_execute),
    repl_core_case!(core_operator_partial_captures_preserve_origin_and_placeholder_order),
    repl_core_case!(core_pair_captures_display_bootstrap_identity_and_concrete_types),
    repl_core_case!(core_error_generation_site_uses_direct_input_and_unicode_pattern_spans),
    repl_core_case!(core_error_generation_site_survives_nested_function_calls_across_chunks),
    repl_core_case!(core_error_generation_site_survives_nested_extractors_and_preserves_cause),
    repl_core_case!(core_error_generation_site_survives_live_extractor_calls_across_chunks),
    repl_core_case!(core_dbg_keeps_original_source_and_position_across_chunks),
    repl_core_case!(core_error_generation_site_survives_static_diagnostic_rollback),
    repl_core_case!(core_eldr_restore_preserves_error_sources_when_new_chunks_are_added),
    repl_core_case!(core_script_preload_rejects_source_spans_outside_the_runtime_range),
    repl_core_case!(core_do_monad_fail_pattern_error_is_preserved_in_fresh_repl),
    repl_core_case!(core_do_monad_fail_pattern_error_is_preserved_across_chunks),
    repl_core_case!(core_do_monad_fail_safebind_and_alternative_boundaries),
    repl_core_case!(core_error_kinds_survive_chunks_and_rollback),
];

fn core_error_kinds_survive_chunks_and_rollback() {
    let mut engine = ReplEngine::from_module_source(
        "error_kind_preload.srt",
        "deferror SavedKind { \"saved\" }",
    )
    .expect("ErrorKind declaration must preload");
    let stored = engine.handle_line("saved_kind = SavedKind");
    assert!(
        matches!(stored.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&stored)
    );
    let checked = engine.handle_line("Error::is_kind(SavedKind(), saved_kind)");
    assert_eq!(rendered_text(&checked), "True");
    let rejected = engine.handle_line("error: Error = saved_kind");
    assert!(
        matches!(rejected.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&rejected)
    );
    assert!(rendered_text(&rejected).contains("ErrorKind"));
    let recovered =
        engine.handle_line("Result::recover_kind(Err(SavedKind()), saved_kind, {|_| Ok(6)})");
    assert_eq!(rendered_text(&recovered), "Ok(6)");
    let captured = engine.handle_line("maker: (-> Error) = &SavedKind");
    assert!(
        matches!(captured.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&captured)
    );
    let kept = engine.handle_line("Error::is_kind(maker(), saved_kind)");
    assert_eq!(rendered_text(&kept), "True");
}

fn assert_repl_error_origin(result: &ReplResult, line: usize, column: usize, origin: &str) {
    assert!(
        !result.should_exit,
        "language Error must keep the session alive"
    );
    assert!(matches!(result.output, ReplOutput::EvalError { .. }));
    let text = strip_ansi(&rendered_text(result));
    let caption = text
        .lines()
        .find(|line| line.contains("╭─["))
        .expect("language Error must render a source caption");
    assert!(caption.contains(&format!(":{line}:{column} ")), "{text}");
    assert!(
        text.contains(origin),
        "generation source must render: {text}"
    );
}

fn core_error_generation_site_uses_direct_input_and_unicode_pattern_spans() {
    let mut engine = engine();
    let direct = engine.handle_line("Err(NoneError())");
    assert_repl_error_origin(&direct, 1, 5, "Err(NoneError())");

    let multiline = engine.handle_line("def fail_unicode() -> Result<Int> {\n  (\"あ\", 11) =? (\"あ\", 2)\n  Ok(0)\n}\nfail_unicode()");
    assert_repl_error_origin(&multiline, 2, 9, "(\"あ\", 11) =? (\"あ\", 2)");
    assert!(rendered_text(&multiline).contains("IntLiteralPatternMismatch"));
    assert_eq!(rendered_text(&engine.handle_line("2 + 3")), "5");
}

fn assert_repl_pattern_mismatch(engine: &mut ReplEngine, source: &str, expected: &str) {
    let result = engine.handle_line(source);
    assert!(!result.should_exit, "{source}: {}", rendered_text(&result));
    assert!(
        matches!(result.output, ReplOutput::EvalSuccess { .. }),
        "{source}: {}",
        rendered_text(&result)
    );
    assert_eq!(rendered_text(&result), expected, "{source}");
}

fn core_do_monad_fail_pattern_error_is_preserved_in_fresh_repl() {
    for source in [
        "match do::<Result> { 2 <- Ok(1); Ok(3) } { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
        "match Identity::run(ResultT::run(do::<ResultT<Identity, _>> { 2 <- ResultT::ok::<Identity>(1); ResultT::ok::<Identity>(3) })) { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
    ] {
        assert_repl_pattern_mismatch(&mut engine(), source, "(\"IntLiteralPatternMismatch\", \"Int literal pattern 2 did not match 1\")");
    }
}

fn core_do_monad_fail_pattern_error_is_preserved_across_chunks() {
    let mut engine = engine();
    for source in [
        "def unrelated(value: Int) -> Int { value + 41 }",
        "saved_closure = {|value: Int| unrelated(value)}",
        "saved_text = \"relocation must preserve Error kind and message\"",
        "saved_error: Result<Int> = Err(NoneError())",
        "mismatch: Result<Int> = do::<Result> { 2 <- Ok(1); Ok(3) }",
        "mismatch_t: ResultT<Identity, Int> = do::<ResultT<Identity, _>> { 2 <- ResultT::ok::<Identity>(1); ResultT::ok::<Identity>(3) }",
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    for source in [
        "match mismatch { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
        "match Identity::run(ResultT::run(mismatch_t)) { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
    ] {
        assert_repl_pattern_mismatch(&mut engine, source, "(\"IntLiteralPatternMismatch\", \"Int literal pattern 2 did not match 1\")");
    }
    assert_eq!(rendered_text(&engine.handle_line("saved_closure(1)")), "42");
    assert_eq!(
        rendered_text(&engine.handle_line("match saved_error { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }")),
        "(\"NoneError\", \"None Value.\")"
    );
}

fn core_do_monad_fail_safebind_and_alternative_boundaries() {
    let mut engine = engine();
    for source in [
        "match do::<Result> { Option::Some(value) =? Option<Int>::None; Ok(value) } { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
        "match Identity::run(ResultT::run(do::<ResultT<Identity, _>> { Option::Some(value) =? Option<Int>::None; ResultT::ok::<Identity>(value) })) { Err(error) => (Error::kind(error), Error::message(error)), Ok(_) => (\"unexpected Ok\", \"\"), }",
    ] {
        assert_repl_pattern_mismatch(&mut engine, source, "(\"EnumVariantPatternMismatch\", \"Option pattern expected Some, got None\")");
    }
    let blocked = engine.handle_line("blocked: OptionT<Result, Unit> = Alternative::guard(False)");
    assert!(
        matches!(blocked.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&blocked)
    );
    for (source, expected) in [
        (
            "OptionT::run(do::<OptionT<Result, _>> { 2 <- OptionT::some::<Result>(1); OptionT::some::<Result>(3) })",
            "Ok(Option::None)",
        ),
        (
            "OptionT::run(do::<OptionT<Result, _>> { Option::Some(value) =? Option<Int>::None; OptionT::some::<Result>(value) })",
            "Ok(Option::None)",
        ),
        (
            "OptionT::run(Alternative::empty::<OptionT<Result, Int>>())",
            "Ok(Option::None)",
        ),
        ("OptionT::run(blocked)", "Ok(Option::None)"),
        (
            "do::<Option> { 2 <- Option::Some(1); Option::Some(3) }",
            "Option::None",
        ),
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
        assert_eq!(rendered_text(&result), expected, "{source}");
    }
}

fn core_error_generation_site_survives_nested_function_calls_across_chunks() {
    let mut engine = engine();
    for source in [
        "def source_error() -> Result<Int> {\n  Err(NoneError())\n}",
        "def relay_error() -> Result<Int> {\n  value =? source_error()\n  Ok(value)\n}",
        "def outer_error() -> Result<Int> { relay_error() }",
        "unrelated = \"あいう\"",
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    let _ = engine.handle_line(":stacktrace verbose");
    let result = engine.handle_line("outer_error()");
    assert_repl_error_origin(&result, 2, 7, "Err(NoneError())");
    let text = rendered_text(&result);
    assert!(
        text.contains("NoneError") && text.contains("None Value."),
        "{text}"
    );
    assert!(
        text.contains("Stack trace:") && text.contains("source_error at"),
        "{text}"
    );
}

fn core_error_generation_site_survives_nested_extractors_and_preserves_cause() {
    let mut engine = ReplEngine::from_module_source(
        "extractor_origins.srt",
        "deferror Inner { \"inner cause\" }\ndeferror Outer { |message: String| message }\ndefmod E {\n  def source() -> Result<Int> {\n    Result::cause(Err(Inner()), Outer(\"wrapped origin\"))\n  }\n  defextractor inner(value: Int) -> MatchResult<Int> {\n    found =? source()\n    MatchResult::Ok(found)\n  }\n  defextractor outer(value: Int) -> MatchResult<Int> {\n    inner(found) =? Ok(value)\n    MatchResult::Ok(found)\n  }\n}",
    ).expect("nested Extractor definitions must preload");
    let _ = engine.handle_line("unrelated = \"あ\"");
    for source in [
        "E::outer(found) =? Ok(2)",
        "do::<Result> {\n  E::outer(found) <- Ok(2)\n  Ok(found)\n}",
    ] {
        let result = engine.handle_line(source);
        assert_repl_error_origin(&result, 5, 33, "Outer(\"wrapped origin\")");
        let text = rendered_text(&result);
        assert!(text.contains("extractor_origins.srt:5:33"), "{text}");
        assert!(
            text.contains("wrapped origin") && text.contains("inner cause"),
            "{text}"
        );
    }
}

fn core_error_generation_site_survives_live_extractor_calls_across_chunks() {
    let mut engine = engine();
    for source in [
        "def source_error(_value: Int) -> Result<Int> {\n  Err(NoneError())\n}",
        "inner = Extractor::from_result(&source_error)",
        "outer = *{|value: Int|\n  inner(found) =? Ok(value)\n  MatchResult::Ok(found)\n}",
        "unrelated = \"あいう\"",
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    for source in [
        "outer(found) =? Ok(2)",
        "do::<Result> {\n  outer(found) <- Ok(2)\n  Ok(found)\n}",
    ] {
        let result = engine.handle_line(source);
        assert_repl_error_origin(&result, 2, 7, "Err(NoneError())");
        assert!(rendered_text(&result).contains("None Value."));
    }
}

fn core_dbg_keeps_original_source_and_position_across_chunks() {
    let mut engine = engine();
    let direct = engine.handle_line("dbg!(1)");
    assert!(matches!(direct.output, ReplOutput::EvalSuccess { .. }));
    let text = strip_ansi(&direct.stderr.join("\n"));
    assert!(
        text.contains(":1:1 ") && text.contains("dbg!(1)") && text.contains("Int: 1"),
        "{text}"
    );

    let definition = engine.handle_line("def log() -> Unit {\n  dbg!(42)\n}");
    assert!(matches!(definition.output, ReplOutput::EvalSuccess { .. }));
    let _ = engine.handle_line("unrelated = \"あいう\"");
    let call = engine.handle_line("log()");
    assert!(
        matches!(call.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&call)
    );
    let text = strip_ansi(&call.stderr.join("\n"));
    assert!(
        text.contains(":2:3 ") && text.contains("dbg!(42)") && text.contains("Int: 42"),
        "{text}"
    );
}

fn core_error_generation_site_survives_static_diagnostic_rollback() {
    let mut engine = engine();
    for (source, expected, chunk, column) in [
        ("unknown = &compare", "needs expected callable type", 1, 11),
        ("wrong: Int = \"あ\"", "TypeError", 3, 14),
    ] {
        let rejected = engine.handle_line(source);
        let text = strip_ansi(&rendered_text(&rejected));
        assert!(text.contains(expected), "{text}");
        assert!(text.contains(source), "{text}");
        let caption = text
            .lines()
            .find(|line| line.contains("╭─["))
            .expect("static diagnostic must render a caption");
        assert!(
            caption.contains(&format!("REPL:{chunk}:1:{column} ")),
            "{text}"
        );
        let next = engine.handle_line("Err(NoneError())");
        assert_repl_error_origin(&next, 1, 5, "Err(NoneError())");
    }
}

fn core_script_preload_rejects_source_spans_outside_the_runtime_range() {
    let source = format!(
        "{}\ndef source_error() -> Result<Int> {{ Err(NoneError()) }}\n",
        "#".repeat(sindr::ir::MODULE_SPAN_STRIDE)
    );
    let Err(xldr::repl::logic::core::ReplLoadError::Diagnostic {
        sources,
        source_id,
        spec,
        ..
    }) = ReplEngine::from_script_source("oversized_preload.srt", &source)
    else {
        panic!("oversized preload must be rejected with a source diagnostic")
    };
    assert_eq!(spec.kind, "SourceError");
    assert_eq!(
        spec.message,
        "REPL source span exceeds the runtime source range"
    );
    assert_eq!(
        sources
            .get(source_id)
            .expect("diagnostic source must exist")
            .file_name,
        "oversized_preload.srt"
    );
}

fn core_eldr_restore_preserves_error_sources_when_new_chunks_are_added() {
    let mut engine = engine();
    let definition =
        engine.handle_line("def saved_error() -> Result<Int> {\n  Err(NoneError())\n}");
    assert!(matches!(definition.output, ReplOutput::EvalSuccess { .. }));
    let original_error = engine.handle_line("saved_error()");
    assert_repl_error_origin(&original_error, 2, 7, "Err(NoneError())");
    let dir = tempfile_dir("xldr-repl-error-source-restore");
    let first_path = dir.join("before.eldr");
    let second_path = dir.join("after.eldr");
    let saved = engine.handle_line(&format!(":save {}", first_path.display()));
    assert!(rendered_text(&saved).contains("saved to"));
    let bytes = fs::read(&first_path).expect("initial snapshot must exist");
    let initial = sindr::ir::Bytecode::decode(&bytes).expect("initial snapshot must decode");
    let saved_source = initial
        .sources
        .iter()
        .find(|source| {
            source
                .text
                .as_deref()
                .is_some_and(|text| text.contains("def saved_error()"))
        })
        .expect("saved definition source must exist")
        .clone();
    let mut restored = ReplEngine::from_eldr(&bytes).expect("snapshot must restore");
    let fresh = restored.handle_line("Err(EmptyHeadTailListPattern())");
    assert_repl_error_origin(&fresh, 1, 5, "Err(EmptyHeadTailListPattern())");
    let saved = restored.handle_line(&format!(":save {}", second_path.display()));
    assert!(rendered_text(&saved).contains("saved to"));
    let updated =
        sindr::ir::Bytecode::decode(&fs::read(&second_path).expect("updated snapshot must exist"))
            .expect("updated snapshot must decode");
    assert!(
        updated.sources.contains(&saved_source),
        "saved source identity must survive restore and append"
    );
    let fresh_source = updated
        .sources
        .iter()
        .find(|source| source.text.as_deref() == Some("Err(EmptyHeadTailListPattern())\n"))
        .expect("new input source must exist");
    assert_ne!(fresh_source.source_id, saved_source.source_id);
    assert_ne!(fresh_source.path, saved_source.path);
    let source_identities: Vec<_> = updated
        .sources
        .iter()
        .map(|source| (source.source_id, source.path.clone()))
        .collect();
    // .eldr restore intentionally omits user compile-time scope. Invoke the saved
    // function through the public interactive VM boundary to verify its old code.
    let saved_function = updated
        .functions
        .iter()
        .find(|function| {
            function
                .qualified_name
                .as_deref()
                .is_some_and(|name| name.ends_with("::saved_error"))
        })
        .expect("saved function must remain in bytecode");
    let call = sindr::ir::BytecodeChunk {
        opcodes: vec![
            sindr::ir::Opcode::Call {
                fun_idx: saved_function.fun_idx,
                arity: 0,
                span_start: 0,
                span_end: 0,
            },
            sindr::ir::Opcode::Halt,
        ],
        source_map: None,
        const_base: updated.constants.len() as u32,
        constants: Vec::new(),
        new_locals: 0,
        type_registry_base: updated.type_registry.entries().len() as u32,
        type_entries: Vec::new(),
        error_template_base: updated.error_templates.len() as u32,
        error_templates: Vec::new(),
        dbg_template_base: updated.dbg_templates.len() as u32,
        dbg_templates: Vec::new(),
        callable_templates: Vec::new(),
        functions: Vec::new(),
        docs: Vec::new(),
        signatures: Vec::new(),
        runtime_process_specs: Vec::new(),
        runtime_boot_plan: Default::default(),
    };
    let mut vm = eldr::InteractiveVm::from_bytecode(updated);
    let result = vm
        .push_chunk(
            call,
            eldr::interactive::InteractiveChunkPolicy::ReplAppendOnly,
        )
        .expect("saved function must execute");
    let sindr::runtime::Value::Tagged { tag: 1, fields } = result.value else {
        panic!("saved function must return Err")
    };
    let sindr::runtime::Value::Error(error) = fields.first().expect("Err must contain Error")
    else {
        panic!("Err must retain rich Error")
    };
    assert_eq!(error.location.file, saved_source.path);
    assert_eq!((error.location.line, error.location.column), (2, 7));
    let text = strip_ansi(&xldr::error_display::runtime_value_error_text_from_vm(
        vm.as_vm(),
        &fields[0],
    ));
    assert!(
        text.contains("Err(NoneError())") && text.contains(":2:7 "),
        "{text}"
    );
    let mut source_ids = HashSet::new();
    let mut source_names = HashSet::new();
    for (source_id, path) in source_identities {
        assert!(
            source_ids.insert(source_id),
            "duplicate source ID: {source_id}: {path}"
        );
        if path.starts_with("REPL:") {
            assert!(
                source_names.insert(path.clone()),
                "duplicate REPL source name: {source_id}: {path}"
            );
        }
    }
    fs::remove_dir_all(dir).expect("snapshot directory must be removable");
}

fn core_docs_do_not_borrow_same_named_or_shadowed_declarations() {
    let dir = tempfile_dir("doc-identity");
    fs::write(
        dir.join("described.srt"),
        r#"
defmod Described {
@doc """foreign sentinel"""
def same() -> Int { 1 }
}
"#,
    )
    .unwrap();
    fs::write(
        dir.join("undescribed.srt"),
        "defmod Undescribed { def same() -> Int { 2 } }",
    )
    .unwrap();
    fs::write(
        dir.join("preload.srt"),
        r#"
include "described.srt"
include "undescribed.srt"
@doc """preload sentinel"""
def greet() -> String { "old" }
"#,
    )
    .unwrap();
    let mut engine = ReplEngine::from_script_file(dir.join("preload.srt").to_str().unwrap())
        .expect("preload fixture");
    let old = engine.handle_line("old_greet: (-> String) = &greet");
    assert!(
        !matches!(old.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&old)
    );
    let capture = engine.handle_line("captured: (-> Int) = &Undescribed::same");
    assert!(
        !matches!(capture.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&capture)
    );
    assert!(!doc_text(&engine.handle_line(":doc captured")).contains("foreign sentinel"));
    let shadow = engine.handle_line("greet = {|| \"new\" }");
    assert!(
        !matches!(shadow.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&shadow)
    );
    assert!(!doc_text(&engine.handle_line(":doc greet")).contains("preload sentinel"));
    assert!(doc_text(&engine.handle_line(":doc old_greet")).contains("preload sentinel"));
    let shadow = engine.handle_line("greet: (-> Int) = &Undescribed::same");
    assert!(
        !matches!(shadow.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&shadow)
    );
    let missing = doc_text(&engine.handle_line(":doc greet"));
    assert!(
        !missing.contains("preload sentinel") && !missing.contains("foreign sentinel"),
        "{missing}"
    );
    assert!(!doc_text(&engine.handle_line(":doc missing")).contains("foreign sentinel"));
}

fn core_trait_docs_resolve_only_authored_definition_docs() {
    let mut engine = ReplEngine::from_script_source(
        "trait_doc_identity.srt",
        r#"
@doc """trait sentinel"""
deftrait DocBoth {
  @doc """method sentinel"""
  def describe(self: Self) -> Int
}
@doc """implementation sentinel"""
impl DocBoth for Int {
  @doc """implementation method sentinel"""
  def describe(self: Self) -> Int { self }
}
@doc """root only sentinel"""
deftrait DocRootOnly {
  def rootless(self: Self) -> Int
}
deftrait DocMethodOnly {
  @doc """method only sentinel"""
  def method_only(self: Self) -> Int
}
"#,
    )
    .expect("trait doc fixture");
    for (query, expected, excluded) in [
        (":doc DocBoth", "trait sentinel", "method sentinel"),
        (
            ":doc DocBoth::describe",
            "method sentinel",
            "implementation",
        ),
        (
            ":doc DocMethodOnly::method_only",
            "method only sentinel",
            "trait sentinel",
        ),
    ] {
        let text = doc_text(&engine.handle_line(query));
        assert!(text.contains(expected), "{query}: {text}");
        assert!(!text.contains(excluded), "{query}: {text}");
    }
    let capture = engine.handle_line("trait_method: (Int -> Int) = &DocBoth::describe");
    assert!(
        !matches!(capture.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&capture)
    );
    let captured_doc = doc_text(&engine.handle_line(":doc trait_method"));
    assert!(
        captured_doc.contains("method sentinel") && !captured_doc.contains("implementation"),
        "capture: {}\ndoc: {captured_doc}",
        rendered_text(&capture)
    );
    let missing = doc_text(&engine.handle_line(":doc DocRootOnly::rootless"));
    assert!(!missing.contains("root only sentinel"), "{missing}");
    assert!(
        missing.contains("undocumented") || missing.contains("No docs found"),
        "{missing}"
    );
}

fn core_captured_doc_identity_survives_shadowed_function_redeclaration() {
    let mut engine = engine();
    for source in [
        r#"@doc """original sentinel""" def probe(x: Int) -> Int { x }"#,
        "old: (Int -> Int) = &probe",
        "probe = 1",
        r#"@doc """replacement sentinel""" def probe(x: Int) -> Int { x + 1 }"#,
    ] {
        let result = engine.handle_line(source);
        assert!(
            !matches!(result.output, ReplOutput::EvalError { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    let old_doc = doc_text(&engine.handle_line(":doc old"));
    assert!(old_doc.contains("original sentinel"), "{old_doc}");
    assert!(!old_doc.contains("replacement sentinel"), "{old_doc}");
    for source in [
        "def plain(x: Int) -> Int { x }",
        "plain_old: (Int -> Int) = &plain",
        "plain = 2",
        r#"@doc """newly documented sentinel""" def plain(x: Int) -> Int { x + 1 }"#,
    ] {
        assert!(
            !matches!(
                engine.handle_line(source).output,
                ReplOutput::EvalError { .. }
            ),
            "{source}"
        );
    }
    let old_plain = doc_text(&engine.handle_line(":doc plain_old"));
    assert!(
        !old_plain.contains("newly documented sentinel"),
        "{old_plain}"
    );
}

fn core_generic_capture_docs_keep_declaration_origin_and_authored_signature() {
    let mut engine = ReplEngine::from_script_source(
        "capture_owner.srt",
        r#"
defstruct CaptureOwner { value: Int }
impl CaptureOwner {
  @doc """constructor sentinel"""
  def new(value: Int) -> Self { CaptureOwner { value } }
}
"#,
    )
    .expect("capture owner fixture");
    for source in [
        r#"@doc """generic original sentinel""" def documented_identity(value: $A) -> $A { value }"#,
        "number: (Int -> Int) = &documented_identity",
        "text: (String -> String) = &documented_identity",
        "partial = &number(&1)",
    ] {
        let result = engine.handle_line(source);
        assert!(
            !matches!(result.output, ReplOutput::EvalError { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    assert!(matches!(
        engine.handle_line("broken = absent_symbol").output,
        ReplOutput::EvalError { .. }
    ));
    for name in ["number", "text", "partial"] {
        let doc = doc_text(&engine.handle_line(&format!(":doc {name}")));
        assert!(doc.contains("generic original sentinel"), "{name}: {doc}");
    }
    for source in [
        "documented_identity = 1",
        r#"@doc """generic replacement sentinel""" def documented_identity(value: $A) -> $A { value }"#,
    ] {
        assert!(
            !matches!(
                engine.handle_line(source).output,
                ReplOutput::EvalError { .. }
            ),
            "{source}"
        );
    }
    let doc = doc_text(&engine.handle_line(":doc number"));
    assert!(
        doc.contains("generic original sentinel") && !doc.contains("generic replacement sentinel"),
        "{doc}"
    );
    let capture =
        engine.handle_line("fixture_constructor: (Int -> CaptureOwner) = &CaptureOwner::new");
    assert!(
        !matches!(capture.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&capture)
    );
    let doc = engine.handle_line(":doc fixture_constructor");
    let (_, signature) = doc_target(&doc);
    assert_eq!(
        signature,
        Some("CaptureOwner::new(value: Int) -> CaptureOwner")
    );
}

fn core_query_commands_report_invalid_input_diagnostics() {
    let mut engine = engine();
    for command in [":doc", ":sig", ":info"] {
        for query in ["print(1)"] {
            let result = engine.handle_line(&format!("{command} {query}"));
            assert!(
                matches!(result.output, ReplOutput::Diagnostic { .. }),
                "{command} {query}: expected rejection"
            );
            let text = strip_ansi(&rendered_text(&result));
            assert!(
                text.contains("ReplQueryParseError"),
                "{command} {query}: {text}"
            );
        }
    }
}

fn core_string_quote_preserves_controls_across_bindings_values_and_recall() {
    let mut engine = engine();
    let binding = engine.handle_line("s =? String::from_codepoints([27], StringEncoding::Utf8)");
    assert_eq!(rendered_text(&binding), r#"s: String = "\u{1b}""#);
    let concatenated = engine.handle_line(r#"s ++ "a""#);
    assert_eq!(rendered_text(&concatenated), r#""\u{1b}a""#);
    let recalled = engine.handle_line(":v 2");
    assert!(
        rendered_text(&recalled).contains(r#""\u{1b}a""#),
        "{}",
        rendered_text(&recalled)
    );
    assert_eq!(
        rendered_text(&engine.handle_line("String::codepoints(s, StringEncoding::Utf8)")),
        "Ok([27])"
    );
    assert_eq!(
        rendered_text(&engine.handle_line(r#"String::codepoints(s ++ "a", StringEncoding::Utf8)"#)),
        "Ok([27, 97])"
    );
}

fn core_string_quote_roundtrips_arbitrary_scalars_and_literal_syntax() {
    let mut engine = engine();
    let controls: String = (0..=0x1f)
        .chain(0x7f..=0x9f)
        .map(|code| char::from_u32(code).unwrap())
        .collect();
    let all_scalars: String = (0..=0x10ffff).filter_map(char::from_u32).collect();
    // Control coverage plus every scalar at the quote/parse boundary. Evaluate
    // selected mixtures as well, including syntax generated by decoded input.
    let source = sindr::runtime::quote_surtr_string_literal(&all_scalars);
    let parsed = spire::parse(&source).expect("every scalar should quote as valid source");
    assert!(
        matches!(parsed.as_slice(), [spire::ast::Ast::Lit(_, spire::ast::Lit::Str(value))] if value == &all_scalars)
    );
    for text in [
        controls.as_str(),
        "\\\"'#{missing}\\u{1b}あ😀",
        "\\#{missing}\\\\#{missing}#{{#{missing}",
        "\u{d7ff}\u{e000}\u{10ffff}\u{fdd0}",
        "\u{1b}[31ma",
    ] {
        let bytes = text
            .as_bytes()
            .iter()
            .map(u8::to_string)
            .collect::<Vec<_>>()
            .join(", ");
        let binding = engine.handle_line(&format!(
            "original =? String::from_codepoints([{bytes}], StringEncoding::Utf8)"
        ));
        assert!(
            matches!(binding.output, ReplOutput::EvalSuccess { .. }),
            "{}",
            rendered_text(&binding)
        );
        let quoted = engine.handle_line("original");
        let reconstructed = engine.handle_line(&format!("restored = {}", rendered_text(&quoted)));
        assert!(
            matches!(reconstructed.output, ReplOutput::EvalSuccess { .. }),
            "{}",
            rendered_text(&reconstructed)
        );
        assert_eq!(
            rendered_text(&engine.handle_line("original == restored")),
            "True",
            "{text:?}"
        );
    }
}

const REPL_CORE_BUCKET_COUNT: usize = 16;

fn run_repl_core_bucket(bucket: usize) {
    assert!(
        bucket < REPL_CORE_BUCKET_COUNT,
        "invalid REPL core bucket: {bucket}"
    );
    for (index, &(name, case)) in REPL_CORE_CASES.iter().enumerate() {
        if index % REPL_CORE_BUCKET_COUNT == bucket {
            eprintln!("repl_core case: {name}");
            case();
        }
    }
}

#[test]
fn repl_core_case_inventory_has_unique_names_and_functions() {
    let mut names = HashSet::new();
    let mut functions = HashSet::new();

    for &(name, case) in REPL_CORE_CASES {
        assert!(names.insert(name), "duplicate REPL core case name: {name}");
        assert!(
            functions.insert(case as usize),
            "duplicate REPL core case function: {name}"
        );
        assert!(
            !include_str!("repl_core.rs").contains(&format!("#[test]\nfn {name}(")),
            "registered REPL core case must run only through a bucket: {name}"
        );
    }

    let mut buckets = HashSet::new();
    for &bucket in REPL_CORE_BUCKET_IDS {
        assert!(
            bucket < REPL_CORE_BUCKET_COUNT,
            "invalid REPL core bucket: {bucket}"
        );
        assert!(
            buckets.insert(bucket),
            "duplicate REPL core bucket: {bucket}"
        );
        assert!(
            REPL_CORE_CASES
                .iter()
                .enumerate()
                .any(|(index, _)| index % REPL_CORE_BUCKET_COUNT == bucket),
            "empty REPL core bucket: {bucket}"
        );
    }
    assert_eq!(
        buckets.len(),
        REPL_CORE_BUCKET_COUNT,
        "missing REPL core bucket"
    );
    for (index, &(name, _)) in REPL_CORE_CASES.iter().enumerate() {
        assert_eq!(
            REPL_CORE_BUCKET_IDS
                .iter()
                .filter(|&&bucket| index % REPL_CORE_BUCKET_COUNT == bucket)
                .count(),
            1,
            "REPL core case must run exactly once: {name}"
        );
    }
}

macro_rules! repl_core_buckets {
    ($($name:ident => $bucket:expr),+ $(,)?) => {
        const REPL_CORE_BUCKET_IDS: &[usize] = &[$($bucket),+];
        $(
        #[test]
        fn $name() {
            run_repl_core_bucket($bucket);
        }
        )+
    };
}

repl_core_buckets! {
    repl_core_bucket_0 => 0,
    repl_core_bucket_1 => 1,
    repl_core_bucket_2 => 2,
    repl_core_bucket_3 => 3,
    repl_core_bucket_4 => 4,
    repl_core_bucket_5 => 5,
    repl_core_bucket_6 => 6,
    repl_core_bucket_7 => 7,
    repl_core_bucket_8 => 8,
    repl_core_bucket_9 => 9,
    repl_core_bucket_10 => 10,
    repl_core_bucket_11 => 11,
    repl_core_bucket_12 => 12,
    repl_core_bucket_13 => 13,
    repl_core_bucket_14 => 14,
    repl_core_bucket_15 => 15,
}

fn core_completion_returns_global_candidates_with_details() {
    let mut engine = engine();
    assert!(
        engine.completions("", 0).candidates.is_empty(),
        "empty prompt should not show global completion noise"
    );
    assert!(rendered_text(&engine.handle_line("answer = 42")).contains("answer: Int"));

    let completion = engine.completions("ans", 3);
    let answer = completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "answer")
        .expect("answer binding should be suggested");
    assert_eq!(answer.kind, ReplCompletionKind::Variable);
    assert_eq!(answer.detail.as_deref(), Some("Int"));

    let print = engine
        .completions("pri", 3)
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "print")
        .expect("pathless function calls should be suggested");
    assert_eq!(print.kind, ReplCompletionKind::FunctionCall);
    assert!(print
        .detail
        .as_deref()
        .is_some_and(|detail| detail.contains("print(")));
    assert!(
        completion.telemetry.completion_compute_ns.is_some(),
        "completion telemetry should record compute time: {:?}",
        completion.telemetry
    );
    assert!(
        completion
            .telemetry
            .completion_compute_ns
            .is_some_and(|value| value > 0),
        "completion telemetry should be positive: {:?}",
        completion.telemetry
    );
}

fn range_literal_used_as_operator_shows_bracket_help() {
    let result = engine().handle_line("2..8");

    assert!(rendered_text(&result).contains("Range literals must use bracket syntax"));
}

fn core_completion_keeps_all_matching_candidates() {
    let mut engine = engine();
    for idx in 0..6 {
        let result = engine.handle_line(&format!("value_{idx} = {idx}"));
        assert!(
            rendered_text(&result).contains(&format!("value_{idx}: Int")),
            "{}",
            rendered_text(&result)
        );
    }

    let completion = engine.completions("value_", "value_".len());
    assert!(
        completion.candidates.len() >= 6,
        "core completion should retain all matching candidates for paging: {:?}",
        completion.candidates
    );
}

fn core_operator_completion_shows_inferred_rhs_signature_without_operator_candidates() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("answer = 42")).contains("answer: Int"));
    assert!(rendered_text(&engine.handle_line("name = \"surtr\"")).contains("name: String"));

    let completion = engine.completions("1 + ", "1 + ".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("operator rhs should show signature help");
    assert_eq!(signature.lines.join("\n"), "Int + [Int]");

    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        !labels
            .iter()
            .any(|label| matches!(*label, "+" | "|>" | "++")),
        "operator symbols must not be completion candidates: {labels:?}"
    );
    let answer_pos = labels
        .iter()
        .position(|label| *label == "answer")
        .expect("Int binding should be suggested");
    let name_pos = labels
        .iter()
        .position(|label| *label == "name")
        .expect("String binding should remain available after matching Int candidates");
    assert!(
        answer_pos < name_pos,
        "Int candidates should rank before nonmatching variables: {labels:?}"
    );

    assert!(ReplCompletionContext::should_request("1 + ", "1 + ".len()));

    let partial = engine.completions("1 + an", "1 + an".len());
    assert_eq!(
        partial
            .signature
            .as_ref()
            .expect("operator rhs prefix should keep signature help")
            .lines
            .join("\n"),
        "Int + [Int]"
    );
    let partial_labels = partial
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        partial_labels.iter().any(|label| *label == "answer"),
        "matching Int variable should remain visible with a RHS prefix: {partial_labels:?}"
    );
}

fn core_operator_completion_shows_string_concat_rhs_signature() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("name = \"surtr\"")).contains("name: String"));

    let completion = engine.completions("name ++ ", "name ++ ".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("concat rhs should show signature help");
    assert_eq!(signature.lines.join("\n"), "String ++ [String]");
}

fn core_operator_completion_stages_function_operator_types() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("x = 1")).contains("x: Int"));

    let first = engine.completions("x |> ", "x |> ".len());
    let first_signature = first
        .signature
        .as_ref()
        .expect("pipe rhs should show callable shape");
    assert_eq!(first_signature.lines.join("\n"), "Int |> [(Int -> _)]");
    let first_labels = first
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        ["|>", ">>", ">*", ">=>"]
            .iter()
            .all(|operator| first_labels.contains(operator)),
        "builtin function operators should be completion candidates: {first_labels:?}"
    );
    let to_string_pos = first_labels
        .iter()
        .position(|label| *label == "to_string")
        .expect("callable RHS candidate should be suggested for pipe");
    let print_pos = first_labels
        .iter()
        .position(|label| *label == "print")
        .expect("nonmatching callable should remain available after matching candidates");
    assert!(
        to_string_pos < print_pos,
        "callable candidates accepting Int should rank first: {:?}",
        first
            .candidates
            .iter()
            .filter(|candidate| matches!(
                candidate.label.as_str(),
                "to_string" | "print" | "Show::to_string" | "Kernel::print"
            ))
            .collect::<Vec<_>>()
    );

    let chained = engine.completions("x |> to_string |> ", "x |> to_string |> ".len());
    let chained_signature = chained
        .signature
        .as_ref()
        .expect("chained pipe rhs should carry staged type");
    assert_eq!(
        chained_signature.lines.join("\n"),
        "Int |> (Int -> String) |> [(String -> _)]"
    );
}

fn core_operator_completion_stages_specialized_function_operators() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("xs = [1, 2]")).contains("xs: List<Int>"));
    assert!(rendered_text(&engine.handle_line("ret = Ok(1)")).contains("ret: Result<Int"));
    assert!(
        rendered_text(&engine.handle_line("to_s = {|n: Int| to_string(n)}"))
            .contains("to_s: (Int -> String)")
    );
    assert!(
        rendered_text(&engine.handle_line("strings = {|n: Int| [to_string(n)]}"))
            .contains("strings: (Int -> List<String>)")
    );
    assert!(
        rendered_text(&engine.handle_line("inc_ok = {|n: Int| Ok(n + 1)}"))
            .contains("inc_ok: (Int -> Result<Int")
    );

    let mapped = engine.completions("xs |*> ", "xs |*> ".len());
    assert_eq!(
        mapped.signature.as_ref().unwrap().lines.join("\n"),
        "List<Int> |*> [(Int -> _)]"
    );

    let bound = engine.completions("ret |>= ", "ret |>= ".len());
    assert_eq!(
        bound.signature.as_ref().unwrap().lines.join("\n"),
        "Result<Int> |>= [(Int -> Result<_>)]"
    );

    let composed = engine.completions("to_s >> ", "to_s >> ".len());
    assert_eq!(
        composed.signature.as_ref().unwrap().lines.join("\n"),
        "(Int -> String) >> [(String -> _)]"
    );

    let lifted = engine.completions("strings >* ", "strings >* ".len());
    assert_eq!(
        lifted.signature.as_ref().unwrap().lines.join("\n"),
        "(Int -> List<String>) >* [(String -> _)]"
    );

    let kleisli = engine.completions("inc_ok >=> ", "inc_ok >=> ".len());
    assert_eq!(
        kleisli.signature.as_ref().unwrap().lines.join("\n"),
        "(Int -> Result<Int>) >=> [(Int -> Result<_>)]"
    );
}

fn core_operator_completion_keeps_unknown_lhs_as_placeholder() {
    let engine = engine();
    let completion = engine.completions("missing |> ", "missing |> ".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("unknown lhs should still show staged operator help");

    assert_eq!(signature.lines.join("\n"), "_ |> [(_ -> _)]");
}

fn core_exposes_shared_semantic_index_for_repl_and_lsp_lookup() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("answer = 42")).contains("answer: Int"));

    let index = engine.semantic_index();
    let answer = surtr_analysis::lookup_symbol_at_cursor(&index, "answer", 3)
        .expect("REPL binding should be visible through shared semantic lookup");
    assert_eq!(answer.symbol.label, "answer");
    assert_eq!(answer.symbol.kind, surtr_analysis::CompletionKind::Variable);
    assert_eq!(answer.symbol.detail.as_deref(), Some("Int"));

    let print = index
        .find_symbol("print")
        .expect("stdlib function should be visible through shared semantic index");
    assert_eq!(print.kind, surtr_analysis::CompletionKind::FunctionCall);
    assert!(print
        .detail
        .as_deref()
        .is_some_and(|detail| detail.contains("print(")));

    let duration = index
        .find_symbol("Duration")
        .expect("stdlib type should be visible through shared semantic index");
    assert_eq!(
        duration.kind,
        surtr_analysis::CompletionKind::TypeConstructor
    );
    assert!(duration
        .detail
        .as_deref()
        .is_some_and(|detail| detail.contains("Duration")));
}

fn core_exposes_symbol_semantic_infos_before_completion_projection() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("answer = 42")).contains("answer: Int"));

    let infos = engine.symbol_semantic_infos();

    let answer = infos
        .iter()
        .find(|info| info.surface_name == "answer")
        .expect("REPL binding should be visible as semantic info");
    assert_eq!(answer.kind, surtr_analysis::CompletionKind::Variable);
    assert_eq!(answer.detail.as_deref(), Some("Int"));

    let print = infos
        .iter()
        .find(|info| info.surface_name == "print")
        .expect("stdlib function should be visible as semantic info");
    assert_eq!(print.kind, surtr_analysis::CompletionKind::FunctionCall);
    assert!(
        print.display_metadata.is_some(),
        "REPL semantic info should retain stdlib display metadata origin: {print:?}"
    );

    let duration = infos
        .iter()
        .find(|info| info.surface_name == "Duration")
        .expect("stdlib type should be visible as semantic info");
    assert_eq!(duration.identity, Some(sindr::names::TypeIdentity::Struct));
    assert_eq!(
        duration.capabilities,
        Some(
            sindr::names::SymbolCapabilities::new(
                true,
                true,
                true,
                Some(sindr::names::FacetRootKind::TypeRoot),
            )
            .with_constructor_capture(sindr::names::ConstructorCapturePolicy::Ordinary),
        )
    );
}

fn core_shared_repl_completion_helper_preserves_repl_visibility_and_presentation() {
    let engine = engine();
    let index = engine.semantic_index();

    let string_repeat = surtr_analysis::complete_repl_prefix(
        surtr_analysis::CompletionRequest {
            index: &index,
            source: "String::re",
            cursor: "String::re".len(),
        },
        surtr_analysis::CompletionScope::All,
    );
    let repeat = string_repeat
        .candidates
        .iter()
        .find(|candidate| candidate.label == "String::repeat")
        .expect("shared REPL completion should expose qualified String helpers");
    assert_eq!(repeat.kind, surtr_analysis::CompletionKind::TypePath);
    assert!(
        repeat
            .detail
            .as_deref()
            .is_some_and(|detail| detail.contains("String::repeat(")),
        "shared completion should retain signature detail: {repeat:?}"
    );

    let process_init = surtr_analysis::complete_repl_prefix(
        surtr_analysis::CompletionRequest {
            index: &index,
            source: "StandbyInit",
            cursor: "StandbyInit".len(),
        },
        surtr_analysis::CompletionScope::All,
    );
    assert!(
        process_init.candidates.is_empty(),
        "shared REPL completion must preserve xldr hidden-owner filtering: {:?}",
        process_init.candidates
    );
}

fn core_command_completion_uses_command_use_sites() {
    let mut engine = engine();

    let all_command_candidates = engine.completions(":", ":".len()).candidates;
    let all_command_rendered = all_command_candidates
        .iter()
        .map(|candidate| {
            format!(
                "{}=>{}::{:?}",
                candidate.label, candidate.replacement, candidate.detail
            )
        })
        .collect::<Vec<_>>();
    for expected in [":help", ":sig", ":quit", ":q"] {
        assert!(
            all_command_candidates
                .iter()
                .any(|candidate| candidate.label == expected && candidate.replacement == expected),
            "command-head completion should expose {expected}: {all_command_rendered:?}"
        );
    }
    let sig = all_command_candidates
        .iter()
        .find(|candidate| candidate.label == ":sig")
        .expect(":sig should be present");
    assert_eq!(
        sig.detail.as_deref(),
        Some(":sig <symbol|query>  Show signatures for visible callable, family, owner, or process surfaces")
    );

    let head_candidates = engine.completions(":si", ":si".len()).candidates;
    let head_rendered = head_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        head_candidates
            .iter()
            .any(|candidate| candidate.label == ":sig" && candidate.replacement == ":sig"),
        "command-head completion should expose :sig: {head_rendered:?}"
    );

    let indented_candidates = engine.completions("  :si", "  :si".len()).candidates;
    assert!(
        indented_candidates
            .iter()
            .any(|candidate| candidate.label == ":sig" && candidate.replacement == ":sig"),
        "command-head completion should allow leading whitespace: {indented_candidates:?}"
    );

    let plain_candidates = engine.completions("si", "si".len()).candidates;
    assert!(
        !plain_candidates
            .iter()
            .any(|candidate| candidate.label.starts_with(':')
                || candidate.replacement.starts_with(':')),
        "plain input should not expose REPL commands: {plain_candidates:?}"
    );

    let bound = rendered_text(&engine.handle_line("print = \"shadowed\""));
    assert!(bound.contains("print: String = \"shadowed\""), "{bound}");

    let sig_unqualified_candidates = engine.completions(":sig pri", ":sig pri".len()).candidates;
    let sig_unqualified_rendered = sig_unqualified_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        sig_unqualified_candidates
            .iter()
            .any(|candidate| candidate.label == "print" && candidate.replacement == "print"),
        ":sig argument completion should use normal semantic candidates: {sig_unqualified_rendered:?}"
    );
    assert!(
        !sig_unqualified_candidates
            .iter()
            .any(|candidate| candidate.label.starts_with(':')
                || candidate.replacement.starts_with(':')),
        ":sig argument completion should not include command heads: {sig_unqualified_rendered:?}"
    );

    let type_candidates = engine
        .completions(":type pri", ":type pri".len())
        .candidates;
    let type_rendered = type_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        type_candidates
            .iter()
            .any(|candidate| candidate.label == "print" && candidate.replacement == "print"),
        ":type completion should keep the binding candidate: {type_rendered:?}"
    );
    assert!(
        !type_candidates
            .iter()
            .any(|candidate| candidate.replacement == "Kernel::print"),
        ":type completion should not surface callable families: {type_rendered:?}"
    );

    let sig_candidates = engine
        .completions(":sig Kernel::pr", ":sig Kernel::pr".len())
        .candidates;
    let sig_rendered = sig_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        sig_candidates
            .iter()
            .any(|candidate| candidate.label == "Kernel::print"
                && candidate.replacement == "Kernel::print"),
        "qualified command completion should preserve callable escape hatches: {sig_rendered:?}"
    );
}

fn core_command_argument_completion_uses_command_policies() {
    let mut engine = engine();
    let bound = rendered_text(&engine.handle_line("print = \"shadowed\""));
    assert!(bound.contains("print: String = \"shadowed\""), "{bound}");
    let value = rendered_text(&engine.handle_line("41 + 1"));
    assert!(value.contains("42"), "{value}");

    let error_candidates = engine.completions(":error s", ":error s".len()).candidates;
    assert!(
        error_candidates
            .iter()
            .any(|candidate| candidate.label == "summary" && candidate.replacement == "summary"),
        ":error should complete summary: {error_candidates:?}"
    );
    assert!(
        !error_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":error should not fall through to semantic symbols: {error_candidates:?}"
    );

    let stacktrace_candidates = engine
        .completions(":stacktrace v", ":stacktrace v".len())
        .candidates;
    assert!(
        stacktrace_candidates
            .iter()
            .any(|candidate| candidate.label == "verbose" && candidate.replacement == "verbose"),
        ":stacktrace should complete verbose: {stacktrace_candidates:?}"
    );
    assert!(
        !stacktrace_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":stacktrace should not fall through to semantic symbols: {stacktrace_candidates:?}"
    );

    let reload_candidates = engine
        .completions(":reload d", ":reload d".len())
        .candidates;
    assert!(
        reload_candidates
            .iter()
            .any(|candidate| candidate.label == "defs" && candidate.replacement == "defs"),
        ":reload should complete defs: {reload_candidates:?}"
    );
    assert!(
        !reload_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":reload should not fall through to semantic symbols: {reload_candidates:?}"
    );

    let help_candidates = engine.completions(":help s", ":help s".len()).candidates;
    assert!(
        help_candidates
            .iter()
            .any(|candidate| candidate.label == ":sig" && candidate.replacement == "sig"),
        ":help should complete command topics: {help_candidates:?}"
    );
    assert!(
        !help_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":help should not fall through to semantic symbols: {help_candidates:?}"
    );

    let no_arg_candidates = engine.completions(":clear p", ":clear p".len()).candidates;
    assert!(
        no_arg_candidates.is_empty(),
        ":clear should not complete command arguments: {no_arg_candidates:?}"
    );

    let value_candidates = engine.completions(":v ", ":v ".len()).candidates;
    assert!(
        value_candidates
            .iter()
            .any(|candidate| candidate.label == "2" && candidate.replacement == "2"),
        ":v should complete result line numbers: {value_candidates:?}"
    );
    assert!(
        !value_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":v should not fall through to semantic symbols: {value_candidates:?}"
    );

    let history_candidates = engine
        .completions(":history 1,", ":history 1,".len())
        .candidates;
    assert!(
        history_candidates
            .iter()
            .any(|candidate| candidate.label == "2" && candidate.replacement == "2"),
        ":history should complete selector line numbers after commas: {history_candidates:?}"
    );

    let facet = rendered_text(&engine.handle_line("path = Tuple._0"));
    assert!(
        facet.contains("path: Facet<InfallibleStructural, _, _, _, _>"),
        "{facet}"
    );
    let facet_candidates = engine
        .completions(":facet pa", ":facet pa".len())
        .candidates;
    assert!(
        facet_candidates
            .iter()
            .any(|candidate| candidate.label == "path" && candidate.replacement == "path"),
        ":facet should complete visible facet bindings: {facet_candidates:?}"
    );
    assert!(
        !facet_candidates
            .iter()
            .any(|candidate| candidate.label == "print"),
        ":facet should not fall through to broad semantic symbols: {facet_candidates:?}"
    );

    let dir = tempfile_dir("xldr-repl-core-save-completion");
    let session_path = dir.join("session.eldr");
    fs::write(&session_path, b"snapshot").expect("path completion fixture should be written");
    let path_prefix = dir.join("sess");
    let save_input = format!(":save {}", path_prefix.display());
    let save_candidates = engine.completions(&save_input, save_input.len()).candidates;
    assert!(
        save_candidates.iter().any(|candidate| {
            candidate.label == "session.eldr"
                && candidate.replacement.ends_with("session.eldr")
                && candidate.replace_start == ":save ".len()
                && candidate.replace_end == save_input.len()
        }),
        ":save should complete .eldr paths without semantic fallback: {save_candidates:?}"
    );
}

fn core_command_outputs_use_repl_scope_before_callable_families() {
    let mut engine = engine();

    let bound = rendered_text(&engine.handle_line("compare = Ok(1)"));
    assert!(bound.contains("compare: Result<Int>"), "{bound}");

    let sig = rendered_text(&engine.handle_line(":sig compare"));
    assert!(sig.contains("No signature found for compare"), "{sig}");

    let doc = engine.handle_line(":doc compare");
    let (symbol, _) = doc_target(&doc);
    assert_eq!(symbol, "Result");

    let escaped_doc = engine.handle_line(":doc Compare::compare");
    let (symbol, _) = doc_target(&escaped_doc);
    assert_eq!(symbol, "Compare::compare");

    let info = rendered_text(&engine.handle_line(":info compare"));
    assert!(info.contains("kind: binding"), "{info}");
    assert!(info.contains("type: Result<Int>"), "{info}");

    let ty = rendered_text(&engine.handle_line(":type compare"));
    assert!(ty.contains("type: Result<Int>"), "{ty}");
}

fn core_completion_returns_type_constructors_and_type_paths() {
    let engine = engine();

    let duration = engine
        .completions("Dur", 3)
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "Duration")
        .expect("type constructor should be suggested");
    assert_eq!(duration.kind, ReplCompletionKind::TypeConstructor);
    assert!(duration
        .detail
        .as_deref()
        .is_some_and(|detail| detail.contains("Duration")));

    let int_min = engine
        .completions("Int::mi", "Int::mi".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "Int::min")
        .expect("qualified type path should be suggested");
    assert_eq!(int_min.kind, ReplCompletionKind::TypePath);
    assert!(int_min
        .detail
        .as_deref()
        .is_some_and(|detail| detail.contains("Int::min(")));
}

fn core_completion_shows_bare_result_constructors_and_bool_variants() {
    let engine = engine();

    let ok_candidates = engine.completions("Ok", "Ok".len()).candidates;
    let ok_labels = ok_candidates
        .iter()
        .map(|candidate| candidate.label.clone())
        .collect::<Vec<_>>();
    let ok = ok_candidates
        .into_iter()
        .find(|candidate| candidate.label == "Ok")
        .unwrap_or_else(|| panic!("bare Ok constructor should be suggested: {ok_labels:?}"));
    assert_eq!(ok.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(ok.replacement, "Ok");
    assert_eq!(
        ok.detail.as_deref(),
        Some("Result::Ok($T) -> Result<$T>"),
        "Ok completion detail should expose the canonical Result surface: {ok:?}"
    );

    let err_candidates = engine.completions("Err", "Err".len()).candidates;
    let err_labels = err_candidates
        .iter()
        .map(|candidate| candidate.label.clone())
        .collect::<Vec<_>>();
    let err = err_candidates
        .into_iter()
        .find(|candidate| candidate.label == "Err")
        .unwrap_or_else(|| panic!("bare Err constructor should be suggested: {err_labels:?}"));
    assert_eq!(err.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(err.replacement, "Err");
    assert_eq!(
        err.detail.as_deref(),
        Some("Result::Err(Error) -> Result<$T>"),
        "Err completion detail should expose the canonical Result surface: {err:?}"
    );

    let true_candidates = engine.completions("Tr", "Tr".len()).candidates;
    let true_labels = true_candidates
        .iter()
        .map(|candidate| candidate.label.clone())
        .collect::<Vec<_>>();
    let true_variant = true_candidates
        .into_iter()
        .find(|candidate| candidate.label == "True")
        .unwrap_or_else(|| panic!("bare True variant should be suggested: {true_labels:?}"));
    assert_eq!(true_variant.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(true_variant.replacement, "True");
    assert_eq!(
        true_variant.detail.as_deref(),
        Some("Boolean::True() -> Boolean")
    );

    let false_candidates = engine.completions("Fal", "Fal".len()).candidates;
    let false_labels = false_candidates
        .iter()
        .map(|candidate| candidate.label.clone())
        .collect::<Vec<_>>();
    let false_variant = false_candidates
        .into_iter()
        .find(|candidate| candidate.label == "False")
        .unwrap_or_else(|| panic!("bare False variant should be suggested: {false_labels:?}"));
    assert_eq!(false_variant.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(false_variant.replacement, "False");
    assert_eq!(
        false_variant.detail.as_deref(),
        Some("Boolean::False() -> Boolean")
    );
}

fn core_completion_accepts_lowercase_bool_aliases() {
    let engine = engine();

    let true_candidates = engine.completions("tru", "tru".len()).candidates;
    let true_labels = true_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    let true_variant = true_candidates
        .into_iter()
        .find(|candidate| candidate.label == "true")
        .unwrap_or_else(|| panic!("lowercase true alias should be suggested: {true_labels:?}"));
    assert_eq!(true_variant.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(true_variant.replacement, "True");

    let false_candidates = engine.completions("fal", "fal".len()).candidates;
    let false_labels = false_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    let false_variant = false_candidates
        .into_iter()
        .find(|candidate| candidate.label == "false")
        .unwrap_or_else(|| panic!("lowercase false alias should be suggested: {false_labels:?}"));
    assert_eq!(false_variant.kind, ReplCompletionKind::FunctionCall);
    assert_eq!(false_variant.replacement, "False");
}

fn core_completion_hides_lowercase_bool_alias_when_shadowed_by_value_binding() {
    let mut engine = engine();
    let bound = rendered_text(&engine.handle_line("true = 1"));
    assert!(bound.contains("true: Int = 1"), "{bound}");

    let candidates = engine.completions("tru", "tru".len()).candidates;
    let rendered = candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        !candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "True"),
        "special lowercase bool alias should disappear once shadowed: {rendered:?}"
    );
    assert!(
        candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "true"),
        "shadowing binding should remain visible as the real completion: {rendered:?}"
    );
}

fn core_completion_hides_lowercase_bool_alias_when_shadowed_by_import() {
    let mut imported_engine = ReplEngine::from_module_source(
        "hoge.srt",
        r#"
defmod Hoge {
  def true() -> Int { 1 }
}
"#,
    )
    .expect("module preload should succeed");

    let imported = rendered_text(&imported_engine.handle_line("import Hoge::true"));
    assert!(imported.contains("Imported Hoge::true"), "{imported}");

    let imported_candidates = imported_engine.completions("tru", "tru".len()).candidates;
    let imported_rendered = imported_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        !imported_candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "True"),
        "imported lowercase symbol should suppress the special bool alias: {imported_rendered:?}"
    );
    assert!(
        imported_candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "true"),
        "imported lowercase symbol should stay visible as the actual completion: {imported_rendered:?}"
    );
}

fn core_completion_hides_lowercase_bool_alias_when_shadowed_by_live_top_level_def() {
    let mut live_engine = engine();
    let defined = live_engine.handle_line("def true() -> Int { 1 }");
    assert!(
        !matches!(defined.output, ReplOutput::EvalError { .. }),
        "live top-level def should compile: {}",
        rendered_text(&defined)
    );

    let live_candidates = live_engine.completions("tru", "tru".len()).candidates;
    let live_rendered = live_candidates
        .iter()
        .map(|candidate| format!("{}=>{}", candidate.label, candidate.replacement))
        .collect::<Vec<_>>();
    assert!(
        !live_candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "True"),
        "live top-level def should suppress the special bool alias: {live_rendered:?}"
    );
    assert!(
        live_candidates
            .iter()
            .any(|candidate| candidate.label == "true" && candidate.replacement == "true"),
        "live top-level def should remain visible as the actual completion: {live_rendered:?}"
    );
}

fn core_completion_only_shows_unqualified_importable_functions_after_import() {
    let mut engine = engine();

    let labels_before = engine
        .completions("a", 1)
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert!(
        !labels_before.iter().any(|label| label == "abs"),
        "Float::abs should not be suggested as a bare call before import: {labels_before:?}"
    );
    assert!(
        engine
            .completions("Float::a", "Float::a".len())
            .candidates
            .iter()
            .any(|candidate| candidate.label == "Float::abs"),
        "qualified Float::abs completion should remain available"
    );

    let imported = rendered_text(&engine.handle_line("import Float::abs"));
    assert!(
        imported.contains("Imported Float::abs"),
        "import should succeed before testing completion: {imported}"
    );

    let labels_after = engine
        .completions("a", 1)
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert!(
        labels_after.iter().any(|label| label == "abs"),
        "Float::abs should be suggested as a bare call after import: {labels_after:?}"
    );
}

fn core_completion_and_sig_prefer_authored_signatures_for_imported_helpers() {
    let mut engine = engine();

    let then_completion = engine
        .completions("th", 2)
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "then")
        .expect("Result::then should be suggested");
    assert_eq!(
        then_completion.detail.as_deref(),
        Some("Result::then(value: Result<$A>, next: (-> Result<$B>)) -> Result<$B>")
    );

    let list_at_completion = engine
        .completions("List::a", "List::a".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "List::at")
        .expect("List::at should be suggested");
    assert_eq!(
        list_at_completion.detail.as_deref(),
        Some("List::at(values: List<$A>, index: Int) -> Result<$A>")
    );

    let imported = rendered_text(&engine.handle_line("import List::{at}"));
    assert!(imported.contains("Imported List::at"), "{imported}");

    let at_completion = engine
        .completions("at", 2)
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "at")
        .expect("imported at helper should be suggested");
    assert_eq!(
        at_completion.detail.as_deref(),
        Some("List::at(values: List<$A>, index: Int) -> Result<$A>")
    );

    assert_eq!(
        signature_text(&engine.handle_line(":sig at")).trim(),
        "List::at(values: List<$A>, index: Int) -> Result<$A, ListIndexOutOfBounds>"
    );
    assert_eq!(
        signature_text(&engine.handle_line(":sig then")).trim(),
        "Result::then(value: Result<$A>, next: (-> Result<$B>)) -> Result<$B>"
    );
    assert_eq!(
        signature_text(&engine.handle_line(":sig List::at")).trim(),
        "List::at(values: List<$A>, index: Int) -> Result<$A, ListIndexOutOfBounds>"
    );
    assert_eq!(
        signature_text(&engine.handle_line(":sig Result::then")).trim(),
        "Result::then(value: Result<$A>, next: (-> Result<$B>)) -> Result<$B>"
    );
}

fn core_completion_is_enabled_inside_string_interpolation_only() {
    let engine = engine();
    let string_body = r#""plain Str"#;
    assert!(
        engine
            .completions(string_body, string_body.len())
            .candidates
            .is_empty(),
        "completion should stay disabled in ordinary string text"
    );

    let interpolation = r#""plain #{Str"#;
    let labels = engine
        .completions(interpolation, interpolation.len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"String".to_string()),
        "completion should be enabled inside string interpolation: {labels:?}"
    );
}

fn core_completion_shows_builtin_owner_surfaces_and_hides_special_types() {
    let engine = engine();
    let completion_context = engine.completion_context();

    for (prefix, expected) in [
        ("Str", "String"),
        ("Lis", "List"),
        ("Fac", "Facet"),
        ("IO", "IO"),
        ("Jso", "Json"),
    ] {
        let candidate = completion_context
            .completions(prefix, prefix.len())
            .candidates
            .into_iter()
            .find(|candidate| candidate.label == expected)
            .unwrap_or_else(|| panic!("{expected} should be suggested for prefix {prefix}"));
        assert_eq!(candidate.kind, ReplCompletionKind::TypeConstructor);
    }

    let string_repeat = completion_context
        .completions("String::re", "String::re".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "String::repeat")
        .expect("qualified String helper should be suggested");
    assert_eq!(string_repeat.kind, ReplCompletionKind::TypePath);

    let facet_view = completion_context
        .completions("Facet::v", "Facet::v".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "Facet::view")
        .expect("qualified Facet helper should be suggested");
    assert_eq!(facet_view.kind, ReplCompletionKind::TypePath);

    let excluded = [
        "MatchArms",
        "MatchResult",
        "CondClauses",
        "BulkUpdateEntries",
        "Hole",
        "Lazy",
        "StandbyInit",
        "Closure",
    ];
    for name in excluded {
        let labels = completion_context
            .completions(name, name.len())
            .candidates
            .into_iter()
            .map(|candidate| candidate.label)
            .collect::<Vec<_>>();
        assert!(
            !labels.iter().any(|label| label == name),
            "{name} should not be suggested: {labels:?}"
        );
    }
}

fn core_completion_keeps_type_owners_ahead_of_members_for_pascal_case_prefix() {
    let engine = engine();
    let labels = engine
        .completions("Int", "Int".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .take(6)
        .collect::<Vec<_>>();

    assert_eq!(
        labels,
        vec![
            "Int".to_string(),
            "IntBase".to_string(),
            "IntLiteralEmpty".to_string(),
            "IntLiteralInvalidDigit".to_string(),
            "IntLiteralMissingDigits".to_string(),
            "IntLiteralPatternMismatch".to_string(),
        ]
    );
}

fn core_completion_shows_user_defined_module_owners() {
    let engine = ReplEngine::from_module_source(
        "demo_module.srt",
        r#"
defmod Demo {
  def hello() -> String { "hi" }
}
"#,
    )
    .expect("module preload should bootstrap");

    let demo = engine
        .completions("Dem", 3)
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "Demo")
        .expect("user-defined module owner should be suggested");
    assert_eq!(demo.kind, ReplCompletionKind::TypeConstructor);

    let hello = engine
        .completions("Demo::h", "Demo::h".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "Demo::hello")
        .expect("user-defined module member should be suggested");
    assert_eq!(hello.kind, ReplCompletionKind::TypePath);

    let mut engine = engine;
    let sig = signature_text(&engine.handle_line(":sig Demo::hello"));
    assert!(sig.contains("Demo::hello() -> String"), "{sig}");
    assert!(!sig.contains("Global::"), "{sig}");
}

fn core_completion_shows_script_preload_owner_and_members_without_docs() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name, age }
  }

  def birthday(self) -> Self {
    put(~self.age, self.age + 1)
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let user = engine
        .completions("U", "U".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "User")
        .expect("script preload owner should be suggested without docs");
    assert_eq!(user.kind, ReplCompletionKind::TypeConstructor);

    let ctor = engine
        .completions("User::n", "User::n".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "User::new")
        .expect("undocumented impl ctor should be suggested");
    assert_eq!(ctor.kind, ReplCompletionKind::TypePath);
    assert!(
        ctor.detail
            .as_deref()
            .is_some_and(|detail| detail.contains("User::new(name: String, age: Int) -> User")),
        "constructor completion detail should use surface names: {ctor:?}"
    );
    assert!(
        ctor.detail
            .as_deref()
            .is_none_or(|detail| !detail.contains("Global::")),
        "constructor completion detail must not expose Global: {ctor:?}"
    );

    let method = engine
        .completions("User::b", "User::b".len())
        .candidates
        .into_iter()
        .find(|candidate| candidate.label == "User::birthday")
        .expect("undocumented impl method should be suggested");
    assert_eq!(method.kind, ReplCompletionKind::TypePath);
    assert!(
        method
            .detail
            .as_deref()
            .is_some_and(|detail| detail.contains("User::birthday(self: User) -> User")),
        "method completion detail should use surface names: {method:?}"
    );
    assert!(
        method
            .detail
            .as_deref()
            .is_none_or(|detail| !detail.contains("Global::")),
        "method completion detail must not expose Global: {method:?}"
    );
}

fn core_script_top_level_defs_are_signature_and_completion_surfaces_without_docs() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/top_level.srt",
        r#"
def greet(name: String) -> String { name }
"#,
    )
    .expect("script preload should bootstrap");

    let sig = signature_text(&engine.handle_line(":sig greet"));
    assert!(
        sig.contains("greet(name: String) -> String"),
        "script top-level def should have a signature surface: {sig}"
    );
    assert!(!sig.contains("Global::"), "{sig}");

    let completion = engine.completions("gre", "gre".len());
    let greet = completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "greet")
        .expect("script top-level def should be suggested by bare name");
    assert_eq!(greet.kind, ReplCompletionKind::FunctionCall);
    assert!(
        greet
            .detail
            .as_deref()
            .is_some_and(|detail| detail.contains("greet(name: String) -> String")),
        "completion detail should mirror :sig: {greet:?}"
    );

    let docs = rendered_text(&engine.handle_line(":doc greet"));
    assert!(
        docs.contains("No docs found for greet"),
        "top-level script defs do not get doc support in this change: {docs}"
    );
}

fn core_sig_query_uses_trait_definition_without_docs() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/no_doc_impl.srt",
        r#"
deftrait Pairwise {
  def pair(self: Self, rhs: Self) -> Self
}

defstruct Duo {
  value: Int,
}

impl Duo {
  def new(value: Int) -> Self {
    Duo { value }
  }
}

impl Pairwise for Duo {
  def pair(self: Self, rhs: Self) -> Self {
    Duo { value: self.value + rhs.value }
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let doc = doc_text(&engine.handle_line(":doc Pairwise::pair"));
    assert!(
        doc.contains("undocumented") || doc.contains("No docs found"),
        "{doc}"
    );
    let sig = signature_text(&engine.handle_line(":sig Pairwise::pair"));
    assert!(sig.contains("pair(self: Self, rhs: Self) -> Self"), "{sig}");
}

fn core_live_repl_top_level_defs_are_signature_and_completion_surfaces() {
    let mut engine = engine();
    let def = engine.handle_line("def local(x: Int) -> Int { x + 1 }");
    assert!(
        !matches!(def.output, ReplOutput::EvalError { .. }),
        "live top-level def should compile: {}",
        rendered_text(&def)
    );

    let sig = signature_text(&engine.handle_line(":sig local"));
    assert!(
        sig.contains("local(x: Int) -> Int"),
        "live REPL top-level def should have a signature surface: {sig}"
    );

    let completion = engine.completions("loc", "loc".len());
    let local = completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "local")
        .expect("live REPL top-level def should be suggested by bare name");
    assert_eq!(local.kind, ReplCompletionKind::FunctionCall);
    assert!(
        local
            .detail
            .as_deref()
            .is_some_and(|detail| detail.contains("local(x: Int) -> Int")),
        "completion detail should mirror :sig: {local:?}"
    );
}

fn core_completion_hides_global_noise_for_empty_constructor_call_arguments() {
    let engine = engine();
    let completion = engine.completions("Duration(", "Duration(".len());

    let signature = completion
        .signature
        .as_ref()
        .expect("constructor call should still show signature help");
    assert_eq!(signature.active_parameter, Some(0));
    assert!(
        signature.lines.join("\n").contains("Duration::new("),
        "constructor signature should remain visible: {:?}",
        signature.lines
    );
    assert!(
        signature.lines.join("\n").contains("[Int]"),
        "active constructor parameter should be highlighted: {:?}",
        signature.lines
    );
    assert!(
        completion.candidates.is_empty(),
        "empty constructor argument position should not show unrelated global candidates: {:?}",
        completion.candidates
    );
}

fn core_completion_shows_script_preload_constructor_signature_without_docs() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> User {
    User { name, age }
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User(", "User(".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("script preload constructor should show signature help");
    assert_eq!(signature.active_parameter, Some(0));
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("User::new("),
        "constructor signature should use owner surface: {rendered:?}"
    );
    assert!(
        rendered.contains("name: [String]"),
        "first constructor parameter should be highlighted: {rendered:?}"
    );
    assert!(
        rendered.contains("-> User"),
        "constructor signature should follow the actual new return type: {rendered:?}"
    );
    assert!(
        !rendered.contains("-> Self"),
        "constructor signature must not fall back to synthesized Self when new returns User: {rendered:?}"
    );
}

fn core_completion_constructor_signature_follows_result_self_new_signature() {
    let engine = ReplEngine::from_script_source(
        "tmp/user_result.srt",
        r#"
defstruct User {
  name: String,
}

impl User {
  def new(name: String) -> Result<Self> {
    Ok(User { name })
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User(", "User(".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("script preload constructor should show signature help");
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("User::new(name: [String]) -> Result<User>"),
        "constructor signature should follow Result<Self> from new after type normalization: {rendered:?}"
    );
    assert!(
        !rendered.contains("-> Self"),
        "constructor signature must not use synthesized Self fallback when new returns Result<Self>: {rendered:?}"
    );
}

fn core_completion_hides_enum_variants_until_owner_path_is_confirmed() {
    let engine = engine();

    let bare_labels = engine
        .completions("IntB", "IntB".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert_eq!(
        bare_labels,
        vec![
            "IntBase",
            "IntBase::label",
            "IntBase::prefix",
            "IntBase::radix"
        ]
    );

    let bool_labels = engine
        .completions("Bool", "Bool".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert_eq!(
        bool_labels,
        vec![
            "Boolean",
            "BooleanLiteralPatternMismatch",
            "Boolean::eqv",
            "Boolean::implies",
            "Boolean::not",
            "Boolean::xor"
        ]
    );

    let qualified_labels = engine
        .completions("IntBase::", "IntBase::".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();
    assert!(qualified_labels.contains(&"IntBase::Bin".to_string()));
    assert!(qualified_labels.contains(&"IntBase::Dec".to_string()));
    assert!(qualified_labels.contains(&"IntBase::Hex".to_string()));
    assert!(qualified_labels.contains(&"IntBase::Oct".to_string()));

    let boolean_candidates = engine
        .completions("Boolean::", "Boolean::".len())
        .candidates;
    let boolean_labels = boolean_candidates
        .iter()
        .map(|candidate| candidate.label.clone())
        .collect::<Vec<_>>();
    assert!(boolean_labels.contains(&"Boolean::True".to_string()));
    assert!(boolean_labels.contains(&"Boolean::False".to_string()));

    let true_variant = boolean_candidates
        .into_iter()
        .find(|candidate| candidate.label == "Boolean::True")
        .expect("qualified Boolean variant should be suggested");
    assert_eq!(true_variant.kind, ReplCompletionKind::TypePath);
    assert_eq!(
        true_variant.detail.as_deref(),
        Some("Boolean::True() -> Boolean")
    );
}

fn core_completion_shows_tuple_variant_signature_help() {
    let engine = engine();
    let completion = engine.completions("BitWidth::Any(", "BitWidth::Any(".len());

    let signature = completion
        .signature
        .as_ref()
        .expect("tuple variant call should show signature help");
    assert_eq!(signature.active_parameter, Some(0));
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("BitWidth::Any([Int]) -> BitWidth"),
        "tuple variant signature should expose constructor call shape: {rendered:?}"
    );
}

fn core_completion_ranks_constructor_arguments_by_expected_parameter_type() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("n = 3")).contains("n: Int"));
    assert!(rendered_text(&engine.handle_line(r#"s = "text""#)).contains("s: String"));

    let completion = engine.completions("Duration(", "Duration(".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();

    assert!(
        labels.contains(&"n"),
        "Int binding should be suggested for constructor argument: {labels:?}"
    );
    assert!(
        labels.contains(&"s"),
        "String binding should remain available but ranked lower: {labels:?}"
    );
    assert!(
        labels.iter().position(|label| label == &"n")
            < labels.iter().position(|label| label == &"s"),
        "Int binding should rank before String binding for Int constructor argument: {labels:?}"
    );
}

fn core_completion_hides_trait_impl_members_from_qualified_type_paths() {
    let engine = engine();
    let labels = engine
        .completions("Boolean::", "Boolean::".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();

    for expected in [
        "Boolean::not",
        "Boolean::xor",
        "Boolean::eqv",
        "Boolean::implies",
    ] {
        assert!(
            labels.iter().any(|label| label == expected),
            "owner method should be suggested: {expected}; labels={labels:?}"
        );
    }

    for hidden in [
        "Boolean::impl Show for Boolean::to_string",
        "Boolean::impl Eq for Boolean::eq",
        "Boolean::impl Neq for Boolean::neq",
        "Boolean::impl Convert<String> for Boolean::to",
    ] {
        assert!(
            labels.iter().all(|label| label != hidden),
            "trait impl member should not be suggested: {hidden}; labels={labels:?}"
        );
    }
}

fn core_completion_hides_trait_impl_roots_from_expression_candidates() {
    let engine = engine();
    let labels = engine
        .completions("i", "i".len())
        .candidates
        .into_iter()
        .map(|candidate| candidate.label)
        .collect::<Vec<_>>();

    assert!(
        labels.iter().all(|label| !label.starts_with("impl ")),
        "trait impl roots should not be suggested as expression candidates: {labels:?}"
    );
}

fn core_completion_shows_facet_path_candidates_for_type_root() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defstruct User {
  readonly name: String,
  private password: String,
  age: Int
}

impl User {
  def new(name: String, password: String, age: Int) -> Self {
    User { name: name, password: password, age: age }
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User.", "User.".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"name"),
        "type-root facet completion should include record fields: {labels:?}"
    );
    assert!(
        labels.contains(&"age"),
        "type-root facet completion should include record fields: {labels:?}"
    );
    assert!(
        !labels.contains(&"password"),
        "REPL facet completion should hide private fields outside owner scope: {labels:?}"
    );
    let name = completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "name")
        .expect("readonly field should be present");
    assert!(
        name.detail
            .as_deref()
            .is_some_and(|detail| detail.contains("readonly")),
        "readonly field detail should show readonly policy: {name:?}"
    );
    let signature = completion
        .signature
        .as_ref()
        .expect("type-root facet completion should show signature help");
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("User.[field] -> Facet<InfallibleStructural, User, _, _, _>"),
        "unexpected facet signature help: {rendered:?}"
    );
}

fn core_completion_shows_record_enum_and_tuple_facet_segments() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord Profile(first: String, last: String)
defrecord User(pair: (String, Int), profile: Profile)
defenum Slot { Taken(Profile), Empty }
"#,
    )
    .expect("script preload should bootstrap");

    let tuple_completion = engine.completions("User.pair.", "User.pair.".len());
    let tuple_labels = tuple_completion
        .candidates
        .iter()
        .map(|candidate| (candidate.label.as_str(), candidate.detail.as_deref()))
        .collect::<Vec<_>>();
    assert!(
        tuple_labels
            .iter()
            .any(|(label, detail)| *label == "_0" && detail == &Some("_0: String")),
        "tuple focus should expose typed tuple indexes: {tuple_labels:?}"
    );
    assert!(
        tuple_labels
            .iter()
            .any(|(label, detail)| *label == "_1" && detail == &Some("_1: Int")),
        "tuple focus should expose typed tuple indexes: {tuple_labels:?}"
    );

    let record_completion = engine.completions("User.profile.", "User.profile.".len());
    let record_labels = record_completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        record_labels.contains(&"first") && record_labels.contains(&"last"),
        "record focus should expose record fields: {record_labels:?}"
    );

    let enum_completion = engine.completions("Slot.", "Slot.".len());
    let enum_labels = enum_completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        enum_labels.contains(&"Taken") && enum_labels.contains(&"Empty"),
        "enum root should expose variants: {enum_labels:?}"
    );
}

fn core_completion_treats_result_focus_as_ok_value_for_next_facet_segment() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord Profile(first: String, last: String)
defrecord User(profile: Result<Profile>)
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User.profile.", "User.profile.".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"first") && labels.contains(&"last"),
        "Result focus should be transparent for Ok payload segment completion: {labels:?}"
    );

    let path = rendered_text(&engine.handle_line("path = User.profile.first"));
    assert!(
        path.contains("path: Facet<InfallibleStructural, User, String, _, _>"),
        "completion should match the compiled transparent Result path: {path}"
    );
}

fn core_completion_suggests_tuple_root_placeholder_only_until_index_is_finished() {
    let engine = engine();

    let root_completion = engine.completions("Tuple.", "Tuple.".len());
    let root_labels = root_completion
        .candidates
        .iter()
        .map(|candidate| (candidate.label.as_str(), candidate.detail.as_deref()))
        .collect::<Vec<_>>();
    assert_eq!(
        root_labels,
        vec![("_", Some("pass _N: N requires UnsignedInt"))],
        "Tuple. should only suggest the tuple index placeholder: {root_labels:?}"
    );

    let numeric_completion = engine.completions("Tuple._0", "Tuple._0".len());
    assert!(
        numeric_completion.candidates.is_empty(),
        "Tuple._N should not suggest more until the next dot: {:?}",
        numeric_completion.candidates
    );
}

fn core_completion_suggests_list_and_hashmap_facet_patterns_and_nests_dynamic_segments() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord Profile(first: String)
defrecord User(scores: List<Profile>, by_name: HashMap<Profile>)
"#,
    )
    .expect("script preload should bootstrap");
    assert!(rendered_text(&engine.handle_line("idx = 0")).contains("idx: Int"));
    assert!(rendered_text(&engine.handle_line(r#"key = "alice""#)).contains("key: String"));

    let list_completion = engine.completions("User.scores.", "User.scores.".len());
    let list_labels = list_completion
        .candidates
        .iter()
        .map(|candidate| (candidate.label.as_str(), candidate.detail.as_deref()))
        .collect::<Vec<_>>();
    assert!(
        list_labels.iter().any(|(label, detail)| {
            *label == "[idx]" && detail == &Some("[idx: Int] -> Profile")
        }),
        "List focus should suggest index pattern: {list_labels:?}"
    );
    assert!(
        list_labels.iter().any(|(label, detail)| {
            *label == "[start..end]" && detail == &Some("[start..end: Int] -> List<Profile>")
        }),
        "List focus should suggest range pattern: {list_labels:?}"
    );

    let nested_list = engine.completions("User.scores.[idx + 1].", "User.scores.[idx + 1].".len());
    let nested_list_labels = nested_list
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        nested_list_labels.contains(&"first"),
        "dynamic list segment should advance to element focus: {nested_list_labels:?}"
    );

    let map_completion = engine.completions("User.by_name.", "User.by_name.".len());
    let map_labels = map_completion
        .candidates
        .iter()
        .map(|candidate| (candidate.label.as_str(), candidate.detail.as_deref()))
        .collect::<Vec<_>>();
    assert!(
        map_labels.iter().any(|(label, detail)| {
            *label == "[key]" && detail == &Some("[key: String] -> Profile")
        }),
        "HashMap focus should suggest key pattern: {map_labels:?}"
    );

    let nested_map = engine.completions("User.by_name.[key].", "User.by_name.[key].".len());
    let nested_map_labels = nested_map
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        nested_map_labels.contains(&"first"),
        "dynamic map segment should advance to value focus: {nested_map_labels:?}"
    );
}

fn core_completion_shows_facet_path_candidates_for_value_root() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(name: String, age: Int)
"#,
    )
    .expect("script preload should bootstrap");
    assert!(
        rendered_text(&engine.handle_line(r#"user = User("alice", 42)"#)).contains("user: User")
    );

    let completion = engine.completions("user.", "user.".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"name"),
        "value-root facet completion should include record fields: {labels:?}"
    );
    assert!(
        labels.contains(&"age"),
        "value-root facet completion should include record fields: {labels:?}"
    );
    let signature = completion
        .signature
        .as_ref()
        .expect("value-root facet completion should show signature help");
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("user.[field] -> _"),
        "unexpected value-root facet signature help: {rendered:?}"
    );
}

fn core_completion_shows_facet_view_closure_candidates() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(name: String, age: Int)
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("&User.", "&User.".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"name"),
        "facet view-closure completion should include record fields: {labels:?}"
    );
    assert!(
        labels.contains(&"age"),
        "facet view-closure completion should include record fields: {labels:?}"
    );
    let signature = completion
        .signature
        .as_ref()
        .expect("facet view-closure completion should show signature help");
    let rendered = signature.lines.join("\n");
    assert!(
        rendered.contains("&User.[field] -> (User -> _)"),
        "unexpected facet view-closure signature help: {rendered:?}"
    );
}

fn core_completion_shows_result_focus_api_help_for_facet_paths() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(score: Result<Int>)
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User.score.", "User.score.".len());
    let rendered = completion
        .signature
        .as_ref()
        .expect("result focus facet completion should show signature help")
        .lines
        .join("\n");
    assert!(
        rendered.contains("Facet::view(User.score, User) -> Result<Int>"),
        "result focus should use view-based return help: {rendered:?}"
    );
    assert!(
        rendered.contains(
            "Facet::over_result(User.score, User, (Result<Int> -> Result<Result<Int>>)) -> Result<User>"
        ),
        "result focus should expose over_result help: {rendered:?}"
    );
}

fn core_completion_shows_combined_list_tuple_result_help() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(scores: List<(String, Result<Int>)>)
"#,
    )
    .expect("script preload should bootstrap");

    let completion = engine.completions("User.scores.[0]._1.", "User.scores.[0]._1.".len());
    let rendered = completion
        .signature
        .as_ref()
        .expect("combined facet path completion should show signature help")
        .lines
        .join("\n");
    assert!(
        rendered.contains("Facet::view(User.scores.[0]._1, User) -> Result<Result<Int>>"),
        "combined facet path should keep list-index fallibility in view help: {rendered:?}"
    );
    assert!(
        rendered.contains("Facet::over_result(User.scores.[0]._1, User, (Result<Int> -> Result<Result<Int>>)) -> Result<User>"),
        "combined facet path should preserve result-focus API help: {rendered:?}"
    );
}

fn core_completion_suggests_facet_path_roots_for_facet_api_first_argument() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(name: String, age: Int)
defenum Slot { Some(String), None }
"#,
    )
    .expect("script preload should bootstrap");
    assert!(rendered_text(&engine.handle_line("name_path = User.name"))
        .contains("Facet<InfallibleStructural, User, String, _, _>"));

    for api in [
        "view",
        "preview",
        "put",
        "set",
        "over",
        "over_result",
        "case_set",
        "case_over",
    ] {
        let input = format!("Facet::{api}(");
        let completion = engine.completions(&input, input.len());
        let labels = completion
            .candidates
            .iter()
            .map(|candidate| candidate.label.as_str())
            .collect::<Vec<_>>();

        assert!(
            labels.contains(&"User"),
            "{api} first argument should suggest path-constructable record roots: {labels:?}"
        );
        assert!(
            labels.contains(&"Slot"),
            "{api} first argument should suggest path-constructable enum roots: {labels:?}"
        );
        assert!(
            labels.contains(&"Boolean"),
            "{api} first argument should suggest Boolean variant root: {labels:?}"
        );
        assert!(
            labels.contains(&"name_path"),
            "{api} first argument should suggest Facet bindings: {labels:?}"
        );
        for primitive in ["String", "Int", "Float", "Function"] {
            assert!(
                !labels.contains(&primitive),
                "{api} first argument should not suggest primitive root {primitive}: {labels:?}"
            );
        }
    }

    for api in [
        "view",
        "preview",
        "put",
        "set",
        "over",
        "over_result",
        "case_set",
        "case_over",
    ] {
        let input = format!("{api}(");
        let completion = engine.completions(&input, input.len());
        let labels = completion
            .candidates
            .iter()
            .map(|candidate| candidate.label.as_str())
            .collect::<Vec<_>>();

        assert!(
            labels.contains(&"User"),
            "{api} short-form first argument should suggest path roots: {labels:?}"
        );
        assert!(
            labels.contains(&"name_path"),
            "{api} short-form first argument should suggest Facet bindings: {labels:?}"
        );
        assert!(
            !labels.contains(&"String"),
            "{api} short-form first argument should not suggest primitive roots: {labels:?}"
        );
    }
}

fn core_completion_suppresses_facet_api_roots_for_invalid_capture_path_argument() {
    let engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(name: String, age: Int)
"#,
    )
    .expect("script preload should bootstrap");

    for input in ["over(&Us", "Facet::over(&Us", "over(_."] {
        let completion = engine.completions(input, input.len());
        assert!(
            completion.candidates.is_empty(),
            "invalid FacetPath argument context should not suggest roots for {input:?}: {:?}",
            completion.candidates
        );
    }
}

fn core_completion_derives_facet_segments_from_facet_binding_focus() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord Profile(first: String, last: String)
defrecord User(profile: Profile, age: Int)
"#,
    )
    .expect("script preload should bootstrap");
    assert!(rendered_text(&engine.handle_line("p = User.profile"))
        .contains("Facet<InfallibleStructural, User, Profile, _, _>"));

    let completion = engine.completions("p.", "p.".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();

    assert!(
        labels.contains(&"first"),
        "Facet binding focus should expose Profile fields: {labels:?}"
    );
    assert!(
        labels.contains(&"last"),
        "Facet binding focus should expose Profile fields: {labels:?}"
    );
    assert!(
        !labels.contains(&"age"),
        "Facet binding completion should use focus type, not original source type: {labels:?}"
    );
}

fn core_completion_respects_shadowed_facet_api_names() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
defrecord User(name: String)
def view(value: Int) -> Int { value }
"#,
    )
    .expect("script preload should bootstrap");
    assert!(rendered_text(&engine.handle_line("name_path = User.name"))
        .contains("Facet<InfallibleStructural, User, String, _, _>"));
    assert!(rendered_text(&engine.handle_line("n = 1")).contains("n: Int"));

    let completion = engine.completions("view(", "view(".len());
    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();

    assert!(
        !labels.contains(&"User"),
        "shadowed view(Int) should not trigger Facet path roots: {labels:?}"
    );
    assert!(
        labels.contains(&"n"),
        "ordinary argument inference should still offer Int variables: {labels:?}"
    );
}

fn core_completion_uses_argument_position_for_variable_candidates_and_signature_help() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line("n = 3")).contains("n: Int"));
    assert!(rendered_text(&engine.handle_line(r#"s = "text""#)).contains("s: String"));

    let input = "Int::min(";
    let completion = engine.completions(input, input.len());
    let signature = completion
        .signature
        .as_ref()
        .expect("signature help should be available at call argument position");
    assert_eq!(signature.active_parameter, Some(0));
    let signature_text = signature.lines.join("\n");
    assert!(signature_text.contains("Int::min("), "{signature_text}");
    assert!(
        signature_text.contains("[Int]"),
        "active parameter type should be highlighted: {signature_text}"
    );

    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"n"),
        "Int binding should be suggested: {labels:?}"
    );
    assert!(
        labels.contains(&"s"),
        "String binding should remain available but ranked lower: {labels:?}"
    );
    assert!(
        labels.iter().position(|label| label == &"n")
            < labels.iter().position(|label| label == &"s"),
        "Int binding should rank before String binding for Int argument: {labels:?}"
    );
}

fn core_completion_shows_nested_if_and_string_contains_signatures() {
    let mut engine = engine();
    assert!(rendered_text(&engine.handle_line(r#"word = "Hello""#)).contains("word: String"));
    assert!(rendered_text(&engine.handle_line(r#"needle = "ll""#)).contains("needle: String"));
    assert!(rendered_text(&engine.handle_line("width = 2")).contains("width: Int"));

    let input = "if(String::contains(w";
    let completion = engine.completions(input, input.len());
    let signature = completion
        .signature
        .as_ref()
        .expect("nested call signature help should be visible");
    assert_eq!(signature.active_parameter, Some(0));
    assert_eq!(signature.lines.len(), 2, "{signature:?}");
    assert!(
        signature.lines[0].contains("if(flag: [Boolean]"),
        "{signature:?}"
    );
    assert!(
        signature.lines[1].contains("  String::contains(value: [String], needle: String)"),
        "{signature:?}"
    );

    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"word"),
        "inner prefix should suggest word: {labels:?}"
    );
    assert!(
        labels.contains(&"width"),
        "nonmatching w-prefix candidates should remain visible after ranked String candidates: {labels:?}"
    );
    assert!(
        labels.iter().position(|label| label == &"word")
            < labels.iter().position(|label| label == &"width"),
        "String candidates should rank before nonmatching w-prefix candidates: {labels:?}"
    );
}

fn core_completion_keeps_path_candidates_while_typing_if_condition_call() {
    let engine = engine();
    let input = "if(String::c";
    let completion = engine.completions(input, input.len());
    let signature = completion
        .signature
        .as_ref()
        .expect("if signature help should stay visible while typing condition");
    assert!(
        signature
            .lines
            .iter()
            .any(|line| line.contains("if(flag: [Boolean]")),
        "{signature:?}"
    );

    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"String::contains"),
        "String path candidates should be visible inside if condition: {labels:?}"
    );
}

fn core_completion_keeps_type_candidates_while_typing_if_condition_prefix() {
    let engine = engine();
    let input = "if(S";
    let completion = engine.completions(input, input.len());
    let signature = completion
        .signature
        .as_ref()
        .expect("if signature help should stay visible while typing condition");
    assert!(
        signature
            .lines
            .iter()
            .any(|line| line.contains("if(flag: [Boolean]")),
        "{signature:?}"
    );

    let labels = completion
        .candidates
        .iter()
        .map(|candidate| candidate.label.as_str())
        .collect::<Vec<_>>();
    assert!(
        labels.contains(&"String"),
        "String type candidate should be visible inside if condition: {labels:?}"
    );
}

fn core_completion_prefers_trait_surface_for_neq_helper_details() {
    let engine = engine();

    let bare = engine.completions("neq", "neq".len());
    let neq = bare
        .candidates
        .iter()
        .find(|candidate| candidate.label == "neq")
        .expect("neq helper should be suggested");
    let bare_detail = neq
        .detail
        .as_deref()
        .expect("neq helper should include detail");
    assert_eq!(
        bare_detail,
        "trait Eq { eq(self: Self, rhs: Self) -> Boolean, neq(self: Self, rhs: Self) -> Boolean }"
    );

    let call = engine.completions("neq(", "neq(".len());
    let call_signature = call
        .signature
        .as_ref()
        .expect("neq call-site should show signature help");
    assert_eq!(call_signature.active_parameter, Some(0));
    let call_text = call_signature.lines.join("\n");
    assert_eq!(
        call_text.trim(),
        "trait Eq { eq(self: [Self], rhs: Self) -> Boolean, neq(self: Self, rhs: Self) -> Boolean }"
    );

    let inferred = engine.completions("neq(1", "neq(1".len());
    let inferred_signature = inferred
        .signature
        .as_ref()
        .expect("neq(1 should keep signature help visible");
    assert_eq!(inferred_signature.active_parameter, Some(0));
    let inferred_text = inferred_signature.lines.join("\n");
    assert_eq!(
        inferred_text.trim(),
        "trait Eq { eq(self: [Self], rhs: Self) -> Boolean, neq(self: Self, rhs: Self) -> Boolean }"
    );

    let second_arg = engine.completions("neq(,)", "neq(,)".len() - 1);
    let second_signature = second_arg
        .signature
        .as_ref()
        .expect("neq(,) should keep signature help visible");
    assert_eq!(second_signature.active_parameter, Some(1));
    let second_text = second_signature.lines.join("\n");
    assert_eq!(
        second_text.trim(),
        "trait Eq { eq(self: Self, rhs: [Self) -> Boolean], neq(self: Self, rhs: Self) -> Boolean }"
    );
}

fn status_text(result: &ReplResult) -> String {
    match &result.output {
        ReplOutput::StatusMessage(message) => message.clone(),
        other => panic!("expected status output, got {}", output_kind(other)),
    }
}

fn output_kind(output: &ReplOutput) -> &'static str {
    match output {
        ReplOutput::EvalStarted { .. } => "EvalStarted",
        ReplOutput::EvalSuccess { .. } => "EvalSuccess",
        ReplOutput::EvalError { .. } => "EvalError",
        ReplOutput::PlainText { .. } => "PlainText",
        ReplOutput::StyledDoc { .. } => "StyledDoc",
        ReplOutput::Diagnostic { .. } => "Diagnostic",
        ReplOutput::DocResolved { .. } => "DocResolved",
        ReplOutput::StatusMessage(_) => "StatusMessage",
    }
}

fn strip_ansi(input: &str) -> String {
    let mut out = String::new();
    let mut chars = input.chars().peekable();

    while let Some(ch) = chars.next() {
        if ch == '\u{1b}' && matches!(chars.peek(), Some('[')) {
            chars.next();
            for next in chars.by_ref() {
                if ('@'..='~').contains(&next) {
                    break;
                }
            }
            continue;
        }
        out.push(ch);
    }

    out
}

fn core_keeps_bindings_and_definitions_between_inputs() {
    let mut engine = engine();

    let bind = engine.handle_line("x = 42");
    assert!(!bind.should_exit);
    assert!(rendered_text(&bind).contains("x: Int = 42"));

    let def = engine.handle_line("def add_core(x: Int, y: Int) -> Int { x + y }");
    assert!(!def.should_exit);

    let call = engine.handle_line("add_core(1, 2)");
    assert!(!call.should_exit);
    assert!(rendered_text(&call).contains("3"));

    let value = engine.handle_line("x");
    assert!(!value.should_exit);
    assert!(rendered_text(&value).contains("42"));
}

fn core_rolls_back_failed_input_without_losing_previous_state() {
    let mut engine = engine();

    let bind = engine.handle_line("x = 1");
    assert!(rendered_text(&bind).contains("x: Int = 1"));

    let err = engine.handle_line("bad: Int = \"oops\"");
    assert!(!err.should_exit);
    assert!(matches!(err.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&err).contains("expected Int, got String"));

    let value = engine.handle_line("x");
    assert!(!value.should_exit);
    assert!(rendered_text(&value).contains("1"));
}

fn core_constructor_relation_rolls_back_after_failed_input() {
    let mut engine = engine();

    let definition = engine.handle_line(
        "def require_same(left: $F<Int>, right: $F<Int>) -> Int where $F: Functor { mapped = Functor::fmap(left, {|x| x}); 1 }",
    );
    assert!(!definition.should_exit);
    assert!(
        !matches!(definition.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&definition)
    );

    let rejected = engine.handle_line("require_same(Option::Some(1), [2])");
    assert!(!rejected.should_exit);
    assert!(matches!(rejected.output, ReplOutput::EvalError { .. }));
    assert!(
        rendered_text(&rejected).contains("Type constructor family mismatch"),
        "{}",
        rendered_text(&rejected)
    );

    let opposite = engine.handle_line("require_same([1], [2])");
    assert!(!opposite.should_exit);
    assert!(
        !matches!(opposite.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&opposite)
    );
    assert!(
        rendered_text(&opposite).contains('1'),
        "{}",
        rendered_text(&opposite)
    );
}

fn core_nominal_constructor_value_survives_failed_bound_check() {
    let mut engine = ReplEngine::from_script_source(
        "nominal_constructor_parameter.srt",
        r#"
defstruct ReplOptionT<$M, $A>
where
  $M: Monad
{
  inner: $M<Option<$A>>,
}
impl ReplOptionT {
  def new(inner: $M<Option<$A>>) -> ReplOptionT<$M, $A>
  where
    $M: Monad
  {
    ReplOptionT { inner: inner }
  }
}

defenum Plain<$A> {
  Plain($A),
}
"#,
    )
    .expect("nominal constructor parameter preload should load");

    let stored =
        engine.handle_line("value: ReplOptionT<Result, Int> = ReplOptionT(Ok(Option::Some(1)))");
    assert!(!stored.should_exit);
    assert!(
        !matches!(stored.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&stored)
    );

    let rejected = engine.handle_line("bad: ReplOptionT<Plain, Int> = value");
    assert!(!rejected.should_exit);
    assert!(matches!(rejected.output, ReplOutput::EvalError { .. }));
    assert!(
        rendered_text(&rejected).contains("does not satisfy declaration constraint Monad"),
        "{}",
        rendered_text(&rejected)
    );

    let inference_rejected =
        engine.handle_line("bad: ReplOptionT<Result, String> = ReplOptionT(Ok(Option::Some(1)))");
    assert!(!inference_rejected.should_exit);
    assert!(matches!(
        inference_rejected.output,
        ReplOutput::EvalError { .. }
    ));

    let rebound = engine.handle_line(
        "bad: ReplOptionT<Option, String> = ReplOptionT(Option::Some(Option::Some(\"ok\")))",
    );
    assert!(!rebound.should_exit);
    assert!(
        !matches!(rebound.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&rebound)
    );

    let viewed = engine.handle_line("Facet::view(ReplOptionT.inner, value)");
    assert!(!viewed.should_exit);
    assert!(
        !matches!(viewed.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&viewed)
    );
    assert!(rendered_text(&viewed).contains("Some(1)"));

    let cross_nominal = engine.handle_line("Facet::view(OptionT.inner, value)");
    assert!(!cross_nominal.should_exit);
    assert!(
        matches!(cross_nominal.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&cross_nominal)
    );
}

fn core_parameterized_monad_t_value_survives_failed_inference() {
    let mut engine = ReplEngine::from_script_source(
        "parameterized_monad_t.srt",
        r#"
impl MonadT<Identity> for Identity<$T>
where
  $T: MonadT.$A
{
  def lift::<Identity<$T>>(value: Identity<$A>) -> Identity<$A> {
    value
  }
}
"#,
    )
    .expect("parameterized MonadT preload should load");

    let stored = engine.handle_line("lifted: Identity<Int> = MonadT::lift(Identity::new(41))");
    assert!(!stored.should_exit);
    assert!(
        !matches!(stored.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&stored)
    );

    let rejected = engine.handle_line("bad: Identity<String> = MonadT::lift(Identity::new(1))");
    assert!(!rejected.should_exit);
    assert!(matches!(rejected.output, ReplOutput::EvalError { .. }));

    let viewed = engine.handle_line("Identity::run(lifted)");
    assert!(!viewed.should_exit);
    assert!(
        !matches!(viewed.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&viewed)
    );
    assert!(rendered_text(&viewed).contains("41"));
}

fn core_rebinding_uses_latest_value_and_grows_snapshot_locals() {
    let mut engine = engine();
    let dir = tempfile_dir("xldr-repl-core-rebind");
    let first_path = dir.join("after-first.eldr");
    let path = dir.join("session.eldr");

    let first = engine.handle_line("x = 1");
    assert!(rendered_text(&first).contains("x: Int = 1"));
    assert_eq!(engine.prompt(), "xldr(2)> ");

    let first_save = engine.handle_line(&format!(":save {}", first_path.display()));
    assert!(rendered_text(&first_save).contains("saved to"));
    let first_bytes = fs::read(&first_path).expect("first .eldr should exist");
    let first_snapshot =
        sindr::ir::Bytecode::decode(&first_bytes).expect("first .eldr should decode");

    let second = engine.handle_line("x = 2");
    assert!(rendered_text(&second).contains("x: Int = 2"));

    let value = engine.handle_line("x");
    assert!(rendered_text(&value).contains("2"));

    let recalled = engine.handle_line(":v 1");
    assert!(
        rendered_text(&recalled).contains("1"),
        "kind={} text={}",
        output_kind(&recalled.output),
        rendered_text(&recalled)
    );

    let save = engine.handle_line(&format!(":save {}", path.display()));
    assert!(rendered_text(&save).contains("saved to"));
    let bytes = fs::read(&path).expect("saved .eldr should exist");
    let snapshot = sindr::ir::Bytecode::decode(&bytes).expect("saved .eldr should decode");
    assert!(
        snapshot.num_locals >= first_snapshot.num_locals + 1,
        "num_locals did not grow: before={}, after={}",
        first_snapshot.num_locals,
        snapshot.num_locals
    );
}

fn core_rejects_top_level_def_capturing_session_value_binding() {
    let mut engine = engine();

    let bind = engine.handle_line("x = 1");
    assert!(rendered_text(&bind).contains("x: Int = 1"));

    let def = engine.handle_line("def f() -> Int { x }");
    assert!(!def.should_exit);
    assert!(
        matches!(def.output, ReplOutput::EvalError { .. }),
        "kind={} text={}",
        output_kind(&def.output),
        rendered_text(&def)
    );
    assert!(
        rendered_text(&def).contains("Top-level definition `f` cannot reference value binding `x`")
    );
}

fn core_rejects_repl_forbidden_top_level_declarations() {
    let mut engine = engine();

    let err = engine.handle_line("defstruct User { name: String }");
    assert!(!err.should_exit);
    assert!(matches!(err.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&err).contains("This top-level declaration is not allowed in REPL"));
}

fn core_routes_print_side_effects_into_repl_result_lines() {
    let mut engine = engine();

    let result = engine.handle_line(r#"print("hello from repl")"#);

    assert!(!result.should_exit);
    assert_eq!(visible_text(&result), "hello from repl");
    assert!(result.stderr.is_empty());
}

fn core_routes_eprint_side_effects_into_repl_stderr_lines() {
    let mut engine = engine();

    let result = engine.handle_line("eprint(NoneError())");

    assert!(!result.should_exit);
    assert_eq!(rendered_text(&result), "");
    assert!(
        result.stderr.iter().any(|line| line.contains("REPL:")),
        "{:?}",
        result.stderr
    );
}

fn core_routes_background_prints_into_pump_result_lines() {
    let mut engine = engine();

    let launched = engine.handle_line(
        r#"_ =? Task::launch({||
  _ =? Process::sleep(5ms)
  print("hello from background")
  Ok(())
})"#,
    );
    assert!(!launched.should_exit, "{}", rendered_text(&launched));

    let background = engine.advance_background_time(Duration::from_millis(5));

    assert!(!background.should_exit);
    assert_eq!(visible_text(&background), "hello from background");
}

fn core_chunk_shares_cpu_budget_with_background_tasks() {
    let mut engine = engine();
    let definition = engine.handle_line(
        "def countdown(remaining: Int) -> Int { if(remaining == 0, 0, countdown(remaining - 1)) }",
    );
    assert!(matches!(definition.output, ReplOutput::EvalSuccess { .. }));
    let result = engine.handle_line(
        r#"slow = Task::async({||
  value = countdown(10000)
  print("slow task")
  Ok(value)
})
fast = Task::async({|| print("fast task"); Ok(1) })
print(inspect(Task::await(slow)))
print(inspect(Task::await(fast)))"#,
    );
    assert!(
        matches!(result.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        visible_text(&result)
    );
    let output = visible_text(&result);
    let fast = output.find("fast task").expect("fast task must complete");
    let slow = output.find("slow task").expect("slow task must complete");
    assert!(fast < slow, "{output}");
    assert_eq!(output.matches("fast task").count(), 1, "{output}");
    assert_eq!(output.matches("slow task").count(), 1, "{output}");
    assert!(
        output.contains("Ok(0)") && output.contains("Ok(1)"),
        "{output}"
    );
}

fn core_flat_map_builder_survives_runtime_error_rollback() {
    let mut engine = engine();
    let stable = engine.handle_line("stable = List::flat_map([7, 8], {|value| [value, value]})");
    assert!(
        matches!(stable.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        visible_text(&stable)
    );
    let pending = engine.handle_line(
        r#"pending = Task::async({||
  values = List::flat_map([1, 2, 3], {|value|
    if(value == 2, { Process::sleep(10ms); () }, ())
    [value]
  })
  print("flat_map complete")
  Ok(values)
})"#,
    );
    assert!(
        matches!(pending.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        visible_text(&pending)
    );
    assert!(!visible_text(&pending).contains("flat_map complete"));
    assert!(engine.has_pending_background_work());

    // The checkpoint now holds a Builder containing [1]. Let the live copy
    // finish before failing, then resume the checkpoint after rollback.
    let failed = engine.handle_line("Task::await(pending)\nProcess::self()");
    assert!(
        matches!(failed.output, ReplOutput::EvalError { .. }),
        "{}",
        visible_text(&failed)
    );
    assert!(visible_text(&failed).contains("Process::self"));
    assert_eq!(
        visible_text(&failed).matches("flat_map complete").count(),
        0
    );
    assert!(engine.has_pending_background_work());

    let resumed = engine.handle_line("Task::await(pending)");
    let text = visible_text(&resumed);
    assert!(
        matches!(resumed.output, ReplOutput::EvalSuccess { .. }),
        "{text}"
    );
    assert!(text.contains("Ok([1, 2, 3])"), "{text}");
    assert_eq!(text.matches("flat_map complete").count(), 1, "{text}");
    let preserved = engine.handle_line("stable");
    assert!(visible_text(&preserved).contains("[7, 7, 8, 8]"));
    assert!(!engine.has_pending_background_work());
    let idle = engine.pump_background_to_next_deadline();
    assert!(!visible_text(&idle).contains("flat_map complete"));
}

fn core_cpu_background_work_requests_immediate_pump() {
    let mut engine = engine();
    let definition = engine.handle_line(
        "def countdown(remaining: Int) -> Int { if(remaining == 0, 0, countdown(remaining - 1)) }",
    );
    assert!(matches!(definition.output, ReplOutput::EvalSuccess { .. }));
    let launched = engine
        .handle_line(r#"Task::launch({|| countdown(10000); print("CPU task complete"); Ok(()) })"#);
    assert!(
        matches!(launched.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        visible_text(&launched)
    );
    assert!(!visible_text(&launched).contains("CPU task complete"));
    assert!(engine.has_pending_background_work());
    let mut completion_count = 0;
    // Match the CLI's idle polling contract, without submitting another chunk.
    for _ in 0..1000 {
        if !engine.has_pending_background_work() {
            break;
        }
        assert_eq!(
            engine.next_background_deadline_delay(),
            Some(Duration::ZERO)
        );
        let progress = engine.pump_background_to_next_deadline();
        assert!(!matches!(progress.output, ReplOutput::EvalError { .. }));
        completion_count += visible_text(&progress).matches("CPU task complete").count();
    }
    assert!(!engine.has_pending_background_work());
    assert_eq!(completion_count, 1);
    assert_eq!(engine.next_background_deadline_delay(), None);
}

fn core_from_script_source_exposes_preloaded_docs_and_keeps_repl_policy() {
    let mut engine = ReplEngine::from_script_source(
        "preload.srt",
        r#"
@doc """
Greets from preload.
"""
def greet() -> String { "hello" }
"#,
    )
    .expect("script preload should bootstrap");

    let doc = engine.handle_line(":doc greet");
    let doc = doc_text(&doc);
    assert!(doc.contains("Greets from preload."), "{doc}");

    let call = engine.handle_line("greet()");
    assert!(rendered_text(&call).contains("hello"));

    let err = engine.handle_line("defstruct User { name: String }");
    assert!(
        rendered_text(&err).contains("REPL"),
        "{}",
        rendered_text(&err)
    );
}

fn core_from_script_file_resolves_include_and_executes_preload_before_repl() {
    let dir = tempfile_dir("xldr-repl-core-script-include");
    let module_path = dir.join("m.srt");
    let script_path = dir.join("a.srt");
    fs::write(
        &module_path,
        r#"
defmod M {
  def one() -> Int { 1 }
}
"#,
    )
    .expect("failed to write preload module");
    fs::write(
        &script_path,
        r#"
include "./m.srt"
import M::one
answer = one()
"#,
    )
    .expect("failed to write preload script");

    let mut engine =
        ReplEngine::from_script_file(script_path.to_str().expect("script path must be utf-8"))
            .expect("script preload with include should bootstrap");

    let value = engine.handle_line("answer + 1");
    let value_text = rendered_text(&value);
    assert!(
        value_text.contains("2"),
        "kind={}\nvalue_text={value_text:?}",
        output_kind(&value.output)
    );
}

fn core_from_module_source_exposes_preloaded_module_definitions() {
    let mut engine = ReplEngine::from_module_source(
        "math.srt",
        r#"
defmod Math {
  @doc """
  Add two ints.
  """
  def add2(x: Int, y: Int) -> Int { x + y }
}
"#,
    )
    .expect("module preload should bootstrap");

    let doc = engine.handle_line(":doc Math::add2");
    let doc = doc_text(&doc);
    assert!(doc.contains("Add two ints."), "{doc}");

    let imported = engine.handle_line("import Math::add2");
    assert!(rendered_text(&imported).contains("Imported Math::add2"));

    let call = engine.handle_line("add2(1, 2)");
    assert!(rendered_text(&call).contains("3"));
}

fn core_imports_non_autoimport_trait_and_rejects_autoimport_trait() {
    let mut engine = engine();

    let failed = engine.handle_line("import Add\n1 + \"bad\"");
    assert!(matches!(failed.output, ReplOutput::EvalError { .. }));

    let imported = engine.handle_line("import Add");
    assert!(rendered_text(&imported).contains("Imported Add"));

    let result = engine.handle_line("add(1, 2)");
    assert!(rendered_text(&result).contains("3"));

    let duplicate = engine.handle_line("import Add");
    assert!(rendered_text(&duplicate).contains("Duplicate import"));

    let rejected = engine.handle_line("import Compare");
    assert!(
        rendered_text(&rejected).contains("Compare` is already imported by file-start autoimport")
    );
}

fn core_script_preload_imports_non_autoimport_trait() {
    let mut engine =
        ReplEngine::from_script_source("trait-import.srt", "import Add\nvalue = add(1, 2)\n")
            .expect("script preload should accept non-autoimport trait import");

    let result = engine.handle_line("value");
    assert!(rendered_text(&result).contains("3"));
}

fn core_from_project_module_stages_exposes_compiled_project_definitions() {
    let mut engine = ReplEngine::from_project_module_stages(&[vec![xldr::ModuleInput {
        file_name: "math.srt".into(),
        source: r#"
defmod Math {
  def add2(x: Int, y: Int) -> Int { x + y }
}
"#
        .into(),
        module_path: "Math".into(),
    }]])
    .expect("project preload should bootstrap");

    let imported = engine.handle_line("import Math::add2");
    assert!(rendered_text(&imported).contains("Imported Math::add2"));

    let call = engine.handle_line("add2(20, 22)");
    assert!(rendered_text(&call).contains("42"));
}

fn core_from_project_runner_source_exposes_selected_profile_definitions() {
    let root = tempfile_dir("xldr-project-runner-repl");
    let src = root.join("src");
    fs::create_dir_all(&src).expect("src dir should be created");
    let project_file = root.join("project.srt");
    let helper_file = src.join("helper.srt");
    fs::write(
        &helper_file,
        r#"
defmod Helper {
  def add2(x: Int, y: Int) -> Int { x + y }
}
"#,
    )
    .expect("helper source should be writable");
    let project_source = r#"
def profile_name() -> String { "dev" }

Project::config({|project|
  Project::entrypoint(project, profile_name(), {|config|
    Config::add_path(config, "./src/helper.srt")
  })
})
"#;

    let mut engine =
        ReplEngine::from_project_runner_source(surtr_analysis::ProjectRunnerSourceInput {
            project_file: project_file.clone(),
            selected_profile: "dev".to_string(),
            normalized_args: vec![("profile".to_string(), "dev".to_string())],
            active_file: None,
            source: project_source.to_string(),
        })
        .expect("project runner source should preload REPL context");

    let imported = engine.handle_line("import Helper::add2");
    assert!(rendered_text(&imported).contains("Imported Helper::add2"));

    let call = engine.handle_line("add2(20, 22)");
    assert!(rendered_text(&call).contains("42"));

    let _ = fs::remove_dir_all(root);
}

fn core_from_project_runner_source_exposes_const_only_file_by_stem_module() {
    let root = tempfile_dir("xldr-project-runner-repl-const-only");
    let src = root.join("src");
    fs::create_dir_all(&src).expect("src dir should be created");
    let project_file = root.join("project.srt");
    let config_file = src.join("AppConfig.srt");
    fs::write(
        &config_file,
        r#"
const APP_NAME = "surtr"
"#,
    )
    .expect("config source should be writable");
    let project_source = r#"
Project::config({|project|
  Project::entrypoint(project, "dev", {|config|
    Config::add_path(config, "./src/AppConfig.srt")
  })
})
"#;

    let mut engine =
        ReplEngine::from_project_runner_source(surtr_analysis::ProjectRunnerSourceInput {
            project_file: project_file.clone(),
            selected_profile: "dev".to_string(),
            normalized_args: Vec::new(),
            active_file: None,
            source: project_source.to_string(),
        })
        .expect("project runner source should preload const-only file");

    let output = engine.handle_line("AppConfig::APP_NAME");
    assert!(rendered_text(&output).contains("surtr"));

    let _ = fs::remove_dir_all(root);
}

fn core_from_module_source_rejects_include_directive() {
    let result = ReplEngine::from_module_source(
        "math.srt",
        r#"
defmod Math {
  def add2(x: Int, y: Int) -> Int { x + y }
}

include "./extra.srt"
"#,
    );
    let err = match result {
        Ok(_) => panic!("module preload with include must fail"),
        Err(err) => err,
    };

    let rendered = format!("{err:?}");
    assert!(rendered.contains("include"), "{rendered}");
}

fn core_commands_do_not_require_a_cli_process() {
    let mut engine = engine();

    let help = engine.handle_line(":help");
    assert!(rendered_text(&help).contains("REPL commands:"));
    assert!(rendered_text(&help).contains(":type <binding>"));

    let doc = engine.handle_line(":doc print");
    let (symbol, signature) = doc_target(&doc);
    assert_eq!(symbol, "Kernel::print");
    assert_eq!(signature, Some("print(a: String) -> Unit"));

    let sig = engine.handle_line(":sig print");
    assert!(signature_text(&sig).contains("Kernel::print(a: String) -> Unit"));

    let missing_sig = engine.handle_line(":sig a");
    let missing_sig = rendered_text(&missing_sig);
    assert!(missing_sig.contains("No signature found for a"));
    assert!(missing_sig.contains(":doc <symbol>"));

    let unknown = engine.handle_line(":nope");
    assert!(!unknown.should_exit);
    assert!(rendered_text(&unknown).contains("Unknown REPL command: :nope"));
}

fn core_reuses_deferred_tuple_facet_bindings_between_inputs() {
    let mut engine = engine();

    let facet = engine.handle_line("a = Tuple._1");
    assert!(rendered_text(&facet).contains("a: Facet<InfallibleStructural, _, _, _, _> = Tuple._1"));

    let pair = engine.handle_line("pair = (\"alice\", 2)");
    assert!(rendered_text(&pair).contains("pair: (String, Int) = (\"alice\", 2)"));

    let value = engine.handle_line("Facet::view(a, pair)");
    assert!(rendered_text(&value).contains("2"));
}

fn core_static_impl_methods_keep_runtime_arity_in_sync() {
    let mut engine = engine();

    let gen_range = engine.handle_line("Generator::to_list(Generator::range(1, 3))");
    assert!(!gen_range.should_exit);
    assert!(rendered_text(&gen_range).contains("[1, 2, 3]"));

    let codepoints = engine.handle_line("String::codepoints(\"a\", StringEncoding::Ascii)");
    assert!(!codepoints.should_exit);
    assert!(rendered_text(&codepoints).contains("Ok([97])"));
}

fn core_range_bindings_keep_constructor_and_compare_fun_indices_in_sync() {
    let mut engine = engine();

    let a = engine.handle_line("a = 20ms");
    assert!(!a.should_exit);
    assert!(rendered_text(&a).contains("a: Duration = 20ms"));

    let a_rebound = engine.handle_line("a = 20ms");
    assert!(!a_rebound.should_exit);
    assert!(rendered_text(&a_rebound).contains("a: Duration = 20ms"));

    let b = engine.handle_line("b = 10ms");
    assert!(!b.should_exit);
    assert!(rendered_text(&b).contains("b: Duration = 10ms"));

    let range = engine.handle_line("Range(a,b)");
    assert!(!range.should_exit);
    assert!(rendered_text(&range).contains("Range(min: 20ms, max: 10ms)"));

    let normalized = engine.handle_line("Range::normalized(a,b)");
    assert!(!normalized.should_exit);
    assert!(rendered_text(&normalized).contains("Range(min: 10ms, max: 20ms)"));

    let neq = engine.handle_line("Range(b,a) != Range(b, 100ms)");
    assert!(!neq.should_exit);
    let text = rendered_text(&neq);
    assert!(text.contains("True"), "{text}");
    assert!(!text.contains("Unknown function index"), "{text}");
    assert!(!text.contains("Call arity mismatch"), "{text}");
}

fn core_range_generic_helpers_survive_sig_doc_interleaving() {
    let mut engine = engine();

    let a = engine.handle_line("a = 20ms");
    assert!(!a.should_exit);
    assert!(rendered_text(&a).contains("a: Duration = 20ms"));

    let sig = signature_text(&engine.handle_line(":sig Compare::compare"));
    assert!(
        sig.contains("compare(self: Self, rhs: Self) -> Ordering"),
        "{sig}"
    );

    let doc = doc_text(&engine.handle_line(":doc Range::new"));
    assert!(!doc.contains("Unknown function index"), "{doc}");
    assert!(!doc.contains("Call arity mismatch"), "{doc}");

    let b = engine.handle_line("b = 10ms");
    assert!(!b.should_exit);
    assert!(rendered_text(&b).contains("b: Duration = 10ms"));

    let neq = engine.handle_line("Range(a,b) != Range(b, 100ms)");
    assert!(!neq.should_exit);
    let text = rendered_text(&neq);
    assert!(text.contains("True"), "{text}");
    assert!(!text.contains("Unknown function index"), "{text}");
    assert!(!text.contains("Call arity mismatch"), "{text}");
}

fn core_range_generic_helpers_survive_runtime_error_rollback() {
    let mut engine = engine();

    let a = engine.handle_line("a = 20ms");
    assert!(!a.should_exit);
    assert!(rendered_text(&a).contains("a: Duration = 20ms"));

    let b = engine.handle_line("b = 10ms");
    assert!(!b.should_exit);
    assert!(rendered_text(&b).contains("b: Duration = 10ms"));

    let runtime_error = engine.handle_line("Process::self()");
    assert!(matches!(runtime_error.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&runtime_error).contains("Process::self"));

    let neq = engine.handle_line("Range(a,b) != Range(b, 100ms)");
    assert!(!neq.should_exit);
    let text = rendered_text(&neq);
    assert!(text.contains("True"), "{text}");
    assert!(!text.contains("Unknown function index"), "{text}");
    assert!(!text.contains("Call arity mismatch"), "{text}");
}

fn core_renders_top_level_facet_composition_expressions_without_codegen_leak() {
    let mut engine = engine();

    let tuple_facet = engine.handle_line("a = Tuple._1");
    assert!(rendered_text(&tuple_facet)
        .contains("a: Facet<InfallibleStructural, _, _, _, _> = Tuple._1"));

    let enum_facet = engine.handle_line("ep = IntBase.Oct");
    assert!(rendered_text(&enum_facet)
        .contains("ep: Facet<VariantPath, IntBase, Unit, _, _> = IntBase.Oct"));

    let arrow = engine.handle_line("a -> ep");
    let arrow = rendered_text(&arrow);
    assert!(
        arrow.contains("Facet<InfallibleStructural, _, _, _, _> = Tuple._1.Oct"),
        "{arrow}"
    );

    let helper = engine.handle_line("Facet::compose(a, ep)");
    let helper = rendered_text(&helper);
    assert!(
        helper.contains("Facet<InfallibleStructural, _, _, _, _> = Tuple._1.Oct"),
        "{helper}"
    );
}

#[test]
fn facet_duration_root_inspection_matches_its_structural_path() {
    let mut engine = engine();
    for root in ["Duration", "Global::Duration"] {
        let info = rendered_text(&engine.handle_line(&format!(":facet {root}")));
        assert!(info.contains("kind: struct"), "{info}");
        assert!(info.contains("- public readonly millis: Int"), "{info}");
        assert_eq!(
            info,
            rendered_text(&engine.handle_line(&format!(":info {root}")))
        );
    }
    let path = rendered_text(&engine.handle_line(":facet Duration.millis"));
    assert!(path.contains("full path: Duration.millis"), "{path}");
    assert!(path.contains("focus: Int"), "{path}");
    let doc = doc_text(&engine.handle_line(":doc Facet.Duration"));
    assert!(doc.contains("is a Facet path root"), "{doc}");
}

#[test]
fn facet_root_inspection_lists_members_and_preserves_path_boundaries() {
    let mut engine = ReplEngine::from_script_source(
        "facet_roots.srt",
        r#"
defstruct Account {
  private password: String,
  readonly age: Int,
  name: String
}
impl Account {
  def new(password: String, age: Int, name: String) -> Self {
    Account { password: password, age: age, name: name }
  }
}
defrecord Profile(name: String, age: Int)
defenum Choice { Empty, One(String), Pair(Int, String) }
defenum MaybeItem<$T> { Nothing, Item($T) }
deferror Trouble(code: Int) { |input: String| Self(message: input, code: 42) }
"#,
    )
    .expect("facet roots should bootstrap");
    let account = rendered_text(&engine.handle_line(":facet Account"));
    assert!(
        account.contains("private         password: String"),
        "{account}"
    );
    assert!(account.contains("public readonly age"), "{account}");
    assert_eq!(account, rendered_text(&engine.handle_line(":info Account")));
    let profile = rendered_text(&engine.handle_line(":facet Profile"));
    assert!(profile.contains("- age : Int"), "{profile}");
    assert!(profile.contains("- name: String"), "{profile}");
    assert!(!profile.contains("- public"), "{profile}");
    assert_eq!(profile, rendered_text(&engine.handle_line(":info Profile")));
    let maybe = rendered_text(&engine.handle_line(":facet MaybeItem"));
    assert!(maybe.contains("- Item   : $T"), "{maybe}");
    let choice = rendered_text(&engine.handle_line(":facet Choice"));
    for row in ["- Empty: Unit", "- One  : String", "- Pair : (Int, String)"] {
        assert!(choice.contains(row), "{choice}");
    }
    for (root, selector) in [
        ("Tuple", "Tuple._N"),
        ("List", "List.[index]"),
        ("HashMap", "HashMap.[key]"),
    ] {
        let info = rendered_text(&engine.handle_line(&format!(":facet {root}")));
        assert!(info.contains(selector), "{info}");
    }
    let error = rendered_text(&engine.handle_line(":facet Error"));
    assert!(error.contains("- kind   : String"), "{error}");
    assert!(error.contains("- message: String"), "{error}");
    let trouble = rendered_text(&engine.handle_line(":facet Trouble"));
    for row in ["- code   : Int", "- kind   : String", "- message: String"] {
        assert!(trouble.contains(row), "{trouble}");
    }
    assert!(!trouble.contains("input:"), "{trouble}");
    assert!(trouble.contains("readonly"), "{trouble}");
    for (path, canonical) in [
        ("Trouble.code", "Error.code"),
        ("Trouble.message", "Error.message"),
        ("Trouble.kind", "Error.kind"),
        ("Account.name", "Account.name"),
    ] {
        let info = rendered_text(&engine.handle_line(&format!(":facet {path}")));
        assert!(info.contains(&format!("full path: {canonical}")), "{info}");
    }
    for root in ["Int", "Result"] {
        let info = rendered_text(&engine.handle_line(&format!(":facet {root}")));
        assert!(info.contains("not a Facet path root"), "{info}");
    }
    let invalid = rendered_text(&engine.handle_line(":facet Account.missing"));
    assert!(invalid.contains("No field"), "{invalid}");
    let candidates = engine.completions(":facet ", 7).candidates;
    for root in [
        "Account", "Profile", "Choice", "Trouble", "Error", "Boolean", "Tuple", "List", "HashMap",
    ] {
        assert!(
            candidates.iter().any(|candidate| candidate.label == root),
            "missing {root}: {candidates:?}"
        );
    }
    assert!(!candidates
        .iter()
        .any(|candidate| candidate.label == "Int" || candidate.label == "print"));
    let boolean = rendered_text(&engine.handle_line(":facet Boolean"));
    assert!(boolean.contains("- False: Unit"), "{boolean}");
    assert!(boolean.contains("- True : Unit"), "{boolean}");
    let function = rendered_text(&engine.handle_line(":facet print"));
    assert!(!function.contains("fields:"), "{function}");
}

fn core_facet_command_reports_kind_apis_segments_and_stop_points() {
    let mut engine = engine();

    let binding = engine.handle_line("path = Tuple._0");
    assert!(rendered_text(&binding)
        .contains("path: Facet<InfallibleStructural, _, _, _, _> = Tuple._0"));

    let facet_info = engine.handle_line(":facet path");
    assert!(matches!(facet_info.output, ReplOutput::StyledDoc { .. }));
    let facet_info = rendered_text(&facet_info);
    assert!(facet_info.contains("## FacetPath"), "{facet_info}");
    assert!(
        facet_info.contains("type: Facet<InfallibleStructural, _, _, _, _>"),
        "{facet_info}"
    );
    assert!(facet_info.contains("stage: pending"), "{facet_info}");
    assert!(facet_info.contains("kind: pending"), "{facet_info}");
    assert!(
        facet_info.contains("pending specialization"),
        "{facet_info}"
    );
    assert!(facet_info.contains("full path: Tuple._0"), "{facet_info}");
    assert!(facet_info.contains("## Flow"), "{facet_info}");
    assert!(facet_info.contains("hop 1: Tuple._0"), "{facet_info}");
    assert!(facet_info.contains("relation: _ -> _"), "{facet_info}");

    let legacy = engine.handle_line(":lens path");
    assert!(rendered_text(&legacy).contains("Unknown REPL command: :lens"));

    let fallible = engine.handle_line(":facet BitWidth.Any");
    let fallible = rendered_text(&fallible);
    assert!(fallible.contains("kind: VariantPath"), "{fallible}");
    assert!(fallible.contains("preview: available"), "{fallible}");
    assert!(fallible.contains("## Stops"), "{fallible}");
    assert!(fallible.contains("stop 1:"), "{fallible}");
    assert!(
        fallible.contains("variant mismatch returns Result"),
        "{fallible}"
    );
}

fn core_facet_record_positional_origin_remains_visible() {
    let mut engine =
        ReplEngine::from_script_source("tmp/user.srt", "defrecord User(name: String, age: Int)")
            .expect("record preload should bootstrap");
    let info = rendered_text(&engine.handle_line(":facet User._1"));
    assert!(info.contains("full path: User._1"), "{info}");
    assert!(info.contains("reason: record position access"), "{info}");
    assert!(info.contains("hop 1: User._1"), "{info}");

    let binding = rendered_text(&engine.handle_line("age_path = User._1"));
    assert!(binding.contains("User._1"), "{binding}");
    let bound_info = rendered_text(&engine.handle_line(":facet age_path"));
    assert!(bound_info.contains("full path: User._1"), "{bound_info}");
    assert!(
        bound_info.contains("reason: record position access"),
        "{bound_info}"
    );

    let named = rendered_text(&engine.handle_line(":facet User.age"));
    assert!(named.contains("full path: User.age"), "{named}");
    assert!(named.contains("reason: field access"), "{named}");

    engine.handle_line("user = User(\"alice\", 42)");
    let value_path = rendered_text(&engine.handle_line(":facet user._1"));
    assert!(value_path.contains("full path: User._1"), "{value_path}");
    assert!(
        value_path.contains("reason: record position access"),
        "{value_path}"
    );
    let value = rendered_text(&engine.handle_line("Facet::view(User._1, user)"));
    assert!(value.contains("42"), "{value}");
    let updated = rendered_text(&engine.handle_line("Facet::set(User._1, user, 43)"));
    assert!(updated.contains("age: 43"), "{updated}");
}

fn core_record_constructor_capture_keeps_local_display_name() {
    let mut engine =
        ReplEngine::from_script_source("tmp/user.srt", "defrecord User(name: String, age: Int)")
            .expect("record preload should bootstrap");

    let capture = rendered_text(&engine.handle_line("make_user = &User"));
    assert!(
        capture.contains("FnCapture(module: <local>, name: User"),
        "{capture}"
    );

    let partial = rendered_text(&engine.handle_line("make_named = &User(&1, 20)"));
    assert!(
        partial.contains("FnCapture(module: <local>, name: User"),
        "{partial}"
    );
}

fn core_facet_command_inspects_operations_and_kind_queries() {
    let mut engine = engine();

    let operation =
        rendered_text(&engine.handle_line(":facet Facet::set(Tuple._0, (1, True), \"one\")"));
    assert!(operation.contains("## FacetOperation"), "{operation}");
    assert!(operation.contains("operation: Facet::set"), "{operation}");
    assert!(
        operation.contains("kind constraint: WritablePath"),
        "{operation}"
    );
    assert!(operation.contains("replacement: String"), "{operation}");
    assert!(
        operation.contains("result: Result<(String, Boolean)>"),
        "{operation}"
    );

    let kind = rendered_text(&engine.handle_line(":info ReadablePath"));
    assert!(kind.contains("@FacetPathKind Type ReadablePath"), "{kind}");
    assert!(kind.contains("Effective atomic kinds"), "{kind}");

    let sig = rendered_text(&engine.handle_line(":sig ReadablePath"));
    assert!(sig.contains("has no constructor signature"), "{sig}");
    assert!(sig.contains("Use `:info ReadablePath`"), "{sig}");
}

fn core_renders_negative_and_range_list_facets() {
    let mut engine = engine();

    let last = engine.handle_line("last = List.[-1]");
    assert!(
        rendered_text(&last).contains("last: Facet<InfallibleStructural, _, _, _, _> = List.[-1]")
    );

    let window = engine.handle_line("window = List.[1..-1]");
    assert!(rendered_text(&window)
        .contains("window: Facet<InfallibleStructural, _, _, _, _> = List.[1..-1]"));

    let info = engine.handle_line(":facet window");
    let info = rendered_text(&info);
    assert!(info.contains("full path: List.[1..-1]"), "{info}");
    assert!(info.contains("fallible: yes"), "{info}");
}

fn core_doc_reports_match_and_cond_from_bootstrap_surface() {
    let mut engine = engine();

    let match_doc = engine.handle_line(":doc match");
    let (symbol, signature) = doc_target(&match_doc);
    assert_eq!(symbol, "Bootstrap::match");
    assert_eq!(
        signature,
        Some("@intrinsic def match(value: $A, arms: MatchArms<$A, $B>) -> $B")
    );

    let cond_doc = engine.handle_line(":doc cond");
    let (symbol, signature) = doc_target(&cond_doc);
    assert_eq!(symbol, "Bootstrap::cond");
    assert_eq!(
        signature,
        Some("@intrinsic def cond(clauses: CondClauses<$A>) -> $A")
    );
}

fn core_type_command_looks_up_visible_bindings_only() {
    let mut engine = engine();

    let list = engine.handle_line("list: List<Int> = [1, 2, 3]");
    let list_text = rendered_text(&list);
    assert!(
        list_text.contains("list: List<Int> = [1, 2, 3]"),
        "{list_text}"
    );

    let list_type = engine.handle_line(":type list");
    let list_type_text = rendered_text(&list_type);
    assert_eq!(
        list_type_text,
        "list\ntype: List<Int>\nidentity: TypeIdentity::Type"
    );

    let closure = engine.handle_line("captured = 1");
    assert!(rendered_text(&closure).contains("captured: Int = 1"));

    let closure_fun = engine.handle_line("pure = {|n: Int| n + 1}");
    let closure_fun_text = rendered_text(&closure_fun);
    assert!(
        closure_fun_text.contains("pure: (Int -> Int) = Closure(Int -> Int)"),
        "{closure_fun_text}"
    );

    let closure_fun_type = engine.handle_line(":type pure");
    let closure_fun_type_text = rendered_text(&closure_fun_type);
    assert_eq!(
        closure_fun_type_text,
        "pure\ntype: (Int -> Int)\nidentity: TypeIdentity::Closure"
    );

    let capture_fun = engine.handle_line("inc = {|n: Int| n + captured}");
    let capture_fun_text = rendered_text(&capture_fun);
    assert!(
        capture_fun_text.contains("inc: (Int -> Int) = Closure(Int -> Int)"),
        "{capture_fun_text}"
    );

    let binary_closure = engine.handle_line("f = {|x: Int, y: Int| x + y}");
    let binary_closure_text = rendered_text(&binary_closure);
    assert!(
        binary_closure_text.contains("f: (Int, Int -> Int) = Closure(Int, Int -> Int)"),
        "{binary_closure_text}"
    );

    let capture_fun_type = engine.handle_line(":type inc");
    let capture_fun_type_text = rendered_text(&capture_fun_type);
    assert_eq!(
        capture_fun_type_text,
        "inc\ntype: (Int -> Int)\nidentity: TypeIdentity::Closure"
    );

    let builtin_capture = engine.handle_line("p = &print");
    let builtin_capture_text = rendered_text(&builtin_capture);
    assert!(
        builtin_capture_text
            .contains("FnCapture(module: Kernel, name: print, sig: (String -> Unit))"),
        "{builtin_capture_text}"
    );

    let builtin_capture_type = engine.handle_line(":type p");
    let builtin_capture_type_text = rendered_text(&builtin_capture_type);
    assert_eq!(
        builtin_capture_type_text,
        "p\ntype: (String -> Unit)\nidentity: TypeIdentity::Capture"
    );

    let partial_capture = engine.handle_line("f = &Add::add(&1, 4)");
    let partial_capture_text = rendered_text(&partial_capture);
    assert!(
        partial_capture_text.contains("FnCapture(module: Add, name: add, sig: (Int -> Int))"),
        "{partial_capture_text}"
    );

    let partial_capture_type = engine.handle_line(":type f");
    let partial_capture_type_text = rendered_text(&partial_capture_type);
    assert_eq!(
        partial_capture_type_text,
        "f\ntype: (Int -> Int)\nidentity: TypeIdentity::Capture"
    );

    for invalid in [":type if", ":type String::is_empty()"] {
        let result = engine.handle_line(invalid);
        let text = rendered_text(&result);
        assert!(
            text.contains("Usage: :type <binding|singleton-owner>"),
            "{text}"
        );
    }
}

fn core_repl_surfaces_keep_generic_arguments_for_bindings() {
    let mut engine = engine();

    let bind = engine.handle_line("maybe: Option<Int> = Option::Some(1)");
    let bind_text = rendered_text(&bind);
    assert!(
        bind_text.contains("maybe: Option<Int> = Option::Some(1)"),
        "{bind_text}"
    );

    let nested = engine.handle_line("nested: List<Option<Int>> = [Option::Some(1)]");
    let nested_text = rendered_text(&nested);
    assert!(
        nested_text.contains("nested: List<Option<Int>> = [Option::Some(1)]"),
        "{nested_text}"
    );

    let ty = engine.handle_line(":type maybe");
    assert_eq!(
        rendered_text(&ty),
        "maybe\ntype: Option<Int>\nidentity: TypeIdentity::Enum"
    );

    let info = engine.handle_line(":info maybe");
    let info_text = rendered_text(&info);
    assert!(info_text.contains("type: Option<Int>"), "{info_text}");

    let nested_info = engine.handle_line(":info nested");
    let nested_info_text = rendered_text(&nested_info);
    assert!(
        nested_info_text.contains("type: List<Option<Int>>"),
        "{nested_info_text}"
    );
}

fn core_help_and_error_commands_return_structured_command_output() {
    let mut engine = engine();

    let help = engine.handle_line(":help");
    let help_text = rendered_text(&help);
    assert!(help_text.contains("REPL commands:"));
    assert!(help_text.contains(":save <path.eldr>"));
    assert!(help_text.contains(":info <query>"));
    assert!(help_text.contains(":vars"));
    assert!(help_text.contains(":history [selector]"));
    assert!(help_text.contains(":reload [all|defs]"));
    assert!(help_text.contains(":clear"));

    let sig_help = engine.handle_line(":h sig");
    let sig_help_text = rendered_text(&sig_help);
    assert!(sig_help_text.contains("Usage: :sig <symbol|query>"));
    assert!(sig_help_text.contains(":sig Compare"));

    let info_help = engine.handle_line(":help info");
    let info_help_text = rendered_text(&info_help);
    assert!(info_help_text.contains("Usage: :info <query>"));
    assert!(info_help_text
        .contains("Accepts: symbol | type-definition | singleton-owner | Facet-root | field-path"));

    let history_help = engine.handle_line(":help history");
    assert!(rendered_text(&history_help).contains("Usage: :history [selector]"));

    let error_default = engine.handle_line(":error");
    assert!(rendered_text(&error_default).contains("error display mode: full"));

    let error_summary = engine.handle_line(":error summary");
    assert!(rendered_text(&error_summary).contains("error display mode: summary"));

    let error_full = engine.handle_line(":error full");
    assert!(rendered_text(&error_full).contains("error display mode: full"));
}

fn core_info_command_reports_queries_and_command_errors() {
    let mut engine = engine();

    let info_usage = engine.handle_line(":info");
    assert!(rendered_text(&info_usage).contains("Usage: :info <query>"));

    let print_info = engine.handle_line(":info print");
    let print_info_text = rendered_text(&print_info);
    assert!(
        print_info_text.contains("Kernel::print"),
        "{print_info_text}"
    );
    assert!(print_info_text.contains("kind:"), "{print_info_text}");
    assert!(print_info_text.contains("origin:"), "{print_info_text}");
    assert!(print_info_text.contains("defined:"), "{print_info_text}");
}

fn core_repl_command_and_query_errors_use_diagnostics() {
    let mut engine = engine();

    let bad_error_mode = engine.handle_line(":error bad");
    let bad_error_mode_text = strip_ansi(&rendered_text(&bad_error_mode));
    assert!(
        bad_error_mode_text.contains("Error: ReplCommandError"),
        "{bad_error_mode_text}"
    );

    let bad_sig_query = engine.handle_line(":sig compare(Int, )");
    let bad_sig_query_text = strip_ansi(&rendered_text(&bad_sig_query));
    assert!(
        bad_sig_query_text.contains("Error: ReplQueryParseError"),
        "{bad_sig_query_text}"
    );

    let info_type_error = engine.handle_line(":info 1 + \"2\"");
    let info_type_error_text = strip_ansi(&rendered_text(&info_type_error));
    assert!(
        info_type_error_text.contains("Error: ReplQueryParseError"),
        "{info_type_error_text}"
    );
}

fn core_value_recall_uses_engine_history_and_prompt_index() {
    let mut engine = engine();
    assert_eq!(engine.prompt(), "xldr(1)> ");

    let first = engine.handle_line("5");
    assert!(rendered_text(&first).contains("5"));
    assert_eq!(engine.prompt(), "xldr(2)> ");

    let recalled = engine.handle_line(":v 1");
    assert!(rendered_text(&recalled).contains("5"));
    assert_eq!(engine.prompt(), "xldr(3)> ");
}

fn core_session_listing_commands_render_current_state() {
    let mut engine = ReplEngine::from_preload_sources(
        Some((
            "math.srt",
            r#"
defmod Math {
  def add2(x: Int, y: Int) -> Int { x + y }
}
"#,
        )),
        Some((
            "preload.srt",
            r#"
def greet() -> String { "hi" }
import Math::add2
"#,
        )),
    )
    .expect("preload should bootstrap");

    let _ = engine.handle_line("answer = add2(1, 2)");
    let _ = engine.handle_line("def local_twice(x: Int) -> Int { add2(x, x) }");

    let vars = rendered_text(&engine.handle_line(":vars"));
    assert!(vars.contains("line"), "{vars}");
    assert!(vars.contains("answer"), "{vars}");
    assert!(vars.contains("Int"), "{vars}");

    let imported = rendered_text(&engine.handle_line(":imported"));
    assert!(imported.contains("auto"), "{imported}");
    assert!(imported.contains("Kernel"), "{imported}");
    assert!(imported.contains("Show::to_string"), "{imported}");
    assert!(imported.contains("Math::add2"), "{imported}");

    let defs = rendered_text(&engine.handle_line(":defs"));
    assert!(defs.contains("greet"), "{defs}");
    assert!(defs.contains("local_twice"), "{defs}");

    let history = rendered_text(&engine.handle_line(":history"));
    assert!(history.contains("line"), "{history}");
    assert!(history.contains("answer = add2(1, 2)"), "{history}");
    assert!(history.contains("def local_twice"), "{history}");

    let selected = rendered_text(&engine.handle_line(":history 1, 2"));
    assert!(selected.contains("1:"), "{selected}");
    assert!(selected.contains("2:"), "{selected}");
}

fn core_clear_command_preserves_session_state() {
    let mut engine = engine();

    let _ = engine.handle_line("seed = 41");

    let cleared = rendered_text(&engine.handle_line(":clear"));
    assert!(
        cleared.contains("clear") || cleared.contains("Clear") || cleared.contains("not available"),
        "{cleared}"
    );
    let after_clear = rendered_text(&engine.handle_line("seed"));
    assert!(after_clear.contains("41"), "{after_clear}");
}

fn core_reload_command_preserves_defs_and_discards_value_bindings() {
    let mut engine = engine();

    let _ = engine.handle_line("seed = 41");
    let _ = engine.handle_line("def keep() -> Int { 42 }");
    let _ = engine.handle_line(":clear");

    let reloaded = rendered_text(&engine.handle_line(":reload"));
    assert!(reloaded.contains("reload"), "{reloaded}");

    let keep_after_reload = rendered_text(&engine.handle_line("keep()"));
    assert!(keep_after_reload.contains("42"), "{keep_after_reload}");

    let seed_after_reload = rendered_text(&engine.handle_line("seed"));
    assert!(
        seed_after_reload.contains("not found")
            || seed_after_reload.contains("Unknown symbol")
            || seed_after_reload.contains("Undefined variable"),
        "{seed_after_reload}"
    );
}

fn core_reload_defs_command_discards_live_defs() {
    let mut engine = engine();

    let _ = engine.handle_line("def drop_me() -> Int { 7 }");
    let reload_defs = rendered_text(&engine.handle_line(":reload defs"));
    assert!(reload_defs.contains("reload"), "{reload_defs}");

    let dropped = rendered_text(&engine.handle_line("drop_me()"));
    assert!(
        dropped.contains("not found")
            || dropped.contains("Unknown symbol")
            || dropped.contains("Undefined variable")
            || dropped.contains("Undefined function"),
        "{dropped}"
    );
}

fn core_result_error_reports_diagnostic_without_exiting() {
    let mut engine = engine();

    let result_err = engine.handle_line("Err(NoneError())");
    assert!(!result_err.should_exit);
    assert!(matches!(result_err.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&result_err).contains("None Value."));

    let safe_mod = engine.handle_line("Mod::safe_mod(10, 0)");
    assert!(!safe_mod.should_exit);
    assert!(matches!(safe_mod.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&safe_mod).contains("modulo by zero"));
}

fn core_stacktrace_command_controls_result_error_trace_display() {
    let mut engine = engine();

    let default_mode = engine.handle_line(":stacktrace");
    assert_eq!(rendered_text(&default_mode), "stacktrace display mode: off");

    let hidden = engine.handle_line("def fail() -> Result<Int> { Err(NoneError()) }\nfail()");
    assert!(matches!(hidden.output, ReplOutput::EvalError { .. }));
    let hidden_text = rendered_text(&hidden);
    assert!(hidden_text.contains("None Value."));
    assert!(
        !hidden_text.contains("Stack trace:"),
        "stacktrace must default to off:\n{hidden_text}"
    );

    let hidden_runtime = engine.handle_line("Mod::safe_mod(10, 0)");
    assert!(matches!(
        hidden_runtime.output,
        ReplOutput::EvalError { .. }
    ));
    let hidden_runtime_text = rendered_text(&hidden_runtime);
    assert!(hidden_runtime_text.contains("modulo by zero"));
    assert!(
        !hidden_runtime_text.contains("Stack trace:"),
        "runtime stacktrace must default to off:\n{hidden_runtime_text}"
    );

    let enabled = engine.handle_line(":stacktrace verbose");
    assert_eq!(rendered_text(&enabled), "stacktrace display mode: verbose");

    let shown = engine.handle_line("fail()");
    assert!(matches!(shown.output, ReplOutput::EvalError { .. }));
    let shown_text = rendered_text(&shown);
    let message_idx = shown_text
        .find("None Value.")
        .expect("error message should render");
    let trace_idx = shown_text
        .find("Stack trace:")
        .expect("stacktrace should render after enabling verbose mode");
    assert!(
        message_idx < trace_idx,
        "error message must render before stacktrace:\n{shown_text}"
    );
    assert!(shown_text.contains("fail at"), "{shown_text}");

    let shown_runtime = engine.handle_line("Mod::safe_mod(10, 0)");
    assert!(matches!(shown_runtime.output, ReplOutput::EvalError { .. }));
    let shown_runtime_text = rendered_text(&shown_runtime);
    let runtime_message_idx = shown_runtime_text
        .find("modulo by zero")
        .expect("runtime error message should render");
    let runtime_trace_idx = shown_runtime_text
        .find("Stack trace:")
        .expect("runtime stacktrace should render after enabling verbose mode");
    assert!(
        runtime_message_idx < runtime_trace_idx,
        "runtime error message must render before stacktrace:\n{shown_runtime_text}"
    );

    let disabled = engine.handle_line(":stacktrace off");
    assert_eq!(rendered_text(&disabled), "stacktrace display mode: off");
    let hidden_again = engine.handle_line("fail()");
    assert!(!rendered_text(&hidden_again).contains("Stack trace:"));
}

fn core_stacktrace_display_is_independent_from_error_display_mode() {
    let mut engine = engine();

    let error_summary = engine.handle_line(":error summary");
    assert_eq!(rendered_text(&error_summary), "error display mode: summary");

    let stacktrace_verbose = engine.handle_line(":stacktrace verbose");
    assert_eq!(
        rendered_text(&stacktrace_verbose),
        "stacktrace display mode: verbose"
    );

    let result = engine.handle_line("def fail() -> Result<Int> { Err(NoneError()) }\nfail()");
    assert!(matches!(result.output, ReplOutput::EvalError { .. }));
    let text = rendered_text(&result);
    let message_idx = text
        .find("None Value.")
        .expect("summary error message should render");
    let trace_idx = text
        .find("Stack trace:")
        .expect("stacktrace should render while error mode is summary");
    assert!(
        message_idx < trace_idx,
        "summary error message must render before stacktrace:\n{text}"
    );
}

fn core_stacktrace_full_is_reserved_until_html_viewer_exists() {
    let mut engine = engine();

    let result = engine.handle_line(":stacktrace full");
    let text = rendered_text(&result);
    assert!(text.contains("not supported yet"), "{text}");
    assert!(text.contains("HTMLViewer"), "{text}");

    let current = engine.handle_line(":stacktrace");
    assert_eq!(rendered_text(&current), "stacktrace display mode: off");
}

fn core_immediate_anonymous_callable_calls_show_binding_hint() {
    let mut engine = engine();

    for source in [
        "&add(&1, 10)(4)",
        "(&add(&1, 10))(4)",
        "({|x| x + 1})(4)",
        "(make())(4)",
    ] {
        let result = engine.handle_line(source);
        assert!(!result.should_exit);
        assert!(matches!(result.output, ReplOutput::EvalError { .. }));
        let text = rendered_text(&result);
        assert!(
            text.contains("Immediate calls on anonymous callable expressions are not supported")
        );
        assert!(text.contains("f = &add(&1, 10)"));
        assert!(text.contains("tmp = make()"));
    }
}

fn core_doc_and_sig_commands_resolve_declarations_and_aliases() {
    let mut engine = engine();

    let builtin_doc = engine.handle_line(":doc print");
    let (symbol, signature) = doc_target(&builtin_doc);
    assert_eq!(symbol, "Kernel::print");
    assert_eq!(signature, Some("print(a: String) -> Unit"));

    let alias_doc = engine.handle_line(":doc +");
    let qualified_add_doc = engine.handle_line(":doc Add::add");
    assert_eq!(doc_target(&alias_doc), doc_target(&qualified_add_doc));
    assert_eq!(doc_target(&alias_doc).0, "Add::add");

    let and_doc = engine.handle_line(":doc &&");
    assert_eq!(doc_target(&and_doc).0, "Kernel::and");

    let or_doc = engine.handle_line(":doc ||");
    assert_eq!(doc_target(&or_doc).0, "Kernel::or");

    let bind_doc = engine.handle_line(":doc =");
    assert_eq!(
        doc_target(&bind_doc),
        (
            "Bootstrap::=",
            Some("@intrinsic def =(pattern: $Pattern, value: $A) -> Unit")
        )
    );

    let safe_bind_doc = engine.handle_line(":doc =?");
    assert_eq!(
        doc_target(&safe_bind_doc),
        (
            "Bootstrap::=?",
            Some("@intrinsic def =?(pattern: $Pattern, value: $A) -> Unit")
        )
    );

    let compare_doc = engine.handle_line(":doc Compare");
    assert_eq!(doc_target(&compare_doc).0, "Compare");

    let facet_doc = engine.handle_line(":doc Facet");
    assert_eq!(doc_target(&facet_doc).0, "Facet");

    let string_doc = engine.handle_line(":doc String");
    assert_eq!(doc_target(&string_doc).0, "String");

    let trait_family_sig = signature_text(&engine.handle_line(":sig Compare"));
    assert!(
        trait_family_sig.contains("trait Compare {"),
        "{trait_family_sig}"
    );
    assert!(
        trait_family_sig.contains("compare(self: Self, rhs: Self) -> Ordering"),
        "{trait_family_sig}"
    );
    assert!(
        trait_family_sig.contains("impl targets:"),
        "{trait_family_sig}"
    );
    assert!(trait_family_sig.contains("Int"), "{trait_family_sig}");
    assert!(trait_family_sig.contains("TupleN"), "{trait_family_sig}");
    assert!(!trait_family_sig.contains("Tuple2"), "{trait_family_sig}");
    assert!(!trait_family_sig.contains("Tuple8"), "{trait_family_sig}");

    let helper_sig = engine.handle_line(":sig compare");
    let helper_sig = signature_text(&helper_sig);
    assert!(
        helper_sig.contains("Compare::compare(self: Self, rhs: Self) -> Ordering"),
        "{helper_sig}"
    );
    assert!(helper_sig.contains("impl targets:"), "{helper_sig}");
    let less_than_sig = engine.handle_line(":sig <");
    let less_than_sig = signature_text(&less_than_sig);
    assert_eq!(
        less_than_sig.trim(),
        "Compare::lt(self: Self, rhs: Self) -> Boolean"
    );

    let default_less_than_sig = engine.handle_line(":sig lt");
    let default_less_than_sig = signature_text(&default_less_than_sig);
    assert_eq!(
        default_less_than_sig.trim(),
        "Compare::lt(self: Self, rhs: Self) -> Boolean"
    );

    let neq_helper_sig = engine.handle_line(":sig neq");
    let neq_helper_sig = signature_text(&neq_helper_sig);
    assert_eq!(
        neq_helper_sig.trim(),
        "Eq::neq(self: Self, rhs: Self) -> Boolean"
    );

    let operator_sig = engine.handle_line(":sig |>");
    let operator_sig = signature_text(&operator_sig);
    assert!(
        operator_sig.contains("Bootstrap::|>(value: $A, f: ($A -> $B)) -> $B"),
        "{operator_sig}"
    );
    for (symbol, signature) in [
        (
            ">>",
            "Bootstrap::>>(left: ($A -> $B), right: ($B -> $C)) -> ($A -> $C)",
        ),
        (
            ">*",
            "Bootstrap::>*(left: ($A -> Functor<$B>), mapper: ($B -> $C)) -> ($A -> Functor<$C>)",
        ),
        (
            ">=>",
            "Bootstrap::>=>(left: ($A -> Monad<$B>), mapper: ($B -> Monad<$C>)) -> ($A -> Monad<$C>)",
        ),
    ] {
        let actual = signature_text(&engine.handle_line(&format!(":sig {symbol}")));
        assert!(actual.contains(signature), "{symbol}: {actual}");
        let doc = doc_text(&engine.handle_line(&format!(":doc {symbol}")));
        assert!(doc.contains(symbol), "{symbol}: {doc}");
    }

    let functor_sig = signature_text(&engine.handle_line(":sig |*>"));
    assert!(functor_sig.contains("Functor::fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>"));
    assert!(functor_sig.contains("impl targets:"), "{functor_sig}");

    let monad_sig = signature_text(&engine.handle_line(":sig |>="));
    assert!(
        monad_sig.contains("Monad::bind(self: Self<$A>"),
        "{monad_sig}"
    );

    let arrow_doc = engine.handle_line(":doc ->");
    let arrow_doc = doc_text(&arrow_doc);
    assert!(arrow_doc.contains("Facet::compose"), "{arrow_doc}");

    let bind_sig = engine.handle_line(":sig =");
    let bind_sig = signature_text(&bind_sig);
    assert_eq!(
        bind_sig.trim(),
        "@intrinsic def =(pattern: $Pattern, value: $A) -> Unit"
    );

    let safe_bind_sig = engine.handle_line(":sig =?");
    let safe_bind_sig = signature_text(&safe_bind_sig);
    assert_eq!(
        safe_bind_sig.trim(),
        "@intrinsic def =?(pattern: $Pattern, value: $A) -> Unit"
    );

    let match_sig = engine.handle_line(":sig match");
    let match_sig = signature_text(&match_sig);
    assert_eq!(
        match_sig.trim(),
        "@intrinsic def match(value: $A, arms: MatchArms<$A, $B>) -> $B"
    );

    let cond_sig = engine.handle_line(":sig cond");
    let cond_sig = signature_text(&cond_sig);
    assert_eq!(
        cond_sig.trim(),
        "@intrinsic def cond(clauses: CondClauses<$A>) -> $A"
    );

    let helper_doc = engine.handle_line(":doc compare");
    let helper_doc = doc_text(&helper_doc);
    assert!(helper_doc.contains("Compare::compare"));

    let neq_helper_doc = engine.handle_line(":doc neq");
    assert_eq!(doc_target(&neq_helper_doc).0, "Eq::neq");

    let operator_doc = engine.handle_line(":doc <");
    let operator_doc = doc_text(&operator_doc);
    assert!(operator_doc.contains("Compare::lt"));
    assert!(!operator_doc.contains("trait Compare {"), "{operator_doc}");

    let default_less_than_doc = engine.handle_line(":doc lt");
    let default_less_than_doc = doc_text(&default_less_than_doc);
    assert!(default_less_than_doc.contains("Compare::lt"));
    assert!(
        !default_less_than_doc.contains("trait Compare {"),
        "{default_less_than_doc}"
    );

    let constructor_doc = engine.handle_line(":doc Duration::new");
    assert_eq!(doc_target(&constructor_doc).0, "Duration::new");
    let extractor_doc = engine.handle_line(":doc Duration!");
    assert_eq!(doc_target(&extractor_doc).0, "Duration::deconstruct");
    let extractor_sig = signature_text(&engine.handle_line(":sig Duration!"));
    assert!(
        extractor_sig.contains("Duration::deconstruct(self: Duration) -> MatchResult<Int>"),
        "{extractor_sig}"
    );

    let duration_sig = engine.handle_line(":sig Duration");
    let duration_sig = signature_text(&duration_sig);
    assert_eq!(
        duration_sig.trim(),
        "Duration::new(value: Int) -> Result<Duration, Error>"
    );
}

fn core_sig_monad_operator_lists_user_defined_box_impl() {
    let mut engine = ReplEngine::from_script_source(
        "box_operator_impls.srt",
        r#"defstruct Box<$T> {
  value: $T,
}

impl Box {
  def new(value: $T) -> Box<$T> {
    Box { value: value }
  }
}

impl Functor for Box<$T> {
  def fmap(self: Box<$A>, mapper: ($A -> $B)) -> Box<$B> {
    Box { value: mapper(self.value) }
  }
}

impl Applicative for Box<$T> {
  def pure::<Box<$T>>(value: $A) -> Box<$A> {
    Box { value: value }
  }

  def ap(mapper: Box<($A -> $B)>, value: Box<$A>) -> Box<$B> {
    f = mapper.value
    Box { value: f(value.value) }
  }
}

impl Monad for Box<$T> {
  def return::<Box<$T>>(value: $A) -> Box<$A> {
    Box { value: value }
  }

  def bind(self: Box<$A>, mapper: ($A -> Box<$B>)) -> Box<$B> {
    mapper(self.value)
  }
}"#,
    )
    .expect("box preload should load");

    let monad_sig = signature_text(&engine.handle_line(":sig Monad"));
    assert!(monad_sig.contains("impl targets:"), "{monad_sig}");
    assert!(monad_sig.contains("Box"), "{monad_sig}");
    let bind_sig = signature_text(&engine.handle_line(":sig |>="));
    assert!(
        bind_sig.contains("Monad::bind(self: Self<$A>"),
        "{bind_sig}"
    );
}

fn core_standard_monad_instances_construct_and_run() {
    let mut engine = engine();

    let identity = engine.handle_line("identity_value = Identity::new(7)");
    assert!(!identity.should_exit);
    assert!(rendered_text(&identity).contains("identity_value"));
    let identity_run = engine.handle_line("Identity::run(identity_value)");
    assert_eq!(rendered_text(&identity_run).trim(), "7");

    let reader = engine.handle_line("reader_value = Reader::new({|value: Int| value + 1})");
    assert!(!reader.should_exit);
    assert!(
        rendered_text(&reader).contains("Reader(run_reader: Closure(Int -> Int))"),
        "{}",
        rendered_text(&reader)
    );
    let reader_run = engine.handle_line("Reader::run(reader_value, 10)");
    assert_eq!(rendered_text(&reader_run).trim(), "11");

    for source in [
        "reader_pure: Reader<Int, Int> = Applicative::pure(7)",
        "reader_return: Reader<Int, Int> = Monad::return(7)",
    ] {
        let result = engine.handle_line(source);
        let rendered = rendered_text(&result);
        assert!(
            rendered.contains("Reader(run_reader: Closure(Int -> Int))"),
            "source: {source}\n{rendered}"
        );
    }

    let state_get = engine.handle_line("state_get_value: State<Int, Int> = State::get()");
    assert!(!state_get.should_exit);
    assert!(rendered_text(&state_get).contains("state_get_value"));
    let state_get_run = engine.handle_line("State::run(state_get_value, 10)");
    assert_eq!(rendered_text(&state_get_run).trim(), "(10, 10)");

    let monoid_capture = engine.handle_line("Monoid(1, &Add::add)");
    let monoid_capture_text = rendered_text(&monoid_capture);
    assert!(
        monoid_capture_text.contains(
            "Monoid(empty: 1, combine: FnCapture(module: Add, name: add, sig: (Int, Int -> Int)))"
        ),
        "{monoid_capture_text}"
    );

    let state = engine.handle_line("state_value = State::new({|value: Int| (value + 1, value)})");
    assert!(!state.should_exit);
    assert!(
        rendered_text(&state).contains("State(run_state: Closure(Int -> (Int, Int)))"),
        "{}",
        rendered_text(&state)
    );
    let state_run = engine.handle_line("State::run(state_value, 10)");
    assert_eq!(rendered_text(&state_run).trim(), "(11, 10)");

    for source in [
        "state_pure: State<Int, Int> = Applicative::pure(4)",
        "state_return: State<Int, Int> = Monad::return(4)",
    ] {
        let result = engine.handle_line(source);
        let rendered = rendered_text(&result);
        assert!(
            rendered.contains("State(run_state: Closure(Int -> (Int, Int)))"),
            "source: {source}\n{rendered}"
        );
    }
}

fn core_standard_monad_transformer_smoke() {
    let mut engine = engine();

    let reader_t =
        engine.handle_line("ReaderT::new({|environment: Int| Identity::new(environment + 1)})");
    assert!(
        rendered_text(&reader_t).contains("ReaderT(run_reader: Closure(Int -> Identity<Int>))"),
        "{}",
        rendered_text(&reader_t)
    );

    let state_t =
        engine.handle_line("StateT::new({|state: Int| Identity::new((state + 1, state + 2))})");
    assert!(
        rendered_text(&state_t).contains("StateT(run_state: Closure(Int -> Identity<(Int, Int)>))"),
        "{}",
        rendered_text(&state_t)
    );

    let reader_t_pure =
        engine.handle_line("reader_t_pure: ReaderT<Int, Identity, Int> = Applicative::pure(2)");
    assert!(
        rendered_text(&reader_t_pure)
            .contains("ReaderT(run_reader: Closure(Int -> Identity<Int>))"),
        "{}",
        rendered_text(&reader_t_pure)
    );

    let reader_t_return =
        engine.handle_line("reader_t_return: ReaderT<Int, Identity, Int> = Monad::return(2)");
    assert!(
        rendered_text(&reader_t_return)
            .contains("ReaderT(run_reader: Closure(Int -> Identity<Int>))"),
        "{}",
        rendered_text(&reader_t_return)
    );

    let base = engine.handle_line("base_value: Result<Int> = Ok(7)");
    assert!(!matches!(base.output, ReplOutput::EvalError { .. }));

    let reader_t_lift = engine
        .handle_line("reader_t_lifted: ReaderT<String, Result, Int> = MonadT::lift(base_value)");
    assert!(
        rendered_text(&reader_t_lift)
            .contains("ReaderT(run_reader: Closure(String -> Result<Int>))"),
        "{}",
        rendered_text(&reader_t_lift)
    );

    let reader_t_empty =
        engine.handle_line("empty_reader_t: ReaderT<Int, Option, Int> = Alternative::empty()");
    assert!(
        rendered_text(&reader_t_empty).contains("ReaderT(run_reader: Closure(Int -> Option<Int>))"),
        "{}",
        rendered_text(&reader_t_empty)
    );

    let state_t_pure =
        engine.handle_line("state_t_pure: StateT<Int, Identity, Int> = Applicative::pure(2)");
    assert!(
        rendered_text(&state_t_pure)
            .contains("StateT(run_state: Closure(Int -> Identity<(Int, Int)>))"),
        "{}",
        rendered_text(&state_t_pure)
    );

    let state_t_return =
        engine.handle_line("state_t_return: StateT<Int, Identity, Int> = Monad::return(2)");
    assert!(
        rendered_text(&state_t_return)
            .contains("StateT(run_state: Closure(Int -> Identity<(Int, Int)>))"),
        "{}",
        rendered_text(&state_t_return)
    );

    let state_t_lift =
        engine.handle_line("state_t_lifted: StateT<Int, Result, Int> = MonadT::lift(base_value)");
    assert!(
        rendered_text(&state_t_lift)
            .contains("StateT(run_state: Closure(Int -> Result<(Int, Int)>))"),
        "{}",
        rendered_text(&state_t_lift)
    );

    let state_t_empty =
        engine.handle_line("state_t_empty: StateT<Int, Option, Int> = Alternative::empty()");
    assert!(
        rendered_text(&state_t_empty)
            .contains("StateT(run_state: Closure(Int -> Option<(Int, Int)>))"),
        "{}",
        rendered_text(&state_t_empty)
    );

    let lifted = engine.handle_line("value: OptionT<Result, Int> = MonadT::lift(Ok(1))");
    assert!(
        !matches!(lifted.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&lifted)
    );
    let run = engine.handle_line("OptionT::run(value)");
    assert_eq!(rendered_text(&run).trim(), "Ok(Option::Some(1))");
}

#[test]
fn core_standard_monad_transformer_survives_ambiguous_lift() {
    let mut engine = engine();

    let constructed =
        engine.handle_line("option_new: OptionT<Result, Int> = OptionT::new(Ok(Option::Some(1)))");
    assert!(!constructed.should_exit);
    assert!(
        !matches!(constructed.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&constructed)
    );

    let lifted = engine.handle_line("option_lifted: OptionT<Result, Int> = MonadT::lift(Ok(2))");
    assert!(!lifted.should_exit);
    assert!(
        !matches!(lifted.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&lifted)
    );

    let mapped = engine
        .handle_line("option_mapped: OptionT<Result, Int> = option_lifted |*> {|value| value + 1}");
    assert!(!mapped.should_exit);
    assert!(
        !matches!(mapped.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&mapped)
    );

    let ambiguous = engine.handle_line("MonadT::lift(Identity::new(9))");
    assert!(!ambiguous.should_exit);
    assert!(matches!(ambiguous.output, ReplOutput::EvalError { .. }));
    let ambiguous_text = rendered_text(&ambiguous);
    assert!(
        ambiguous_text.contains("return type arguments for")
            && ambiguous_text.contains("cannot be inferred"),
        "{ambiguous_text}"
    );

    let run = engine.handle_line("OptionT::run(option_mapped)");
    assert!(!run.should_exit);
    assert!(
        !matches!(run.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&run)
    );
    assert_eq!(rendered_text(&run).trim(), "Ok(Option::Some(3))");

    let either_new = engine.handle_line(
        "either_new: EitherT<String, Identity, Int> = EitherT::new(Identity::new(Either::Right(4)))",
    );
    assert!(!matches!(either_new.output, ReplOutput::EvalError { .. }));
    let either_lifted = engine.handle_line(
        "either_lifted: EitherT<String, Identity, Int> = MonadT::lift(Identity::new(5))",
    );
    assert!(!matches!(
        either_lifted.output,
        ReplOutput::EvalError { .. }
    ));
    let either_mapped = engine.handle_line(
        "either_mapped: EitherT<String, Identity, Int> = either_lifted |*> {|value| value + 1}",
    );
    assert!(!matches!(
        either_mapped.output,
        ReplOutput::EvalError { .. }
    ));
    let either_run = engine.handle_line("Identity::run(EitherT::run(either_mapped))");
    assert_eq!(rendered_text(&either_run).trim(), "Either::Right(6)");

    let reader_new = engine.handle_line(
        "reader_new: ReaderT<Int, Identity, Int> = ReaderT::new({|environment: Int| Identity::new(environment)})",
    );
    assert!(!matches!(reader_new.output, ReplOutput::EvalError { .. }));
    let reader_lifted = engine
        .handle_line("reader_lifted: ReaderT<Int, Identity, Int> = MonadT::lift(Identity::new(7))");
    assert!(!matches!(
        reader_lifted.output,
        ReplOutput::EvalError { .. }
    ));
    let reader_mapped = engine.handle_line(
        "reader_mapped: ReaderT<Int, Identity, Int> = reader_lifted |*> {|value| value + 1}",
    );
    assert!(!matches!(
        reader_mapped.output,
        ReplOutput::EvalError { .. }
    ));
    let reader_run = engine.handle_line("Identity::run(ReaderT::run(reader_mapped, 99))");
    assert_eq!(rendered_text(&reader_run).trim(), "8");

    let state_new = engine.handle_line(
        "state_new: StateT<Int, Identity, Int> = StateT::new({|state: Int| Identity::new((state, state))})",
    );
    assert!(!matches!(state_new.output, ReplOutput::EvalError { .. }));
    let state_lifted = engine
        .handle_line("state_lifted: StateT<Int, Identity, Int> = MonadT::lift(Identity::new(9))");
    assert!(!matches!(state_lifted.output, ReplOutput::EvalError { .. }));
    let state_mapped = engine.handle_line(
        "state_mapped: StateT<Int, Identity, Int> = state_lifted |*> {|value| value + 1}",
    );
    assert!(!matches!(state_mapped.output, ReplOutput::EvalError { .. }));
    let state_run = engine.handle_line("Identity::run(StateT::run(state_mapped, 12))");
    assert_eq!(rendered_text(&state_run).trim(), "(10, 12)");
}

#[test]
fn core_standard_monad_transformer_persists_explicit_rta() {
    let mut engine = engine();

    let full = engine.handle_line("full = MonadT::lift::<OptionT<Result, Int>>(Ok(1))");
    assert!(
        !matches!(full.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&full)
    );
    let full_run = engine.handle_line("OptionT::run(full)");
    assert_eq!(rendered_text(&full_run).trim(), "Ok(Option::Some(1))");

    let inferred = engine.handle_line("inferred = MonadT::lift::<OptionT<Result, _>>(Ok(2))");
    assert!(
        !matches!(inferred.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&inferred)
    );
    let inferred_run = engine.handle_line("OptionT::run(inferred)");
    assert_eq!(rendered_text(&inferred_run).trim(), "Ok(Option::Some(2))");

    let base = engine.handle_line("base: OptionT<Result, Int> = OptionT::some::<Result>(3)");
    assert!(
        !matches!(base.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&base)
    );
    let stacked = engine
        .handle_line("stacked = MonadT::lift::<ReaderT<String, OptionT<Result, _>, Int>>(base)");
    assert!(
        !matches!(stacked.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&stacked)
    );
    let stacked_run = engine.handle_line("OptionT::run(ReaderT::run(stacked, \"env\"))");
    assert_eq!(rendered_text(&stacked_run).trim(), "Ok(Option::Some(3))");
}

fn core_standard_state_get_rejects_ambiguity_and_keeps_session_alive() {
    let mut engine = engine();

    let ambiguous = engine.handle_line("State::get()");
    assert!(!ambiguous.should_exit);
    assert!(matches!(ambiguous.output, ReplOutput::EvalError { .. }));
    let ambiguous_text = rendered_text(&ambiguous);
    assert!(
        ambiguous_text.contains("return type arguments for")
            && ambiguous_text.contains("cannot be inferred"),
        "{ambiguous_text}"
    );

    let continued = engine.handle_line("after_state_get_error = 42");
    assert!(!continued.should_exit);
    assert!(rendered_text(&continued).contains("after_state_get_error: Int"));
}

fn core_safebind_diagnostic_keeps_session_alive() {
    let mut engine = engine();

    let rejected = engine.handle_line("saved =? Option::Some(1)");
    assert!(!rejected.should_exit);
    assert!(matches!(rejected.output, ReplOutput::EvalError { .. }));
    let rejected_text = rendered_text(&rejected);
    assert!(
        rejected_text.contains("Result以外")
            || rejected_text.contains("non-Result")
            || rejected_text.contains("SafeBind"),
        "{rejected_text}"
    );

    let continued = engine.handle_line("after_safebind_error = 42");
    assert!(!continued.should_exit);
    assert!(rendered_text(&continued).contains("after_safebind_error: Int"));
}

fn core_compare_definition_query_ignores_impl_override_selection() {
    let mut engine = ReplEngine::from_script_source(
        "compare_default.srt",
        r#"
defstruct Ranked {
  weight: Int,
}

impl Ranked {
  def new(weight: Int) -> Self {
    Ranked { weight: weight }
  }
}

impl Compare for Ranked {
  def compare(self: Self, rhs: Self) -> Ordering {
    Compare::compare(self.weight, rhs.weight)
  }
}
"#,
    )
    .expect("compare default preload should bootstrap");

    let sig = signature_text(&engine.handle_line(":sig Compare::lt"));
    assert_eq!(sig.trim(), "Compare::lt(self: Self, rhs: Self) -> Boolean");
    assert_eq!(doc_target(&engine.handle_line(":doc lt")).0, "Compare::lt");
}

fn core_sig_type_owner_uses_constructor_signatures() {
    let mut engine = engine();

    let option_sig = engine.handle_line(":sig Option");
    let option_sig = rendered_text(&option_sig);
    assert!(option_sig.contains("* Option::Some($T)"), "{option_sig}");
    assert!(option_sig.contains("* Option::None"), "{option_sig}");

    let point_sig = engine.handle_line(":sig StyledDocStyle");
    let point_sig = signature_text(&point_sig);
    assert!(point_sig.contains("StyledDocStyle::new("), "{point_sig}");
    assert!(point_sig.contains("fg: Option"), "{point_sig}");
    assert!(point_sig.contains("italic: Boolean"), "{point_sig}");
    assert!(point_sig.contains("-> StyledDocStyle"), "{point_sig}");

    let style = rendered_text(&engine.handle_line(
        "style = StyledDocStyle::new(Option::None, Option::None, True, False, False, False)",
    ));
    assert!(style.contains("style: StyledDocStyle"), "{style}");
}

fn core_sig_record_owner_uses_record_constructor_surface() {
    let mut engine = ReplEngine::from_script_source(
        "record_sig.srt",
        r#"
defrecord ScoreFixture(scores: List<Int>, score: HashMap<Int>)
"#,
    )
    .expect("record preload should bootstrap");

    let sig = signature_text(&engine.handle_line(":sig ScoreFixture"));
    assert_eq!(
        sig.trim(),
        "ScoreFixture(scores: List<Int>, score: HashMap<Int>) -> ScoreFixture"
    );
}

fn core_range_constructor_and_extractor_queries_use_named_declarations() {
    let mut engine = engine();

    let constructor_doc = doc_text(&engine.handle_line(":doc Range::new"));
    assert!(constructor_doc.contains("Range::new"), "{constructor_doc}");
    assert!(constructor_doc.contains("min: $A"), "{constructor_doc}");
    assert!(constructor_doc.contains("max: $A"), "{constructor_doc}");
    assert!(
        constructor_doc.contains("-> Range<$A>"),
        "{constructor_doc}"
    );

    let range_sig = signature_text(&engine.handle_line(":sig Range"));
    assert!(range_sig.contains("Range::new"), "{range_sig}");
    assert!(range_sig.contains("min: $A"), "{range_sig}");
    assert!(range_sig.contains("max: $A"), "{range_sig}");
    assert!(range_sig.contains("-> Range<$A>"), "{range_sig}");

    let extractor_doc = doc_text(&engine.handle_line(":doc Range!"));
    assert!(
        extractor_doc.contains("Range::deconstruct"),
        "{extractor_doc}"
    );
    assert!(
        extractor_doc.contains("MatchResult<($A, $A)>"),
        "{extractor_doc}"
    );

    let extractor_sig = signature_text(&engine.handle_line(":sig Range!"));
    assert_eq!(
        extractor_sig.trim(),
        "Range::deconstruct(self: Range<$A>) -> MatchResult<($A, $A)>"
    );
}

fn core_sig_resolves_enum_variant_names() {
    let mut engine = engine();
    let bare_variant = signature_text(&engine.handle_line(":sig Option::Some"));
    assert!(bare_variant.contains("Option::Some"), "{bare_variant}");
}

fn core_doc_command_resolves_closure_type_and_callable_bindings() {
    let mut engine = engine();

    let closure_doc = engine.handle_line(":doc Closure");
    assert_eq!(doc_target(&closure_doc).0, "Closure");

    let closure_binding = engine.handle_line("adder = {|n: Int| n + 1}");
    assert!(rendered_text(&closure_binding).contains("adder: (Int -> Int)"));
    let closure_binding_doc = engine.handle_line(":doc adder");
    let closure_binding_doc = doc_text(&closure_binding_doc);
    assert!(
        closure_binding_doc.contains("type: (Int -> Int)"),
        "{closure_binding_doc}"
    );
    assert!(
        closure_binding_doc.contains("example: ret: Int = adder(Int)"),
        "{closure_binding_doc}"
    );
    assert!(
        !closure_binding_doc.contains("captures:"),
        "{closure_binding_doc}"
    );

    let capture_binding = engine.handle_line("printer = &print");
    assert!(rendered_text(&capture_binding).contains("FnCapture(module: Kernel, name: print"));
    let capture_binding_doc = engine.handle_line(":doc printer");
    let capture_binding_doc = doc_text(&capture_binding_doc);
    assert!(
        capture_binding_doc.contains("Kernel::print"),
        "{capture_binding_doc}"
    );
    assert!(
        capture_binding_doc.contains("binding: printer"),
        "{capture_binding_doc}"
    );
    assert!(
        capture_binding_doc.contains("derived from: Kernel::print"),
        "{capture_binding_doc}"
    );

    let result_binding = engine.handle_line("ret = Ok(1)");
    assert!(rendered_text(&result_binding).contains("ret: Result<Int>"));
    let result_binding_doc = engine.handle_line(":doc ret");
    assert_eq!(doc_target(&result_binding_doc).0, "Result");
}

fn core_process_doc_and_sig_support_hidden_and_concrete_surfaces() {
    let mut engine = process_engine();

    let hidden_doc = doc_text(&engine.handle_line(":doc GenServer::spawn"));
    assert!(hidden_doc.contains("GenServer::spawn"), "{hidden_doc}");
    assert!(
        hidden_doc.contains("Compiler-managed lower target for GenServer worker spawn."),
        "{hidden_doc}"
    );

    let concrete_doc = doc_text(&engine.handle_line(":doc MySup::status"));
    assert!(concrete_doc.contains("MySup::status"), "{concrete_doc}");
    assert!(
        concrete_doc.contains("Compiler-managed lower target for reading supervisor status."),
        "{concrete_doc}"
    );
    assert!(
        !concrete_doc.contains("Supervisor::status(supervisor:"),
        "{concrete_doc}"
    );

    let hidden_sig = signature_text(&engine.handle_line(":sig Supervisor::status"));
    assert!(
        hidden_sig
            .contains("Supervisor::status(supervisor: $Supervisor) -> Result<SupervisorStatus>"),
        "{hidden_sig}"
    );

    let concrete_sig = signature_text(&engine.handle_line(":sig MySup::status"));
    assert!(
        concrete_sig.contains("MySup::status() -> Result<SupervisorStatus>"),
        "{concrete_sig}"
    );

    let hidden_pid_doc = doc_text(&engine.handle_line(":doc Agent::pid"));
    assert!(hidden_pid_doc.contains("Agent::pid"), "{hidden_pid_doc}");
    assert!(
        hidden_pid_doc.contains("Compiler-managed lower target for Agent singleton PID lookup."),
        "{hidden_pid_doc}"
    );

    let concrete_pid_doc = doc_text(&engine.handle_line(":doc MyServer::pid"));
    assert!(
        concrete_pid_doc.contains("MyServer::pid"),
        "{concrete_pid_doc}"
    );
    assert!(
        concrete_pid_doc
            .contains("Compiler-managed lower target for GenServer singleton PID lookup."),
        "{concrete_pid_doc}"
    );
    assert!(
        !concrete_pid_doc.contains("GenServer::pid(owner:"),
        "{concrete_pid_doc}"
    );

    let hidden_pid_sig = signature_text(&engine.handle_line(":sig GenServer::pid"));
    assert!(
        hidden_pid_sig
            .contains("GenServer::pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>"),
        "{hidden_pid_sig}"
    );

    let concrete_pid_sig = signature_text(&engine.handle_line(":sig MyServer::pid"));
    assert!(
        concrete_pid_sig.contains("MyServer::pid() -> PID<MyServer>"),
        "{concrete_pid_sig}"
    );
}

fn core_process_public_surface_respects_annotations() {
    let mut engine = process_engine();

    let public_sig = signature_text(&engine.handle_line(":sig MyServer::size"));
    assert!(
        public_sig.contains("MyServer::size() -> Result<Int>"),
        "{public_sig}"
    );

    let public_doc = doc_text(&engine.handle_line(":doc MyWorker::read"));
    assert!(public_doc.contains("MyWorker::read"), "{public_doc}");

    let private_sig = rendered_text(&engine.handle_line(":sig MyServer::hidden_size"));
    assert!(
        private_sig
            .contains("`MyServer::hidden_size` is private and cannot be queried with `:sig`."),
        "{private_sig}"
    );
    assert!(
        private_sig.contains("Only public declarations are visible to REPL signature lookup."),
        "{private_sig}"
    );

    let private_doc = rendered_text(&engine.handle_line(":doc MyWorker::hidden_value"));
    assert!(
        private_doc
            .contains("`MyWorker::hidden_value` is private and cannot be queried with `:doc`."),
        "{private_doc}"
    );
    assert!(
        private_doc.contains("Add `@doc` only to public declarations."),
        "{private_doc}"
    );

    let annotation_query = rendered_text(&engine.handle_line(":sig @call"));
    assert!(
        annotation_query.contains("ReplQueryParseError"),
        "{annotation_query}"
    );
}

fn core_process_sig_owner_summary_includes_init_pid_and_messages() {
    let mut engine = process_engine();

    let owner_sig = signature_text(&engine.handle_line(":sig MyServer"));
    assert!(owner_sig.contains("GenServer MyServer"), "{owner_sig}");
    assert!(
        owner_sig.contains("@init init() -> Result<PID<MyServer>>"),
        "{owner_sig}"
    );
    assert!(
        owner_sig.contains("@pid pid() -> PID<MyServer>"),
        "{owner_sig}"
    );
    assert!(
        owner_sig.contains("@call size(pid: PID<MyServer>) -> Result<Int>"),
        "{owner_sig}"
    );
}

fn core_process_sig_worker_owner_summary_includes_init_and_messages() {
    let mut engine = process_engine();

    let owner_sig = signature_text(&engine.handle_line(":sig MyWorker"));
    assert!(owner_sig.contains("Agent MyWorker"), "{owner_sig}");
    assert!(
        owner_sig.contains("@init init(seed: Int) -> Result<PID<MyWorker>>"),
        "{owner_sig}"
    );
    assert!(
        owner_sig.contains("@get read(pid: PID<MyWorker>) -> Result<Int>"),
        "{owner_sig}"
    );
    assert!(
        owner_sig.contains("@set write(pid: PID<MyWorker>, next: Int) -> Result<Unit>"),
        "{owner_sig}"
    );
    assert!(!owner_sig.contains("@pid"), "{owner_sig}");
}

fn core_process_sig_pid_binding_lists_available_messages() {
    let mut engine = process_engine();

    let bind = engine.handle_line("server = MyServer::pid()");
    assert!(rendered_text(&bind).contains("server: PID<MyServer>"));

    let pid_sig = signature_text(&engine.handle_line(":sig server"));
    assert!(pid_sig.contains("PID<MyServer> messaging"), "{pid_sig}");
    assert!(
        pid_sig.contains("@call size(pid: PID<MyServer>) -> Result<Int>"),
        "{pid_sig}"
    );
    assert!(!pid_sig.contains("@init"), "{pid_sig}");
    assert!(!pid_sig.contains("@pid"), "{pid_sig}");
}

fn core_process_type_and_info_support_singletons_and_worker_pids() {
    let mut engine = process_engine();

    let singleton_type = rendered_text(&engine.handle_line(":type MyServer"));
    assert!(
        singleton_type.contains("type: PID<MyServer>"),
        "{singleton_type}"
    );
    assert!(
        !singleton_type.contains("<pid>") && !singleton_type.contains("pid:"),
        "{singleton_type}"
    );

    let singleton_info = rendered_text(&engine.handle_line(":info MyServer"));
    assert!(
        singleton_info.contains("defined: PID<MyServer>"),
        "{singleton_info}"
    );
    assert!(
        singleton_info.contains("instance: Singleton"),
        "{singleton_info}"
    );

    let spawn = engine.handle_line("pid =? MyWorker::init(1)");
    let spawn_text = rendered_text(&spawn);
    assert!(spawn_text.contains("pid: PID<MyWorker>"), "{spawn_text}");
    assert!(!spawn_text.contains("PID<$Process>"), "{spawn_text}");

    let worker_type = rendered_text(&engine.handle_line(":type pid"));
    assert!(worker_type.contains("type: PID<MyWorker>"), "{worker_type}");
    assert!(
        !worker_type.contains("<pid>") && !worker_type.contains("pid: <"),
        "{worker_type}"
    );

    let worker_info = rendered_text(&engine.handle_line(":info pid"));
    assert!(
        worker_info.contains("defined: PID<MyWorker>"),
        "{worker_info}"
    );
    assert!(worker_info.contains("instance: Worker"), "{worker_info}");
    assert!(worker_info.contains("runtime kind:"), "{worker_info}");
    assert!(!worker_info.contains("process:"), "{worker_info}");
    assert!(!worker_info.contains("<pid>"), "{worker_info}");

    let singleton_pid_binding = rendered_text(&engine.handle_line("server = MyServer::pid()"));
    assert!(
        singleton_pid_binding.contains("server: PID<MyServer>"),
        "{singleton_pid_binding}"
    );

    let singleton_pid_info = rendered_text(&engine.handle_line(":info server"));
    assert!(
        singleton_pid_info.contains("kind: process pid"),
        "{singleton_pid_info}"
    );
    assert!(
        singleton_pid_info.contains("defined: PID<MyServer>"),
        "{singleton_pid_info}"
    );
}

fn core_sig_expression_queries_support_operator_forms() {
    let mut engine = engine();

    for (operator, trait_name, method) in [("/", "Div", "safe_div"), ("%", "Mod", "safe_mod")] {
        let doc = engine.handle_line(&format!(":doc {operator}"));
        assert_eq!(doc_target(&doc).0, format!("{trait_name}::{method}"));
        let sig = signature_text(&engine.handle_line(&format!(":sig {operator}")));
        assert!(sig.contains(&format!("{trait_name}::{method}")), "{sig}");
    }
}

fn core_sig_preserves_polymorphic_declarations() {
    let mut engine = engine();
    let sig = signature_text(&engine.handle_line(":sig id"));
    assert_eq!(sig.trim(), "Function::id(value: $A) -> $A");
}

fn core_operator_captures_display_trait_identity_and_execute() {
    let mut engine = engine();
    for (operator, module, name, signature, args, result) in [
        ("+", "Add", "add", "Int, Int -> Int", "8, 2", "10"),
        ("-", "Sub", "sub", "Int, Int -> Int", "8, 2", "6"),
        ("*", "Mul", "mul", "Int, Int -> Int", "8, 2", "16"),
        (
            "/",
            "Div",
            "safe_div",
            "Int, Int -> Result<Int>",
            "8, 2",
            "Ok(4)",
        ),
        (
            "%",
            "Mod",
            "safe_mod",
            "Int, Int -> Result<Int>",
            "8, 3",
            "Ok(2)",
        ),
        (
            "++",
            "Concat",
            "concat",
            "String, String -> String",
            "\"a\", \"b\"",
            "\"ab\"",
        ),
        ("==", "Eq", "eq", "Int, Int -> Boolean", "8, 2", "False"),
        ("!=", "Eq", "neq", "Int, Int -> Boolean", "8, 2", "True"),
        ("<", "Compare", "lt", "Int, Int -> Boolean", "8, 2", "False"),
        (">", "Compare", "gt", "Int, Int -> Boolean", "8, 2", "True"),
        (
            "<=",
            "Compare",
            "lte",
            "Int, Int -> Boolean",
            "8, 2",
            "False",
        ),
        (
            ">=",
            "Compare",
            "gte",
            "Int, Int -> Boolean",
            "8, 2",
            "True",
        ),
    ] {
        let source = format!("operator: ({signature}) = &`{operator}`");
        let output = rendered_text(&engine.handle_line(&source));
        let expected = format!("FnCapture(module: {module}, name: {name}, sig: ({signature}))");
        assert!(output.contains(&expected), "{source}\n{output}");
        let applied = rendered_text(&engine.handle_line(&format!("operator({args})")));
        assert!(applied.trim() == result, "{operator}\n{applied}");
    }

    let closure = rendered_text(&engine.handle_line("literal = {|a: Int, b: Int| a + b}"));
    assert!(closure.contains("Closure(Int, Int -> Int)"), "{closure}");
}

fn core_operator_partial_captures_preserve_origin_and_placeholder_order() {
    let mut engine = engine();
    let swapped = rendered_text(&engine.handle_line("swapped: (Int, Int -> Int) = &`-`(&2, &1)"));
    assert!(
        swapped.contains("FnCapture(module: Sub, name: sub, sig: (Int, Int -> Int))"),
        "{swapped}"
    );
    let applied = rendered_text(&engine.handle_line("swapped(2, 8)"));
    assert!(applied.trim() == "6", "{applied}");

    let partial = rendered_text(&engine.handle_line("partial = &swapped(2, &1)"));
    assert!(
        partial.contains("FnCapture(module: Sub, name: sub, sig: (Int -> Int))"),
        "{partial}"
    );
    let applied = rendered_text(&engine.handle_line("partial(8)"));
    assert!(applied.trim() == "6", "{applied}");

    let direct = rendered_text(&engine.handle_line("increment = &`+`(&1, 4)"));
    assert!(
        direct.contains("FnCapture(module: Add, name: add, sig: (Int -> Int))"),
        "{direct}"
    );
    let nested = rendered_text(&engine.handle_line("Ok(increment)"));
    assert!(
        nested.contains("Ok(FnCapture(module: Add, name: add, sig: (Int -> Int)))"),
        "{nested}"
    );
    let literal = rendered_text(&engine.handle_line("wrapped = {|n: Int| increment(n)}"));
    assert!(literal.contains("Closure(Int -> Int)"), "{literal}");
}

fn core_pair_captures_display_bootstrap_identity_and_concrete_types() {
    let mut engine = engine();
    let pair = rendered_text(&engine.handle_line("pair: (Int, String -> (Int, String)) = &`(,)`"));
    assert!(
        pair.contains(
            "FnCapture(module: Bootstrap, name: (,), sig: (Int, String -> (Int, String)))"
        ),
        "{pair}"
    );
    let applied = rendered_text(&engine.handle_line("pair(1, \"one\")"));
    assert!(applied.trim() == "(1, \"one\")", "{applied}");

    let swapped = rendered_text(
        &engine.handle_line("swapped_pair: (String, Int -> (Int, String)) = &`(,)`(&2, &1)"),
    );
    assert!(
        swapped.contains(
            "FnCapture(module: Bootstrap, name: (,), sig: (String, Int -> (Int, String)))"
        ),
        "{swapped}"
    );
    let applied = rendered_text(&engine.handle_line("swapped_pair(\"one\", 1)"));
    assert!(applied.trim() == "(1, \"one\")", "{applied}");

    let partial =
        rendered_text(&engine.handle_line("tagged: (Int -> (Int, String)) = &`(,)`(&1, \"tag\")"));
    assert!(
        partial.contains("FnCapture(module: Bootstrap, name: (,), sig: (Int -> (Int, String)))"),
        "{partial}"
    );
    let recaptured = rendered_text(&engine.handle_line("again = &tagged(&1)"));
    assert!(
        recaptured.contains("FnCapture(module: Bootstrap, name: (,), sig: (Int -> (Int, String)))"),
        "{recaptured}"
    );
    let nested = rendered_text(&engine.handle_line("Ok(again)"));
    assert!(
        nested.contains("Ok(FnCapture(module: Bootstrap, name: (,), sig: (Int -> (Int, String))))"),
        "{nested}"
    );
    let applied = rendered_text(&engine.handle_line("again(2)"));
    assert!(applied.trim() == "(2, \"tag\")", "{applied}");
}

fn core_sig_supports_closure_bindings() {
    let mut engine = engine();

    let closure = engine.handle_line("a = {|n: Int, m: Int| n + m}");
    let closure_text = rendered_text(&closure);
    assert!(
        closure_text.contains("a: (Int, Int -> Int)"),
        "{closure_text}"
    );

    let closure_sig = engine.handle_line(":sig a");
    assert_eq!(
        signature_text(&closure_sig),
        "a: (Int, Int -> Int) :: Closure"
    );

    let recaptured = engine.handle_line("b = &a(1, &1)");
    let recaptured_text = rendered_text(&recaptured);
    assert!(
        recaptured_text.contains("b: (Int -> Int)"),
        "{recaptured_text}"
    );

    let recaptured_sig = engine.handle_line(":sig b");
    assert_eq!(
        signature_text(&recaptured_sig),
        "b: (Int -> Int) :: Closure"
    );
    let recaptured_type = rendered_text(&engine.handle_line(":type b"));
    assert!(
        recaptured_type.contains("identity: TypeIdentity::Closure"),
        "{recaptured_type}"
    );
}

fn core_completion_shows_signature_for_callable_binding_calls() {
    let mut engine = engine();

    let closure = engine.handle_line("formatter = {|value: Int| to_string(value)}");
    let closure_text = rendered_text(&closure);
    assert!(
        closure_text.contains("formatter: (Int -> String)"),
        "{closure_text}"
    );

    let completion = engine.completions("formatter(", "formatter(".len());
    let signature = completion
        .signature
        .as_ref()
        .expect("callable binding call-site should show signature help");
    assert_eq!(signature.active_parameter, Some(0));
    assert_eq!(signature.lines.join("\n"), "formatter([Int]) -> String");
}

fn core_callable_refs_and_signature_errors_are_ui_independent() {
    let mut engine = engine();

    let builtin_ref = engine.handle_line("&Int::shr");
    let builtin_ref_text = rendered_text(&builtin_ref);
    assert!(
        builtin_ref_text
            .contains("FnCapture(module: Int, name: shr, sig: (Int, Int -> Result<Int>))"),
        "{builtin_ref_text}"
    );

    let partial_capture_ref = engine.handle_line("&Add::add(&1, 1)");
    assert!(rendered_text(&partial_capture_ref)
        .contains("FnCapture(module: Add, name: add, sig: (Int -> Int))"));

    let typed_capture_ref = engine.handle_line("f: (Int, Int -> Int) = &Add::add");
    let typed_capture_ref_text = rendered_text(&typed_capture_ref);
    assert!(
        typed_capture_ref_text.contains(
            "f: (Int, Int -> Int) = FnCapture(module: Add, name: add, sig: (Int, Int -> Int))"
        ),
        "{typed_capture_ref_text}"
    );

    let closure_ref = engine.handle_line("{|x: Int, y: Int| x + y}");
    assert!(rendered_text(&closure_ref).contains("Closure(Int, Int -> Int)"));

    let trait_helper = engine.handle_line("&concat");
    assert!(!trait_helper.should_exit);
    assert!(matches!(trait_helper.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&trait_helper).contains(
        "Trait helper `concat` needs expected callable type or same-expression inference evidence"
    ));

    let builtin_call = engine.handle_line("print()");
    assert!(!builtin_call.should_exit);
    assert!(rendered_text(&builtin_call).contains("print expects 1 argument(s), got 0"));

    let add_call = engine.handle_line("Add::add(False, True)");
    assert!(!add_call.should_exit);
    let add_text = rendered_text(&add_call);
    assert!(add_text.contains("No implementation satisfies Add for Boolean"));
}

fn core_generic_callable_capture_uses_site_signature_inside_nested_values() {
    let mut engine = engine();

    let rejected = rendered_text(&engine.handle_line("r: Result<Int, Error> = Ok(1)"));
    assert!(
        rejected.contains("Result<T, E> is only allowed in function return signatures"),
        "{rejected}"
    );
    let declaration =
        rendered_text(&engine.handle_line("def fetch() -> Result<Int, NoneError> { Ok(1) }"));
    assert!(!declaration.contains("Error:"), "{declaration}");
    let signature = signature_text(&engine.handle_line(":sig fetch"));
    assert!(signature.contains("Result<Int, NoneError>"), "{signature}");
    let captured = rendered_text(&engine.handle_line("fetcher: (-> Result<Int>) = &fetch"));
    assert!(captured.contains("sig: (-> Result<Int>)"), "{captured}");

    let result = rendered_text(&engine.handle_line("r = Ok(1)"));
    assert_eq!(result, "r: Result<Int> = Ok(1)");
    let nested = rendered_text(&engine.handle_line("nested = [Ok(1)]"));
    assert!(nested.contains("nested: List<Result<Int>>"), "{nested}");

    let generic = engine.handle_line("def keep(value: $A) -> $A { value }");
    assert!(!generic.should_exit);

    let inferred_capture = engine.handle_line("inferred_capture = keep(&Add::add(&1, 1))");
    let inferred_capture_text = rendered_text(&inferred_capture);
    assert!(
        inferred_capture_text.contains("FnCapture(module: Add, name: add, sig: (Int -> Int))"),
        "{inferred_capture_text}"
    );

    let identity_int = engine.handle_line("identity_int: (Int -> Int) = &id");
    let identity_int_text = rendered_text(&identity_int);
    assert!(
        identity_int_text.contains(
            "identity_int: (Int -> Int) = FnCapture(module: Function, name: id, sig: (Int -> Int))"
        ),
        "{identity_int_text}"
    );

    let identity_string = engine.handle_line("identity_string: (String -> String) = &id");
    let identity_string_text = rendered_text(&identity_string);
    assert!(
        identity_string_text.contains(
            "identity_string: (String -> String) = FnCapture(module: Function, name: id, sig: (String -> String))"
        ),
        "{identity_string_text}"
    );

    let identity_result = engine.handle_line("identity_result: Result<(Int -> Int)> = Ok(&id)");
    let identity_result_text = rendered_text(&identity_result);
    assert!(
        identity_result_text
            .contains("Ok(FnCapture(module: Function, name: id, sig: (Int -> Int)))"),
        "{identity_result_text}"
    );
}

fn core_facet_capture_identity_survives_bindings_and_nested_fields() {
    let mut engine = ReplEngine::from_script_source(
        "facet_capture.srt",
        "defrecord FacetReaderBox(read: (Duration -> Int))",
    )
    .expect("callable field declaration must preload");

    let view = "FnCapture(module: Facet, name: view, sig: (Duration -> Int))";
    for source in [
        "api = &Facet::view(Duration.millis, &1)",
        "direct = &Duration.millis",
        "path = Duration.millis",
        "bound = &path",
        "inferred: (Duration -> Int) = _.millis",
        "alias = api",
        "recaptured = &alias(&1)",
    ] {
        let text = rendered_text(&engine.handle_line(source));
        if source.starts_with("path =") {
            assert!(text.contains("Duration.millis"), "{text}");
        } else {
            assert!(text.ends_with(view), "{source}: {text}");
        }
    }
    for (source, expected) in [
        ("api", view.to_string()),
        (
            "readers = [api, direct, bound, inferred, recaptured]",
            format!("readers: List<(Duration -> Int)> = [{view}, {view}, {view}, {view}, {view}]"),
        ),
        (
            "pair = (api, recaptured)",
            format!("pair: ((Duration -> Int), (Duration -> Int)) = ({view}, {view})"),
        ),
        (
            "by_name = HashMap::map_from_entries([(\"read\", api)])",
            format!("by_name: HashMap<(Duration -> Int)> = hash![\"read\" => {view}]"),
        ),
        (
            "boxed = FacetReaderBox(recaptured)",
            format!("boxed: FacetReaderBox = FacetReaderBox(read: {view})"),
        ),
        ("boxed.read", view.to_string()),
        (
            "extracted = boxed.read",
            format!("extracted: (Duration -> Int) = {view}"),
        ),
        ("extracted(12ms)", "12".to_string()),
        (
            "wrapped: (Duration -> Int) = {|value| recaptured(value)}",
            "wrapped: (Duration -> Int) = Closure(Duration -> Int)".to_string(),
        ),
        (
            "wrapped_box = FacetReaderBox(wrapped)",
            "wrapped_box: FacetReaderBox = FacetReaderBox(read: Closure(Duration -> Int))"
                .to_string(),
        ),
    ] {
        assert_eq!(
            rendered_text(&engine.handle_line(source)),
            expected,
            "{source}"
        );
    }

    for (source, expected) in [
        ("read_at: (Int, List<Int> -> Result<Int>) = &Facet::view(List.[&1], &2)", "read_at: (Int, List<Int> -> Result<Int>) = FnCapture(module: Facet, name: view, sig: (Int, List<Int> -> Result<Int>))"),
        ("partial = &read_at(1, &1)", "partial: (List<Int> -> Result<Int>) = FnCapture(module: Facet, name: view, sig: (List<Int> -> Result<Int>))"),
        ("again = &partial(&1)", "again: (List<Int> -> Result<Int>) = FnCapture(module: Facet, name: view, sig: (List<Int> -> Result<Int>))"),
        ("nested = Ok(again)", "nested: Result<(List<Int> -> Result<Int>)> = Ok(FnCapture(module: Facet, name: view, sig: (List<Int> -> Result<Int>)))"),
        ("again([10, 20])", "Ok(20)"),
        ("put: ((Int, String), Int -> (Int, String)) = &Facet::put(Tuple._0, &1, &2)", "put: ((Int, String), Int -> (Int, String)) = FnCapture(module: Facet, name: put, sig: ((Int, String), Int -> (Int, String)))"),
        ("put_partial = &put(&1, 3)", "put_partial: ((Int, String) -> (Int, String)) = FnCapture(module: Facet, name: put, sig: ((Int, String) -> (Int, String)))"),
        ("put_again = &put_partial(&1)", "put_again: ((Int, String) -> (Int, String)) = FnCapture(module: Facet, name: put, sig: ((Int, String) -> (Int, String)))"),
        ("put_again((1, \"a\"))", "(3, \"a\")"),
    ] {
        assert_eq!(rendered_text(&engine.handle_line(source)), expected, "{source}");
    }
}

fn core_partial_capture_chains_preserve_capture_origin_until_a_closure_literal_appears() {
    let mut engine = engine();

    let def = engine.handle_line("def f(a: Int, b: Int, c: Int) -> Int { a + b + c }");
    assert!(!def.should_exit);

    let f3 = engine.handle_line("f3 = &f");
    let f3_text = rendered_text(&f3);
    assert!(f3_text.contains("FnCapture("), "{f3_text}");

    let f2 = engine.handle_line("f2 = &f3(&1, &2, 3)");
    let f2_text = rendered_text(&f2);
    assert!(f2_text.contains("FnCapture("), "{f2_text}");
    assert!(f2_text.contains("sig: (Int, Int -> Int)"), "{f2_text}");

    let f1 = engine.handle_line("f1 = &f2(&1, 2)");
    let f1_text = rendered_text(&f1);
    assert!(f1_text.contains("FnCapture("), "{f1_text}");
    assert!(f1_text.contains("sig: (Int -> Int)"), "{f1_text}");

    let applied = engine.handle_line("f1(10)");
    assert!(rendered_text(&applied).contains("15"));

    let g3 = engine.handle_line("g3 = {|a: Int, b: Int, c: Int| a + b + c}");
    let g3_text = rendered_text(&g3);
    assert!(
        g3_text.contains("Closure(Int, Int, Int -> Int)"),
        "{g3_text}"
    );

    let g2 = engine.handle_line("g2 = &g3(&1, &2, 3)");
    let g2_text = rendered_text(&g2);
    assert!(
        g2_text.contains("Closure(Int, Int -> Int)")
            || g2_text.contains("FnCapture(") && g2_text.contains("sig: (Int, Int -> Int)"),
        "{g2_text}"
    );

    let closure_wrapping_capture =
        engine.handle_line("wrapped_capture: (Int -> Int) = {|value: Int| f1(value)}");
    let closure_wrapping_capture_text = rendered_text(&closure_wrapping_capture);
    assert!(
        closure_wrapping_capture_text
            .contains("wrapped_capture: (Int -> Int) = Closure(Int -> Int)"),
        "{closure_wrapping_capture_text}"
    );

    let zero_arg_closure = engine.handle_line("zero_arg: (-> Int) = {|| f1(10)}");
    let zero_arg_closure_text = rendered_text(&zero_arg_closure);
    assert!(
        zero_arg_closure_text.contains("zero_arg: (-> Int) = Closure(-> Int)"),
        "{zero_arg_closure_text}"
    );
}

fn core_repl_displays_curry_callable_inside_result_without_internal_id() {
    let mut engine = engine();

    let pair = engine.handle_line("pair: (String -> (Int -> (String, Int))) = curry(&`(,)`)");
    let pair_text = rendered_text(&pair);
    assert!(
        pair_text.contains("= Closure(String -> (Int -> (String, Int)))"),
        "{pair_text}"
    );

    let result = engine.handle_line("p = Ok(pair)");
    let result_text = rendered_text(&result);
    assert!(
        result_text.contains("Ok(Closure(String -> (Int -> (String, Int))))"),
        "{result_text}"
    );
    assert!(!result_text.contains("<function:"), "{result_text}");

    let applied_once = engine.handle_line("p |*| Ok(\"hoge\")");
    let applied_once_text = rendered_text(&applied_once);
    assert!(
        applied_once_text.contains("Ok(Closure(Int -> (String, Int)))"),
        "{applied_once_text}"
    );
    assert!(
        !applied_once_text.contains("<function:"),
        "{applied_once_text}"
    );

    let applied_twice = engine.handle_line("p |*| Ok(\"hoge\") |*| Ok(1)");
    assert_eq!(rendered_text(&applied_twice), "Ok((\"hoge\", 1))");
}

fn core_duplicate_defs_and_runtime_result_errors_keep_the_session_alive() {
    let mut engine = engine();

    let first_def = engine.handle_line("def f() -> Int { 1 }");
    assert!(!first_def.should_exit);

    let duplicate = engine.handle_line("def f() -> Int { 2 }");
    assert!(!duplicate.should_exit);
    assert!(matches!(duplicate.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&duplicate).contains("Duplicate top-level definition: f"));

    let err_value = engine.handle_line("Err(NoneError())");
    assert!(!err_value.should_exit);
    assert!(matches!(err_value.output, ReplOutput::EvalError { .. }));
    assert!(rendered_text(&err_value).contains("None Value."));

    let still_alive = engine.handle_line("1");
    assert!(!still_alive.should_exit);
    assert!(rendered_text(&still_alive).contains("1"));
}

fn core_pattern_bindings_are_displayed_in_preorder() {
    let mut engine = engine();
    let result = engine.handle_line("(i, s) @ w = (1, 2)");
    let text = rendered_text(&result);

    let i = text.find("i: Int").expect("left binding should be shown");
    let s = text.find("s: Int").expect("right binding should be shown");
    let w = text
        .find("w: (Int, Int)")
        .expect("as binding should be shown");
    assert!(i < s && s < w, "unexpected binding order: {text}");
}

fn core_pattern_binding_order_defers_pattern_match_as_aliases() {
    let mut engine = engine();
    let result = engine.handle_line("(t1 @ t1a, (t2, t3) @ taila) @ r = (1, (2, 3))");
    let text = rendered_text(&result);

    let t1 = text.find("t1: Int").expect("t1 should be shown");
    let r = text
        .find("r: (Int, (Int, Int))")
        .expect("r should be shown");
    let t1a = text.find("t1a: Int").expect("t1a should be shown");
    let t2 = text.find("t2: Int").expect("t2 should be shown");
    let t3 = text.find("t3: Int").expect("t3 should be shown");
    let taila = text
        .find("taila: (Int, Int)")
        .expect("taila should be shown");
    assert!(
        t1 < r && r < t1a && t1a < t2 && t2 < t3 && t3 < taila,
        "unexpected binding order: {text}"
    );
}

fn core_pattern_binding_order_flattens_list_children_before_parent_alias() {
    let mut engine = engine();
    let result = engine.handle_line("[head, ..[middle, ..tail]] @ whole =? [1, 2, 3]");
    let text = rendered_text(&result);

    let head = text.find("head:").expect("head should be shown");
    let middle = text.find("middle:").expect("middle should be shown");
    let tail = text.find("tail:").expect("tail should be shown");
    let whole = text.find("whole:").expect("whole should be shown");
    assert!(
        head < middle && middle < tail && tail < whole,
        "unexpected binding order: {text}"
    );
}

fn core_duplicate_pattern_diagnostic_labels_are_limited_to_five() {
    let mut engine = engine();
    let result = engine.handle_line("(x, x, x, x, x, x) = (1, 2, 3, 4, 5, 6)");
    let text = rendered_text(&result);

    for label in ["first", "second", "third", "fourth", "fifth"] {
        assert!(
            text.contains(label),
            "missing diagnostic label {label}: {text}"
        );
    }
    assert!(
        !text.contains("sixth"),
        "diagnostic should stop at five: {text}"
    );
    assert_eq!(
        text.matches("Duplicate binding in pattern: x").count(),
        1,
        "duplicate message should remain the headline, not an LHS caption: {text}"
    );
}

fn core_save_writes_decodable_eldr_snapshot() {
    let mut engine = engine();
    let dir = tempfile_dir("xldr-repl-core-save");
    let path = dir.join("session.eldr");

    let bind = engine.handle_line("answer = 42");
    assert!(rendered_text(&bind).contains("answer: Int = 42"));

    let save = engine.handle_line(&format!(":save {}", path.display()));
    assert!(rendered_text(&save).contains("saved to"));

    let bytes = fs::read(&path).expect("saved .eldr should exist");
    let bytecode = sindr::ir::Bytecode::decode(&bytes).expect("saved .eldr should decode");
    assert!(!bytecode.opcodes.is_empty());
}

fn core_eldr_sig_queries_do_not_depend_on_docs_chunk() {
    let mut engine = engine();
    let dir = tempfile_dir("xldr-repl-core-eldr-sig-without-docs");
    let path = dir.join("session.eldr");

    let save = engine.handle_line(&format!(":save {}", path.display()));
    assert!(rendered_text(&save).contains("saved to"));

    let bytes = fs::read(&path).expect("saved .eldr should exist");
    let mut bytecode = sindr::ir::Bytecode::decode(&bytes).expect("saved .eldr should decode");
    bytecode.docs.clear();
    let bytes = bytecode.encode().expect("modified .eldr should encode");

    let mut restored = ReplEngine::from_eldr(&bytes).expect("restored engine should load");

    let doc = doc_text(&restored.handle_line(":doc Compare::compare"));
    assert!(
        doc.contains("undocumented") || doc.contains("No docs found"),
        "{doc}"
    );
    let sig = signature_text(&restored.handle_line(":sig Compare::compare"));
    assert!(
        sig.contains("Compare::compare(self: Self, rhs: Self) -> Ordering"),
        "{sig}"
    );
    let capture = restored.handle_line("after_load: (Int -> Int) = &Function::id");
    assert!(
        !matches!(capture.output, ReplOutput::EvalError { .. }),
        "{}",
        rendered_text(&capture)
    );
    let capture_doc = restored.handle_line(":doc after_load");
    assert!(
        !matches!(capture_doc.output, ReplOutput::DocResolved { .. }),
        "empty Docs chunk must not recover bootstrap body through capture"
    );
}

fn core_eldr_restore_reports_partial_semantic_restore_notice() {
    let mut engine = engine();
    let dir = tempfile_dir("xldr-repl-core-eldr-partial-restore");
    let path = dir.join("session.eldr");

    let save = engine.handle_line(&format!(":save {}", path.display()));
    assert!(rendered_text(&save).contains("saved to"));

    let bytes = fs::read(&path).expect("saved .eldr should exist");
    let mut restored = ReplEngine::from_eldr(&bytes).expect("restored engine should load");
    let startup = restored.take_startup_results();
    assert!(
        startup
            .iter()
            .any(|result| rendered_text(result).contains("compile semantic metadata")),
        "startup results should report partial semantic restore: {:?}",
        startup.iter().map(rendered_text).collect::<Vec<_>>()
    );
}

fn core_quit_command_sets_exit_without_ui_work() {
    let mut engine = engine();

    let result = engine.handle_line(":quit");
    assert!(result.should_exit);
    assert_eq!(status_text(&result), "quit");
}

fn core_dbg_docs_and_signatures_resolve_from_bootstrap_source() {
    let mut engine = engine();

    let binding = engine.handle_line("dbg = {|value: Int| value + 1}");
    assert!(
        matches!(binding.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&binding)
    );
    let call = engine.handle_line("dbg!(dbg(3))");
    assert!(
        matches!(call.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&call)
    );
    let stderr = strip_ansi(&call.stderr.join("\n"));
    assert!(stderr.contains("Int: 4"), "{stderr}");

    let doc = engine.handle_line(":doc dbg!");
    assert_eq!(doc_target(&doc).0, "Bootstrap::dbg!");

    let sig = engine.handle_line(":sig dbg!");
    let rendered = signature_text(&sig);
    assert!(
        rendered.contains("@intrinsic def dbg!(values: *$A) -> Unit"),
        "{rendered}"
    );
}

fn core_doc_reports_tuple_surface_undocumented_types_and_scope_aware_helpers() {
    let mut engine = engine();

    let tuple_doc = engine.handle_line(":doc Tuple");
    assert_eq!(doc_target(&tuple_doc).0, "Tuple");

    let tuple_sig = signature_text(&engine.handle_line(":sig Tuple"));
    assert!(
        tuple_sig.contains("(T1, T2, ..) : Tuple<T1, T2, ..>"),
        "{tuple_sig}"
    );

    let list_sig = signature_text(&engine.handle_line(":sig List"));
    assert!(list_sig.contains("[T1, ..] : List<T>"), "{list_sig}");

    let hash_map_sig = signature_text(&engine.handle_line(":sig HashMap"));
    assert!(
        hash_map_sig.contains("hash![String => V1, ..] : HashMap<V>"),
        "{hash_map_sig}"
    );

    let boolean_sig = signature_text(&engine.handle_line(":sig Boolean"));
    assert!(boolean_sig.contains("* Boolean::True"), "{boolean_sig}");
    assert!(boolean_sig.contains("* Boolean::False"), "{boolean_sig}");

    let result_sig = signature_text(&engine.handle_line(":sig Result"));
    assert!(result_sig.contains("* Result::Ok($T)"), "{result_sig}");
    assert!(result_sig.contains("* Result::Err(Error)"), "{result_sig}");

    let true_sig = signature_text(&engine.handle_line(":sig True"));
    assert!(
        true_sig.contains("Boolean::True() -> Boolean"),
        "{true_sig}"
    );

    let ok_sig = signature_text(&engine.handle_line(":sig Ok"));
    assert!(ok_sig.contains("Result::Ok($T) -> Result<$T>"), "{ok_sig}");

    let config_doc = engine.handle_line(":doc Config");
    let config_doc = doc_text(&config_doc);
    assert!(config_doc.contains("Config"), "{config_doc}");
    assert!(config_doc.contains("defstruct Config"), "{config_doc}");
    assert!(config_doc.contains("undocumented"), "{config_doc}");
    assert!(config_doc.contains("@doc"), "{config_doc}");

    let style_doc = engine.handle_line(":doc StyledDocStyle");
    assert_eq!(doc_target(&style_doc).0, "StyledDocStyle");

    let helper_before_import = engine.handle_line(":doc add");
    let helper_before_import = rendered_text(&helper_before_import);
    assert!(
        helper_before_import.contains("No docs found for add"),
        "{helper_before_import}"
    );

    let import_add = engine.handle_line("import Add::add");
    let import_add_text = rendered_text(&import_add);
    assert!(
        import_add_text.contains("Imported Add::add"),
        "{import_add_text}"
    );

    let helper_after_import = engine.handle_line(":doc add");
    assert_eq!(doc_target(&helper_after_import).0, "Add::add");

    let if_doc = engine.handle_line(":doc if");
    assert_eq!(doc_target(&if_doc).0, "Kernel::if");
}

fn core_doc_supports_qualified_inherent_impl_method_names() {
    let mut engine = engine();

    let doc = engine.handle_line(":doc Boolean::not");
    let doc = doc_text(&doc);
    assert!(doc.contains("Boolean::not"), "{doc}");
}

fn core_sig_guides_field_paths_to_info_or_facet() {
    let mut engine = engine();

    let pair = engine.handle_line("pair = (\"alice\", 2)");
    let pair_text = rendered_text(&pair);
    assert!(pair_text.contains("pair: (String, Int)"), "{pair_text}");

    let field_sig = engine.handle_line(":sig pair._1");
    let field_sig = rendered_text(&field_sig);
    assert!(
        field_sig.contains("Use `:info pair` or `:facet pair._1`"),
        "{field_sig}"
    );
}

fn core_inspects_facet_roots_and_private_paths_without_exposing_them_to_source() {
    let mut engine = ReplEngine::from_script_source(
        "tmp/user.srt",
        r#"
@readonly
defstruct User {
  private password: String,
  readonly age: Int,
  name: String
}

impl User {
  def new(password: String, age: Int, name: String) -> Self {
    User { password: password, age: age, name: name }
  }
}
"#,
    )
    .expect("script preload should bootstrap");

    let doc = doc_text(&engine.handle_line(":doc Facet.User"));
    assert!(doc.contains("Facet root for User"), "{doc}");

    let field_doc = rendered_text(&engine.handle_line(":doc User.password"));
    assert!(
        field_doc.contains("not a documentation target"),
        "{field_doc}"
    );

    let info = rendered_text(&engine.handle_line(":info User"));
    assert!(info.contains("facet root: public"), "{info}");
    assert!(info.contains("private readonly password: String"), "{info}");
    assert!(info.contains("public readonly  age"), "{info}");

    let facet = rendered_text(&engine.handle_line(":facet User.password"));
    assert!(facet.contains("full path: User.password"), "{facet}");
    assert!(facet.contains("policy: private"), "{facet}");
    assert!(
        facet.contains("availability in this REPL: unavailable (private path)"),
        "{facet}"
    );

    let source_completion = engine.completions("User.p", "User.p".len());
    assert!(
        source_completion
            .candidates
            .iter()
            .all(|candidate| candidate.label != "password"),
        "ordinary source completion must hide private fields: {:?}",
        source_completion.candidates
    );
    let inspection_completion = engine.completions(":facet User.p", ":facet User.p".len());
    let password = inspection_completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "password")
        .expect(":facet completion should expose inspectable private path");
    assert!(
        password
            .detail
            .as_deref()
            .is_some_and(|detail| detail.contains("private")),
        "private completion should be labelled: {password:?}"
    );
}

fn tempfile_dir(prefix: &str) -> std::path::PathBuf {
    let mut dir = std::env::temp_dir();
    dir.push(format!(
        "{prefix}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock should be after Unix epoch")
            .as_nanos()
    ));
    fs::create_dir_all(&dir).expect("temp dir should be created");
    dir
}

fn core_extractor_closure_keeps_capture_signature_and_identity_across_chunks() {
    let mut engine = engine();
    for source in [
        "limit = 10",
        "ext = *{|value: Int| MatchResult::Ok(value + limit)}",
        "limit = 20",
        "other = *{|value: Int| MatchResult::Ok(value + limit)}",
        "unrelated = {|value: Int| value * 2}",
        "selected = if(True, ext, other)",
    ] {
        let result = engine.handle_line(source);
        assert!(
            !matches!(
                result.output,
                ReplOutput::EvalError { .. } | ReplOutput::Diagnostic { .. }
            ),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    let signature = signature_text(&engine.handle_line(":sig ext"));
    assert!(
        signature.contains("ExtractorClosure<(Int -> MatchResult<Int>)>"),
        "{signature}"
    );
    for (source, expected) in [
        ("if_let(3, selected(value), value, 0)", "13"),
        ("if_let(3, other(value), value, 0)", "23"),
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(&result.output, ReplOutput::EvalSuccess { .. }),
            "{}",
            rendered_text(&result)
        );
        let actual = rendered_text(&result);
        assert!(actual.contains(expected), "{actual}");
    }
    let invalid = rendered_text(&engine.handle_line("ext(3)"));
    assert!(invalid.contains("ExtractorClosure"), "{invalid}");
    let after = rendered_text(&engine.handle_line("if_let(4, ext(value), value, 0)"));
    assert!(after.contains("14"), "{after}");
    let doc = engine.handle_line(":doc ExtractorClosure");
    let (symbol, signature) = doc_target(&doc);
    assert_eq!(symbol, "ExtractorClosure");
    assert_eq!(signature, Some("type ExtractorClosure<$Signature>"));
}

fn core_apply_pattern_keeps_projection_local_and_resolves_canonical_queries() {
    let mut engine = engine();
    for source in [
        "temporary = 99",
        "offset = 10",
        "ext = *{|value: Int| MatchResult::Ok(value + offset)}",
        "offset = 20",
        "projected = apply_pattern((2, 3), (temporary, ext(_1)))",
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    for (source, expected) in [
        ("projected", "Ok(13)"),
        ("temporary", "99"),
        ("3 |> apply_pattern(ext(_1))", "Ok(13)"),
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
        assert!(
            rendered_text(&result).contains(expected),
            "{}",
            rendered_text(&result)
        );
    }
    let bad = engine.handle_line("apply_pattern((1, 2), (_1, _1))");
    assert!(
        matches!(
            bad.output,
            ReplOutput::Diagnostic { .. } | ReplOutput::EvalError { .. }
        ),
        "{}",
        rendered_text(&bad)
    );
    let after = engine.handle_line("apply_pattern(4, ext(_1))");
    assert!(
        rendered_text(&after).contains("Ok(14)"),
        "{}",
        rendered_text(&after)
    );
    let signature = signature_text(&engine.handle_line(":sig apply_pattern"));
    assert!(
        signature.contains("$Pattern") && signature.contains("Result<$Return"),
        "{signature}"
    );
    let doc = engine.handle_line(":doc apply_pattern");
    let (symbol, signature) = doc_target(&doc);
    assert_eq!(symbol, "Kernel::apply_pattern");
    let signature = signature.expect("canonical consumer signature");
    assert!(
        signature.contains("$Pattern") && signature.contains("Result<$Return"),
        "{signature}"
    );
}

fn core_extractor_module_queries_and_from_result_work_across_chunks() {
    let mut engine = engine();
    let module = engine.handle_line(":doc Extractor");
    assert_eq!(doc_target(&module).0, "Extractor");
    let doc = engine.handle_line(":doc Extractor::from_result");
    let (symbol, signature) = doc_target(&doc);
    assert_eq!(symbol, "Extractor::from_result");
    let signature = signature.expect("standard function signature");
    assert!(
        signature.contains("Result<$B") && signature.contains("ExtractorClosure<"),
        "{signature}"
    );
    let query = signature_text(&engine.handle_line(":sig Extractor::from_result"));
    assert!(query.contains(signature), "{query}: {signature}");
    let created = engine.handle_line("converted = Extractor::from_result(&Int::parse)");
    assert!(
        matches!(created.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&created)
    );
    assert!(
        rendered_text(&created).contains(
            "converted: ExtractorClosure<(String -> MatchResult<Int>)> = ExtractorClosure<(String -> MatchResult<Int>)>"
        ),
        "{}",
        rendered_text(&created)
    );
    let display = "ExtractorClosure<(String -> MatchResult<Int>)>";
    assert_eq!(rendered_text(&engine.handle_line("converted")), display);
    assert_eq!(
        rendered_text(&engine.handle_line("[converted]")),
        format!("[{display}]")
    );
    let signature = signature_text(&engine.handle_line(":sig converted"));
    assert!(
        signature.contains("ExtractorClosure<(String -> MatchResult<Int>)>"),
        "{signature}"
    );
    let result = engine.handle_line("apply_pattern(\"42\", converted(_1: Int))");
    assert!(
        matches!(result.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&result)
    );
    assert!(
        rendered_text(&result).contains("Ok(42)"),
        "{}",
        rendered_text(&result)
    );
}

fn lazy_capture_requires_signature_at_repl_line_completion() {
    let mut engine = engine();
    let rejected = engine.handle_line("unknown = &if(True, &1, &2)");
    let diagnostic = rendered_text(&rejected);
    assert!(diagnostic.contains("concrete signature"), "{diagnostic}");
    let accepted = engine.handle_line("select: ((-> Int), (-> Int) -> Int) = &if(True, &1, &2)");
    assert!(
        !rendered_text(&accepted).contains("Error"),
        "{}",
        rendered_text(&accepted)
    );
    let value = engine.handle_line("select({|| 7}, {|| 0})");
    assert_eq!(rendered_text(&value), "7");
}

fn lazy_capture_guidance_survives_repl_alias_and_failed_line() {
    let mut engine = engine();
    for source in ["both = &and(&1, &2)", "alias = both", "reference = &alias"] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{}",
            rendered_text(&result)
        );
    }
    let rejected = engine.handle_line("reference(True, False)");
    let text = rendered_text(&rejected);
    assert!(
        text.contains("signature") && text.contains("(-> Boolean)") && text.contains("{ ||"),
        "{text}"
    );
    let accepted = engine.handle_line("reference(True, {|| False})");
    assert_eq!(rendered_text(&accepted), "False");

    let ordinary =
        engine.handle_line("def ordinary(a: Boolean, b: (-> Boolean)) -> Boolean { b() }");
    assert!(
        matches!(ordinary.output, ReplOutput::EvalSuccess { .. }),
        "{}",
        rendered_text(&ordinary)
    );
    let rejected = engine.handle_line("ordinary(True, False)");
    let text = rendered_text(&rejected);
    assert!(
        !text.contains("Lazy capture") && !text.contains("{ ||"),
        "{text}"
    );
}

#[test]
fn error_contract_surface_and_extractor_inspection_share_value_rendering() {
    let mut engine = ReplEngine::from_script_source(
        "error_contracts.srt",
        r#"impl Int {
  defextractor plain(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }
  defextractor detailed(value: Int) -> MatchResult<Int, Error> { MatchResult::Ok(value) }
}
deftrait ExtractorFactory<$A> {
  def make(self: Self, seed: $A) -> ExtractorClosure<($A -> MatchResult<$A>)>
}
impl ExtractorFactory<$A> for Unit {
  def make(self: Unit, seed: $A) -> ExtractorClosure<($A -> MatchResult<$A>)> {
    *{|value: $A| MatchResult::Ok(value)}
  }
}"#,
    )
    .expect("extractor definitions should preload");
    let short = "ExtractorClosure<(Int -> MatchResult<Int>)>";
    let bound = engine.handle_line("ext = *{|value: Int| MatchResult::Ok(value)}");
    assert_eq!(rendered_text(&bound), format!("ext: {short} = {short}"));
    for (source, expected) in [
        ("ext", short.to_string()),
        ("[ext]", format!("[{short}]")),
        ("inspect(ext)", format!("\"{short}\"")),
    ] {
        assert_eq!(
            rendered_text(&engine.handle_line(source)),
            expected,
            "{source}"
        );
    }
    let factory = engine.handle_line(
        "factory: ExtractorClosure<(Int -> MatchResult<Int>)> = ExtractorFactory::make((), 1)",
    );
    assert_eq!(
        rendered_text(&factory),
        format!("factory: {short} = {short}")
    );
    assert_eq!(rendered_text(&engine.handle_line("factory")), short);
    assert_eq!(
        rendered_text(&engine.handle_line("[factory]")),
        format!("[{short}]")
    );
    for source in [
        "def plain() -> Result<Int> { Ok(1) }",
        "def detailed() -> Result<Int, NoneError> { Ok(1) }",
    ] {
        let result = engine.handle_line(source);
        assert!(
            matches!(result.output, ReplOutput::EvalSuccess { .. }),
            "{source}: {}",
            rendered_text(&result)
        );
    }
    for (query, expected, forbidden) in [
        (":sig plain", "Result<Int>", "Result<Int, Error>"),
        (
            ":sig detailed",
            "Result<Int, NoneError>",
            "Result<Int, Error>",
        ),
        (
            ":sig Int::plain",
            "MatchResult<Int>",
            "MatchResult<Int, Error>",
        ),
        (":sig Int::detailed", "MatchResult<Int, Error>", "NoneError"),
    ] {
        let actual = signature_text(&engine.handle_line(query));
        assert!(actual.contains(expected), "{query}: {actual}");
        assert!(!actual.contains(forbidden), "{query}: {actual}");
    }
    let completion = engine.completions("detailed", "detailed".len());
    let detail = completion
        .candidates
        .iter()
        .find(|candidate| candidate.label == "detailed")
        .and_then(|candidate| candidate.detail.as_deref())
        .expect("function completion detail");
    assert!(detail.contains("Result<Int>"), "{detail}");
    assert!(!detail.contains("NoneError"), "{detail}");
    let call = engine.completions("detailed(", "detailed(".len());
    let help = call
        .signature
        .expect("function signature help")
        .lines
        .join("\n");
    assert!(help.contains("Result<Int>"), "{help}");
    assert!(!help.contains("NoneError"), "{help}");
    let query = "String::strip_prefix";
    let completion = engine.completions(query, query.len());
    let detail = completion
        .candidates
        .iter()
        .find(|candidate| candidate.replacement == query)
        .and_then(|candidate| candidate.detail.as_deref())
        .expect("standard function completion detail");
    assert!(detail.contains("Result<String>"), "{detail}");
    assert!(!detail.contains("NoneError"), "{detail}");
    let captured = rendered_text(&engine.handle_line("reader: (-> Result<Int>) = &detailed"));
    assert!(captured.contains("sig: (-> Result<Int>)"), "{captured}");
    assert!(!captured.contains("NoneError"), "{captured}");
    let rejected = rendered_text(&engine.handle_line("ret: Result<Int, NoneError> = Ok(1)"));
    assert!(
        rejected.contains("only allowed in function return signatures"),
        "{rejected}"
    );
}

fn core_callable_declaration_identity_survives_chunks() {
    let mut engine = engine();
    let declaration = engine.handle_line("def curry(value: Int) -> Int { value + 900 }");
    assert!(
        !matches!(declaration.output, ReplOutput::EvalError { .. }),
        "{}",
        visible_text(&declaration)
    );
    assert_eq!(rendered_text(&engine.handle_line("curry(99)")), "999");
    let bound = engine.handle_line("saved = &curry");
    assert!(
        !matches!(bound.output, ReplOutput::EvalError { .. }),
        "{}",
        visible_text(&bound)
    );
    assert_eq!(rendered_text(&engine.handle_line("saved(1)")), "901");

    engine.handle_line("def combine(a: Int, b: Int) -> Int { a + b }");
    assert_eq!(rendered_text(&engine.handle_line("2 `combine` 3")), "5");
    let bound = engine.handle_line("combine = {|a: Int, b: Int| a * b}");
    assert!(
        !matches!(bound.output, ReplOutput::EvalError { .. }),
        "{}",
        visible_text(&bound)
    );
    let rejected = engine.handle_line("2 `combine` 3");
    assert!(
        matches!(rejected.output, ReplOutput::EvalError { .. }),
        "{}",
        visible_text(&rejected)
    );
    assert_eq!(rendered_text(&engine.handle_line("combine(2, 3)")), "6");
}

fn core_generic_trait_forwarding_retains_substitutions_across_submissions() {
    for reversed in [false, true] {
        let mut engine = ReplEngine::from_script_source(
            "generic_extractor_preload.srt",
            "impl Int { defextractor relay(source: Result<$A>) -> MatchResult<$A> { value =? Monad::bind(source, {|x| Ok(x)}); MatchResult::Ok(value) } }",
        ).expect("named Extractor preload should typecheck");
        for declaration in [
            "def inner(source: Result<$A>, next: ($A -> Result<$B>)) -> Result<$B> { Monad::bind(source, next) }",
            "def outer(source: Result<$A>, next: ($A -> Result<$B>)) -> Result<$B> { inner(source, next) }",
            "def partial::<$B>(source: Result<$A>) -> (($A -> Result<$B>) -> Result<$B>) { &inner(source, &1) }",
        ] {
            let result = engine.handle_line(declaration);
            assert!(!matches!(result.output, ReplOutput::Diagnostic { .. } | ReplOutput::EvalError { .. }), "{}", rendered_text(&result));
        }
        let mut calls = [
            ("outer(Ok(7), {|x: Int| Ok(x + 1)})", "Ok(8)"),
            ("outer(Ok(7), {|x: Int| Ok(inspect(x))})", "Ok(\"7\")"),
            (
                "outer(Ok([1,2]), {|x: List<Int>| Ok((x, True))})",
                "Ok(([1, 2], True))",
            ),
            ("apply_pattern(Ok(7), Int::relay(_1))", "Ok(7)"),
            ("apply_pattern(Ok(\"x\"), Int::relay(_1))", "Ok(\"x\")"),
        ];
        if reversed {
            calls.reverse();
        }
        for (source, expected) in calls.into_iter().chain(calls) {
            let result = engine.handle_line(source);
            assert!(
                matches!(result.output, ReplOutput::EvalSuccess { .. }),
                "{}",
                rendered_text(&result)
            );
            assert_eq!(rendered_text(&result), expected);
        }
        let captured = engine.handle_line(
            "f: ((Int -> Result<String>) -> Result<String>) = partial::<String>(Ok(3))",
        );
        assert!(
            !matches!(
                captured.output,
                ReplOutput::Diagnostic { .. } | ReplOutput::EvalError { .. }
            ),
            "{}",
            rendered_text(&captured)
        );
        assert_eq!(
            rendered_text(&engine.handle_line("f({|x| Ok(inspect(x))})")),
            "Ok(\"3\")"
        );
    }
}
