#[cfg(test)]
use std::cell::Cell;
use std::cell::RefCell;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fs;
use std::panic;
use std::path::{Path, PathBuf};
use std::sync::{Arc, OnceLock};
use std::time::{Duration, Instant};

#[cfg(test)]
use std::sync::atomic::{AtomicUsize, Ordering};

use diagnostics::{DiagnosticSpec, SourceId, SourceRegistry};
use eldr::builtin::inspect_value;
use eldr::interactive::InteractiveChunkPolicy;
use eldr::value::{TypeKind, Value};
use scar::typed::{TypedInner, TypedNode, TypedPattern};
use scar::types::Ty;
use serde::{Deserialize, Serialize};
use sindr::builtin::builtin_function_metas;
use sindr::ir::{DocEntry, DocKind, SignatureEntry};
use sindr::names::SymbolCapabilities;
use sindr::policy::CompileUnitKind;
use spire::ast::{Ast, AstTy, ImportSpec, Span};

use super::command::{
    parse_repl_command, repl_command_help_lines, repl_command_spec_for_alias, repl_command_specs,
    repl_command_topic_help_lines, ReplCommand, ReplCommandArgCompletion, ReplCommandKind,
    ReplCommandSpec,
};
use super::output::{ReplOutput, ReplResult};
use super::preload::PreloadCompileMode;
use super::query::{
    format_query_ty, parse_binding_query_type, parse_repl_query, parse_signature_type,
    CommandQueryParseErrorReason, ReplQuery,
};
use super::{eval, render, session};

fn type_error_spec_from_scar(
    sources: &SourceRegistry,
    source_id: SourceId,
    error: &scar::error::TypeError,
    span: Span,
) -> DiagnosticSpec {
    error
        .structured
        .as_ref()
        .map(|diagnostic| {
            let diagnostic = diagnostic.clone().map_source_locations(|span| {
                crate::decode_rebased_module_span(span).unwrap_or_else(|| (source_id, span.clone()))
            });
            let source = sources
                .source(diagnostic.primary.source_id)
                .expect("compile diagnostic source");
            diagnostics::structured_compile_error_spec(source, &diagnostic)
        })
        .unwrap_or_else(|| {
            let (source_id, span) =
                crate::decode_rebased_module_span(&span).unwrap_or((source_id, span));
            diagnostics::typecheck_invariant_spec_with_display(
                source_id,
                span,
                error.message.clone(),
                error.hint.clone(),
            )
        })
}
use crate::error_display::StackTraceDisplayMode;
use crate::loader::{self, StagedModule};
use crate::ErrorDisplayMode;
use crate::{
    collect_additional_default_std_module_inputs, error_display, LoadError, ModuleStageParseError,
    ModuleStageParseErrorKind, SourceKind,
};

// Callable documentation belongs to the declaration that produced its code,
// including specializations materialized after that declaration was shadowed.
#[derive(Clone, Default)]
struct CallableDocSnapshots {
    functions: HashMap<(String, u32, u32), DocEntry>,
    trait_methods: HashMap<String, Option<DocEntry>>,
}

const XLDR_VERSION: &str = env!("CARGO_PKG_VERSION");
const OPERATOR_DOC_TARGETS: &[(&str, &str)] = &[
    ("+", "Add::add"),
    ("-", "Sub::sub"),
    ("*", "Mul::mul"),
    ("/", "Div::safe_div"),
    ("%", "Mod::safe_mod"),
    ("&&", "and"),
    ("||", "or"),
    ("==", "Eq::eq"),
    ("!=", "Eq::neq"),
    ("<", "Compare::lt"),
    ("<=", "Compare::lte"),
    (">", "Compare::gt"),
    (">=", "Compare::gte"),
    ("->", "Facet::compose"),
    ("++", "Concat::concat"),
    ("|>", "Bootstrap::|>"),
    ("|*>", "Functor::fmap"),
    ("|>=", "Monad::bind"),
    (">>", "Bootstrap::>>"),
    (">*", "Bootstrap::>*"),
    (">=>", "Bootstrap::>=>"),
];
const OPERATOR_DOC_TRAIT_ALIASES: &[(&str, &str)] = &[
    ("+", "Add"),
    ("-", "Sub"),
    ("*", "Mul"),
    ("/", "Div"),
    ("%", "Mod"),
    ("&&", "and"),
    ("||", "or"),
    ("==", "Eq"),
    ("!=", "Eq"),
    ("<", "Compare"),
    ("<=", "Compare"),
    (">", "Compare"),
    (">=", "Compare"),
    ("++", "Concat"),
    ("|*>", "Functor"),
    ("|>=", "Monad"),
];
const METHOD_DOC_TRAIT_ALIASES: &[(&str, &str)] = &[
    ("add", "Add"),
    ("sub", "Sub"),
    ("mul", "Mul"),
    ("safe_div", "Div"),
    ("safe_mod", "Mod"),
    ("eq", "Eq"),
    ("neq", "Eq"),
    ("compare", "Compare"),
    ("lt", "Compare"),
    ("lte", "Compare"),
    ("gt", "Compare"),
    ("gte", "Compare"),
    ("concat", "Concat"),
];
const COMPARE_METHOD_DOC_TARGETS: &[(&str, &str)] = &[
    ("compare", "Compare::compare"),
    ("lt", "Compare::lt"),
    ("lte", "Compare::lte"),
    ("gt", "Compare::gt"),
    ("gte", "Compare::gte"),
];
const REPL_UNRESOLVED_TYPE_MESSAGE: &str = "Cannot persist binding with unresolved type variable.";
const REPL_UNRESOLVED_TYPE_HINT: &str =
    "Add a type annotation or use the value in a context that determines the success type.";
const STAGE_PARSE_WORKER_STACK_SIZE: usize = 8 * 1024 * 1024;

#[cfg(test)]
static DEFAULT_REPL_BOOTSTRAP_BUILDS: AtomicUsize = AtomicUsize::new(0);

#[cfg(test)]
thread_local! {
    static TEST_REPL_RUNTIME_BOOT_CALLS: Cell<usize> = const { Cell::new(0) };
}

fn record_repl_runtime_boot_call() {
    #[cfg(test)]
    TEST_REPL_RUNTIME_BOOT_CALLS.with(|calls| calls.set(calls.get() + 1));
}

fn duration_to_nanos(elapsed: Duration) -> u64 {
    elapsed.as_nanos().min(u128::from(u64::MAX)) as u64
}

/// Error returned when loading a `.eldr` file into a REPL engine.
#[derive(Debug)]
pub enum EldrLoadError {
    /// Binary format error (bad magic, truncation, decode failure, etc.).
    Format(sindr::ir::BytecodeFormatError),
    /// Source / module loader error.
    Load(LoadError),
}

impl std::fmt::Display for EldrLoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EldrLoadError::Format(e) => write!(f, "eldr format error: {}", e),
            EldrLoadError::Load(e) => write!(f, "loader error: {}", e),
        }
    }
}

/// Error returned when preloading source files into a REPL engine.
#[derive(Debug, Clone)]
pub enum ReplLoadError {
    SourceReadFailed {
        file_name: String,
        message: String,
    },
    Diagnostic {
        phase: String,
        sources: SourceRegistry,
        source_id: SourceId,
        spec: DiagnosticSpec,
    },
    Load(LoadError),
    Runtime {
        file_name: String,
        message: String,
    },
}

impl std::fmt::Display for ReplLoadError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SourceReadFailed { file_name, message } => {
                write!(f, "cannot read {}: {}", file_name, message)
            }
            Self::Diagnostic { .. } => write!(f, "preload diagnostic"),
            Self::Load(error) => write!(f, "{}", error),
            Self::Runtime { file_name, message } => {
                write!(
                    f,
                    "runtime error while preloading {}: {}",
                    file_name, message
                )
            }
        }
    }
}

#[derive(Debug, Clone)]
struct PreparedScriptPreload {
    file_name: String,
    source_for_parse: String,
    include_modules: Vec<crate::ModuleInput>,
}

#[derive(Clone)]
struct ReplInput {
    source: String,
    // File-preload expressions have already been parsed and materialized.
    // Preserve them when replaying; live REPL input always uses None.
    ast: Option<Vec<Ast>>,
}

#[derive(Clone)]
struct PreloadedChunkState {
    sources: SourceRegistry,
    repl_source_id: SourceId,
    repl_module_path: String,
    module_stages: Vec<Vec<StagedModule>>,
    declaration_index: sigil::DeclarationIndex,
    sigil_session: sigil::SigilSession,
    scar_checkpoint: scar::ScarCheckpoint,
    vm: eldr::InteractiveVm,
    docs: Vec<DocEntry>,
    callable_doc_snapshots: CallableDocSnapshots,
    signatures: Vec<SignatureEntry>,
    process_metadata: BTreeMap<String, ReplProcessMetadata>,
    symbols: BTreeSet<String>,
    auto_import_modules: BTreeSet<String>,
    auto_import_records: Vec<ReplImportRecord>,
    script_runtime_inputs: Vec<ReplInput>,
    script_preload_docs: Vec<DocEntry>,
    script_preload_signatures: Vec<SignatureEntry>,
    import_records: Vec<ReplImportRecord>,
    def_records: Vec<ReplDefRecord>,
}

#[derive(Clone)]
struct DefaultReplBootstrapState {
    sources: SourceRegistry,
    repl_source_id: SourceId,
    repl_module_path: String,
    module_stages: Vec<Vec<StagedModule>>,
    declaration_index: sigil::DeclarationIndex,
    sigil_session: sigil::SigilSession,
    scar_checkpoint: scar::ScarCheckpoint,
    bytecode: forge::bytecode::Bytecode,
    vm_source_context: Option<(String, String)>,
    docs: Vec<DocEntry>,
    callable_doc_snapshots: CallableDocSnapshots,
    signatures: Vec<SignatureEntry>,
    process_metadata: BTreeMap<String, ReplProcessMetadata>,
    symbols: BTreeSet<String>,
    auto_import_modules: BTreeSet<String>,
    auto_import_records: Vec<ReplImportRecord>,
}

impl DefaultReplBootstrapState {
    fn from_preloaded(state: PreloadedChunkState) -> Self {
        Self {
            sources: state.sources,
            repl_source_id: state.repl_source_id,
            repl_module_path: state.repl_module_path,
            module_stages: state.module_stages,
            declaration_index: state.declaration_index,
            sigil_session: state.sigil_session,
            scar_checkpoint: state.scar_checkpoint,
            bytecode: state.vm.snapshot_bytecode(),
            vm_source_context: state
                .vm
                .source()
                .zip(state.vm.source_file())
                .map(|(source, file_name)| (source.to_string(), file_name.to_string())),
            docs: state.docs,
            callable_doc_snapshots: state.callable_doc_snapshots,
            signatures: state.signatures,
            process_metadata: state.process_metadata,
            symbols: state.symbols,
            auto_import_modules: state.auto_import_modules,
            auto_import_records: state.auto_import_records,
        }
    }

    fn instantiate(&self) -> Result<PreloadedChunkState, ReplLoadError> {
        let mut vm = match &self.vm_source_context {
            Some((source, file_name)) => session::bytecode_interactive_vm(self.bytecode.clone())
                .with_source(source.clone(), file_name.clone()),
            None => session::bytecode_interactive_vm(self.bytecode.clone()),
        };
        record_repl_runtime_boot_call();
        vm.boot_runtime().map_err(|error| ReplLoadError::Runtime {
            file_name: self
                .vm_source_context
                .as_ref()
                .map(|(_, file_name)| file_name.clone())
                .unwrap_or_else(|| "<stdlib>".to_string()),
            message: error.to_string(),
        })?;
        Ok(PreloadedChunkState {
            sources: self.sources.clone(),
            repl_source_id: self.repl_source_id,
            repl_module_path: self.repl_module_path.clone(),
            module_stages: self.module_stages.clone(),
            declaration_index: self.declaration_index.clone(),
            sigil_session: self.sigil_session.clone(),
            scar_checkpoint: self.scar_checkpoint.clone(),
            vm,
            docs: self.docs.clone(),
            callable_doc_snapshots: self.callable_doc_snapshots.clone(),
            signatures: self.signatures.clone(),
            process_metadata: self.process_metadata.clone(),
            symbols: self.symbols.clone(),
            auto_import_modules: self.auto_import_modules.clone(),
            auto_import_records: self.auto_import_records.clone(),
            script_runtime_inputs: Vec::new(),
            script_preload_docs: Vec::new(),
            script_preload_signatures: Vec::new(),
            import_records: Vec::new(),
            def_records: Vec::new(),
        })
    }
}

/// Check the compiler-visible identities whose stable indices are restored
/// from the default stdlib snapshot. Function PCs and implementation opcodes
/// are intentionally excluded because a normal build and an interactive save
/// lay out top-level code differently; calls from new chunks use the validated
/// function/type/template/process indices instead.
fn bytecode_has_compatible_stdlib_prefix(
    actual: &forge::bytecode::Bytecode,
    expected: &forge::bytecode::Bytecode,
) -> bool {
    let functions_match = actual.functions.len() >= expected.functions.len()
        && actual
            .functions
            .iter()
            .zip(&expected.functions)
            .all(|(actual, expected)| {
                actual.fun_idx == expected.fun_idx
                    && actual.arity == expected.arity
                    && actual.qualified_name == expected.qualified_name
                    && actual.signature == expected.signature
                    && actual.flags == expected.flags
            });
    let actual_boot = &actual.runtime_boot_plan;
    let expected_boot = &expected.runtime_boot_plan;

    functions_match
        && actual.num_locals >= expected.num_locals
        && actual
            .type_registry
            .entries()
            .starts_with(expected.type_registry.entries())
        && actual
            .callable_templates
            .starts_with(&expected.callable_templates)
        && actual
            .runtime_process_specs
            .entries
            .starts_with(&expected.runtime_process_specs.entries)
        && actual_boot.root == expected_boot.root
        && actual_boot.runtime_limits == expected_boot.runtime_limits
        && actual_boot
            .singletons
            .starts_with(&expected_boot.singletons)
        && actual_boot
            .standard_overrides
            .starts_with(&expected_boot.standard_overrides)
        && actual_boot
            .handler_overrides
            .starts_with(&expected_boot.handler_overrides)
        && actual_boot
            .supervisor_overrides
            .starts_with(&expected_boot.supervisor_overrides)
}

fn default_repl_bootstrap_state() -> Result<Arc<DefaultReplBootstrapState>, ReplLoadError> {
    static STATE: OnceLock<Result<Arc<DefaultReplBootstrapState>, ReplLoadError>> = OnceLock::new();
    STATE
        .get_or_init(|| {
            #[cfg(test)]
            DEFAULT_REPL_BOOTSTRAP_BUILDS.fetch_add(1, Ordering::Relaxed);

            compile_default_repl_bootstrap_chunk()
                .map(DefaultReplBootstrapState::from_preloaded)
                .map(Arc::new)
        })
        .clone()
}

fn repl_load_error_into_load_error(error: ReplLoadError) -> LoadError {
    match error {
        ReplLoadError::SourceReadFailed { file_name, message } => {
            LoadError::SourceReadFailed { file_name, message }
        }
        ReplLoadError::Diagnostic {
            phase,
            sources,
            source_id,
            spec,
        } => LoadError::BootstrapFailed {
            phase,
            file_name: sources
                .file_name(source_id)
                .unwrap_or("<stdlib>")
                .to_string(),
            message: spec.message,
        },
        ReplLoadError::Load(error) => error,
        ReplLoadError::Runtime { file_name, message } => LoadError::BootstrapFailed {
            phase: "runtime".to_string(),
            file_name,
            message,
        },
    }
}

#[derive(Debug, Clone, PartialEq)]
struct ReplProcessMetadata {
    kind: spire::ast::ProcessKind,
    instance: spire::ast::ProcessInstance,
    handler_specs: Vec<spire::ast::ProcessRuntimeHandlerSpec>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReplTypeDisplayCategory {
    Type,
    Struct,
    Record,
    Enum,
    Closure,
    Capture,
    FacetPath,
}

impl ReplTypeDisplayCategory {
    fn identity_label(self) -> &'static str {
        match self {
            Self::Type => "TypeIdentity::Type",
            Self::Struct => "TypeIdentity::Struct",
            Self::Record => "TypeIdentity::Record",
            Self::Enum => "TypeIdentity::Enum",
            Self::Closure => "TypeIdentity::Closure",
            Self::Capture => "TypeIdentity::Capture",
            Self::FacetPath => "TypeIdentity::FacetPath",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReplSessionPhase {
    Preload,
    Live,
}

impl ReplSessionPhase {
    fn execution_policy(self) -> InteractiveChunkPolicy {
        match self {
            Self::Preload => InteractiveChunkPolicy::Preload,
            Self::Live => InteractiveChunkPolicy::ReplAppendOnly,
        }
    }
}

#[derive(Debug, Clone, Default)]
enum ReplReloadSeed {
    #[default]
    Empty,
    ProjectModuleStages(Vec<Vec<crate::ModuleInput>>),
    Sources {
        module: Option<(String, String)>,
        script: Option<(String, String)>,
    },
}

#[derive(Debug, Clone)]
struct ReplHistoryEntry {
    line: usize,
    source: String,
}

#[derive(Debug, Clone)]
struct ReplBindingRecord {
    line: usize,
    name: String,
    ty: String,
}

#[derive(Debug, Clone)]
struct ReplImportRecord {
    line: usize,
    src: String,
    item: String,
    via: String,
}

#[derive(Debug, Clone)]
struct ReplDefRecord {
    line: usize,
    name: String,
    arity: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReplCompletionKind {
    Variable,
    TypeConstructor,
    TypePath,
    FunctionCall,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplCompletionCandidate {
    pub label: String,
    pub replacement: String,
    pub kind: ReplCompletionKind,
    pub detail: Option<String>,
    pub documentation: Option<String>,
    pub replace_start: usize,
    pub replace_end: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReplSignatureHelp {
    pub lines: Vec<String>,
    pub active_parameter: Option<usize>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct CompletionTelemetry {
    pub input_event_to_ui_handler_ns: Option<u64>,
    pub completion_queue_ns: Option<u64>,
    pub completion_compute_ns: Option<u64>,
    pub completion_apply_ns: Option<u64>,
    pub completion_render_ns: Option<u64>,
    pub total_key_to_visible_response_ns: Option<u64>,
}

impl CompletionTelemetry {
    pub fn record_input_event_to_ui_handler(&mut self, elapsed: Duration) {
        self.input_event_to_ui_handler_ns = Some(duration_to_nanos(elapsed));
    }

    pub fn record_completion_compute(&mut self, elapsed: Duration) {
        self.completion_compute_ns = Some(duration_to_nanos(elapsed));
    }

    pub fn record_completion_queue(&mut self, elapsed: Duration) {
        self.completion_queue_ns = Some(duration_to_nanos(elapsed));
    }

    pub fn record_completion_apply(&mut self, elapsed: Duration) {
        self.completion_apply_ns = Some(duration_to_nanos(elapsed));
    }

    pub fn record_completion_render(&mut self, elapsed: Duration) {
        self.completion_render_ns = Some(duration_to_nanos(elapsed));
    }

    pub fn record_total_key_to_visible_response(&mut self, elapsed: Duration) {
        self.total_key_to_visible_response_ns = Some(duration_to_nanos(elapsed));
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ReplCompletion {
    pub candidates: Vec<ReplCompletionCandidate>,
    pub signature: Option<ReplSignatureHelp>,
    pub telemetry: CompletionTelemetry,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ReplCompletionContext {
    input_support: surtr_analysis::ReplInputSupportContext,
}

impl ReplCompletionContext {
    pub fn completions(&self, input: &str, cursor: usize) -> ReplCompletion {
        let started = Instant::now();
        let use_site = surtr_analysis::repl_completion_use_site(input, cursor);
        let (candidates, signature) =
            if matches!(use_site, surtr_analysis::ReplCompletionUseSite::CommandHead) {
                (
                    Self::command_head_completion_candidates(input, cursor),
                    None,
                )
            } else {
                let support = self.input_support.input_support(input, cursor, use_site);
                let candidates = support
                    .candidates
                    .into_iter()
                    .map(ReplEngine::repl_completion_candidate_from_analysis)
                    .collect::<Vec<_>>();
                let signature = support.signature.map(|signature| ReplSignatureHelp {
                    lines: signature
                        .lines
                        .into_iter()
                        .map(|line| surtr_analysis::query::format_completion_signature(&line))
                        .collect(),
                    active_parameter: signature.active_parameter,
                });
                (candidates, signature)
            };
        let mut telemetry = CompletionTelemetry::default();
        telemetry.record_completion_compute(started.elapsed());
        ReplCompletion {
            candidates,
            signature,
            telemetry,
        }
    }

    pub fn should_request(input: &str, cursor: usize) -> bool {
        surtr_analysis::ReplInputSupportContext::should_request(input, cursor)
    }

    fn command_head_completion_candidates(
        input: &str,
        cursor: usize,
    ) -> Vec<ReplCompletionCandidate> {
        if !completion_allowed_at_cursor(input, cursor) {
            return Vec::new();
        }
        let (replace_start, replace_end, prefix) = completion_token(input, cursor);
        let mut candidates = Vec::new();
        for spec in repl_command_specs() {
            for alias in spec.aliases {
                let label = format!(":{alias}");
                if !label.starts_with(&prefix) {
                    continue;
                }
                candidates.push(ReplCompletionCandidate {
                    label: label.clone(),
                    replacement: label,
                    kind: ReplCompletionKind::FunctionCall,
                    detail: Some(spec.completion_detail()),
                    documentation: None,
                    replace_start,
                    replace_end,
                });
            }
        }
        candidates
    }

    #[cfg(test)]
    pub(crate) fn insert_callable_signature_for_test(
        &mut self,
        label: &str,
        qualified_name: &str,
        signature: &str,
    ) {
        self.input_support
            .apply_update(surtr_analysis::ReplInputSupportUpdate {
                symbols: Vec::new(),
                callable_signatures: vec![surtr_analysis::CallableSignature {
                    label: label.to_string(),
                    qualified_name: qualified_name.to_string(),
                    signature: signature.to_string(),
                }],
            });
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct FacetCompletionAssist {
    candidates: Vec<ReplCompletionCandidate>,
    signature: ReplSignatureHelp,
}

#[derive(Debug, Clone, PartialEq)]
struct FacetStep {
    ty: AstTy,
    fallible: bool,
    variant: bool,
}

#[derive(Debug, Clone)]
struct ReplCommandArgContext<'a> {
    spec: ReplCommandSpec,
    arg_start: usize,
    cursor: usize,
    args_before_cursor: &'a str,
}

pub struct ReplEngine {
    sources: SourceRegistry,
    module_stages: Vec<Vec<StagedModule>>,
    declaration_index: sigil::DeclarationIndex,
    repl_source_id: SourceId,
    repl_module_path: String,
    sigil_session: sigil::SigilSession,
    scar_session: scar::ScarSession,
    forge_session: forge::ForgeSession,
    vm: eldr::InteractiveVm,
    pending: String,
    next_line: usize,
    results: Vec<Option<Value>>,
    result_metas: Vec<Option<forge::ChunkMeta>>,
    symbols: BTreeSet<String>,
    docs: Vec<DocEntry>,
    callable_doc_snapshots: CallableDocSnapshots,
    signatures: Vec<SignatureEntry>,
    process_metadata: BTreeMap<String, ReplProcessMetadata>,
    auto_import_modules: BTreeSet<String>,
    auto_import_records: Vec<ReplImportRecord>,
    reload_seed: ReplReloadSeed,
    replay_inputs: Vec<ReplInput>,
    history_entries: Vec<ReplHistoryEntry>,
    binding_records: Vec<ReplBindingRecord>,
    import_records: Vec<ReplImportRecord>,
    def_records: Vec<ReplDefRecord>,
    completion_context_cache: RefCell<Option<ReplCompletionContext>>,
    #[cfg(test)]
    completion_context_builds: Cell<usize>,
    startup_results: Vec<ReplResult>,
    error_display_mode: ErrorDisplayMode,
    stack_trace_display_mode: StackTraceDisplayMode,
}

fn repl_source_span_fits(source_id: SourceId, source_len: usize) -> bool {
    source_len < sindr::ir::MODULE_SPAN_STRIDE
        && crate::module_span_base_for_source(source_id)
            .checked_add(source_len)
            .is_some_and(|end| end <= u32::MAX as usize)
}

fn runtime_source_entries(
    sources: &SourceRegistry,
    repl_source_id: SourceId,
) -> Vec<sindr::ir::SourceFileEntry> {
    sources
        .entries()
        .iter()
        .filter(|entry| entry.id != repl_source_id)
        .map(|entry| sindr::ir::SourceFileEntry {
            source_id: entry.id.0,
            path: entry.file_name.clone(),
            normalized_path: Some(entry.file_name.clone()),
            content_hash: Some(sindr::ir::stable_hash_hex(&entry.source)),
            text: Some(entry.source.clone()),
        })
        .collect()
}

fn register_runtime_sources(
    vm: &mut eldr::InteractiveVm,
    sources: &SourceRegistry,
    repl_source_id: SourceId,
) -> Result<(), eldr::RuntimeError> {
    for entry in sources
        .entries()
        .iter()
        .filter(|entry| entry.id != repl_source_id)
    {
        if let Some(existing) = vm
            .bytecode()
            .sources
            .iter()
            .find(|source| source.source_id == entry.id.0)
        {
            if existing
                .normalized_path
                .as_deref()
                .unwrap_or(&existing.path)
                != entry.file_name
            {
                return Err(eldr::RuntimeError::new(format!(
                    "Source ID {} already belongs to another file",
                    entry.id.0
                )));
            }
            // A loaded image owns its existing sources, including intentionally omitted text.
            continue;
        }
        vm.register_source(sindr::ir::SourceFileEntry {
            source_id: entry.id.0,
            path: entry.file_name.clone(),
            normalized_path: Some(entry.file_name.clone()),
            content_hash: Some(sindr::ir::stable_hash_hex(&entry.source)),
            text: Some(entry.source.clone()),
        })?;
    }
    Ok(())
}

impl ReplEngine {
    fn execute_vm_chunk(
        &mut self,
        chunk: sindr::ir::BytecodeChunk,
        phase: ReplSessionPhase,
    ) -> Result<eldr::interactive::ChunkExecution, eldr::RuntimeError> {
        register_runtime_sources(&mut self.vm, &self.sources, self.repl_source_id)?;
        self.vm.push_chunk(chunk, phase.execution_policy())
    }

    pub fn new() -> Result<Self, LoadError> {
        let state = default_repl_bootstrap_state().map_err(repl_load_error_into_load_error)?;
        let preloaded = state
            .instantiate()
            .map_err(repl_load_error_into_load_error)?;
        Self::from_preloaded_state(preloaded).map_err(repl_load_error_into_load_error)
    }

    /// Initialise a REPL engine from an existing `.eldr` bytecode payload.
    ///
    /// The VM is seeded with the compiled bytecode from the file, so all
    /// function definitions in the image are already resident.  Standard-
    /// library sigil / scar context is restored from the shared default
    /// bootstrap state (no source recompilation or re-execution needed) so that
    /// new REPL chunks can reference stdlib symbols.
    ///
    /// Limitation: user-defined functions in the `.eldr` that are beyond the
    /// standard library are present in the VM but are not visible to sigil name
    /// resolution.  New REPL input that calls them will therefore fail to
    /// resolve.  Full restoration requires the compile-time type context, which
    /// will be addressed when `--debug=full` span / type metadata is added.
    pub fn from_eldr(bytes: &[u8]) -> Result<Self, EldrLoadError> {
        let bytecode = sindr::ir::Bytecode::decode(bytes).map_err(EldrLoadError::Format)?;

        let std_module_inputs =
            collect_additional_default_std_module_inputs().map_err(EldrLoadError::Load)?;
        let mut repl_sources =
            loader::collect_repl_sources_with_module_stages(&[std_module_inputs])
                .map_err(EldrLoadError::Load)?;

        let mut sources = SourceRegistry::new();
        for entry in repl_sources
            .sources
            .entries()
            .iter()
            .filter(|entry| entry.id != repl_sources.repl_source_id)
        {
            assert!(sources.restore(entry.clone()), "unique compiler source IDs");
        }
        if let Some(last_id) = bytecode.sources.iter().map(|source| source.source_id).max() {
            sources.reserve_ids_before(last_id.checked_add(1).ok_or_else(|| {
                EldrLoadError::Load(LoadError::BootstrapFailed {
                    phase: "source registration".into(),
                    file_name: "<eldr>".into(),
                    message: "loaded source ID overflow".into(),
                })
            })?);
        }
        for source in &bytecode.sources {
            if let Some(text) = &source.text {
                let file = source.normalized_path.as_deref().unwrap_or(&source.path);
                let id = SourceId(source.source_id);
                if let Some(existing) = sources.get(id) {
                    if existing.file_name != file {
                        return Err(EldrLoadError::Load(LoadError::ConflictingSource {
                            file_name: file.into(),
                        }));
                    }
                    sources.update_source(id, text.clone());
                } else if !sources.restore(diagnostics::SourceEntry {
                    id,
                    file_name: file.into(),
                    source: text.clone(),
                }) {
                    return Err(EldrLoadError::Load(LoadError::ConflictingSource {
                        file_name: file.into(),
                    }));
                }
            }
        }
        repl_sources.repl_source_id = sources.register("REPL", "");
        repl_sources.sources = sources;

        let docs = bytecode.docs.clone();
        let signatures = bytecode.signatures.clone();
        let forge_session = forge::ForgeSession::from_bytecode(&bytecode);
        let vm = session::bytecode_interactive_vm(bytecode);

        // Populate completion symbols from the pre-loaded function table.
        let mut symbols: BTreeSet<String> = sindr::names::SPECIAL_ENUM_VARIANT_METAS
            .iter()
            .map(|meta| meta.bare_alias.to_string())
            .chain(
                builtin_function_metas()
                    .iter()
                    .map(|meta| meta.name.to_string()),
            )
            .collect();
        for entry in vm.bytecode().functions.iter() {
            if let Some(name) = &entry.qualified_name {
                let surface_name = crate::surface_rendered_name(name);
                symbols.insert(surface_name.clone());
                if let Some(short) = surface_name.rsplit("::").next() {
                    symbols.insert(short.to_string());
                }
            }
        }
        for entry in vm.bytecode().type_registry.entries().iter() {
            let surface_name = crate::surface_rendered_name(&entry.name);
            symbols.insert(surface_name.clone());
            if let Some(short) = surface_name.rsplit("::").next() {
                symbols.insert(short.to_string());
            }
        }

        let bootstrap_state = default_repl_bootstrap_state()
            .map_err(repl_load_error_into_load_error)
            .map_err(EldrLoadError::Load)?;
        let callable_doc_snapshots = CallableDocSnapshots {
            functions: bootstrap_state
                .callable_doc_snapshots
                .functions
                .iter()
                .filter(|(_, snapshot)| docs.iter().any(|entry| entry == *snapshot))
                .map(|(key, snapshot)| (key.clone(), snapshot.clone()))
                .collect(),
            trait_methods: bootstrap_state
                .callable_doc_snapshots
                .trait_methods
                .iter()
                .map(|(key, snapshot)| {
                    (
                        key.clone(),
                        snapshot
                            .as_ref()
                            .filter(|snapshot| docs.iter().any(|entry| entry == *snapshot))
                            .cloned(),
                    )
                })
                .collect(),
        };
        let mut engine = Self {
            sources: repl_sources.sources,
            module_stages: repl_sources.module_stages,
            declaration_index: Default::default(),
            repl_source_id: repl_sources.repl_source_id,
            repl_module_path: repl_sources.repl_module_path.clone(),
            sigil_session: bootstrap_state.sigil_session.clone(),
            scar_session: scar::ScarSession::new(),
            forge_session,
            vm,
            pending: String::new(),
            next_line: 1,
            results: Vec::new(),
            result_metas: Vec::new(),
            symbols,
            docs,
            callable_doc_snapshots,
            signatures,
            process_metadata: BTreeMap::new(),
            auto_import_modules: BTreeSet::new(),
            auto_import_records: Vec::new(),
            reload_seed: ReplReloadSeed::Empty,
            replay_inputs: Vec::new(),
            history_entries: Vec::new(),
            binding_records: Vec::new(),
            import_records: Vec::new(),
            def_records: Vec::new(),
            completion_context_cache: RefCell::new(None),
            #[cfg(test)]
            completion_context_builds: Cell::new(0),
            startup_results: vec![Self::eldr_partial_semantic_restore_notice()],
            error_display_mode: ErrorDisplayMode::Full,
            stack_trace_display_mode: StackTraceDisplayMode::Off,
        };
        // Set up sigil / scar scope for stdlib without re-executing bytecode.
        engine
            .restore_stdlib_scope_from_bootstrap()
            .map_err(EldrLoadError::Load)?;
        Ok(engine)
    }

    pub fn from_script_file(path: &str) -> Result<Self, ReplLoadError> {
        Self::from_preload_files(None, Some(path))
    }

    pub fn from_module_file(path: &str) -> Result<Self, ReplLoadError> {
        Self::from_preload_files(Some(path), None)
    }

    pub fn from_script_source(file_name: &str, source: &str) -> Result<Self, ReplLoadError> {
        Self::from_preload_sources(None, Some((file_name, source)))
    }

    pub fn from_module_source(file_name: &str, source: &str) -> Result<Self, ReplLoadError> {
        Self::from_preload_sources(Some((file_name, source)), None)
    }

    pub fn from_project_module_stages(
        module_input_stages: &[Vec<crate::ModuleInput>],
    ) -> Result<Self, ReplLoadError> {
        let state = compile_project_repl_chunk(module_input_stages)?;
        let mut engine = Self::from_preloaded_state(state)?;
        engine.reload_seed = ReplReloadSeed::ProjectModuleStages(module_input_stages.to_vec());
        Ok(engine)
    }

    pub fn from_project_runner_source(
        input: surtr_analysis::ProjectRunnerSourceInput,
    ) -> Result<Self, ReplLoadError> {
        let project_file = input.project_file.to_string_lossy().into_owned();
        let module_input_stages =
            crate::project_runner_module_input_stages(input).map_err(|error| {
                ReplLoadError::Runtime {
                    file_name: project_file,
                    message: error.to_string(),
                }
            })?;
        Self::from_project_module_stages(&module_input_stages)
    }

    pub fn from_project_runner_file(
        path: &str,
        profile: Option<&str>,
    ) -> Result<Self, ReplLoadError> {
        let selected_profile = profile.unwrap_or("main").to_string();
        let source = fs::read_to_string(path).map_err(|e| ReplLoadError::SourceReadFailed {
            file_name: path.to_string(),
            message: e.to_string(),
        })?;
        Self::from_project_runner_source(surtr_analysis::ProjectRunnerSourceInput {
            project_file: path.into(),
            selected_profile: selected_profile.clone(),
            normalized_args: vec![("profile".to_string(), selected_profile)],
            active_file: None,
            source,
        })
    }

    pub fn from_preload_files(
        module_path: Option<&str>,
        script_path: Option<&str>,
    ) -> Result<Self, ReplLoadError> {
        let module_source = match module_path {
            Some(path) => Some((
                path,
                fs::read_to_string(path).map_err(|e| ReplLoadError::SourceReadFailed {
                    file_name: path.to_string(),
                    message: e.to_string(),
                })?,
            )),
            None => None,
        };
        let script_source = match script_path {
            Some(path) => Some((
                path,
                fs::read_to_string(path).map_err(|e| ReplLoadError::SourceReadFailed {
                    file_name: path.to_string(),
                    message: e.to_string(),
                })?,
            )),
            None => None,
        };

        Self::from_preload_sources(
            module_source
                .as_ref()
                .map(|(path, source)| (*path, source.as_str())),
            script_source
                .as_ref()
                .map(|(path, source)| (*path, source.as_str())),
        )
    }

    pub fn from_preload_sources(
        module: Option<(&str, &str)>,
        script: Option<(&str, &str)>,
    ) -> Result<Self, ReplLoadError> {
        let state = compile_preloaded_repl_chunk(module, script)?;
        let mut engine = Self::from_preloaded_state(state)?;
        engine.reload_seed = ReplReloadSeed::Sources {
            module: module.map(|(file_name, source)| (file_name.to_string(), source.to_string())),
            script: script.map(|(file_name, source)| (file_name.to_string(), source.to_string())),
        };
        Ok(engine)
    }

    fn from_preloaded_state(state: PreloadedChunkState) -> Result<Self, ReplLoadError> {
        let forge_session = forge::ForgeSession::from_bytecode(&state.vm.snapshot_bytecode());

        Ok(Self {
            sources: state.sources,
            module_stages: state.module_stages,
            declaration_index: state.declaration_index,
            repl_source_id: state.repl_source_id,
            repl_module_path: state.repl_module_path.clone(),
            sigil_session: state.sigil_session,
            scar_session: {
                let mut session = scar::ScarSession::new();
                session.rollback(state.scar_checkpoint);
                session
            },
            forge_session,
            vm: state.vm,
            pending: String::new(),
            next_line: 1,
            results: Vec::new(),
            result_metas: Vec::new(),
            symbols: state.symbols,
            docs: state.docs,
            callable_doc_snapshots: state.callable_doc_snapshots,
            signatures: state.signatures,
            process_metadata: state.process_metadata,
            auto_import_modules: state.auto_import_modules,
            auto_import_records: state.auto_import_records,
            reload_seed: ReplReloadSeed::Empty,
            replay_inputs: Vec::new(),
            history_entries: Vec::new(),
            binding_records: Vec::new(),
            import_records: state.import_records.clone(),
            def_records: state.def_records.clone(),
            completion_context_cache: RefCell::new(None),
            #[cfg(test)]
            completion_context_builds: Cell::new(0),
            startup_results: Vec::new(),
            error_display_mode: ErrorDisplayMode::Full,
            stack_trace_display_mode: StackTraceDisplayMode::Off,
        })
        .map(|mut engine| {
            engine.append_docs(state.script_preload_docs.clone());
            engine.append_signatures(state.script_preload_signatures.clone());
            engine.sync_scar_fun_index_with_vm();
            engine
        })
        .and_then(|mut engine| {
            let script_runtime_inputs = state.script_runtime_inputs;
            for input in script_runtime_inputs {
                let result = engine.handle_line_with_ast(&input.source, input.ast);
                if result.should_exit {
                    return Err(ReplLoadError::Runtime {
                        file_name: "<repl-preload>".to_string(),
                        message: "preloaded script requested REPL exit".to_string(),
                    });
                }
                match result.output {
                    ReplOutput::EvalSuccess { .. }
                    | ReplOutput::PlainText { .. }
                    | ReplOutput::StyledDoc { .. }
                    | ReplOutput::StatusMessage(_) => {
                        engine.startup_results.push(result);
                    }
                    ReplOutput::EvalError { rendered, .. } => {
                        return Err(ReplLoadError::Runtime {
                            file_name: "<repl-preload>".to_string(),
                            message: rendered.join("\n"),
                        });
                    }
                    ReplOutput::Diagnostic {
                        rendered,
                        summary_tail,
                    } => {
                        return Err(ReplLoadError::Runtime {
                            file_name: "<repl-preload>".to_string(),
                            message: rendered
                                .into_iter()
                                .chain(summary_tail.into_iter())
                                .collect::<Vec<_>>()
                                .join("\n"),
                        });
                    }
                    ReplOutput::DocResolved { .. } | ReplOutput::EvalStarted { .. } => {}
                }
            }
            engine.vm.enable_repl_host_io_buffering();
            Ok(engine)
        })
    }

    pub fn take_startup_results(&mut self) -> Vec<ReplResult> {
        std::mem::take(&mut self.startup_results)
    }

    fn eldr_partial_semantic_restore_notice() -> ReplResult {
        Self::plain(vec![
            ".eldr runtime image loaded; compile semantic metadata for user definitions is not restored yet.".to_string(),
        ])
    }

    /// Bootstrap stdlib sigil / scar context WITHOUT re-executing bytecode.
    ///
    /// Used when loading a `.eldr` image: the VM already contains compiled
    /// stdlib code, so we only need the name-resolution and type-checking
    /// context that sigil and scar provide.  Forge codegen and vm.push_atomic
    /// are intentionally skipped.
    fn restore_stdlib_scope_from_bootstrap(&mut self) -> Result<(), LoadError> {
        let state = default_repl_bootstrap_state().map_err(repl_load_error_into_load_error)?;
        if self.module_stages != state.module_stages
            || self.repl_module_path != state.repl_module_path
        {
            return Err(LoadError::BootstrapFailed {
                phase: "load".to_string(),
                file_name: "<stdlib>".to_string(),
                message: "default REPL stdlib stage layout mismatch".to_string(),
            });
        }
        if !bytecode_has_compatible_stdlib_prefix(self.vm.bytecode(), &state.bytecode) {
            return Err(LoadError::BootstrapFailed {
                phase: "load".to_string(),
                file_name: "<stdlib>".to_string(),
                message: "default REPL stdlib bytecode prefix mismatch".to_string(),
            });
        }

        self.auto_import_modules = state.auto_import_modules.clone();
        self.declaration_index = state.declaration_index.clone();
        self.auto_import_records = state.auto_import_records.clone();
        self.sigil_session = state.sigil_session.clone();
        self.scar_session.rollback(state.scar_checkpoint.clone());
        self.sync_scar_fun_index_with_vm();
        self.process_metadata = state.process_metadata.clone();
        Ok(())
    }

    pub fn completion_symbols(&self) -> Vec<String> {
        self.symbols.iter().cloned().collect()
    }

    pub fn semantic_index(&self) -> surtr_analysis::SemanticIndex {
        surtr_analysis::SemanticIndex::from_symbol_semantic_infos(self.symbol_semantic_infos())
    }

    fn resolve_diagnostic_for_repl(
        &self,
        error: &sigil::error::ResolveError,
        fallback_source_id: SourceId,
    ) -> (SourceId, DiagnosticSpec) {
        let diagnostic_location = |span: &Span| {
            crate::decode_rebased_module_span(span)
                .filter(|(source_id, _)| self.sources.get(*source_id).is_some())
                .unwrap_or((fallback_source_id, span.clone()))
        };
        let (source_id, primary_span) = diagnostic_location(&error.span);
        let reason = match resolve_diagnostic_reason(&error.diagnostic.reason) {
            Ok(reason) => reason,
            Err(parse_error) => {
                let source = self
                    .sources
                    .source(source_id)
                    .expect("resolved diagnostic source");
                let local_error = parse_error
                    .clone()
                    .map_spans(|span| diagnostic_location(span).1);
                return (
                    source_id,
                    diagnostics::parse_error_spec(source_id, source, &local_error),
                );
            }
        };
        let labels = error
            .related_labels
            .iter()
            .map(|label| {
                let (label_source_id, span) = diagnostic_location(&label.span);
                (label_source_id, span, label.message.clone())
            })
            .collect::<Vec<_>>();
        let spec = diagnostics::resolve_error_spec(
            source_id,
            &error.message,
            primary_span,
            reason,
            error.diagnostic.subject.clone(),
            &labels,
        );
        (source_id, spec)
    }

    pub fn symbol_semantic_infos(&self) -> Vec<surtr_analysis::SymbolSemanticInfo> {
        let compile_index = surtr_analysis::SemanticIndex::from_compile_metadata(
            self.sigil_session.owner_registry(),
            &self.declaration_index,
            &self.docs,
            &self.signatures,
        );
        let mut symbols = compile_index
            .symbols()
            .iter()
            .filter(|symbol| self.compile_symbol_is_repl_completion_surface(symbol))
            .cloned()
            .collect::<Vec<_>>();
        let compile_semantic_infos = compile_index
            .symbol_semantic_infos()
            .iter()
            .filter(|info| {
                symbols
                    .iter()
                    .any(|symbol| symbol.label == info.surface_name && symbol.kind == info.kind)
            })
            .cloned()
            .collect::<Vec<_>>();
        self.enrich_compile_symbol_details(&mut symbols);

        let visible_symbols = self
            .sigil_session
            .visible_declaration_entries()
            .into_iter()
            .filter_map(|visible| {
                surtr_analysis::symbol_semantic_info_for_effective_visible_entry(
                    self.sigil_session.owner_registry(),
                    &compile_semantic_infos,
                    &visible,
                )
                .map(surtr_analysis::SymbolSemanticInfo::into_completion_symbol)
            })
            .filter(|symbol| {
                symbol.kind == surtr_analysis::CompletionKind::FunctionCall
                    || self
                        .completion_symbol_declaration(symbol)
                        .is_some_and(|decl| {
                            matches!(decl.kind, sigil::DeclarationKind::EnumVariant)
                        })
            })
            .collect::<Vec<_>>();
        symbols.extend(visible_symbols);
        self.enrich_compile_symbol_details(&mut symbols);
        Self::remove_shadowed_type_path_symbols(&mut symbols);

        for label in self.completion_visible_module_labels() {
            if symbols.iter().any(|symbol| {
                symbol.label == label
                    && symbol.kind == surtr_analysis::CompletionKind::TypeConstructor
            }) {
                continue;
            }
            let capabilities = Self::completion_capabilities_for_builtin(&label);
            symbols.push(surtr_analysis::CompletionSymbol {
                label: label.clone(),
                replacement: label,
                kind: surtr_analysis::CompletionKind::TypeConstructor,
                detail: None,
                documentation: None,
                sort_text: None,
                origin: None,
                definition: None,
                capabilities,
            });
        }

        let mut seen_bindings = BTreeSet::new();
        for binding in self.binding_records.iter().rev() {
            if !seen_bindings.insert(binding.name.as_str()) {
                continue;
            }
            symbols.push(surtr_analysis::CompletionSymbol {
                label: binding.name.clone(),
                replacement: binding.name.clone(),
                kind: surtr_analysis::CompletionKind::Variable,
                detail: Some(binding.ty.clone()),
                documentation: None,
                sort_text: None,
                origin: None,
                definition: None,
                capabilities: None,
            });
        }

        for entry in self.vm.function_entries().iter().rev() {
            if entry.flags.generated {
                continue;
            }
            let Some(qualified_name) = entry.qualified_name.as_deref() else {
                continue;
            };
            if !self.function_entry_is_top_level_repl_surface(qualified_name) {
                continue;
            }
            let label = crate::surface_path_name(qualified_name).to_string();
            symbols.push(surtr_analysis::CompletionSymbol {
                label: label.clone(),
                replacement: label,
                kind: surtr_analysis::CompletionKind::FunctionCall,
                detail: entry.signature.clone().map(|signature| {
                    Self::render_signature_with_qualified_name(qualified_name, signature)
                }),
                documentation: None,
                sort_text: None,
                origin: None,
                definition: None,
                capabilities: None,
            });
            if let Some(tail) = crate::surface_path_name(qualified_name).rsplit("::").next() {
                symbols.push(surtr_analysis::CompletionSymbol {
                    label: tail.to_string(),
                    replacement: tail.to_string(),
                    kind: surtr_analysis::CompletionKind::FunctionCall,
                    detail: entry.signature.clone().map(|signature| {
                        Self::render_signature_with_qualified_name(qualified_name, signature)
                    }),
                    documentation: None,
                    sort_text: None,
                    origin: None,
                    definition: None,
                    capabilities: Self::completion_capabilities_for_builtin(qualified_name),
                });
            }
        }

        let mut projected_infos = symbols
            .into_iter()
            .map(|symbol| self.symbol_semantic_info_from_completion_symbol(&symbol))
            .collect::<Vec<_>>();
        for projected in &mut projected_infos {
            let Some(original) = compile_semantic_infos.iter().find(|original| {
                original.surface_name == projected.surface_name && original.kind == projected.kind
            }) else {
                continue;
            };
            if original.identity.is_some() {
                projected.identity = original.identity;
            }
            if original.capabilities.is_some() {
                projected.capabilities = original.capabilities;
            }
        }
        projected_infos
    }

    fn typecheck_context_for_source(source_kind: SourceKind) -> scar::TypecheckContext {
        scar::TypecheckContext::from_source_policy(source_kind.policy(CompileUnitKind::Repl, None))
    }

    fn compile_symbol_is_repl_completion_surface(
        &self,
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> bool {
        if symbol.label.starts_with("impl ") || symbol.label.contains("::impl ") {
            return false;
        }
        if let Some((owner, _)) = symbol.label.split_once("::") {
            if !Self::completion_visible_owner_name(owner) {
                return false;
            }
        } else if symbol.kind == surtr_analysis::CompletionKind::TypeConstructor
            && !Self::completion_visible_owner_name(&symbol.label)
        {
            return false;
        }
        match symbol.kind {
            surtr_analysis::CompletionKind::TypePath => {
                Self::completion_visible_module_name(&symbol.label)
            }
            surtr_analysis::CompletionKind::TypeConstructor => self
                .completion_symbol_declaration(symbol)
                .is_none_or(|decl| Self::declaration_is_repl_completion_surface(decl)),
            _ => self
                .completion_symbol_declaration(symbol)
                .is_none_or(|decl| Self::declaration_is_repl_completion_surface(decl)),
        }
    }

    fn enrich_compile_symbol_details(&self, symbols: &mut [surtr_analysis::CompletionSymbol]) {
        for symbol in symbols {
            if let Some(decl) = self.completion_symbol_declaration(symbol) {
                if matches!(decl.kind, sigil::DeclarationKind::EnumVariant) {
                    symbol.kind = surtr_analysis::CompletionKind::FunctionCall;
                    if let Some(signature) = self.declaration_signature(decl) {
                        symbol.detail = Some(signature);
                    } else if let Some(signature) = symbol.detail.take() {
                        symbol.detail = Some(Self::render_signature_with_qualified_name(
                            &decl.fq_name,
                            signature,
                        ));
                    }
                }
                symbol.capabilities = self.completion_capabilities_for_declaration(decl);
                if decl.kind == sigil::DeclarationKind::TraitMethod && !symbol.label.contains("::")
                {
                    if let Some((owner, _)) = decl.fq_name.rsplit_once("::") {
                        if let Some(owner_decl) = self.qualified_declaration(owner) {
                            symbol.detail = self
                                .declaration_signature(owner_decl)
                                .or(symbol.detail.take());
                            continue;
                        }
                    }
                }
                if matches!(decl.kind, sigil::DeclarationKind::Trait) {
                    symbol.detail = self.declaration_signature(decl).or(symbol.detail.take());
                    continue;
                }
                if symbol.detail.is_some() {
                    continue;
                }
                symbol.detail = self.declaration_signature(decl);
            }
        }
    }

    fn remove_shadowed_type_path_symbols(symbols: &mut Vec<surtr_analysis::CompletionSymbol>) {
        let type_constructor_labels = symbols
            .iter()
            .filter(|symbol| symbol.kind == surtr_analysis::CompletionKind::TypeConstructor)
            .map(|symbol| symbol.label.clone())
            .collect::<BTreeSet<_>>();
        symbols.retain(|symbol| {
            symbol.kind != surtr_analysis::CompletionKind::TypePath
                || !type_constructor_labels.contains(&symbol.label)
        });
    }

    fn completion_symbol_declaration<'a>(
        &'a self,
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> Option<&'a sigil::DeclarationEntry> {
        match symbol.origin.as_ref() {
            Some(surtr_analysis::CompletionOrigin::Declaration { qualified_name, .. }) => {
                self.qualified_declaration(qualified_name)
            }
            _ => self.qualified_declaration(&symbol.label),
        }
    }

    fn symbol_semantic_info_from_completion_symbol(
        &self,
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> surtr_analysis::SymbolSemanticInfo {
        let mut info = surtr_analysis::SymbolSemanticInfo::from_completion_symbol(symbol);
        if let Some(declaration) = self.completion_symbol_declaration(symbol) {
            info.canonical_name = declaration.fq_name.clone();
        }
        if info.identity.is_none() {
            info.identity = self
                .completion_symbol_declaration(symbol)
                .and_then(|entry| {
                    surtr_analysis::symbol_identity_for_declaration_entry(
                        self.sigil_session.owner_registry(),
                        entry,
                    )
                })
                .or_else(|| surtr_analysis::symbol_identity_for_builtin_surface(&symbol.label));
        }
        if info.display_metadata.is_none() {
            info.display_metadata = self.symbol_display_metadata_for_completion_symbol(symbol);
        }
        info
    }

    fn symbol_display_metadata_for_completion_symbol(
        &self,
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> Option<surtr_analysis::SymbolDisplayMetadata> {
        let (qualified_name, module_path) = match symbol.origin.as_ref() {
            Some(surtr_analysis::CompletionOrigin::Metadata {
                qualified_name,
                module_path,
            })
            | Some(surtr_analysis::CompletionOrigin::Declaration {
                qualified_name,
                module_path,
                ..
            }) => (qualified_name.as_str(), module_path.as_str()),
            None => self
                .completion_symbol_declaration(symbol)
                .map(|decl| (decl.fq_name.as_str(), decl.module_path.as_str()))?,
        };
        let surface_name = crate::surface_path_name(qualified_name);
        let has_doc = self.docs.iter().any(|entry| {
            entry.qualified_name == qualified_name || entry.qualified_name == surface_name
        });
        let has_signature = self.signatures.iter().any(|entry| {
            entry.qualified_name == qualified_name || entry.qualified_name == surface_name
        }) || self.docs.iter().any(|entry| {
            (entry.qualified_name == qualified_name || entry.qualified_name == surface_name)
                && entry.signature.is_some()
        });
        (has_doc || has_signature).then(|| surtr_analysis::SymbolDisplayMetadata {
            qualified_name: qualified_name.to_string(),
            module_path: module_path.to_string(),
            has_doc,
            has_signature,
        })
    }

    fn build_completion_context(&self) -> ReplCompletionContext {
        let semantic_index = self.semantic_index();
        let mut callable_signatures = BTreeMap::new();

        for symbol in semantic_index.symbols() {
            if !matches!(
                symbol.kind,
                surtr_analysis::CompletionKind::FunctionCall
                    | surtr_analysis::CompletionKind::TypeConstructor
            ) {
                continue;
            }
            let bare_trait_method_decl = (!symbol.label.contains("::"))
                .then(|| self.completion_symbol_declaration(symbol))
                .flatten()
                .filter(|decl| decl.kind == sigil::DeclarationKind::TraitMethod);
            let signature_entry = bare_trait_method_decl
                .and_then(|decl| self.declaration_signature_entry(decl))
                .or_else(|| self.completion_symbol_signature_entry(symbol));
            let Some((qualified_name, signature)) = signature_entry else {
                continue;
            };
            if bare_trait_method_decl.is_some() {
                callable_signatures.insert(symbol.label.clone(), (qualified_name, signature));
            } else {
                Self::insert_completion_context_signature(
                    &mut callable_signatures,
                    &symbol.label,
                    qualified_name,
                    signature,
                );
            }
        }

        for entry in self.vm.function_entries().iter().rev() {
            if entry.flags.generated {
                continue;
            }
            let Some(qualified_name) = entry.qualified_name.as_deref() else {
                continue;
            };
            if !self.function_entry_is_top_level_repl_surface(qualified_name) {
                continue;
            }
            let Some(signature) = entry.signature.as_ref() else {
                continue;
            };
            let label = crate::surface_path_name(qualified_name).to_string();
            Self::insert_completion_context_signature(
                &mut callable_signatures,
                &label,
                qualified_name.to_string(),
                signature.clone(),
            );
        }

        let mut seen_bindings = BTreeSet::new();
        for binding in self.binding_records.iter().rev() {
            if !seen_bindings.insert(binding.name.as_str()) {
                continue;
            }
            if let Some(signature) =
                Self::callable_binding_signature_from_type(&binding.name, &binding.ty)
            {
                Self::insert_completion_context_signature(
                    &mut callable_signatures,
                    &binding.name,
                    binding.name.clone(),
                    signature,
                );
            }
        }

        ReplCompletionContext {
            input_support: surtr_analysis::ReplInputSupportContext::from_parts(
                semantic_index,
                callable_signatures,
            ),
        }
    }

    fn insert_completion_context_signature(
        callable_signatures: &mut BTreeMap<String, (String, String)>,
        label: &str,
        qualified_name: String,
        signature: String,
    ) {
        callable_signatures
            .entry(label.to_string())
            .or_insert((qualified_name.clone(), signature.clone()));
        if let Some(tail) = label.rsplit("::").next() {
            callable_signatures
                .entry(tail.to_string())
                .or_insert((qualified_name, signature));
        }
    }

    fn completion_symbol_qualified_name(
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> Option<String> {
        match symbol.origin.as_ref()? {
            surtr_analysis::CompletionOrigin::Metadata { qualified_name, .. }
            | surtr_analysis::CompletionOrigin::Declaration { qualified_name, .. } => {
                Some(qualified_name.clone())
            }
        }
    }

    fn completion_symbol_signature_entry(
        &self,
        symbol: &surtr_analysis::CompletionSymbol,
    ) -> Option<(String, String)> {
        let qualified_name = Self::completion_symbol_qualified_name(symbol)?;
        if symbol.kind == surtr_analysis::CompletionKind::TypeConstructor {
            if let Some(decl) = self.qualified_declaration(&qualified_name) {
                if let Some(signature) = self.constructor_signature_entry(decl) {
                    return Some(signature);
                }
            }
        }
        symbol
            .detail
            .clone()
            .map(|signature| (qualified_name.clone(), signature))
            .or_else(|| {
                self.qualified_declaration(&qualified_name)
                    .and_then(|decl| self.declaration_signature_entry(decl))
            })
    }

    pub fn completion_context(&self) -> ReplCompletionContext {
        if let Some(cached) = self.completion_context_cache.borrow().clone() {
            return cached;
        }

        let context = self.build_completion_context();
        #[cfg(test)]
        self.completion_context_builds
            .set(self.completion_context_builds.get() + 1);
        *self.completion_context_cache.borrow_mut() = Some(context.clone());
        context
    }

    fn insert_completion_symbol(&mut self, symbol: String) {
        self.symbols.insert(symbol);
    }

    fn insert_surface_symbol(&mut self, name: &str) {
        let surface_name = crate::surface_rendered_name(name);
        self.insert_completion_symbol(surface_name.clone());
        if let Some(short) = surface_name.rsplit("::").next() {
            self.insert_completion_symbol(short.to_string());
        }
    }

    fn empty_completion() -> ReplCompletion {
        ReplCompletion {
            candidates: Vec::new(),
            signature: None,
            telemetry: CompletionTelemetry::default(),
        }
    }

    fn completion_from_candidates(candidates: Vec<ReplCompletionCandidate>) -> ReplCompletion {
        ReplCompletion {
            candidates,
            signature: None,
            telemetry: CompletionTelemetry::default(),
        }
    }

    fn repl_command_arg_context<'a>(
        input: &'a str,
        cursor: usize,
    ) -> Option<ReplCommandArgContext<'a>> {
        let cursor = clamp_to_char_boundary(input, cursor.min(input.len()));
        let before_cursor = &input[..cursor];
        let trimmed_start = before_cursor.trim_start();
        let line_start = before_cursor.len() - trimmed_start.len();
        if !trimmed_start.starts_with(':') {
            return None;
        }

        let command_start = line_start + ':'.len_utf8();
        let command_tail = &input[command_start..];
        let command_len = command_tail
            .char_indices()
            .find_map(|(idx, ch)| ch.is_whitespace().then_some(idx))
            .unwrap_or(command_tail.len());
        let command_end = command_start + command_len;
        if cursor <= command_end {
            return None;
        }

        let command = &input[command_start..command_end];
        let spec = repl_command_spec_for_alias(command)?;
        let mut arg_start = command_end;
        for (idx, ch) in input[command_end..cursor].char_indices() {
            if !ch.is_whitespace() {
                arg_start = command_end + idx;
                break;
            }
            arg_start = command_end + idx + ch.len_utf8();
        }
        Some(ReplCommandArgContext {
            spec,
            arg_start,
            cursor,
            args_before_cursor: &input[arg_start..cursor],
        })
    }

    fn command_arg_word_range(
        input: &str,
        cursor: usize,
        arg_start: usize,
    ) -> (usize, usize, String) {
        let (replace_start, replace_end, prefix) = completion_token(input, cursor);
        if replace_start < arg_start {
            (arg_start, cursor, input[arg_start..cursor].to_string())
        } else {
            (replace_start, replace_end, prefix)
        }
    }

    fn selector_arg_word_range(
        input: &str,
        cursor: usize,
        arg_start: usize,
    ) -> (usize, usize, String) {
        let before = &input[arg_start..cursor];
        let comma_start = before.rfind(',').map(|idx| arg_start + idx + 1);
        let range_start = before.rfind("..").map(|idx| arg_start + idx + 2);
        let mut replace_start = comma_start
            .into_iter()
            .chain(range_start)
            .max()
            .unwrap_or(arg_start);
        while replace_start < cursor {
            let Some(ch) = input[replace_start..cursor].chars().next() else {
                break;
            };
            if !ch.is_whitespace() {
                break;
            }
            replace_start += ch.len_utf8();
        }
        (
            replace_start,
            cursor,
            input[replace_start..cursor].to_string(),
        )
    }

    fn fixed_arg_candidates(
        options: &[&str],
        detail: Option<String>,
        replace_start: usize,
        replace_end: usize,
        prefix: &str,
    ) -> Vec<ReplCompletionCandidate> {
        options
            .iter()
            .filter(|option| option.starts_with(prefix))
            .map(|option| ReplCompletionCandidate {
                label: (*option).to_string(),
                replacement: (*option).to_string(),
                kind: ReplCompletionKind::Variable,
                detail: detail.clone(),
                documentation: None,
                replace_start,
                replace_end,
            })
            .collect()
    }

    fn help_topic_candidates(
        input: &str,
        ctx: &ReplCommandArgContext<'_>,
    ) -> Vec<ReplCompletionCandidate> {
        let (replace_start, replace_end, prefix) =
            Self::command_arg_word_range(input, ctx.cursor, ctx.arg_start);
        let typed_colon = prefix.starts_with(':');
        let topic_prefix = prefix.strip_prefix(':').unwrap_or(&prefix).to_string();
        repl_command_specs()
            .iter()
            .flat_map(|spec| {
                spec.aliases.iter().filter_map({
                    let prefix = prefix.clone();
                    let topic_prefix = topic_prefix.clone();
                    move |alias| {
                        let label = format!(":{alias}");
                        if !alias.starts_with(&topic_prefix) && !label.starts_with(&prefix) {
                            return None;
                        }
                        Some(ReplCompletionCandidate {
                            label,
                            replacement: if typed_colon {
                                format!(":{alias}")
                            } else {
                                (*alias).to_string()
                            },
                            kind: ReplCompletionKind::FunctionCall,
                            detail: Some(spec.completion_detail()),
                            documentation: None,
                            replace_start,
                            replace_end,
                        })
                    }
                })
            })
            .collect()
    }

    fn numeric_line_candidates<I>(
        lines: I,
        replace_start: usize,
        replace_end: usize,
        prefix: &str,
    ) -> Vec<ReplCompletionCandidate>
    where
        I: IntoIterator<Item = usize>,
    {
        lines
            .into_iter()
            .map(|line| line.to_string())
            .filter(|line| line.starts_with(prefix))
            .map(|line| ReplCompletionCandidate {
                label: line.clone(),
                replacement: line,
                kind: ReplCompletionKind::Variable,
                detail: Some("REPL line".to_string()),
                documentation: None,
                replace_start,
                replace_end,
            })
            .collect()
    }

    fn save_path_candidates(ctx: &ReplCommandArgContext<'_>) -> Vec<ReplCompletionCandidate> {
        let (replace_start, replace_end) = (ctx.arg_start, ctx.cursor);
        let typed_path = ctx.args_before_cursor;
        let path = Path::new(typed_path);
        let (dir, prefix) = if typed_path.is_empty() {
            (PathBuf::from("."), "")
        } else if typed_path.ends_with(std::path::MAIN_SEPARATOR) {
            (PathBuf::from(path), "")
        } else {
            (
                path.parent()
                    .filter(|parent| !parent.as_os_str().is_empty())
                    .map(Path::to_path_buf)
                    .unwrap_or_else(|| PathBuf::from(".")),
                path.file_name()
                    .and_then(|name| name.to_str())
                    .unwrap_or(""),
            )
        };

        let Ok(entries) = fs::read_dir(&dir) else {
            return Vec::new();
        };
        let mut candidates = entries
            .filter_map(Result::ok)
            .filter_map(|entry| {
                let file_name = entry.file_name().to_str()?.to_string();
                if !file_name.starts_with(prefix) {
                    return None;
                }
                let is_dir = entry.file_type().ok().is_some_and(|ty| ty.is_dir());
                let mut replacement = if dir == Path::new(".") {
                    file_name.clone()
                } else {
                    dir.join(&file_name).display().to_string()
                };
                let label = if is_dir {
                    replacement.push(std::path::MAIN_SEPARATOR);
                    format!("{file_name}{}", std::path::MAIN_SEPARATOR)
                } else {
                    file_name
                };
                Some(ReplCompletionCandidate {
                    label,
                    replacement,
                    kind: ReplCompletionKind::Variable,
                    detail: Some(if is_dir {
                        "directory".to_string()
                    } else {
                        ".eldr session path".to_string()
                    }),
                    documentation: None,
                    replace_start,
                    replace_end,
                })
            })
            .collect::<Vec<_>>();
        candidates.sort_by(|left, right| left.label.cmp(&right.label));
        candidates
    }

    fn binding_target_candidates(
        &self,
        input: &str,
        ctx: &ReplCommandArgContext<'_>,
        facet_only: bool,
    ) -> Vec<ReplCompletionCandidate> {
        let (replace_start, replace_end, prefix) =
            Self::command_arg_word_range(input, ctx.cursor, ctx.arg_start);
        let mut seen = BTreeSet::new();
        let mut candidates = Vec::new();
        for binding in self
            .result_metas
            .iter()
            .rev()
            .flatten()
            .flat_map(|meta| meta.bindings.iter().rev())
        {
            if facet_only && binding.facet_info.is_none() {
                continue;
            }
            if !seen.insert(binding.name.clone()) || !binding.name.starts_with(&prefix) {
                continue;
            }
            candidates.push(ReplCompletionCandidate {
                label: binding.name.clone(),
                replacement: binding.name.clone(),
                kind: if binding.facet_info.is_some() {
                    ReplCompletionKind::TypePath
                } else {
                    ReplCompletionKind::Variable
                },
                detail: Some(crate::surface_rendered_name(&binding.ty)),
                documentation: None,
                replace_start,
                replace_end,
            });
        }
        if facet_only {
            for name in self
                .declaration_index
                .values()
                .map(|decl| decl.name.as_str())
                .chain(std::iter::once("Tuple"))
            {
                let label = crate::surface_path_name(name);
                if !label.starts_with(&prefix)
                    || self.binding_info(label).is_some()
                    || self.facet_root_kind_for_symbol(label).is_none()
                    || !seen.insert(label.to_string())
                {
                    continue;
                }
                candidates.push(ReplCompletionCandidate {
                    label: label.to_string(),
                    replacement: label.to_string(),
                    kind: ReplCompletionKind::TypePath,
                    detail: Some("Facet path root".to_string()),
                    documentation: None,
                    replace_start,
                    replace_end,
                });
            }
        }
        if !facet_only {
            for (name, metadata) in &self.process_metadata {
                if metadata.instance != spire::ast::ProcessInstance::Singleton {
                    continue;
                }
                let rendered = name.rsplit("::").next().unwrap_or(name);
                if !seen.insert(rendered.to_string()) || !rendered.starts_with(&prefix) {
                    continue;
                }
                candidates.push(ReplCompletionCandidate {
                    label: rendered.to_string(),
                    replacement: rendered.to_string(),
                    kind: ReplCompletionKind::Variable,
                    detail: Some("singleton process owner".to_string()),
                    documentation: None,
                    replace_start,
                    replace_end,
                });
            }
        }
        candidates
    }

    fn command_argument_completion(
        &self,
        input: &str,
        cursor: usize,
        use_site: surtr_analysis::ReplCompletionUseSite,
    ) -> Option<ReplCompletion> {
        if !matches!(use_site, surtr_analysis::ReplCompletionUseSite::Command(_)) {
            return None;
        }
        if !completion_allowed_at_cursor(input, cursor) {
            return Some(Self::empty_completion());
        }
        let ctx = Self::repl_command_arg_context(input, cursor)?;
        match ctx.spec.arg_completion {
            ReplCommandArgCompletion::Semantic => None,
            ReplCommandArgCompletion::None => Some(Self::empty_completion()),
            ReplCommandArgCompletion::CommandTopic => Some(Self::completion_from_candidates(
                Self::help_topic_candidates(input, &ctx),
            )),
            ReplCommandArgCompletion::Fixed(options) => {
                let (replace_start, replace_end, prefix) =
                    Self::command_arg_word_range(input, cursor, ctx.arg_start);
                Some(Self::completion_from_candidates(
                    Self::fixed_arg_candidates(
                        options,
                        Some(ctx.spec.usage.to_string()),
                        replace_start,
                        replace_end,
                        &prefix,
                    ),
                ))
            }
            ReplCommandArgCompletion::ResultLine => {
                let (replace_start, replace_end, prefix) =
                    Self::selector_arg_word_range(input, cursor, ctx.arg_start);
                Some(Self::completion_from_candidates(
                    Self::numeric_line_candidates(
                        1..=self.results.len(),
                        replace_start,
                        replace_end,
                        &prefix,
                    ),
                ))
            }
            ReplCommandArgCompletion::HistorySelector => {
                let (replace_start, replace_end, prefix) =
                    Self::selector_arg_word_range(input, cursor, ctx.arg_start);
                Some(Self::completion_from_candidates(
                    Self::numeric_line_candidates(
                        self.history_entries.iter().map(|entry| entry.line),
                        replace_start,
                        replace_end,
                        &prefix,
                    ),
                ))
            }
            ReplCommandArgCompletion::SavePath => Some(Self::completion_from_candidates(
                Self::save_path_candidates(&ctx),
            )),
            ReplCommandArgCompletion::TypeTarget => Some(Self::completion_from_candidates(
                self.binding_target_candidates(input, &ctx, false),
            )),
            ReplCommandArgCompletion::FacetTarget => {
                if let Some(assist) = self.facet_completion_assist(input, cursor) {
                    return Some(ReplCompletion {
                        candidates: assist.candidates,
                        signature: Some(assist.signature),
                        telemetry: CompletionTelemetry::default(),
                    });
                }
                Some(Self::completion_from_candidates(
                    self.binding_target_candidates(input, &ctx, true),
                ))
            }
        }
    }

    pub fn completions(&self, input: &str, cursor: usize) -> ReplCompletion {
        let use_site = surtr_analysis::repl_completion_use_site(input, cursor);
        if let Some(completion) = self.command_argument_completion(input, cursor, use_site) {
            return completion;
        }
        if matches!(
            use_site,
            surtr_analysis::ReplCompletionUseSite::Input
                | surtr_analysis::ReplCompletionUseSite::Command(
                    surtr_analysis::ReplCommandUseSite::Facet
                )
        ) {
            if let Some(assist) = self.facet_completion_assist(input, cursor) {
                return ReplCompletion {
                    candidates: assist.candidates,
                    signature: Some(assist.signature),
                    telemetry: CompletionTelemetry::default(),
                };
            }
        }
        self.completion_context().completions(input, cursor)
    }

    pub fn cached_completion_context(&self) -> Option<ReplCompletionContext> {
        self.completion_context_cache.borrow().clone()
    }

    #[cfg(test)]
    fn completion_context_build_count(&self) -> usize {
        self.completion_context_builds.get()
    }

    fn repl_completion_candidate_from_analysis(
        candidate: surtr_analysis::CompletionCandidate,
    ) -> ReplCompletionCandidate {
        let label = Self::repl_completion_label(
            &candidate.label,
            &candidate.replacement,
            candidate.detail.as_deref(),
        );
        let kind = match candidate.kind {
            surtr_analysis::CompletionKind::Variable => ReplCompletionKind::Variable,
            surtr_analysis::CompletionKind::TypeConstructor => ReplCompletionKind::TypeConstructor,
            surtr_analysis::CompletionKind::TypePath => ReplCompletionKind::TypePath,
            surtr_analysis::CompletionKind::FunctionCall => ReplCompletionKind::FunctionCall,
        };

        ReplCompletionCandidate {
            label,
            replacement: candidate.replacement,
            kind,
            detail: candidate
                .detail
                .map(|detail| surtr_analysis::query::format_completion_signature(&detail)),
            documentation: candidate.documentation,
            replace_start: candidate.replace_start,
            replace_end: candidate.replace_end,
        }
    }

    fn facet_completion_assist(&self, input: &str, cursor: usize) -> Option<FacetCompletionAssist> {
        let cursor = clamp_to_char_boundary(input, cursor.min(input.len()));
        if !completion_allowed_at_cursor(input, cursor) {
            return None;
        }
        // `:facet` is definition inspection. It can traverse private segments so
        // that the REPL can describe a path which is valid in its owner scope,
        // while ordinary source completion keeps those members hidden.
        let command_context = Self::repl_command_arg_context(input, cursor);
        let include_private = command_context
            .as_ref()
            .is_some_and(|context| context.spec.kind == ReplCommandKind::Facet);
        let (facet_input, facet_cursor, offset) = if let Some(context) = &command_context {
            if include_private {
                (
                    &input[context.arg_start..],
                    cursor.saturating_sub(context.arg_start),
                    context.arg_start,
                )
            } else {
                (input, cursor, 0)
            }
        } else {
            (input, cursor, 0)
        };
        let mut context = surtr_analysis::facet_path_context_at_cursor(facet_input, facet_cursor)?;
        context.replace_start += offset;
        context.replace_end += offset;
        context.token_start += offset;
        let (root_ty, mut focus_ty, source_is_result) = self.facet_root_ast_ty(&context)?;
        let mut path_is_variant = false;
        let mut path_is_fallible = false;
        for segment in &context.completed_segments {
            if let Some(inner) = Self::result_inner_ast_ty(&focus_ty) {
                focus_ty = inner.clone();
                path_is_fallible = true;
            }
            let step = self.facet_next_ast_ty(&focus_ty, segment, include_private)?;
            path_is_variant |= step.variant;
            path_is_fallible |= step.fallible;
            focus_ty = step.ty;
        }
        let candidate_focus_ty = Self::result_inner_ast_ty(&focus_ty).unwrap_or(&focus_ty);
        let placeholder = if matches!(candidate_focus_ty, AstTy::Tuple(_, _)) {
            "[segment]"
        } else {
            "[field]"
        };
        let candidates = self
            .facet_candidate_segments(
                candidate_focus_ty,
                context.replace_start,
                context.replace_end,
                include_private,
            )
            .unwrap_or_default()
            .into_iter()
            .filter(|candidate| candidate.label.starts_with(&context.prefix))
            .collect::<Vec<_>>();
        let path_display = if context.completed_segments.is_empty() {
            format!(
                "{}{}",
                &input[context.token_start..context.replace_start],
                placeholder
            )
        } else {
            context.current_path.clone()
        };
        let signature = ReplSignatureHelp {
            lines: self.facet_api_help_lines(
                &path_display,
                &root_ty,
                &focus_ty,
                source_is_result || path_is_fallible,
                path_is_variant,
                context.completed_segments.is_empty(),
                context.root_kind,
                context.root_kind == surtr_analysis::FacetPathRootKind::ViewClosureRoot,
            ),
            active_parameter: Some(0),
        };
        Some(FacetCompletionAssist {
            candidates,
            signature,
        })
    }

    fn facet_root_ast_ty(
        &self,
        context: &surtr_analysis::FacetPathCompletionContext,
    ) -> Option<(AstTy, AstTy, bool)> {
        match context.root_kind {
            surtr_analysis::FacetPathRootKind::TypeRoot
            | surtr_analysis::FacetPathRootKind::ViewClosureRoot => Some((
                AstTy::Named(Span { start: 0, end: 0 }, context.root.clone()),
                AstTy::Named(Span { start: 0, end: 0 }, context.root.clone()),
                false,
            )),
            surtr_analysis::FacetPathRootKind::ValueRoot => self
                .binding_type(&context.root)
                .as_deref()
                .and_then(parse_signature_type)
                .or_else(|| {
                    self.semantic_index()
                        .find_symbol(&context.root)
                        .and_then(|symbol| symbol.detail.as_deref())
                        .and_then(parse_signature_type)
                })
                .map(|root_ty| {
                    if let Some((source, focus)) = Self::facet_source_and_focus_ast_ty(&root_ty) {
                        return (source, focus, false);
                    }
                    if let Some(inner) = Self::result_inner_ast_ty(&root_ty) {
                        (root_ty.clone(), inner.clone(), true)
                    } else {
                        (root_ty.clone(), root_ty, false)
                    }
                }),
        }
    }

    fn facet_candidate_segments(
        &self,
        ty: &AstTy,
        replace_start: usize,
        replace_end: usize,
        include_private: bool,
    ) -> Option<Vec<ReplCompletionCandidate>> {
        match ty {
            AstTy::Named(_, name) => {
                if name.rsplit("::").next().unwrap_or(name) == "Tuple" {
                    return Some(vec![ReplCompletionCandidate {
                        label: "_".to_string(),
                        replacement: "_".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some("pass _N: N requires UnsignedInt".to_string()),
                        documentation: None,
                        replace_start,
                        replace_end,
                    }]);
                }
                if name.rsplit("::").next().unwrap_or(name) == "Result" {
                    return Some(Vec::new());
                }
                if let Some(def) = self.scar_session.lookup_type_def(name) {
                    let mut candidates = def
                        .fields
                        .iter()
                        .filter(|(field, _)| include_private || !def.private_fields.contains(field))
                        .map(|(field, field_ty)| ReplCompletionCandidate {
                            label: field.clone(),
                            replacement: field.clone(),
                            kind: ReplCompletionKind::TypePath,
                            detail: Some(Self::field_completion_detail(
                                field,
                                field_ty,
                                def.private_fields.contains(field),
                                def.readonly_fields.contains(field),
                            )),
                            documentation: None,
                            replace_start,
                            replace_end,
                        })
                        .collect::<Vec<_>>();
                    if matches!(def.kind, scar::env::TypeKind::Enum) {
                        candidates.extend(
                            self.scar_session
                                .enum_variants_of(name)
                                .into_iter()
                                .flatten()
                                .map(|variant| ReplCompletionCandidate {
                                    label: variant.short_name.clone(),
                                    replacement: variant.short_name.clone(),
                                    kind: ReplCompletionKind::TypePath,
                                    detail: Some(if variant.payload.is_empty() {
                                        format!(
                                            "{}::{}",
                                            crate::surface_path_name(name),
                                            variant.short_name
                                        )
                                    } else {
                                        format!(
                                            "{}::{}({})",
                                            crate::surface_path_name(name),
                                            variant.short_name,
                                            variant
                                                .payload
                                                .iter()
                                                .map(Self::ty_to_string)
                                                .collect::<Vec<_>>()
                                                .join(", ")
                                        )
                                    }),
                                    documentation: None,
                                    replace_start,
                                    replace_end,
                                }),
                        );
                    }
                    candidates.sort_by(|left, right| left.label.cmp(&right.label));
                    return Some(candidates);
                }
                None
            }
            AstTy::Tuple(_, items) => Some(
                items
                    .iter()
                    .enumerate()
                    .map(|(idx, item)| ReplCompletionCandidate {
                        label: format!("_{idx}"),
                        replacement: format!("_{idx}"),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("_{idx}: {}", format_query_ty(item))),
                        documentation: None,
                        replace_start,
                        replace_end,
                    })
                    .collect(),
            ),
            AstTy::Generic(_, name, args) if name == "List" && args.len() == 1 => {
                let item = Self::facet_help_ty_display(&args[0]);
                Some(vec![
                    ReplCompletionCandidate {
                        label: "[idx]".to_string(),
                        replacement: "[idx]".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("[idx: Int] -> {item}")),
                        documentation: None,
                        replace_start,
                        replace_end,
                    },
                    ReplCompletionCandidate {
                        label: "[idx + 1]".to_string(),
                        replacement: "[idx + 1]".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("[idx + 1: Int] -> {item}")),
                        documentation: None,
                        replace_start,
                        replace_end,
                    },
                    ReplCompletionCandidate {
                        label: "[start..end]".to_string(),
                        replacement: "[start..end]".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("[start..end: Int] -> List<{item}>")),
                        documentation: None,
                        replace_start,
                        replace_end,
                    },
                ])
            }
            AstTy::Generic(_, name, args) if name == "HashMap" && args.len() == 1 => {
                let value = Self::facet_help_ty_display(&args[0]);
                Some(vec![
                    ReplCompletionCandidate {
                        label: "[key]".to_string(),
                        replacement: "[key]".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("[key: String] -> {value}")),
                        documentation: None,
                        replace_start,
                        replace_end,
                    },
                    ReplCompletionCandidate {
                        label: "[\"key\"]".to_string(),
                        replacement: "[\"key\"]".to_string(),
                        kind: ReplCompletionKind::TypePath,
                        detail: Some(format!("[\"key\": String] -> {value}")),
                        documentation: None,
                        replace_start,
                        replace_end,
                    },
                ])
            }
            _ => None,
        }
    }

    fn field_completion_detail(
        field: &str,
        field_ty: &Ty,
        private: bool,
        readonly: bool,
    ) -> String {
        let mut detail = format!("{}: {}", field, Self::ty_to_string(field_ty));
        if private {
            detail.push_str(" private");
        }
        if readonly {
            detail.push_str(" readonly");
        }
        detail
    }

    fn facet_next_ast_ty(
        &self,
        ty: &AstTy,
        segment: &str,
        include_private: bool,
    ) -> Option<FacetStep> {
        match ty {
            AstTy::Named(_, name) => {
                let def = self.scar_session.lookup_type_def(name)?;
                if let Some((_, field_ty)) = def.fields.iter().find(|(field, _)| {
                    field == segment && (include_private || !def.private_fields.contains(field))
                }) {
                    return parse_signature_type(&Self::ty_to_string(field_ty)).map(|ty| {
                        FacetStep {
                            ty,
                            fallible: false,
                            variant: false,
                        }
                    });
                }
                if matches!(def.kind, scar::env::TypeKind::Enum) {
                    let variant = self
                        .scar_session
                        .enum_variants_of(name)?
                        .iter()
                        .find(|variant| variant.short_name == segment.trim_end_matches('?'))?;
                    return match variant.payload.as_slice() {
                        [] => Some(FacetStep {
                            ty: AstTy::Named(
                                Span { start: 0, end: 0 },
                                crate::surface_path_name(name).to_string(),
                            ),
                            fallible: true,
                            variant: true,
                        }),
                        [single] => {
                            parse_signature_type(&Self::ty_to_string(single)).map(|ty| FacetStep {
                                ty,
                                fallible: true,
                                variant: true,
                            })
                        }
                        many => Some(FacetStep {
                            ty: AstTy::Tuple(
                                Span { start: 0, end: 0 },
                                many.iter()
                                    .map(|item| parse_signature_type(&Self::ty_to_string(item)))
                                    .collect::<Option<Vec<_>>>()?,
                            ),
                            fallible: true,
                            variant: true,
                        }),
                    };
                }
                None
            }
            AstTy::Tuple(_, items) => segment
                .strip_prefix('_')
                .and_then(|value| value.parse::<usize>().ok())
                .and_then(|idx| items.get(idx).cloned())
                .map(|ty| FacetStep {
                    ty,
                    fallible: false,
                    variant: false,
                }),
            AstTy::Generic(_, name, args) if segment.starts_with('[') && segment.ends_with(']') => {
                match name.as_str() {
                    "List" if args.len() == 1 => Some(FacetStep {
                        ty: if segment.contains("..") {
                            AstTy::Generic(
                                Span { start: 0, end: 0 },
                                "List".to_string(),
                                vec![args[0].clone()],
                            )
                        } else {
                            args[0].clone()
                        },
                        fallible: true,
                        variant: false,
                    }),
                    "HashMap" if args.len() == 1 => Some(FacetStep {
                        ty: args[0].clone(),
                        fallible: true,
                        variant: false,
                    }),
                    _ => None,
                }
            }
            AstTy::Generic(_, name, args) if name != "Result" => {
                match (name.as_str(), segment.trim_end_matches('?')) {
                    ("Option", "Some") if args.len() == 1 => Some(FacetStep {
                        ty: args[0].clone(),
                        fallible: true,
                        variant: true,
                    }),
                    _ => None,
                }
            }
            _ => None,
        }
    }

    fn result_inner_ast_ty(ty: &AstTy) -> Option<&AstTy> {
        match ty {
            AstTy::Generic(_, name, args) if name == "Result" && !args.is_empty() => args.first(),
            _ => None,
        }
    }

    fn facet_source_and_focus_ast_ty(ty: &AstTy) -> Option<(AstTy, AstTy)> {
        match ty {
            AstTy::Generic(_, name, args) if name == "Facet" && args.len() == 5 => {
                Some((args[1].clone(), args[2].clone()))
            }
            _ => None,
        }
    }

    fn facet_api_help_lines(
        &self,
        path_display: &str,
        source_ty: &AstTy,
        focus_ty: &AstTy,
        path_is_fallible: bool,
        path_is_variant: bool,
        root_only: bool,
        root_kind: surtr_analysis::FacetPathRootKind,
        is_view_closure: bool,
    ) -> Vec<String> {
        let source = Self::facet_help_ty_display(source_ty);
        let focus = Self::facet_help_ty_display(focus_ty);
        let view_result = if path_is_fallible {
            format!("Result<{focus}>")
        } else {
            focus.clone()
        };
        let mut lines = if root_only && is_view_closure {
            vec![format!("{path_display} -> ({source} -> _)")]
        } else if root_only && root_kind == surtr_analysis::FacetPathRootKind::TypeRoot {
            vec![format!(
                "{path_display} -> Facet<InfallibleStructural, {source}, _, _, _>"
            )]
        } else if root_only && root_kind == surtr_analysis::FacetPathRootKind::ValueRoot {
            vec![format!("{path_display} -> _")]
        } else if is_view_closure {
            vec![format!("&{path_display} -> ({source} -> {view_result})")]
        } else {
            vec![format!(
                "Facet::view({path_display}, {source}) -> {view_result}"
            )]
        };
        lines.push(format!(
            "Facet::set({path_display}, {source}, {}) -> Result<{source}>",
            self.facet_set_value_display(focus_ty)
        ));
        let over_input = self.facet_over_input_display(focus_ty);
        lines.push(format!(
            "Facet::over({path_display}, {source}, ({over_input} -> Result<{over_input}>)) -> Result<{source}>"
        ));
        if Self::result_inner_ast_ty(focus_ty).is_some() {
            lines.push(format!(
                "Facet::over_result({path_display}, {source}, ({focus} -> Result<{focus}>)) -> Result<{source}>"
            ));
        }
        if path_is_variant {
            lines.push(format!(
                "Facet::preview({path_display}, {source}) -> {view_result}"
            ));
            lines.push(format!(
                "Facet::case_set({path_display}, {source}, {}) -> Result<{source}>",
                self.facet_set_value_display(focus_ty)
            ));
            lines.push(format!(
                "Facet::case_over({path_display}, {source}, ({over_input} -> Result<{over_input}>)) -> Result<{source}>"
            ));
        }
        lines
    }

    fn facet_set_value_display(&self, focus_ty: &AstTy) -> String {
        if let Some(inner) = Self::result_inner_ast_ty(focus_ty) {
            format!(
                "{} or {}",
                Self::facet_help_ty_display(inner),
                Self::facet_help_ty_display(focus_ty)
            )
        } else {
            Self::facet_help_ty_display(focus_ty)
        }
    }

    fn facet_over_input_display(&self, focus_ty: &AstTy) -> String {
        Self::result_inner_ast_ty(focus_ty)
            .map(Self::facet_help_ty_display)
            .unwrap_or_else(|| Self::facet_help_ty_display(focus_ty))
    }

    fn facet_help_ty_display(ty: &AstTy) -> String {
        match ty {
            AstTy::Generic(_, name, args)
                if name == "Result"
                    && args.len() == 2
                    && matches!(
                        args.get(1),
                        Some(AstTy::Named(_, error)) if error == "Error"
                    ) =>
            {
                format!("Result<{}>", Self::facet_help_ty_display(&args[0]))
            }
            AstTy::Generic(_, name, args) => format!(
                "{}<{}>",
                name,
                args.iter()
                    .map(Self::facet_help_ty_display)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Tuple(_, items) => format!(
                "({})",
                items
                    .iter()
                    .map(Self::facet_help_ty_display)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Func(_, params, ret) => format!(
                "({} -> {})",
                params
                    .iter()
                    .map(Self::facet_help_ty_display)
                    .collect::<Vec<_>>()
                    .join(", "),
                Self::facet_help_ty_display(ret)
            ),
            _ => format_query_ty(ty),
        }
    }

    fn repl_completion_label(label: &str, replacement: &str, detail: Option<&str>) -> String {
        if label != replacement {
            return label.to_string();
        }

        if !matches!(replacement, "True" | "False") {
            return label.to_string();
        }

        if detail.is_some_and(|detail| detail.contains(&format!("Result::{replacement}("))) {
            label.to_string()
        } else {
            label.to_string()
        }
    }

    fn callable_binding_signature_from_type(binding_name: &str, ty: &str) -> Option<String> {
        let parsed = parse_signature_type(ty)?;
        if Self::is_extractor_closure_query_type(&parsed) {
            return Some(format!("{binding_name}: {}", format_query_ty(&parsed)));
        }
        let AstTy::Func(_, params, ret) = parsed else {
            return None;
        };
        let params = params
            .iter()
            .map(format_query_ty)
            .collect::<Vec<_>>()
            .join(", ");
        Some(format!(
            "{binding_name}({params}) -> {}",
            format_query_ty(ret.as_ref())
        ))
    }

    fn sync_cached_completion_context_after_commit(
        &self,
        imported_symbols: &[String],
        bindings: &[forge::BindingInfo],
        function_defs: &[String],
    ) {
        if self.completion_context_cache.borrow().is_none() {
            return;
        }

        let _ = (imported_symbols, bindings, function_defs);
        *self.completion_context_cache.borrow_mut() = Some(self.build_completion_context());
    }

    fn completion_capabilities_for_builtin(name: &str) -> Option<SymbolCapabilities> {
        let surface_name = crate::surface_rendered_name(name);
        surtr_analysis::symbol_capabilities_for_builtin_surface(&surface_name)
    }

    fn completion_capabilities_for_declaration(
        &self,
        entry: &sigil::DeclarationEntry,
    ) -> Option<SymbolCapabilities> {
        surtr_analysis::symbol_capabilities_for_declaration_entry(
            self.sigil_session.owner_registry(),
            entry,
        )
    }

    pub fn prompt(&self) -> String {
        if self.pending.is_empty() {
            format!("xldr({})> ", self.next_line)
        } else {
            format!("...({})> ", self.next_line)
        }
    }

    fn report_main_result_error_if_any(
        &self,
        value: &Value,
    ) -> Result<Option<Vec<String>>, eldr::RuntimeError> {
        // A valid language Err keeps the REPL alive; malformed values are runtime traps.
        match value {
            Value::Tagged { tag: 1, fields } => {
                inspect_value(self.vm.as_vm(), value)?;
                Ok(Some(self.report_error_value(&fields[0])))
            }
            _ => Ok(None),
        }
    }

    fn report_error_value(&self, value: &Value) -> Vec<String> {
        error_display::runtime_value_error_lines_with_registry_and_stack_trace(
            self.vm.as_vm(),
            value,
            &self.sources,
            self.repl_source_id,
            self.error_display_mode,
            self.stack_trace_display_mode,
        )
    }

    fn bump_line(&mut self, value: Option<Value>, meta: Option<forge::ChunkMeta>) {
        self.results.push(value);
        self.result_metas.push(meta);
        self.next_line += 1;
    }

    fn help_lines() -> Vec<String> {
        repl_command_help_lines()
    }

    fn doc_help_lines() -> Vec<String> {
        repl_command_topic_help_lines("doc").expect(":doc should have topic help")
    }

    fn sig_help_lines() -> Vec<String> {
        repl_command_topic_help_lines("sig").expect(":sig should have topic help")
    }

    fn info_help_lines() -> Vec<String> {
        repl_command_topic_help_lines("info").expect(":info should have topic help")
    }

    fn type_help_lines() -> Vec<String> {
        repl_command_topic_help_lines("type").expect(":type should have topic help")
    }

    fn facet_help_lines() -> Vec<String> {
        repl_command_topic_help_lines("facet").expect(":facet should have topic help")
    }

    fn handle_help(&self, topic: Option<&str>) -> Vec<String> {
        let Some(topic) = topic.map(str::trim).filter(|topic| !topic.is_empty()) else {
            return Self::help_lines();
        };
        match repl_command_topic_help_lines(topic) {
            Some(lines) => lines,
            None => {
                let other = topic.strip_prefix(':').unwrap_or(topic);
                let mut rendered = vec![format!("No help found for :{}", other)];
                rendered.push("Type :help for available REPL commands.".to_string());
                rendered
            }
        }
    }

    fn plain(lines: Vec<String>) -> ReplResult {
        ReplResult::plain(lines)
    }

    fn styled(lines: Vec<String>) -> ReplResult {
        ReplResult::styled(lines)
    }

    fn take_repl_host_io_lines(&mut self) -> (Vec<String>, Vec<String>) {
        (
            self.vm.take_repl_host_stdout(),
            self.vm.take_repl_host_stderr(),
        )
    }

    fn repl_command_diagnostic(
        &self,
        source: &str,
        message: impl Into<String>,
        span: Span,
        reason: diagnostics::ReplDiagnosticReason,
        help: Option<String>,
        summary_tail: Vec<String>,
    ) -> ReplResult {
        let mut spec = diagnostics::repl_command_parse_error_spec(source, message, span, reason);
        if let Some(help) = help {
            spec.help = Some(help);
        }
        let rendered =
            error_display::diagnostic_lines("REPL", source, &spec, self.error_display_mode);
        ReplResult::diagnostic(rendered, summary_tail)
    }

    fn repl_query_diagnostic(
        &self,
        source: &str,
        message: impl Into<String>,
        span: Span,
        reason: diagnostics::ReplDiagnosticReason,
        help: Option<String>,
    ) -> ReplResult {
        let mut spec = diagnostics::repl_query_parse_error_spec(source, message, span, reason);
        if let Some(help) = help {
            spec.help = Some(help);
        }
        let rendered =
            error_display::diagnostic_lines("REPL", source, &spec, self.error_display_mode);
        ReplResult::diagnostic(rendered, Vec::new())
    }

    fn query_diagnostic_reason(
        reason: CommandQueryParseErrorReason,
    ) -> diagnostics::ReplDiagnosticReason {
        use diagnostics::ReplDiagnosticReason as Target;
        match reason {
            CommandQueryParseErrorReason::Empty => Target::QueryEmpty,
            CommandQueryParseErrorReason::UnsupportedSymbol
            | CommandQueryParseErrorReason::UnsupportedForm => Target::QueryUnsupported,
        }
    }

    fn handle_doc(&self, symbol: &str) -> ReplResult {
        let trimmed = symbol.trim();
        if sindr::reflection::Reflection::from_name(trimmed).is_some() {
            if let Some(entry) = self.docs.iter().find(|entry| {
                entry.kind == DocKind::Function
                    && entry.qualified_name == format!("Bootstrap::{trimmed}")
            }) {
                return ReplResult::ok(Self::doc_resolved_output(entry));
            }
        }
        if trimmed.is_empty() {
            return Self::plain(Self::doc_help_lines());
        }
        match parse_repl_query(trimmed) {
            Ok(ReplQuery::Symbol(symbol)) => self.handle_doc_symbol(trimmed, &symbol),
            Ok(ReplQuery::FacetRootDoc(symbol)) => self.handle_facet_root_doc(&symbol),
            Ok(ReplQuery::FieldPath(symbol)) => Self::plain(vec![format!(
                "`{}` is not a documentation target. Fields do not have standalone declaration documentation. Use `:info {}` or `:facet {}`.",
                symbol.source,
                symbol.source.split('.').next().unwrap_or(&symbol.source),
                symbol.source
            )]),
            Err(err) => self.repl_query_diagnostic(
                &format!(":doc {trimmed}"),
                err.message().to_string(),
                err.span(),
                Self::query_diagnostic_reason(err.reason()),
                Some("Accepted forms: symbol, Facet root, or field path.".to_string()),
            ),
        }
    }

    fn facet_root_kind_for_symbol(&self, symbol: &str) -> Option<sindr::names::FacetRootKind> {
        if let Some(decl) = self.visible_declaration(symbol) {
            // Concrete Error roots carry a stored Payload schema. Their path
            // consumption remains subject to Scar's local identity checks.
            return match decl.kind {
                sigil::DeclarationKind::Deferror => Some(sindr::names::FacetRootKind::TypeRoot),
                sigil::DeclarationKind::Struct
                | sigil::DeclarationKind::Record
                | sigil::DeclarationKind::Enum
                | sigil::DeclarationKind::BuiltinType => {
                    // Struct/Record paths follow their declaration schema, even
                    // when builtin signatures reserve the name (e.g. Duration).
                    if matches!(
                        decl.kind,
                        sigil::DeclarationKind::BuiltinType | sigil::DeclarationKind::Enum
                    ) {
                        if let Some(info) =
                            sindr::names::builtin_symbol_identity_info(&decl.fq_name)
                        {
                            return info.capabilities.facet_root_path;
                        }
                    }
                    surtr_analysis::symbol_capabilities_for_declaration_entry(
                        self.sigil_session.owner_registry(),
                        decl,
                    )
                    .and_then(|capabilities| capabilities.facet_root_path)
                }
                _ => None,
            };
        }
        if self.sigil_session.lookup_uid(symbol).is_some() {
            return None;
        }
        sindr::names::builtin_symbol_identity_info(symbol)
            .and_then(|info| info.capabilities.facet_root_path)
    }

    fn handle_facet_root_doc(&self, ty: &str) -> ReplResult {
        let kind = self.facet_root_kind_for_symbol(ty);
        let Some(kind) = kind else {
            return Self::plain(vec![format!("{ty} is not a Facet path root.")]);
        };
        let root_form = match kind {
            sindr::names::FacetRootKind::Tuple => "Tuple._N",
            sindr::names::FacetRootKind::List => "List.[index]",
            sindr::names::FacetRootKind::HashMap => "HashMap.[key]",
            sindr::names::FacetRootKind::TypeRoot => "Ty.segment",
        };
        ReplResult::ok(ReplOutput::DocResolved {
            symbol: format!("Facet.{ty}"),
            signature: None,
            summary: Some(format!("Facet root for {ty}.")),
            source_snippet: Some(format!(
                "`{ty}` is a Facet path root. Use `{root_form}` to build a path.\nUse `:info {ty}` for field policies and `:facet {ty}.segment` for path inspection."
            )),
            details: Vec::new(),
        })
    }

    fn handle_doc_symbol(&self, source_symbol: &str, symbol: &str) -> ReplResult {
        if let Some(owner) = symbol.strip_suffix('!') {
            if let Some(decl) = self.private_declaration(owner) {
                return ReplResult::ok(Self::private_doc_output(decl));
            }
            if let Some(decl) = self.visible_declaration(owner) {
                match decl.kind {
                    sigil::DeclarationKind::Struct => {
                        let extractor = format!("{}::deconstruct", decl.fq_name);
                        return self.handle_doc_symbol(&extractor, &extractor);
                    }
                    sigil::DeclarationKind::Record
                    | sigil::DeclarationKind::Deferror
                    | sigil::DeclarationKind::Enum => {
                        return Self::plain(vec![format!("`{symbol}` is a pattern query. Use `:doc {owner}` for type documentation.")]);
                    }
                    _ => {}
                }
            }
        }
        if symbol == "Tuple" {
            return ReplResult::ok(Self::tuple_doc_output());
        }
        if symbol == "Closure" {
            if let Some(entry) = self.closure_doc_entry() {
                return ReplResult::ok(Self::doc_resolved_output(entry));
            }
        }
        if let Some(entry) = self.special_form_doc_entry(symbol) {
            return ReplResult::ok(Self::doc_resolved_output(entry));
        }
        if !Self::is_qualified_symbol(source_symbol) {
            if let Some(binding) = self.binding_info(source_symbol) {
                if let Some(result) = self.handle_doc_binding(source_symbol) {
                    return result;
                }
                if let Some(type_symbol) = Self::binding_doc_type_symbol(binding) {
                    return self.handle_doc_symbol(&type_symbol, &type_symbol);
                }
            }
        }
        let canonical = self
            .visible_helper_doc_alias(symbol)
            .unwrap_or_else(|| Self::canonical_symbol(symbol).to_string());
        let canonical = self
            .visible_declaration(&canonical)
            .map(|declaration| declaration.fq_name.clone())
            .unwrap_or(canonical);
        let preferred_kind = Self::definition_doc_kind(&canonical);
        let matches = self
            .type_owner_doc_entries(&canonical)
            .unwrap_or_else(|| self.visible_doc_entries(&canonical, preferred_kind));

        match matches.as_slice() {
            [] => self
                .private_declaration(&canonical)
                .map(Self::private_doc_output)
                .or_else(|| {
                    self.private_declaration(symbol)
                        .map(Self::private_doc_output)
                })
                .or_else(|| self.concrete_process_alias_doc_output(&canonical))
                .or_else(|| self.undocumented_doc_output(&canonical))
                .map(|output| ReplResult::ok(output))
                .unwrap_or_else(|| {
                    if let Some(binding) = self.binding_info(source_symbol) {
                        if let Some(result) = self.handle_doc_binding(source_symbol) {
                            result
                        } else if let Some(type_symbol) = Self::binding_doc_type_symbol(binding) {
                            self.handle_doc_symbol(&type_symbol, &type_symbol)
                        } else {
                            Self::plain(vec![format!("No docs found for {}", source_symbol)])
                        }
                    } else {
                        Self::plain(vec![format!("No docs found for {}", source_symbol)])
                    }
                }),
            [entry] => ReplResult::ok(Self::doc_resolved_output(entry)),
            entries => Self::plain(Self::ambiguous_doc_lines(source_symbol, entries)),
        }
    }

    fn type_owner_doc_entries<'a>(&'a self, symbol: &str) -> Option<Vec<&'a DocEntry>> {
        let decl = self.visible_declaration(symbol)?;
        if !matches!(
            decl.kind,
            sigil::DeclarationKind::Struct
                | sigil::DeclarationKind::Record
                | sigil::DeclarationKind::Deferror
                | sigil::DeclarationKind::Enum
                | sigil::DeclarationKind::BuiltinType
                | sigil::DeclarationKind::Trait
        ) {
            return None;
        }

        let mut matches = self
            .docs
            .iter()
            .filter(|entry| {
                entry.kind == DocKind::Type
                    && crate::surface_path_name(&entry.qualified_name)
                        == crate::surface_path_name(&decl.fq_name)
            })
            .collect::<Vec<_>>();
        matches.sort_by(|a, b| a.qualified_name.cmp(&b.qualified_name));
        matches.dedup_by(|a, b| {
            a.qualified_name == b.qualified_name
                && a.kind == b.kind
                && a.signature == b.signature
                && a.doc == b.doc
        });
        Some(matches)
    }

    fn canonical_symbol(symbol: &str) -> &str {
        OPERATOR_DOC_TARGETS
            .iter()
            .find_map(|(alias, target)| (*alias == symbol).then_some(*target))
            .unwrap_or(symbol)
    }

    fn definition_doc_kind(symbol: &str) -> Option<DocKind> {
        if symbol != "and"
            && symbol != "or"
            && OPERATOR_DOC_TRAIT_ALIASES
                .iter()
                .any(|(_, trait_name)| *trait_name == symbol)
        {
            Some(DocKind::Type)
        } else {
            None
        }
    }

    fn symbol_matches(qualified_name: &str, symbol: &str) -> bool {
        let qualified_name = sindr::names::CanonicalSymbolName::new(qualified_name);
        let symbol = sindr::names::VisibleSymbolRef::new(symbol);
        symbol.matches_qualified_name(&qualified_name)
    }

    fn is_qualified_symbol(symbol: &str) -> bool {
        symbol.contains("::")
    }

    fn function_entry_is_top_level_repl_surface(&self, qualified_name: &str) -> bool {
        let qualified_name = crate::surface_path_name(qualified_name);
        qualified_name.starts_with("__Script::")
            || qualified_name.starts_with("REPL::")
            || qualified_name.starts_with("__Repl::Session::")
            || qualified_name.starts_with(&format!(
                "{}::",
                crate::surface_path_name(&self.repl_module_path)
            ))
    }

    fn visible_doc_entries<'a>(&'a self, symbol: &str, kind: Option<DocKind>) -> Vec<&'a DocEntry> {
        let mut matches = self
            .docs
            .iter()
            .filter(|entry| kind.as_ref().is_none_or(|kind| &entry.kind == kind))
            .filter(|entry| self.doc_entry_matches_visible_symbol(entry, symbol))
            .collect::<Vec<_>>();
        matches.sort_by(|a, b| a.qualified_name.cmp(&b.qualified_name));
        matches.dedup_by(|a, b| {
            a.qualified_name == b.qualified_name
                && a.kind == b.kind
                && a.signature == b.signature
                && a.doc == b.doc
        });
        matches
    }

    fn doc_entry_matches_visible_symbol(&self, entry: &DocEntry, symbol: &str) -> bool {
        if !Self::symbol_matches(&entry.qualified_name, symbol) {
            return false;
        }
        if entry.kind == DocKind::Module {
            return sindr::names::surface_path_eq(&entry.qualified_name, symbol);
        }
        if Self::is_qualified_symbol(symbol) {
            let Some(decl) = self.qualified_declaration(symbol) else {
                return sindr::names::surface_path_eq(&entry.qualified_name, symbol);
            };
            return sindr::names::surface_path_eq(&entry.qualified_name, &decl.fq_name)
                && Self::declaration_is_public_surface(decl);
        }
        self.visible_uid_matches(symbol, &entry.qualified_name)
    }

    fn qualified_declaration<'a>(&'a self, symbol: &str) -> Option<&'a sigil::DeclarationEntry> {
        self.declaration_index
            .get(symbol)
            .or_else(|| {
                self.declaration_index
                    .values()
                    .find(|entry| sindr::names::surface_path_eq(&entry.fq_name, symbol))
            })
            .or_else(|| {
                let (owner, member) = symbol.rsplit_once("::")?;
                let owner = self.visible_declaration(owner)?;
                let qualified = format!("{}::{member}", owner.fq_name);
                self.declaration_index.get(&qualified).or_else(|| {
                    self.declaration_index
                        .values()
                        .find(|entry| sindr::names::surface_path_eq(&entry.fq_name, &qualified))
                })
            })
    }

    fn visible_uid_matches(&self, visible_name: &str, qualified_name: &str) -> bool {
        let Some(visible_uid) = self.sigil_session.lookup_uid(visible_name) else {
            return false;
        };
        self.qualified_declaration(qualified_name)
            .and_then(|entry| self.sigil_session.lookup_uid(&entry.fq_name))
            .or_else(|| self.sigil_session.lookup_uid(qualified_name))
            .or_else(|| {
                self.sigil_session
                    .lookup_uid(crate::surface_path_name(qualified_name))
            })
            .is_some_and(|qualified_uid| visible_uid == qualified_uid)
    }

    fn tuple_doc_output() -> ReplOutput {
        ReplOutput::DocResolved {
            symbol: "Tuple".to_string(),
            signature: None,
            summary: Some("Tuple doc surface for tuple values and Facet paths.".to_string()),
            source_snippet: Some(
                "Tuple is the doc surface for tuple values and `Tuple._N` facet roots.\nValues use `pair._0`, `pair._1`, ... and facet paths use `Tuple._0`, `Tuple._1`, ...\nExamples:\n- pair: (String, Int)\n- pair._0\n- pair._1\n- Facet::view(Tuple._0, pair)\n- Facet::view(Tuple._1, pair)\n- Facet::set(Tuple._1, pair, 3)"
                    .to_string(),
            ),
            details: Vec::new(),
        }
    }

    fn undocumented_doc_output(&self, symbol: &str) -> Option<ReplOutput> {
        let decl = self.visible_declaration(symbol)?;
        if self.function_entry_is_top_level_repl_surface(&decl.fq_name)
            && matches!(
                decl.kind,
                sigil::DeclarationKind::Def | sigil::DeclarationKind::Extractor
            )
        {
            return None;
        }
        let signature = self.declaration_signature(decl);
        let display_fq_name = crate::surface_path_name(&decl.fq_name);
        let display_name = crate::surface_path_name(&decl.name);
        let source_snippet = if let Some(signature) = &signature {
            format!(
                "`{}` resolves in the current scope, but it does not have an `@doc` entry yet.\nAdd `@doc` immediately before the declaration.\nExample:\n@doc \"\"\"\nDescribe `{}` here.\n\"\"\"\n{}",
                display_fq_name, display_name, signature
            )
        } else {
            format!(
                "`{}` resolves in the current scope, but it does not have an `@doc` entry yet.\nAdd `@doc` at the declaration site.\nExample:\n@doc \"\"\"\nDescribe `{}` here.\n\"\"\"",
                display_fq_name, display_name
            )
        };
        Some(ReplOutput::DocResolved {
            symbol: display_fq_name.to_string(),
            signature,
            summary: Some(format!("`{}` is currently undocumented.", display_name)),
            source_snippet: Some(source_snippet),
            details: vec!["status: undocumented".to_string()],
        })
    }

    fn declaration_is_public_surface(entry: &sigil::DeclarationEntry) -> bool {
        entry.visibility == spire::ast::Visibility::Public
    }

    fn declaration_is_repl_completion_surface(entry: &sigil::DeclarationEntry) -> bool {
        Self::declaration_is_public_surface(entry)
            && !entry.hidden
            && (entry.user_callable || entry.user_importable)
    }

    fn completion_visible_owner_name(label: &str) -> bool {
        !matches!(
            crate::surface_path_name(label),
            "MatchArms"
                | "CondClauses"
                | "BulkUpdateEntries"
                | "Hole"
                | "Lazy"
                | "StandbyInit"
                | "Closure"
                | "MatchResult"
        )
    }

    fn completion_visible_module_labels(&self) -> Vec<String> {
        let mut labels = BTreeSet::new();
        for entry in self.declaration_index.values() {
            if !Self::declaration_is_public_surface(entry) || entry.hidden {
                continue;
            }
            let module_label = crate::surface_path_name(&entry.module_path);
            if Self::completion_visible_module_name(module_label) {
                labels.insert(module_label.to_string());
            }
        }
        labels.into_iter().collect()
    }

    fn completion_visible_module_name(label: &str) -> bool {
        !label.is_empty()
            && !label.contains("::")
            && !label.starts_with("__")
            && Self::completion_visible_owner_name(label)
    }

    fn parse_pid_type_name(ty: &str) -> Option<&str> {
        ty.strip_prefix("PID<")?.strip_suffix('>')
    }

    fn process_metadata_for_pid_type<'a>(
        &self,
        ty: &'a str,
    ) -> Option<(&'a str, &ReplProcessMetadata)> {
        let process_name = Self::parse_pid_type_name(ty)?;
        Some((process_name, self.lookup_process_metadata(process_name)?))
    }

    fn process_metadata_for_singleton_owner<'a>(
        &self,
        symbol: &'a str,
    ) -> Option<(&'a str, &ReplProcessMetadata)> {
        if Self::is_qualified_symbol(symbol) {
            return None;
        }
        let metadata = self.lookup_process_metadata(symbol)?;
        (metadata.instance == spire::ast::ProcessInstance::Singleton).then_some((symbol, metadata))
    }

    fn process_metadata_for_owner<'a>(
        &self,
        symbol: &'a str,
    ) -> Option<(&'a str, &ReplProcessMetadata)> {
        if Self::is_qualified_symbol(symbol) {
            return None;
        }
        Some((symbol, self.lookup_process_metadata(symbol)?))
    }

    fn pid_type_from_value(value: &Value) -> Option<String> {
        match value {
            Value::Pid(pid) => Some(format!(
                "PID<{}>",
                crate::surface_rendered_name(&pid.process_name)
            )),
            _ => None,
        }
    }

    fn process_metadata_for_pid_value<'a>(
        &self,
        value: &'a Value,
    ) -> Option<(&'a str, &ReplProcessMetadata)> {
        let Value::Pid(pid) = value else {
            return None;
        };
        Some((
            pid.process_name.as_str(),
            self.lookup_process_metadata(&pid.process_name)?,
        ))
    }

    fn lookup_process_metadata(&self, name: &str) -> Option<&ReplProcessMetadata> {
        self.process_metadata.get(name).or_else(|| {
            self.process_metadata
                .iter()
                .find(|(key, _)| crate::surface_path_name(key) == crate::surface_path_name(name))
                .map(|(_, metadata)| metadata)
        })
    }

    fn process_hidden_doc_alias(&self, symbol: &str) -> Option<String> {
        let (owner, method) = symbol.rsplit_once("::")?;
        let metadata = self.lookup_process_metadata(owner)?;
        let hidden_owner = match (metadata.kind, method) {
            (spire::ast::ProcessKind::Agent, "pid") => "Agent",
            (spire::ast::ProcessKind::Agent, "spawn")
                if metadata.instance == spire::ast::ProcessInstance::Worker =>
            {
                "Agent"
            }
            (spire::ast::ProcessKind::GenServer, "pid") => "GenServer",
            (spire::ast::ProcessKind::GenServer, "spawn")
                if metadata.instance == spire::ast::ProcessInstance::Worker =>
            {
                "GenServer"
            }
            (
                spire::ast::ProcessKind::Supervisor
                | spire::ast::ProcessKind::RuntimeSupervisor
                | spire::ast::ProcessKind::DynamicSupervisor,
                "spawn" | "adopt" | "status" | "workers",
            ) => "Supervisor",
            _ => return None,
        };
        Some(format!("{hidden_owner}::{method}"))
    }

    fn doc_output_with_symbol_and_signature(
        entry: &DocEntry,
        symbol: String,
        signature: Option<String>,
        details: Vec<String>,
    ) -> ReplOutput {
        let summary = entry
            .doc
            .lines()
            .map(str::trim)
            .find(|line| !line.is_empty())
            .map(ToString::to_string);
        ReplOutput::DocResolved {
            symbol,
            signature,
            summary,
            source_snippet: Some(entry.doc.clone()),
            details,
        }
    }

    fn concrete_process_alias_doc_output(&self, symbol: &str) -> Option<ReplOutput> {
        let hidden_symbol = self.process_hidden_doc_alias(symbol)?;
        let entry = self.docs.iter().find(|entry| {
            entry.kind == DocKind::Function && entry.qualified_name == hidden_symbol
        })?;
        let signature = self
            .find_signature(symbol)
            .or_else(|| self.concrete_process_alias_signature(symbol))
            .map(|(_, signature)| signature);
        Some(Self::doc_output_with_symbol_and_signature(
            entry,
            symbol.to_string(),
            signature,
            Vec::new(),
        ))
    }

    fn concrete_process_alias_signature(&self, symbol: &str) -> Option<(String, String)> {
        self.process_hidden_doc_alias(symbol)?;
        if let Some((owner, metadata)) = symbol.rsplit_once("::").and_then(|(owner, method)| {
            (method == "pid").then_some((owner, self.lookup_process_metadata(owner)?))
        }) {
            if metadata.instance == spire::ast::ProcessInstance::Singleton {
                let owner = crate::surface_rendered_name(owner);
                return Some((symbol.to_string(), format!("{symbol}() -> PID<{owner}>")));
            }
        }
        self.vm
            .function_entries()
            .iter()
            .rev()
            .filter_map(|entry| {
                let qualified_name = entry.qualified_name.as_ref()?;
                let signature = entry.signature.as_ref()?;
                (crate::surface_path_name(qualified_name) == crate::surface_path_name(symbol))
                    .then(|| (qualified_name.clone(), signature.clone()))
            })
            .next()
    }

    fn process_owner_type_lines(
        &self,
        owner: &str,
        _metadata: &ReplProcessMetadata,
    ) -> Vec<String> {
        vec![
            owner.to_string(),
            format!("type: PID<{}>", crate::surface_rendered_name(owner)),
            "identity: TypeIdentity::Type".to_string(),
        ]
    }

    fn process_owner_info_lines(&self, owner: &str, metadata: &ReplProcessMetadata) -> Vec<String> {
        let owner = crate::surface_rendered_name(owner);
        vec![
            owner.clone(),
            "kind: process singleton".to_string(),
            format!("origin: {}", Self::origin_for_name(&owner)),
            format!("defined: PID<{owner}>"),
            format!("type: PID<{owner}>"),
            "identity: TypeIdentity::Type".to_string(),
            format!("instance: {:?}", metadata.instance),
            format!("runtime kind: {:?}", metadata.kind),
        ]
    }

    fn process_kind_heading(kind: spire::ast::ProcessKind) -> &'static str {
        match kind {
            spire::ast::ProcessKind::Agent => "Agent",
            spire::ast::ProcessKind::GenServer => "GenServer",
            spire::ast::ProcessKind::Supervisor => "Supervisor",
            spire::ast::ProcessKind::RuntimeSupervisor => "RuntimeSupervisor",
            spire::ast::ProcessKind::DynamicSupervisor => "DynamicSupervisor",
            spire::ast::ProcessKind::Task => "Task",
        }
    }

    fn process_handler_label(kind: spire::ast::ProcessRuntimeHandlerKind) -> &'static str {
        match kind {
            spire::ast::ProcessRuntimeHandlerKind::Init => "@init",
            spire::ast::ProcessRuntimeHandlerKind::Get => "@get",
            spire::ast::ProcessRuntimeHandlerKind::Set => "@set",
            spire::ast::ProcessRuntimeHandlerKind::Call => "@call",
            spire::ast::ProcessRuntimeHandlerKind::Cast => "@cast",
        }
    }

    fn render_process_surface_signature(&self, owner: &str, method: &str) -> Option<String> {
        let symbol = format!("{owner}::{method}");
        let (qualified_name, signature) = self
            .find_signature(&symbol)
            .or_else(|| self.concrete_process_alias_signature(&symbol))?;
        let rendered = Self::render_signature_with_qualified_name(&qualified_name, signature);
        let owner_prefix = format!("{}::", crate::surface_rendered_name(owner));
        Some(
            rendered
                .strip_prefix(&owner_prefix)
                .unwrap_or(&rendered)
                .to_string(),
        )
    }

    fn prepend_pid_param_to_signature(signature: &str, owner: &str) -> Option<String> {
        let (head, tail) = signature.split_once('(')?;
        let (params, rest) = tail.rsplit_once(')')?;
        let pid_param = format!("pid: PID<{}>", crate::surface_rendered_name(owner));
        let params = params.trim();
        let new_params = if params.is_empty() {
            pid_param
        } else {
            format!("{pid_param}, {params}")
        };
        Some(format!("{head}({new_params}){rest}"))
    }

    fn render_process_message_signature(
        &self,
        owner: &str,
        metadata: &ReplProcessMetadata,
        method: &str,
    ) -> Option<String> {
        let signature = self.render_process_surface_signature(owner, method)?;
        if metadata.instance == spire::ast::ProcessInstance::Singleton {
            return Self::prepend_pid_param_to_signature(&signature, owner);
        }
        Some(signature)
    }

    fn render_process_init_summary_signature(&self, owner: &str, method: &str) -> Option<String> {
        let signature = self.render_process_surface_signature(owner, method)?;
        let pid_return = format!("PID<{}>", crate::surface_rendered_name(owner));
        let result_return = format!("Result<{pid_return}>");
        Some(signature.replace(&format!("-> {pid_return}"), &format!("-> {result_return}")))
    }

    fn process_owner_sig_summary_lines(
        &self,
        owner: &str,
        metadata: &ReplProcessMetadata,
    ) -> Option<Vec<String>> {
        let owner = crate::surface_rendered_name(owner);
        let mut lines = vec![format!(
            "{} {}",
            Self::process_kind_heading(metadata.kind),
            owner
        )];

        let init_spec = metadata
            .handler_specs
            .iter()
            .find(|spec| spec.kind == spire::ast::ProcessRuntimeHandlerKind::Init)?;
        if let Some(init_sig) = self.render_process_init_summary_signature(&owner, &init_spec.name)
        {
            lines.push(format!(
                "{} {}",
                Self::process_handler_label(init_spec.kind),
                init_sig
            ));
        }
        if metadata.instance == spire::ast::ProcessInstance::Singleton {
            if let Some(pid_sig) = self.render_process_surface_signature(&owner, "pid") {
                lines.push(format!("@pid {pid_sig}"));
            }
        }
        for spec in &metadata.handler_specs {
            if spec.kind == spire::ast::ProcessRuntimeHandlerKind::Init {
                continue;
            }
            if let Some(sig) = self.render_process_message_signature(&owner, metadata, &spec.name) {
                lines.push(format!(
                    "{} {}",
                    Self::process_handler_label(spec.kind),
                    sig
                ));
            }
        }
        Some(lines)
    }

    fn process_pid_binding_sig_summary_lines(
        &self,
        owner: &str,
        metadata: &ReplProcessMetadata,
    ) -> Option<Vec<String>> {
        let owner = crate::surface_rendered_name(owner);
        let mut lines = vec![format!("PID<{owner}> messaging")];
        for spec in &metadata.handler_specs {
            if spec.kind == spire::ast::ProcessRuntimeHandlerKind::Init {
                continue;
            }
            if let Some(sig) = self.render_process_message_signature(&owner, metadata, &spec.name) {
                lines.push(format!(
                    "{} {}",
                    Self::process_handler_label(spec.kind),
                    sig
                ));
            }
        }
        (lines.len() > 1).then_some(lines)
    }

    fn method_trait_alias(symbol: &str) -> Option<&'static str> {
        METHOD_DOC_TRAIT_ALIASES
            .iter()
            .find_map(|(method, trait_name)| (*method == symbol).then_some(*trait_name))
    }

    fn compare_method_doc_target(symbol: &str) -> Option<&'static str> {
        COMPARE_METHOD_DOC_TARGETS
            .iter()
            .find_map(|(method, target)| (*method == symbol).then_some(*target))
    }

    fn visible_helper_doc_alias(&self, symbol: &str) -> Option<String> {
        if let Some(target) = Self::compare_method_doc_target(symbol) {
            return self.visible_compare_method_doc_alias(symbol).or_else(|| {
                self.visible_declaration(symbol)
                    .is_none()
                    .then(|| target.to_string())
            });
        }
        self.visible_helper_trait_alias(symbol)
    }

    fn visible_compare_method_doc_alias(&self, symbol: &str) -> Option<String> {
        let target = Self::compare_method_doc_target(symbol)?;
        let trait_name = Self::method_trait_alias(symbol)?;
        let decl = self.visible_declaration(symbol)?;
        if decl.kind != sigil::DeclarationKind::TraitMethod {
            return None;
        }
        let (owner_fq_name, _) = decl.fq_name.rsplit_once("::")?;
        let owner = self.declaration_index.get(owner_fq_name)?;
        (owner.kind == sigil::DeclarationKind::Trait
            && owner.auto_import
            && owner.name == trait_name)
            .then(|| target.to_string())
    }

    fn visible_helper_trait_alias(&self, symbol: &str) -> Option<String> {
        let trait_name = Self::method_trait_alias(symbol)?;
        let decl = self.visible_declaration(symbol)?;
        if decl.kind != sigil::DeclarationKind::TraitMethod {
            return None;
        }
        let (owner_fq_name, _) = decl.fq_name.rsplit_once("::")?;
        let owner = self.declaration_index.get(owner_fq_name)?;
        (owner.kind == sigil::DeclarationKind::Trait
            && owner.auto_import
            && owner.name == trait_name)
            .then(|| format!("{owner_fq_name}::{symbol}"))
    }

    fn visible_declaration<'a>(&'a self, symbol: &str) -> Option<&'a sigil::DeclarationEntry> {
        if Self::is_qualified_symbol(symbol) {
            let entry = self.qualified_declaration(symbol)?;
            return Self::declaration_is_public_surface(entry).then_some(entry);
        }
        if let Some(visible_uid) = self.sigil_session.lookup_uid(symbol) {
            return self.declaration_index.values().find(|entry| {
                Self::declaration_is_public_surface(entry)
                    && (entry.name == symbol
                        || entry
                            .name
                            .rsplit("::")
                            .next()
                            .is_some_and(|tail| tail == symbol))
                    && self.sigil_session.lookup_uid(&entry.fq_name) == Some(visible_uid)
            });
        }

        // Builtin types intentionally do not enter the value scope, but they
        // remain public declarations and must still be addressable by :doc.
        // Resolve the bare type name directly from the declaration index only
        // after the ordinary scope lookup has found nothing, preserving local
        // binding shadowing for all scope-visible declarations.
        self.declaration_index.values().find(|entry| {
            entry.kind == sigil::DeclarationKind::BuiltinType
                && Self::declaration_is_public_surface(entry)
                && sindr::names::surface_path_eq(&entry.fq_name, symbol)
        })
    }

    fn private_declaration<'a>(&'a self, symbol: &str) -> Option<&'a sigil::DeclarationEntry> {
        if Self::is_qualified_symbol(symbol) {
            let entry = self.qualified_declaration(symbol)?;
            return (!Self::declaration_is_public_surface(entry)).then_some(entry);
        }
        let visible_uid = self.sigil_session.lookup_uid(symbol)?;
        self.declaration_index.values().find(|entry| {
            !Self::declaration_is_public_surface(entry)
                && (entry.name == symbol
                    || entry
                        .name
                        .rsplit("::")
                        .next()
                        .is_some_and(|tail| tail == symbol))
                && self.sigil_session.lookup_uid(&entry.fq_name) == Some(visible_uid)
        })
    }

    fn private_doc_output(entry: &sigil::DeclarationEntry) -> ReplOutput {
        Self::plain(vec![
            format!(
                "`{}` is private and cannot be queried with `:doc`.",
                crate::surface_path_name(&entry.fq_name)
            ),
            "Add `@doc` only to public declarations.".to_string(),
        ])
        .output
    }

    fn private_sig_output(entry: &sigil::DeclarationEntry) -> ReplOutput {
        Self::plain(vec![
            format!(
                "`{}` is private and cannot be queried with `:sig`.",
                crate::surface_path_name(&entry.fq_name)
            ),
            "Only public declarations are visible to REPL signature lookup.".to_string(),
        ])
        .output
    }

    fn declaration_signature(&self, decl: &sigil::DeclarationEntry) -> Option<String> {
        match decl.kind {
            sigil::DeclarationKind::Struct => Some(crate::format_struct_signature(
                crate::surface_path_name(&decl.name),
            )),
            sigil::DeclarationKind::Record => Some(crate::format_record_signature(
                crate::surface_path_name(&decl.name),
            )),
            sigil::DeclarationKind::Deferror => self
                .find_signature(&decl.fq_name)
                .map(|(_, signature)| crate::surface_rendered_name(&signature)),
            sigil::DeclarationKind::Enum => {
                Some(format!("defenum {}", crate::surface_path_name(&decl.name)))
            }
            sigil::DeclarationKind::EnumVariant => {
                self.enum_variant_signature_entry(decl)
                    .map(|(qualified_name, signature)| {
                        Self::render_signature_with_qualified_name(&qualified_name, signature)
                    })
            }
            sigil::DeclarationKind::BuiltinType => {
                Some(format!("type {}", crate::surface_path_name(&decl.name)))
            }
            _ => self
                .find_signature(&decl.fq_name)
                .map(|(qualified_name, signature)| {
                    Self::render_signature_with_qualified_name(&qualified_name, signature)
                }),
        }
    }

    fn declaration_signature_entry(
        &self,
        decl: &sigil::DeclarationEntry,
    ) -> Option<(String, String)> {
        match decl.kind {
            sigil::DeclarationKind::EnumVariant => self.enum_variant_signature_entry(decl),
            _ => self.find_signature(&decl.fq_name),
        }
    }

    fn enum_variant_signature_entry(
        &self,
        decl: &sigil::DeclarationEntry,
    ) -> Option<(String, String)> {
        if decl.kind != sigil::DeclarationKind::EnumVariant {
            return None;
        }
        if let Some(signature) = self.find_signature(&decl.fq_name) {
            return Some(signature);
        }
        let (owner, _) = decl.fq_name.rsplit_once("::")?;
        let variant = self
            .scar_session
            .enum_variants_of(owner)?
            .iter()
            .find(|variant| {
                variant.short_name == decl.name
                    || variant.constructor_name == decl.name
                    || decl.name.ends_with(&format!("::{}", variant.short_name))
            })?;
        let params = variant
            .payload
            .iter()
            .map(Self::ty_to_string)
            .collect::<Vec<_>>()
            .join(", ");
        let signature = format!(
            "{}({params}) -> {}",
            crate::surface_path_name(&decl.fq_name),
            Self::ty_to_string(&variant.enum_ty)
        );
        Some((decl.fq_name.clone(), signature))
    }

    fn doc_resolved_output(entry: &DocEntry) -> ReplOutput {
        Self::doc_resolved_output_with_details(entry, Vec::new())
    }

    fn doc_resolved_output_with_details(entry: &DocEntry, details: Vec<String>) -> ReplOutput {
        let summary = entry
            .doc
            .lines()
            .map(str::trim)
            .find(|line| !line.is_empty())
            .map(ToString::to_string);
        ReplOutput::DocResolved {
            symbol: crate::surface_path_name(&entry.qualified_name).to_string(),
            signature: Self::display_signature_for_doc_entry(entry),
            summary,
            source_snippet: Some(entry.doc.clone()),
            details,
        }
    }

    fn display_signature_for_doc_entry(entry: &DocEntry) -> Option<String> {
        entry
            .signature
            .clone()
            .filter(|signature| Self::trait_signature_methods(signature).is_empty())
            .map(|signature| crate::surface_rendered_name(&signature))
    }

    fn handle_doc_binding(&self, symbol: &str) -> Option<ReplResult> {
        let binding = self.binding_info(symbol)?;
        let kind = self.binding_callable_kind(binding)?;
        let value = self.vm.get_local(binding.slot_id)?;

        let entry = if self
            .binding_callable_ty(binding)
            .as_ref()
            .is_some_and(Self::is_extractor_closure_query_type)
        {
            self.matching_doc_entries(
                sindr::names::TypeName::ExtractorClosure.as_str(),
                Some(DocKind::Type),
            )
            .into_iter()
            .next()?
        } else {
            match kind {
                forge::ReplCallableKind::Capture => {
                    let Some(entry) = self.capture_doc_entry(&value) else {
                        return Some(Self::plain(vec![format!(
                            "No documentation found for {symbol}."
                        )]));
                    };
                    entry
                }
                forge::ReplCallableKind::Closure => self.closure_doc_entry()?,
            }
        };

        Some(ReplResult::ok(Self::doc_resolved_output_with_details(
            entry,
            self.binding_doc_details(symbol, binding, &value, kind),
        )))
    }

    fn binding_doc_type_symbol(binding: &forge::BindingInfo) -> Option<String> {
        if let Some(ty) = parse_binding_query_type(&binding.ty) {
            match ty {
                AstTy::Named(_, name) => return Some(name),
                AstTy::Generic(_, name, _) => return Some(name),
                _ => {}
            }
        }
        let surface = crate::surface_rendered_name(&binding.ty);
        let head = surface.split('<').next().unwrap_or(surface.as_str()).trim();
        Self::is_type_lookup_symbol(head).then(|| head.to_string())
    }

    fn closure_doc_entry(&self) -> Option<&DocEntry> {
        self.matching_doc_entries("Closure", Some(DocKind::Type))
            .into_iter()
            .next()
    }

    fn capture_doc_entry(&self, value: &Value) -> Option<&DocEntry> {
        use sindr::ir::{CallableTemplateDirectTarget, CallableTemplateKind};
        use sindr::runtime::CallableTarget;
        let callable = Self::callable_origin_source(value)?;
        if let (Some(module), Some(name)) = (
            callable.metadata.module.as_deref(),
            callable.metadata.name.as_deref(),
        ) {
            let qualified = format!("{}::{name}", crate::surface_path_name(module));
            if let Some(doc) = self.callable_doc_snapshots.trait_methods.get(&qualified) {
                return doc.as_ref();
            }
        }
        let target = callable
            .metadata
            .delegate_function
            .map(CallableTarget::Function)
            .unwrap_or_else(|| callable.target.clone());
        let function = match target {
            CallableTarget::Function(function) => Some(function),
            CallableTarget::Template(template) => match &self
                .vm
                .bytecode()
                .callable_templates
                .iter()
                .find(|entry| entry.template_id == template)?
                .kind
            {
                CallableTemplateKind::PartialDirectCall { target, .. }
                | CallableTemplateKind::InjectDirectCall { target, .. } => match target {
                    CallableTemplateDirectTarget::Function(function) => Some(*function),
                    CallableTemplateDirectTarget::Builtin(_) => None,
                },
                CallableTemplateKind::ComposeDirect { .. } => return None,
            },
            CallableTarget::Builtin(_) => None,
        };
        if let Some(function) = function {
            let entry = self.vm.function_entries().get(function as usize)?;
            let qualified = entry.qualified_name.as_deref()?;
            return self.callable_doc_snapshots.functions.get(&(
                crate::surface_path_name(qualified).to_string(),
                entry.span_start,
                entry.span_end,
            ));
        }
        let module = callable.metadata.module.as_deref()?;
        let name = callable.metadata.name.as_deref()?;
        let qualified = format!("{module}::{name}");
        self.docs.iter().find(|entry| {
            entry.kind == DocKind::Function
                && sindr::names::surface_path_eq(&entry.qualified_name, &qualified)
        })
    }

    fn binding_doc_details(
        &self,
        symbol: &str,
        binding: &forge::BindingInfo,
        value: &Value,
        kind: forge::ReplCallableKind,
    ) -> Vec<String> {
        match kind {
            forge::ReplCallableKind::Capture => {
                let mut details = vec![format!("binding: {symbol}")];
                details.push(format!(
                    "type: {}",
                    crate::surface_rendered_name(&binding.ty)
                ));
                if let Value::Callable(callable) = value {
                    let capture_count = callable.lexical_captures.len();
                    if capture_count == 0 {
                        details.push("captures: none".to_string());
                    } else {
                        details.push(format!("captures: {capture_count} bound value(s)"));
                    }
                }
                if let Some(derived) = self.callable_origin_label(value) {
                    details.push(format!("derived from: {derived}"));
                }
                details
            }
            forge::ReplCallableKind::Closure => self.closure_binding_doc_details(symbol, binding),
        }
    }

    fn closure_binding_doc_details(
        &self,
        symbol: &str,
        binding: &forge::BindingInfo,
    ) -> Vec<String> {
        let rendered_ty = crate::surface_rendered_name(&binding.ty);
        let mut details = vec![format!("type: {rendered_ty}")];
        if let Some(example) = Self::closure_binding_example(symbol, &rendered_ty) {
            details.push(format!("example: {example}"));
        }
        details
    }

    fn closure_binding_example(symbol: &str, signature: &str) -> Option<String> {
        let ty = parse_binding_query_type(signature)?;
        let AstTy::Func(_, params, ret) = ty else {
            return None;
        };
        let args = params
            .iter()
            .map(format_query_ty)
            .collect::<Vec<_>>()
            .join(", ");
        Some(format!(
            "ret: {} = {}({args})",
            format_query_ty(ret.as_ref()),
            symbol
        ))
    }

    fn callable_origin_label(&self, value: &Value) -> Option<String> {
        let callable = Self::callable_origin_source(value)?;
        match (
            callable.metadata.module.as_deref(),
            callable.metadata.name.as_deref(),
        ) {
            (Some("<local>"), Some(name)) => Some(name.to_string()),
            (Some(module), Some(name)) => Some(format!("{module}::{name}")),
            (None, Some(name)) => Some(name.to_string()),
            _ => None,
        }
    }

    fn callee_tail(callee: &str) -> &str {
        callee.rsplit("::").next().unwrap_or(callee)
    }

    fn matching_doc_entries<'a>(
        &'a self,
        symbol: &str,
        kind: Option<DocKind>,
    ) -> Vec<&'a DocEntry> {
        let mut matches = self
            .docs
            .iter()
            .filter(|entry| kind.as_ref().is_none_or(|kind| &entry.kind == kind))
            .filter(|entry| Self::symbol_matches(&entry.qualified_name, symbol))
            .collect::<Vec<_>>();
        matches.sort_by(|a, b| a.qualified_name.cmp(&b.qualified_name));
        matches.dedup_by(|a, b| {
            a.qualified_name == b.qualified_name
                && a.kind == b.kind
                && a.signature == b.signature
                && a.doc == b.doc
        });
        matches
    }

    fn ambiguous_doc_lines(symbol: &str, entries: &[&DocEntry]) -> Vec<String> {
        let mut rendered = vec![format!("{symbol} has multiple docs:")];
        rendered.extend(
            entries
                .iter()
                .map(|entry| format!("  {}", crate::surface_path_name(&entry.qualified_name))),
        );
        rendered.push("Use a qualified name, for example `:doc Compare::compare`.".to_string());
        rendered
    }

    fn special_form_doc_entry(&self, symbol: &str) -> Option<&DocEntry> {
        if symbol == "(,)" {
            return self.docs.iter().find(|entry| {
                entry.kind == DocKind::Function && entry.qualified_name == "Bootstrap::(,)"
            });
        }
        self.docs.iter().find(|entry| {
            entry.kind == DocKind::Function
                && entry.qualified_name == format!("Bootstrap::{symbol}")
        })
    }

    fn special_form_signature_entry(&self, symbol: &str) -> Option<&SignatureEntry> {
        if symbol == "(,)" {
            return self.signatures.iter().find(|entry| {
                entry.kind == DocKind::Function && entry.qualified_name == "Bootstrap::(,)"
            });
        }
        self.signatures.iter().find(|entry| {
            entry.kind == DocKind::Function
                && entry.qualified_name == format!("Bootstrap::{symbol}")
        })
    }

    fn find_signature(&self, symbol: &str) -> Option<(String, String)> {
        if symbol == "Tuple" {
            return None;
        }
        if let Some(entry) = self.special_form_doc_entry(symbol) {
            if let Some(signature) = Self::display_signature_for_doc_entry(entry) {
                return Some((entry.qualified_name.clone(), signature));
            }
        }
        if let Some(entry) = self.special_form_signature_entry(symbol) {
            return Some((
                entry.qualified_name.clone(),
                crate::surface_rendered_name(&entry.signature),
            ));
        }
        let canonical = self
            .visible_helper_doc_alias(symbol)
            .unwrap_or_else(|| Self::canonical_symbol(symbol).to_string());
        let canonical = self
            .visible_declaration(&canonical)
            .map(|declaration| declaration.fq_name.clone())
            .unwrap_or(canonical);
        let qualified_lookup = Self::is_qualified_symbol(&canonical);
        if qualified_lookup
            && self
                .qualified_declaration(&canonical)
                .is_some_and(|entry| !Self::declaration_is_public_surface(entry))
        {
            return None;
        }
        let visible_uid = (!qualified_lookup)
            .then(|| self.sigil_session.lookup_uid(&canonical))
            .flatten();

        if let Some(entry) = self.docs.iter().rev().find(|entry| {
            if entry.kind != DocKind::Function {
                return false;
            }
            if !Self::symbol_matches(&entry.qualified_name, &canonical) {
                return false;
            }
            if qualified_lookup {
                crate::surface_path_name(&entry.qualified_name)
                    == crate::surface_path_name(&canonical)
            } else if let Some(uid) = visible_uid {
                self.sigil_session.lookup_uid(&entry.qualified_name) == Some(uid)
            } else {
                false
            }
        }) {
            if let Some(signature) = Self::display_signature_for_doc_entry(entry) {
                return Some((entry.qualified_name.clone(), signature));
            }
        }

        // Declaration signatures preserve return-only documentation error markers.
        // Runtime function types have already erased those markers.
        if let Some(entry) = self.signatures.iter().rev().find(|entry| {
            qualified_lookup
                && crate::surface_path_name(&entry.qualified_name)
                    == crate::surface_path_name(&canonical)
        }) {
            return Some((entry.qualified_name.clone(), entry.signature.clone()));
        }

        if let Some(entry) = self.signatures.iter().rev().find(|entry| {
            if !Self::symbol_matches(&entry.qualified_name, &canonical) {
                return false;
            }
            if qualified_lookup {
                crate::surface_path_name(&entry.qualified_name)
                    == crate::surface_path_name(&canonical)
            } else if self.function_entry_is_top_level_repl_surface(&entry.qualified_name) {
                true
            } else if let Some(uid) = visible_uid {
                self.sigil_session.lookup_uid(&entry.qualified_name) == Some(uid)
            } else {
                false
            }
        }) {
            return Some((entry.qualified_name.clone(), entry.signature.clone()));
        }

        if canonical == symbol {
            if let Some(found) = self
                .vm
                .function_entries()
                .iter()
                .rev()
                .filter(|entry| !entry.flags.generated)
                .find_map(|entry| {
                    let qualified_name = entry.qualified_name.as_ref()?;
                    if !Self::symbol_matches(qualified_name, &canonical) {
                        return None;
                    }
                    if qualified_lookup {
                        if crate::surface_path_name(qualified_name)
                            != crate::surface_path_name(&canonical)
                        {
                            return None;
                        }
                    } else if let Some(uid) = visible_uid {
                        if self.sigil_session.lookup_uid(qualified_name) != Some(uid) {
                            return None;
                        }
                    } else {
                        return None;
                    }
                    let signature = entry.signature.clone()?;
                    Some((qualified_name.clone(), signature))
                })
            {
                return Some(found);
            }
        }

        if let Some(found) = self
            .vm
            .function_entries()
            .iter()
            .rev()
            .filter(|entry| !entry.flags.generated)
            .find_map(|entry| {
                let qualified_name = entry.qualified_name.as_ref()?;
                if !self.function_entry_is_top_level_repl_surface(qualified_name) {
                    return None;
                }
                let surface_qualified = crate::surface_path_name(qualified_name);
                if qualified_lookup {
                    if surface_qualified != crate::surface_path_name(&canonical) {
                        return None;
                    }
                } else if surface_qualified
                    .rsplit("::")
                    .next()
                    .is_none_or(|tail| tail != crate::surface_path_name(&canonical))
                {
                    return None;
                }
                let signature = entry.signature.clone()?;
                Some((qualified_name.clone(), signature))
            })
        {
            return Some(found);
        }

        None
    }

    fn render_signature_with_qualified_name(qualified_name: &str, signature: String) -> String {
        let qualified_name = crate::surface_path_name(qualified_name);
        let signature = crate::surface_rendered_name(&signature);
        if let Some((module, tail)) = qualified_name.rsplit_once("::") {
            if signature == tail
                || signature.starts_with(&format!("{tail}("))
                || signature.starts_with(&format!("{tail}<"))
            {
                return format!("{module}::{signature}");
            }
        }
        signature
    }

    fn handle_sig(&mut self, symbol: &str) -> ReplResult {
        let trimmed = symbol.trim();
        if let Some(reflection) = sindr::reflection::Reflection::from_name(trimmed) {
            if let Some(entry) = self.signatures.iter().find(|entry| {
                entry.kind == DocKind::Function
                    && entry.qualified_name == format!("Bootstrap::{}", reflection.name())
            }) {
                return Self::styled(vec![Self::render_signature_with_qualified_name(
                    &entry.qualified_name,
                    entry.signature.clone(),
                )]);
            }
        }
        if trimmed.is_empty() {
            return Self::plain(Self::sig_help_lines());
        }
        if Self::facet_path_kind_info(trimmed).is_some() {
            return Self::plain(vec![
                format!("`{trimmed}` has no constructor signature."),
                "Facet path kinds are compiler-managed and cannot be used as values.".into(),
                format!("Use `:info {trimmed}`."),
            ]);
        }
        match parse_repl_query(trimmed) {
            Ok(ReplQuery::Symbol(symbol)) => {
                if let Some(result) = self.handle_sig_binding(symbol.source.as_str()) {
                    return result;
                }
                if let Some(result) = self.handle_sig_owner_pattern(&symbol) {
                    return result;
                }
                if let Some((owner, metadata)) =
                    self.process_metadata_for_owner(symbol.source.as_str())
                {
                    if let Some(lines) = self.process_owner_sig_summary_lines(owner, metadata) {
                        return Self::styled(lines);
                    }
                }
                if let Some(lines) = self.sig_type_owner_summary_lines(&symbol) {
                    return Self::styled(lines);
                }
                if let Some(lines) = self.builtin_literal_pattern_sig_lines(&symbol) {
                    return Self::styled(lines);
                }
                if let Some(lines) = self.trait_family_signature_lines(&symbol) {
                    return Self::styled(lines);
                }
                if let Some(lines) = self.trait_method_family_signature_lines(&symbol) {
                    return Self::styled(lines);
                }
                match self
                    .find_signature(&symbol)
                    .or_else(|| self.concrete_process_alias_signature(&symbol))
                {
                    Some((qualified_name, signature)) => {
                        let rendered =
                            Self::render_signature_with_qualified_name(&qualified_name, signature);
                        Self::styled(vec![rendered])
                    }
                    None => {
                        if let Some(entry) = self.private_declaration(trimmed) {
                            return ReplResult::ok(Self::private_sig_output(entry));
                        }
                        Self::plain(vec![
                            format!("No signature found for {}", trimmed),
                            "Try `:doc <symbol>` for docs.".to_string(),
                        ])
                    }
                }
            }
            Ok(ReplQuery::FacetRootDoc(symbol)) => Self::plain(vec![format!(
                "`Facet.{}` has no constructor signature. Use `:doc Facet.{}`.",
                symbol.source, symbol.source
            )]),
            Ok(ReplQuery::FieldPath(symbol)) => Self::plain(vec![format!(
                "`{}` has no field signature. Use `:info {}` or `:facet {}`.",
                symbol.source,
                symbol.source.split('.').next().unwrap_or(&symbol.source),
                symbol.source
            )]),
            Err(err) => self.repl_query_diagnostic(
                &format!(":sig {trimmed}"),
                err.message().to_string(),
                err.span(),
                Self::query_diagnostic_reason(err.reason()),
                Some("Accepted forms: symbol, Facet root, or field path.".to_string()),
            ),
        }
    }

    fn handle_type(&self, symbol: &str) -> ReplResult {
        let trimmed = symbol.trim();
        if trimmed.is_empty() {
            return Self::plain(Self::type_help_lines());
        }
        if !Self::is_type_lookup_symbol(trimmed) {
            return self.repl_command_diagnostic(
                &format!(":type {trimmed}"),
                format!("Invalid binding lookup target `{trimmed}`."),
                Span {
                    start: ":type ".chars().count(),
                    end: format!(":type {trimmed}").chars().count(),
                },
                diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                Some("Usage: :type <binding|singleton-owner>".to_string()),
                Vec::new(),
            );
        }
        let binding_name = trimmed;

        let Some(binding) = self.binding_info(binding_name) else {
            if let Some((owner, metadata)) = self.process_metadata_for_singleton_owner(binding_name)
            {
                return Self::styled(self.process_owner_type_lines(owner, metadata));
            }
            return Self::plain(vec![format!("No binding found for {}", trimmed)]);
        };

        if binding.facet_info.is_some() {
            return Self::styled(vec![
                binding_name.to_string(),
                format!(
                    "type: {}",
                    crate::surface_rendered_name(binding.ty.as_str())
                ),
                format!("identity: {}", self.render_type_identity(binding, None)),
            ]);
        }

        let Some(value) = self.vm.get_local(binding.slot_id) else {
            return Self::plain(vec![format!("Binding `{}` has no current value.", trimmed)]);
        };

        let rendered_ty = Self::pid_type_from_value(&value)
            .unwrap_or_else(|| crate::surface_rendered_name(binding.ty.as_str()));

        Self::styled(vec![
            binding_name.to_string(),
            format!("type: {rendered_ty}"),
            format!(
                "identity: {}",
                self.render_type_identity(binding, Some(&value))
            ),
        ])
    }

    fn handle_info(&mut self, query: &str) -> ReplResult {
        let trimmed = query.trim();
        if sindr::reflection::Reflection::from_name(trimmed).is_some()
            || sindr::reflection::Reflection::from_builtin_name(crate::surface_path_name(trimmed))
                .is_some()
        {
            return Self::plain(vec![format!(
                "Source reflection functions are not :info targets; use :doc or :sig {trimmed}."
            )]);
        }
        if trimmed.is_empty() {
            return Self::plain(Self::info_help_lines());
        }
        match parse_repl_query(trimmed) {
            Ok(ReplQuery::Symbol(symbol)) => self.handle_info_symbol(trimmed, &symbol),
            Ok(ReplQuery::FacetRootDoc(symbol)) => self.handle_info_symbol(trimmed, &symbol),
            Ok(ReplQuery::FieldPath(symbol)) => Self::plain(vec![format!(
                "`{}` is a Facet path. Use `:facet {}`.",
                symbol.source, symbol.source
            )]),
            Err(err) => self.repl_query_diagnostic(
                &format!(":info {trimmed}"),
                err.message().to_string(),
                err.span(),
                Self::query_diagnostic_reason(err.reason()),
                Some("Accepted forms: symbol, Facet root, or field path.".to_string()),
            ),
        }
    }

    fn render_facet_info(info: &forge::ReplFacetInfo) -> Vec<String> {
        let mut lines = vec![
            if info.operation.is_some() {
                "## FacetOperation".to_string()
            } else {
                "## FacetPath".to_string()
            },
            format!("type: {}", crate::surface_rendered_name(&info.ty)),
            format!(
                "stage: {}",
                match info.stage {
                    forge::ReplFacetStage::Template => "template",
                    forge::ReplFacetStage::Pending => "pending",
                }
            ),
            format!("kind: {}", info.path_kind),
            format!("source: {}", crate::surface_rendered_name(&info.source_ty)),
            format!("focus: {}", crate::surface_rendered_name(&info.focus_ty)),
            format!(
                "updated source: {}",
                crate::surface_rendered_name(&info.update_source_ty)
            ),
            format!(
                "replacement focus: {}",
                crate::surface_rendered_name(&info.update_focus_ty)
            ),
            format!(
                "full path: {}",
                crate::surface_rendered_name(&info.full_path)
            ),
            format!("facet root: {}", info.root_policy),
            format!(
                "availability in this REPL: {}",
                if info.available_in_current_scope {
                    "available"
                } else {
                    "unavailable (private path)"
                }
            ),
            "## API eligibility".to_string(),
            "## Flow".to_string(),
        ];
        if let Some(operation) = &info.operation {
            lines.insert(1, format!("operation: {}", operation.name));
            lines.insert(2, format!("kind constraint: {}", operation.kind_constraint));
            lines.insert(
                3,
                format!(
                    "result: {}",
                    crate::surface_rendered_name(&operation.result_ty)
                ),
            );
            if let Some(replacement) = &operation.replacement_ty {
                lines.insert(
                    4,
                    format!("replacement: {}", crate::surface_rendered_name(replacement)),
                );
            }
            if let Some(mapper) = &operation.mapper_ty {
                lines.insert(
                    5,
                    format!("mapper: {}", crate::surface_rendered_name(mapper)),
                );
            }
        }
        let flow_index = lines.len() - 1;
        lines.splice(flow_index..flow_index, info.api_eligibility.iter().cloned());

        let mut previous_terminal = None::<String>;
        for (index, segment) in info.segments.iter().enumerate() {
            let terminal = Self::facet_segment_terminal_name(&segment.label);
            let local_path =
                Self::render_facet_local_hop(segment, previous_terminal.as_deref(), &terminal);
            lines.push(format!("hop {}: {}", index + 1, local_path));
            lines.push(format!(
                "relation: {} -> {}",
                crate::surface_rendered_name(&segment.source_ty),
                crate::surface_rendered_name(&segment.focus_ty)
            ));
            lines.push(format!(
                "cumulative: {}",
                crate::surface_rendered_name(&segment.label)
            ));
            lines.push(format!(
                "fallible: {}",
                if segment.fallible { "yes" } else { "no" }
            ));
            lines.push(format!("reason: {}", segment.reason));
            lines.push(format!("policy: {}", segment.policy));
            previous_terminal = Some(terminal);
        }
        lines.push("## Stops".to_string());
        if info.stop_points.is_empty() {
            lines.push("none".to_string());
        } else {
            for (index, stop_point) in info.stop_points.iter().enumerate() {
                lines.push(format!("stop {}: {}", index + 1, stop_point));
            }
        }
        lines
    }

    fn facet_segment_terminal_name(label: &str) -> String {
        label.rsplit('.').next().unwrap_or(label).to_string()
    }

    fn render_facet_local_hop(
        segment: &forge::ReplFacetSegmentInfo,
        previous_terminal: Option<&str>,
        terminal: &str,
    ) -> String {
        if segment.label == format!("Tuple.{terminal}") {
            return segment.label.clone();
        }
        if segment.source_ty != "_" && !segment.source_ty.starts_with('(') {
            return format!("{}.{}", segment.source_ty, terminal);
        }
        if let Some(previous_terminal) = previous_terminal {
            return format!("{previous_terminal}.{terminal}");
        }
        segment.label.clone()
    }

    fn handle_facet(&mut self, query: &str) -> ReplResult {
        let trimmed = query.trim();
        if trimmed.is_empty() {
            return Self::plain(Self::facet_help_lines());
        }
        if let Some(binding) = self.binding_info(trimmed) {
            if let Some(facet_info) = &binding.facet_info {
                return Self::styled(Self::render_facet_info(facet_info));
            }
        }
        if self.binding_info(trimmed).is_none() {
            if let Some(kind) = self.facet_root_kind_for_symbol(trimmed) {
                return self.handle_facet_root(trimmed, kind);
            }
            let is_type = self.visible_declaration(trimmed).is_some_and(|decl| {
                matches!(
                    decl.kind,
                    sigil::DeclarationKind::BuiltinType
                        | sigil::DeclarationKind::Struct
                        | sigil::DeclarationKind::Record
                        | sigil::DeclarationKind::Enum
                        | sigil::DeclarationKind::Deferror
                )
            }) || (self.sigil_session.lookup_uid(trimmed).is_none()
                && sindr::names::builtin_symbol_identity_info(trimmed).is_some());
            if is_type {
                return Self::plain(vec![format!("{trimmed} is not a Facet path root.")]);
            }
        }
        self.handle_facet_expression(trimmed)
    }

    fn handle_facet_root(&self, symbol: &str, kind: sindr::names::FacetRootKind) -> ReplResult {
        if let Some(lines) = self.type_definition_info_lines(symbol) {
            return Self::styled(lines);
        }
        let (root_kind, selectors) = match kind {
            sindr::names::FacetRootKind::Tuple => ("tuple", vec!["Tuple._N"]),
            sindr::names::FacetRootKind::List => {
                ("list", vec!["List.[index]", "List.[start..end]"])
            }
            sindr::names::FacetRootKind::HashMap => ("hashmap", vec!["HashMap.[key]"]),
            sindr::names::FacetRootKind::TypeRoot => {
                return Self::plain(vec![format!(
                    "Facet root metadata is missing for {symbol}."
                )]);
            }
        };
        let mut lines = vec![
            symbol.to_string(),
            format!("kind: {root_kind}"),
            "selectors:".into(),
        ];
        lines.extend(
            selectors
                .into_iter()
                .map(|selector| format!("- {selector}")),
        );
        Self::styled(lines)
    }

    fn handle_facet_expression(&mut self, source_query: &str) -> ReplResult {
        let original_pending = self.pending.clone();
        let original_source = self
            .sources
            .source(self.repl_source_id)
            .unwrap_or("")
            .to_string();
        let query_source = format!("{source_query}\n");
        let sigil_cp = self.sigil_session.checkpoint();
        let scar_cp = self.scar_session.checkpoint();
        let forge_cp = self.forge_session.checkpoint();

        self.sources
            .update_source(self.repl_source_id, query_source.clone());

        let result = self.handle_facet_expression_inner(source_query, &query_source);

        self.sigil_session.rollback(sigil_cp);
        self.scar_session.rollback(scar_cp);
        self.forge_session.rollback(forge_cp);
        self.pending = original_pending;
        self.sources
            .update_source(self.repl_source_id, original_source);

        result
    }

    fn handle_facet_expression_inner(
        &mut self,
        source_query: &str,
        query_source: &str,
    ) -> ReplResult {
        let ast = match spire::parse_with_context(
            query_source,
            crate::derive_parser_context(
                self.repl_source_id.0,
                SourceKind::ReplChunk,
                CompileUnitKind::Repl,
                None,
            ),
        ) {
            Ok(ast) => ast,
            Err(e) => {
                let spec = diagnostics::parse_error_spec(self.repl_source_id, query_source, &e);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    self.repl_source_id,
                    &spec,
                    self.error_display_mode,
                );
                return ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: format!(":facet {source_query}"),
                    rendered,
                });
            }
        };

        let resolved = match self.sigil_session.resolve(ast.clone()) {
            Ok(r) => r,
            Err(e) => {
                let (source_id, spec) = self.resolve_diagnostic_for_repl(&e, self.repl_source_id);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    source_id,
                    &spec,
                    self.error_display_mode,
                );
                return ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: format!(":facet {source_query}"),
                    rendered,
                });
            }
        };

        let mut context = Self::typecheck_context_for_source(SourceKind::ReplChunk);
        context.allow_private_facet_inspection = true;
        let typed = match self.scar_session.typecheck_with_context(resolved, context) {
            Ok(t) => t,
            Err(e) => {
                let spec = type_error_spec_from_scar(
                    &self.sources,
                    self.repl_source_id,
                    &e,
                    e.span.clone(),
                );
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    self.repl_source_id,
                    &spec,
                    self.error_display_mode,
                );
                return ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: format!(":facet {source_query}"),
                    rendered,
                });
            }
        };

        let Some(root) = typed.first() else {
            return Self::plain(Self::facet_help_lines());
        };
        let Some(info) = forge::repl_facet_info_for_node(root) else {
            return Self::plain(vec![format!(
                "`{source_query}` is not a FacetPath binding or expression."
            )]);
        };

        Self::styled(Self::render_facet_info(&info))
    }

    fn handle_info_symbol(&self, source_query: &str, symbol: &str) -> ReplResult {
        if let Some(lines) = Self::facet_path_kind_info(symbol) {
            return Self::styled(lines);
        }
        if let Some(lines) = self.type_definition_info_lines(symbol) {
            return Self::styled(lines);
        }
        if let Some(binding) = self.binding_info(symbol) {
            return self.render_info_binding(symbol, binding);
        }

        if let Some((owner, metadata)) = self.process_metadata_for_singleton_owner(symbol) {
            return Self::styled(self.process_owner_info_lines(owner, metadata));
        }

        if let Some((qualified_name, signature)) = self.find_signature(symbol) {
            let kind = self
                .visible_declaration(symbol)
                .map(|decl| match decl.kind {
                    sigil::DeclarationKind::Enum => "enum",
                    sigil::DeclarationKind::Struct
                    | sigil::DeclarationKind::Record
                    | sigil::DeclarationKind::BuiltinType
                    | sigil::DeclarationKind::Trait => "type",
                    _ => "function",
                })
                .unwrap_or("function");
            return Self::styled(vec![
                qualified_name.clone(),
                format!("kind: {kind}"),
                format!("origin: {}", Self::origin_for_name(&qualified_name)),
                format!(
                    "defined: {}",
                    Self::render_signature_with_qualified_name(&qualified_name, signature)
                ),
            ]);
        }

        Self::plain(vec![format!("No signature found for {}", source_query)])
    }

    fn render_member_rows(mut rows: Vec<(Option<String>, String, String)>) -> Vec<String> {
        rows.sort_by(|left, right| left.1.cmp(&right.1));
        let policy_width = rows
            .iter()
            .filter_map(|row| row.0.as_ref())
            .map(String::len)
            .max()
            .unwrap_or(0);
        let name_width = rows.iter().map(|row| row.1.len()).max().unwrap_or(0);
        rows.into_iter()
            .map(|(policy, name, ty)| match policy {
                Some(policy) => format!("- {policy:policy_width$} {name:name_width$}: {ty}"),
                None => format!("- {name:name_width$}: {ty}"),
            })
            .collect()
    }

    fn type_definition_info_lines(&self, symbol: &str) -> Option<Vec<String>> {
        let decl = self.visible_declaration(symbol)?;
        self.facet_root_kind_for_symbol(symbol)?;
        let (kind, heading) = match decl.kind {
            sigil::DeclarationKind::Struct => ("struct", "fields:"),
            sigil::DeclarationKind::Record => ("record", "fields:"),
            sigil::DeclarationKind::Enum => ("enum", "variants:"),
            sigil::DeclarationKind::Deferror => ("error", "fields:"),
            sigil::DeclarationKind::BuiltinType
                if crate::surface_path_name(&decl.fq_name) == "Error" =>
            {
                ("error", "fields:")
            }
            _ => return None,
        };
        let error = kind == "error";
        let mut rows = Vec::new();
        if error {
            rows.extend(
                ["kind", "message"]
                    .into_iter()
                    .map(|name| (None, name.to_string(), "String".to_string())),
            );
        }
        let def = if decl.kind == sigil::DeclarationKind::BuiltinType {
            None
        } else {
            Some(self.scar_session.lookup_type_def(&decl.fq_name)?)
        };
        if let Some(def) = def {
            if kind == "enum" {
                for variant in self.scar_session.enum_variants_of(&decl.fq_name)? {
                    let focus = match variant.payload.as_slice() {
                        [] => Ty::Unit,
                        [ty] => ty.clone(),
                        payload => Ty::Tuple(payload.to_vec()),
                    };
                    rows.push((
                        None,
                        variant.short_name.clone(),
                        Self::definition_ty_display(&focus, def),
                    ));
                }
            } else {
                for (field, ty) in &def.fields {
                    let policy = (kind == "struct").then(|| {
                        let mut policy = if def.private_fields.contains(field) {
                            "private"
                        } else {
                            "public"
                        }
                        .to_string();
                        if def.readonly_fields.contains(field) {
                            policy.push_str(" readonly");
                        }
                        policy
                    });
                    rows.push((policy, field.clone(), Self::definition_ty_display(ty, def)));
                }
            }
        }
        let mut lines = vec![
            crate::surface_path_name(&decl.fq_name).to_string(),
            format!("kind: {kind}"),
            format!("facet root: {}", if error { "readonly" } else { "public" }),
            heading.to_string(),
        ];
        lines.extend(Self::render_member_rows(rows));
        Some(lines)
    }

    fn definition_ty_display(ty: &Ty, def: &scar::env::TypeDefInfo) -> String {
        let params = def
            .type_param_vars
            .iter()
            .copied()
            .zip(def.type_params.iter().map(String::as_str))
            .collect::<Vec<_>>();
        Self::ty_to_string_with_params(ty, &params)
    }

    fn facet_path_kind_info(symbol: &str) -> Option<Vec<String>> {
        let name = crate::surface_path_name(symbol).rsplit("::").next()?;
        let atomic = ["InfallibleStructural", "FallibleStructural", "VariantPath"];
        let aliases: &[(&str, &[&str])] = &[
            ("ReadablePath", &atomic),
            ("WritablePath", &atomic),
            ("PutPath", &["InfallibleStructural"]),
            ("PreviewPath", &["VariantPath"]),
            ("CasePath", &["VariantPath"]),
        ];
        if name == "FacetPathKind" {
            let mut lines = vec![
                "FacetPathKind".into(),
                "Compiler-managed types usable only as the first argument of Facet<K, S, A, T, B>."
                    .into(),
                "Atomic kinds".into(),
            ];
            lines.extend(atomic.iter().map(|kind| format!("- {kind}")));
            lines.push("Kind-set aliases".into());
            lines.extend(aliases.iter().map(|(alias, _)| format!("- {alias}")));
            return Some(lines);
        }
        if atomic.contains(&name) {
            return Some(vec![
                format!("@FacetPathKind Type {name}"),
                "Compiler-derived atomic Facet path kind.".into(),
                "Usage: first type argument of Facet<K, S, A, T, B> only.".into(),
            ]);
        }
        aliases
            .iter()
            .find(|(alias, _)| *alias == name)
            .map(|(alias, members)| {
                let rhs = members.join(" | ");
                let mut lines = vec![
                    format!("@FacetPathKind Type {alias} ="),
                    format!("  {rhs}"),
                    "Direct members".into(),
                ];
                lines.extend(members.iter().map(|member| format!("- {member}")));
                lines.push("Effective atomic kinds".into());
                lines.extend(members.iter().map(|member| format!("- {member}")));
                lines.push("Usage: first type argument of Facet<K, S, A, T, B> only.".into());
                lines.push("Compiler-managed; not a runtime value or constructor.".into());
                lines
            })
    }

    fn render_info_binding(&self, symbol: &str, binding: &forge::BindingInfo) -> ReplResult {
        if let Some(value) = self.vm.get_local(binding.slot_id) {
            if let Some((process_name, metadata)) = self.process_metadata_for_pid_value(&value) {
                let rendered_ty = Self::pid_type_from_value(&value)
                    .unwrap_or_else(|| crate::surface_rendered_name(&binding.ty));
                return Self::styled(vec![
                    symbol.to_string(),
                    "kind: process pid".to_string(),
                    "origin: repl".to_string(),
                    format!("type: {rendered_ty}"),
                    "identity: TypeIdentity::Type".to_string(),
                    format!(
                        "defined: PID<{}>",
                        crate::surface_rendered_name(process_name)
                    ),
                    format!("instance: {:?}", metadata.instance),
                    format!("runtime kind: {:?}", metadata.kind),
                ]);
            }
        }

        if let Some((_, metadata)) = self.process_metadata_for_pid_type(binding.ty.as_str()) {
            return Self::styled(vec![
                symbol.to_string(),
                "kind: process pid".to_string(),
                "origin: repl".to_string(),
                format!("type: {}", crate::surface_rendered_name(&binding.ty)),
                "identity: TypeIdentity::Type".to_string(),
                format!("defined: {}", crate::surface_rendered_name(&binding.ty)),
                format!("instance: {:?}", metadata.instance),
                format!("runtime kind: {:?}", metadata.kind),
            ]);
        }

        let mut lines = vec![symbol.to_string()];
        let kind = match self.binding_callable_kind(binding) {
            Some(forge::ReplCallableKind::Closure) => "closure",
            Some(forge::ReplCallableKind::Capture) => "capture",
            None => "binding",
        };
        lines.push(format!("kind: {kind}"));
        lines.push("origin: repl".to_string());
        if binding.facet_info.is_some() {
            lines.push(format!(
                "type: {}",
                crate::surface_rendered_name(&binding.ty)
            ));
            lines.push(format!(
                "identity: {}",
                self.render_type_identity(binding, None)
            ));
            if let Some(facet_info) = &binding.facet_info {
                lines.push(format!(
                    "full path: {}",
                    crate::surface_rendered_name(&facet_info.full_path)
                ));
            }
        } else if let Some(value) = self.vm.get_local(binding.slot_id) {
            lines.push(format!(
                "type: {}",
                crate::surface_rendered_name(&binding.ty)
            ));
            lines.push(format!(
                "identity: {}",
                self.render_type_identity(binding, Some(&value))
            ));
        }
        if let Some(sig) = self.binding_callable_sig_summary(symbol) {
            lines.push(format!("defined: {sig}"));
        }
        Self::styled(lines)
    }

    fn origin_for_name(name: &str) -> &'static str {
        if name.contains("REPL::") {
            "repl"
        } else if builtin_function_metas()
            .iter()
            .any(|meta| name == meta.name || name.ends_with(&format!("::{}", meta.name)))
        {
            "builtin"
        } else {
            "stdlib"
        }
    }

    #[cfg(test)]
    fn repl_result_text(result: &ReplResult) -> String {
        match &result.output {
            ReplOutput::StyledDoc { lines } | ReplOutput::PlainText { lines } => lines.join("\n"),
            ReplOutput::Diagnostic {
                rendered,
                summary_tail,
            } => rendered
                .iter()
                .chain(summary_tail.iter())
                .cloned()
                .collect::<Vec<_>>()
                .join("\n"),
            ReplOutput::EvalSuccess { rendered, .. } | ReplOutput::EvalError { rendered, .. } => {
                rendered.join("\n")
            }
            ReplOutput::DocResolved {
                symbol,
                signature,
                summary,
                source_snippet,
                details,
            } => [
                vec![symbol.clone()],
                signature.clone().into_iter().collect(),
                summary.clone().into_iter().collect(),
                source_snippet.clone().into_iter().collect(),
                details.clone(),
            ]
            .concat()
            .join("\n"),
            ReplOutput::StatusMessage(message) => message.clone(),
            ReplOutput::EvalStarted { source, .. } => source.clone(),
        }
    }

    fn ty_to_string(ty: &Ty) -> String {
        Self::ty_to_string_with_params(ty, &[])
    }

    fn ty_to_string_with_params(ty: &Ty, names: &[(u32, &str)]) -> String {
        match ty {
            Ty::Int => "Int".into(),
            Ty::Float => "Float".into(),
            Ty::Str => "String".into(),
            Ty::Bool => "Boolean".into(),
            Ty::Unit => "Unit".into(),
            Ty::Hole => "_".into(),
            Ty::List(inner) => format!("List<{}>", Self::ty_to_string_with_params(inner, names)),
            Ty::Lazy(inner) => format!("Lazy<{}>", Self::ty_to_string_with_params(inner, names)),
            Ty::Pid(marker) => format!("PID<{}>", Self::ty_to_string_with_params(marker, names)),
            Ty::ProcessMarker(name) => crate::surface_rendered_name(name).to_string(),
            Ty::Facet(kind, source, focus, update_source, update_focus) => {
                format!(
                    "Facet<{}, {}, {}, {}, {}>",
                    kind.as_str(),
                    Self::ty_to_string_with_params(source, names),
                    Self::ty_to_string_with_params(focus, names),
                    Self::ty_to_string_with_params(update_source, names),
                    Self::ty_to_string_with_params(update_focus, names)
                )
            }
            Ty::Tuple(items) => format!(
                "({})",
                items
                    .iter()
                    .map(|ty| Self::ty_to_string_with_params(ty, names))
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            Ty::SelfApp(args) => format!(
                "Self<{}>",
                args.iter()
                    .map(|ty| Self::ty_to_string_with_params(ty, names))
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            Ty::ExtractorClosure(signature) => {
                format!(
                    "ExtractorClosure<{}>",
                    Self::ty_to_string_with_params(signature, names)
                )
            }
            Ty::MatchResult(payload) => {
                format!(
                    "MatchResult<{}>",
                    Self::ty_to_string_with_params(payload, names)
                )
            }
            Ty::Result(ok, _) => format!("Result<{}>", Self::ty_to_string_with_params(ok, names)),
            Ty::Struct(name, _) | Ty::Record(name, _) => crate::surface_path_name(name).to_string(),
            Ty::Enum(name, args) => {
                let name = crate::surface_path_name(name);
                if args.is_empty() {
                    name.to_string()
                } else {
                    let args = args
                        .iter()
                        .map(|ty| Self::ty_to_string_with_params(ty, names))
                        .collect::<Vec<_>>()
                        .join(", ");
                    format!("{name}<{args}>")
                }
            }
            Ty::Error => "Error".into(),
            Ty::Var(id) => names
                .iter()
                .find(|(var, _)| var == id)
                .map(|(_, name)| format!("${}", name.trim_start_matches('$')))
                .unwrap_or_else(|| "_".into()),
            Ty::Func(params, ret) => {
                let param_str = params
                    .iter()
                    .map(|ty| Self::ty_to_string_with_params(ty, names))
                    .collect::<Vec<_>>()
                    .join(", ");
                if param_str.is_empty() {
                    format!("(-> {})", Self::ty_to_string_with_params(ret, names))
                } else {
                    format!(
                        "({} -> {})",
                        param_str,
                        Self::ty_to_string_with_params(ret, names)
                    )
                }
            }
            Ty::BuiltinFunc { name, .. } => format!("Builtin({})", name),
            Ty::UserFunc { .. } => "UserFunc".into(),
        }
    }

    fn handle_sig_owner_pattern(&self, symbol: &str) -> Option<ReplResult> {
        let owner = symbol.strip_suffix('!')?;
        if let Some(decl) = self.private_declaration(owner) {
            return Some(ReplResult::ok(Self::private_sig_output(decl)));
        }
        let decl = self.visible_declaration(owner)?;
        let name = crate::surface_path_name(&decl.fq_name);
        match decl.kind {
            sigil::DeclarationKind::Struct => {
                let extractor = format!("{}::deconstruct", decl.fq_name);
                Some(match self.find_signature(&extractor) {
                    Some((qualified, signature)) => {
                        Self::styled(vec![Self::render_signature_with_qualified_name(
                            &qualified, signature,
                        )])
                    }
                    None => Self::plain(vec![format!("No signature found for {symbol}")]),
                })
            }
            sigil::DeclarationKind::Record | sigil::DeclarationKind::Deferror => {
                let def = self.scar_session.lookup_type_def(&decl.fq_name)?;
                let fields = def
                    .fields
                    .iter()
                    .map(|(field, ty)| format!("{field}: {}", Self::definition_ty_display(ty, def)))
                    .collect::<Vec<_>>()
                    .join(", ");
                Some(Self::styled(vec![format!("{name}({fields}) : {name}")]))
            }
            sigil::DeclarationKind::Enum => {
                let mut lines = self.enum_variant_signature_lines(decl)?;
                for line in &mut lines {
                    line.push_str(&format!(" : {name}"));
                }
                Some(Self::styled(lines))
            }
            _ => None,
        }
    }

    fn sig_type_owner_summary_lines(&self, symbol: &str) -> Option<Vec<String>> {
        let decl = self.visible_declaration(symbol)?;
        match decl.kind {
            sigil::DeclarationKind::Struct
            | sigil::DeclarationKind::Record
            | sigil::DeclarationKind::Deferror => self.constructor_signature_lines(decl),
            sigil::DeclarationKind::Enum => self.enum_variant_signature_lines(decl),
            _ => None,
        }
    }

    fn builtin_literal_pattern_sig_lines(&self, symbol: &str) -> Option<Vec<String>> {
        Some(vec![match symbol {
            "List" => "[T1, ..] : List<T>".to_string(),
            "HashMap" => "hash![String => V1, ..] : HashMap<V>".to_string(),
            "Tuple" => "(T1, T2, ..) : Tuple<T1, T2, ..>".to_string(),
            _ => return None,
        }])
    }

    fn trait_family_signature_lines(&self, symbol: &str) -> Option<Vec<String>> {
        let decl = self.visible_declaration(symbol)?;
        if decl.kind != sigil::DeclarationKind::Trait {
            return None;
        }
        let (_, signature) = self.trait_signature_entry(symbol)?;
        let methods = Self::trait_signature_methods(&signature);
        if methods.is_empty() {
            return Some(vec![crate::surface_rendered_name(&signature)]);
        }

        let mut lines = Vec::with_capacity(methods.len() + 3);
        lines.push(format!(
            "trait {} {{",
            crate::surface_path_name(&decl.fq_name)
        ));
        lines.extend(methods.into_iter().map(|method| format!("  {method}")));
        lines.push("}".to_string());
        if let Some(targets) = self.impl_targets_summary_for_trait(symbol) {
            lines.push(format!("impl targets: {targets}"));
        }
        Some(lines)
    }

    fn trait_method_family_signature_lines(&self, symbol: &str) -> Option<Vec<String>> {
        let (trait_name, member) = match symbol {
            "compare" => ("Compare", "compare"),
            "|*>" => ("Functor", "fmap"),
            _ => return None,
        };
        let (_, signature) = self.trait_signature_entry(trait_name)?;
        let method = Self::trait_signature_methods(&signature)
            .into_iter()
            .find(|method| {
                Self::callee_tail(method.split_once('(').map_or(method, |(head, _)| head)) == member
            })?;
        let mut lines = vec![format!("{trait_name}::{method}")];
        if let Some(targets) = self.impl_targets_summary_for_trait(trait_name) {
            lines.push(format!("impl targets: {targets}"));
        }
        Some(lines)
    }

    fn trait_signature_entry(&self, trait_name: &str) -> Option<(String, String)> {
        self.find_signature(trait_name)
            .filter(|(_, signature)| Self::trait_signature_methods(signature).len() > 0)
    }

    fn trait_signature_methods(signature: &str) -> Vec<String> {
        let Some(open) = signature.find('{') else {
            return Vec::new();
        };
        let Some(close) = signature.rfind('}') else {
            return Vec::new();
        };
        let head = signature[..open].trim();
        if !head.starts_with("trait ") && !head.starts_with("deftrait ") {
            return Vec::new();
        }
        Self::split_top_level_items(&signature[open + 1..close])
            .into_iter()
            .map(|method| crate::surface_rendered_name(&method))
            .collect()
    }

    fn impl_targets_summary_for_trait(&self, trait_name: &str) -> Option<String> {
        let mut targets = Vec::new();
        for signature in self.signatures.iter().map(|entry| entry.signature.as_str()) {
            if let Some(target) = Self::impl_signature_target_for_trait(signature, trait_name) {
                let target = Self::impl_target_summary_name(target);
                if !targets.iter().any(|seen| seen == &target) {
                    targets.push(target);
                }
            }
        }
        if targets
            .iter()
            .any(|target| Self::is_tuple_summary_name(target))
        {
            let mut collapsed = vec!["TupleN".to_string()];
            collapsed.extend(
                targets
                    .into_iter()
                    .filter(|target| !Self::is_tuple_summary_name(target)),
            );
            targets = collapsed;
        }
        (!targets.is_empty()).then(|| targets.join(", "))
    }

    fn impl_signature_target_for_trait<'a>(
        signature: &'a str,
        trait_name: &str,
    ) -> Option<&'a str> {
        let rest = signature.strip_prefix("impl ")?;
        let for_pos = rest.find(" for ")?;
        let trait_head = rest[..for_pos].trim();
        let trait_head_name = trait_head.split('<').next().unwrap_or(trait_head).trim();
        if trait_head_name != trait_name {
            return None;
        }
        let target_and_member = rest[for_pos + " for ".len()..].trim();
        target_and_member
            .split_once("::")
            .map(|(target, _)| target.trim())
    }

    fn impl_target_summary_name(target: &str) -> String {
        let target = crate::surface_rendered_name(target);
        if target.starts_with('(') && target.ends_with(')') {
            let inner = &target[1..target.len() - 1];
            let arity = Self::split_top_level_items(inner).len();
            if arity > 0 {
                return format!("Tuple{arity}");
            }
        }
        target
            .split('<')
            .next()
            .unwrap_or(target.as_str())
            .trim()
            .to_string()
    }

    fn is_tuple_summary_name(target: &str) -> bool {
        target
            .strip_prefix("Tuple")
            .is_some_and(|tail| !tail.is_empty() && tail.chars().all(|ch| ch.is_ascii_digit()))
    }

    fn constructor_signature_lines(&self, decl: &sigil::DeclarationEntry) -> Option<Vec<String>> {
        if let Some((qualified_name, signature)) = self.constructor_signature_entry(decl) {
            return Some(vec![Self::render_signature_with_qualified_name(
                &qualified_name,
                signature,
            )]);
        }

        None
    }

    fn constructor_signature_entry(
        &self,
        decl: &sigil::DeclarationEntry,
    ) -> Option<(String, String)> {
        if decl.kind == sigil::DeclarationKind::Deferror {
            let (_, signature) = self.find_signature(&decl.fq_name)?;
            let (_, block) = signature.split_once('{')?;
            let (_, inputs) = block.split_once('|')?;
            let (inputs, _) = inputs.split_once('|')?;
            let owner = crate::surface_path_name(&decl.fq_name);
            return Some((
                decl.fq_name.clone(),
                format!("{owner}({}) -> {owner}", inputs.trim()),
            ));
        }
        let constructor_qualified_name = format!("{}::new", decl.fq_name);
        if let Some(signature) = self.find_signature(&constructor_qualified_name) {
            return Some(signature);
        }

        let mut matches = self
            .signatures
            .iter()
            .filter(|entry| entry.kind == DocKind::Function)
            .filter(|entry| {
                crate::surface_path_name(&entry.qualified_name)
                    == crate::surface_path_name(&constructor_qualified_name)
            })
            .map(|entry| (entry.qualified_name.clone(), entry.signature.clone()))
            .collect::<Vec<_>>();
        matches.sort_by(|left, right| left.0.cmp(&right.0).then(left.1.cmp(&right.1)));
        if let Some(first) = matches.into_iter().next() {
            return Some(first);
        }

        self.scar_session
            .lookup_type_def(&decl.fq_name)
            .filter(|def| {
                matches!(
                    def.kind,
                    scar::env::TypeKind::Struct | scar::env::TypeKind::Record
                )
            })
            .map(|def| {
                let params = def
                    .fields
                    .iter()
                    .map(|(name, ty)| format!("{name}: {}", Self::ty_to_string(ty)))
                    .collect::<Vec<_>>()
                    .join(", ");
                match def.kind {
                    scar::env::TypeKind::Record => (
                        decl.fq_name.clone(),
                        format!(
                            "{}({params}) -> {}",
                            crate::surface_path_name(&decl.fq_name),
                            crate::surface_path_name(&decl.fq_name)
                        ),
                    ),
                    scar::env::TypeKind::Struct => (
                        constructor_qualified_name,
                        format!(
                            "{}::new({params}) -> {}",
                            crate::surface_path_name(&decl.fq_name),
                            crate::surface_path_name(&decl.fq_name)
                        ),
                    ),
                    _ => unreachable!("constructor signatures only support struct/record"),
                }
            })
    }

    fn enum_variant_signature_lines(&self, decl: &sigil::DeclarationEntry) -> Option<Vec<String>> {
        let entry = self.signatures.iter().rev().find(|entry| {
            entry.kind == DocKind::Type
                && crate::surface_path_name(&entry.qualified_name)
                    == crate::surface_path_name(&decl.fq_name)
        });
        if let Some(entry) = entry {
            if let Some((_owner_surface, variants_src)) =
                Self::parse_defenum_signature(&entry.signature)
            {
                let variants = Self::split_top_level_items(variants_src)
                    .into_iter()
                    .map(|variant| Self::render_enum_variant_listing(&decl.fq_name, &variant))
                    .collect::<Vec<_>>();
                if !variants.is_empty() {
                    return Some(variants);
                }
            }
        }

        self.scar_session
            .enum_variants_of(&decl.fq_name)
            .and_then(|variants| {
                let lines = variants
                    .iter()
                    .map(|variant| {
                        if variant.payload.is_empty() {
                            format!(
                                "* {}::{}",
                                crate::surface_path_name(&decl.fq_name),
                                variant.short_name
                            )
                        } else {
                            let payload = variant
                                .payload
                                .iter()
                                .map(Self::ty_to_string)
                                .collect::<Vec<_>>()
                                .join(", ");
                            format!(
                                "* {}::{}({payload})",
                                crate::surface_path_name(&decl.fq_name),
                                variant.short_name
                            )
                        }
                    })
                    .collect::<Vec<_>>();
                (!lines.is_empty()).then_some(lines)
            })
    }

    fn parse_defenum_signature(signature: &str) -> Option<(String, &str)> {
        let rest = signature.strip_prefix("defenum ")?;
        let open = rest.find('{')?;
        let close = rest.rfind('}')?;
        let owner = rest[..open].trim().to_string();
        let variants = rest[open + 1..close].trim();
        Some((owner, variants))
    }

    fn split_top_level_items(input: &str) -> Vec<String> {
        let mut items = Vec::new();
        let mut current = String::new();
        let mut depth = 0usize;
        for ch in input.chars() {
            match ch {
                '<' | '(' | '[' | '{' => {
                    depth += 1;
                    current.push(ch);
                }
                '>' | ')' | ']' | '}' => {
                    depth = depth.saturating_sub(1);
                    current.push(ch);
                }
                ',' if depth == 0 => {
                    let item = current.trim();
                    if !item.is_empty() {
                        items.push(item.to_string());
                    }
                    current.clear();
                }
                _ => current.push(ch),
            }
        }
        let tail = current.trim();
        if !tail.is_empty() {
            items.push(tail.to_string());
        }
        items
    }

    fn render_enum_variant_listing(owner_fq: &str, variant: &str) -> String {
        let owner_fq = crate::surface_path_name(owner_fq);
        if let Some((name, payload)) = variant.split_once('(') {
            let payload = crate::surface_rendered_name(payload.trim_end_matches(')').trim());
            format!("* {}::{}({payload})", owner_fq, name.trim())
        } else {
            format!("* {}::{}", owner_fq, variant.trim())
        }
    }

    fn handle_sig_binding(&self, symbol: &str) -> Option<ReplResult> {
        let binding = self.binding_info(symbol)?;
        if let Some(value) = self.vm.get_local(binding.slot_id) {
            if let Some((owner, metadata)) = self.process_metadata_for_pid_value(&value) {
                if let Some(lines) = self.process_pid_binding_sig_summary_lines(owner, metadata) {
                    return Some(Self::styled(lines));
                }
            }
        }
        if let Some((owner, metadata)) = self.process_metadata_for_pid_type(binding.ty.as_str()) {
            if let Some(lines) = self.process_pid_binding_sig_summary_lines(owner, metadata) {
                return Some(Self::styled(lines));
            }
        }
        self.binding_callable_sig_summary(symbol)
            .map(|rendered| Self::styled(vec![rendered]))
            .or_else(|| {
                Some(Self::plain(vec![format!(
                    "No signature found for {}",
                    symbol
                )]))
            })
    }

    fn binding_callable_sig_summary(&self, symbol: &str) -> Option<String> {
        let binding = self.binding_info(symbol)?;
        let kind = self.binding_callable_kind(binding)?;
        let ty = self.binding_callable_ty(binding)?;
        Some(Self::render_callable_sig_summary(
            symbol,
            &format_query_ty(&ty),
            kind,
        ))
    }

    fn render_callable_sig_summary(
        name_or_source: &str,
        ty: &str,
        kind: forge::ReplCallableKind,
    ) -> String {
        let kind = match kind {
            forge::ReplCallableKind::Closure => "Closure",
            forge::ReplCallableKind::Capture => "Capture",
        };
        format!("{name_or_source}: {ty} :: {kind}")
    }

    fn binding_callable_kind(
        &self,
        binding: &forge::BindingInfo,
    ) -> Option<forge::ReplCallableKind> {
        self.vm
            .get_local(binding.slot_id)
            .and_then(|value| Self::callable_origin_kind(&value))
            .or(binding.callable_kind)
    }

    fn callable_origin_kind(value: &Value) -> Option<forge::ReplCallableKind> {
        let callable = Self::callable_origin_source(value)?;
        match callable.metadata.origin {
            sindr::runtime::CallableOrigin::Closure => Some(forge::ReplCallableKind::Closure),
            sindr::runtime::CallableOrigin::Capture => Some(forge::ReplCallableKind::Capture),
            sindr::runtime::CallableOrigin::Unknown => None,
        }
    }

    fn callable_origin_source(value: &Value) -> Option<&sindr::runtime::Callable> {
        let mut current = value;
        loop {
            let Value::Callable(callable) = current else {
                return None;
            };
            if let Some(index) = callable.metadata.origin_source {
                current = callable.lexical_captures.get(index)?;
            } else {
                return Some(callable);
            }
        }
    }

    fn is_extractor_closure_query_type(ty: &AstTy) -> bool {
        matches!(ty, AstTy::Generic(_, name, args)
            if sindr::names::builtin_type_name(name) == Some(sindr::names::TypeName::ExtractorClosure)
                && args.len() == 1 && matches!(args[0], AstTy::Func(_, _, _)))
    }

    fn binding_callable_ty(&self, binding: &forge::BindingInfo) -> Option<AstTy> {
        let ty = parse_binding_query_type(&binding.ty)?;
        (matches!(ty, AstTy::Func(_, _, _)) || Self::is_extractor_closure_query_type(&ty))
            .then_some(ty)
    }

    fn binding_type(&self, name: &str) -> Option<String> {
        self.result_metas
            .iter()
            .rev()
            .flatten()
            .flat_map(|meta| meta.bindings.iter().rev())
            .find(|binding| binding.name == name)
            .map(|binding| crate::surface_rendered_name(&binding.ty))
    }

    fn binding_info(&self, name: &str) -> Option<&forge::BindingInfo> {
        self.result_metas
            .iter()
            .rev()
            .flatten()
            .flat_map(|meta| meta.bindings.iter().rev())
            .find(|binding| binding.name == name)
    }

    fn history_summary(source: &str) -> String {
        source
            .lines()
            .map(str::trim)
            .filter(|line| !line.is_empty())
            .collect::<Vec<_>>()
            .join(" ")
    }

    fn is_replayable_stmt(stmt: &Ast) -> bool {
        matches!(
            stmt,
            Ast::Import(_, _, _) | Ast::Def(..) | Ast::ExtractorDef(..)
        )
    }

    fn chunk_is_replayable(ast: &[Ast]) -> bool {
        !ast.is_empty() && ast.iter().all(Self::is_replayable_stmt)
    }

    fn collect_def_records(ast: &[Ast], line: usize) -> Vec<ReplDefRecord> {
        ast.iter()
            .filter_map(|stmt| match stmt {
                Ast::Def(_, name, _, params, ..) => Some(ReplDefRecord {
                    line,
                    name: name.clone(),
                    arity: params.len(),
                }),
                Ast::ExtractorDef(_, name, ..) => Some(ReplDefRecord {
                    line,
                    name: name.clone(),
                    arity: 1,
                }),
                _ => None,
            })
            .collect()
    }

    fn collect_import_records(ast: &[Ast], line: usize) -> Vec<ReplImportRecord> {
        let mut records = Vec::new();
        for stmt in ast {
            let Ast::Import(_, path, spec) = stmt else {
                continue;
            };
            let module_name = path.segments.join("::");
            match spec {
                ImportSpec::All => records.push(ReplImportRecord {
                    line,
                    src: "kwd".to_string(),
                    item: module_name,
                    via: "import".to_string(),
                }),
                ImportSpec::Single(name) => records.push(ReplImportRecord {
                    line,
                    src: "kwd".to_string(),
                    item: format!("{}::{}", module_name, name),
                    via: "import".to_string(),
                }),
                ImportSpec::List(names) => {
                    for name in names {
                        records.push(ReplImportRecord {
                            line,
                            src: "kwd".to_string(),
                            item: format!("{}::{}", module_name, name),
                            via: "import".to_string(),
                        });
                    }
                }
            }
        }
        records
    }

    fn collect_auto_import_records(
        module_stages: &[Vec<sigil::StagedModuleAst>],
        declaration_index: &sigil::DeclarationIndex,
    ) -> Vec<ReplImportRecord> {
        let mut seen = BTreeSet::new();
        let mut records = Vec::new();
        let mut member_auto_import_modules = BTreeSet::new();

        for stage in module_stages {
            for module in stage {
                if !module.auto_import {
                    continue;
                }
                let first_non_import = module
                    .ast
                    .iter()
                    .find(|stmt| !matches!(stmt, Ast::Import(_, _, _)));
                match first_non_import {
                    Some(Ast::ImplDef(_, _, _, _, _) | Ast::TraitImplDef(..)) => {
                        member_auto_import_modules.insert(module.module_path.clone());
                    }
                    _ => {
                        let item = crate::surface_rendered_name(&module.module_path);
                        if seen.insert((
                            0usize,
                            "auto".to_string(),
                            item.clone(),
                            "@autoimport".to_string(),
                        )) {
                            records.push(ReplImportRecord {
                                line: 0,
                                src: "auto".to_string(),
                                item,
                                via: "@autoimport".to_string(),
                            });
                        }
                    }
                }
            }
        }

        for entry in declaration_index.values() {
            if entry.kind != sigil::DeclarationKind::Trait
                || !entry.auto_import
                || entry.hidden
                || !entry.user_importable
                || entry.visibility != spire::ast::Visibility::Public
            {
                continue;
            }
            let method_prefix = format!("{}::", entry.fq_name);
            for method_entry in declaration_index.values() {
                if method_entry.kind != sigil::DeclarationKind::TraitMethod
                    || !method_entry.fq_name.starts_with(&method_prefix)
                    || method_entry.hidden
                    || !method_entry.user_importable
                    || method_entry.visibility != spire::ast::Visibility::Public
                {
                    continue;
                }
                let item = crate::surface_rendered_name(&method_entry.name);
                if seen.insert((
                    0usize,
                    "auto".to_string(),
                    item.clone(),
                    "@autoimport".to_string(),
                )) {
                    records.push(ReplImportRecord {
                        line: 0,
                        src: "auto".to_string(),
                        item,
                        via: "@autoimport".to_string(),
                    });
                }
            }
        }

        let current_stage_index = module_stages.len().saturating_sub(1);
        if let Ok(entries) =
            sigil::effective_auto_import_entries(module_stages, None, current_stage_index)
        {
            for entry in entries {
                if !member_auto_import_modules.contains(&entry.module_path) {
                    continue;
                }
                let item = match entry.kind {
                    sigil::DeclarationKind::TraitMethod => {
                        crate::surface_rendered_name(&entry.name)
                    }
                    _ => crate::surface_rendered_name(&entry.fq_name),
                };
                if seen.insert((
                    0usize,
                    "auto".to_string(),
                    item.clone(),
                    "@autoimport".to_string(),
                )) {
                    records.push(ReplImportRecord {
                        line: 0,
                        src: "auto".to_string(),
                        item,
                        via: "@autoimport".to_string(),
                    });
                }
            }
        }

        records.sort_by(|left, right| {
            left.line
                .cmp(&right.line)
                .then_with(|| left.src.cmp(&right.src))
                .then_with(|| left.item.cmp(&right.item))
                .then_with(|| left.via.cmp(&right.via))
        });
        records
    }

    fn handle_vars(&self) -> ReplResult {
        if self.binding_records.is_empty() {
            return Self::plain(vec!["No visible value bindings.".to_string()]);
        }
        let mut lines = vec!["line | name | type".to_string()];
        lines.extend(
            self.binding_records
                .iter()
                .map(|binding| format!("{}: {}: {}", binding.line, binding.name, binding.ty)),
        );
        Self::plain(lines)
    }

    fn handle_imported(&self) -> ReplResult {
        let mut lines = vec!["line | src | item | via".to_string()];
        lines.extend(self.auto_import_records.iter().map(|record| {
            format!(
                "{} | {} | {} | {}",
                record.line, record.src, record.item, record.via
            )
        }));
        lines.extend(self.import_records.iter().map(|record| {
            format!(
                "{} | {} | {} | {}",
                record.line, record.src, record.item, record.via
            )
        }));
        if lines.len() == 1 {
            lines.push("No imports are active.".to_string());
        }
        Self::plain(lines)
    }

    fn handle_defs(&self) -> ReplResult {
        if self.def_records.is_empty() {
            return Self::plain(vec!["No visible top-level defs.".to_string()]);
        }
        let mut lines = vec!["line | name | arity".to_string()];
        lines.extend(
            self.def_records
                .iter()
                .map(|record| format!("{}: {}/{}", record.line, record.name, record.arity)),
        );
        Self::plain(lines)
    }

    fn parse_history_selector(&self, selector: &str) -> Result<Vec<usize>, String> {
        let selector = selector.trim();
        if selector.is_empty() {
            return Ok(self
                .history_entries
                .iter()
                .map(|entry| entry.line)
                .collect());
        }
        if let Some((start, end)) = selector.split_once("..") {
            let start = start
                .trim()
                .parse::<usize>()
                .map_err(|_| format!("Invalid history selector `{selector}`."))?;
            let end = end
                .trim()
                .parse::<usize>()
                .map_err(|_| format!("Invalid history selector `{selector}`."))?;
            if start > end {
                return Err(format!("History range `{selector}` is reversed."));
            }
            return Ok((start..=end).collect());
        }

        selector
            .split(',')
            .map(|part| {
                part.trim()
                    .parse::<usize>()
                    .map_err(|_| format!("Invalid history selector `{selector}`."))
            })
            .collect()
    }

    fn handle_history(&self, selector: Option<&str>) -> ReplResult {
        if self.history_entries.is_empty() {
            return Self::plain(vec!["No REPL history yet.".to_string()]);
        }
        let selected = match selector {
            Some(selector) => match self.parse_history_selector(selector) {
                Ok(lines) => lines,
                Err(message) => {
                    return self.repl_command_diagnostic(
                        &format!(":history {}", selector.trim()),
                        message,
                        Span {
                            start: ":history ".chars().count(),
                            end: format!(":history {}", selector.trim()).chars().count(),
                        },
                        diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                        Some("Usage: :history [selector]".to_string()),
                        Vec::new(),
                    );
                }
            },
            None => self
                .history_entries
                .iter()
                .map(|entry| entry.line)
                .collect(),
        };

        let mut lines = vec!["line | input".to_string()];
        for line in selected {
            let Some(entry) = self.history_entries.iter().find(|entry| entry.line == line) else {
                return self.repl_command_diagnostic(
                    &format!(":history {}", selector.unwrap_or_default().trim()),
                    format!("History line {} is out of range.", line),
                    Span {
                        start: ":history ".chars().count(),
                        end: format!(":history {}", selector.unwrap_or_default().trim())
                            .chars()
                            .count(),
                    },
                    diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                    Some("Usage: :history [selector]".to_string()),
                    Vec::new(),
                );
            };
            lines.push(format!(
                "{}: {}",
                entry.line,
                Self::history_summary(&entry.source)
            ));
        }
        Self::plain(lines)
    }

    fn rebuild_for_reload(&self, keep_session_defs: bool) -> Result<Self, ReplResult> {
        let mut engine = match &self.reload_seed {
            ReplReloadSeed::Empty => ReplEngine::new()
                .map_err(|error| Self::plain(vec![format!("reload failed: {}", error)]))?,
            ReplReloadSeed::ProjectModuleStages(module_input_stages) => {
                ReplEngine::from_project_module_stages(module_input_stages)
                    .map_err(|error| Self::plain(vec![format!("reload failed: {}", error)]))?
            }
            ReplReloadSeed::Sources { module, script } => ReplEngine::from_preload_sources(
                module
                    .as_ref()
                    .map(|(file_name, source)| (file_name.as_str(), source.as_str())),
                script
                    .as_ref()
                    .map(|(file_name, source)| (file_name.as_str(), source.as_str())),
            )
            .map_err(|error| Self::plain(vec![format!("reload failed: {}", error)]))?,
        };
        engine.reload_seed = self.reload_seed.clone();
        engine.error_display_mode = self.error_display_mode;
        engine.stack_trace_display_mode = self.stack_trace_display_mode;
        if keep_session_defs {
            for input in &self.replay_inputs {
                let result = engine.handle_line_with_ast(&input.source, input.ast.clone());
                if result.should_exit {
                    return Err(Self::plain(vec![
                        "reload failed: replay requested REPL exit".to_string(),
                    ]));
                }
                match result.output {
                    ReplOutput::EvalSuccess { .. }
                    | ReplOutput::PlainText { .. }
                    | ReplOutput::StyledDoc { .. }
                    | ReplOutput::StatusMessage(_) => {}
                    ReplOutput::EvalError { .. } | ReplOutput::Diagnostic { .. } => {
                        return Err(result);
                    }
                    ReplOutput::DocResolved { .. } | ReplOutput::EvalStarted { .. } => {}
                }
            }
        }
        Ok(engine)
    }

    fn handle_reload(&mut self, mode: Option<&str>) -> ReplResult {
        let keep_session_defs = match mode.map(str::trim).filter(|mode| !mode.is_empty()) {
            None | Some("all") => true,
            Some("defs") => false,
            Some(other) => {
                return self.repl_command_diagnostic(
                    &format!(":reload {}", other),
                    format!("Invalid reload mode `{}`.", other),
                    Span {
                        start: ":reload ".chars().count(),
                        end: format!(":reload {}", other).chars().count(),
                    },
                    diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                    Some("Usage: :reload [all|defs]".to_string()),
                    Vec::new(),
                );
            }
        };

        let mode_name = if keep_session_defs { "all" } else { "defs" };
        match self.rebuild_for_reload(keep_session_defs) {
            Ok(engine) => {
                *self = engine;
                Self::plain(vec![format!("reload complete: {}", mode_name)])
            }
            Err(result) => result,
        }
    }

    fn handle_clear(&self) -> ReplResult {
        Self::plain(vec!["clear is not available in this host".to_string()])
    }

    fn is_type_lookup_symbol(symbol: &str) -> bool {
        if symbol.is_empty() {
            return false;
        }
        if matches!(
            symbol,
            "True"
                | "False"
                | "def"
                | "defp"
                | "defmod"
                | "namespace"
                | "deftrait"
                | "import"
                | "include"
                | "if"
                | "if_then"
                | "defstruct"
                | "defrecord"
                | "deferror"
                | "defenum"
                | "defextractor"
                | "impl"
                | "for"
                | "match"
                | "when"
                | "cond"
                | "private"
                | "public"
                | "const"
                | "type"
                | "where"
        ) {
            return false;
        }

        let mut chars = symbol.chars();
        let Some(first) = chars.next() else {
            return false;
        };
        if !(first.is_ascii_alphabetic() || first == '_') {
            return false;
        }
        chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '_')
    }

    fn render_type_identity(&self, binding: &forge::BindingInfo, value: Option<&Value>) -> String {
        if binding.facet_info.is_some() {
            return ReplTypeDisplayCategory::FacetPath
                .identity_label()
                .to_string();
        }
        if let Some(kind) = self.binding_callable_kind(binding) {
            return Self::callable_display_category(kind)
                .identity_label()
                .to_string();
        }
        let category = match value {
            None => ReplTypeDisplayCategory::Type,
            Some(Value::Callable(callable)) => match callable.metadata.origin {
                sindr::runtime::CallableOrigin::Closure => ReplTypeDisplayCategory::Closure,
                sindr::runtime::CallableOrigin::Capture => ReplTypeDisplayCategory::Capture,
                sindr::runtime::CallableOrigin::Unknown => ReplTypeDisplayCategory::Closure,
            },
            Some(Value::Tagged { tag, .. }) => self
                .vm
                .type_registry()
                .lookup(*tag)
                .map(|entry| match entry.kind {
                    TypeKind::Struct => ReplTypeDisplayCategory::Struct,
                    TypeKind::Record => ReplTypeDisplayCategory::Record,
                    TypeKind::EnumVariant => ReplTypeDisplayCategory::Enum,
                })
                .unwrap_or(ReplTypeDisplayCategory::Type),
            Some(_) => ReplTypeDisplayCategory::Type,
        };
        category.identity_label().to_string()
    }

    fn callable_display_category(kind: forge::ReplCallableKind) -> ReplTypeDisplayCategory {
        match kind {
            forge::ReplCallableKind::Closure => ReplTypeDisplayCategory::Closure,
            forge::ReplCallableKind::Capture => ReplTypeDisplayCategory::Capture,
        }
    }

    fn handle_error_mode(&mut self, mode: Option<&str>) -> ReplResult {
        let Some(mode) = mode else {
            return Self::plain(vec![format!(
                "error display mode: {}",
                self.error_display_mode.as_str()
            )]);
        };

        match ErrorDisplayMode::parse(mode.trim()) {
            Some(parsed) => {
                self.error_display_mode = parsed;
                Self::plain(vec![format!("error display mode: {}", parsed.as_str())])
            }
            None => self.repl_command_diagnostic(
                &format!(":error {}", mode.trim()),
                format!("Invalid error display mode `{}`.", mode.trim()),
                Span {
                    start: ":error ".chars().count(),
                    end: format!(":error {}", mode.trim()).chars().count(),
                },
                diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                Some("Usage: :error [full|summary]".to_string()),
                vec!["Use `:error full` or `:error summary`.".to_string()],
            ),
        }
    }

    fn handle_stacktrace_mode(&mut self, mode: Option<&str>) -> ReplResult {
        let Some(mode) = mode else {
            return Self::plain(vec![format!(
                "stacktrace display mode: {}",
                self.stack_trace_display_mode.as_str()
            )]);
        };
        let mode = mode.trim();

        if mode == "full" {
            return Self::plain(vec![
                "stacktrace display mode `full` is not supported yet.".to_string(),
                "Full stacktrace rendering is reserved for future HTMLViewer support.".to_string(),
                format!(
                    "stacktrace display mode: {}",
                    self.stack_trace_display_mode.as_str()
                ),
            ]);
        }

        match StackTraceDisplayMode::parse(mode) {
            Some(parsed) => {
                self.stack_trace_display_mode = parsed;
                Self::plain(vec![format!(
                    "stacktrace display mode: {}",
                    parsed.as_str()
                )])
            }
            None => self.repl_command_diagnostic(
                &format!(":stacktrace {}", mode),
                format!("Invalid stacktrace display mode `{}`.", mode),
                Span {
                    start: ":stacktrace ".chars().count(),
                    end: format!(":stacktrace {}", mode).chars().count(),
                },
                diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                Some("Usage: :stacktrace [off|verbose|full]".to_string()),
                vec![
                    "Use `:stacktrace off` or `:stacktrace verbose`.".to_string(),
                    "`:stacktrace full` is reserved for future HTMLViewer support.".to_string(),
                ],
            ),
        }
    }

    fn append_docs(&mut self, docs: Vec<DocEntry>) {
        for doc in docs {
            let exists = self.docs.iter().any(|existing| {
                existing.qualified_name == doc.qualified_name
                    && existing.kind == doc.kind
                    && existing.signature == doc.signature
                    && existing.doc == doc.doc
            });
            if !exists {
                self.docs.push(doc);
            }
        }
    }

    fn append_signatures(&mut self, signatures: Vec<SignatureEntry>) {
        for signature in signatures {
            let exists = self
                .signatures
                .iter()
                .any(|existing| existing == &signature);
            if !exists {
                self.signatures.push(signature);
            }
        }
    }

    /// Evaluate one line and return a structured `ReplResult`.
    ///
    /// The unified entry point used by both CLI and TUI.
    pub fn handle_line(&mut self, line: &str) -> ReplResult {
        self.handle_line_with_ast(line, None)
    }

    fn handle_line_with_ast(&mut self, line: &str, preparsed_ast: Option<Vec<Ast>>) -> ReplResult {
        if self.pending.is_empty() {
            let trimmed = line.trim();
            if trimmed.is_empty() {
                return Self::plain(vec![]);
            }
            if let Some(cmd) = parse_repl_command(trimmed) {
                match cmd {
                    ReplCommand::Quit => {
                        return ReplResult::exit(ReplOutput::StatusMessage("quit".to_string()));
                    }
                    ReplCommand::Help { topic } => {
                        let rendered = self.handle_help(topic.as_deref());
                        return Self::plain(rendered);
                    }
                    ReplCommand::Doc { symbol } => {
                        return self.handle_doc(&symbol);
                    }
                    ReplCommand::Sig { symbol } => {
                        return self.handle_sig(&symbol);
                    }
                    ReplCommand::Info { query } => {
                        return self.handle_info(&query);
                    }
                    ReplCommand::Type { symbol } => {
                        return self.handle_type(&symbol);
                    }
                    ReplCommand::Facet { query } => {
                        return self.handle_facet(&query);
                    }
                    ReplCommand::Error { mode } => {
                        return self.handle_error_mode(mode.as_deref());
                    }
                    ReplCommand::StackTrace { mode } => {
                        return self.handle_stacktrace_mode(mode.as_deref());
                    }
                    ReplCommand::ValueRecall { arg } => {
                        return self.handle_value_recall(&arg);
                    }
                    ReplCommand::Save { path } => {
                        return self.handle_save(&path);
                    }
                    ReplCommand::Vars => {
                        return self.handle_vars();
                    }
                    ReplCommand::Imported => {
                        return self.handle_imported();
                    }
                    ReplCommand::Defs => {
                        return self.handle_defs();
                    }
                    ReplCommand::History { selector } => {
                        return self.handle_history(selector.as_deref());
                    }
                    ReplCommand::Reload { mode } => {
                        return self.handle_reload(mode.as_deref());
                    }
                    ReplCommand::Clear => {
                        return self.handle_clear();
                    }
                    ReplCommand::Unknown { raw } => {
                        return self.repl_command_diagnostic(
                            &raw,
                            format!("Unknown REPL command: {}", raw),
                            Span {
                                start: 0,
                                end: raw.chars().count(),
                            },
                            diagnostics::ReplDiagnosticReason::CommandUnknown,
                            Some("Type :help for available REPL commands.".to_string()),
                            Vec::new(),
                        );
                    }
                }
            }
        }

        let idx = self.results.len();
        let source = line.to_string();
        let committed_line = self.next_line;

        self.pending.push_str(line);
        self.pending.push('\n');
        self.sources
            .update_source(self.repl_source_id, self.pending.clone());

        let parsed = match &preparsed_ast {
            Some(ast) => Ok(ast.clone()),
            None => spire::parse_with_context(
                &self.pending,
                crate::derive_parser_context(
                    self.repl_source_id.0,
                    SourceKind::ReplChunk,
                    CompileUnitKind::Repl,
                    None,
                ),
            ),
        };
        let ast = match parsed {
            Ok(ast) => ast,
            Err(e) if e.is_incomplete() => {
                return Self::plain(vec![]);
            }
            Err(e) => {
                let spec = diagnostics::parse_error_spec(self.repl_source_id, &self.pending, &e);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    self.repl_source_id,
                    &spec,
                    self.error_display_mode,
                );
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: self.pending.clone(),
                });
                self.pending.clear();
                self.bump_line(None, None);
                return ReplResult::ok(ReplOutput::EvalError {
                    idx,
                    source,
                    rendered,
                });
            }
        };

        if ast.is_empty() {
            self.pending.clear();
            return Self::plain(vec![]);
        }

        let mut source_number = committed_line;
        let owner_file =
            loop {
                let file = format!("REPL:{source_number}");
                if !self
                    .sources
                    .entries()
                    .iter()
                    .any(|entry| entry.file_name == file)
                    && !self.vm.bytecode().sources.iter().any(|entry| {
                        entry.normalized_path.as_deref().unwrap_or(&entry.path) == file
                    })
                {
                    break file;
                }
                source_number += 1;
            };
        let owner_source_id = self.sources.register(owner_file, self.pending.clone());
        let source_len = self.pending.chars().count();
        if !repl_source_span_fits(owner_source_id, source_len) {
            let spec = diagnostics::simple_error(
                "ReplSourceError",
                "REPL source span exceeds the runtime source range",
                Span {
                    start: 0,
                    end: source_len.min(1),
                },
                None,
            );
            let rendered = error_display::diagnostic_lines_by_id(
                &self.sources,
                owner_source_id,
                &spec,
                self.error_display_mode,
            );
            self.history_entries.push(ReplHistoryEntry {
                line: committed_line,
                source: self.pending.clone(),
            });
            self.pending.clear();
            self.bump_line(None, None);
            return ReplResult::ok(ReplOutput::EvalError {
                idx,
                source,
                rendered,
            });
        }

        let import_only = ast.iter().all(|stmt| matches!(stmt, Ast::Import(_, _, _)));
        let sigil_cp = self.sigil_session.checkpoint();
        let scar_cp = self.scar_session.checkpoint();
        let forge_cp = self.forge_session.checkpoint();
        let docs = crate::collect_doc_entries(&[], &ast, Some(self.repl_module_path.as_str()));
        let signatures =
            crate::collect_signature_entries(&[], &ast, Some(self.repl_module_path.as_str()));
        let resolved = match self
            .sigil_session
            .resolve(crate::rebase_module_ast_spans(ast.clone(), owner_source_id))
        {
            Ok(r) => r,
            Err(e) => {
                self.sigil_session.rollback(sigil_cp);
                self.scar_session.rollback(scar_cp);
                self.forge_session.rollback(forge_cp);
                let (source_id, spec) = self.resolve_diagnostic_for_repl(&e, self.repl_source_id);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    source_id,
                    &spec,
                    self.error_display_mode,
                );
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: self.pending.clone(),
                });
                self.pending.clear();
                self.bump_line(None, None);
                return ReplResult::ok(ReplOutput::EvalError {
                    idx,
                    source,
                    rendered,
                });
            }
        };

        let import_result = self.sigil_session.last_imports().clone();

        let typed = match self.scar_session.typecheck_with_context(
            resolved,
            Self::typecheck_context_for_source(SourceKind::ReplChunk),
        ) {
            Ok(t) => t,
            Err(e) => {
                self.sigil_session.rollback(sigil_cp);
                self.scar_session.rollback(scar_cp);
                self.forge_session.rollback(forge_cp);
                let (source_id, span) = crate::decode_rebased_module_span(&e.span)
                    .unwrap_or((owner_source_id, e.span.clone()));
                let spec = type_error_spec_from_scar(&self.sources, source_id, &e, span);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    source_id,
                    &spec,
                    self.error_display_mode,
                );
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: self.pending.clone(),
                });
                self.pending.clear();
                self.bump_line(None, None);
                return ReplResult::ok(ReplOutput::EvalError {
                    idx,
                    source,
                    rendered,
                });
            }
        };

        if let Some((span, names)) = unresolved_repl_binding_issue(&typed) {
            self.sigil_session.rollback(sigil_cp);
            self.scar_session.rollback(scar_cp);
            self.forge_session.rollback(forge_cp);
            let hint = if names.is_empty() {
                REPL_UNRESOLVED_TYPE_HINT.to_string()
            } else {
                format!(
                    "{} Affected binding(s): {}.",
                    REPL_UNRESOLVED_TYPE_HINT,
                    names.join(", ")
                )
            };
            let (source_id, span) =
                crate::decode_rebased_module_span(&span).unwrap_or((owner_source_id, span));
            let spec = diagnostics::simple_error(
                "ReplQueryError",
                REPL_UNRESOLVED_TYPE_MESSAGE,
                span,
                Some(hint),
            );
            let rendered = error_display::diagnostic_lines_by_id(
                &self.sources,
                source_id,
                &spec,
                self.error_display_mode,
            );
            self.history_entries.push(ReplHistoryEntry {
                line: committed_line,
                source: self.pending.clone(),
            });
            self.pending.clear();
            self.bump_line(None, None);
            return ReplResult::ok(ReplOutput::EvalError {
                idx,
                source,
                rendered,
            });
        }

        let (mut chunk, mut meta) = match self.forge_session.codegen_chunk_repl_result(typed) {
            Ok(c) => c,
            Err(e) => {
                self.sigil_session.rollback(sigil_cp);
                self.scar_session.rollback(scar_cp);
                self.forge_session.rollback(forge_cp);
                let (source_id, span) = crate::decode_rebased_module_span(&e.span)
                    .unwrap_or((owner_source_id, e.span.clone()));
                let spec = diagnostics::simple_error("CodegenError", &e.message, span, None);
                let rendered = error_display::diagnostic_lines_by_id(
                    &self.sources,
                    source_id,
                    &spec,
                    self.error_display_mode,
                );
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: self.pending.clone(),
                });
                self.pending.clear();
                self.bump_line(None, None);
                return ReplResult::ok(ReplOutput::EvalError {
                    idx,
                    source,
                    rendered,
                });
            }
        };
        let chunk_functions = chunk.functions.clone();
        meta.docs = docs.clone();
        chunk.docs = docs.clone();

        if let Some((source_str, file_name)) = self.sources.owned_context(owner_source_id) {
            self.vm.set_source(source_str, file_name);
        }

        let execution = self
            .execute_vm_chunk(chunk, ReplSessionPhase::Live)
            .and_then(|execution| {
                let value = eval::committed_chunk_value(execution);
                let main_error = self.report_main_result_error_if_any(&value)?;
                Ok((value, main_error))
            });
        match execution {
            Ok((value, main_error)) => {
                let committed_source = self.pending.clone();
                self.sync_scar_fun_index_with_vm();
                self.sync_repl_chunk_function_indices(&meta.function_defs, &chunk_functions);
                if let Some(rendered) = main_error {
                    let (stdout, stderr) = self.take_repl_host_io_lines();
                    self.history_entries.push(ReplHistoryEntry {
                        line: committed_line,
                        source: committed_source,
                    });
                    self.bump_line(None, None);
                    self.pending.clear();
                    return ReplResult::ok(ReplOutput::EvalError {
                        idx,
                        source,
                        rendered,
                    })
                    .with_stdout(stdout)
                    .with_stderr(stderr);
                }

                let rendered =
                    match render::format_result_lines(self.vm.as_vm(), Some(&value), Some(&meta)) {
                        Ok(rendered) => rendered,
                        Err(error) => {
                            let rendered =
                                error_display::runtime_error_lines_with_registry_and_stack_trace(
                                    &error,
                                    &self.sources,
                                    self.repl_source_id,
                                    self.vm.runtime_error_location(),
                                    self.error_display_mode,
                                    self.stack_trace_display_mode,
                                );
                            let (stdout, stderr) = self.take_repl_host_io_lines();
                            self.history_entries.push(ReplHistoryEntry {
                                line: committed_line,
                                source: committed_source,
                            });
                            self.bump_line(None, None);
                            self.pending.clear();
                            return ReplResult::exit(ReplOutput::EvalError {
                                idx,
                                source,
                                rendered,
                            })
                            .with_stdout(stdout)
                            .with_stderr(stderr);
                        }
                    };

                let (stdout, stderr) = self.take_repl_host_io_lines();
                let mut all_rendered = rendered;
                if import_only {
                    for label in &import_result.success_labels {
                        all_rendered.push(format!("Imported {}", label));
                    }
                }
                for imported in &import_result.imported_symbols {
                    self.insert_completion_symbol(imported.clone());
                }
                for b in &meta.bindings {
                    self.insert_completion_symbol(b.name.clone());
                }
                for name in &meta.function_defs {
                    self.insert_surface_symbol(name);
                }
                collect_callable_doc_snapshots(
                    &crate::rebase_module_ast_spans(ast.clone(), owner_source_id),
                    &self.repl_module_path,
                    &self.repl_module_path,
                    &mut self.callable_doc_snapshots,
                );
                for declaration in &signatures {
                    self.docs.retain(|entry| {
                        entry.kind != declaration.kind
                            || !sindr::names::surface_path_eq(
                                &entry.qualified_name,
                                &declaration.qualified_name,
                            )
                    });
                }
                self.append_docs(docs);
                self.append_signatures(signatures);
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: committed_source.clone(),
                });
                self.binding_records
                    .extend(meta.bindings.iter().map(|binding| ReplBindingRecord {
                        line: committed_line,
                        name: binding.name.clone(),
                        ty: crate::surface_rendered_name(&binding.ty),
                    }));
                self.import_records
                    .extend(Self::collect_import_records(&ast, committed_line));
                self.def_records
                    .extend(Self::collect_def_records(&ast, committed_line));
                self.sync_cached_completion_context_after_commit(
                    &import_result.imported_symbols,
                    &meta.bindings,
                    &meta.function_defs,
                );
                if Self::chunk_is_replayable(&ast) {
                    self.replay_inputs.push(ReplInput {
                        source: committed_source,
                        ast: preparsed_ast,
                    });
                }
                let history_value = history_value_for_result(&self.vm, &value, &meta);
                self.bump_line(Some(history_value), Some(meta.clone()));
                self.pending.clear();
                ReplResult::ok(ReplOutput::EvalSuccess {
                    idx,
                    source,
                    rendered: all_rendered,
                })
                .with_stdout(stdout)
                .with_stderr(stderr)
            }
            Err(e) => {
                let committed_source = self.pending.clone();
                self.sigil_session.rollback(sigil_cp);
                self.scar_session.rollback(scar_cp);
                self.forge_session.rollback(forge_cp);
                let location = e
                    .context
                    .call_site
                    .clone()
                    .or_else(|| self.vm.runtime_error_location());
                let rendered = error_display::runtime_error_lines_with_registry_and_stack_trace(
                    &e,
                    &self.sources,
                    self.repl_source_id,
                    location.clone(),
                    self.error_display_mode,
                    self.stack_trace_display_mode,
                );
                let (stdout, stderr) = self.take_repl_host_io_lines();
                self.history_entries.push(ReplHistoryEntry {
                    line: committed_line,
                    source: committed_source,
                });
                self.bump_line(None, None);
                self.pending.clear();
                ReplResult::exit(ReplOutput::EvalError {
                    idx,
                    source,
                    rendered,
                })
                .with_stdout(stdout)
                .with_stderr(stderr)
            }
        }
    }

    pub fn has_pending_background_work(&self) -> bool {
        self.vm.has_pending_background_work()
    }

    pub fn next_background_deadline_delay(&self) -> Option<std::time::Duration> {
        self.vm.next_background_deadline_delay()
    }

    pub fn pump_background_ready(&mut self) -> ReplResult {
        match self.vm.pump_background_ready() {
            Ok(()) => {
                let (stdout, stderr) = self.take_repl_host_io_lines();
                Self::plain(stdout).with_stderr(stderr)
            }
            Err(err) => {
                let location = err
                    .context
                    .call_site
                    .clone()
                    .or_else(|| self.vm.runtime_error_location());
                let rendered = error_display::runtime_error_lines_with_registry_and_stack_trace(
                    &err,
                    &self.sources,
                    self.repl_source_id,
                    location,
                    self.error_display_mode,
                    self.stack_trace_display_mode,
                );
                let (stdout, stderr) = self.take_repl_host_io_lines();
                ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: "<background>".to_string(),
                    rendered,
                })
                .with_stdout(stdout)
                .with_stderr(stderr)
            }
        }
    }

    pub fn advance_background_time(&mut self, elapsed: std::time::Duration) -> ReplResult {
        match self.vm.advance_background_time(elapsed) {
            Ok(()) => {
                let (stdout, stderr) = self.take_repl_host_io_lines();
                Self::plain(stdout).with_stderr(stderr)
            }
            Err(err) => {
                let location = err
                    .context
                    .call_site
                    .clone()
                    .or_else(|| self.vm.runtime_error_location());
                let rendered = error_display::runtime_error_lines_with_registry_and_stack_trace(
                    &err,
                    &self.sources,
                    self.repl_source_id,
                    location,
                    self.error_display_mode,
                    self.stack_trace_display_mode,
                );
                let (stdout, stderr) = self.take_repl_host_io_lines();
                ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: "<background>".to_string(),
                    rendered,
                })
                .with_stdout(stdout)
                .with_stderr(stderr)
            }
        }
    }

    pub fn pump_background_to_next_deadline(&mut self) -> ReplResult {
        match self.vm.pump_background_to_next_deadline() {
            Ok(_) => self.pump_background_ready(),
            Err(err) => {
                let location = err
                    .context
                    .call_site
                    .clone()
                    .or_else(|| self.vm.runtime_error_location());
                let rendered = error_display::runtime_error_lines_with_registry_and_stack_trace(
                    &err,
                    &self.sources,
                    self.repl_source_id,
                    location,
                    self.error_display_mode,
                    self.stack_trace_display_mode,
                );
                let (stdout, stderr) = self.take_repl_host_io_lines();
                ReplResult::ok(ReplOutput::EvalError {
                    idx: self.results.len(),
                    source: "<background>".to_string(),
                    rendered,
                })
                .with_stdout(stdout)
                .with_stderr(stderr)
            }
        }
    }

    fn handle_save(&mut self, arg: &str) -> ReplResult {
        if arg.is_empty() {
            return Self::plain(vec!["Usage: :save <path.eldr>".to_string()]);
        }

        let path = if arg.ends_with(".eldr") {
            arg.to_string()
        } else {
            format!("{}.eldr", arg)
        };

        let mut bytecode = self.vm.snapshot_bytecode();
        bytecode.docs = self.docs.clone();
        bytecode.signatures = self.signatures.clone();
        match bytecode.encode() {
            Err(e) => Self::plain(vec![format!("Error encoding bytecode: {}", e)]),
            Ok(bytes) => match fs::write(&path, bytes) {
                Ok(()) => Self::plain(vec![format!("saved to {}", path)]),
                Err(e) => Self::plain(vec![format!("Error writing {}: {}", path, e)]),
            },
        }
    }

    fn handle_value_recall(&mut self, arg: &str) -> ReplResult {
        if arg.is_empty() {
            self.bump_line(None, None);
            return Self::plain(vec!["Usage: :v <line>".to_string()]);
        }

        let line_num = match arg.parse::<usize>() {
            Ok(n) if n > 0 => n,
            _ => {
                self.bump_line(None, None);
                return self.repl_command_diagnostic(
                    &format!(":v {arg}"),
                    format!("Invalid line number for :v: {}", arg),
                    Span {
                        start: ":v ".chars().count(),
                        end: format!(":v {arg}").chars().count(),
                    },
                    diagnostics::ReplDiagnosticReason::CommandArgumentInvalid,
                    Some("Usage: :v <line>".to_string()),
                    Vec::new(),
                );
            }
        };

        if line_num > self.results.len() {
            self.bump_line(None, None);
            return Self::plain(vec![format!("No such line: {}", line_num)]);
        }

        match self.results[line_num - 1].clone() {
            Some(value) => match inspect_value(self.vm.as_vm(), &value) {
                Ok(displayed) => {
                    self.bump_line(Some(value), None);
                    Self::plain(vec![displayed])
                }
                Err(error) => {
                    let rendered = error_display::runtime_error_lines_with_registry_and_stack_trace(
                        &error,
                        &self.sources,
                        self.repl_source_id,
                        self.vm.runtime_error_location(),
                        self.error_display_mode,
                        self.stack_trace_display_mode,
                    );
                    self.bump_line(None, None);
                    ReplResult::exit(ReplOutput::PlainText { lines: rendered })
                }
            },
            None => {
                self.bump_line(None, None);
                Self::plain(vec![format!("Line {} has no value", line_num)])
            }
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PreloadRuntimeExecution {
    Execute,
    Defer,
}

fn compile_default_repl_bootstrap_chunk() -> Result<PreloadedChunkState, ReplLoadError> {
    compile_preloaded_repl_chunk_with_runtime(None, None, PreloadRuntimeExecution::Defer)
}

fn compile_preloaded_repl_chunk(
    module: Option<(&str, &str)>,
    script: Option<(&str, &str)>,
) -> Result<PreloadedChunkState, ReplLoadError> {
    compile_preloaded_repl_chunk_with_runtime(module, script, PreloadRuntimeExecution::Execute)
}

fn compile_preloaded_repl_chunk_with_runtime(
    module: Option<(&str, &str)>,
    script: Option<(&str, &str)>,
    runtime_execution: PreloadRuntimeExecution,
) -> Result<PreloadedChunkState, ReplLoadError> {
    let std_module_inputs =
        collect_additional_default_std_module_inputs().map_err(ReplLoadError::Load)?;
    let prepared_script = prepare_script_preload(script)?;
    let mut module_input_stages = vec![std_module_inputs];
    if let Some((file_name, source)) = module {
        module_input_stages.push(vec![crate::ModuleInput {
            file_name: file_name.to_string(),
            source: source.to_string(),
            module_path: crate::module_path_from_source_or_file_name(file_name, source),
        }]);
    }
    if let Some(script) = prepared_script.as_ref() {
        for module in &script.include_modules {
            module_input_stages.push(vec![module.clone()]);
        }
    }
    compile_repl_preload_from_module_stages(
        module_input_stages,
        prepared_script,
        PreloadCompileMode::SCRIPT,
        runtime_execution,
    )
}

fn compile_project_repl_chunk(
    project_module_input_stages: &[Vec<crate::ModuleInput>],
) -> Result<PreloadedChunkState, ReplLoadError> {
    let std_module_inputs =
        collect_additional_default_std_module_inputs().map_err(ReplLoadError::Load)?;
    let mut module_input_stages = vec![std_module_inputs];
    module_input_stages.extend(project_module_input_stages.iter().cloned());
    compile_repl_preload_from_module_stages(
        module_input_stages,
        None,
        PreloadCompileMode::PROJECT,
        PreloadRuntimeExecution::Execute,
    )
}

fn compile_repl_preload_from_module_stages(
    module_input_stages: Vec<Vec<crate::ModuleInput>>,
    prepared_script: Option<PreparedScriptPreload>,
    mode: PreloadCompileMode,
    runtime_execution: PreloadRuntimeExecution,
) -> Result<PreloadedChunkState, ReplLoadError> {
    let mut repl_sources = loader::collect_repl_sources_with_module_stages(&module_input_stages)
        .map_err(ReplLoadError::Load)?;

    let user_file_name = prepared_script
        .as_ref()
        .map(|script| script.file_name.as_str())
        .unwrap_or("<repl-preload>");
    let user_source = prepared_script
        .as_ref()
        .map(|script| script.source_for_parse.as_str())
        .unwrap_or("");
    let user_source_id = repl_sources.sources.register(user_file_name, user_source);
    let compile_sources = crate::CompileSources {
        module_source_ids: repl_sources
            .module_stages
            .iter()
            .flat_map(|stage| stage.iter().map(|entry| entry.source_id))
            .collect(),
        sources: repl_sources.sources.clone(),
        user_source_id,
        user_module_path: crate::script_pseudo_module_path(user_file_name),
        builtin_source_id: repl_sources.builtin_source_id,
        builtin_module_path: Some("Bootstrap".to_string()),
        module_stages: repl_sources.module_stages.clone(),
        stdlib_variant: crate::StdlibVariant::Default,
    };
    let snapshot = crate::default_stdlib_semantic_snapshot().map_err(ReplLoadError::Load)?;
    let (module_stage_asts, raw_module_stages, user_ast, script_runtime_inputs) =
        parse_preload_sources(&compile_sources, &snapshot, mode.compile_unit_kind)?;

    let script_preload_docs = crate::collect_doc_entries(
        &[],
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );
    let script_preload_signatures = crate::collect_signature_entries(
        &[],
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );
    let process_metadata = collect_process_metadata(&module_stage_asts);
    let docs = crate::collect_doc_entries_with_base(
        &snapshot.docs,
        if module_stage_asts.len() > snapshot.default_stage_count {
            &module_stage_asts[snapshot.default_stage_count..]
        } else {
            &[]
        },
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );
    let signatures = crate::collect_signature_entries_with_base(
        &snapshot.signatures,
        if module_stage_asts.len() > snapshot.default_stage_count {
            &module_stage_asts[snapshot.default_stage_count..]
        } else {
            &[]
        },
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );

    let mut callable_doc_snapshots = CallableDocSnapshots::default();
    for module in module_stage_asts.iter().flatten() {
        collect_callable_doc_snapshots(
            &module.ast,
            &module.module_path,
            module
                .doc_module_path
                .as_deref()
                .unwrap_or(&module.module_path),
            &mut callable_doc_snapshots,
        );
    }
    collect_callable_doc_snapshots(
        &crate::rebase_module_ast_spans(user_ast.clone(), user_source_id),
        &repl_sources.repl_module_path,
        &compile_sources.user_module_path,
        &mut callable_doc_snapshots,
    );

    let mut precollected = if module_stage_asts.len() == snapshot.default_stage_count {
        sigil::PrecollectedDeclarations {
            declaration_index: snapshot.declaration_index().clone(),
            owner_registry: sigil::precollect_owner_registry(&module_stage_asts)
                .map_err(|e| preload_resolve_error(&compile_sources, &e))?,
        }
    } else {
        sigil::precollect_declarations(&module_stage_asts)
            .map_err(|e| preload_resolve_error(&compile_sources, &e))?
    };
    merge_user_preload_declarations(
        &mut precollected,
        &user_ast,
        &compile_sources.user_module_path,
        module_stage_asts.len(),
        &compile_sources,
    )?;
    let declaration_index = precollected.declaration_index.clone();

    let mut staged_program = sigil::resolve_staged_program_from_state(
        &module_stage_asts,
        Vec::new(),
        &declaration_index,
        Some(compile_sources.user_module_path.clone()),
        snapshot.default_stage_count,
        snapshot.resolve_state(),
    )
    .map_err(|e| preload_resolve_error(&compile_sources, &e))?;

    let environment =
        sigil::ResolveEnvironment::from_precollected(&module_stage_asts, &precollected);
    let mut sigil_session = sigil::SigilSession::from_environment(
        &environment,
        Some(repl_sources.repl_module_path.clone()),
        staged_program.resume_state,
    )
    .map_err(|e| preload_resolve_error(&compile_sources, &e))?;

    let mut preload_imported = Vec::new();
    if !user_ast.is_empty() {
        let source = compile_sources
            .sources
            .source(user_source_id)
            .expect("preload source");
        if !repl_source_span_fits(user_source_id, source.chars().count()) {
            return Err(ReplLoadError::Diagnostic {
                phase: "parse".into(),
                sources: compile_sources.sources.clone(),
                source_id: user_source_id,
                spec: diagnostics::simple_error(
                    "SourceError",
                    "REPL source span exceeds the runtime source range",
                    Span {
                        start: 0,
                        end: source.chars().count().min(1),
                    },
                    None,
                ),
            });
        }
        let user_resolved = sigil_session
            .resolve(crate::rebase_module_ast_spans(
                user_ast.clone(),
                user_source_id,
            ))
            .map_err(|e| preload_resolve_error(&compile_sources, &e))?;
        preload_imported = sigil_session.last_imports().imported_symbols.clone();
        bind_preload_script_qualified_names(
            &mut sigil_session,
            &user_ast,
            &compile_sources.user_module_path,
        );
        staged_program.resolved.extend(user_resolved);
    }

    let mut scar_session = snapshot.compile_prefix().restored_scar_session();
    let typed = scar_session
        .typecheck_staged_program_with_context(
            staged_program,
            scar::TypecheckContext::from_source_policy(
                mode.runtime_source_kind
                    .policy(mode.compile_unit_kind, None),
            ),
        )
        .map_err(|e| ReplLoadError::Diagnostic {
            // Keep the structured checker envelope intact when this error
            // crosses the REPL loader boundary.
            phase: e
                .structured
                .as_ref()
                .map(diagnostics::compile_error_phase)
                .unwrap_or("typecheck")
                .to_string(),
            sources: compile_sources.sources.clone(),
            source_id: diagnostic_source_id(&compile_sources, &e.span),
            spec: type_error_spec_from_scar(
                &compile_sources.sources,
                diagnostic_source_id(&compile_sources, &e.span),
                &e,
                local_diagnostic_span(&compile_sources, &e.span),
            ),
        })?;

    let mut forge_session = snapshot.compile_prefix().forge_session();
    let (mut chunk, meta) = forge_session
        .codegen_chunk_typed_program(typed)
        .map_err(|e| ReplLoadError::Diagnostic {
            phase: "codegen".to_string(),
            sources: compile_sources.sources.clone(),
            source_id: diagnostic_source_id(&compile_sources, &e.span),
            spec: diagnostics::simple_error(
                "CodegenError",
                &e.message,
                local_diagnostic_span(&compile_sources, &e.span),
                None,
            ),
        })?;
    chunk.docs = docs.clone();
    chunk.signatures = signatures.clone();

    let source_context = compile_sources
        .sources
        .owned_context(user_source_id)
        .or_else(|| {
            compile_sources
                .sources
                .owned_context(compile_sources.builtin_source_id)
        });
    let vm = match runtime_execution {
        PreloadRuntimeExecution::Execute => {
            let mut vm = match source_context {
                Some((source, file_name)) => {
                    session::bytecode_interactive_vm(snapshot.bytecode().clone())
                        .with_source(source, file_name)
                }
                None => session::bytecode_interactive_vm(snapshot.bytecode().clone()),
            };
            register_runtime_sources(
                &mut vm,
                &compile_sources.sources,
                repl_sources.repl_source_id,
            )
            .map_err(|e| ReplLoadError::Runtime {
                file_name: "<repl-preload>".into(),
                message: e.to_string(),
            })?;
            record_repl_runtime_boot_call();
            vm.push_chunk(chunk, ReplSessionPhase::Preload.execution_policy())
                .map_err(|e| ReplLoadError::Runtime {
                    file_name: compile_sources
                        .sources
                        .file_name(user_source_id)
                        .unwrap_or("<repl-preload>")
                        .to_string(),
                    message: e.to_string(),
                })?;
            vm
        }
        PreloadRuntimeExecution::Defer => {
            let mut bytecode =
                forge::compose_bytecode_with_chunk(snapshot.bytecode().clone(), chunk).map_err(
                    |e| ReplLoadError::Diagnostic {
                        phase: "codegen".to_string(),
                        sources: compile_sources.sources.clone(),
                        source_id: diagnostic_source_id(&compile_sources, &e.span),
                        spec: diagnostics::simple_error(
                            "CodegenError",
                            &e.message,
                            local_diagnostic_span(&compile_sources, &e.span),
                            None,
                        ),
                    },
                )?;
            bytecode.sources =
                runtime_source_entries(&compile_sources.sources, repl_sources.repl_source_id);
            match source_context {
                Some((source, file_name)) => {
                    session::bytecode_interactive_vm(bytecode).with_source(source, file_name)
                }
                None => session::bytecode_interactive_vm(bytecode),
            }
        }
    };

    let mut symbols: BTreeSet<String> = sindr::names::SPECIAL_ENUM_VARIANT_METAS
        .iter()
        .map(|meta| meta.bare_alias.to_string())
        .chain(
            builtin_function_metas()
                .iter()
                .map(|meta| meta.name.to_string()),
        )
        .collect();
    for entry in vm.bytecode().functions.iter() {
        if let Some(name) = &entry.qualified_name {
            let surface_name = crate::surface_rendered_name(name);
            symbols.insert(surface_name.clone());
            if let Some(short) = surface_name.rsplit("::").next() {
                symbols.insert(short.to_string());
            }
        }
    }
    for entry in vm.bytecode().type_registry.entries().iter() {
        let surface_name = crate::surface_rendered_name(&entry.name);
        symbols.insert(surface_name.clone());
        if let Some(short) = surface_name.rsplit("::").next() {
            symbols.insert(short.to_string());
        }
    }
    for binding in &meta.bindings {
        symbols.insert(binding.name.clone());
    }
    for visible in apply_preload_visible_names(&user_ast, preload_imported) {
        symbols.insert(visible);
    }

    let auto_import_modules = module_stage_asts
        .iter()
        .flat_map(|stage| stage.iter())
        .filter(|module| module.auto_import)
        .map(|module| module.module_path.clone())
        .collect();
    let auto_import_records =
        ReplEngine::collect_auto_import_records(&module_stage_asts, &declaration_index);
    let import_records = ReplEngine::collect_import_records(&user_ast, 0);
    let def_records = ReplEngine::collect_def_records(&user_ast, 0);

    Ok(PreloadedChunkState {
        sources: repl_sources.sources,
        repl_source_id: repl_sources.repl_source_id,
        repl_module_path: repl_sources.repl_module_path,
        module_stages: raw_module_stages,
        declaration_index,
        sigil_session,
        scar_checkpoint: scar_session.checkpoint(),
        vm,
        docs,
        callable_doc_snapshots,
        signatures,
        process_metadata,
        symbols,
        auto_import_modules,
        auto_import_records,
        script_runtime_inputs,
        script_preload_docs,
        script_preload_signatures,
        import_records,
        def_records,
    })
}

fn parse_preload_sources(
    compile_sources: &crate::CompileSources,
    snapshot: &crate::DefaultStdlibSnapshot,
    compile_unit_kind: CompileUnitKind,
) -> Result<
    (
        Vec<Vec<sigil::StagedModuleAst>>,
        Vec<Vec<StagedModule>>,
        Vec<Ast>,
        Vec<ReplInput>,
    ),
    ReplLoadError,
> {
    let expanded =
        crate::expand_snapshot_module_stages(compile_sources, snapshot, compile_unit_kind)
            .map_err(|e| ReplLoadError::Diagnostic {
                phase: "parse".to_string(),
                sources: compile_sources.sources.clone(),
                source_id: e.source_id,
                spec: e.diagnostic_spec(&compile_sources.sources),
            })?;
    let mut module_stage_asts = expanded.module_stages.into_owned();
    let raw_module_stages = compile_sources.module_stages.clone();

    let user_source = compile_sources
        .sources
        .source(compile_sources.user_source_id)
        .unwrap_or("");
    let user_ast = crate::parse_file_source(
        user_source,
        crate::derive_parser_context(
            compile_sources.user_source_id.0,
            SourceKind::Script,
            CompileUnitKind::Script,
            None,
        ),
        compile_sources
            .sources
            .file_name(compile_sources.user_source_id)
            .expect("registered preload source"),
    )
    .map_err(|e| ReplLoadError::Diagnostic {
        phase: "parse".to_string(),
        sources: compile_sources.sources.clone(),
        source_id: compile_sources.user_source_id,
        spec: diagnostics::parse_error_spec(compile_sources.user_source_id, user_source, &e),
    })?;
    let (preload_ast, script_runtime_inputs) = split_preload_script_ast(&user_ast, user_source);
    let (process_stage, preload_ast) = crate::extract_process_modules_from_user_ast(preload_ast);
    if !process_stage.is_empty() {
        module_stage_asts.push(process_stage);
    }

    Ok((
        module_stage_asts,
        raw_module_stages,
        preload_ast,
        script_runtime_inputs,
    ))
}

fn collect_process_metadata(
    module_stages: &[Vec<sigil::StagedModuleAst>],
) -> BTreeMap<String, ReplProcessMetadata> {
    let mut out = BTreeMap::new();
    for stage in module_stages {
        for module in stage {
            if let Some(spec) = &module.process_spec {
                out.insert(
                    spec.process_name.clone(),
                    ReplProcessMetadata {
                        kind: spec.kind,
                        instance: spec.instance,
                        handler_specs: spec.handler_specs.clone(),
                    },
                );
            }
        }
    }
    out
}

fn split_preload_script_ast(ast: &[Ast], source: &str) -> (Vec<Ast>, Vec<ReplInput>) {
    let first_runtime_index = ast
        .iter()
        .position(|stmt| !is_preload_declaration(stmt))
        .unwrap_or(ast.len());
    let preload_ast = ast[..first_runtime_index].to_vec();
    let runtime_inputs = ast[first_runtime_index..]
        .iter()
        .filter_map(|stmt| {
            let span = ast_span(stmt)?;
            let snippet = source
                .chars()
                .skip(span.start)
                .take(span.end.saturating_sub(span.start))
                .collect::<String>();
            let trimmed = snippet.trim();
            (!trimmed.is_empty()).then(|| ReplInput {
                source: trimmed.to_string(),
                ast: Some(spire::map_ast_spans(vec![stmt.clone()], &|inner| {
                    spire::ast::Span {
                        start: inner.start - span.start,
                        end: inner.end - span.start,
                    }
                })),
            })
        })
        .collect();
    (preload_ast, runtime_inputs)
}

fn is_preload_declaration(stmt: &Ast) -> bool {
    matches!(
        stmt,
        Ast::Import(_, _, _)
            | Ast::Def(..)
            | Ast::ExtractorDef(..)
            | Ast::ConstDef(..)
            | Ast::SupervisorInit(..)
            | Ast::StructDef(..)
            | Ast::RecordDef(..)
            | Ast::DeferrorDef(..)
            | Ast::EnumDef(..)
            | Ast::TraitDef(..)
            | Ast::TraitImplDef(..)
            | Ast::ImplDef(..)
            | Ast::Namespace(..)
            | Ast::Defagent(..)
            | Ast::Defgenserver(..)
            | Ast::Defsupervisor(..)
            | Ast::DefdynamicSupervisor(..)
            | Ast::BuiltinDecl(..)
            | Ast::BuiltinReflectionDecl(..)
            | Ast::IntrinsicDecl(..)
            | Ast::BuiltinExtractorDecl(..)
            | Ast::BuiltinTypeDecl(..)
    )
}

fn ast_span(stmt: &Ast) -> Option<&Span> {
    match stmt {
        Ast::PatternConsumerCall(span, _, _)
        | Ast::NumberedPlaceholder(span, _)
        | Ast::Lit(span, _)
        | Ast::Var(span, _)
        | Ast::InternalVar(span, _)
        | Ast::Path(span, _)
        | Ast::FuncLiteralRef(span, _)
        | Ast::NamedInfixRef(span, _)
        | Ast::App(span, _, _)
        | Ast::ReturnTypeArgumentApply(span, _, _)
        | Ast::Block(span, _)
        | Ast::Bind(span, _, _)
        | Ast::SafeBind(span, _, _, _)
        | Ast::StatementQuestion(span, _)
        | Ast::Do(span, _, _, _)
        | Ast::BinOp(span, _, _, _)
        | Ast::Pipe(span, _, _)
        | Ast::ContextMap(span, _, _)
        | Ast::ContextApply(span, _, _)
        | Ast::ContextBind(span, _, _)
        | Ast::Compose(span, _, _)
        | Ast::LiftedCompose(span, _, _)
        | Ast::KleisliCompose(span, _, _)
        | Ast::ListNil(span)
        | Ast::ListCons(span, _, _)
        | Ast::ListLiteral(span, _)
        | Ast::HashMapLiteral(span, _)
        | Ast::RangeLiteral(span, _, _)
        | Ast::TupleLiteral(span, _)
        | Ast::Grouped(span, _)
        | Ast::InterpolatedStr(span, _)
        | Ast::Dbg(span, _)
        | Ast::Cond(span, _)
        | Ast::Match(span, _, _)
        | Ast::BulkUpdate(span, _, _)
        | Ast::FieldAccess(span, _, _)
        | Ast::FacetSegmentAccess(span, _, _)
        | Ast::FacetCapture(span, _)
        | Ast::StructDef(span, ..)
        | Ast::RecordDef(span, _, _, _)
        | Ast::StructLit(span, _, _)
        | Ast::InternalStructLit(span, _, _)
        | Ast::ConstructorCall(span, _, _)
        | Ast::EnumConstructorCall(span, _, _, _, _)
        | Ast::DeferrorDef(span, _, _, _, _)
        | Ast::EnumDef(span, _, _, _, _)
        | Ast::Def(span, ..)
        | Ast::ConstDef(span, _, _, _, _)
        | Ast::SupervisorInit(span, _)
        | Ast::ExtractorDef(span, _, _, _, _, _, _)
        | Ast::BuiltinDecl(span, ..)
        | Ast::BuiltinReflectionDecl(span, _, _)
        | Ast::Reflection(span, _)
        | Ast::IntrinsicDecl(span, _, _, _)
        | Ast::BuiltinExtractorDecl(span, _, _, _, _)
        | Ast::BuiltinTypeDecl(span, _, _)
        | Ast::TypeAlias(span, _, _, _)
        | Ast::Defmod(span, _, _, _)
        | Ast::Defagent(span, _, _, _, _)
        | Ast::Defgenserver(span, _, _, _, _)
        | Ast::Defsupervisor(span, _, _, _, _)
        | Ast::DefdynamicSupervisor(span, _, _, _, _)
        | Ast::Namespace(span, _, _)
        | Ast::ImplDef(span, _, _, _, _)
        | Ast::TraitDef(span, ..)
        | Ast::TraitImplDef(span, ..)
        | Ast::Import(span, _, _)
        | Ast::Include(span, _)
        | Ast::Closure(span, _, _)
        | Ast::ExtractorClosure(span, _, _)
        | Ast::Capture(span, _, _)
        | Ast::CapturePlaceholder(span, _)
        | Ast::Semi(span, _) => Some(span),
    }
}

fn prepare_script_preload(
    script: Option<(&str, &str)>,
) -> Result<Option<PreparedScriptPreload>, ReplLoadError> {
    let Some((file_name, source)) = script else {
        return Ok(None);
    };

    let prepared = crate::prepare_script_sources(file_name, source, SourceKind::Script)
        .map_err(|e| preload_script_prepare_error(file_name, source, e))?;

    Ok(Some(PreparedScriptPreload {
        file_name: file_name.to_string(),
        source_for_parse: prepared.source_for_parse,
        include_modules: prepared.include_modules,
    }))
}

fn merge_user_preload_declarations(
    precollected: &mut sigil::PrecollectedDeclarations,
    user_ast: &[Ast],
    user_module_path: &str,
    stage_index: usize,
    compile_sources: &crate::CompileSources,
) -> Result<(), ReplLoadError> {
    if user_ast.is_empty() {
        return Ok(());
    }

    let stage = vec![sigil::StagedModuleAst {
        source_index: 0,
        module_path: user_module_path.to_string(),
        doc_module_path: Some(user_module_path.to_string()),
        ast: user_ast.to_vec(),
        owner: None,
        module_doc: None,
        auto_import: false,
        process_spec: None,
    }];
    let mut staged_user = vec![Vec::new(); stage_index];
    staged_user.push(stage);
    let user_precollected = sigil::precollect_declarations(&staged_user)
        .map_err(|e| preload_resolve_error(compile_sources, &e))?;

    let mut validated_owner_registry = precollected.owner_registry.clone();
    validated_owner_registry
        .merge(&user_precollected.owner_registry)
        .map_err(|e| preload_resolve_error(compile_sources, &e))?;

    for (fq_name, entry) in user_precollected.declaration_index {
        precollected.declaration_index.insert(fq_name, entry);
    }
    Ok(())
}

fn preload_script_prepare_error(
    file_name: &str,
    source: &str,
    error: crate::ScriptSourcePrepareError,
) -> ReplLoadError {
    match error {
        crate::ScriptSourcePrepareError::Parse { error } => preload_script_diagnostic(
            file_name,
            source,
            diagnostics::parse_error_spec(diagnostics::SourceId(0), source, &error),
        ),
        crate::ScriptSourcePrepareError::IncludeRead { message, span } => {
            preload_script_load_error(file_name, source, span, message)
        }
    }
}

fn preload_script_load_error(
    file_name: &str,
    source: &str,
    span: Span,
    message: String,
) -> ReplLoadError {
    preload_script_diagnostic(
        file_name,
        source,
        diagnostics::simple_error("LoadError", message, span, None),
    )
}

fn preload_script_diagnostic(
    file_name: &str,
    source: &str,
    spec: diagnostics::DiagnosticSpec,
) -> ReplLoadError {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register(file_name, source.to_string());
    ReplLoadError::Diagnostic {
        phase: "parse".to_string(),
        sources,
        source_id,
        spec,
    }
}

fn resolve_diagnostic_reason(
    reason: &sigil::error::ResolveErrorReason,
) -> Result<diagnostics::ResolveDiagnosticReason, &spire::error::ParseError> {
    use diagnostics::ResolveDiagnosticReason as D;
    use sigil::error::ResolveErrorReason as R;
    Ok(match reason {
        R::NameResolution => D::NameResolution,
        R::Namespace => D::Namespace,
        R::Visibility => D::Visibility,
        R::Import => D::Import,
        R::Capture => D::Capture,
        R::ConstructorCaptureForbidden => D::ConstructorCaptureForbidden,
        R::Pattern => D::Pattern,
        R::Declaration => D::Declaration,
        R::SpecialForm => D::SpecialForm,
        R::SourcePolicy => D::SourcePolicy,
        R::InvalidIntrinsicSurfaceContract => D::InvalidIntrinsicSurfaceContract,
        R::ReservedIntrinsicMarkerDeclaration => D::ReservedIntrinsicMarkerDeclaration,
        R::ReservedIntrinsicMarkerImpl => D::ReservedIntrinsicMarkerImpl,
        R::CompilerInvariant => D::CompilerInvariant,
        R::DeferredParse(error) => return Err(error),
    })
}

fn preload_resolve_error(
    compile_sources: &crate::CompileSources,
    error: &sigil::error::ResolveError,
) -> ReplLoadError {
    let source_id = diagnostic_source_id(compile_sources, &error.span);
    let reason = match resolve_diagnostic_reason(&error.diagnostic.reason) {
        Ok(reason) => reason,
        Err(parse_error) => {
            let source = compile_sources
                .sources
                .source(source_id)
                .expect("resolved diagnostic source");
            let local_error = parse_error
                .clone()
                .map_spans(|span| local_diagnostic_span(compile_sources, span));
            return ReplLoadError::Diagnostic {
                phase: "parse".to_string(),
                sources: compile_sources.sources.clone(),
                source_id,
                spec: diagnostics::parse_error_spec(source_id, source, &local_error),
            };
        }
    };
    let labels = error
        .related_labels
        .iter()
        .map(|label| {
            (
                diagnostic_source_id(compile_sources, &label.span),
                local_diagnostic_span(compile_sources, &label.span),
                label.message.clone(),
            )
        })
        .collect::<Vec<_>>();
    let spec = diagnostics::resolve_error_spec(
        source_id,
        &error.message,
        local_diagnostic_span(compile_sources, &error.span),
        reason,
        error.diagnostic.subject.clone(),
        &labels,
    );
    ReplLoadError::Diagnostic {
        phase: "resolve".to_string(),
        sources: compile_sources.sources.clone(),
        source_id,
        spec,
    }
}

fn collect_callable_doc_snapshots(
    ast: &[Ast],
    runtime_module: &str,
    doc_module: &str,
    snapshots: &mut CallableDocSnapshots,
) {
    fn qualified(module: &str, name: &str) -> String {
        let module = crate::surface_path_name(module);
        let name = crate::surface_path_name(name);
        if module.is_empty()
            || name
                .strip_prefix(module)
                .is_some_and(|rest| rest.starts_with("::"))
        {
            name.to_string()
        } else {
            format!("{module}::{name}")
        }
    }
    for statement in ast {
        match statement {
            Ast::Def(span, name, ..) | Ast::ExtractorDef(span, name, ..) => {
                let docs = crate::collect_doc_entries(
                    &[],
                    std::slice::from_ref(statement),
                    Some(doc_module),
                );
                if let Some(doc) = docs.into_iter().find(|doc| doc.kind == DocKind::Function) {
                    snapshots
                        .functions
                        .entry((
                            qualified(runtime_module, name),
                            span.start as u32,
                            span.end as u32,
                        ))
                        .or_insert(doc);
                }
            }
            Ast::TraitDef(_, owner, _, _, methods, _) => {
                let docs = crate::collect_doc_entries(
                    &[],
                    std::slice::from_ref(statement),
                    Some(doc_module),
                );
                for method in methods {
                    let member = format!("{owner}::{}", method.name);
                    let runtime_identity = qualified(runtime_module, &member);
                    let doc_identity = qualified(doc_module, &member);
                    let doc = docs
                        .iter()
                        .find(|doc| {
                            doc.kind == DocKind::Function
                                && sindr::names::surface_path_eq(&doc.qualified_name, &doc_identity)
                        })
                        .cloned();
                    snapshots
                        .trait_methods
                        .entry(runtime_identity)
                        .or_insert(doc);
                }
            }
            Ast::ImplDef(_, owner, _, methods, _) => {
                let docs = crate::collect_doc_entries(
                    &[],
                    std::slice::from_ref(statement),
                    Some(doc_module),
                );
                for method in methods {
                    let (span, name) = match method {
                        Ast::Def(span, name, ..) | Ast::ExtractorDef(span, name, ..) => {
                            (span, name)
                        }
                        _ => continue,
                    };
                    let name = qualified(owner, name);
                    if let Some(doc) = docs.iter().find(|doc| {
                        doc.kind == DocKind::Function
                            && sindr::names::surface_path_eq(&doc.qualified_name, &name)
                    }) {
                        snapshots
                            .functions
                            .entry((name, span.start as u32, span.end as u32))
                            .or_insert_with(|| doc.clone());
                    }
                }
            }
            Ast::Semi(_, statement) => {
                collect_callable_doc_snapshots(
                    std::slice::from_ref(statement.as_ref()),
                    runtime_module,
                    doc_module,
                    snapshots,
                );
            }
            _ => {}
        }
    }
}

fn bind_preload_script_qualified_names(
    sigil_session: &mut sigil::SigilSession,
    user_ast: &[Ast],
    module_path: &str,
) {
    for stmt in user_ast {
        let Some(name) = preload_decl_name(stmt) else {
            continue;
        };
        let Some(uid) = sigil_session.lookup_uid(name) else {
            continue;
        };
        let qualified = format!("{module_path}::{name}");
        sigil_session.define_with_id(&qualified, uid);
    }
}

fn preload_decl_name(stmt: &Ast) -> Option<&str> {
    match stmt {
        Ast::Def(_, name, ..)
        | Ast::ExtractorDef(_, name, ..)
        | Ast::ConstDef(_, name, ..)
        | Ast::StructDef(_, name, ..)
        | Ast::RecordDef(_, name, ..)
        | Ast::DeferrorDef(_, name, ..)
        | Ast::EnumDef(_, name, ..)
        | Ast::TraitDef(_, name, ..) => Some(name.as_str()),
        _ => None,
    }
}

fn diagnostic_source_id(compile_sources: &crate::CompileSources, span: &Span) -> SourceId {
    if let Some((source_id, _)) = crate::decode_rebased_module_span(span) {
        return source_id;
    }
    compile_sources.user_source_id
}

fn local_diagnostic_span(compile_sources: &crate::CompileSources, span: &Span) -> Span {
    if let Some((_, local_span)) = crate::decode_rebased_module_span(span) {
        return local_span;
    }
    let source = compile_sources
        .sources
        .source(compile_sources.user_source_id)
        .unwrap_or("");
    if source.chars().count() >= span.end {
        span.clone()
    } else {
        Span { start: 0, end: 0 }
    }
}

fn history_value_for_result(
    vm: &eldr::InteractiveVm,
    value: &Value,
    meta: &forge::ChunkMeta,
) -> Value {
    if matches!(value, Value::Unit) {
        if let Some(binding) = meta.bindings.last() {
            if let Some(bound) = vm.get_local(binding.slot_id) {
                return bound;
            }
        }
    }
    value.clone()
}

fn collect_unresolved_pattern_binding_names(pat: &TypedPattern, names: &mut Vec<String>) {
    match pat {
        TypedPattern::Located(_, inner) => collect_unresolved_pattern_binding_names(inner, names),
        TypedPattern::Var(ty, id) => {
            if scar::type_contains_unresolved_vars(ty) {
                names.push(id.name.clone());
            }
        }
        TypedPattern::As(ty, inner, id) => {
            if scar::type_contains_unresolved_vars(ty) {
                names.push(id.name.clone());
            }
            collect_unresolved_pattern_binding_names(inner, names);
        }
        TypedPattern::ListCons(_, head, tail) => {
            collect_unresolved_pattern_binding_names(head, names);
            collect_unresolved_pattern_binding_names(tail, names);
        }
        TypedPattern::HashMap(_, entries) => {
            for entry in entries {
                collect_unresolved_pattern_binding_names(&entry.pattern, names);
            }
        }
        TypedPattern::Tuple(_, items)
        | TypedPattern::Constructor { fields: items, .. }
        | TypedPattern::Extractor { items, .. } => {
            for item in items {
                collect_unresolved_pattern_binding_names(item, names);
            }
        }
        TypedPattern::Wildcard(_)
        | TypedPattern::Pin(_, _, _)
        | TypedPattern::ListNil(_)
        | TypedPattern::IntLit(_, _)
        | TypedPattern::StrLit(_, _)
        | TypedPattern::BoolLit(_, _)
        | TypedPattern::DurationLit(_, _) => {}
    }
}

fn unresolved_repl_binding_issue(typed: &[TypedNode]) -> Option<(Span, Vec<String>)> {
    fn binding_rhs_allows_unresolved_persistence(rhs: &TypedNode) -> bool {
        matches!(
            rhs.node,
            TypedInner::FacetPath(_) | TypedInner::PendingFacetPath(_)
        )
    }

    fn visit_stmt(stmt: &TypedNode) -> Option<(Span, Vec<String>)> {
        match &stmt.node {
            TypedInner::Bind(pat, rhs) | TypedInner::SafeBind(pat, rhs, _, _) => {
                if binding_rhs_allows_unresolved_persistence(rhs) {
                    return None;
                }
                let mut names = Vec::new();
                collect_unresolved_pattern_binding_names(pat, &mut names);
                (!names.is_empty()).then(|| (stmt.span.clone(), names))
            }
            TypedInner::Semi(inner) => visit_stmt(inner),
            _ => None,
        }
    }

    typed.iter().find_map(visit_stmt)
}

fn apply_preload_visible_names(user_ast: &[Ast], mut visible: Vec<String>) -> Vec<String> {
    for stmt in user_ast {
        match stmt {
            Ast::Def(_, name, ..)
            | Ast::ExtractorDef(_, name, ..)
            | Ast::ConstDef(_, name, ..)
            | Ast::StructDef(_, name, ..)
            | Ast::RecordDef(_, name, ..)
            | Ast::DeferrorDef(_, name, ..)
            | Ast::EnumDef(_, name, ..)
            | Ast::TraitDef(_, name, ..) => visible.push(name.clone()),
            _ => {}
        }
    }

    visible
}

impl ReplEngine {
    fn sync_scar_fun_index_with_vm(&mut self) {
        let mut function_indices = HashMap::new();
        for entry in &self.vm.bytecode().functions {
            let Some(qualified_name) = entry.qualified_name.as_deref() else {
                continue;
            };
            function_indices.insert(qualified_name.to_string(), entry.fun_idx);
            if let Some(short_name) = qualified_name.strip_prefix("__Repl::Session::") {
                function_indices.insert(short_name.to_string(), entry.fun_idx);
            }
        }
        let next_fun_idx = self
            .vm
            .bytecode()
            .functions
            .iter()
            .map(|entry| entry.fun_idx + 1)
            .max()
            .unwrap_or(0);
        self.scar_session.ensure_next_fun_idx_at_least(next_fun_idx);
        self.scar_session.reconcile_function_indices(
            function_indices
                .iter()
                .map(|(qualified_name, fun_idx)| (qualified_name.as_str(), *fun_idx)),
        );
    }

    fn sync_repl_chunk_function_indices(
        &mut self,
        function_names: &[String],
        functions: &[sindr::ir::FunctionEntry],
    ) {
        let visible_function_indices = function_names
            .iter()
            .filter_map(|name| {
                let uid = self.sigil_session.lookup_uid(name)?;
                let fun_idx = functions
                    .iter()
                    .rev()
                    .find(|entry| {
                        entry
                            .qualified_name
                            .as_deref()
                            .is_some_and(|qualified_name| {
                                self.sigil_session.lookup_uid(qualified_name) == Some(uid)
                                    || (Self::symbol_matches(qualified_name, name)
                                        && entry.signature.as_deref().is_some_and(|signature| {
                                            signature.starts_with(&format!("{name}("))
                                        }))
                            })
                    })
                    .map(|entry| entry.fun_idx)?;
                Some((uid, fun_idx))
            })
            .collect::<Vec<_>>();
        self.scar_session
            .reconcile_visible_function_indices(visible_function_indices);
    }
}

pub(crate) fn parse_module_stages_from_sources(
    sources: &SourceRegistry,
    module_stages: &[Vec<StagedModule>],
    compile_unit_kind: CompileUnitKind,
) -> Result<Vec<Vec<sigil::StagedModuleAst>>, ModuleStageParseError> {
    let mut staged_module_asts = Vec::with_capacity(module_stages.len());
    let mut seen_module_paths: HashMap<String, SeenModulePath> = HashMap::new();

    for stage in module_stages {
        let mut stage_ast = Vec::new();
        let parsed_stage = parse_stage_modules_parallel(sources, stage, compile_unit_kind);
        for (source_index, (module, lowered_modules)) in stage.iter().zip(parsed_stage).enumerate()
        {
            for lowered in lowered_modules? {
                if !lowered.module_path.is_empty() && lowered.owner.is_none() {
                    let is_impl_owner = crate::lowered_module_is_impl_owner(&lowered);
                    let second_file_name = sources
                        .file_name(module.source_id)
                        .unwrap_or("<unknown>")
                        .to_string();
                    if let Some(seen) = seen_module_paths.get(&lowered.module_path) {
                        if !is_impl_owner && seen.has_normal_module() {
                            return Err(ModuleStageParseError {
                                source_id: module.source_id,
                                kind: ModuleStageParseErrorKind::DuplicateModulePath {
                                    module_path: lowered.module_path.clone(),
                                    first_file_name: seen
                                        .first_normal_file_name()
                                        .unwrap_or_else(|| seen.first_file_name())
                                        .to_string(),
                                    second_file_name,
                                    span: lowered
                                        .declared_span
                                        .unwrap_or(spire::ast::Span { start: 0, end: 0 }),
                                },
                            });
                        }
                    }
                    seen_module_paths
                        .entry(lowered.module_path.clone())
                        .and_modify(|seen| seen.record(second_file_name.clone(), is_impl_owner))
                        .or_insert_with(|| SeenModulePath::new(second_file_name, is_impl_owner));
                }

                let owner = lowered.owner.map(|mut owner| {
                    let base = crate::module_span_base_for_source(module.source_id);
                    owner.span.start = owner.span.start.saturating_add(base);
                    owner.span.end = owner.span.end.saturating_add(base);
                    owner
                });
                stage_ast.push(sigil::StagedModuleAst {
                    source_index,
                    module_path: lowered.module_path,
                    doc_module_path: lowered.doc_module_path,
                    ast: crate::rebase_module_ast_spans(lowered.ast, module.source_id),
                    owner,
                    module_doc: lowered.module_doc,
                    auto_import: lowered.auto_import,
                    process_spec: lowered.process_spec,
                });
            }
        }
        staged_module_asts.push(stage_ast);
    }

    Ok(staged_module_asts)
}

#[derive(Debug, Clone)]
struct SeenModulePath {
    first_file_name: String,
    first_normal_file_name: Option<String>,
}

impl SeenModulePath {
    fn new(file_name: String, is_impl_owner: bool) -> Self {
        Self {
            first_normal_file_name: (!is_impl_owner).then(|| file_name.clone()),
            first_file_name: file_name,
        }
    }

    fn record(&mut self, file_name: String, is_impl_owner: bool) {
        if !is_impl_owner && self.first_normal_file_name.is_none() {
            self.first_normal_file_name = Some(file_name);
        }
    }

    fn has_normal_module(&self) -> bool {
        self.first_normal_file_name.is_some()
    }

    fn first_file_name(&self) -> &str {
        &self.first_file_name
    }

    fn first_normal_file_name(&self) -> Option<&str> {
        self.first_normal_file_name.as_deref()
    }
}

type StageParseResult = Result<Vec<crate::LoweredModuleAst>, ModuleStageParseError>;

fn parse_stage_modules_parallel(
    sources: &SourceRegistry,
    stage: &[StagedModule],
    compile_unit_kind: CompileUnitKind,
) -> Vec<StageParseResult> {
    std::thread::scope(|scope| {
        let mut handles = Vec::with_capacity(stage.len());
        for module in stage {
            handles.push((
                module,
                std::thread::Builder::new()
                    .stack_size(STAGE_PARSE_WORKER_STACK_SIZE)
                    .spawn_scoped(scope, move || {
                        let module_source = sources.source(module.source_id).unwrap_or("");
                        let parsed = crate::parse_file_source(
                            module_source,
                            crate::derive_parser_context(
                                module.source_id.0,
                                module.source_kind,
                                compile_unit_kind,
                                module
                                    .module_path
                                    .as_deref()
                                    .filter(|path| *path == "Facet")
                                    .map(str::to_owned),
                            ),
                            sources
                                .file_name(module.source_id)
                                .expect("registered module source"),
                        )
                        .map_err(|error| ModuleStageParseError {
                            source_id: module.source_id,
                            kind: ModuleStageParseErrorKind::Parse { error },
                        })?;
                        let fallback_module_path = sigil::const_only_fallback_module_path(
                            &parsed,
                            module.module_path.as_deref(),
                        );
                        Ok(crate::lower_module_source_ast(parsed, fallback_module_path))
                    }),
            ));
        }

        handles
            .into_iter()
            .map(|(module, worker)| finish_stage_parse_worker(module, worker))
            .collect()
    })
}

fn finish_stage_parse_worker(
    module: &StagedModule,
    worker: std::io::Result<std::thread::ScopedJoinHandle<'_, StageParseResult>>,
) -> StageParseResult {
    let worker = worker.map_err(|error| ModuleStageParseError {
        source_id: module.source_id,
        kind: ModuleStageParseErrorKind::WorkerSpawnFailure {
            module_path: module.module_path.clone(),
            message: error.to_string(),
        },
    })?;
    match worker.join() {
        Ok(result) => result,
        Err(payload) => panic::resume_unwind(payload),
    }
}

pub(crate) fn xldr_version() -> &'static str {
    XLDR_VERSION
}

fn clamp_to_char_boundary(input: &str, mut cursor: usize) -> usize {
    cursor = cursor.min(input.len());
    while cursor > 0 && !input.is_char_boundary(cursor) {
        cursor -= 1;
    }
    cursor
}

pub(crate) fn completion_token(input: &str, cursor: usize) -> (usize, usize, String) {
    let cursor = clamp_to_char_boundary(input, cursor);
    let before = &input[..cursor];
    let start = before
        .char_indices()
        .rev()
        .find_map(|(idx, ch)| (!completion_token_char(ch)).then_some(idx + ch.len_utf8()))
        .unwrap_or(0);
    (start, cursor, input[start..cursor].to_string())
}

fn completion_token_char(ch: char) -> bool {
    ch.is_ascii_alphanumeric() || matches!(ch, '_' | ':' | '?')
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CompletionLexState {
    Code,
    String { escaped: bool },
    Interpolation { brace_depth: usize },
    InterpolationString { brace_depth: usize, escaped: bool },
}

pub(crate) fn completion_allowed_at_cursor(input: &str, cursor: usize) -> bool {
    let cursor = clamp_to_char_boundary(input, cursor.min(input.len()));
    let before = &input[..cursor];
    let mut state = CompletionLexState::Code;
    let mut chars = before.char_indices().peekable();

    while let Some((_idx, ch)) = chars.next() {
        state = match state {
            CompletionLexState::Code => match ch {
                '"' => CompletionLexState::String { escaped: false },
                _ => CompletionLexState::Code,
            },
            CompletionLexState::String { escaped } => {
                if escaped {
                    CompletionLexState::String { escaped: false }
                } else if ch == '\\' {
                    CompletionLexState::String { escaped: true }
                } else if ch == '"' {
                    CompletionLexState::Code
                } else if ch == '#' && chars.peek().is_some_and(|(_, next)| *next == '{') {
                    chars.next();
                    CompletionLexState::Interpolation { brace_depth: 1 }
                } else {
                    CompletionLexState::String { escaped: false }
                }
            }
            CompletionLexState::Interpolation { brace_depth } => match ch {
                '"' => CompletionLexState::InterpolationString {
                    brace_depth,
                    escaped: false,
                },
                '{' => CompletionLexState::Interpolation {
                    brace_depth: brace_depth + 1,
                },
                '}' if brace_depth <= 1 => CompletionLexState::String { escaped: false },
                '}' => CompletionLexState::Interpolation {
                    brace_depth: brace_depth - 1,
                },
                _ => CompletionLexState::Interpolation { brace_depth },
            },
            CompletionLexState::InterpolationString {
                brace_depth,
                escaped,
            } => {
                if escaped {
                    CompletionLexState::InterpolationString {
                        brace_depth,
                        escaped: false,
                    }
                } else if ch == '\\' {
                    CompletionLexState::InterpolationString {
                        brace_depth,
                        escaped: true,
                    }
                } else if ch == '"' {
                    CompletionLexState::Interpolation { brace_depth }
                } else {
                    CompletionLexState::InterpolationString {
                        brace_depth,
                        escaped: false,
                    }
                }
            }
        };
    }

    matches!(
        state,
        CompletionLexState::Code | CompletionLexState::Interpolation { .. }
    )
}

#[cfg(test)]
mod tests {
    #[test]
    fn stage_parser_spawn_failure_retains_module_source_and_diagnostic() {
        let mut sources = SourceRegistry::new();
        sources.register("other.srt", "");
        let source_id = sources.register("failed.srt", "defmod Failed {}");
        let module = StagedModule {
            source_id,
            module_path: Some("Failed".into()),
            source_kind: SourceKind::DefinitionSource,
        };
        let error = finish_stage_parse_worker(
            &module,
            Err(std::io::Error::new(
                std::io::ErrorKind::WouldBlock,
                "injected worker shortage",
            )),
        )
        .expect_err("worker creation failure must be a parse phase error");
        assert_eq!(error.source_id, source_id);
        assert_eq!(error.span(), Span { start: 0, end: 0 });
        assert!(error.message().contains("Failed"));
        assert!(error.message().contains("injected worker shortage"));
        let spec = error.diagnostic_spec(&sources);
        let diagnostic =
            diagnostics::serializable_diagnostic_by_id(&sources, source_id, "parse", &spec);
        assert_eq!(diagnostic.kind, "ParseError");
        assert_eq!(diagnostic.phase, "parse");
        assert_eq!(diagnostic.reason.as_deref(), Some("WorkerSpawnFailure"));
        assert_eq!(diagnostic.span, [0, 0]);
        assert_eq!(
            spec.structured.as_ref().unwrap().primary.source_id,
            source_id
        );
        assert_eq!(sources.file_name(source_id), Some("failed.srt"));
        let rendered = diagnostics::render_error_by_id(&sources, source_id, &spec);
        assert!(rendered.contains("failed.srt"), "{rendered}");
        assert!(rendered.contains("injected worker shortage"), "{rendered}");
    }

    #[test]
    fn stage_parser_worker_panic_keeps_its_payload() {
        let module = StagedModule {
            source_id: SourceId(0),
            module_path: Some("Broken".into()),
            source_kind: SourceKind::DefinitionSource,
        };
        let failure = std::panic::catch_unwind(|| {
            std::thread::scope(|scope| {
                finish_stage_parse_worker(
                    &module,
                    std::thread::Builder::new()
                        .spawn_scoped(scope, || std::panic::panic_any(73_u32)),
                )
            })
        })
        .expect_err("worker panic must unwind");
        assert_eq!(failure.downcast_ref::<u32>(), Some(&73));
    }

    #[test]
    fn boolean_function_suffix_completion_token_keeps_the_full_name() {
        let source = ":sig Predicates::positive?";
        assert_eq!(
            completion_token(source, source.len()),
            (5, source.len(), "Predicates::positive?".into())
        );
    }

    #[test]
    fn final_err_display_rejects_missing_and_extra_payload() {
        let engine = ReplEngine::new().expect("REPL engine should initialize");
        for field_count in [0, 2] {
            let value = Value::Tagged {
                tag: 1,
                fields: vec![Value::Unit; field_count],
            };
            let error = engine
                .report_main_result_error_if_any(&value)
                .expect_err("malformed Err must be a RuntimeError");
            assert!(
                error.message.contains("invalid runtime payload for tag 1"),
                "{error:?}"
            );
            assert!(
                error
                    .message
                    .contains(&format!("expected 1 fields, got {field_count}")),
                "{error:?}"
            );
        }
    }

    #[test]
    fn repl_source_spans_reject_overlapping_and_unrepresentable_offsets() {
        use diagnostics::SourceId;
        assert!(super::repl_source_span_fits(SourceId(0), 999_999));
        assert!(!super::repl_source_span_fits(SourceId(0), 1_000_000));
        assert!(super::repl_source_span_fits(SourceId(4293), 967_295));
        assert!(!super::repl_source_span_fits(SourceId(4293), 967_296));
        assert!(!super::repl_source_span_fits(SourceId(4294), 1));
    }

    use super::*;
    use eldr::interactive::InteractiveChunkPolicy;
    use eldr::value::CallableTarget;
    use sindr::ir::{
        BootEntrySource, BytecodeChunk, Constant, Opcode, RuntimeBootPlan, SingletonBootEntry,
    };
    use sindr::runtime::{TypeEntry, TypeKind};
    #[cfg(unix)]
    use std::io::{Read, Write};
    #[cfg(unix)]
    use std::os::fd::FromRawFd;
    #[cfg(unix)]
    use std::sync::Mutex;

    #[cfg(unix)]
    static STDERR_CAPTURE_LOCK: Mutex<()> = Mutex::new(());

    #[cfg(unix)]
    extern "C" {
        fn close(fd: i32) -> i32;
        fn dup(fd: i32) -> i32;
        fn dup2(src: i32, dst: i32) -> i32;
        fn pipe(fds: *mut i32) -> i32;
    }

    fn strip_ansi(input: &str) -> String {
        let mut out = String::new();
        let mut chars = input.chars().peekable();
        while let Some(ch) = chars.next() {
            if ch == '\u{1b}' && matches!(chars.peek(), Some('[')) {
                chars.next();
                for next in chars.by_ref() {
                    if ('@'..='~').contains(&next) {
                        break;
                    }
                }
                continue;
            }
            out.push(ch);
        }
        out
    }

    #[cfg(unix)]
    fn capture_process_stderr<T>(f: impl FnOnce() -> T) -> (T, String) {
        let _guard = STDERR_CAPTURE_LOCK.lock().expect("stderr capture lock");
        let mut pipe_fds = [0_i32; 2];
        unsafe {
            assert_eq!(pipe(pipe_fds.as_mut_ptr()), 0, "pipe should succeed");
            let saved_stderr = dup(2);
            assert!(saved_stderr >= 0, "dup stderr should succeed");
            assert_eq!(dup2(pipe_fds[1], 2), 2, "redirect stderr should succeed");
            assert_eq!(close(pipe_fds[1]), 0, "close write pipe should succeed");

            let result = f();
            std::io::stderr().flush().expect("flush stderr");

            assert_eq!(dup2(saved_stderr, 2), 2, "restore stderr should succeed");
            assert_eq!(close(saved_stderr), 0, "close saved stderr should succeed");

            let mut stderr = String::new();
            let mut reader = std::fs::File::from_raw_fd(pipe_fds[0]);
            reader
                .read_to_string(&mut stderr)
                .expect("read captured stderr");
            (result, stderr)
        }
    }

    fn interactive_test_chunk() -> BytecodeChunk {
        BytecodeChunk {
            opcodes: vec![Opcode::LoadConst(0), Opcode::Halt],
            source_map: None,
            const_base: 0,
            constants: vec![Constant::Int(sindr::primitives::int(1))],
            new_locals: 0,
            type_registry_base: 0,
            type_entries: Vec::new(),
            error_template_base: 0,
            error_templates: Vec::new(),
            dbg_template_base: 0,
            dbg_templates: Vec::new(),
            callable_templates: Vec::new(),
            functions: Vec::new(),
            docs: Vec::new(),
            signatures: Vec::new(),
            runtime_process_specs: Vec::new(),
            runtime_boot_plan: Default::default(),
        }
    }

    fn expect_module_preload_failure(
        source: &str,
        phase: &str,
        message_fragment: &str,
    ) -> ReplLoadError {
        let err = match ReplEngine::from_module_source("lib/bad.srt", source) {
            Ok(_) => panic!("module preload should fail"),
            Err(error) => error,
        };
        match &err {
            ReplLoadError::Diagnostic {
                phase: actual_phase,
                sources,
                source_id,
                spec,
            } => {
                assert_eq!(actual_phase, phase);
                assert_eq!(sources.file_name(*source_id), Some("lib/bad.srt"));
                assert!(
                    spec.message.contains(message_fragment),
                    "expected `{}` to contain `{}`",
                    spec.message,
                    message_fragment
                );
            }
            other => panic!("expected module preload diagnostic, got {other:?}"),
        }
        err
    }

    #[test]
    fn module_preload_returns_parse_failure() {
        expect_module_preload_failure("defmod Broken { def nope( }", "parse", "Expected");
    }

    #[test]
    fn repl_engine_new_builds_default_bootstrap_state_at_most_once() {
        let before = DEFAULT_REPL_BOOTSTRAP_BUILDS.load(Ordering::Relaxed);

        let _first = ReplEngine::new().expect("first engine should initialize");
        let _second = ReplEngine::new().expect("second engine should initialize");

        let builds = DEFAULT_REPL_BOOTSTRAP_BUILDS
            .load(Ordering::Relaxed)
            .saturating_sub(before);
        assert!(
            builds <= 1,
            "default REPL bootstrap state was rebuilt {builds} times"
        );
    }

    #[test]
    fn first_repl_engine_executes_runtime_boot_once() {
        TEST_REPL_RUNTIME_BOOT_CALLS.with(|calls| calls.set(0));

        let _engine = ReplEngine::new().expect("engine should initialize");

        let calls = TEST_REPL_RUNTIME_BOOT_CALLS.with(Cell::get);
        assert_eq!(calls, 1, "runtime boot should run only for the owned VM");
    }

    #[test]
    fn repl_engine_new_keeps_cloned_session_state_isolated() {
        let mut first = ReplEngine::new().expect("first engine should initialize");
        let mut second = ReplEngine::new().expect("second engine should initialize");

        let first_binding = first.handle_line("isolated_value = 1");
        let second_binding = second.handle_line("isolated_value = \"second\"");
        let first_value = first.handle_line("isolated_value");
        let second_value = second.handle_line("isolated_value");

        assert!(matches!(
            first_binding.output,
            ReplOutput::EvalSuccess { .. }
        ));
        assert!(matches!(
            second_binding.output,
            ReplOutput::EvalSuccess { .. }
        ));
        let first_rendered = ReplEngine::repl_result_text(&first_value);
        let second_rendered = ReplEngine::repl_result_text(&second_value);
        assert!(first_rendered.contains("1"), "{first_rendered}");
        assert!(second_rendered.contains("second"), "{second_rendered}");
        assert!(!first_rendered.contains("second"), "{first_rendered}");
    }

    #[test]
    fn deferred_bootstrap_instantiation_boots_each_owned_runtime_once() {
        TEST_REPL_RUNTIME_BOOT_CALLS.with(|calls| calls.set(0));
        let preloaded = compile_preloaded_repl_chunk_with_runtime(
            Some((
                "process_bootstrap.srt",
                r#"
defgenserver BootstrapProbe {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(7) }

  @call
  def read(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}

supervisor_init {
  BootstrapProbe {}
}
"#,
            )),
            None,
            PreloadRuntimeExecution::Defer,
        )
        .expect("process preload should compile without booting");
        assert_eq!(
            TEST_REPL_RUNTIME_BOOT_CALLS.with(Cell::get),
            0,
            "shared bootstrap construction must not boot a transient VM"
        );
        let state = DefaultReplBootstrapState::from_preloaded(preloaded);
        assert!(
            !state.bytecode.runtime_boot_plan.singletons.is_empty(),
            "boot plan: {:?}; specs: {:?}",
            state.bytecode.runtime_boot_plan,
            state.bytecode.runtime_process_specs
        );

        let first = state
            .instantiate()
            .expect("first runtime should boot from shared bytecode");
        let second = state
            .instantiate()
            .expect("second runtime should boot from shared bytecode");
        assert_eq!(
            TEST_REPL_RUNTIME_BOOT_CALLS.with(Cell::get),
            2,
            "each owned VM should boot exactly once"
        );

        let first_runtime = first.vm.as_vm().process_runtime_snapshot().unwrap();
        let second_runtime = second.vm.as_vm().process_runtime_snapshot().unwrap();
        assert!(
            first_runtime
                .singleton_slots
                .keys()
                .any(|name| name.ends_with("BootstrapProbe")),
            "{:?}",
            first_runtime.singleton_slots
        );
        assert!(
            second_runtime
                .singleton_slots
                .keys()
                .any(|name| name.ends_with("BootstrapProbe")),
            "{:?}",
            second_runtime.singleton_slots
        );
    }

    #[test]
    fn eldr_scope_restore_rejects_modified_stdlib_bytecode_prefix() {
        let engine = ReplEngine::new().expect("engine should initialize");
        let mut bytecode = engine.vm.snapshot_bytecode();
        let default_function = bytecode
            .functions
            .first_mut()
            .expect("default bootstrap must contain a function");
        default_function.qualified_name = Some("StaleStdlib::modified".to_string());
        let bytes = bytecode.encode().expect("modified bytecode should encode");

        let error = match ReplEngine::from_eldr(&bytes) {
            Ok(_) => panic!("modified stdlib bytecode prefix must be rejected"),
            Err(error) => error,
        };

        let EldrLoadError::Load(LoadError::BootstrapFailed {
            phase,
            file_name,
            message,
        }) = error
        else {
            panic!("expected stdlib compatibility failure");
        };
        assert_eq!(phase, "load");
        assert_eq!(file_name, "<stdlib>");
        assert!(message.contains("bytecode prefix mismatch"), "{message}");
    }

    #[test]
    fn repl_help_lists_q_quit_alias() {
        let mut engine = ReplEngine::new().expect("engine should initialize");

        let help = engine.handle_line(":help");
        let rendered = ReplEngine::repl_result_text(&help);

        assert!(rendered.contains(":quit, :exit, :q"), "{rendered}");
    }

    #[test]
    #[cfg(unix)]
    fn handle_line_type_error_returns_diagnostic_without_writing_process_stderr() {
        let mut engine = ReplEngine::new().expect("engine should initialize");

        let (result, stderr) = capture_process_stderr(|| engine.handle_line("bad: Int = \"oops\""));
        let rendered = ReplEngine::repl_result_text(&result);

        assert!(
            stderr.is_empty(),
            "REPL core wrote directly to process stderr:\n{stderr}"
        );
        assert!(matches!(result.output, ReplOutput::EvalError { .. }));
        assert!(rendered.contains("expected Int"), "{rendered}");
    }

    #[test]
    fn module_preload_returns_resolve_failure() {
        expect_module_preload_failure(
            "defmod Broken { def nope() -> Int { missing } }",
            "resolve",
            "Undefined variable",
        );
    }

    #[test]
    fn module_preload_returns_typecheck_failure() {
        expect_module_preload_failure(
            "defmod Broken { def nope() -> Int { \"bad\" } }",
            "typecheck",
            "expected Int",
        );
    }

    #[test]
    fn partial_capture_chain_keeps_outer_capture_arity_in_vm() {
        let mut engine = ReplEngine::new().expect("engine should initialize");

        let def = engine.handle_line("def f(a: Int, b: Int, c: Int) -> Int { a + b + c }");
        assert!(!def.should_exit);
        let f3 = engine.handle_line("f3 = &f");
        assert!(!f3.should_exit);
        let f2 = engine.handle_line("f2 = &f3(&1, &2, 3)");
        assert!(!f2.should_exit);
        let f1 = engine.handle_line("f1 = &f2(&1, 2)");
        assert!(!f1.should_exit);

        let bytecode = engine.vm.snapshot_bytecode();
        let f_entry = bytecode
            .functions
            .iter()
            .find(|entry| entry.signature.as_deref() == Some("f(a: Int, b: Int, c: Int) -> Int"))
            .expect("repl def f should be present in bytecode");
        assert_eq!(f_entry.arity, 3, "{f_entry:?}");

        let binding = engine.binding_info("f2").expect("f2 binding should exist");
        let value = engine
            .vm
            .get_local(binding.slot_id)
            .expect("f2 value should be stored");
        let Value::Callable(callable) = value else {
            panic!("expected callable binding, got {value:?}");
        };
        assert_eq!(callable.lexical_captures.len(), 1, "{callable:?}");

        let CallableTarget::Function(fun_idx) = callable.target else {
            panic!(
                "expected function callable target, got {:?}",
                callable.target
            );
        };
        let entry = bytecode
            .functions
            .get(fun_idx as usize)
            .expect("callable target function should exist");
        assert_eq!(entry.fun_idx, fun_idx, "{entry:?}");
        assert_eq!(entry.arity, 3, "{entry:?}");
        let Some(Value::Callable(inner)) = callable.lexical_captures.first() else {
            panic!(
                "expected f2 to capture f3 callable, got {:?}",
                callable.lexical_captures
            );
        };
        let CallableTarget::Function(fun_idx) = inner.target.clone() else {
            panic!(
                "expected captured f3 function target, got {:?}",
                inner.target
            );
        };
        let entry = bytecode
            .functions
            .get(fun_idx as usize)
            .expect("captured f3 function should exist");
        assert_eq!(
            fun_idx, f_entry.fun_idx,
            "captured f3 should target repl f: {f_entry:?}"
        );
        assert_eq!(entry.fun_idx, fun_idx, "{entry:?}");
        assert_eq!(entry.arity, 3, "{entry:?}");

        let binding = engine.binding_info("f1").expect("f1 binding should exist");
        let value = engine
            .vm
            .get_local(binding.slot_id)
            .expect("f1 value should be stored");
        let Value::Callable(callable) = value else {
            panic!("expected callable binding, got {value:?}");
        };
        assert_eq!(callable.lexical_captures.len(), 1, "{callable:?}");
        let Some(Value::Callable(inner)) = callable.lexical_captures.first() else {
            panic!(
                "expected f1 to capture f2 callable, got {:?}",
                callable.lexical_captures
            );
        };
        let CallableTarget::Function(fun_idx) = inner.target.clone() else {
            panic!(
                "expected captured f2 function target, got {:?}",
                inner.target
            );
        };
        let entry = bytecode
            .functions
            .get(fun_idx as usize)
            .expect("captured f2 function should exist");
        assert_eq!(entry.fun_idx, fun_idx, "{entry:?}");
        assert_eq!(entry.arity, 3, "{entry:?}");
        let Some(Value::Callable(inner_f3)) = inner.lexical_captures.first() else {
            panic!(
                "expected captured f2 to retain f3 callable, got {:?}",
                inner.lexical_captures
            );
        };
        let CallableTarget::Function(fun_idx) = inner_f3.target.clone() else {
            panic!(
                "expected retained f3 function target, got {:?}",
                inner_f3.target
            );
        };
        let entry = bytecode
            .functions
            .get(fun_idx as usize)
            .expect("retained f3 function should exist");
        assert_eq!(entry.fun_idx, fun_idx, "{entry:?}");
        assert_eq!(entry.arity, 3, "{entry:?}");

        let applied = engine.handle_line("f1(10)");
        let applied_text = ReplEngine::repl_result_text(&applied);
        assert!(applied_text.contains("15"), "{applied_text}");
    }

    #[test]
    fn completion_context_is_memoized_until_repl_state_changes() {
        let mut engine = ReplEngine::new().expect("engine should initialize");

        let baseline = engine.completion_context_build_count();
        let first = engine.completion_context();
        let second = engine.completion_context();

        assert_eq!(first, second);
        assert_eq!(engine.completion_context_build_count(), baseline + 1);

        let bind = engine.handle_line("value = 1");
        assert!(!bind.should_exit, "{}", ReplEngine::repl_result_text(&bind));

        let after_mutation = engine
            .cached_completion_context()
            .expect("completion cache should stay available after commit");
        assert!(
            after_mutation
                .completions("value(", "value(".len())
                .signature
                .is_none(),
            "plain value bindings should not become callable signatures"
        );
        assert_eq!(engine.completion_context_build_count(), baseline + 1);

        let after_cached_reuse = engine.completion_context();
        assert_eq!(after_mutation, after_cached_reuse);
        assert_eq!(engine.completion_context_build_count(), baseline + 1);
    }

    #[test]
    fn cached_completion_context_keeps_new_binding_after_commit() {
        let mut engine = ReplEngine::new().expect("engine should initialize");
        let _ = engine.completion_context();

        let bind = engine.handle_line("value = 1");
        assert!(!bind.should_exit, "{}", ReplEngine::repl_result_text(&bind));

        let cached = engine
            .cached_completion_context()
            .expect("completion cache should remain available after commit");
        let labels = cached
            .completions("val", 3)
            .candidates
            .into_iter()
            .map(|candidate| candidate.label)
            .collect::<Vec<_>>();
        assert!(
            labels.iter().any(|label| label == "value"),
            "cached completion context should include new binding: {labels:?}"
        );
    }

    #[test]
    fn core_completion_uses_live_imported_short_names_from_session_scope() {
        let mut engine = ReplEngine::from_module_source(
            "helper.srt",
            r#"defmod Helper {
  def helper() -> Int { 1 }
}"#,
        )
        .expect("module source should initialize");

        let imported = engine.handle_line("import Helper::helper");
        assert!(
            !imported.should_exit,
            "{}",
            ReplEngine::repl_result_text(&imported)
        );

        let semantic_labels = engine
            .semantic_index()
            .symbols()
            .iter()
            .map(|symbol| symbol.label.clone())
            .collect::<Vec<_>>();
        assert!(
            semantic_labels.iter().any(|label| label == "helper"),
            "semantic index should include imported short symbol: {semantic_labels:?}"
        );

        let completion_labels = engine
            .completions("hel", 3)
            .candidates
            .into_iter()
            .map(|candidate| candidate.label)
            .collect::<Vec<_>>();
        assert!(
            completion_labels.iter().any(|label| label == "helper"),
            "completion should expose imported short symbol: {completion_labels:?}"
        );

        let signature_lines = engine
            .completion_context()
            .completions("helper(", "helper(".len())
            .signature
            .map(|signature| signature.lines)
            .unwrap_or_default();
        assert!(
            signature_lines
                .iter()
                .any(|line| line.contains("helper() -> Int")),
            "signature help should resolve imported short callable: {signature_lines:?}"
        );
    }

    #[test]
    fn preloaded_owner_registry_rejects_later_repl_owner_collision() {
        let mut engine = ReplEngine::from_module_source(
            "preloaded_owner.srt",
            "defrecord PreloadedOwner(value: Int)",
        )
        .expect("preloaded owner should initialize");

        let err = engine
            .sigil_session
            .resolve(
                spire::parse("type PreloadedOwner = (Int -> Int)")
                    .expect("later owner chunk should parse"),
            )
            .expect_err("later owner chunk must collide with the preloaded owner");

        assert_eq!(err.message, "Duplicate top-level owner: PreloadedOwner");
        assert_eq!(err.related_labels[0].message, "first Record declaration");
    }

    #[test]
    fn prior_repl_chunk_owner_collision_renders_the_first_chunk_source() {
        let mut engine = ReplEngine::new().expect("REPL engine should initialize");
        let first_source = "defrecord SessionOwner(first_value: Int)";
        let first_source_id = engine.sources.register("REPL:1", first_source);
        engine
            .sigil_session
            .resolve(crate::rebase_module_ast_spans(
                spire::parse(first_source).expect("first owner chunk should parse"),
                first_source_id,
            ))
            .expect("first owner declaration should resolve");

        let later_source = "defstruct SessionOwner { later_value: String }";
        let later_source_id = engine.sources.register("REPL:2", later_source);
        let err = engine
            .sigil_session
            .resolve(crate::rebase_module_ast_spans(
                spire::parse(later_source).expect("later owner chunk should parse"),
                later_source_id,
            ))
            .expect_err("later owner declaration must collide");
        let (source_id, spec) = engine.resolve_diagnostic_for_repl(&err, later_source_id);
        let rendered = strip_ansi(&error_display::diagnostic_text_by_id(
            &engine.sources,
            source_id,
            &spec,
        ));

        assert!(
            rendered.contains("Duplicate top-level owner: SessionOwner"),
            "{rendered}"
        );
        assert!(rendered.contains("first Record declaration"), "{rendered}");
        assert!(rendered.contains("first_value"), "{rendered}");
        assert!(rendered.contains("later_value"), "{rendered}");
    }

    #[test]
    fn preloaded_owner_collision_renders_the_preload_source() {
        let mut engine = ReplEngine::from_module_source(
            "preloaded_owner.srt",
            "defrecord PreloadedOwner(preloaded_value: Int)",
        )
        .expect("preloaded owner should initialize");

        let later_source = "defstruct PreloadedOwner { later_value: String }";
        let later_source_id = engine.sources.register("REPL:1", later_source);
        let err = engine
            .sigil_session
            .resolve(crate::rebase_module_ast_spans(
                spire::parse(later_source).expect("later owner chunk should parse"),
                later_source_id,
            ))
            .expect_err("later owner declaration must collide");
        let (source_id, spec) = engine.resolve_diagnostic_for_repl(&err, later_source_id);
        let rendered = strip_ansi(&error_display::diagnostic_text_by_id(
            &engine.sources,
            source_id,
            &spec,
        ));

        assert!(
            rendered.contains("Duplicate top-level owner: PreloadedOwner"),
            "{rendered}"
        );
        assert!(rendered.contains("first Record declaration"), "{rendered}");
        assert!(rendered.contains("preloaded_value"), "{rendered}");
        assert!(rendered.contains("later_value"), "{rendered}");
    }

    #[test]
    fn preloaded_script_owner_is_registered_once_and_persists() {
        let mut engine = ReplEngine::from_script_source(
            "preloaded_script_owner.srt",
            "defrecord ScriptOwner(value: Int)",
        )
        .expect("a script preload owner should initialize exactly once");
        assert_eq!(
            engine
                .sigil_session
                .owner_registry()
                .identity_for_owner("ScriptOwner"),
            Some(sindr::names::TypeIdentity::Record)
        );

        let err = engine
            .sigil_session
            .resolve(
                spire::parse("type ScriptOwner = (Int -> Int)")
                    .expect("later owner chunk should parse"),
            )
            .expect_err("later owner chunk must collide with the script preload owner");
        assert_eq!(err.message, "Duplicate top-level owner: ScriptOwner");
    }

    #[test]
    fn preload_duplicate_owner_uses_the_resolve_diagnostic_contract() {
        let err = match ReplEngine::from_module_source(
            "duplicate_owner.srt",
            "defrecord Hoge(value: Int)\ndefmod Hoge {}",
        ) {
            Ok(_) => panic!("duplicate preload owners must fail"),
            Err(err) => err,
        };
        let ReplLoadError::Diagnostic { spec, .. } = err else {
            panic!("duplicate owner should be a resolve diagnostic: {err:?}");
        };

        assert_eq!(spec.message, "Duplicate top-level owner: Hoge");
        assert!(spec
            .labels
            .iter()
            .any(|label| label.message == "first Record declaration"));
        assert!(spec
            .labels
            .iter()
            .any(|label| label.message == "conflicting Mod declaration"));
        let structured = spec
            .structured
            .as_ref()
            .expect("resolver diagnostics should carry producer-owned structured facts");
        assert_eq!(
            structured.reason,
            diagnostics::DiagnosticReason::Resolve(diagnostics::ResolveDiagnosticReason::Namespace)
        );
        assert_eq!(structured.origin, diagnostics::DiagnosticOrigin::Resolve);
        assert_eq!(
            structured.data,
            diagnostics::DiagnosticData::Resolve(diagnostics::ResolveDiagnosticData {
                detail: "Duplicate top-level owner: Hoge".into(),
                subject: Some("Hoge".into()),
                related_labels: vec![
                    "first Record declaration".into(),
                    "conflicting Mod declaration".into()
                ],
            })
        );
    }

    #[test]
    fn error_signature_exposes_payload_and_constructor_inputs_separately() {
        let mut engine = ReplEngine::from_module_source(
            "saved_value.srt",
            "deferror SavedValue(num: Int) { |value: Int| Self(message: \"saved\", num: value) }",
        )
        .expect("Error module should initialize");
        let signature = ReplEngine::repl_result_text(&engine.handle_line(":sig SavedValue"));
        assert!(
            signature.contains("SavedValue(value: Int) -> SavedValue"),
            "{signature}"
        );
    }

    #[test]
    fn trait_capture_docs_do_not_replace_missing_method_docs() {
        let mut engine = ReplEngine::from_script_source(
            "trait_capture_doc.srt",
            r#"
@doc """trait body sentinel"""
deftrait MissingCaptureDoc {
  def missing(self: Self, rhs: Self) -> Self
}
@doc """implementation body sentinel"""
impl MissingCaptureDoc for Int {
  @doc """implementation method sentinel"""
  def missing(self: Self, rhs: Self) -> Self { self + rhs }
}
deftrait AuthoredCaptureDoc {
  @doc """definition method sentinel"""
  def authored(self: Self, rhs: Self) -> Self
}
impl AuthoredCaptureDoc for Int {
  @doc """unrelated implementation sentinel"""
  def authored(self: Self, rhs: Self) -> Self { self + rhs }
}
"#,
        )
        .expect("Trait capture doc fixture should initialize");
        for source in [
            "missing_capture: (Int, Int -> Int) = &MissingCaptureDoc::missing",
            "missing_partial: (Int -> Int) = &missing_capture(1, &1)",
            "missing_recapture: (Int -> Int) = &missing_partial",
            "authored_capture: (Int, Int -> Int) = &AuthoredCaptureDoc::authored",
            "authored_partial: (Int -> Int) = &authored_capture(1, &1)",
            "authored_recapture: (Int -> Int) = &authored_partial",
        ] {
            let result = engine.handle_line(source);
            assert!(
                matches!(result.output, ReplOutput::EvalSuccess { .. }),
                "{source}: {}",
                ReplEngine::repl_result_text(&result)
            );
        }
        for name in ["missing_capture", "missing_partial", "missing_recapture"] {
            let doc = engine.handle_line(&format!(":doc {name}"));
            assert!(
                !matches!(doc.output, ReplOutput::DocResolved { .. }),
                "{}",
                ReplEngine::repl_result_text(&doc)
            );
        }
        for name in ["authored_capture", "authored_partial", "authored_recapture"] {
            let doc = ReplEngine::repl_result_text(&engine.handle_line(&format!(":doc {name}")));
            assert!(doc.contains("definition method sentinel"), "{doc}");
            assert!(!doc.contains("unrelated implementation sentinel"), "{doc}");
        }
    }

    #[test]
    fn generic_capture_docs_keep_declaration_identity_after_binding_shadow() {
        let mut engine = ReplEngine::from_script_source(
            "generic_capture_doc.srt",
            r#"@doc """original generic doc"""
def documented_echo(value: $A) -> $A { value }
"#,
        )
        .expect("generic capture fixture should initialize");
        for source in [
            "old_echo: (Int -> Int) = &documented_echo",
            "documented_echo = 1",
            r#"@doc """replacement generic doc""" def documented_echo(value: $A) -> $A { value }"#,
            "new_echo: (String -> String) = &documented_echo",
            "recaptured: (Int -> Int) = &old_echo",
        ] {
            let result = engine.handle_line(source);
            assert!(
                matches!(result.output, ReplOutput::EvalSuccess { .. }),
                "{}",
                ReplEngine::repl_result_text(&result)
            );
        }
        for name in ["old_echo", "recaptured"] {
            let doc = ReplEngine::repl_result_text(&engine.handle_line(&format!(":doc {name}")));
            assert!(doc.contains("original generic doc"), "{doc}");
            assert!(!doc.contains("replacement generic doc"), "{doc}");
        }
        let doc = ReplEngine::repl_result_text(&engine.handle_line(":doc new_echo"));
        assert!(doc.contains("replacement generic doc"), "{doc}");
        assert!(!doc.contains("original generic doc"), "{doc}");
    }

    #[test]
    fn owner_pattern_queries_use_payload_shapes_and_type_doc_guidance() {
        let mut engine = ReplEngine::from_module_source(
            "pattern_surfaces.srt",
            r#"
@doc """record-owner-doc"""
defrecord QueryRecord(value: Int)
@doc """error-owner-doc"""
deferror QueryError(payload: String) { |input: Int| Self(message: "query", payload: "payload") }
@doc """enum-owner-doc"""
defenum QueryEnum { Empty, Item(Int) }
"#,
        )
        .expect("pattern query fixture should initialize");
        for (owner, shape, doc) in [
            (
                "QueryRecord",
                "QueryRecord(value: Int) : QueryRecord",
                "record-owner-doc",
            ),
            (
                "QueryError",
                "QueryError(payload: String) : QueryError",
                "error-owner-doc",
            ),
            (
                "QueryEnum",
                "QueryEnum::Item(Int) : QueryEnum",
                "enum-owner-doc",
            ),
        ] {
            let pattern =
                ReplEngine::repl_result_text(&engine.handle_line(&format!(":sig {owner}!")));
            assert!(pattern.contains(shape), "{pattern}");
            let guidance =
                ReplEngine::repl_result_text(&engine.handle_line(&format!(":doc {owner}!")));
            assert!(guidance.contains(&format!(":doc {owner}")), "{guidance}");
            assert!(!guidance.contains(doc), "{guidance}");
            let type_doc =
                ReplEngine::repl_result_text(&engine.handle_line(&format!(":doc {owner}")));
            assert!(type_doc.contains(doc), "{type_doc}");
        }
        let constructor = ReplEngine::repl_result_text(&engine.handle_line(":sig QueryError"));
        assert!(
            constructor.contains("QueryError(input: Int) -> QueryError"),
            "{constructor}"
        );
        assert!(!constructor.contains("payload: String"), "{constructor}");
        let variant = ReplEngine::repl_result_text(&engine.handle_line(":sig QueryEnum::Item"));
        assert!(variant.contains("QueryEnum::Item"), "{variant}");
    }

    #[test]
    fn error_payload_can_use_an_enum_from_the_repl_prefix() {
        let mut engine = ReplEngine::from_module_source(
            "saved_option.srt",
            "deferror SavedOption(value: Option<Int>) { |input: Option<Int>| Self(message: \"option\", value: input) }",
        ).expect("Error module should initialize");
        let value = engine.handle_line(
            "match SavedOption(Option::Some(7)) { SavedOption(Option::Some(value)) => value, _ => 0 }",
        );
        assert_eq!(ReplEngine::repl_result_text(&value), "7");
    }

    #[test]
    fn source_reflections_are_documented_but_disabled_in_repl() {
        let mut engine = ReplEngine::new().expect("REPL should initialize");
        for input in ["__", ":sig __", ":info __", ":type __"] {
            assert!(!engine
                .completions(input, input.len())
                .candidates
                .iter()
                .any(|candidate| candidate.replacement.contains("__FILE__")
                    || candidate.replacement.contains("__DIR__")
                    || candidate.replacement.contains("__LINE__")
                    || candidate.replacement.contains("__ENV__")));
        }
        assert!(!matches!(
            engine.handle_line(":doc __ENV__").output,
            ReplOutput::DocResolved { .. }
        ));
        assert!(
            ReplEngine::repl_result_text(&engine.handle_line(":sig __ENV__"))
                .contains("No signature found")
        );
        assert!(matches!(
            engine.handle_line("__ENV__").output,
            ReplOutput::EvalError { .. }
        ));
        for value in sindr::reflection::Reflection::ALL {
            let doc = engine.handle_line(&format!(":doc {}", value.name()));
            assert!(
                matches!(doc.output, ReplOutput::DocResolved { .. }),
                "{}: {}",
                value.name(),
                ReplEngine::repl_result_text(&doc)
            );
            let signature = engine.handle_line(&format!(":sig {}", value.name()));
            assert!(ReplEngine::repl_result_text(&signature).contains(&value.signature()));
            for name in [
                value.name().to_string(),
                format!("Bootstrap::{}", value.name()),
                format!("Global::Bootstrap::{}", value.name()),
            ] {
                let info = engine.handle_line(&format!(":info {name}"));
                assert!(ReplEngine::repl_result_text(&info).contains("use :doc or :sig"));
            }
            let expression = engine.handle_line(value.name());
            assert!(
                matches!(expression.output, ReplOutput::EvalError { .. }),
                "{}",
                ReplEngine::repl_result_text(&expression)
            );
        }
    }

    #[test]
    fn source_reflections_in_preloaded_runtime_input_survive_replay() {
        let mut engine = ReplEngine::from_script_source(
            "/repo/origin.srt",
            "# header\nlocation = (__FILE__, __DIR__, __LINE__)",
        )
        .expect("preload should compile");
        assert_eq!(
            ReplEngine::repl_result_text(&engine.handle_line("location")),
            "(\"origin.srt\", \"/repo\", 2)"
        );
        let reload = engine.handle_line(":reload defs");
        assert!(
            !matches!(
                reload.output,
                ReplOutput::Diagnostic { .. } | ReplOutput::EvalError { .. }
            ),
            "{}",
            ReplEngine::repl_result_text(&reload)
        );
        assert_eq!(
            ReplEngine::repl_result_text(&engine.handle_line("location")),
            "(\"origin.srt\", \"/repo\", 2)"
        );
    }

    #[test]
    fn source_reflections_in_preloaded_function_use_definition_source() {
        let mut engine = ReplEngine::from_script_source(
            "/repo/origin.srt",
            "# header\ndef location() -> (String, String, Int) { (__FILE__, __DIR__, __LINE__) }",
        )
        .expect("preload should compile");
        assert_eq!(
            ReplEngine::repl_result_text(&engine.handle_line("location()")),
            "(\"origin.srt\", \"/repo\", 2)"
        );
    }

    #[test]
    fn bootstrap_special_form_signatures_remain_queryable() {
        let mut engine = ReplEngine::new().expect("REPL engine should initialize");

        for symbol in [
            "(,)", "dbg!", "=", "=?", "match", "cond", "import", "include",
        ] {
            let signature =
                ReplEngine::repl_result_text(&engine.handle_line(&format!(":sig {symbol}")));
            assert!(
                !signature.contains("No signature found"),
                ":sig {symbol} unexpectedly failed: {signature}"
            );
        }
    }

    #[test]
    fn repl_session_rejects_top_level_def_capturing_existing_value_binding() {
        let mut engine = ReplEngine::new().expect("engine should initialize");

        let bind = engine.handle_line("x = 1");
        assert!(!bind.should_exit);
        assert!(engine.sigil_session.lookup_uid("x").is_some());

        let ast = spire::parse("def f() -> Int { x }").expect("parse failed");
        let err = engine
            .sigil_session
            .resolve(ast)
            .expect_err("top-level capture must fail");
        assert!(
            err.message
                .contains("Top-level definition `f` cannot reference value binding `x`"),
            "{}",
            err.message
        );
    }

    #[test]
    fn repl_session_phase_maps_to_interactive_vm_policy() {
        assert_eq!(
            ReplSessionPhase::Preload.execution_policy(),
            InteractiveChunkPolicy::Preload
        );
        assert_eq!(
            ReplSessionPhase::Live.execution_policy(),
            InteractiveChunkPolicy::ReplAppendOnly
        );
    }

    #[test]
    fn preload_phase_allows_structural_vm_growth() {
        let mut engine = ReplEngine::new().expect("engine should initialize");
        let mut chunk = interactive_test_chunk();
        chunk.const_base = engine.vm.bytecode().constants.len() as u32;
        chunk.error_template_base = engine.vm.bytecode().error_templates.len() as u32;
        chunk.type_registry_base = engine.vm.bytecode().type_registry.entries().len() as u32;
        let next_tag = engine
            .vm
            .bytecode()
            .type_registry
            .entries()
            .iter()
            .map(|entry| entry.tag)
            .max()
            .unwrap_or(1)
            + 1;
        chunk.type_entries.push(TypeEntry {
            tag: next_tag,
            name: "Extra".into(),
            kind: TypeKind::Struct,
            field_names: Vec::new(),
            private_flags: Vec::new(),
        });

        let execution = engine
            .execute_vm_chunk(chunk, ReplSessionPhase::Preload)
            .expect("preload phase should allow structural chunk growth");

        assert_eq!(execution.value, Value::Int(sindr::primitives::int(1)));
    }

    #[test]
    fn live_phase_rejects_runtime_boot_plan_growth() {
        let mut engine = ReplEngine::new().expect("engine should initialize");
        let mut chunk = interactive_test_chunk();
        chunk.runtime_boot_plan = RuntimeBootPlan {
            singletons: vec![SingletonBootEntry {
                process_name: "Counter".into(),
                init_timeout_ms: 5000,
                source: BootEntrySource::ExplicitConfig,
            }],
            ..RuntimeBootPlan::default()
        };

        let err = engine
            .execute_vm_chunk(chunk, ReplSessionPhase::Live)
            .expect_err("live phase should reject runtime boot plan growth");

        assert!(err.message.contains("runtime_boot_plan"), "{}", err.message);
    }

    #[test]
    fn repl_singleton_cast_accepts_explicit_pid_argument() {
        let mut engine = ReplEngine::from_script_source(
            "ticker_preload.srt",
            r#"
defgenserver Ticker {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def value(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }

  @cast
  def tick(state: Int) -> Result<CastResult<Int>> {
    Ok(CastResult::Next(state + 1))
  }
}

supervisor_init {
  Ticker {}
}
"#,
        )
        .expect("preloaded singleton process should initialize");

        let bind = engine.handle_line("p = Ticker::pid()");
        assert!(!bind.should_exit, "{}", ReplEngine::repl_result_text(&bind));

        let tick = engine.handle_line("Ticker::tick(p)");
        assert!(!tick.should_exit, "{}", ReplEngine::repl_result_text(&tick));
        assert!(
            !matches!(
                tick.output,
                ReplOutput::EvalError { .. } | ReplOutput::Diagnostic { .. }
            ),
            "{}",
            ReplEngine::repl_result_text(&tick)
        );
    }

    #[test]
    fn core_type_identity_reports_repl_surface_contract() {
        assert_eq!(
            ReplTypeDisplayCategory::FacetPath.identity_label(),
            "TypeIdentity::FacetPath"
        );
        assert_eq!(
            ReplTypeDisplayCategory::Closure.identity_label(),
            "TypeIdentity::Closure"
        );
        assert_eq!(
            ReplTypeDisplayCategory::Struct.identity_label(),
            "TypeIdentity::Struct"
        );
    }
}
