use diagnostics::{DiagnosticSpec, SourceId, SourceRegistry};
use eldr::builtin::inspect_value;
use eldr::value::Value;
use spire::ast::Span;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ErrorDisplayMode {
    #[default]
    Full,
    Summary,
}

impl ErrorDisplayMode {
    pub fn parse(raw: &str) -> Option<Self> {
        match raw {
            "full" => Some(Self::Full),
            "summary" => Some(Self::Summary),
            _ => None,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Full => "full",
            Self::Summary => "summary",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum StackTraceDisplayMode {
    #[default]
    Off,
    Verbose,
}

impl StackTraceDisplayMode {
    pub fn parse(raw: &str) -> Option<Self> {
        match raw {
            "off" => Some(Self::Off),
            "verbose" => Some(Self::Verbose),
            _ => None,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Off => "off",
            Self::Verbose => "verbose",
        }
    }
}

fn first_visible_line(text: &str) -> String {
    text.lines()
        .find(|line| !line.trim().is_empty())
        .map(|line| line.trim_end().to_string())
        .unwrap_or_default()
}

pub fn text_for_mode(text: &str, mode: ErrorDisplayMode) -> String {
    match mode {
        ErrorDisplayMode::Full => text.to_string(),
        ErrorDisplayMode::Summary => first_visible_line(text),
    }
}

pub fn lines_for_mode(text: &str, mode: ErrorDisplayMode) -> Vec<String> {
    text_for_mode(text, mode)
        .lines()
        .map(|line| line.to_string())
        .collect()
}

fn append_stack_trace_lines(
    lines: &mut Vec<String>,
    stack_trace: &[sindr::runtime::RuntimeStackFrame],
    mode: StackTraceDisplayMode,
) {
    if !matches!(mode, StackTraceDisplayMode::Verbose) || stack_trace.is_empty() {
        return;
    }

    lines.push("Stack trace:".to_string());
    for (idx, frame) in stack_trace.iter().take(32).enumerate() {
        lines.push(format!("  {}: {}", idx, eldr::format_stack_frame(frame)));
    }
    if stack_trace.len() > 32 {
        lines.push(format!("  ... {} frame(s) omitted", stack_trace.len() - 32));
    }
}

pub fn emit_text(text: &str, mode: ErrorDisplayMode) {
    let rendered = text_for_mode(text, mode);
    if rendered.is_empty() {
        return;
    }

    if rendered.ends_with('\n') {
        eprint!("{}", rendered);
    } else {
        eprintln!("{}", rendered);
    }
}

pub fn diagnostic_text(file_name: &str, source: &str, spec: &DiagnosticSpec) -> String {
    diagnostics::render_error(file_name, source, spec)
}

pub fn diagnostic_text_by_id(
    sources: &SourceRegistry,
    source_id: SourceId,
    spec: &DiagnosticSpec,
) -> String {
    diagnostics::render_error_by_id(sources, source_id, spec)
}

pub fn diagnostic_lines(
    file_name: &str,
    source: &str,
    spec: &DiagnosticSpec,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    lines_for_mode(&diagnostic_text(file_name, source, spec), mode)
}

pub fn diagnostic_lines_by_id(
    sources: &SourceRegistry,
    source_id: SourceId,
    spec: &DiagnosticSpec,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    lines_for_mode(&diagnostic_text_by_id(sources, source_id, spec), mode)
}

pub fn emit_diagnostic(
    file_name: &str,
    source: &str,
    spec: &DiagnosticSpec,
    mode: ErrorDisplayMode,
) {
    emit_text(&diagnostic_text(file_name, source, spec), mode);
}

pub fn emit_diagnostic_by_id(
    sources: &SourceRegistry,
    source_id: SourceId,
    spec: &DiagnosticSpec,
    mode: ErrorDisplayMode,
) {
    emit_text(&diagnostic_text_by_id(sources, source_id, spec), mode);
}

fn runtime_error_verbose_enabled() -> bool {
    matches!(
        std::env::var("SURTR_VERBOSE_RUNTIME_ERROR").ok().as_deref(),
        Some("1" | "true" | "TRUE" | "yes" | "YES")
    )
}

fn runtime_error_help_lines(err: &eldr::RuntimeError) -> Vec<String> {
    let mut lines = Vec::new();
    if let Some(pc) = err.context.pc {
        lines.push(format!("pc: {}", pc));
    }
    if let Some(opcode) = err.context.opcode.as_deref() {
        lines.push(format!("opcode: {}", opcode));
    }
    if let Some(function) = err.context.function.as_deref() {
        lines.push(format!("function: {}", function));
    }
    if let Some(location) = err.context.call_site.as_ref() {
        lines.push(format!(
            "call_site: {}:{}:{}",
            location.file, location.line, location.column
        ));
    }
    for detail in &err.context.details {
        if detail.starts_with("__surtr_runtime_error_kind=") {
            continue;
        }
        lines.push(format!("detail: {}", detail));
    }
    lines
}

fn runtime_error_help(err: &eldr::RuntimeError) -> Option<String> {
    let lines = runtime_error_help_lines(err);
    if lines.is_empty() {
        None
    } else {
        Some(lines.join("\n"))
    }
}

fn runtime_error_spec_with_source(
    err: &eldr::RuntimeError,
    location: &sindr::runtime::Location,
    _source: &str,
    include_help: bool,
) -> DiagnosticSpec {
    diagnostics::runtime_error_spec(
        SourceId(0),
        err.message.clone(),
        Span {
            start: location.span_start as usize,
            end: location.span_end as usize,
        },
        &runtime_diagnostic_context(err),
        if include_help {
            runtime_error_help(err)
        } else {
            None
        },
    )
}

fn runtime_error_spec_with_registry(
    err: &eldr::RuntimeError,
    location: &sindr::runtime::Location,
    sources: &SourceRegistry,
    source_id: SourceId,
    include_help: bool,
) -> DiagnosticSpec {
    let (label_source_id, local_span) = runtime_source_context(sources, source_id, location);
    diagnostics::runtime_error_spec_by_id(
        sources,
        label_source_id,
        err.message.clone(),
        local_span,
        &runtime_diagnostic_context(err),
        if include_help {
            runtime_error_help(err)
        } else {
            None
        },
    )
}

fn runtime_diagnostic_context(err: &eldr::RuntimeError) -> diagnostics::RuntimeDiagnosticContext {
    let reason = match err.kind() {
        eldr::error::RuntimeErrorKind::ProcessInitTimeout => {
            diagnostics::RuntimeDiagnosticReason::ProcessInitTimeout
        }
        eldr::error::RuntimeErrorKind::ProcessInitFailed => {
            diagnostics::RuntimeDiagnosticReason::ProcessInitFailed
        }
        eldr::error::RuntimeErrorKind::TaskTimeout => {
            diagnostics::RuntimeDiagnosticReason::TaskTimeout
        }
        eldr::error::RuntimeErrorKind::CallTimeout => {
            diagnostics::RuntimeDiagnosticReason::CallTimeout
        }
        eldr::error::RuntimeErrorKind::ProcessLifecycleFailed => {
            diagnostics::RuntimeDiagnosticReason::ProcessLifecycleFailed
        }
        eldr::error::RuntimeErrorKind::Generic
            if err.context.opcode.as_deref() == Some("CallBuiltin") =>
        {
            diagnostics::RuntimeDiagnosticReason::BuiltinContractViolation
        }
        eldr::error::RuntimeErrorKind::Generic => diagnostics::RuntimeDiagnosticReason::VmInvariant,
    };
    diagnostics::RuntimeDiagnosticContext {
        reason,
        opcode: err.context.opcode.clone(),
        function: err.context.function.clone(),
        details: err
            .context
            .details
            .iter()
            .filter(|detail| !detail.starts_with("__surtr_runtime_error_kind="))
            .cloned()
            .collect(),
    }
}

fn runtime_source_context(
    sources: &SourceRegistry,
    fallback_source_id: SourceId,
    location: &sindr::runtime::Location,
) -> (SourceId, Span) {
    let raw_span = Span {
        start: location.span_start as usize,
        end: location.span_end as usize,
    };
    if let Some((source_id, local_span)) = crate::decode_rebased_module_span(&raw_span) {
        if sources.get(source_id).is_some() {
            return (source_id, local_span);
        }
    }
    let by_file = sources
        .entries()
        .iter()
        .find(|entry| entry.file_name == location.file)
        .map(|entry| entry.id);
    (by_file.unwrap_or(fallback_source_id), raw_span)
}

fn runtime_file_name(location: &sindr::runtime::Location, fallback_file: Option<&str>) -> String {
    if location.file.is_empty() {
        fallback_file.unwrap_or("<runtime>").to_string()
    } else {
        location.file.clone()
    }
}

fn fallback_span_from_source(source: &str) -> Span {
    let len = source.chars().count();
    if len == 0 {
        Span { start: 0, end: 0 }
    } else {
        Span { start: 0, end: 1 }
    }
}

fn invalid_result_spec(span: Span) -> DiagnosticSpec {
    diagnostics::simple_error(
        "InvalidResult",
        "missing Err payload",
        span,
        Some("Result::Err must carry one payload value.".into()),
    )
}

pub fn runtime_error_text(
    err: &eldr::RuntimeError,
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
) -> String {
    let verbose = runtime_error_verbose_enabled();
    let effective_location = location.or_else(|| err.context.call_site.clone());
    match (source, effective_location.as_ref()) {
        (Some(source), Some(location)) => {
            let file_name = runtime_file_name(location, fallback_file);
            let spec = runtime_error_spec_with_source(err, location, source, verbose);
            diagnostics::render_error(&file_name, source, &spec)
        }
        _ => {
            let mut rendered =
                eldr::format_runtime_error_with_location(err, effective_location.as_ref());
            if verbose {
                if let Some(help) = runtime_error_help(err) {
                    if !rendered.ends_with('\n') {
                        rendered.push('\n');
                    }
                    for line in help.lines() {
                        rendered.push_str("help: ");
                        rendered.push_str(line);
                        rendered.push('\n');
                    }
                }
            }
            rendered
        }
    }
}

pub fn runtime_error_text_with_registry(
    err: &eldr::RuntimeError,
    sources: &SourceRegistry,
    source_id: SourceId,
    location: Option<sindr::runtime::Location>,
) -> String {
    let verbose = runtime_error_verbose_enabled();
    match location.as_ref() {
        Some(location) => {
            let (label_source_id, _) = runtime_source_context(sources, source_id, location);
            let spec = runtime_error_spec_with_registry(err, location, sources, source_id, verbose);
            diagnostic_text_by_id(sources, label_source_id, &spec)
        }
        None => {
            let mut rendered = eldr::format_runtime_error(err);
            if verbose {
                if let Some(help) = runtime_error_help(err) {
                    if !rendered.ends_with('\n') {
                        rendered.push('\n');
                    }
                    for line in help.lines() {
                        rendered.push_str("help: ");
                        rendered.push_str(line);
                        rendered.push('\n');
                    }
                }
            }
            rendered
        }
    }
}

fn runtime_value_cause_help(value: &sindr::runtime::RichError) -> Option<String> {
    let mut lines = Vec::new();
    let mut next = value.cause.as_deref();
    while let Some(cause) = next {
        lines.push(format!(
            "Caused by: {}: {}",
            cause.kind,
            cause.visible_message()
        ));
        next = cause.cause.as_deref();
    }
    if lines.is_empty() {
        None
    } else {
        Some(lines.join("\n"))
    }
}

pub fn runtime_error_lines(
    err: &eldr::RuntimeError,
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    runtime_error_lines_with_stack_trace(
        err,
        source,
        fallback_file,
        location,
        mode,
        StackTraceDisplayMode::Off,
    )
}

pub fn runtime_error_lines_with_stack_trace(
    err: &eldr::RuntimeError,
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
    stack_trace_mode: StackTraceDisplayMode,
) -> Vec<String> {
    let mut lines = lines_for_mode(
        &runtime_error_text(err, source, fallback_file, location),
        mode,
    );
    append_stack_trace_lines(&mut lines, &err.context.stack_trace, stack_trace_mode);
    lines
}

pub fn runtime_error_lines_with_registry(
    err: &eldr::RuntimeError,
    sources: &SourceRegistry,
    source_id: SourceId,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    runtime_error_lines_with_registry_and_stack_trace(
        err,
        sources,
        source_id,
        location,
        mode,
        StackTraceDisplayMode::Off,
    )
}

pub fn runtime_error_lines_with_registry_and_stack_trace(
    err: &eldr::RuntimeError,
    sources: &SourceRegistry,
    source_id: SourceId,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
    stack_trace_mode: StackTraceDisplayMode,
) -> Vec<String> {
    let mut lines = lines_for_mode(
        &runtime_error_text_with_registry(err, sources, source_id, location),
        mode,
    );
    append_stack_trace_lines(&mut lines, &err.context.stack_trace, stack_trace_mode);
    lines
}

pub fn emit_runtime_error(
    err: &eldr::RuntimeError,
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
) {
    emit_text(
        &runtime_error_text(err, source, fallback_file, location),
        mode,
    );
}

pub fn emit_runtime_error_with_registry(
    err: &eldr::RuntimeError,
    sources: &SourceRegistry,
    source_id: SourceId,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
) {
    emit_text(
        &runtime_error_text_with_registry(err, sources, source_id, location),
        mode,
    );
}

pub fn invalid_result_missing_payload_text(
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
) -> String {
    match source {
        Some(source) => {
            let (file_name, span) = match location.as_ref() {
                Some(location) => {
                    let start = location.span_start as usize;
                    let end = if location.span_end > location.span_start {
                        location.span_end as usize
                    } else {
                        start.saturating_add(1)
                    };
                    (
                        runtime_file_name(location, fallback_file),
                        Span { start, end },
                    )
                }
                None => (
                    fallback_file.unwrap_or("<runtime>").to_string(),
                    fallback_span_from_source(source),
                ),
            };
            diagnostics::render_error(&file_name, source, &invalid_result_spec(span))
        }
        None => "Error: InvalidResult: missing Err payload".to_string(),
    }
}

pub fn emit_invalid_result_missing_payload(
    source: Option<&str>,
    fallback_file: Option<&str>,
    location: Option<sindr::runtime::Location>,
    mode: ErrorDisplayMode,
) {
    emit_text(
        &invalid_result_missing_payload_text(source, fallback_file, location),
        mode,
    );
}

fn error_spec_from_value_error_at_span(
    value: &sindr::runtime::RichError,
    source_id: SourceId,
    span: &Span,
) -> DiagnosticSpec {
    diagnostics::runtime_value_error_spec(
        source_id,
        crate::surface_path_name(&value.kind).to_string(),
        value.visible_message(),
        span.start,
        span.end,
        value.diagnostic.as_ref(),
        runtime_value_cause_help(value),
    )
}

fn value_error_text_without_source(value: &sindr::runtime::RichError) -> String {
    let mut text = format!(
        "Error: {}: {}",
        crate::surface_path_name(&value.kind),
        value.visible_message()
    );
    let location = value.primary_location();
    if location.line > 0 {
        text.push_str(&format!(
            "\n  at {}:{}:{}",
            location.file, location.line, location.column
        ));
    } else {
        text.push_str(&format!(
            "\n  at {} (span {}..{})",
            location.file, location.span_start, location.span_end
        ));
    }
    if let Some(cause) = runtime_value_cause_help(value) {
        text.push('\n');
        text.push_str(&cause);
    }
    text
}

fn value_error_source_context(
    vm: &eldr::VM,
    sources: &SourceRegistry,
    location: &sindr::runtime::Location,
) -> Option<(SourceId, Span)> {
    let raw_span = Span {
        start: location.span_start as usize,
        end: location.span_end as usize,
    };
    let (file, span) =
        if let Some((source_id, local_span)) = crate::decode_rebased_module_span(&raw_span) {
            if vm.bytecode().sources.is_empty() {
                // The caller's live registry retains the compiler's original source IDs.
                sources.get(source_id)?;
                return Some((source_id, local_span));
            }
            // Embedded source registries may assign new IDs when omitting source text.
            // Resolve the original ID through the canonical bytecode table first.
            let entry = vm
                .bytecode()
                .sources
                .iter()
                .find(|entry| entry.source_id == source_id.0)?;
            (
                entry.normalized_path.as_deref().unwrap_or(&entry.path),
                local_span,
            )
        } else {
            (location.file.as_str(), raw_span)
        };
    let source_id = sources
        .entries()
        .iter()
        .find(|entry| entry.file_name == file)?
        .id;
    Some((source_id, span))
}

pub fn runtime_value_error_text_from_vm(vm: &eldr::VM, value: &Value) -> String {
    match value {
        Value::Error(rich) => {
            let location = rich.primary_location();
            let raw_span = Span {
                start: location.span_start as usize,
                end: location.span_end as usize,
            };
            let origin =
                if let Some((source_id, span)) = crate::decode_rebased_module_span(&raw_span) {
                    vm.bytecode()
                        .sources
                        .iter()
                        .find(|entry| entry.source_id == source_id.0)
                        .and_then(|entry| {
                            entry.text.as_deref().map(|text| {
                                (
                                    entry.normalized_path.as_deref().unwrap_or(&entry.path),
                                    text,
                                    span,
                                )
                            })
                        })
                } else if let Some(entry) = vm.bytecode().sources.iter().find(|entry| {
                    entry.normalized_path.as_deref().unwrap_or(&entry.path) == location.file
                }) {
                    entry
                        .text
                        .as_deref()
                        .map(|text| (location.file.as_str(), text, raw_span))
                } else {
                    vm.source_file()
                        .filter(|file| *file == location.file)
                        .zip(vm.source())
                        .map(|(file, source)| (file, source, raw_span))
                };
            if let Some((file_name, source, span)) = origin {
                let spec = error_spec_from_value_error_at_span(rich, SourceId(0), &span);
                diagnostic_text(file_name, source, &spec)
            } else {
                value_error_text_without_source(rich)
            }
        }
        other => match inspect_value(vm, other) {
            Ok(rendered) => format!("Error: {}", rendered),
            Err(error) => runtime_error_text(
                &error,
                vm.source(),
                vm.source_file(),
                vm.runtime_error_location(),
            ),
        },
    }
}

pub fn runtime_value_error_text_with_registry(
    vm: &eldr::VM,
    value: &Value,
    sources: &SourceRegistry,
    _source_id: SourceId,
) -> String {
    match value {
        Value::Error(rich) => {
            if let Some((source_id, span)) =
                value_error_source_context(vm, sources, rich.primary_location())
            {
                let spec = error_spec_from_value_error_at_span(rich, source_id, &span);
                diagnostic_text_by_id(sources, source_id, &spec)
            } else {
                value_error_text_without_source(rich)
            }
        }
        other => match inspect_value(vm, other) {
            Ok(rendered) => format!("Error: {}", rendered),
            Err(error) => runtime_error_text_with_registry(
                &error,
                sources,
                _source_id,
                vm.runtime_error_location(),
            ),
        },
    }
}

pub fn runtime_value_error_lines_from_vm(
    vm: &eldr::VM,
    value: &Value,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    runtime_value_error_lines_from_vm_with_stack_trace(vm, value, mode, StackTraceDisplayMode::Off)
}

pub fn runtime_value_error_lines_from_vm_with_stack_trace(
    vm: &eldr::VM,
    value: &Value,
    mode: ErrorDisplayMode,
    stack_trace_mode: StackTraceDisplayMode,
) -> Vec<String> {
    let mut lines = lines_for_mode(&runtime_value_error_text_from_vm(vm, value), mode);
    if let Value::Error(rich) = value {
        append_stack_trace_lines(&mut lines, &rich.stack_trace, stack_trace_mode);
    }
    lines
}

pub fn runtime_value_error_lines_with_registry(
    vm: &eldr::VM,
    value: &Value,
    sources: &SourceRegistry,
    source_id: SourceId,
    mode: ErrorDisplayMode,
) -> Vec<String> {
    runtime_value_error_lines_with_registry_and_stack_trace(
        vm,
        value,
        sources,
        source_id,
        mode,
        StackTraceDisplayMode::Off,
    )
}

pub fn runtime_value_error_lines_with_registry_and_stack_trace(
    vm: &eldr::VM,
    value: &Value,
    sources: &SourceRegistry,
    source_id: SourceId,
    mode: ErrorDisplayMode,
    stack_trace_mode: StackTraceDisplayMode,
) -> Vec<String> {
    let mut lines = lines_for_mode(
        &runtime_value_error_text_with_registry(vm, value, sources, source_id),
        mode,
    );
    if let Value::Error(rich) = value {
        append_stack_trace_lines(&mut lines, &rich.stack_trace, stack_trace_mode);
    }
    lines
}

pub fn emit_runtime_value_error_from_vm(vm: &eldr::VM, value: &Value, mode: ErrorDisplayMode) {
    emit_text(&runtime_value_error_text_from_vm(vm, value), mode);
}

pub fn emit_runtime_value_error_with_registry(
    vm: &eldr::VM,
    value: &Value,
    sources: &SourceRegistry,
    source_id: SourceId,
    mode: ErrorDisplayMode,
) {
    emit_text(
        &runtime_value_error_text_with_registry(vm, value, sources, source_id),
        mode,
    );
}

#[cfg(test)]
mod tests {
    use super::{
        invalid_result_missing_payload_text, runtime_error_text, runtime_value_error_text_from_vm,
        runtime_value_error_text_with_registry,
    };
    use eldr::{error::RuntimeErrorContext, VM};
    use sindr::ir::Bytecode;
    use sindr::runtime::{Location, RichError, Value};

    #[test]
    fn runtime_value_error_registry_uses_the_creation_file() {
        let mut sources = diagnostics::SourceRegistry::new();
        let script = sources.register("main.srt", "main()\n");
        sources.register("definition.srt", "def source() {\n  Failure(\"bad\")\n}\n");
        let vm = VM::new(Bytecode::default()).with_source("main()\n".into(), "main.srt".into());
        let error = Value::Error(Box::new(RichError::new(
            "Failure",
            "bad",
            Location {
                file: "definition.srt".into(),
                func: "Failure".into(),
                line: 2,
                column: 3,
                span_start: 17,
                span_end: 31,
            },
            None,
        )));
        let text = runtime_value_error_text_with_registry(&vm, &error, &sources, script);
        assert!(text.contains("definition.srt:2:3"), "{text}");
        assert!(!text.contains("main.srt:"), "{text}");
    }

    #[test]
    fn runtime_value_error_does_not_substitute_an_unrelated_source() {
        let mut sources = diagnostics::SourceRegistry::new();
        let script = sources.register("main.srt", "UNRELATED_SCRIPT()\n");
        for (file, start, embedded) in [
            ("missing.srt", 4, vec![]),
            (
                "<source:9>",
                10 * sindr::ir::MODULE_SPAN_STRIDE as u32 + 4,
                vec![],
            ),
            (
                "<source:0>",
                sindr::ir::MODULE_SPAN_STRIDE as u32 + 4,
                vec![sindr::ir::SourceFileEntry {
                    source_id: 10,
                    path: "main.srt".into(),
                    normalized_path: None,
                    content_hash: None,
                    text: Some("UNRELATED_SCRIPT()\n".into()),
                }],
            ),
        ] {
            let vm = VM::new(Bytecode {
                sources: embedded,
                ..Bytecode::default()
            })
            .with_source("UNRELATED_SCRIPT()\n".into(), "main.srt".into());
            let value = Value::Error(Box::new(RichError::new(
                "Failure",
                "bad",
                Location {
                    file: file.into(),
                    func: "Failure".into(),
                    line: 0,
                    column: 0,
                    span_start: start,
                    span_end: start + 1,
                },
                None,
            )));
            for text in [
                runtime_value_error_text_from_vm(&vm, &value),
                runtime_value_error_text_with_registry(&vm, &value, &sources, script),
            ] {
                assert!(text.contains("Error: Failure: bad"), "{text}");
                assert!(text.contains(file), "{text}");
                assert!(!text.contains("UNRELATED_SCRIPT"), "{text}");
                assert!(!text.contains("main.srt:"), "{text}");
            }
        }
    }

    #[test]
    fn runtime_value_error_resolves_an_encoded_origin_in_the_live_registry() {
        let mut sources = diagnostics::SourceRegistry::new();
        let script = sources.register("main.srt", "main()\n");
        sources.register("definition.srt", "def source() {\n  Failure(\"bad\")\n}\n");
        let vm = VM::new(Bytecode::default()).with_source("main()\n".into(), "main.srt".into());
        let base = 2 * sindr::ir::MODULE_SPAN_STRIDE as u32;
        let value = Value::Error(Box::new(RichError::new(
            "Failure",
            "bad",
            Location {
                file: "<source:1>".into(),
                func: "Failure".into(),
                line: 0,
                column: 0,
                span_start: base + 17,
                span_end: base + 31,
            },
            None,
        )));
        let text = runtime_value_error_text_with_registry(&vm, &value, &sources, script);
        assert!(text.contains("definition.srt:2:3"), "{text}");
        assert!(!text.contains("main.srt:"), "{text}");
    }

    #[test]
    fn runtime_error_text_uses_runtimeerror_headline_with_message() {
        let err = eldr::RuntimeError::new("division by zero");
        let text = runtime_error_text(
            &err,
            Some("Mod::safe_mod(10, 0)"),
            Some("main.srt"),
            Some(Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 14,
            }),
        );
        assert!(text.contains("RuntimeError: division by zero"));
        assert!(text.contains("main.srt"));
    }

    #[test]
    fn runtime_error_text_does_not_infer_builtin_contract_from_message() {
        let err = eldr::RuntimeError::new("len expects List as first argument");
        let text = runtime_error_text(
            &err,
            Some(r#"len("oops")"#),
            Some("main.srt"),
            Some(Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 11,
            }),
        );
        assert!(text.contains("len expects List as first argument"));
        assert!(!text.contains("call target"));
        assert!(!text.contains("expected rule:"));
    }

    #[test]
    fn runtime_error_text_uses_explicit_opcode_without_inferring_runtime_rule() {
        let err = eldr::RuntimeError::new("JumpIfFalse: expected Bool").with_context(
            RuntimeErrorContext {
                pc: Some(9),
                opcode: Some("JumpIfFalse".into()),
                function: Some("fun#1".into()),
                call_site: None,
                details: Vec::new(),
                stack_trace: Vec::new(),
            },
        );
        let text = runtime_error_text(
            &err,
            Some("bad_jump"),
            Some("main.srt"),
            Some(Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 8,
            }),
        );
        assert!(text.contains("opcode: JumpIfFalse"));
        assert!(!text.contains("runtime rule:"));
    }

    #[test]
    fn runtime_value_error_text_includes_cause_chain_as_help() {
        let vm = VM::new(Bytecode::default()).with_source("main()".into(), "main.srt".into());
        let value = Value::Error(Box::new(RichError {
            kind: "Higher".into(),
            message: "higher".into(),
            payload: Vec::new(),
            location: Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 6,
            },
            diagnostic: None,
            cause: Some(Box::new(RichError {
                kind: "Lower".into(),
                message: "lower".into(),
                payload: Vec::new(),
                location: Location {
                    file: "main.srt".into(),
                    func: "<runtime>".into(),
                    line: 1,
                    column: 1,
                    span_start: 0,
                    span_end: 6,
                },
                diagnostic: None,
                cause: None,
                stack_trace: Vec::new(),
            })),
            stack_trace: Vec::new(),
        }));

        let text = runtime_value_error_text_from_vm(&vm, &value);
        assert!(text.contains("Higher: higher"));
        assert!(text.contains("Caused by: Lower: lower"));
    }

    #[test]
    fn runtime_value_error_text_adds_list_pattern_rule_for_fixed_safebind() {
        let vm =
            VM::new(Bytecode::default()).with_source("[h] =? [1, 2]".into(), "main.srt".into());
        let value = Value::Error(Box::new(RichError {
            kind: "IndexOutOfBounds".into(),
            message: "LHS.len(1) < RHS.len(2)".into(),
            payload: Vec::new(),
            location: Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 8,
                span_start: 7,
                span_end: 12,
            },
            diagnostic: Some(
                sindr::runtime::RuntimeErrorDiagnostic::SafeBindPatternFailure {
                    rule: "fixed-length list pattern requires List.len to match the pattern arity"
                        .into(),
                    input_source: Some("List".into()),
                },
            ),
            cause: None,
            stack_trace: Vec::new(),
        }));

        let text = runtime_value_error_text_from_vm(&vm, &value);
        assert!(
            text.contains("fixed-length list pattern requires List.len to match the pattern arity")
        );
        assert!(text.contains("SafeBind partial match"));
        assert!(text.contains("input source: List"));
    }

    #[test]
    fn runtime_value_error_text_adds_list_pattern_rule_for_head_tail_safebind() {
        let vm =
            VM::new(Bytecode::default()).with_source("[h, ..t] =? []".into(), "main.srt".into());
        let value = Value::Error(Box::new(RichError {
            kind: "EmptyList".into(),
            message: "Empty List.".into(),
            payload: Vec::new(),
            location: Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 13,
                span_start: 12,
                span_end: 14,
            },
            diagnostic: Some(
                sindr::runtime::RuntimeErrorDiagnostic::SafeBindPatternFailure {
                    rule: "head-tail list pattern requires a non-empty List".into(),
                    input_source: Some("List".into()),
                },
            ),
            cause: None,
            stack_trace: Vec::new(),
        }));

        let text = runtime_value_error_text_from_vm(&vm, &value);
        assert!(text.contains("head-tail list pattern requires a non-empty List"));
        assert!(text.contains("SafeBind partial match"));
        assert!(text.contains("input source: List"));
    }

    #[test]
    fn runtime_value_error_text_adds_string_pattern_rule_for_head_tail_safebind() {
        let vm =
            VM::new(Bytecode::default()).with_source(r#"[h, ..t] =? """#.into(), "main.srt".into());
        let value = Value::Error(Box::new(RichError {
            kind: "PatternMismatch".into(),
            message: "Pattern did not match.".into(),
            payload: Vec::new(),
            location: Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            diagnostic: Some(
                sindr::runtime::RuntimeErrorDiagnostic::SafeBindPatternFailure {
                    rule: "head-tail list pattern requires a non-empty String".into(),
                    input_source: Some("String".into()),
                },
            ),
            cause: None,
            stack_trace: Vec::new(),
        }));

        let text = runtime_value_error_text_from_vm(&vm, &value);
        assert!(text.contains("head-tail list pattern requires a non-empty String"));
        assert!(text.contains("SafeBind partial match"));
        assert!(text.contains("input source: String"));
    }

    #[test]
    fn runtime_error_text_fallback_keeps_context_help_when_verbose_is_enabled() {
        static ENV_LOCK: std::sync::OnceLock<std::sync::Mutex<()>> = std::sync::OnceLock::new();
        let env_lock = ENV_LOCK.get_or_init(|| std::sync::Mutex::new(()));
        let _guard = env_lock.lock().expect("lock should succeed");
        let previous = std::env::var("SURTR_VERBOSE_RUNTIME_ERROR").ok();
        std::env::set_var("SURTR_VERBOSE_RUNTIME_ERROR", "1");

        let err = eldr::RuntimeError::new("boom").with_context(RuntimeErrorContext {
            pc: Some(9),
            opcode: Some("AddInt".into()),
            function: Some("fun#1".into()),
            call_site: Some(Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 2,
                column: 3,
                span_start: 3,
                span_end: 5,
            }),
            details: vec!["stack_depth=1".into()],
            stack_trace: Vec::new(),
        });
        let text = runtime_error_text(&err, None, None, None);
        assert!(text.contains("RuntimeError: boom"));
        assert!(text.contains("help: pc: 9"));
        assert!(text.contains("help: opcode: AddInt"));

        match previous {
            Some(value) => std::env::set_var("SURTR_VERBOSE_RUNTIME_ERROR", value),
            None => std::env::remove_var("SURTR_VERBOSE_RUNTIME_ERROR"),
        }
    }

    #[test]
    fn invalid_result_missing_payload_uses_diagnostic_shape_when_source_exists() {
        let text = invalid_result_missing_payload_text(
            Some("main()"),
            Some("main.srt"),
            Some(Location {
                file: "main.srt".into(),
                func: "<runtime>".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 6,
            }),
        );
        assert!(text.contains("InvalidResult: missing Err payload"));
        assert!(text.contains("main.srt"));
    }
}
