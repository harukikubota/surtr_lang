use super::context::ParseUnitKind;
use super::*;
use crate::error::ParseErrorReason;
use sindr::primitives::int;

fn bulk_path_segments(path: &BulkUpdatePath) -> &[FacetPathSegment] {
    match path {
        BulkUpdatePath::Segments(_, segments) => segments,
        other => panic!("expected bulk path segments, got {other:?}"),
    }
}

#[test]
fn test_bind_and_var() {
    let ast = parse("x = 42").unwrap();
    assert_eq!(ast.len(), 1);
    match &ast[0] {
        Ast::Bind(_, AstPattern::Var(_, name), rhs) => {
            assert_eq!(name, "x");
            assert!(matches!(rhs.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(42)));
        }
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_annotated_bind() {
    let ast = parse("num: Int = 10").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, name, AstTy::Named(_, ty)), _) => {
            assert_eq!(name, "num");
            assert_eq!(ty, "Int");
        }
        _ => panic!("Expected annotated Bind"),
    }
}

#[test]
fn test_defp_marks_definition_private() {
    let ast = parse("defp helper() -> String { \"ok\" }").unwrap();
    match &ast[0] {
        Ast::Def(_, name, _, _, _, _, _, attrs) => {
            assert_eq!(name, "helper");
            assert_eq!(attrs.visibility, Visibility::Private);
        }
        _ => panic!("Expected Def"),
    }
}

#[test]
fn test_doc_on_private_def_is_rejected() {
    let err = parse(
        r#"@doc """Hidden helper."""
defp helper() -> String { "ok" }"#,
    )
    .expect_err("@doc on defp should fail");

    assert!(err
        .message()
        .contains("@doc is only allowed on public declarations"));
}

#[test]
fn test_const_definition_surface() {
    let ast = parse("public const APP_NAME: String = \"surtr\"").unwrap();
    match &ast[0] {
        Ast::ConstDef(_, name, Some(AstTy::Named(_, ty)), rhs, attrs) => {
            assert_eq!(name, "APP_NAME");
            assert_eq!(ty, "String");
            assert_eq!(attrs.visibility, Visibility::Public);
            assert!(matches!(rhs.as_ref(), Ast::Lit(_, Lit::Str(value)) if value == "surtr"));
        }
        _ => panic!("Expected ConstDef"),
    }
}

#[test]
fn test_const_name_requires_cap_pattern() {
    let err = parse("const app_name = \"surtr\"").expect_err("expected parse error");
    assert!(err.message().contains("const name must match CAP_PATTERN"));
}

#[test]
fn test_private_field_modifier_is_preserved() {
    let ast = parse_with_context(
        "defstruct User { private password: String, name: String }",
        ParserContext::project(0),
    )
    .unwrap();
    match &ast[0] {
        Ast::StructDef(_, name, _, fields, attrs) => {
            assert_eq!(name, "Global::User");
            assert_eq!(fields[0].name, "password");
            assert_eq!(fields[0].visibility, Visibility::Private);
            assert!(!fields[0].readonly);
            assert_eq!(fields[1].name, "name");
            assert_eq!(fields[1].visibility, Visibility::Public);
            assert!(!fields[1].readonly);
            assert_eq!(attrs, &DeclAttrs::default());
        }
        _ => panic!("Expected StructDef"),
    }
}

#[test]
fn test_generic_struct_type_params_are_preserved() {
    let ast =
        parse_with_context("defstruct Box<$A> { value: $A }", ParserContext::project(0)).unwrap();
    match &ast[0] {
        Ast::StructDef(_, name, type_params, fields, attrs) => {
            assert_eq!(name, "Global::Box");
            assert_eq!(type_params.len(), 1);
            assert_eq!(type_params[0].name, "$A");
            assert_eq!(fields.len(), 1);
            assert_eq!(fields[0].name, "value");
            assert!(matches!(fields[0].ty, AstTy::Named(_, ref ty) if ty == "$A"));
            assert_eq!(attrs, &DeclAttrs::default());
        }
        _ => panic!("Expected StructDef"),
    }
}

#[test]
fn test_generic_struct_two_type_params_are_preserved() {
    let ast = parse_with_context(
        "defstruct Pair<$A, $B> { left: $A, right: $B }",
        ParserContext::project(0),
    )
    .unwrap();
    match &ast[0] {
        Ast::StructDef(_, name, type_params, fields, _) => {
            assert_eq!(name, "Global::Pair");
            assert_eq!(type_params.len(), 2);
            assert_eq!(type_params[0].name, "$A");
            assert_eq!(type_params[1].name, "$B");
            assert_eq!(fields.len(), 2);
            assert!(matches!(fields[0].ty, AstTy::Named(_, ref ty) if ty == "$A"));
            assert!(matches!(fields[1].ty, AstTy::Named(_, ref ty) if ty == "$B"));
        }
        _ => panic!("Expected StructDef"),
    }
}

#[test]
fn test_readonly_struct_field_modifier_is_preserved() {
    let ast = parse_with_context(
        "defstruct User { readonly profile: Profile, public readonly name: String }",
        ParserContext::project(0),
    )
    .unwrap();
    match &ast[0] {
        Ast::StructDef(_, name, _, fields, attrs) => {
            assert_eq!(name, "Global::User");
            assert_eq!(fields[0].name, "profile");
            assert!(fields[0].readonly);
            assert_eq!(fields[0].visibility, Visibility::Public);
            assert_eq!(fields[1].name, "name");
            assert!(fields[1].readonly);
            assert_eq!(fields[1].visibility, Visibility::Public);
            assert_eq!(attrs, &DeclAttrs::default());
        }
        _ => panic!("Expected StructDef"),
    }
}

#[test]
fn test_readonly_record_field_modifier_is_rejected() {
    let err = parse_with_context(
        "defrecord User(readonly name: String)",
        ParserContext::project(0),
    )
    .expect_err("readonly record field should fail");

    assert!(err
        .message()
        .contains("readonly field modifier is only supported on `defstruct` fields"));
}

#[test]
fn test_record_field_visibility_modifiers_are_rejected() {
    for source in [
        "defrecord User(private name: String)",
        "defrecord User(public name: String)",
    ] {
        let err = parse_with_context(source, ParserContext::project(0))
            .expect_err("record field visibility should fail");
        assert!(err
            .message()
            .contains("record fields do not support visibility modifiers"));
    }
}

#[test]
fn test_zero_field_record_definitions_are_rejected() {
    for source in ["defrecord Empty()", "defrecord Empty( )"] {
        let err = parse_with_context(source, ParserContext::project(0))
            .expect_err("zero-field record should fail");
        assert!(err
            .message()
            .contains("record must declare at least one field"));
    }
}

#[test]
fn test_record_positional_field_names_are_rejected() {
    for source in ["defrecord User(_0: String)", "defrecord User(_12: String)"] {
        let err = parse_with_context(source, ParserContext::project(0))
            .expect_err("record positional field name should fail");
        assert!(err
            .message()
            .contains("record field name cannot use positional `_N`"));
    }
}

#[test]
fn test_readonly_struct_metadata_and_field_modifier_are_preserved() {
    let ast = parse_with_context(
        "@readonly\ndefstruct User { private readonly password: String, readonly name: String }",
        ParserContext::project(0),
    )
    .unwrap();
    match &ast[0] {
        Ast::StructDef(_, name, _, fields, attrs) => {
            assert_eq!(name, "Global::User");
            assert!(attrs.readonly);
            assert_eq!(fields[0].name, "password");
            assert_eq!(fields[0].visibility, Visibility::Private);
            assert!(fields[0].readonly);
            assert_eq!(fields[1].name, "name");
            assert_eq!(fields[1].visibility, Visibility::Public);
            assert!(fields[1].readonly);
        }
        _ => panic!("Expected StructDef"),
    }
}

#[test]
fn test_doc_attributes_parse_for_struct_and_record_decls() {
    let ast = parse_with_context(
        r#"@doc """User docs."""
defstruct User {
  name: String,
}

@doc """Point docs."""
defrecord Point(x: Float, y: Float)"#,
        ParserContext::module(1, None),
    )
    .expect("annotated struct and record should parse");

    match &ast[0] {
        Ast::StructDef(_, name, _, fields, attrs) => {
            assert_eq!(name, "Global::User");
            assert_eq!(fields.len(), 1);
            assert_eq!(attrs.doc.as_deref(), Some("User docs."));
        }
        other => panic!("Expected StructDef, got {other:?}"),
    }

    match &ast[1] {
        Ast::RecordDef(_, name, fields, attrs) => {
            assert_eq!(name, "Global::Point");
            assert_eq!(fields.len(), 2);
            assert_eq!(attrs.doc.as_deref(), Some("Point docs."));
        }
        other => panic!("Expected RecordDef, got {other:?}"),
    }
}

#[test]
fn test_process_state_annotation_is_rejected() {
    let err = parse_with_context(
        r#"@process_state(Counter)
defstruct CounterState {
  value: Int,
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@process_state should be rejected");

    assert!(err.message().contains("@process_state has been removed"));
}

#[test]
fn test_process_helpers_require_defp_and_handlers_require_def() {
    for (kind, marker, handler_return) in [
        ("defagent", "get", "Result<Int>"),
        ("defgenserver", "call", "Result<CallResult<Int, Int>>"),
    ] {
        let source = format!(
            r#"{kind} Counter {{
  meta {{
    instance: Worker
    init_policy: Eager
    state: Int
  }}
  @init
  def init(seed: Int) -> Result<Int> {{ Ok(seed) }}
  @{marker}
  def read(state: Int) -> {handler_return} {{ helper(state) }}
  def helper(state: Int) -> Int {{ state }}
}}"#
        );
        for source in [
            source.clone(),
            source.replace("  def helper", "  @doc \"\"\"Helper.\"\"\"\n  def helper"),
        ] {
            let error = parse_with_context(&source, ParserContext::module(1, None))
                .expect_err("annotation-less def must be rejected");
            assert!(
                error
                    .message()
                    .contains("Process helpers must use `defp`; change `def` to `defp`"),
                "{error:?}"
            );
        }
        let valid = source.replace("def helper", "defp helper");
        let ast = parse_with_context(&valid, ParserContext::module(1, None)).unwrap();
        let body = match &ast[0] {
            Ast::Defagent(_, _, body, _, _) | Ast::Defgenserver(_, _, body, _, _) => body,
            other => panic!("expected process, got {other:?}"),
        };
        let attrs = body
            .iter()
            .find_map(|node| match node {
                Ast::Def(_, name, _, _, _, _, _, attrs) if name == "helper" => Some(attrs),
                _ => None,
            })
            .unwrap();
        assert_eq!(attrs.visibility, Visibility::Private);
        let bad = valid.replace("def read", "defp read");
        let error = parse_with_context(&bad, ParserContext::module(1, None)).unwrap_err();
        assert!(
            error.message().contains("must be followed by def"),
            "{error:?}"
        );
    }
}

#[test]
fn test_doc_on_private_process_helper_is_rejected() {
    let err = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def read(state: Int) -> Result<Int> { Ok(state) }

  @doc """Internal helper."""
  defp hidden_value(_state: Int) -> Result<Int> { Ok(99) }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@doc on explicit private process helper should fail");

    assert!(err
        .message()
        .contains("@doc is only allowed on public declarations"));
}

#[test]
fn test_duplicate_doc_annotation_reports_later_span_for_struct_decl() {
    let src = r#"@doc """first"""
@doc """second"""
defstruct User {
  name: String,
}"#;
    let err = parse_with_context(src, ParserContext::module(1, None))
        .expect_err("duplicate struct doc annotation should fail");
    assert!(err
        .message()
        .contains("@doc may only appear once before a declaration"));

    let duplicate_offset = src.find(r#"@doc """second""""#).expect("second @doc");
    assert_eq!(
        err.span(),
        &Span {
            start: duplicate_offset,
            end: duplicate_offset + "@doc".len(),
        }
    );
}

#[test]
fn test_impl_member_rejects_autoimport_annotation() {
    let err = parse_with_context(
        r#"defstruct User {
  name: String,
}

impl User {
  @autoimport
  def normalize(self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@autoimport impl member should be rejected");

    assert!(err
        .message()
        .contains("Only @doc / @hidden / @builtin / @intrinsic are allowed before impl members"));
}

#[test]
fn test_doc_on_private_impl_member_is_rejected() {
    let err = parse_with_context(
        r#"defstruct User {
  name: String,
}

impl User {
  @doc """Normalize a private helper."""
  defp normalize(self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@doc on private impl member should fail");

    assert!(err
        .message()
        .contains("@doc is only allowed on public declarations"));
}

#[test]
fn test_dbg_special_form_parses() {
    let ast = parse("dbg!(x, y)").unwrap();
    match &ast[0] {
        Ast::Dbg(_, args) => {
            assert_eq!(args.len(), 2);
            assert!(matches!(args[0].expr, Ast::Var(_, ref name) if name == "x"));
            assert!(matches!(args[1].expr, Ast::Var(_, ref name) if name == "y"));
        }
        other => panic!("Expected Dbg, got {other:?}"),
    }
}

#[test]
fn test_dbg_zero_arg_is_rejected() {
    let err = parse("dbg!()").expect_err("dbg!() should fail");
    assert!(err.message().contains("at least one argument"));
}

#[test]
fn test_intrinsic_dbg_decl_parses_in_std_module() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  Debug special form.
  """
  @intrinsic def dbg!(values: *$A) -> Unit
}"#,
        context,
    )
    .expect("intrinsic decl should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            match &body[0] {
                Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                    assert_eq!(intrinsic_name, "dbg!");
                    assert_eq!(signature.raw, "@intrinsic def dbg!(values: *$A) -> Unit");
                    assert!(attrs
                        .doc
                        .as_deref()
                        .is_some_and(|doc| doc.contains("Debug special form.")));
                }
                other => panic!("Expected IntrinsicDecl, got {other:?}"),
            }
        }
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_decl_preserves_source_text_verbatim() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  Debug special form.
  """
  @intrinsic def dbg!::<$A>(values: *$A) -> Unit
}"#,
        context,
    )
    .expect("intrinsic decl should parse");

    match &ast[0] {
        Ast::Defmod(_, _, body, _) => match &body[0] {
            Ast::IntrinsicDecl(_, _, signature, _) => {
                assert_eq!(
                    signature.raw,
                    "@intrinsic def dbg!::<$A>(values: *$A) -> Unit"
                );
            }
            other => panic!("Expected IntrinsicDecl, got {other:?}"),
        },
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_bind_decl_parses_in_std_module() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  Bind special form.
  """
  @intrinsic def =(pattern: $Pattern, value: $A) -> Unit
}"#,
        context,
    )
    .expect("intrinsic bind decl should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            match &body[0] {
                Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                    assert_eq!(intrinsic_name, "=");
                    assert_eq!(
                        signature.raw,
                        "@intrinsic def =(pattern: $Pattern, value: $A) -> Unit"
                    );
                    assert!(attrs
                        .doc
                        .as_deref()
                        .is_some_and(|doc| doc.contains("Bind special form.")));
                }
                other => panic!("Expected IntrinsicDecl, got {other:?}"),
            }
        }
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_safebind_decl_parses_in_std_module() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  SafeBind special form.
  """
  @intrinsic def =?(pattern: $Pattern, value: $A) -> Unit
}"#,
        context,
    )
    .expect("intrinsic safebind decl should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            match &body[0] {
                Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                    assert_eq!(intrinsic_name, "=?");
                    assert_eq!(
                        signature.raw,
                        "@intrinsic def =?(pattern: $Pattern, value: $A) -> Unit"
                    );
                    assert!(attrs
                        .doc
                        .as_deref()
                        .is_some_and(|doc| doc.contains("SafeBind special form.")));
                }
                other => panic!("Expected IntrinsicDecl, got {other:?}"),
            }
        }
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_match_decl_parses_in_std_module() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  Match special form.
  """
  @intrinsic def match(value: $A, arms: MatchArms<$A, $B>) -> $B
}"#,
        context,
    )
    .expect("intrinsic match decl should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            match &body[0] {
                Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                    assert_eq!(intrinsic_name, "match");
                    assert_eq!(
                        signature.raw,
                        "@intrinsic def match(value: $A, arms: MatchArms<$A, $B>) -> $B"
                    );
                    assert!(attrs
                        .doc
                        .as_deref()
                        .is_some_and(|doc| doc.contains("Match special form.")));
                }
                other => panic!("Expected IntrinsicDecl, got {other:?}"),
            }
        }
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_cond_decl_parses_in_std_module() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @doc """
  Cond special form.
  """
  @intrinsic def cond(clauses: CondClauses<$A>) -> $A
}"#,
        context,
    )
    .expect("intrinsic cond decl should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            match &body[0] {
                Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                    assert_eq!(intrinsic_name, "cond");
                    assert_eq!(
                        signature.raw,
                        "@intrinsic def cond(clauses: CondClauses<$A>) -> $A"
                    );
                    assert!(attrs
                        .doc
                        .as_deref()
                        .is_some_and(|doc| doc.contains("Cond special form.")));
                }
                other => panic!("Expected IntrinsicDecl, got {other:?}"),
            }
        }
        other => panic!("Expected Defmod, got {other:?}"),
    }
}

#[test]
fn test_do_intrinsic_decl_keeps_structured_validation_signature() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>
}"#,
        context,
    )
    .expect("canonical do intrinsic surface should parse");

    match &ast[0] {
        Ast::Defmod(_, _, body, _) => match &body[0] {
            Ast::IntrinsicDecl(_, name, signature, _) => {
                assert_eq!(name, "do");
                assert_eq!(signature.return_type_arguments.len(), 1);
                assert_eq!(signature.value_parameters.len(), 1);
                assert!(signature.return_type.is_some());
                assert_eq!(
                    signature.raw,
                    "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>"
                );
            }
            other => panic!("expected structured intrinsic declaration, got {other:?}"),
        },
        other => panic!("expected Bootstrap module, got {other:?}"),
    }
}

#[test]
fn test_intrinsic_bulk_update_decl_parses_in_std_module() {
    let mut context = ParserContext::project(0);
    context.parse_rules = ParseRules::permissive_for_tests();
    let ast = parse_with_context(
        r#"@builtin type Facet<$K, $S, $A, $T, $B>
impl Facet {
  @doc """
  Bulk update special form.
  """
  @intrinsic def bulk_update(source: $S, updates: BulkUpdateEntries<$S>) -> Result<$S>
}"#,
        context,
    )
    .expect("intrinsic bulk_update decl should parse");

    match &ast[0] {
        Ast::BuiltinTypeDecl(_, _, _) => match &ast[1] {
            Ast::ImplDef(_, name, _, body, _) => {
                assert_eq!(name, "Global::Facet");
                match &body[0] {
                    Ast::IntrinsicDecl(_, intrinsic_name, signature, attrs) => {
                        assert_eq!(intrinsic_name, "bulk_update");
                        assert!(signature.raw.contains(
                            "@intrinsic def bulk_update(source: $S, updates: BulkUpdateEntries<$S>) -> Result<$S>"
                        ));
                        assert!(attrs
                            .doc
                            .as_deref()
                            .is_some_and(|doc| doc.contains("Bulk update special form.")));
                    }
                    other => panic!("Expected IntrinsicDecl, got {other:?}"),
                }
            }
            other => panic!("Expected ImplDef, got {other:?}"),
        },
        other => panic!("Expected BuiltinTypeDecl, got {other:?}"),
    }
}

#[test]
fn test_facet_bulk_update_special_form_parses() {
    let ast = parse(
        r#"updated =? Facet::bulk_update(user) {
  name <- set("taro")
  score <- over_result({|score: Result<Int>| Ok(score)})
  address {
    country <- set("Tokyo")
  }
}"#,
    )
    .expect("bulk update should parse");

    match &ast[0] {
        Ast::SafeBind(_, AstPattern::Var(_, name), rhs, _) => {
            assert_eq!(name, "updated");
            match rhs.as_ref() {
                Ast::BulkUpdate(_, source, entries) => {
                    assert!(matches!(source.as_ref(), Ast::Var(_, name) if name == "user"));
                    assert_eq!(entries.len(), 3);
                    assert_eq!(
                        bulk_path_segments(&entries[0].path),
                        [FacetPathSegment::field("name")]
                    );
                    assert!(matches!(entries[0].kind, BulkUpdateEntryKind::Set(_)));
                    assert_eq!(
                        bulk_path_segments(&entries[1].path),
                        [FacetPathSegment::field("score")]
                    );
                    assert!(matches!(
                        entries[1].kind,
                        BulkUpdateEntryKind::OverResult(_)
                    ));
                    assert_eq!(
                        bulk_path_segments(&entries[2].path),
                        [FacetPathSegment::field("address")]
                    );
                    assert!(matches!(entries[2].kind, BulkUpdateEntryKind::Nested(_)));
                }
                other => panic!("Expected BulkUpdate, got {other:?}"),
            }
        }
        other => panic!("Expected SafeBind, got {other:?}"),
    }
}

#[test]
fn test_facet_bulk_update_rejects_commas_between_entries() {
    let err = parse(
        r#"updated =? Facet::bulk_update(user) {
  name <- set("taro"),
  age <- over({|age| Ok(age + 1)})
}"#,
    )
    .expect_err("commas should be rejected");

    assert!(!err.message().is_empty());
}

#[test]
fn test_facet_bulk_update_rejects_non_whitelisted_leaf_call() {
    let err = parse(
        r#"updated =? Facet::bulk_update(user) {
  name <- replace("taro")
}"#,
    )
    .expect_err("non-whitelisted leaf should be rejected");

    assert!(err
        .message()
        .contains("set(value), over(update_fun), over_result(update_fun)"));
    assert!(err.message().contains("case_set(payload)"));
}

#[test]
fn test_facet_bulk_update_rejects_qualified_facet_leaf_call() {
    let err = parse(
        r#"updated =? Facet::bulk_update(user) {
  name <- Facet::set("taro")
}"#,
    )
    .expect_err("qualified Facet leaf call should be rejected");

    assert!(!err.message().is_empty());
}

#[test]
fn test_safebind() {
    let ast = parse("num =? gen()").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, AstPattern::Var(_, name), rhs, _) => {
            assert_eq!(name, "num");
            assert!(matches!(rhs.as_ref(), Ast::App(_, _, _)));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_assignment_operator_is_non_associative() {
    let err = parse("x = y =? z").expect_err("Expected parse error");
    assert!(err.message().contains("non-associative"));
}

#[test]
fn test_function_call() {
    let ast = parse("print(to_string(num))").unwrap();
    match &ast[0] {
        Ast::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "print"));
            assert_eq!(args.len(), 1);
            assert!(matches!(args[0], RecordLitArg::Positional(_)));
        }
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_function_call_named_args() {
    let ast = parse("add(y: 2, x: 1)").unwrap();
    match &ast[0] {
        Ast::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "add"));
            assert_eq!(args.len(), 2);
            assert!(matches!(&args[0], RecordLitArg::Named(n, _) if n == "y"));
            assert!(matches!(&args[1], RecordLitArg::Named(n, _) if n == "x"));
        }
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_function_call_accepts_trailing_block_arg() {
    let ast = parse("if_then(True) { num = 10; num }").expect("trailing block call should parse");
    match &ast[0] {
        Ast::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "if_then"));
            assert_eq!(args.len(), 2);
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::ConstructorCall(_, name, args)) if name == "Boolean::True" && args.is_empty()
            ));
            assert!(matches!(
                &args[1],
                RecordLitArg::Positional(Ast::Closure(_, params, body))
                    if params.is_empty()
                    && matches!(
                        body.as_ref(),
                        Ast::Block(_, stmts)
                            if matches!(stmts.as_slice(), [Ast::Semi(_, _), Ast::Var(_, name)] if name == "num")
                    )
            ));
        }
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_zero_arg_call_accepts_trailing_block_arg() {
    let ast = parse("run() { print(\"x\") }").expect("zero-arg trailing block call should parse");
    match &ast[0] {
        Ast::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "run"));
            assert_eq!(args.len(), 1);
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::Closure(_, params, body))
                    if params.is_empty()
                    && matches!(body.as_ref(), Ast::App(_, _, inner_args) if inner_args.len() == 1)
            ));
        }
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_brace_expression_is_zero_arg_closure() {
    let ast = parse("x = { tmp = 10; tmp * 10 }").expect("brace expression should parse");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Closure(_, params, body) => {
                assert!(params.is_empty());
                assert!(matches!(
                    body.as_ref(),
                    Ast::Block(_, stmts)
                        if matches!(stmts.as_slice(), [Ast::Semi(_, _), Ast::BinOp(_, BinOp::Mul, _, _)])
                ));
            }
            other => panic!("Expected zero-arg Closure, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_test_dsl_trailing_block_uses_zero_arg_closure() {
    let ast = parse(r#"test("suite") { it("case") { assert_true(True) } }"#)
        .expect("test DSL trailing block should parse");
    match &ast[0] {
        Ast::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "test"));
            assert_eq!(args.len(), 2);
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::Lit(_, Lit::Str(value))) if value == "suite"
            ));
            assert!(matches!(
                &args[1],
                RecordLitArg::Positional(Ast::Closure(_, params, _)) if params.is_empty()
            ));
        }
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_trailing_block_rejects_named_args() {
    let err = parse("add(x: 1) { 2 }").expect_err("named args with trailing block should fail");
    assert!(err
        .message()
        .contains("Trailing block sugar cannot follow named arguments"));
}

#[test]
fn test_constructor_call_rejects_trailing_block_arg() {
    let err = parse("Foo(1) { 2 }").expect_err("constructor call with trailing block should fail");
    assert!(err
        .message()
        .contains("Trailing block sugar is not supported for constructor calls"));

    let err = parse("Foo() { 2 }")
        .expect_err("zero-arg constructor call with trailing block should fail");
    assert!(err
        .message()
        .contains("Trailing block sugar is not supported for constructor calls"));
}

#[test]
fn test_match_scrutinee_does_not_consume_arm_block_as_trailing_call_arg() {
    let ast = parse("match noop() { _ => 1 }").expect("match scrutinee should parse");
    match &ast[0] {
        Ast::Match(_, scrutinee, arms) => {
            assert!(matches!(scrutinee.as_ref(), Ast::App(_, _, args) if args.is_empty()));
            assert_eq!(arms.len(), 1);
        }
        _ => panic!("Expected Match"),
    }
}

#[test]
fn test_zero_arg_call() {
    let ast = parse("x = noop()").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(func.as_ref(), Ast::Var(_, ref n) if n == "noop"));
                assert!(args.is_empty());
            }
            _ => panic!("Expected zero-arg App"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_function_def() {
    let ast = parse(
        r#"def add(x: Int, y: Int) -> Int { x + y }
def noop() {()}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Def(_, name, _, params, ret_ty, _, body, attrs) => {
            assert_eq!(name, "add");
            assert_eq!(params.len(), 2);
            assert_eq!(attrs, &DeclAttrs::default());
            assert!(matches!(ret_ty, Some(AstTy::Named(_, ty)) if ty == "Int"));
            assert!(
                matches!(body.as_ref(), Ast::Block(_, stmts) if matches!(stmts.as_slice(), [Ast::BinOp(_, BinOp::Add, _, _)]))
            );
        }
        _ => panic!("Expected Def"),
    }
    match &ast[1] {
        Ast::Def(_, name, _, params, ret_ty, _, body, attrs) => {
            assert_eq!(name, "noop");
            assert_eq!(params.len(), 0);
            assert_eq!(attrs, &DeclAttrs::default());
            assert!(ret_ty.is_none());
            assert!(
                matches!(body.as_ref(), Ast::Block(_, stmts) if matches!(stmts.as_slice(), [Ast::Lit(_, Lit::Unit)]))
            );
        }
        _ => panic!("Expected Def"),
    }
}

#[test]
fn test_impl_parses_and_keeps_methods() {
    let ast = parse_with_context(
        r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name: name, age: age }
  }

  def normalize(self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("impl should parse");

    let impl_node = ast
        .iter()
        .find(|node| matches!(node, Ast::ImplDef(_, _, _, _, _)))
        .expect("expected impl node");
    match impl_node {
        Ast::ImplDef(_, target, _, methods, attrs) => {
            assert_eq!(target, "Global::User");
            assert_eq!(attrs, &DeclAttrs::default());
            assert_eq!(methods.len(), 2);
            assert!(matches!(
                &methods[0],
                Ast::Def(_, name, _, _, Some(AstTy::Named(_, ret)), _, _, _)
                    if name == "new" && ret == "Self"
            ));
            assert!(matches!(
                &methods[1],
                Ast::Def(_, name, _, _, Some(AstTy::Named(_, ret)), _, _, _)
                    if name == "normalize" && ret == "Self"
            ));
        }
        _ => panic!("Expected ImplDef"),
    }
}

#[test]
fn test_impl_parses_and_keeps_builtin_methods() {
    let ast = parse_with_context(
        r#"@builtin type Int

impl Int {
  @doc """Builtin int helper."""
  @builtin def safe_mod(a: Int, b: Int) -> Result<Int, ZeroDivisionError>
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("builtin impl method should parse");

    let impl_node = ast
        .iter()
        .find(|node| matches!(node, Ast::ImplDef(_, _, _, _, _)))
        .expect("expected impl node");
    match impl_node {
        Ast::ImplDef(_, target, _, methods, _) => {
            assert_eq!(target, "Global::Int");
            assert!(matches!(
                methods.as_slice(),
                [Ast::BuiltinDecl(_, name, _, _, Some(AstTy::Generic(_, ret, _)), _, attrs)]
                    if name == "safe_mod"
                    && ret == "Result"
                    && attrs.doc.as_deref() == Some("Builtin int helper.")
            ));
        }
        _ => panic!("Expected ImplDef"),
    }
}

#[test]
fn test_trait_def_parses_method_signatures() {
    let ast = parse_with_context(
        r#"deftrait Describable {
  def add(self: Self, rhs: Self) -> Self
  def abs(self: Self) -> Self
}"#,
        ParserContext::module(1, None),
    )
    .expect("trait should parse");

    match ast.as_slice() {
        [Ast::TraitDef(_, name, type_params, _, methods, attrs)] => {
            assert_eq!(name, "Describable");
            assert_eq!(attrs, &DeclAttrs::default());
            assert!(type_params.is_empty());
            assert_eq!(methods.len(), 2);
            assert_eq!(methods[0].name, "add");
            assert_eq!(methods[0].value_parameters.len(), 2);
            assert!(methods[0].type_params.is_empty());
            assert!(
                matches!(methods[0].value_parameters[0].ty, AstTy::Named(_, ref ty) if ty == "Self")
            );
            assert!(
                matches!(methods[0].value_parameters[1].ty, AstTy::Named(_, ref ty) if ty == "Self")
            );
            assert!(matches!(methods[0].ret_ty, AstTy::Named(_, ref ty) if ty == "Self"));
            assert_eq!(methods[1].name, "abs");
            assert_eq!(methods[1].value_parameters.len(), 1);
        }
        _ => panic!("Expected TraitDef"),
    }
}

#[test]
fn test_trait_def_parses_method_docs_and_optional_default_bodies() {
    let ast = parse_with_context(
        r#"deftrait Describable {
  @doc """Delegates to abs."""
  def magnitude(self: Self) -> Self {
    abs(self)
  }

  def abs(self: Self) -> Self
}"#,
        ParserContext::module(1, None),
    )
    .expect("trait with documented default method should parse");

    match ast.as_slice() {
        [Ast::TraitDef(_, name, _, _, methods, _)] => {
            assert_eq!(name, "Describable");
            assert_eq!(methods.len(), 2);
            assert_eq!(methods[0].name, "magnitude");
            assert_eq!(methods[0].attrs.doc.as_deref(), Some("Delegates to abs."));
            assert!(
                matches!(methods[0].body.as_deref(), Some(Ast::Block(_, stmts)) if stmts.len() == 1)
            );
            assert_eq!(methods[1].name, "abs");
            assert_eq!(methods[1].attrs, DeclAttrs::default());
            assert!(methods[1].body.is_none());
        }
        _ => panic!("Expected TraitDef"),
    }
}

#[test]
fn test_trait_impl_parses_and_keeps_methods() {
    let ast = parse_with_context(
        r#"impl Describable for Int {
  def add(self: Self, rhs: Self) -> Self {
    self + rhs
  }

  def abs(self: Self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("trait impl should parse");

    match ast.as_slice() {
        [Ast::TraitImplDef(
            _,
            trait_name,
            trait_args,
            AstTy::Named(_, target),
            _,
            methods,
            attrs,
        )] => {
            assert_eq!(trait_name, "Describable");
            assert!(trait_args.is_empty());
            assert_eq!(target, "Global::Int");
            assert_eq!(attrs, &DeclAttrs::default());
            assert_eq!(methods.len(), 2);
            assert!(matches!(
                &methods[0],
                Ast::Def(_, name, _, _, Some(AstTy::Named(_, ret)), _, _, _)
                    if name == "add" && ret == "Self"
            ));
            assert!(matches!(
                &methods[1],
                Ast::Def(_, name, _, _, Some(AstTy::Named(_, ret)), _, _, _)
                    if name == "abs" && ret == "Self"
            ));
        }
        _ => panic!("Expected TraitImplDef"),
    }
}

#[test]
fn test_trait_impl_accepts_builtin_def_method() {
    let ast = parse_with_context(
        r#"impl Add for Int {
  @builtin def add(self: Self, rhs: Self) -> Self
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("trait impl builtin method should parse");

    match ast.as_slice() {
        [Ast::TraitImplDef(_, trait_name, _, AstTy::Named(_, target), _, methods, _)] => {
            assert_eq!(trait_name, "Add");
            assert_eq!(target, "Global::Int");
            assert!(matches!(
                methods.as_slice(),
                [Ast::BuiltinDecl(_, name, _, _, Some(AstTy::Named(_, ret)), _, _)]
                    if name == "add" && ret == "Self"
            ));
        }
        _ => panic!("Expected TraitImplDef"),
    }
}

#[test]
fn test_trait_impl_rejects_builtin_defp_method() {
    let err = parse_with_context(
        r#"impl Add for Int {
  @builtin defp add(self: Self, rhs: Self) -> Self
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect_err("trait impl builtin private method should be rejected");
    assert!(err
        .message()
        .contains("@builtin is not allowed before `defp` impl members"));
}

#[test]
fn test_doc_attributes_parse_for_trait_and_trait_impl_decls() {
    let ast = parse_with_context(
        r#"@doc """Trait docs."""
deftrait Describable {
  def add(self: Self, rhs: Self) -> Self
}

@doc """Impl docs."""
impl Show for User {
  def to_string(self: Self) -> String {
    "user"
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("annotated trait and trait impl should parse");

    match &ast[0] {
        Ast::TraitDef(_, name, _, _, _, attrs) => {
            assert_eq!(name, "Describable");
            assert_eq!(attrs.doc.as_deref(), Some("Trait docs."));
        }
        _ => panic!("Expected TraitDef"),
    }

    match &ast[1] {
        Ast::TraitImplDef(_, trait_name, _, target, _, _, attrs) => {
            assert_eq!(trait_name, "Show");
            assert!(matches!(target, AstTy::Named(_, name) if name == "Global::User"));
            assert_eq!(attrs.doc.as_deref(), Some("Impl docs."));
        }
        _ => panic!("Expected TraitImplDef"),
    }
}

#[test]
fn test_doc_attribute_rejected_for_impl_block() {
    let err = parse_with_context(
        r#"@doc """Impl docs."""
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@doc on impl block should be rejected");

    assert!(err
        .message()
        .contains("@doc is not allowed before `impl Type`; attach docs to the type declaration, defagent, or impl members"));
}

#[test]
fn test_hidden_attribute_rejected_for_impl_block() {
    let err = parse_with_context(
        r#"@hidden
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("@hidden on impl block should be rejected");

    assert!(err
        .message()
        .contains("@hidden is only allowed together with @builtin in standard/internal source"));
}

#[test]
fn test_autoimport_attribute_allowed_for_impl_block() {
    let ast = parse_with_context(
        r#"@autoimport
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("@autoimport on impl block should parse");

    match &ast[0] {
        Ast::ImplDef(_, target, _, _, attrs) => {
            assert_eq!(target, "Global::User");
            assert!(attrs.auto_import);
        }
        other => panic!("Expected ImplDef, got {other:?}"),
    }
}

#[test]
fn test_removed_entrypoint_annotation_is_rejected() {
    let err = parse_with_context(
        r#"@entrypoint
def main() -> Int { 0 }"#,
        ParserContext::project(0),
    )
    .expect_err("@entrypoint should be rejected");

    assert!(err.message().contains("@entrypoint has been removed"));
}

#[test]
fn test_removed_test_annotation_is_rejected() {
    let err = parse_with_context(
        r#"@test
def sample() -> Int { 0 }"#,
        ParserContext::project(0),
    )
    .expect_err("@test should be rejected");

    assert!(err.message().contains("@test has been removed"));
}

#[test]
fn test_agent_handler_marker_is_rejected_outside_defagent() {
    let err = parse_with_context(
        r#"@init
def init() -> Int { 0 }"#,
        ParserContext::module(1, None),
    )
    .expect_err("@init outside defagent should be rejected");

    assert!(err
        .message()
        .contains("@init/@get/@set are only allowed on def declarations inside defagent"));
}

#[test]
fn test_doc_attributes_parse_for_impl_methods() {
    let ast = parse_with_context(
        r#"defstruct User {
  name: String,
}

impl User {
  @doc """Construct a user."""
  def new(name: String) -> Self {
    User { name: name }
  }

  @doc """Normalize the user."""
  def normalize(self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("annotated impl methods should parse");

    match &ast[1] {
        Ast::ImplDef(_, target, _, methods, _) => {
            assert_eq!(target, "Global::User");
            assert_eq!(methods.len(), 2);
            match &methods[0] {
                Ast::Def(_, name, _, _, _, _, _, attrs) => {
                    assert_eq!(name, "new");
                    assert_eq!(attrs.doc.as_deref(), Some("Construct a user."));
                }
                _ => panic!("Expected impl def"),
            }
            match &methods[1] {
                Ast::Def(_, name, _, _, _, _, _, attrs) => {
                    assert_eq!(name, "normalize");
                    assert_eq!(attrs.doc.as_deref(), Some("Normalize the user."));
                }
                _ => panic!("Expected impl def"),
            }
        }
        _ => panic!("Expected ImplDef"),
    }
}

#[test]
fn test_struct_literal_field_shorthand_parses() {
    let ast = parse_with_context(
        r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name, age }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("impl with struct shorthand should parse");

    let impl_node = ast
        .iter()
        .find(|node| matches!(node, Ast::ImplDef(_, _, _, _, _)))
        .expect("expected impl node");
    match impl_node {
        Ast::ImplDef(_, _, _, methods, _) => match &methods[0] {
            Ast::Def(_, _, _, _, _, _, body, _) => match body.as_ref() {
                Ast::Block(_, stmts) => match &stmts[0] {
                    Ast::StructLit(_, _, fields) => {
                        assert!(matches!(
                            fields.as_slice(),
                            [
                                StructLitField::Shorthand(name),
                                StructLitField::Shorthand(age)
                            ] if name == "name" && age == "age"
                        ));
                    }
                    other => panic!("Expected StructLit, got {:?}", other),
                },
                other => panic!("Expected block body, got {:?}", other),
            },
            other => panic!("Expected Def, got {:?}", other),
        },
        other => panic!("Expected ImplDef, got {:?}", other),
    }
}

#[test]
fn test_struct_literal_field_shorthand_mixed_with_explicit_parses() {
    let ast = parse_with_context(
        r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def update(self, name: String, next_age: Int) -> Self {
    User { name, age: next_age }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("mixed struct shorthand should parse");

    let impl_node = ast
        .iter()
        .find(|node| matches!(node, Ast::ImplDef(_, _, _, _, _)))
        .expect("expected impl node");
    match impl_node {
        Ast::ImplDef(_, _, _, methods, _) => match &methods[0] {
            Ast::Def(_, _, _, _, _, _, body, _) => match body.as_ref() {
                Ast::Block(_, stmts) => match &stmts[0] {
                    Ast::StructLit(_, _, fields) => {
                        assert!(matches!(
                            fields.as_slice(),
                            [
                                StructLitField::Shorthand(name),
                                StructLitField::Explicit(age, Ast::Var(_, next_age))
                            ] if name == "name" && age == "age" && next_age == "next_age"
                        ));
                    }
                    other => panic!("Expected StructLit, got {:?}", other),
                },
                other => panic!("Expected block body, got {:?}", other),
            },
            other => panic!("Expected Def, got {:?}", other),
        },
        other => panic!("Expected ImplDef, got {:?}", other),
    }
}

#[test]
fn test_doc_attributes_parse_for_trait_impl_methods() {
    let ast = parse_with_context(
        r#"impl Show for Int {
  @doc """Format the integer."""
  def to_string(self: Self) -> String {
    inspect(self)
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("annotated trait impl methods should parse");

    match ast.as_slice() {
        [Ast::TraitImplDef(_, trait_name, _, AstTy::Named(_, target), _, methods, _)] => {
            assert_eq!(trait_name, "Show");
            assert_eq!(target, "Global::Int");
            match &methods[0] {
                Ast::Def(_, name, _, _, _, _, _, attrs) => {
                    assert_eq!(name, "to_string");
                    assert_eq!(attrs.doc.as_deref(), Some("Format the integer."));
                }
                _ => panic!("Expected trait impl def"),
            }
        }
        _ => panic!("Expected TraitImplDef"),
    }
}

#[test]
fn test_function_def_rejects_explicit_type_params() {
    let err = parse("def add<$N: Describable>(x: $N, y: $N) -> $N { x }")
        .expect_err("regular definitions must not accept explicit type parameters");
    assert!(err.to_string().contains("Expected"));
}

#[test]
fn test_defmod_rejects_type_params() {
    let err = parse("defmod MyFun<$A> { def id(value: $A) -> $A { value } }")
        .expect_err("defmod must not accept type parameters");
    assert!(!err.to_string().is_empty());
}

#[test]
fn test_trait_def_parses_head_type_params() {
    let ast = parse_with_context(
        r#"deftrait Convert<$To> {
  def to::<$To>(self: Self) -> $To
}"#,
        ParserContext::module(1, None),
    )
    .expect("generic trait should parse");

    match ast.as_slice() {
        [Ast::TraitDef(_, name, type_params, _, methods, _)] => {
            assert_eq!(name, "Convert");
            assert_eq!(type_params.len(), 1);
            assert_eq!(type_params[0].name, "$To");
            assert_eq!(methods.len(), 1);
            assert_eq!(methods[0].value_parameters.len(), 1);
        }
        _ => panic!("Expected TraitDef"),
    }
}

#[test]
fn test_trait_impl_parses_trait_type_args() {
    let ast = parse_with_context(
        r#"impl Convert<String> for Int {
  def to::<String>(self: Self) -> String {
    inspect(self)
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("generic trait impl should parse");

    match ast.as_slice() {
        [Ast::TraitImplDef(
            _,
            trait_name,
            trait_args,
            AstTy::Named(_, target),
            _,
            methods,
            attrs,
        )] => {
            assert_eq!(trait_name, "Convert");
            assert!(matches!(trait_args.as_slice(), [AstTy::Named(_, name)] if name == "String"));
            assert_eq!(target, "Global::Int");
            assert_eq!(attrs, &DeclAttrs::default());
            assert_eq!(methods.len(), 1);
        }
        _ => panic!("Expected TraitImplDef"),
    }
}

#[test]
fn test_function_def_rejects_impl_trait_parameter() {
    let err = parse("def abs(x: impl Describable) -> Int { 0 }")
        .expect_err("anonymous impl Trait parameters must be rejected");
    assert!(err.to_string().contains("Anonymous `impl Trait` types"));
}

#[test]
fn test_impl_target_rejects_impl_trait_components() {
    let err = parse("impl Compare for (impl Compare, impl Conpare) { }")
        .expect_err("anonymous impl Trait target components must be rejected");
    assert!(err.to_string().contains("Anonymous `impl Trait` types"));
}

#[test]
fn test_return_position_impl_trait_is_rejected() {
    let err = parse("def bad(x: Int) -> impl Describable { x }")
        .expect_err("return-position impl Trait should be rejected");
    assert!(err
        .message()
        .contains("Anonymous `impl Trait` types are not supported"));
}

#[test]
fn test_function_where_clause_parses_multiple_bounds() {
    let ast = parse(
        r#"def append(left: $A, right: $A) -> $A
where
  $A: Eq + Concat
{
  left
}"#,
    )
    .expect("function where clause should parse");

    let [Ast::Def(_, _, _, _, _, Some(clause), _, _)] = ast.as_slice() else {
        panic!("expected function with where clause");
    };
    assert_eq!(clause.constraints.len(), 1);
    let constraint = &clause.constraints[0];
    assert!(matches!(&constraint.subject, AstTy::Named(_, name) if name == "$A"));
    assert!(matches!(
        constraint.bounds.as_slice(),
        [WhereConstraintRhs::Trait(_, eq), WhereConstraintRhs::Trait(_, concat)]
            if eq.ends_with("Eq") && concat.ends_with("Concat")
    ));
}

#[test]
fn test_where_trait_rhs_is_bare_in_every_declaration_context() {
    let cases = [
        (
            "function",
            "def use_it(value: $A) -> $A where $A: Convert<$B> { value }",
        ),
        (
            "trait definition",
            "deftrait Child where Self: Parent<$A> { def use_it(self: Self) -> Self }",
        ),
        (
            "trait method",
            "deftrait Child { def use_it(value: $A) -> $A where $A: Convert<$B> }",
        ),
        (
            "trait implementation",
            "impl Child for Box<$A> where $A: Convert<$B> { def use_it(self: Self) -> Self { self } }",
        ),
        (
            "inherent implementation method",
            "impl Box { def use_it(self: Self) -> Self where Self: Convert<$B> { self } }",
        ),
    ];

    for (context, source) in cases {
        let err = parse(source).expect_err(&format!(
            "parameterized trait RHS must be rejected in {context}"
        ));
        assert!(err.message().contains("where"), "{context}: {err}");
    }
}

#[test]
fn test_type_constructor_where_rhs_is_limited_to_deftrait_self() {
    let cases = [
        (
            "ordinary function subject",
            "def use_it(value: $A) -> $A where $A: Type<$B> { value }",
        ),
        (
            "ordinary function Self subject",
            "def use_it(value: $A) -> $A where Self: Type<$B> { value }",
        ),
        (
            "trait definition non-Self subject",
            "deftrait Bad where $A: Type<$B> { def use_it(self: Self) -> Self }",
        ),
        (
            "trait method",
            "deftrait Bad { def use_it(value: $A) -> $A where Self: Type<$B> }",
        ),
        (
            "trait implementation",
            "impl Bad for Box<$A> where Self: Type<$B> { def use_it(self: Self) -> Self { self } }",
        ),
        (
            "inherent implementation method",
            "impl Box { def use_it(self: Self) -> Self where Self: Type<$B> { self } }",
        ),
    ];

    for (context, source) in cases {
        let err = parse(source).expect_err(&format!("Type RHS must be rejected in {context}"));
        assert!(!err.message().is_empty(), "{context}: {err}");
    }
}

#[test]
fn test_type_constructor_where_rhs_and_trait_slot_remain_distinct() {
    let ast = parse(
        r#"deftrait Functor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

impl Functor for Result<$T>
where
  $T: Functor.$A
{
  def fmap(self: Self) -> Self { self }
}"#,
    )
    .expect("shape and slot-map RHS forms should parse");

    assert!(matches!(
        &ast[0],
        Ast::TraitDef(_, _, _, Some(WhereClause { constraints, .. }), _, _)
            if matches!(constraints[0].bounds.as_slice(), [WhereConstraintRhs::TypeConstructor(_, _)])
    ));
    assert!(matches!(
        &ast[1],
        Ast::TraitImplDef(_, _, _, _, Some(WhereClause { constraints, .. }), _, _)
            if matches!(constraints[0].bounds.as_slice(), [WhereConstraintRhs::TraitSlot(_, _, _)])
    ));
}

#[test]
fn test_trait_slot_mapping_is_limited_to_trait_impl_where_blocks() {
    let cases = [
        (
            "ordinary function",
            "def use_it(value: $A) -> $A where $A: Functor.$A { value }",
        ),
        (
            "trait definition",
            "deftrait Bad where Self: Functor.$A { def use_it(self: Self) -> Self }",
        ),
        (
            "trait method",
            "deftrait Bad { def use_it(value: $A) -> $A where $A: Functor.$A }",
        ),
        (
            "inherent implementation method",
            "impl Box { def use_it(self: Self) -> Self where Self: Functor.$A { self } }",
        ),
    ];

    for (context, source) in cases {
        let err = parse(source).expect_err(&format!(
            "constructor slot mappings must be rejected in {context}"
        ));
        assert!(
            err.message().contains("trait implementation where clause"),
            "{context}: {err}"
        );
    }
}

#[test]
fn test_marker_names_cannot_be_value_owner_paths() {
    for source in [
        "Self::f()",
        "Type::f()",
        "`Self::f`()",
        "`Type::f`()",
        "capture = &`Self::f`",
        "capture = &`Type::f`",
    ] {
        let err = parse(source).expect_err("marker owner path must be rejected");
        assert!(err.message().contains("owner"), "{err}");
    }
}

#[test]
fn test_tolerant_parser_rejects_quoted_marker_owner_paths() {
    for source in [
        "`Self::f`()",
        "`Type::f`()",
        "capture = &`Self::f`",
        "capture = &`Type::f`",
    ] {
        let result = parse_tolerant_with_context(source, ParserContext::default(), None);
        assert!(
            result
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.error.message().contains("owner")),
            "quoted marker owner path must produce a tolerant diagnostic: {source}"
        );
    }
}

#[test]
fn test_constructor_application_parser_preserves_type_identity_boundaries() {
    let allowed = [
        "def map(value: Applicative<$A>) -> Applicative<$B> { value }",
        "deftrait Mapper { def map(value: Applicative<$A>) -> Applicative<$B> }",
    ];
    for source in allowed {
        parse(source)
            .expect("direct normal-function and trait-method signature application should parse");
    }

    // `Applicative` is syntactically indistinguishable from a concrete generic
    // owner such as `List`. Spire therefore preserves these forms for the
    // identity-aware resolver/checker, which rejects constructor-trait use in
    // the non-direct positions below.
    let identity_dependent = [
        "value: Applicative<$A> = value",
        "defstruct Holder { value: Applicative<$A> }",
        "defrecord Holder(value: Applicative<$A>)",
        "deferror Holder(value: Applicative<$A>) { |value: Applicative<$A>| Self(message: \"holder\", value: value) }",
        "callback = {|value: Applicative<$A>| value}",
        "def nested(value: List<Applicative<$A>>) -> Int { 0 }",
        "def paired(value: (Applicative<$A>, Int)) -> Int { 0 }",
    ];
    for source in identity_dependent {
        parse(source).expect("parser must leave constructor-trait identity checks downstream");
    }
}

#[test]
fn test_self_application_is_allowed_recursively_in_trait_and_impl_signatures() {
    let allowed = [
        "deftrait Functor { def fmap(value: Self<$A>) -> Self<$B> }",
        "impl Box { def map(self: Self<$A>) -> Self<$B> { self } }",
        r#"deftrait Monad {
  def bind(self: Self<$A>, mapper: ($A -> Self<$B>)) -> Self<$B>
}"#,
        "impl Box { def map(mapper: ($A -> Self<$B>)) -> List<Self<$B>> { self } }",
    ];
    for source in allowed {
        parse(source).expect("Self substitution should parse throughout trait or impl signatures");
    }

    let forbidden = [
        "impl Box { def map(self: Self) -> Self { value: Self<$A> = self; value } }",
        "impl Box { def map(self: Self) -> Self { callback = {|value: Self<$A>| value}; self } }",
        "defstruct Holder { value: Self<$A> }",
    ];
    for source in forbidden {
        let err = parse(source).expect_err("Self application outside a signature must be rejected");
        assert!(err.message().contains("Self"), "{err}");
    }
}

#[test]
fn test_trait_where_type_constructor_and_self_application_parse() {
    let ast = parse(
        r#"deftrait Functor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
    )
    .expect("type-constructor trait should parse");

    let [Ast::TraitDef(_, _, _, Some(clause), methods, _)] = ast.as_slice() else {
        panic!("expected trait with where clause");
    };
    assert!(matches!(
        clause.constraints[0].bounds.as_slice(),
        [WhereConstraintRhs::TypeConstructor(_, slots)]
            if matches!(slots.as_slice(), [AstTy::Named(_, name)] if name == "$A")
    ));
    assert!(matches!(
        &methods[0].value_parameters[0].ty,
        AstTy::Generic(_, name, args)
            if name == "Self" && matches!(args.as_slice(), [AstTy::Named(_, arg)] if arg == "$A")
    ));
    assert!(matches!(
        &methods[0].ret_ty,
        AstTy::Generic(_, name, args)
            if name == "Self" && matches!(args.as_slice(), [AstTy::Named(_, arg)] if arg == "$B")
    ));
}

#[test]
fn test_trait_impl_where_slot_projection_is_distinct() {
    let ast = parse(
        r#"impl Functor for Result<$T>
where
  $T: Functor.$A
{
  def fmap(self: Self) -> Self { self }
}"#,
    )
    .expect("trait slot projection should parse");

    let [Ast::TraitImplDef(_, _, _, _, Some(clause), _, _)] = ast.as_slice() else {
        panic!("expected trait impl with where clause");
    };
    assert!(matches!(
        clause.constraints[0].bounds.as_slice(),
        [WhereConstraintRhs::TraitSlot(_, trait_name, slot)]
            if trait_name.ends_with("Functor") && slot == "$A"
    ));
}

#[test]
fn test_trait_method_where_clause_parses() {
    let ast = parse(
        r#"deftrait Default {
  def make() -> $A
  where
    $A: Default
}
"#,
    )
    .expect("trait method where clause should parse");

    let [Ast::TraitDef(_, _, _, _, methods, _)] = ast.as_slice() else {
        panic!("expected trait");
    };
    assert!(methods[0].where_clause.is_some());
}

#[test]
fn test_where_type_constructor_requires_a_slot() {
    let err = parse("deftrait Bad where Self: Type<> { def make() -> Self }")
        .expect_err("empty Type constraint should be rejected");
    assert!(err.message().contains("at least one constructor slot"));
}

#[test]
fn test_impl_rejects_self_not_first_param() {
    let err = parse_with_context(
        r#"defstruct User {
  name: String,
}

impl User {
  def bad(x: Int, self: Self) -> Self {
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("self after first parameter must fail");
    assert!(err
        .message()
        .contains("`self` is only allowed as the first parameter of impl methods"));
}

#[test]
fn test_impl_allows_self_rebinding_syntax() {
    let ast = parse_with_context(
        r#"defstruct User {
  name: String,
}

impl User {
  def bad(self) -> Self {
    self = self
    self
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("self rebinding should be parsed");
    assert!(ast
        .iter()
        .any(|node| matches!(node, Ast::ImplDef(_, _, _, _, _))));
}

#[test]
fn test_defmod_rejects_self_and_self_type() {
    let err = parse(
        r#"defmod UserTools {
  def bad(self: Int) -> Int { self }
}"#,
    )
    .expect_err("defmod must reject `self`");
    assert!(err
        .message()
        .contains("`self` is only allowed as the first parameter of impl methods"));

    let err = parse(
        r#"defmod UserTools {
  def bad(x: Self) -> Int { 1 }
}"#,
    )
    .expect_err("defmod must reject `Self`");
    assert!(err
        .message()
        .contains("`Self` can only be used inside trait or impl declarations"));
}

#[test]
fn test_defmod_rejects_matcharms_builtin_type_name() {
    let err = parse("defmod MatchArms { def ok() -> Int { 1 } }")
        .expect_err("builtin clause block type name should be reserved");
    assert!(err
        .message()
        .contains("Module name `MatchArms` is reserved by a canonical builtin type declaration"));
}

#[test]
fn test_defmod_rejects_builtin_special_variant_owner_name() {
    let err = parse("defmod Ok { def ok() -> Int { 1 } }")
        .expect_err("builtin-special variant alias should be reserved as an owner");
    assert!(err
        .message()
        .contains("Module name `Ok` is reserved for canonical enum variant aliases"));

    let err = parse("defmod Auth::Err { def ok() -> Int { 1 } }")
        .expect_err("builtin-special variant alias should be reserved as a qualified owner tail");
    assert!(err
        .message()
        .contains("Module name `Err` is reserved for canonical enum variant aliases"));

    let err = parse("defmod True { def ok() -> Int { 1 } }")
        .expect_err("Boolean variant alias should be reserved as an owner");
    assert!(err
        .message()
        .contains("Module name `True` is reserved for canonical enum variant aliases"));
}

#[test]
fn test_builtin_decl() {
    let ast = parse_with_context(
        "@builtin def to_string(a: $A) -> String",
        ParserContext::module(1, Some("Bootstrap".into())).with_rules(ParseRules::std_module()),
    )
    .expect("std module should accept builtin declarations");
    match &ast[0] {
        Ast::BuiltinDecl(_, name, _, params, ret_ty, _, attrs) => {
            assert_eq!(name, "to_string");
            assert_eq!(params.len(), 1);
            assert_eq!(
                attrs,
                &DeclAttrs {
                    builtin: true,
                    ..DeclAttrs::default()
                }
            );
            assert!(matches!(
                params[0].ty,
                AstTy::Named(_, ref name) if name == "$A"
            ));
            assert!(matches!(ret_ty, Some(AstTy::Named(_, ty)) if ty == "String"));
        }
        _ => panic!("Expected BuiltinDecl"),
    }
}

#[test]
fn test_builtin_decl_accepts_where_clause() {
    let ast = parse_with_context(
        "@builtin def group_count(values: List<$A>) -> List<($A, Int)>\nwhere\n  $A: Eq\n@doc \"\"\"next\"\"\"\n@builtin def zip(left: List<$A>, right: List<$B>) -> List<($A, $B)>",
        ParserContext::module(1, Some("List".into())).with_rules(ParseRules::std_module()),
    )
    .expect("constrained builtin declarations should parse");
    let [Ast::BuiltinDecl(_, _, _, _, _, Some(clause), _), Ast::BuiltinDecl(..)] = ast.as_slice()
    else {
        panic!("expected constrained builtin followed by builtin declaration");
    };
    assert_eq!(clause.constraints.len(), 1);
}

#[test]
fn test_builtin_type_decl() {
    let ast = parse_with_context(
        "@builtin\ntype Int",
        ParserContext::module(1, Some("Bootstrap".into())).with_rules(ParseRules::std_module()),
    )
    .expect("std module should accept builtin type declarations");
    assert!(matches!(
        ast.as_slice(),
        [Ast::BuiltinTypeDecl(_, BuiltinTypeHead { name, params, .. }, attrs)]
            if name == "Int"
                && params.is_empty()
                && attrs == &DeclAttrs {
                    builtin: true,
                    ..DeclAttrs::default()
                }
    ));
}

#[test]
fn facet_path_kind_declarations_are_std_only_and_preserve_alias_members() {
    let ast = parse_with_context(
        "@FacetPathKind Type ReadablePath = InfallibleStructural | VariantPath",
        ParserContext::module(1, Some("Facet".into())).with_rules(ParseRules::std_module()),
    )
    .expect("std Facet kind declaration should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::BuiltinTypeDecl(_, BuiltinTypeHead { name, params, .. }, DeclAttrs { facet_path_kind: Some(members), builtin: false, .. })]
            if name == "ReadablePath"
                && params.is_empty()
                && members == &vec!["InfallibleStructural".to_string(), "VariantPath".to_string()]
    ));

    let err = parse_with_context(
        "@FacetPathKind Type ReadablePath = InfallibleStructural",
        ParserContext::module(1, Some("User".into())),
    )
    .expect_err("user source must not declare Facet path kinds");
    assert!(err
        .message()
        .contains("only allowed in canonical standard library source"));

    let err = parse_with_context(
        "@FacetPathKind Type ReadablePath = InfallibleStructural",
        ParserContext::module(1, Some("Process".into())).with_rules(ParseRules::std_module()),
    )
    .expect_err("only the canonical Facet standard source may declare path kinds");
    assert!(err
        .message()
        .contains("only allowed in canonical standard library source"));

    let err = parse_with_context(
        "@builtin @FacetPathKind Type ReadablePath = InfallibleStructural",
        ParserContext::module(1, Some("Facet".into())).with_rules(ParseRules::std_module()),
    )
    .expect_err("Facet path kind declarations cannot be builtin declarations");
    assert!(err.message().contains("cannot be combined with @builtin"));
}

#[test]
fn test_hidden_annotates_builtin_decl() {
    let ast = parse_with_context(
        "@hidden\n@builtin def __process_sleep(duration: Duration) -> Result<Unit>",
        ParserContext::module(1, Some("Process".into())).with_rules(ParseRules::std_module()),
    )
    .expect("hidden + builtin def should parse");

    assert!(matches!(
        ast.as_slice(),
        [Ast::BuiltinDecl(_, name, _, _, _, _, DeclAttrs { hidden: true, .. })]
            if name == "__process_sleep"
    ));
}

#[test]
fn test_hidden_duplicate_is_error() {
    let err = parse_with_context(
        "@hidden\n@hidden\n@builtin def __process_sleep(duration: Duration) -> Result<Unit>",
        ParserContext::module(1, Some("Process".into())).with_rules(ParseRules::std_module()),
    )
    .expect_err("duplicate hidden should fail");
    assert!(err
        .message()
        .contains("@hidden may only appear once before a declaration"));
}

#[test]
fn test_hidden_builtin_impl_member_parses() {
    let ast = parse_with_context(
        r#"impl Task {
  @hidden
  @builtin def __task_call(body: (-> Result<$A>)) -> Result<$A>
}"#,
        ParserContext::module(1, Some("Task".into())).with_rules(ParseRules::std_module()),
    )
    .expect("hidden builtin impl member should parse");

    match &ast[0] {
        Ast::ImplDef(_, target, _, body, _) => {
            assert_eq!(target, "Global::Task");
            assert!(matches!(
                &body[0],
                Ast::BuiltinDecl(_, name, _, _, _, _, DeclAttrs { hidden: true, .. })
                    if name == "__task_call"
            ));
        }
        other => panic!("expected impl, got {:?}", other),
    }
}

#[test]
fn test_private_builtin_impl_member_parses() {
    let ast = parse_with_context(
        r#"impl List {
  @builtin defp zip(left: List<$A>, right: List<$B>) -> List<($A, $B)>
}"#,
        ParserContext::module(1, Some("List".into())).with_rules(ParseRules::std_module()),
    )
    .expect("private builtin impl member should parse");

    match &ast[0] {
        Ast::ImplDef(_, target, _, body, _) => {
            assert_eq!(target, "Global::List");
            assert!(matches!(
                &body[0],
                Ast::BuiltinDecl(
                    _,
                    name,
                    _,
                    _,
                    _,
                    _,
                    DeclAttrs {
                        builtin: true,
                        visibility: Visibility::Private,
                        ..
                    },
                ) if name == "zip"
            ));
        }
        other => panic!("expected impl, got {:?}", other),
    }
}

#[test]
fn test_duration_literal_lowers_to_internal_struct_lit() {
    let ast = parse("100ms").expect("duration literal should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::InternalStructLit(_, name, fields)]
            if name == "Duration"
                && matches!(
                    fields.as_slice(),
                    [StructLitField::Explicit(field, Ast::Lit(_, Lit::Int(value)))]
                        if field == "millis" && *value == int(100)
                )
    ));
}

#[test]
fn test_doc_annotates_builtin_type_decl() {
    let ast = parse_with_context(
        "@doc \"\"\"\nBuiltin Int.\n\"\"\"\n@builtin type Int",
        ParserContext::module(1, Some("Bootstrap".into())).with_rules(ParseRules::std_module()),
    )
    .expect("doc + builtin type should parse");

    assert!(matches!(
        ast.as_slice(),
        [Ast::BuiltinTypeDecl(_, BuiltinTypeHead { name, .. }, DeclAttrs { doc: Some(doc), .. })]
            if name == "Int" && doc == "\nBuiltin Int.\n"
    ));
}

#[test]
fn test_doc_annotates_defmod() {
    let ast = parse_with_context(
            "@doc \"\"\"Kernel docs\"\"\"\ndefmod Kernel {\n  def add(x: Int, y: Int) -> Int { x + y }\n}",
            ParserContext::module(1, None),
        )
        .expect("doc + defmod should parse");

    assert!(matches!(
        ast.as_slice(),
        [Ast::Defmod(_, name, _, DeclAttrs { doc: Some(doc), .. })]
            if name == "Global::Kernel" && doc == "Kernel docs"
    ));
}

#[test]
fn test_autoimport_annotates_defmod() {
    let ast = parse_with_context(
        "@autoimport\ndefmod Kernel { def add(x: Int, y: Int) -> Int { x + y } }",
        ParserContext::module(1, None),
    )
    .expect("autoimport + defmod should parse");

    assert!(matches!(
        ast.as_slice(),
        [Ast::Defmod(_, name, _, DeclAttrs { auto_import: true, .. })]
            if name == "Global::Kernel"
    ));
}

#[test]
fn test_doc_annotates_deferror() {
    let ast = parse_with_context(
        "@doc \"\"\"Missing value error\"\"\"\ndeferror NoneError { \"None Value.\" }",
        ParserContext::module(1, None),
    )
    .expect("doc + deferror should parse");

    assert!(matches!(
        ast.as_slice(),
        [Ast::DeferrorDef(_, name, _, _, DeclAttrs { doc: Some(doc), .. })]
            if name == "Global::NoneError" && doc == "Missing value error"
    ));
}

#[test]
fn test_doc_requires_following_declaration() {
    let err = parse("@doc \"\"\"dangling\"\"\"").expect_err("expected parse error");
    assert!(err.message().contains("declaration"));
}

#[test]
fn test_builtin_type_decl_preserves_generic_head() {
    let ast = parse_with_context(
        "@builtin type Result<$T>",
        ParserContext::module(1, Some("Bootstrap".into())).with_rules(ParseRules::std_module()),
    )
    .expect("generic builtin type should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::BuiltinTypeDecl(_, BuiltinTypeHead { name, params, .. }, _)]
            if name == "Result" && params.as_slice() == ["$T"]
    ));
}

#[test]
fn test_std_module_builtin_defenum_result_is_accepted() {
    let ast = parse_with_context(
        r#"@builtin
defenum Result<$T> {
  Ok($T),
  Err(Error),
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("builtin result enum should parse in std modules");

    assert!(matches!(
        ast.as_slice(),
        [Ast::EnumDef(_, name, params, variants, DeclAttrs { .. })]
            if name.ends_with("Result")
                && params.len() == 1
                && params[0].name == "$T"
                && variants.len() == 2
                && variants[0].name == "Ok"
                && variants[1].name == "Err"
    ));
}

#[test]
fn test_unit_payload_extractor_pattern_preserves_empty_arguments() {
    for head in ["check", "Checked::unit"] {
        let source = format!("match value {{ {head}() => 1, _ => 0 }}");
        let ast = parse(&source).expect("an Extractor head permits zero payload patterns");
        let Ast::Match(_, _, arms) = &ast[0] else {
            panic!("expected match expression");
        };
        assert!(matches!(&arms[0].pattern, AstPattern::Call(_, name, args)
            if name == head && args.is_empty()));
    }
    parse("match value { check(()) => 1, _ => 0 }")
        .expect("Unit remains an Expr candidate until the signature fixes its role");
}

#[test]
fn extractor_payload_pattern_preserves_binding_and_wildcard_annotations() {
    for child in ["value: Unit", "_: Unit"] {
        let source = format!("match input {{ Checked::unit({child}) => 1, _ => 0 }}");
        parse(&source).expect("payload pattern permits a type-correct annotation");
    }
}

#[test]
fn test_std_module_builtin_defenum_boolean_is_accepted() {
    let ast = parse_with_context(
        r#"@builtin
defenum Boolean {
  True,
  False,
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("builtin boolean enum should parse in std modules");

    assert!(matches!(
        ast.as_slice(),
        [Ast::EnumDef(_, name, params, variants, DeclAttrs { .. })]
            if name.ends_with("Boolean")
                && params.is_empty()
                && variants.len() == 2
                && variants[0].name == "True"
                && variants[1].name == "False"
    ));
}

#[test]
fn test_user_source_builtin_defenum_is_rejected() {
    let err = parse("@builtin\ndefenum Boolean { True, False }")
        .expect_err("user source should reject builtin defenum");
    assert!(err.message().contains("@builtin"));
}

#[test]
fn test_type_keyword_cannot_be_used_as_function_name() {
    let err = parse("def type() -> Int { 0 }").expect_err("type should stay reserved");
    assert!(err.message().contains("Expected identifier"));
}

#[test]
fn test_builtin_decl_with_body_is_error() {
    let err = parse_with_context(
        "@builtin def print(a: String) -> Unit { print(a) }",
        ParserContext::module(1, Some("Bootstrap".into())).with_rules(ParseRules::std_module()),
    )
    .expect_err("builtin declaration with a body should be rejected");
    assert!(err.message().contains("must not have a function body"));
}

#[test]
fn test_builtin_if_decl_accepts_keyword_name_in_std_module_member() {
    let ast = parse_with_context(
        r#"defmod Kernel {
  @builtin def if(flag: Boolean, then_branch: (-> $A), else_branch: (-> $A)) -> $A
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("builtin if declaration should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Kernel");
            assert!(matches!(
                &body[0],
                Ast::BuiltinDecl(_, builtin_name, _, params, Some(AstTy::Named(_, ret)), _, _)
                    if builtin_name == "if" && params.len() == 3 && ret == "$A"
            ));
        }
        other => panic!("expected defmod, got {:?}", other),
    }
}

#[test]
fn test_builtin_import_decl_accepts_keyword_name_in_std_module_member() {
    let ast = parse_with_context(
        r#"defmod Bootstrap {
  @builtin def import() -> Unit
  @builtin def include(path: String) -> Unit
}"#,
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("builtin import/include declarations should parse");

    match &ast[0] {
        Ast::Defmod(_, name, body, _) => {
            assert_eq!(name, "Global::Bootstrap");
            assert!(matches!(
                &body[0],
                Ast::BuiltinDecl(_, builtin_name, _, params, Some(AstTy::Named(_, ret)), _, _)
                    if builtin_name == "import" && params.is_empty() && ret == "Unit"
            ));
            assert!(matches!(
                &body[1],
                Ast::BuiltinDecl(_, builtin_name, _, params, Some(AstTy::Named(_, ret)), _, _)
                    if builtin_name == "include" && params.len() == 1 && ret == "Unit"
            ));
        }
        other => panic!("expected defmod, got {:?}", other),
    }
}

#[test]
fn test_unknown_annotator_is_error() {
    let err = parse("@memo def f()").expect_err("error");
    assert!(err.message().contains("Unknown annotation: @memo"));
}

#[test]
fn test_derive_annotation_is_attached_to_data_declarations() {
    let ast = parse(
        "@derive Eq,\n  Neq, Compare, Show\ndefstruct User { name: String, age: Int }\n\n@derive Eq\ndefrecord Point(x: Int, y: Int)\n\n@derive Show\ndefenum Color { Red, Blue }",
    )
    .expect("derive annotations should parse");

    assert!(matches!(
        &ast[0],
        Ast::StructDef(_, _, _, _, attrs) if attrs.derives == ["Eq", "Neq", "Compare", "Show"]
    ));
    assert!(matches!(
        &ast[1],
        Ast::RecordDef(_, _, _, attrs) if attrs.derives == ["Eq"]
    ));
    assert!(matches!(
        &ast[2],
        Ast::EnumDef(_, _, _, _, attrs) if attrs.derives == ["Show"]
    ));
}

#[test]
fn test_derive_annotation_rejects_empty_trailing_and_duplicate_lists() {
    for (source, expected) in [
        ("@derive\ndefstruct User {}", "at least one bare trait name"),
        ("@derive Eq,\ndefstruct User {}", "after"),
        ("@derive Eq, Eq\ndefstruct User {}", "DuplicateDerivedTrait"),
        (
            "@derive Eq\n@derive Show\ndefstruct User {}",
            "may only appear once",
        ),
    ] {
        let err = parse(source).expect_err("invalid derive annotation should fail");
        assert!(
            err.message().contains(expected),
            "{}: {}",
            source,
            err.message()
        );
    }
}

#[test]
fn test_derive_annotation_rejects_non_data_declarations() {
    let err =
        parse("@derive Eq\ndef main() -> Int { 0 }").expect_err("derive on a function should fail");
    assert!(err.message().contains("DeriveNotAllowed"));
}

#[test]
fn test_binop() {
    let ast = parse("x = 10 + 5").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::BinOp(_, BinOp::Add, _, _)));
        }
        _ => panic!("Expected Bind with BinOp"),
    }
}

#[test]
fn test_precedence() {
    // Expr-class operators are same-precedence and left-associative.
    let ast = parse("x = 1 + 2 * 3").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Mul, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(3)));
                assert!(matches!(
                    left.as_ref(),
                    Ast::BinOp(_, BinOp::Add, ll, lr)
                        if matches!(ll.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(1))
                            && matches!(lr.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(2))
                ));
            }
            _ => panic!("Expected left-associative Expr-class parse at top"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_logical_precedence_is_lower_than_expr_class() {
    let ast = parse("x = a + b == c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Eq, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "c"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::BinOp(_, BinOp::Add, ll, lr)
                        if matches!(ll.as_ref(), Ast::Var(_, name) if name == "a")
                            && matches!(lr.as_ref(), Ast::Var(_, name) if name == "b")
                ));
            }
            other => panic!("Expected logical top-level parse, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_prefix_bang_lowers_to_boolean_not_call() {
    let ast = parse("x = !flag").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Ast::Path(_, path)
                        if path.segments == vec!["Boolean".to_string(), "not".to_string()]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(arg)]
                        if matches!(arg, Ast::Var(_, name) if name == "flag")
                ));
            }
            other => panic!("Expected lowered Boolean::not call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_prefix_bang_binds_tighter_than_comparison() {
    let ast = parse("x = !a == b").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Eq, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "b"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::App(_, func, args)
                        if matches!(
                            func.as_ref(),
                            Ast::Path(_, path)
                                if path.segments == vec!["Boolean".to_string(), "not".to_string()]
                        ) && matches!(
                            args.as_slice(),
                            [RecordLitArg::Positional(arg)]
                                if matches!(arg, Ast::Var(_, name) if name == "a")
                        )
                ));
            }
            other => panic!("Expected Eq at top level, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_prefix_bang_binds_tighter_than_expr_class_ops() {
    let ast = parse("x = !a + b").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Add, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "b"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::App(_, func, args)
                        if matches!(
                            func.as_ref(),
                            Ast::Path(_, path)
                                if path.segments == vec!["Boolean".to_string(), "not".to_string()]
                        ) && matches!(
                            args.as_slice(),
                            [RecordLitArg::Positional(arg)]
                                if matches!(arg, Ast::Var(_, name) if name == "a")
                        )
                ));
            }
            other => panic!("Expected Add at top level, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_prefix_bang_binds_tighter_than_and() {
    let ast = parse("x = !a && b").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(func.as_ref(), Ast::Var(_, name) if name == "&&"));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(
                            left,
                            Ast::App(_, func, args)
                                if matches!(
                                    func.as_ref(),
                                    Ast::Path(_, path)
                                        if path.segments == vec!["Boolean".to_string(), "not".to_string()]
                                ) && matches!(
                                    args.as_slice(),
                                    [RecordLitArg::Positional(arg)]
                                        if matches!(arg, Ast::Var(_, name) if name == "a")
                                )
                        ) && matches!(right, Ast::Var(_, name) if name == "b")
                ));
            }
            other => panic!("Expected and(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_prefix_bang_preserves_grouping() {
    let ast = parse("x = !(a && b)").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Ast::Path(_, path)
                        if path.segments == vec!["Boolean".to_string(), "not".to_string()]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(Ast::Grouped(_, inner))]
                        if matches!(
                            inner.as_ref(),
                            Ast::App(_, inner_func, inner_args)
                                if matches!(inner_func.as_ref(), Ast::Var(_, name) if name == "&&")
                                    && matches!(
                                        inner_args.as_slice(),
                                        [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                                            if matches!(left, Ast::Var(_, name) if name == "a")
                                                && matches!(right, Ast::Var(_, name) if name == "b")
                                    )
                        )
                ));
            }
            other => panic!("Expected lowered Boolean::not call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_name_lowers_to_binary_call() {
    let ast = parse("x = left `eq` right").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(
                    matches!(func.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == ["eq"])
                );
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "left")
                            && matches!(right, Ast::Var(_, name) if name == "right")
                ));
            }
            other => panic!("Expected lowered App, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_qualified_path_lowers_to_binary_call() {
    let ast = parse("x = left `Boolean::not_eq` right").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Ast::NamedInfixRef(_, path)
                        if path.segments == vec!["Boolean".to_string(), "not_eq".to_string()]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "left")
                            && matches!(right, Ast::Var(_, name) if name == "right")
                ));
            }
            other => panic!("Expected lowered App, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_comparison_name_uses_logical_tier() {
    let ast = parse("x = a `eq` b + c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(
                    matches!(func.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == ["eq"])
                );
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "a")
                            && matches!(
                                right,
                                Ast::BinOp(_, BinOp::Add, rl, rr)
                                    if matches!(rl.as_ref(), Ast::Var(_, name) if name == "b")
                                        && matches!(rr.as_ref(), Ast::Var(_, name) if name == "c")
                            )
                ));
            }
            other => panic!(
                "Expected logical-tier comparison helper parse, got {:?}",
                other
            ),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_and_is_lower_precedence_than_comparison_ops() {
    let ast = parse("x = 0 < num `and` num < 10").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(
                    matches!(func.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == ["and"])
                );
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(
                            left,
                            Ast::BinOp(_, BinOp::Lt, ll, lr)
                                if matches!(ll.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(0))
                                    && matches!(lr.as_ref(), Ast::Var(_, name) if name == "num")
                        ) && matches!(
                            right,
                            Ast::BinOp(_, BinOp::Lt, rl, rr)
                                if matches!(rl.as_ref(), Ast::Var(_, name) if name == "num")
                                    && matches!(rr.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(10))
                        )
                ));
            }
            other => panic!("Expected and(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_symbolic_and_is_lower_precedence_than_comparison_ops() {
    let ast = parse("x = 0 < num && num < 10").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(func.as_ref(), Ast::Var(_, name) if name == "&&"));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(
                            left,
                            Ast::BinOp(_, BinOp::Lt, ll, lr)
                                if matches!(ll.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(0))
                                    && matches!(lr.as_ref(), Ast::Var(_, name) if name == "num")
                        ) && matches!(
                            right,
                            Ast::BinOp(_, BinOp::Lt, rl, rr)
                                if matches!(rl.as_ref(), Ast::Var(_, name) if name == "num")
                                    && matches!(rr.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(10))
                        )
                ));
            }
            other => panic!("Expected and(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_symbolic_or_lowers_to_call() {
    let ast = parse("x = left || right").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(func.as_ref(), Ast::Var(_, name) if name == "||"));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "left")
                            && matches!(right, Ast::Var(_, name) if name == "right")
                ));
            }
            other => panic!("Expected lowered App, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_and_or_chain_is_left_associative_with_comparisons() {
    let ast = parse("x = 0 < num `and` num < 10 `or` num == 42").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, or_func, or_args) => {
                assert!(
                    matches!(or_func.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == ["or"])
                );
                assert!(matches!(
                    or_args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(
                            left,
                            Ast::App(_, and_func, and_args)
                                if matches!(and_func.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == ["and"])
                                    && matches!(
                                        and_args.as_slice(),
                                        [RecordLitArg::Positional(_), RecordLitArg::Positional(_)]
                                    )
                        ) && matches!(
                            right,
                            Ast::BinOp(_, BinOp::Eq, rl, rr)
                                if matches!(rl.as_ref(), Ast::Var(_, name) if name == "num")
                                    && matches!(rr.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(42))
                        )
                ));
            }
            other => panic!("Expected or(...) at top, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_operator_lowers_to_binop() {
    let ast = parse("x = left `+` right").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::BinOp(_, BinOp::Add, left, right)
                    if matches!(left.as_ref(), Ast::Var(_, name) if name == "left")
                        && matches!(right.as_ref(), Ast::Var(_, name) if name == "right")
            ));
        }
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_quoted_callee_name_and_path_lower_like_plain_calls() {
    let ast = parse("a = `eq`(left, right)\nb = `Boolean::eq`(True, False)").unwrap();
    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs) if matches!(rhs.as_ref(), Ast::App(_, func, args)
            if matches!(func.as_ref(), Ast::Var(_, name) if name == "eq") && args.len() == 2)
    ));
    assert!(matches!(
        &ast[1],
        Ast::Bind(_, _, rhs) if matches!(rhs.as_ref(), Ast::App(_, func, args)
            if matches!(func.as_ref(), Ast::Path(_, path) if path.segments == vec!["Boolean", "eq"])
                && args.len() == 2)
    ));
}

#[test]
fn test_quoted_operator_callee_lowers_to_binop() {
    let ast = parse("value = `+`(1, 2)").unwrap();
    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs) if matches!(rhs.as_ref(), Ast::BinOp(_, BinOp::Add, _, _))
    ));
}

#[test]
fn test_quoted_operator_callee_requires_two_positional_arguments() {
    let err = parse("`+`(1)").expect_err("quoted operator call must require two arguments");
    assert!(err
        .message()
        .contains("expects exactly 2 positional arguments"));
}

#[test]
fn test_individually_quoted_path_segments_are_rejected() {
    assert!(parse("`Boolean`::`eq`(True, False)").is_err());
}

#[test]
fn test_bare_and_call_stays_plain_name() {
    let ast = parse("x = and(left, right)").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(func.as_ref(), Ast::Var(_, name) if name == "and"));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "left")
                            && matches!(right, Ast::Var(_, name) if name == "right")
                ));
            }
            other => panic!("Expected bare and(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_unqualified_on_is_lower_precedence_than_compose() {
    let ast = parse("x = a `on` b >> c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Ast::NamedInfixRef(_, AstPath { segments, .. }) if segments == &vec!["Function".to_string(), "on".to_string()]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "a")
                            && matches!(
                                right,
                                Ast::Compose(_, rl, rr)
                                    if matches!(rl.as_ref(), Ast::Var(_, name) if name == "b")
                                        && matches!(rr.as_ref(), Ast::Var(_, name) if name == "c")
                            )
                ));
            }
            other => panic!("Expected Function::on(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_function_on_path_is_lower_precedence_than_compose() {
    let ast = parse("x = a `Function::on` b >> c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Ast::NamedInfixRef(_, AstPath { segments, .. }) if segments == &vec!["Function".to_string(), "on".to_string()]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]
                        if matches!(left, Ast::Var(_, name) if name == "a")
                            && matches!(
                                right,
                                Ast::Compose(_, rl, rr)
                                    if matches!(rl.as_ref(), Ast::Var(_, name) if name == "b")
                                        && matches!(rr.as_ref(), Ast::Var(_, name) if name == "c")
                            )
                ));
            }
            other => panic!("Expected Function::on(...) call, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_kernel_on_path_stays_expr_tier() {
    let ast = parse("x = a `Kernel::on` b >> c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Compose(_, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "c"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::App(_, func, args)
                        if matches!(
                            func.as_ref(),
                            Ast::NamedInfixRef(_, AstPath { segments, .. }) if segments == &vec!["Kernel".to_string(), "on".to_string()]
                        )
                        && matches!(
                            args.as_slice(),
                            [RecordLitArg::Positional(lhs), RecordLitArg::Positional(rhs)]
                                if matches!(lhs, Ast::Var(_, name) if name == "a")
                                    && matches!(rhs, Ast::Var(_, name) if name == "b")
                        )
                ));
            }
            other => panic!(
                "Expected compose with expr-tier Kernel::on call, got {:?}",
                other
            ),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_other_on_path_stays_expr_tier() {
    let ast = parse("x = a `Other::on` b >> c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Compose(_, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "c"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::App(_, func, args)
                        if matches!(
                            func.as_ref(),
                            Ast::NamedInfixRef(_, AstPath { segments, .. }) if segments == &vec!["Other".to_string(), "on".to_string()]
                        )
                        && matches!(
                            args.as_slice(),
                            [RecordLitArg::Positional(lhs), RecordLitArg::Positional(rhs)]
                                if matches!(lhs, Ast::Var(_, name) if name == "a")
                                    && matches!(rhs, Ast::Var(_, name) if name == "b")
                        )
                ));
            }
            other => panic!(
                "Expected compose with expr-tier Other::on call, got {:?}",
                other
            ),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_func_literal_operator_comparison_uses_logical_tier() {
    let ast = parse("x = a `==` b + c").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Eq, left, right) => {
                assert!(matches!(left.as_ref(), Ast::Var(_, name) if name == "a"));
                assert!(matches!(
                    right.as_ref(),
                    Ast::BinOp(_, BinOp::Add, rl, rr)
                        if matches!(rl.as_ref(), Ast::Var(_, name) if name == "b")
                            && matches!(rr.as_ref(), Ast::Var(_, name) if name == "c")
                ));
            }
            other => panic!("Expected logical-tier func literal parse, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_standalone_func_literal_is_error() {
    let err = parse("`eq`").expect_err("expected parse error");
    assert!(err
        .message()
        .contains("FuncLiteral must appear in infix position"));
}

#[test]
fn test_list_literal() {
    let ast = parse("nums = [1, 2, 3]").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::ListLiteral(_, elems) => assert_eq!(elems.len(), 3),
            _ => panic!("Expected ListLiteral"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_empty_list_with_annotation() {
    let ast = parse("empty: List<Int> = []").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), rhs) => {
            assert_eq!(name, "List");
            assert_eq!(args.len(), 1);
            assert!(matches!(args[0], AstTy::Named(_, ref n) if n == "Int"));
            assert!(matches!(rhs.as_ref(), Ast::ListNil(_)));
        }
        _ => panic!("Expected annotated Bind with empty List"),
    }
}

#[test]
fn test_list_cons_expr() {
    let ast = parse("nums = [1, ..tail]").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::ListCons(_, head, tail) => {
                assert!(matches!(head.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(1)));
                assert!(matches!(tail.as_ref(), Ast::Var(_, name) if name == "tail"));
            }
            _ => panic!("Expected ListCons"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_single_item_list_literal_accepts_trailing_comma() {
    let ast = parse("nums = [1,]").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::ListLiteral(_, elems) => {
                assert_eq!(elems.len(), 1);
                assert!(matches!(elems[0], Ast::Lit(_, Lit::Int(ref n)) if *n == int(1)));
            }
            other => panic!("Expected ListLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_hash_map_literal_accepts_string_and_expression_keys() {
    let ast = parse(r#"scores = hash!["talk" => 80, String::trim(raw) => 90,]"#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::HashMapLiteral(_, entries) => {
                assert_eq!(entries.len(), 2);
                assert!(matches!(entries[0].key, Ast::Lit(_, Lit::Str(ref key)) if key == "talk"));
                assert!(matches!(entries[0].value, Ast::Lit(_, Lit::Int(ref n)) if *n == int(80)));
                assert!(matches!(entries[1].key, Ast::App(_, _, _)));
                assert!(matches!(entries[1].value, Ast::Lit(_, Lit::Int(ref n)) if *n == int(90)));
            }
            other => panic!("Expected HashMapLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_empty_hash_map_literal() {
    let ast = parse("scores = hash![]").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::HashMapLiteral(_, entries) => assert!(entries.is_empty()),
            other => panic!("Expected HashMapLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_hash_map_literal_requires_fat_arrow() {
    let err = parse(r#"scores = hash!["talk", 80]"#).expect_err("expected parse error");
    assert!(err.message().contains("expected `=>` in hash! literal"));
}

#[test]
fn test_range_literal_expr() {
    let ast = parse("nums = [1..3]").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::RangeLiteral(_, start, stop) => {
                assert!(matches!(start.as_ref(), Ast::Lit(_, Lit::Int(n)) if *n == int(1)));
                assert!(matches!(stop.as_ref(), Ast::Lit(_, Lit::Int(n)) if *n == int(3)));
            }
            other => panic!("Expected RangeLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_string_range_literal_expr() {
    let ast = parse(r#"chars = ["a".."c"]"#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::RangeLiteral(_, start, stop) => {
                assert!(matches!(start.as_ref(), Ast::Lit(_, Lit::Str(value)) if value == "a"));
                assert!(matches!(stop.as_ref(), Ast::Lit(_, Lit::Str(value)) if value == "c"));
            }
            other => panic!("Expected RangeLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_single_item_list_pattern_accepts_trailing_comma() {
    let ast = parse("[head,] =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::ListCons(_, head, tail)
                    if matches!(head.as_ref(), AstPattern::Var(_, name) if name == "head")
                    && matches!(tail.as_ref(), AstPattern::ListNil(_))
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        other => panic!("Expected SafeBind, got {other:?}"),
    }
}

#[test]
fn test_list_pattern_safebind() {
    let ast = parse("[head, ..tail] =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::ListCons(_, head, tail)
                    if matches!(head.as_ref(), AstPattern::Var(_, name) if name == "head")
                    && matches!(tail.as_ref(), AstPattern::Var(_, name) if name == "tail")
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_as_pattern_safebind_with_annotation() {
    let ast = parse("[head, ..tail] @ list_dup: List<Int> =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::As(_, inner, alias, Some(AstTy::Generic(_, name, args)), _)
                    if alias == "list_dup"
                    && name == "List"
                    && matches!(args.as_slice(), [AstTy::Named(_, elem)] if elem == "Int")
                    && matches!(inner.as_ref(), AstPattern::ListCons(_, _, _))
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_nested_as_pattern_safebind() {
    let ast = parse("[head, .. [e2, ..tail] @ tail_dup] @ list_dup =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::As(_, outer_inner, outer_alias, None, _)
                    if outer_alias == "list_dup"
                    && matches!(
                        outer_inner.as_ref(),
                        AstPattern::ListCons(_, _, tail_pattern)
                            if matches!(
                                tail_pattern.as_ref(),
                                AstPattern::As(_, inner_list, inner_alias, None, _)
                                    if inner_alias == "tail_dup"
                                    && matches!(inner_list.as_ref(), AstPattern::ListCons(_, _, _))
                            )
                    )
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_as_pattern_bind() {
    let ast = parse("[head, ..tail] @ list_dup = list").unwrap();
    match &ast[0] {
        Ast::Bind(_, pattern, rhs) => {
            assert!(matches!(
                pattern,
                AstPattern::As(_, inner, alias, None, _)
                    if alias == "list_dup"
                    && matches!(inner.as_ref(), AstPattern::ListCons(_, _, _))
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "list"));
        }
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_constructor_pattern_safebind() {
    let ast = parse("Ok(num) =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::Call(_, ctor, inner)
                    if ctor == "Result::Ok"
                    && inner.len() == 1 && matches!(inner[0].pattern.as_deref(), Some(AstPattern::Var(_, name)) if name == "num")
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_wildcard_pattern_safebind() {
    let ast = parse("_ =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(pattern, AstPattern::Wildcard(_)));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_underscore_prefixed_pattern_is_wildcard() {
    let ast = parse("(_discard, value) = (1, 2)").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Tuple(_, items), _) => {
            assert!(
                matches!(items.as_slice(), [AstPattern::Wildcard(_), AstPattern::Var(_, name)] if name == "value")
            );
        }
        other => panic!("Expected tuple bind with wildcard, got {other:?}"),
    }
}

#[test]
fn test_as_pattern_rejects_wildcard_alias() {
    for alias in ["_", "_discard"] {
        let err = parse(&format!("(left, right) @ {alias} = (1, 2)"))
            .expect_err("as-pattern aliases must create a binding");

        assert!(err
            .message()
            .contains("as-pattern alias must be a binding identifier."));
    }
}

#[test]
fn test_as_pattern_accepts_compact_at_alias() {
    for source in [
        "(left, right)@whole = (1, 2)",
        "(left, right) @whole = (1, 2)",
    ] {
        let ast = parse(source).expect("compact as-pattern alias should parse");
        assert!(matches!(
            &ast[0],
            Ast::Bind(_, AstPattern::As(_, inner, alias, None, _), _)
                if alias == "whole" && matches!(inner.as_ref(), AstPattern::Tuple(_, _))
        ));
    }
}

#[test]
fn test_integer_literal_pattern_safebind() {
    let ast = parse("1 =? value").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(pattern, AstPattern::IntLit(_, n) if n == &int(1)));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_list_pattern_with_nested_constructor_literals_safebind() {
    let ast = parse("[Ok(1), Ok(2), _] =? lr").unwrap();
    match &ast[0] {
        Ast::SafeBind(_, pattern, rhs, _) => {
            assert!(matches!(
                pattern,
                AstPattern::ListCons(_, first, rest)
                    if matches!(first.as_ref(),
                        AstPattern::Call(_, ctor, inner)
                        if ctor == "Result::Ok" && inner.len() == 1 && matches!(inner[0].pattern.as_deref(), Some(AstPattern::IntLit(_, n)) if n == &int(1))
                    )
                    && matches!(rhs.as_ref(), Ast::Var(_, name) if name == "lr")
                    && matches!(rest.as_ref(), AstPattern::ListCons(_, _, _))
            ));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_result_type_annotation() {
    let ast = parse("r: Result<Int> = Ok(42)").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), _) => {
            assert_eq!(name, "Result");
            assert!(matches!(args.as_slice(), [AstTy::Named(_, n)] if n == "Int"));
        }
        _ => panic!("Expected annotated Bind with Result type"),
    }
}

#[test]
fn test_result_unit_type_annotation_uses_unit_token() {
    let ast = parse("def main() -> Result<()> { Ok(()) }").unwrap();
    match &ast[0] {
        Ast::Def(_, _, _, _, Some(AstTy::Generic(_, name, args)), _, _, _) => {
            assert_eq!(name, "Result");
            assert!(matches!(args.as_slice(), [AstTy::Named(_, n)] if n == "Unit"));
        }
        _ => panic!("Expected def with Result<()> return type"),
    }
}

#[test]
fn test_generic_type_args_are_preserved_for_user_defined_type() {
    let ast = parse("v: Option<Result<Int, ParseError>> = value").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), _) => {
            assert_eq!(name, "Option");
            assert!(matches!(
                args.as_slice(),
                [AstTy::Generic(_, inner_name, inner_args)]
                    if inner_name == "Result"
                    && matches!(
                        inner_args.as_slice(),
                        [AstTy::Named(_, a), AstTy::Named(_, b)] if a == "Int" && b == "ParseError"
                    )
            ));
        }
        _ => panic!("Expected annotated bind with nested generic type"),
    }
}

#[test]
fn test_function_type_and_closure_literal() {
    let ast = parse("fun: (Int -> Unit) = {|val| do_something(val)}").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Func(_, params, ret)), rhs) => {
            assert_eq!(params.len(), 1);
            assert!(matches!(params[0], AstTy::Named(_, ref n) if n == "Int"));
            assert!(matches!(ret.as_ref(), AstTy::Named(_, ref n) if n == "Unit"));
            assert!(
                matches!(rhs.as_ref(), Ast::Closure(_, params, body) if params.len() == 1 && matches!(body.as_ref(), Ast::App(_, _, _)))
            );
        }
        _ => panic!("Expected annotated Bind with function type and closure"),
    }
}

#[test]
fn test_multiline_function_type_annotation() {
    let ast = parse(
        r#"handler: (
  Int,
  String
  -> Unit
) = {|x, y| print(y)}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Func(_, params, ret)), rhs) => {
            assert_eq!(params.len(), 2);
            assert!(matches!(params[0], AstTy::Named(_, ref name) if name == "Int"));
            assert!(matches!(params[1], AstTy::Named(_, ref name) if name == "String"));
            assert!(matches!(ret.as_ref(), AstTy::Named(_, name) if name == "Unit"));
            assert!(matches!(rhs.as_ref(), Ast::Closure(_, params, _) if params.len() == 2));
        }
        _ => panic!("Expected multiline function type bind"),
    }
}

#[test]
fn test_capture_and_zero_arg_closure() {
    let ast = parse("f = &print\nnoop: (-> Unit) = {|| print(\"x\")}").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(
                matches!(rhs.as_ref(), Ast::Capture(_, target, args) if args.is_empty() && matches!(target.as_ref(), Ast::Var(_, ref n) if n == "print"))
            );
        }
        _ => panic!("Expected Capture"),
    }
    match &ast[1] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Func(_, params, _)), rhs) => {
            assert!(params.is_empty());
            assert!(matches!(rhs.as_ref(), Ast::Closure(_, params, _) if params.is_empty()));
        }
        _ => panic!("Expected zero-arg closure"),
    }
}

#[test]
fn test_capture_placeholder_and_tuple_field_access_parse() {
    let ast = parse("inc = &add(&1, 1)\nsecond = pair._1").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Capture(_, target, args)
                if matches!(target.as_ref(), Ast::Var(_, name) if name == "add")
                && matches!(args.as_slice(), [Ast::CapturePlaceholder(_, 1), Ast::Lit(_, Lit::Int(_))])));
        }
        other => panic!("Expected capture placeholder bind, got {:?}", other),
    }
    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::FieldAccess(_, _, field) if field == "_1"));
        }
        other => panic!("Expected tuple field access bind, got {:?}", other),
    }
}

#[test]
fn test_generic_enum_constructor_capture_target_parse() {
    let ast = parse("captured = &Choice<_, Int>::Left(&1)").unwrap();
    let Ast::Bind(_, _, rhs) = &ast[0] else {
        panic!("Expected capture binding");
    };
    let Ast::Capture(_, target, args) = rhs.as_ref() else {
        panic!("Expected constructor capture");
    };
    assert!(matches!(
        target.as_ref(),
        Ast::EnumConstructorCall(_, owner, type_args, variant, constructor_args)
            if owner == "Choice"
                && type_args.len() == 2
                && variant == "Left"
                && constructor_args.is_empty()
    ));
    assert!(matches!(args.as_slice(), [Ast::CapturePlaceholder(_, 1)]));
}

#[test]
fn test_capture_placeholder_index_is_limited_to_sixteen() {
    let ast =
        parse("captured = &f(&16)").expect("the maximum capture placeholder index should parse");
    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::Capture(_, _, args)
                if matches!(args.as_slice(), [Ast::CapturePlaceholder(_, 16)]))
    ));

    let error = parse("captured = &f(&17)")
        .expect_err("capture placeholder indices above sixteen must be rejected");
    assert_eq!(error.reason(), ParseErrorReason::ExpressionSyntax);
    assert_eq!(error.span(), &Span { start: 15, end: 17 });
    assert!(error
        .detail()
        .contains("capture placeholder index must be between &1 and &16"));

    let error =
        parse("captured = &f(&0)").expect_err("capture placeholder indices must remain one-based");
    assert_eq!(error.reason(), ParseErrorReason::ExpressionSyntax);
    assert!(error
        .detail()
        .contains("capture placeholder index must be between &1 and &16"));

    let error = parse("captured = &f(&999999999999999999999999999999999999)")
        .expect_err("oversized capture placeholder indices must be rejected");
    assert_eq!(error.reason(), ParseErrorReason::ExpressionSyntax);
    assert!(error
        .detail()
        .contains("capture placeholder index must be between &1 and &16"));
}

#[test]
fn test_identity_anonymous_capture_reports_id_hint() {
    let err = parse("f = &(&1)").expect_err("identity anonymous capture must fail");
    assert!(err.message().contains("use `&id` instead"));
}

#[test]
fn test_anonymous_capture_reports_named_function_hint() {
    let err = parse(
        r#"f = &(&1 + &2)
g = &(print("Hello"))"#,
    )
    .expect_err("anonymous capture forms must fail");
    assert!(err
        .message()
        .contains("capture it like `&fun_name(&1, &2)`"));
}

#[test]
fn test_immediate_anonymous_callable_calls_report_dedicated_error() {
    for source in [
        "f = &add(&1, 10)(4)",
        "f = (&add(&1, 10))(4)",
        "f = ({|x| x + 1})(4)",
        "f = (make())(4)",
        "f = (&noop)()",
    ] {
        let err = parse(source).expect_err("immediate anonymous callable call must fail");
        assert_eq!(
            err.message(),
            "Immediate calls on anonymous callable expressions are not supported; bind the callable to a name and call it as `fn(args)`"
        );
    }
}

#[test]
fn test_qualified_capture_and_flow_parse() {
    let ast = parse("reader = &User::get_name\nout = value |> trim() |*> normalize()").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Capture(_, target, args)
                    if args.is_empty() && matches!(target.as_ref(), Ast::Path(_, path) if path.segments == vec!["User".to_string(), "get_name".to_string()])));
        }
        _ => panic!("Expected qualified capture"),
    }
    match &ast[1] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::ContextMap(_, left, _) => {
                assert!(matches!(left.as_ref(), Ast::Pipe(_, _, _)));
            }
            other => panic!("Expected left-associative flow parse, got {:?}", other),
        },
        _ => panic!("Expected bind"),
    }
}

#[test]
fn test_capture_allows_facet_bracket_segments() {
    let ast = parse(
        r#"first = &List.[0]
talk = &HashMap.["talk"]
user_score = &User.scores.[1]"#,
    )
    .unwrap();

    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.is_empty()
                        && matches!(target.as_ref(),
                            Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                                if matches!(expr.as_ref(), Ast::Var(_, name) if name == "List")
                        )
            ));
        }
        other => panic!("Expected List bracket capture bind, got {:?}", other),
    }

    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.is_empty()
                        && matches!(target.as_ref(),
                            Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                                if matches!(expr.as_ref(), Ast::Var(_, name) if name == "HashMap")
                        )
            ));
        }
        other => panic!("Expected HashMap bracket capture bind, got {:?}", other),
    }

    match &ast[2] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.is_empty()
                        && matches!(target.as_ref(),
                            Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                                if matches!(expr.as_ref(),
                                    Ast::FieldAccess(_, owner, field)
                                        if field == "scores"
                                            && matches!(owner.as_ref(), Ast::Var(_, name) if name == "User")
                                )
                        )
            ));
        }
        other => panic!("Expected property bracket capture bind, got {:?}", other),
    }
}

#[test]
fn test_facet_bracket_segments_parse_dynamic_expressions() {
    let ast = parse(
        r#"list_value = List.[index + 1]
map_value = HashMap.[String::trim(raw_name)]
Facet::bulk_update(book) {
  scores.[n] <- set(1)
}"#,
    )
    .unwrap();

    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                    if matches!(expr.as_ref(), Ast::Var(_, name) if name == "List")
            ));
        }
        other => panic!("Expected dynamic List bracket bind, got {:?}", other),
    }

    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                    if matches!(expr.as_ref(), Ast::Var(_, name) if name == "HashMap")
            ));
        }
        other => panic!("Expected dynamic HashMap bracket bind, got {:?}", other),
    }

    match &ast[2] {
        Ast::BulkUpdate(_, _, entries) => {
            assert!(matches!(
                entries.as_slice(),
                [BulkUpdateEntry { path, .. }]
                    if matches!(bulk_path_segments(path), [FacetPathSegment::Field { name, .. }, FacetPathSegment::Bracket(_)] if name == "scores")
            ));
        }
        other => panic!("Expected bulk update, got {:?}", other),
    }
}

#[test]
fn test_facet_bracket_segments_parse_negative_indexes_and_ranges() {
    let ast = parse(
        r#"last = List.[-1]
window = values.[2..-2]"#,
    )
    .unwrap();

    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                    if matches!(expr.as_ref(), Ast::Var(_, name) if name == "List")
            ));
        }
        other => panic!("Expected negative List bracket bind, got {:?}", other),
    }

    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::FacetSegmentAccess(_, expr, FacetPathSegment::Bracket(_))
                    if matches!(expr.as_ref(), Ast::Var(_, name) if name == "values")
            ));
        }
        other => panic!("Expected range bracket bind, got {:?}", other),
    }
}

#[test]
fn test_facet_bracket_segments_reject_malformed_ranges() {
    let err = parse("bad = List.[1..]").expect_err("unterminated right endpoint should fail");
    assert!(
        err.message().contains("expression")
            || err.message().contains("RBrack")
            || err.message().contains("unexpected"),
        "{err:?}"
    );

    let err = parse("bad = List.[..3]").expect_err("missing left endpoint should fail");
    assert!(
        err.message().contains("expression")
            || err.message().contains("unexpected")
            || err.message().contains("DotDot"),
        "{err:?}"
    );
}

#[test]
fn test_backtick_qualified_capture_and_operator_capture_parse() {
    let ast = parse("reader = &`User::get_name`\ninc = &`+`(&1, 10)\nadd = &`+`").unwrap();

    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.is_empty()
                        && matches!(target.as_ref(), Ast::Path(_, path)
                            if path.segments == vec!["User".to_string(), "get_name".to_string()])
            ));
        }
        other => panic!("Expected qualified capture bind, got {:?}", other),
    }

    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.len() == 2
                        && matches!(target.as_ref(), Ast::FuncLiteralRef(_, func) if func.body == "+")
            ));
        }
        other => panic!("Expected operator capture bind, got {:?}", other),
    }

    match &ast[2] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.is_empty()
                        && matches!(target.as_ref(), Ast::FuncLiteralRef(_, func) if func.body == "+")
            ));
        }
        other => panic!("Expected bare operator capture bind, got {:?}", other),
    }
}

#[test]
fn test_bare_operator_capture_suggests_quoted_operator_capture() {
    for (source, suggestion) in [("&+", "&`+`"), ("List::reduce([1, 2], 0, &*)", "&`*`")] {
        let err = parse(source).expect_err("bare operator capture must be rejected with guidance");
        assert!(err.message().contains("Unquoted operator capture"));
        assert!(err
            .message()
            .contains(suggestion.trim_matches(|ch| ch == '&' || ch == '`')));
    }
}

#[test]
fn test_pipe_rhs_call_stays_as_app() {
    let ast = parse("out = user |> User::get_name()").expect("pipe with method call should parse");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Pipe(_, _, right) => {
                assert!(matches!(right.as_ref(), Ast::App(_, _, args) if args.is_empty()));
            }
            other => panic!("Expected pipe node, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_flow_operators_allow_elixir_style_line_breaks() {
    let ast = parse(
        "out = value\n|> trim()\n|*> normalize()\npipeline = &parse\n>* &render\nplain = &inc >>\n&inc",
    )
    .expect("flow operators should continue across newlines");

    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::ContextMap(_, left, _) => {
                assert!(matches!(left.as_ref(), Ast::Pipe(_, _, _)));
            }
            other => panic!("Expected multiline pipe/map chain, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }

    match &ast[1] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::LiftedCompose(_, _, _)));
        }
        other => panic!("Expected multiline lifted compose, got {:?}", other),
    }

    match &ast[2] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Compose(_, _, _)));
        }
        other => panic!("Expected multiline compose, got {:?}", other),
    }
}

#[test]
fn test_nested_generic_type_closes_without_confusing_compose() {
    let ast = parse("value: Result<List<Int>> = Ok([])").expect("nested generic type should parse");
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, outer_args)), rhs) => {
            assert_eq!(name, "Result");
            assert_eq!(outer_args.len(), 1);
            assert!(matches!(
                &outer_args[0],
                AstTy::Generic(_, inner_name, inner_args)
                    if inner_name == "List"
                        && inner_args.len() == 1
                        && matches!(&inner_args[0], AstTy::Named(_, ty) if ty == "Int")
            ));
            assert!(matches!(
                rhs.as_ref(),
                Ast::ConstructorCall(_, ctor, args) if ctor == "Result::Ok" && args.len() == 1
            ));
        }
        other => panic!("Expected annotated Result<List<Int>> bind, got {:?}", other),
    }
}

#[test]
fn test_generic_type_close_followed_by_bind_without_space_parses() {
    let ast = parse("h: HashMap<Int>=HashMap::empty_map()")
        .expect("generic close followed by bind without space should parse");
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), rhs) => {
            assert_eq!(name, "HashMap");
            assert!(matches!(args.as_slice(), [AstTy::Named(_, inner)] if inner == "Int"));
            assert!(matches!(rhs.as_ref(), Ast::App(_, _, _)));
        }
        other => panic!("Expected annotated HashMap<Int> bind, got {:?}", other),
    }
}

#[test]
fn test_nested_generic_type_close_followed_by_bind_without_space_parses() {
    let ast = parse("v: Option<Result<Int, ParseError>>=value")
        .expect("nested generic close followed by bind without space should parse");
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), rhs) => {
            assert_eq!(name, "Option");
            assert!(matches!(
                args.as_slice(),
                [AstTy::Generic(_, inner_name, inner_args)]
                    if inner_name == "Result"
                        && matches!(
                            inner_args.as_slice(),
                            [AstTy::Named(_, left), AstTy::Named(_, right)]
                                if left == "Int" && right == "ParseError"
                        )
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        other => panic!("Expected annotated nested generic bind, got {:?}", other),
    }
}

#[test]
fn test_gte_expression_still_parses_as_comparison() {
    let ast = parse("value = a >= b").expect("gte expression should still parse as comparison");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::BinOp(_, BinOp::Gte, left, right)
                    if matches!(left.as_ref(), Ast::Var(_, name) if name == "a")
                        && matches!(right.as_ref(), Ast::Var(_, name) if name == "b")
            ));
        }
        other => panic!("Expected bind with >= comparison, got {:?}", other),
    }
}

#[test]
fn test_qualified_placeholder_capture_parses() {
    let ast = parse(r#"rename = &User::with_name("bob", &1)"#)
        .expect("qualified placeholder capture should parse");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Capture(_, target, args)
                    if args.len() == 2
                        && matches!(target.as_ref(), Ast::Path(_, path)
                            if path.segments == vec!["User".to_string(), "with_name".to_string()])
            ));
        }
        other => panic!("Expected qualified partial capture bind, got {:?}", other),
    }
}

#[test]
fn test_compose_chain_is_left_associative_at_same_precedence() {
    let ast =
        parse("pipeline = parse() >=> validate() >> render()").expect("compose chain should parse");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Compose(_, left, right) => {
                assert!(matches!(right.as_ref(), Ast::App(_, _, args) if args.is_empty()));
                assert!(matches!(left.as_ref(), Ast::KleisliCompose(_, _, _)));
            }
            other => panic!("Expected outer compose node, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_legacy_pipe_compose_operator_is_rejected() {
    parse("pipeline = &parse |=> &render").expect_err("legacy pipe compose should be rejected");
}

#[test]
fn test_facet_arrow_chain_expression_parses() {
    parse(r#"value = Facet::view(User.profile -> Profile.name, user)"#)
        .expect("facet arrow chain should parse");
}

#[test]
fn test_facet_arrow_chain_left_association_parses() {
    parse(r#"value = Facet::view(Config.root -> Project.current -> Tuple._0, cfg)"#)
        .expect("chained facet arrow chain should parse");
}

#[test]
fn test_closure_body_accepts_semicolon_separated_statements() {
    let ast = parse("fun = {|num| x = x + 5;x+num}").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Closure(_, params, body) => {
                assert_eq!(params.len(), 1);
                assert!(matches!(params[0].name.as_str(), "num"));
                assert!(matches!(
                    body.as_ref(),
                    Ast::Block(_, stmts)
                        if matches!(stmts.as_slice(), [Ast::Semi(_, _), Ast::BinOp(_, _, _, _)])
                ));
            }
            _ => panic!("Expected Closure"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_closure_param_annotation_is_optional() {
    let ast = parse("fun = {|x: Int, y| y}").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Closure(_, params, _) => {
                assert_eq!(params.len(), 2);
                assert!(matches!(params[0].ty, Some(AstTy::Named(_, ref n)) if n == "Int"));
                assert!(params[1].ty.is_none());
            }
            _ => panic!("Expected Closure"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_semicolon_wraps_statement_in_semi() {
    let ast = parse("print(\"x\");").unwrap();
    assert!(matches!(
        &ast[0],
        Ast::Semi(_, inner) if matches!(inner.as_ref(), Ast::App(_, _, _))
    ));
}

#[test]
fn test_function_body_trailing_semicolon_is_explicit_unit() {
    let ast = parse("def fun() -> Unit { print(\"x\"); }").unwrap();
    match &ast[0] {
        Ast::Def(_, _, _, _, _, _, body, _) => {
            assert!(matches!(
                body.as_ref(),
                Ast::Block(_, stmts) if matches!(stmts.as_slice(), [Ast::Semi(_, inner)] if matches!(inner.as_ref(), Ast::App(_, _, _)))
            ));
        }
        _ => panic!("Expected Def"),
    }
}

#[test]
fn test_empty_def_body_is_error() {
    let err = parse("def noop() -> Unit {}").expect_err("Expected parse error");
    assert!(err.message().contains("Function body must not be empty"));
}

#[test]
fn test_multiline() {
    let ast = parse("x = 1\ny = 2\nprint(to_string(x))").unwrap();
    assert_eq!(ast.len(), 3);
}

#[test]
fn test_statements_on_same_line_require_separator() {
    let err = parse("[]1").expect_err("Expected parse error");
    assert!(err.message().contains("Expected newline or `;`"));
}

#[test]
fn test_range_literal_used_as_operator_has_bracket_help() {
    let err = parse("2..8").expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("Range literals must use bracket syntax"));
}

#[test]
fn test_safebind_rhs_requires_statement_separator() {
    let err = parse("[] =? []1").expect_err("Expected parse error");
    assert!(err.message().contains("Expected newline or `;`"));
}

#[test]
fn test_unit_is_rejected_as_a_pattern_with_binding_help() {
    for source in ["() = ()", "() =? ()"] {
        let err = parse(source).expect_err("Unit must not be accepted as a pattern");
        assert!(
            err.message()
                .contains("The Unit type has no pattern matching."),
            "source={source:?}, message={}",
            err.message()
        );
    }
}

#[test]
fn test_safebind_allows_trailing_semicolon() {
    let ast = parse("[] =? value;").unwrap();
    assert!(matches!(
        &ast[0],
        Ast::Semi(_, inner) if matches!(inner.as_ref(), Ast::SafeBind(_, _, _, _))
    ));
}

#[test]
fn test_string_concat() {
    let ast = parse(r#"msg = "hello" ++ " world""#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::BinOp(_, BinOp::Concat, _, _)));
        }
        _ => panic!("Expected Bind with Concat"),
    }
}

#[test]
fn test_string_concat_is_left_associative() {
    let ast = parse(r#"msg = a ++ b ++ c"#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::BinOp(_, BinOp::Concat, left, right) => {
                assert!(matches!(right.as_ref(), Ast::Var(_, name) if name == "c"));
                assert!(matches!(
                    left.as_ref(),
                    Ast::BinOp(_, BinOp::Concat, ll, lr)
                        if matches!(ll.as_ref(), Ast::Var(_, name) if name == "a")
                            && matches!(lr.as_ref(), Ast::Var(_, name) if name == "b")
                ));
            }
            _ => panic!("Expected nested left-associative concat"),
        },
        _ => panic!("Expected Bind with chained Concat"),
    }
}

#[test]
fn test_interpolated_string_ast() {
    let ast = parse(r#"msg = "hi #{name}!""#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::InterpolatedStr(_, parts) => {
                assert!(matches!(parts.first(), Some(InterpolatedPart::Text(s)) if s == "hi "));
                assert!(matches!(parts.get(1), Some(InterpolatedPart::Expr(expr))
                            if matches!(expr.as_ref(), Ast::Var(_, name) if name == "name")));
                assert!(matches!(parts.get(2), Some(InterpolatedPart::Text(s)) if s == "!"));
            }
            _ => panic!("Expected InterpolatedStr"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_interpolated_string_allows_brace_in_inner_string_literal() {
    let ast = parse(r#"msg = '#{to_string("}")}'"#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::InterpolatedStr(_, parts) => {
                assert!(matches!(
                    parts.as_slice(),
                    [InterpolatedPart::Expr(expr)]
                        if matches!(expr.as_ref(), Ast::App(_, _, _))
                ));
            }
            _ => panic!("Expected InterpolatedStr"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_interpolation_escape_drops_backslash() {
    let ast = parse(r#"msg = "\#{name}""#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Lit(_, Lit::Str(s)) if s == "#{name}"));
        }
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_triple_quoted_string_parses_as_plain_string_expr() {
    let ast = parse("msg = \"\"\"\nhello\n\"\"\"").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Lit(_, Lit::Str(s)) if s == "\nhello\n"));
        }
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_triple_quoted_string_allows_interpolation() {
    let ast = parse("msg = \"\"\"\nhello #{name}\n\"\"\"").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::InterpolatedStr(_, parts) => {
                assert!(
                    matches!(parts.first(), Some(InterpolatedPart::Text(s)) if s == "\nhello ")
                );
                assert!(matches!(parts.get(1), Some(InterpolatedPart::Expr(expr))
                    if matches!(expr.as_ref(), Ast::Var(_, name) if name == "name")));
                assert!(matches!(parts.get(2), Some(InterpolatedPart::Text(s)) if s == "\n"));
            }
            _ => panic!("Expected InterpolatedStr"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_triple_quoted_string_dedents_from_starting_line_indent() {
    let ast = parse("def main() -> Unit {\n  msg = \"\"\"\n  hello\n  world\n  \"\"\"\n}");
    let ast = ast.unwrap();
    match &ast[0] {
        Ast::Def(_, _, _, _, _, _, body, _) => match body.as_ref() {
            Ast::Block(_, stmts) => {
                assert!(matches!(
                    stmts.as_slice(),
                    [Ast::Bind(_, _, rhs)]
                        if matches!(rhs.as_ref(), Ast::Lit(_, Lit::Str(s)) if s == "\nhello\nworld\n")
                ));
            }
            _ => panic!("Expected Block"),
        },
        _ => panic!("Expected Def"),
    }
}

#[test]
fn test_doc_attribute_rejects_interpolation() {
    let err = parse("@doc \"\"\"\nhello #{name}\n\"\"\"\ndef main() -> Unit { () }")
        .expect_err("@doc interpolation must fail");
    assert!(
        err.message()
            .contains("@doc does not allow string interpolation"),
        "unexpected error: {}",
        err.message()
    );
}

#[test]
fn test_triple_quoted_string_rejects_content_shallower_than_starting_line() {
    let err = parse("def main() -> Unit {\n  msg = \"\"\"\n shallow\n  \"\"\"\n}");
    assert!(err
        .expect_err("expected indentation error")
        .message()
        .contains(
            "Triple-quoted string content must be indented at least as far as the starting line"
        ));
}

#[test]
fn test_regex_generated_literal_double_quote_lowers_to_compile_call() {
    let ast = parse(r#"rx = re"^a+$""#).unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, callee, args) => {
                assert!(matches!(
                    callee.as_ref(),
                    Ast::Path(_, path) if path.segments == vec!["Regex", "compile"]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(Ast::Lit(_, Lit::Str(pat)))] if pat == "^a+$"
                ));
            }
            other => panic!("Expected compile App, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_regex_generated_literal_single_quote_lowers_to_compile_call() {
    let ast = parse("rx = re'^a+$'").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, callee, args) => {
                assert!(matches!(
                    callee.as_ref(),
                    Ast::Path(_, path) if path.segments == vec!["Regex", "compile"]
                ));
                assert!(matches!(
                    args.as_slice(),
                    [RecordLitArg::Positional(Ast::Lit(_, Lit::Str(pat)))] if pat == "^a+$"
                ));
            }
            other => panic!("Expected compile App, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_negative_int() {
    let ast = parse("x = -5").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(-5)));
        }
        _ => panic!("Expected Bind with negative Int"),
    }
}

#[test]
fn test_negative_variable_reports_phase1_guidance() {
    let err = parse("x = -value").expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("write `0 - value` instead of `-value`"));
}

#[test]
fn test_tuple_literal() {
    let ast = parse("pair = (1, 2)").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::TupleLiteral(_, elems) => {
                assert_eq!(elems.len(), 2);
                assert!(matches!(elems[0], Ast::Lit(_, Lit::Int(ref n)) if n == &int(1)));
                assert!(matches!(elems[1], Ast::Lit(_, Lit::Int(ref n)) if n == &int(2)));
            }
            other => panic!("Expected TupleLiteral, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_pair_constructor_operator_lowers_to_right_associative_tuple_literals() {
    let ast = parse(
        "simple = a (,) b\nright = a (,) b (,) c\nexpr = a + b (,) c + d\ncompare = a (,) b == c (,) d",
    )
    .expect("pair constructor expressions should parse");

    let rhs = |index| match &ast[index] {
        Ast::Bind(_, _, rhs) => rhs.as_ref(),
        other => panic!("Expected Bind, got {other:?}"),
    };

    assert!(matches!(
        rhs(0),
        Ast::TupleLiteral(_, items)
            if matches!(&items[..], [Ast::Var(_, left), Ast::Var(_, right)] if left == "a" && right == "b")
    ));
    assert!(matches!(
        rhs(1),
        Ast::TupleLiteral(_, items)
            if matches!(&items[..], [Ast::Var(_, left), Ast::TupleLiteral(_, nested)]
                if left == "a"
                    && matches!(&nested[..], [Ast::Var(_, middle), Ast::Var(_, right)] if middle == "b" && right == "c"))
    ));
    assert!(matches!(
        rhs(2),
        Ast::TupleLiteral(_, items)
            if matches!(&items[..], [Ast::BinOp(_, BinOp::Add, _, _), Ast::BinOp(_, BinOp::Add, _, _)])
    ));
    assert!(matches!(
        rhs(3),
        Ast::BinOp(_, BinOp::Eq, left, right)
            if matches!(left.as_ref(), Ast::TupleLiteral(_, items) if items.len() == 2)
                && matches!(right.as_ref(), Ast::TupleLiteral(_, items) if items.len() == 2)
    ));
}

#[test]
fn test_cond_expression_can_be_the_left_operand_of_pair_constructor() {
    let ast = parse("value = cond { flag => 1, True => 2 } (,) \"one\"")
        .expect("a cond expression should be usable as the left pair operand");

    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::TupleLiteral(_, items)
                if matches!(&items[..], [Ast::Cond(_, clauses), Ast::Lit(_, Lit::Str(right))]
                    if clauses.len() == 2 && right == "one"))
    ));
}

#[test]
fn test_quoted_pair_constructor_lowers_for_calls_and_captures() {
    let ast = parse("called = `(,)`(1, \"one\")\npiped = 1 |> `(,)`(\"one\")\npair = &`(,)`")
        .expect("quoted pair constructor references should parse");

    let rhs = |index| match &ast[index] {
        Ast::Bind(_, _, rhs) => rhs.as_ref(),
        other => panic!("Expected Bind, got {other:?}"),
    };

    assert!(matches!(rhs(0), Ast::TupleLiteral(_, items) if items.len() == 2));
    assert!(matches!(
        rhs(1),
        Ast::Pipe(_, _, right)
            if matches!(right.as_ref(), Ast::App(_, func, args)
                if args.len() == 1
                    && matches!(func.as_ref(), Ast::FuncLiteralRef(_, pair) if pair.body == "(,)"))
    ));
    assert!(matches!(
        rhs(2),
        Ast::Capture(_, target, args)
            if args.is_empty()
                && matches!(target.as_ref(), Ast::FuncLiteralRef(_, func) if func.body == "(,)")
    ));
}

#[test]
fn test_quoted_pair_constructor_call_rejects_non_pair_arity_or_named_arguments() {
    for source in ["`(,)`()", "`(,)`(1)", "`(,)`(left: 1, right: 2)"] {
        let err =
            parse(source).expect_err("pair constructor calls require two positional arguments");
        assert!(
            err.message().contains(
                "quoted pair constructor call `(,)` expects exactly 2 positional arguments"
            ),
            "{source}: {}",
            err.message()
        );
    }

    for source in [
        "1 |> `(,)`(\"one\")",
        "[1] |*> `(,)`(\"tag\")",
        "Ok(1) |>= `(,)`(\"tag\")",
    ] {
        parse(source).expect("a direct first-argument-injection RHS must retain the pair route");
    }

    for source in [
        "1 |> f(`(,)`(\"one\"))",
        "1 |> (`(,)`(\"one\"))",
        "1 |> `(,)`(\"one\") + 1",
        "Ok(1) |*| `(,)`(\"tag\")",
    ] {
        let err = parse(source)
            .expect_err("a partial pair call is only valid as the direct pipeline RHS");
        assert!(
            err.message().contains("quoted pair constructor"),
            "{source}: {}",
            err.message()
        );
    }
}

#[test]
fn test_unquoted_pair_constructor_callable_forms_explain_quoting() {
    for (source, span) in [
        ("&(,)", Span { start: 0, end: 4 }),
        ("(,)", Span { start: 0, end: 3 }),
    ] {
        let err = parse(source).expect_err("unquoted pair callable form must be rejected");
        assert!(
            err.message() == "bare `(,)` is only valid in infix position",
            "{source}: {}",
            err.message()
        );
        assert_eq!(
            err.span(),
            &span,
            "{source}: diagnostic must cover the full bare pair spelling"
        );
    }
}

#[test]
fn test_parenthesized_expression_is_not_tuple_literal() {
    let ast = parse("value = (1)").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Ast::Grouped(_, inner)
                    if matches!(inner.as_ref(), Ast::Lit(_, Lit::Int(n)) if n == &int(1))
            ));
        }
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_deep_parenthesized_expression_parses_without_stacker_feature() {
    let depth = 16;
    let mut source = String::from("value = ");
    source.push_str(&"(".repeat(depth));
    source.push('1');
    source.push_str(&")".repeat(depth));

    let ast = parse(&source).expect("deep parenthesized expression should parse");
    assert_eq!(ast.len(), 1);
}

#[test]
fn test_max_depth_parenthesized_expression_parses() {
    let depth = MAX_PARSE_NESTING;
    let mut source = String::from("value = ");
    source.push_str(&"(".repeat(depth));
    source.push('1');
    source.push_str(&")".repeat(depth));

    let ast = parse(&source).expect("maximum allowed parenthesized expression should parse");
    assert_eq!(ast.len(), 1);
}

#[test]
fn test_excessive_parenthesized_expression_is_parse_error() {
    let depth = MAX_PARSE_NESTING + 1;
    let mut source = String::from("value = ");
    source.push_str(&"(".repeat(depth));
    source.push('1');
    source.push_str(&")".repeat(depth));

    let err = parse(&source).expect_err("excessive parenthesized expression must fail");
    assert!(err.message().contains(MAX_PARSE_NESTING_MESSAGE));
}

#[test]
fn test_excessive_generic_type_nesting_is_parse_error() {
    let depth = MAX_PARSE_NESTING + 1;
    let mut ty = "Int".to_string();
    for _ in 0..depth {
        ty = format!("List<{}>", ty);
    }
    let source = format!("value: {} = []", ty);

    let err = parse(&source).expect_err("excessive generic type nesting must fail");
    assert!(err.message().contains(MAX_PARSE_NESTING_MESSAGE));
}

#[test]
fn test_excessive_list_expression_nesting_is_parse_error() {
    let depth = MAX_PARSE_NESTING + 1;
    let mut source = String::from("value = ");
    source.push_str(&"[".repeat(depth));
    source.push('1');
    source.push_str(&"]".repeat(depth));

    let err = parse(&source).expect_err("excessive list expression nesting must fail");
    assert!(err.message().contains(MAX_PARSE_NESTING_MESSAGE));
}

#[test]
fn test_excessive_block_expression_nesting_is_parse_error() {
    let depth = MAX_PARSE_NESTING + 1;
    let mut source = String::from("value = ");
    source.push_str(&"{".repeat(depth));
    source.push('1');
    source.push_str(&"}".repeat(depth));

    let err = parse(&source).expect_err("excessive block expression nesting must fail");
    assert!(err.message().contains(MAX_PARSE_NESTING_MESSAGE));
}

#[test]
fn test_excessive_pattern_nesting_is_parse_error() {
    let depth = MAX_PARSE_NESTING + 1;
    let mut source = "[".repeat(depth);
    source.push('_');
    source.push_str(&"]".repeat(depth));
    source.push_str(" = value");

    let err = parse(&source).expect_err("excessive pattern nesting must fail");
    assert!(err.message().contains(MAX_PARSE_NESTING_MESSAGE));
}

#[test]
fn test_grouped_pipe_rhs_preserves_callable_returning_call() {
    let ast = parse("out = value |> (make_closure(1))").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Pipe(_, _, right) => assert!(matches!(
                right.as_ref(),
                Ast::Grouped(_, inner) if matches!(inner.as_ref(), Ast::App(_, _, _))
            )),
            other => panic!("Expected pipe node, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_tuple_pattern_bind() {
    let ast = parse("(left, right) = pair").unwrap();
    match &ast[0] {
        Ast::Bind(_, pattern, rhs) => {
            assert!(matches!(
                pattern,
                AstPattern::Tuple(_, items)
                    if matches!(items.as_slice(),
                        [AstPattern::Var(_, left), AstPattern::Var(_, right)]
                            if left == "left" && right == "right")
            ));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "pair"));
        }
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_tuple_type_annotation() {
    let ast = parse("pair: (Int, String) = value").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Tuple(_, items)), rhs) => {
            assert_eq!(items.len(), 2);
            assert!(matches!(&items[0], AstTy::Named(_, name) if name == "Int"));
            assert!(matches!(&items[1], AstTy::Named(_, name) if name == "String"));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "value"));
        }
        other => panic!("Expected annotated tuple bind, got {:?}", other),
    }
}

#[test]
fn test_function_type_annotation_is_not_tuple_type() {
    let ast = parse("fun: (Int, String -> Unit) = {|x, y| ()}").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Func(_, params, ret)), rhs) => {
            assert_eq!(params.len(), 2);
            assert!(matches!(&params[0], AstTy::Named(_, name) if name == "Int"));
            assert!(matches!(&params[1], AstTy::Named(_, name) if name == "String"));
            assert!(matches!(ret.as_ref(), AstTy::Named(_, name) if name == "Unit"));
            assert!(matches!(rhs.as_ref(), Ast::Closure(_, params, _) if params.len() == 2));
        }
        other => panic!("Expected function type bind, got {:?}", other),
    }
}

#[test]
fn test_function_type_annotation_arrow_outside_parens_has_guided_error() {
    let err = parse("fun: (Int) -> String = value").expect_err("Expected parse error");
    let message = err.message();
    assert!(message.contains("choose tuple or function syntax"));
    assert!(message.contains("`, `") || message.contains("`,`"));
    assert!(message.contains("`->`"));
    assert!(message.contains("(Int -> String)"));
}

#[test]
fn test_parenthesized_single_type_annotation_is_rejected() {
    let err = parse("value: (Int) = input").expect_err("Expected parse error");
    let message = err.message();
    assert!(message.contains("one element"));
    assert!(message.contains("without parentheses"));
    assert!(message.contains("(T, U)"));
    assert!(message.contains("(T -> R)"));
}

#[test]
fn test_optional_type_annotation_lowers_to_option() {
    let ast = parse("value: Int? = input").unwrap();
    match &ast[0] {
        Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, args)), rhs) => {
            assert_eq!(name, "Option");
            assert_eq!(args.len(), 1);
            assert!(matches!(&args[0], AstTy::Named(_, inner) if inner == "Int"));
            assert!(matches!(rhs.as_ref(), Ast::Var(_, name) if name == "input"));
        }
        other => panic!("Expected optional type bind, got {:?}", other),
    }
}

#[test]
fn test_field_access() {
    let ast = parse("user.name").unwrap();
    assert!(matches!(&ast[0], Ast::FieldAccess(_, _, ref f) if f == "name"));
}

#[test]
fn test_tuple_index_field_access() {
    let ast = parse("first = pair._0").unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => {
            assert!(matches!(rhs.as_ref(), Ast::FieldAccess(_, _, field) if field == "_0"));
        }
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_tuple_dot_numeric_index_is_rejected() {
    let err = parse("first = pair.0").expect_err("Expected parse error");
    assert!(err.message().contains("Tuple access uses ._0, ._1, ..."));
}

#[test]
fn test_facet_capture_shorthand_parses_field_access_chain() {
    let ast = parse("Facet::set(~user.profile.name, \"bob\")").unwrap();
    match &ast[0] {
        Ast::App(_, callee, args) => {
            assert!(
                matches!(callee.as_ref(), Ast::Path(_, path) if path.segments == vec!["Facet", "set"])
            );
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::FacetCapture(_, inner))
                    if matches!(inner.as_ref(),
                        Ast::FieldAccess(_, expr, field)
                            if field == "name"
                                && matches!(expr.as_ref(),
                                    Ast::FieldAccess(_, expr2, field2)
                                        if field2 == "profile"
                                            && matches!(expr2.as_ref(), Ast::Var(_, name) if name == "user")
                                )
                    )
            ));
        }
        other => panic!("Expected App, got {:?}", other),
    }
}

#[test]
fn test_facet_capture_shorthand_parses_grouped_and_call_roots() {
    let ast = parse("put(~(make_pair())._1, 99)").unwrap();
    match &ast[0] {
        Ast::App(_, _, args) => {
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::FacetCapture(_, inner))
                    if matches!(inner.as_ref(),
                        Ast::FieldAccess(_, expr, field)
                            if field == "_1"
                                && matches!(expr.as_ref(), Ast::Grouped(_, _))
                    )
            ));
        }
        other => panic!("Expected App, got {:?}", other),
    }
}

#[test]
fn test_facet_capture_shorthand_allows_bare_inner_expr_for_later_diagnostics() {
    let ast = parse("Facet::view(~user)").unwrap();
    match &ast[0] {
        Ast::App(_, _, args) => {
            assert!(matches!(
                &args[0],
                RecordLitArg::Positional(Ast::FacetCapture(_, inner))
                    if matches!(inner.as_ref(), Ast::Var(_, name) if name == "user")
            ));
        }
        other => panic!("Expected App, got {:?}", other),
    }
}

#[test]
fn parses_facet_index_and_key_segments() {
    let ast = parse("updated =? Facet::set(~user.score.[\"talk\"], 90)").unwrap();
    let Ast::SafeBind(_, _, rhs, _) = &ast[0] else {
        panic!("expected safe bind");
    };
    let Ast::App(_, callee, args) = rhs.as_ref() else {
        panic!("expected Facet::set call");
    };
    assert!(matches!(callee.as_ref(), Ast::Path(_, path) if path.segments == vec!["Facet", "set"]));
    assert!(matches!(
        &args[0],
        RecordLitArg::Positional(Ast::FacetCapture(_, inner))
            if matches!(
                inner.as_ref(),
                Ast::FacetSegmentAccess(_, _, FacetPathSegment::Bracket(_))
            )
    ));
}

#[test]
fn parses_container_root_facet_paths() {
    let ast = parse(r#"print(inspect(Facet::view(HashMap.["taro"], map)))"#).unwrap();
    let rendered = format!("{ast:?}");
    assert!(rendered.contains("FacetSegmentAccess"), "{rendered}");
    assert!(rendered.contains("Bracket"), "{rendered}");

    let ast = parse("print(inspect(Facet::view(List.[0], values)))").unwrap();
    let rendered = format!("{ast:?}");
    assert!(rendered.contains("FacetSegmentAccess"), "{rendered}");
    assert!(rendered.contains("Bracket"), "{rendered}");
}

#[test]
fn rejects_optional_enum_facet_segment() {
    let error = parse("print(inspect(Facet::view(Option.Some?, option)))").unwrap_err();
    assert!(error.message().contains("OptionalSelector"));
}

#[test]
fn parses_boolean_variant_facet_segment() {
    let ast = parse("print(inspect(Facet::preview(Boolean.True, flag)))").unwrap();
    let rendered = format!("{ast:?}");
    assert!(rendered.contains("FieldAccess"), "{rendered}");
    assert!(rendered.contains("\"True\""), "{rendered}");
}

#[test]
fn parses_bulk_update_index_key_and_case_actions() {
    let ast = parse(
        r#"user2 =? Facet::bulk_update(user) {
  score.["talk"] <- over({|score| Ok(score + 1)})
  scores.[1] <- set(500)
  nickname.Some <- case_over({|name| Ok(name ++ "!")})
  phone.Some <- case_set("090")
}"#,
    )
    .unwrap();
    let Ast::SafeBind(_, _, rhs, _) = &ast[0] else {
        panic!("expected safe bind");
    };
    let Ast::BulkUpdate(_, _, entries) = rhs.as_ref() else {
        panic!("expected bulk update");
    };
    assert_eq!(entries.len(), 4);
    assert!(matches!(
        bulk_path_segments(&entries[0].path)[1],
        FacetPathSegment::Bracket(_)
    ));
    assert!(matches!(
        bulk_path_segments(&entries[1].path)[1],
        FacetPathSegment::Bracket(_)
    ));
    assert!(matches!(entries[2].kind, BulkUpdateEntryKind::CaseOver(_)));
    assert!(matches!(entries[3].kind, BulkUpdateEntryKind::CaseSet(_)));
}

#[test]
fn test_one_tuple_literal_is_rejected() {
    let err = parse("pair = (1,)").expect_err("Expected parse error");
    assert!(err.message().contains("1-tuple literals are not supported"));
}

#[test]
fn test_one_tuple_pattern_is_rejected() {
    let err = parse("(x,) = pair").expect_err("Expected parse error");
    assert!(err.message().contains("1-tuple patterns are not supported"));
}

#[test]
fn test_one_tuple_type_is_rejected() {
    let err = parse("pair: (Int,) = value").expect_err("Expected parse error");
    assert!(err.message().contains("1-tuple types are not supported"));
}

#[test]
fn test_match_wildcard_and_int_pattern() {
    let ast = parse(
        r#"x = match n {
  1 => "one",
  _ => "other",
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(&arms[0].pattern, AstPattern::IntLit(_, n) if n == &int(1)));
                assert!(matches!(&arms[1].pattern, AstPattern::Wildcard(_)));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_string_pattern() {
    let ast = parse(
        r#"x = match s {
  "a" => 1,
  _ => 0,
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(&arms[0].pattern, AstPattern::StrLit(_, s) if s == "a"));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_qualified_boolean_constructor_patterns() {
    let ast = parse(
        r#"x = match flag {
  Boolean::True => 1,
  Boolean::False => 0,
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(
                    matches!(&arms[0].pattern, AstPattern::Constructor(_, name, args) if name == "Boolean::True" && args.is_empty())
                );
                assert!(
                    matches!(&arms[1].pattern, AstPattern::Constructor(_, name, args) if name == "Boolean::False" && args.is_empty())
                );
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_arm_rhs_brace_block_is_block_expr() {
    let ast = parse(
        r#"x = match n {
  1 => {
    y = 2
    y + 3
  },
  _ => 0,
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(&arms[0].body, Ast::Block(_, stmts) if stmts.len() == 2));
            }
            other => panic!("Expected Match, got {:?}", other),
        },
        other => panic!("Expected Bind with Match, got {:?}", other),
    }
}

#[test]
fn test_match_arm_rhs_explicit_closure_stays_closure() {
    let ast = parse(
        r#"x = match n {
  1 => {|| 2},
  _ => {|| 0},
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(&arms[0].body, Ast::Closure(_, params, _) if params.is_empty()));
                assert!(matches!(&arms[1].body, Ast::Closure(_, params, _) if params.is_empty()));
            }
            other => panic!("Expected Match, got {:?}", other),
        },
        other => panic!("Expected Bind with Match, got {:?}", other),
    }
}

#[test]
fn test_match_negative_int_in_list_pattern() {
    let ast = parse(
        r#"x = match nums {
  [-1] => "neg",
  _ => "other",
}"#,
    )
    .unwrap();
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    AstPattern::ListCons(_, head, tail)
                        if matches!(head.as_ref(), AstPattern::IntLit(_, n) if n == &int(-1))
                            && matches!(tail.as_ref(), AstPattern::ListNil(_))
                ));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_empty_match_is_error() {
    let err = parse("x = match value {}").expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("Match expression must contain at least one arm"));
}

#[test]
fn test_cond_retains_ordered_clause_bodies_and_spans() {
    let source = "x = cond { a => 1, b => 2, True => 3 }";
    let ast = parse(source).expect("cond should parse");
    let Ast::Bind(_, _, rhs) = &ast[0] else {
        panic!("binding")
    };
    let Ast::Cond(span, clauses) = rhs.as_ref() else {
        panic!("cond provenance")
    };
    assert_eq!(
        &source[span.start..span.end],
        "cond { a => 1, b => 2, True => 3 }"
    );
    assert_eq!(clauses.len(), 3);
    for (ordinal, (_, body)) in clauses.iter().enumerate() {
        assert_eq!(
            &source[body.span().start..body.span().end],
            (ordinal + 1).to_string()
        );
    }
}

#[test]
fn test_cond_accepts_zero_arg_closure_body() {
    let ast = parse(r#"x = cond { True => { print("ok"); 1 }, }"#).expect("parse");
    let Ast::Bind(_, _, rhs) = &ast[0] else {
        panic!("binding")
    };
    let Ast::Cond(_, clauses) = rhs.as_ref() else {
        panic!("cond provenance")
    };
    assert!(matches!(&clauses[0].1, Ast::Closure(_, params, _) if params.is_empty()));
}

#[test]
fn test_empty_cond_is_error() {
    let err = parse("x = cond {}").expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("Cond expression must contain at least one clause"));
}

#[test]
fn test_cond_requires_final_true_clause() {
    let err = parse(
        r#"x = cond {
  flag => 1,
}"#,
    )
    .expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("Final cond clause must use `True` as its condition"));
}

#[test]
fn test_cond_rejects_non_final_true_clause() {
    let err = parse(
        r#"x = cond {
  True => 1,
  other => 2,
}"#,
    )
    .expect_err("Expected parse error");
    assert!(err
        .message()
        .contains("`True` clause must be the final cond clause"));
}

#[test]
fn test_match_constructor_pattern_is_accepted() {
    let ast = parse(
        r#"x = match value {
  Some(y) => y,
  _ => 0,
}"#,
    )
    .expect("constructor pattern should parse");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    AstPattern::Call(_, name, inner)
                        if name == "Some"
                            && inner.len() == 1 && matches!(inner[0].pattern.as_deref(), Some(AstPattern::Var(_, bound)) if bound == "y")
                ));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_bare_uppercase_identifier_is_constructor_pattern() {
    let ast = parse(
        r#"x = match value {
  ParseError => 0,
  _ => 1,
}"#,
    )
    .expect("bare uppercase identifier should parse as a constructor pattern");
    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    AstPattern::Constructor(_, name, args) if name == "ParseError" && args.is_empty()
                ));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_as_and_annotated_pattern_is_accepted() {
    let ast = parse(
        r#"x = match value {
  [head, ..tail] @ whole: List<Int> => head,
  _ => 0,
}"#,
    )
    .expect("as-pattern and annotation in match should parse");

    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    AstPattern::As(_, inner, alias, Some(AstTy::Generic(_, ty_name, ty_args)), _)
                        if alias == "whole"
                            && ty_name == "List"
                            && ty_args.len() == 1
                            && matches!(inner.as_ref(), AstPattern::ListCons(_, _, _))
                ));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_or_pattern_remains_in_single_arm() {
    let ast = parse(
        r#"x = match value {
  "a" | "b" => 1,
  _ => 0,
}"#,
    )
    .expect("or pattern should parse");

    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert_eq!(arms.len(), 2);
                assert!(matches!(
                    &arms[0].pattern,
                    AstPattern::Or(_, alternatives)
                        if alternatives.len() == 2
                            && matches!(&alternatives[0], AstPattern::StrLit(_, s) if s == "a")
                            && matches!(&alternatives[1], AstPattern::StrLit(_, s) if s == "b")
                ));
                assert!(matches!(&arms[1].pattern, AstPattern::Wildcard(_)));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_or_pattern_is_rejected_in_binding_contexts() {
    for pattern in [
        "1 | 2",
        "1 |\n2",
        "1\n| 2",
        "1 | 2\n",
        "1 |\n2\n",
        "value | _",
        "value |\n_",
        "_ | _",
        "True | False",
        "\"a\" | \"b\"",
        "(1 | 2)",
        "(1 | 2, _)",
        "[1 | 2]",
        "[_, ..tail | _]",
        "Some(1 | 2)",
        "extract(1 | 2)",
        "Matchers::extract(1 | 2)",
        "(1 | 2) @ whole",
        "1 | 2\n@ whole\n",
        "Some(1 | 2)\n@ whole\n",
        "(1 | 2) @ whole\n: Int\n",
    ] {
        for operator in ["=", "=?"] {
            let source = format!("{pattern} {operator} input");
            let error = parse(&source).expect_err(&source);
            if pattern.contains('\n') {
                // Newlines end ordinary Pattern operators just as they end Expr
                // operators; these inputs reject before binding OR validation.
                continue;
            }
            assert_eq!(error.reason(), ParseErrorReason::PatternSyntax, "{source}");
            assert!(
                error
                    .message()
                    .contains("OR patterns are not allowed in binding patterns"),
                "{source}: {error:?}"
            );
            assert_eq!(
                &source[error.span().start..error.span().end],
                "|",
                "{source}"
            );
        }
        for operator in ["<-", "=?"] {
            let source = format!("do {{ {pattern} {operator} input\n Ok(()) }}");
            let error = parse(&source).expect_err(&source);
            if pattern.contains('\n') {
                // Newlines end ordinary Pattern operators just as they end Expr
                // operators; these inputs reject before binding OR validation.
                continue;
            }
            assert_eq!(error.reason(), ParseErrorReason::PatternSyntax, "{source}");
            assert!(
                error
                    .message()
                    .contains("OR patterns are not allowed in binding patterns"),
                "{source}: {error:?}"
            );
            assert_eq!(
                &source[error.span().start..error.span().end],
                "|",
                "{source}"
            );
        }
    }
}

#[test]
fn test_is_match_accepts_root_and_nested_or_without_bindings() {
    for consumer in ["is_match", "Kernel::is_match"] {
        for pattern in [
            "1 | 2",
            "True | False",
            "_ | _",
            "\"a\" | \"b\"",
            "(1 | 2, _)",
            "[1 | 2]",
            "[_, .._ | _]",
            "Some(1 | 2)",
            "extract(1 | 2)",
            "Err(Timeout | ConnectionReset)",
        ] {
            let source = format!("{consumer}(input, {pattern})");
            let ast = parse(&source).expect(&source);
            let Ast::PatternConsumerCall(_, _, args) = &ast[0] else {
                panic!("Expected predicate consumer call: {source}");
            };
            assert!(args[1].pattern.is_some(), "{source}");
        }
    }
}

#[test]
fn test_is_match_preserves_binding_candidates_for_identity_resolution() {
    for consumer in ["is_match", "Kernel::is_match"] {
        for pattern in [
            "value | _",
            "_ | value",
            "Some(value | _)",
            "[_, ..tail | _]",
            "(1 | 2) @ whole",
        ] {
            let source = format!("{consumer}(input, {pattern})");
            let ast = parse(&source).expect(&source);
            assert!(
                matches!(&ast[0], Ast::PatternConsumerCall(_, _, args) if args[1].pattern.is_some())
            );
        }
    }
}

#[test]
fn test_match_nested_or_patterns_are_preserved() {
    fn contains_or(pattern: &AstPattern) -> bool {
        match pattern {
            AstPattern::Or(_, _) => true,
            AstPattern::Tuple(_, items) | AstPattern::Constructor(_, _, items) => {
                items.iter().any(contains_or)
            }
            AstPattern::Call(_, _, args) => args
                .iter()
                .filter_map(|arg| arg.pattern.as_deref())
                .any(contains_or),
            AstPattern::ListCons(_, head, tail) => contains_or(head) || contains_or(tail),
            AstPattern::As(_, inner, _, _, _) => contains_or(inner),
            _ => false,
        }
    }
    for pattern in [
        "(1 | 2, _)",
        "[1 | 2]",
        "[_, ..tail | _]",
        "Some(1 | 2)",
        "extract(1 | 2)",
        "Err(Timeout | ConnectionReset @ error: Error)",
        "(1 | 2) @ whole",
    ] {
        let source = format!("match input {{ {pattern} => 1, _ => 0, }}");
        let ast = parse(&source).expect(&source);
        let Ast::Match(_, _, arms) = &ast[0] else {
            panic!("Expected Match: {source}");
        };
        assert_eq!(
            arms.len(),
            2,
            "nested OR must not expand outer arms: {source}"
        );
        assert!(contains_or(&arms[0].pattern), "{source}");
    }
    for source in [
        "value = match input { 1 | 2 => 1, _ => 0, }",
        "value =? Ok(match input { 1 | 2 => 1, _ => 0, })",
        "do { value <- Ok(match input { 1 | 2 => 1, _ => 0, })\n Ok(value) }",
        "do { value =? Ok(match input { 1 | 2 => 1, _ => 0, })\n Ok(value) }",
        "is_match(match input { 1 | 2 => 1, _ => 0, }, _)",
        "if_let(input, _, match input { 1 | 2 => 1, _ => 0, }, 0)",
        "if_let_then(input, _, print(match input { 1 | 2 => 1, _ => 0, }))",
        "Regex::matches(regex, input)",
        "predicate = &Regex::matches",
    ] {
        parse(source).expect(source);
    }
}

#[test]
fn test_if_let_or_patterns_use_pattern_grammar() {
    fn contains_or(pattern: &AstPattern) -> bool {
        match pattern {
            AstPattern::Or(..) => true,
            AstPattern::Constructor(_, _, children) | AstPattern::Tuple(_, children) => {
                children.iter().any(contains_or)
            }
            AstPattern::Call(_, _, args) => args
                .iter()
                .filter_map(|arg| arg.pattern.as_deref())
                .any(contains_or),
            AstPattern::ListCons(_, head, tail) => contains_or(head) || contains_or(tail),
            AstPattern::As(_, inner, _, _, _) => contains_or(inner),
            _ => false,
        }
    }

    for consumer in [
        "if_let",
        "Kernel::if_let",
        "if_let_then",
        "Kernel::if_let_then",
    ] {
        for pattern in [
            "1 | 2",
            "Some(1 | 2)",
            "[1 | 2]",
            "(1 | 2, _)",
            "value | value",
            "Some(value) | Some(value)",
        ] {
            let branches = if consumer.ends_with("then") {
                ", ()"
            } else {
                ", 1, 0"
            };
            let source = format!("{consumer}(input, {pattern}{branches})");
            let ast = parse(&source).expect(&source);
            let call = &ast[0];
            let Ast::PatternConsumerCall(_, _, args) = call else {
                panic!("expected call: {source}");
            };
            assert!(
                contains_or(args[1].pattern.as_deref().expect("Pattern candidate")),
                "{source}"
            );
        }
    }
}

#[test]
fn test_match_guard_is_shared_by_or_alternatives() {
    let ast = parse(
        r#"x = match n {
  1 | 2 when 0 < n `and` n < 10 => n,
  _ => 0,
}"#,
    )
    .expect("guarded or pattern should parse");

    match &ast[0] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::Match(_, _, arms) => {
                assert_eq!(arms.len(), 2);
                assert!(
                    matches!(&arms[0].pattern, AstPattern::Or(_, alternatives) if alternatives.len() == 2)
                );
                assert!(arms[0].guard.is_some());
                assert!(arms[1].guard.is_none());
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_defmod_parses_module_body() {
    let ast = parse_with_context(
        r#"defmod Kernel {
  def add(x: Int, y: Int) -> Int { x + y }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defmod should parse");

    match ast.as_slice() {
        [Ast::Defmod(_, name, body, _)] => {
            assert_eq!(name, "Global::Kernel");
            assert!(matches!(body.as_slice(), [Ast::Def(..)]));
        }
        _ => panic!("Expected single defmod declaration"),
    }
}

#[test]
fn test_import_three_forms_parse() {
    let ast = parse(
        r#"import Kernel;
import Kernel::add;
import Kernel::{add, sub};"#,
    )
    .expect("imports should parse");

    assert!(matches!(
        ast[0],
        Ast::Import(_, AstPath { ref segments, .. }, ImportSpec::All)
            if segments.as_slice() == ["Kernel"]
    ));
    assert!(matches!(
        ast[1],
        Ast::Import(_, AstPath { ref segments, .. }, ImportSpec::Single(ref name))
            if segments.as_slice() == ["Kernel"] && name == "add"
    ));
    assert!(matches!(
        ast[2],
        Ast::Import(_, AstPath { ref segments, .. }, ImportSpec::List(ref names))
            if segments.as_slice() == ["Kernel"] && names.as_slice() == ["add", "sub"]
    ));
}

#[test]
fn test_include_parses_string_path() {
    let ast = parse("include './mylib.srt'").expect("include should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::Include(_, path)] if path == "./mylib.srt"
    ));
}

#[test]
fn test_defenum_parses_variants_with_payload_and_discriminant() {
    let ast = parse_with_context(
        r#"defenum Direction {
  Up = 1,
  Down,
  Arrow(Int, Int),
}"#,
        ParserContext::module(1, None),
    )
    .expect("defenum should parse");

    match ast.as_slice() {
        [Ast::EnumDef(_, name, type_params, variants, _)] => {
            assert_eq!(name, "Global::Direction");
            assert!(type_params.is_empty());
            assert_eq!(variants.len(), 3);
            assert_eq!(variants[0].name, "Up");
            assert_eq!(variants[0].discriminant, Some(int(1)));
            assert_eq!(variants[1].name, "Down");
            assert_eq!(variants[1].payload.len(), 0);
            assert_eq!(variants[2].name, "Arrow");
            assert_eq!(variants[2].payload.len(), 2);
        }
        other => panic!("Expected enum definition, got {:?}", other),
    }
}

#[test]
fn test_defenum_parses_generic_header() {
    let ast = parse_with_context(
        r#"defenum ReduceStep<$A> {
  Resume($A),
  Stop($A),
}"#,
        ParserContext::module(1, None),
    )
    .expect("generic defenum should parse");

    match ast.as_slice() {
        [Ast::EnumDef(_, name, type_params, variants, _)] => {
            assert_eq!(name, "Global::ReduceStep");
            assert_eq!(type_params.len(), 1);
            assert_eq!(type_params[0].name, "$A");
            assert_eq!(variants.len(), 2);
        }
        other => panic!("Expected generic enum definition, got {:?}", other),
    }
}

#[test]
fn test_qualified_constructor_call_and_unit_constructor_parse() {
    let ast = parse(
        r#"x = Direction::Up
y = KeyInput::Arrow(Direction::Down)"#,
    )
    .expect("qualified constructors should parse");

    assert!(matches!(
        ast[0],
        Ast::Bind(_, _, ref rhs)
            if matches!(rhs.as_ref(), Ast::Path(_, path) if path.segments == ["Direction", "Up"])
    ));
    assert!(matches!(
        ast[1],
        Ast::Bind(_, _, ref rhs)
            if matches!(rhs.as_ref(), Ast::ConstructorCall(_, name, args) if name == "KeyInput::Arrow" && args.len() == 1)
    ));
}

#[test]
fn test_nested_defmod_is_rejected() {
    let err = parse(
        r#"defmod Outer {
  defmod Inner {
    def run() -> Unit { () }
  }
}"#,
    )
    .expect_err("nested defmod must be rejected");
    assert!(err
        .message()
        .contains("Nested module declarations are not allowed"));
}

#[test]
fn test_defmod_body_rejects_top_level_expression() {
    let err = parse(
        r#"defmod Kernel {
  x = 42
}"#,
    )
    .expect_err("module body should reject top-level expressions");
    assert!(err
        .message()
        .contains("Top-level expressions are not allowed in module compile units"));
}

#[test]
fn test_module_compile_unit_rejects_top_level_bind() {
    let err = parse_with_context("x = 42", ParserContext::module(1, None))
        .expect_err("module compile unit should reject top-level binding");
    assert!(err
        .message()
        .contains("Top-level expressions are not allowed in module compile units"));
}

#[test]
fn test_module_compile_unit_rejects_top_level_def() {
    let err = parse_with_context(
        "def add(x: Int, y: Int) -> Int { x + y }",
        ParserContext::module(1, None),
    )
    .expect_err("module compile unit should require defmod wrappers for functions");
    assert!(err
        .message()
        .contains("This top-level declaration is not allowed in the current source policy"));
}

#[test]
fn test_module_compile_unit_rejects_top_level_defextractor() {
    let err = parse_with_context(
        "defextractor never(self: Int) -> MatchResult<Int> { MatchResult::Err(NoneError()) }",
        ParserContext::module(1, None),
    )
    .expect_err("module compile unit should require defmod wrappers for extractors");
    assert!(err
        .message()
        .contains("This top-level declaration is not allowed in the current source policy"));
}

#[test]
fn test_module_compile_unit_accepts_top_level_defmod() {
    let ast = parse_with_context(
        "defmod Kernel { def add(x: Int, y: Int) -> Int { x + y } }",
        ParserContext::module(1, None),
    )
    .expect("module compile unit should accept defmod declarations");
    assert!(matches!(ast.as_slice(), [Ast::Defmod(_, _, _, _)]));
}

#[test]
fn test_namespace_block_lowers_type_and_module_heads() {
    let ast = parse_with_context(
        r#"namespace Auth {
  defrecord User(name: String)
  defmod Repo {
    def wrap(user: Auth::User) -> Auth::User { user }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("namespace declarations should lower into ordinary top-level declarations");

    assert!(matches!(
        ast.as_slice(),
        [Ast::RecordDef(_, name, _, _), Ast::Defmod(_, module_name, _, _)]
            if name == "Auth::User" && module_name == "Auth::Repo"
    ));
}

#[test]
fn test_defmod_accepts_qualified_module_path() {
    let ast = parse_with_context(
        "defmod Auth::Repo { def name() -> String { \"repo\" } }",
        ParserContext::module(1, None),
    )
    .expect("qualified defmod path should parse");
    assert!(matches!(ast.as_slice(), [Ast::Defmod(_, name, _, _)] if name == "Auth::Repo"));
}

#[test]
fn test_global_defmod_is_canonicalized_to_internal_root_path() {
    let ast = parse_with_context(
        "defmod Kernel { def name() -> String { \"repo\" } }",
        ParserContext::module(1, None),
    )
    .expect("bare global defmod should parse");
    assert!(matches!(ast.as_slice(), [Ast::Defmod(_, name, _, _)] if name == "Global::Kernel"));
}

#[test]
fn test_namespace_block_lowers_bare_defmod_to_two_segment_canonical_path() {
    let ast = parse_with_context(
        r#"namespace Auth {
  defmod Repo {
    def name() -> String { "repo" }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("namespace declarations should lower into ordinary top-level declarations");
    assert!(matches!(ast.as_slice(), [Ast::Defmod(_, name, _, _)] if name == "Auth::Repo"));
}

#[test]
fn test_explicit_global_root_module_path_is_rejected() {
    let err = parse_with_context(
        "defmod Global::Kernel { def name() -> String { \"repo\" } }",
        ParserContext::module(1, None),
    )
    .expect_err("explicit Global root should be rejected");
    assert!(err.message().contains("Global"));
}

#[test]
fn test_namespace_global_is_reserved() {
    let err = parse_with_context(
        "namespace Global { defmod Repo { def name() -> String { \"repo\" } } }",
        ParserContext::module(1, None),
    )
    .expect_err("Global namespace should be reserved");
    assert!(err.message().contains("Global"));
}

#[test]
fn test_owner_name_cannot_reuse_namespace_name() {
    let err = parse_with_context(
        r#"namespace Auth {
  defmod Auth {
    def name() -> String { "repo" }
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("owner name should not reuse active namespace name");
    assert!(err.message().contains("Auth"));
}

#[test]
fn test_global_type_names_are_canonicalized_to_internal_root_path() {
    let ast = parse_with_context(
        "defrecord User(name: String)",
        ParserContext::module(1, None),
    )
    .expect("bare global type should parse");
    assert!(matches!(ast.as_slice(), [Ast::RecordDef(_, name, _, _)] if name == "Global::User"));
}

#[test]
fn test_impl_accepts_qualified_type_target() {
    let source = r#"impl Auth::User {
  def id(self: Self) -> Auth::User { self }
}"#;
    let ast = parse_with_context(source, ParserContext::module(1, None))
        .expect("qualified impl target should parse");
    let [Ast::ImplDef(_, target, target_span, methods, _)] = ast.as_slice() else {
        panic!("expected one inherent impl");
    };
    assert_eq!(target, "Auth::User");
    assert_eq!(target_span, &Span { start: 5, end: 15 });
    assert!(
        matches!(methods.as_slice(), [Ast::Def(_, _, _, _, Some(AstTy::Named(_, ret_ty)), _, _, _)] if ret_ty == "Auth::User")
    );

    let rebased = rebase_ast_spans(ast.clone(), 9);
    let [Ast::ImplDef(_, _, rebased_target_span, _, _)] = rebased.as_slice() else {
        panic!("expected one rebased inherent impl");
    };
    assert_eq!(rebased_target_span, &Span { start: 14, end: 24 });

    let tolerant = parse_tolerant_with_context(source, ParserContext::module(1, None), None);
    let [Ast::ImplDef(_, _, tolerant_target_span, _, _)] = tolerant.ast.as_slice() else {
        panic!("expected tolerant parser to retain one inherent impl");
    };
    assert_eq!(tolerant_target_span, &Span { start: 5, end: 15 });
}

#[test]
fn test_defmod_body_accepts_defextractor() {
    let ast = parse_with_context(
        r#"defmod Matchers {
  defextractor never(self: Int) -> MatchResult<Int> {
    MatchResult::Err(NoneError())
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defmod should accept extractor declarations");
    assert!(matches!(
        ast.as_slice(),
        [Ast::Defmod(_, name, body, _)]
            if name == "Global::Matchers"
                && matches!(body.as_slice(), [Ast::ExtractorDef(_, extractor_name, _, _, _, _, _)] if extractor_name == "never")
    ));
}

#[test]
fn test_defmod_body_accepts_import() {
    let ast = parse_with_context(
        r#"defmod Parser {
  import String;
  def parse(line: String) -> String { trim(line) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defmod should accept import declarations");

    assert!(matches!(
        ast.as_slice(),
        [Ast::Defmod(_, name, body, _)]
            if name == "Global::Parser"
                && matches!(body.as_slice(),
                    [
                        Ast::Import(_, AstPath { segments, .. }, ImportSpec::All),
                        Ast::Def(_, def_name, _, _, _, _, _, _)
                    ]
                    if segments.as_slice() == ["String"] && def_name == "parse")
    ));
}

#[test]
fn test_impl_body_accepts_import() {
    let ast = parse_with_context(
        r#"impl User {
  import String;
  def normalize(self: Self, name: String) -> String { trim(name) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("impl should accept import declarations");

    assert!(matches!(
        ast.as_slice(),
        [Ast::ImplDef(_, target, _, body, _)]
            if target == "Global::User"
                && matches!(body.as_slice(),
                    [
                        Ast::Import(_, AstPath { segments, .. }, ImportSpec::All),
                        Ast::Def(_, def_name, _, _, _, _, _, _)
                    ]
                    if segments.as_slice() == ["String"] && def_name == "normalize")
    ));
}

#[test]
fn test_trait_impl_body_accepts_import() {
    let ast = parse_with_context(
        r#"impl Show for User {
  import String;
  def to_string(self: Self) -> String { trim("x") }
}"#,
        ParserContext::module(1, None),
    )
    .expect("trait impl should accept import declarations");

    assert!(matches!(
        ast.as_slice(),
        [Ast::TraitImplDef(_, trait_name, _, AstTy::Named(_, target), _, body, _)]
            if trait_name == "Show"
                && target == "Global::User"
                && matches!(body.as_slice(),
                    [
                        Ast::Import(_, AstPath { segments, .. }, ImportSpec::All),
                        Ast::Def(_, def_name, _, _, _, _, _, _)
                    ]
                    if segments.as_slice() == ["String"] && def_name == "to_string")
    ));
}

#[test]
fn test_module_compile_unit_accepts_import() {
    let ast = parse_with_context("import Kernel::add;", ParserContext::module(1, None))
        .expect("module compile unit should accept import declarations");
    assert!(matches!(
        ast.as_slice(),
        [Ast::Import(_, AstPath { segments, .. }, ImportSpec::Single(name))]
            if segments.as_slice() == ["Kernel"] && name == "add"
    ));
}

#[test]
fn test_defmod_body_rejects_non_function_declarations() {
    let err = parse(
        r#"defmod Kernel {
  defrecord Pair(left: Int, right: Int)
}"#,
    )
    .expect_err("defmod should only contain function declarations");
    assert!(err
        .message()
        .contains("This top-level declaration is not allowed in the current source policy"));
}

#[test]
fn test_module_compile_unit_rejects_builtin_decl() {
    let err = parse_with_context(
        "@builtin def print(a: String) -> Unit",
        ParserContext::module(1, None),
    )
    .expect_err("user module compile unit should reject builtin declarations");
    assert!(err
        .message()
        .contains("@builtin declarations are only allowed in standard/internal source"));
}

#[test]
fn test_module_compile_unit_rejects_builtin_type_decl() {
    let err = parse_with_context("@builtin type Int", ParserContext::module(1, None))
        .expect_err("user module compile unit should reject builtin type declarations");
    assert!(err
        .message()
        .contains("@builtin declarations are only allowed in standard/internal source"));
}

#[test]
fn test_std_module_compile_unit_accepts_builtin_decl() {
    let ast = parse_with_context(
        "defmod Bootstrap { @builtin def print(a: String) -> Unit }",
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("std module compile unit should accept builtin declarations");
    assert!(
        matches!(ast.as_slice(), [Ast::Defmod(_, name, body, _)] if name == "Global::Bootstrap"
            && matches!(body.as_slice(), [Ast::BuiltinDecl(..)]))
    );
}

#[test]
fn test_std_module_compile_unit_accepts_builtin_type_decl() {
    let ast = parse_with_context(
        "defmod Bootstrap { @builtin type Int }",
        ParserContext::module(1, None).with_rules(ParseRules::std_module()),
    )
    .expect("std module compile unit should accept builtin type declarations");
    assert!(
        matches!(ast.as_slice(), [Ast::Defmod(_, name, body, _)] if name == "Global::Bootstrap"
            && matches!(body.as_slice(), [Ast::BuiltinTypeDecl(_, BuiltinTypeHead { name: builtin_name, .. }, _)] if builtin_name == "Int"))
    );
}

#[test]
fn test_script_compile_unit_accepts_top_level_def_import_and_include() {
    let ast = parse_with_context(
        "include './mylib.srt'\ndef add(x: Int, y: Int) -> Int { x + y }\nimport Kernel::add;",
        ParserContext::script(1),
    )
    .expect("script compile unit should accept top-level def, include, and import");
    assert!(matches!(
        ast.as_slice(),
        [
            Ast::Include(_, include_path),
            Ast::Def(_, name, _, _, _, _, _, _),
            Ast::Import(_, AstPath { segments, .. }, ImportSpec::Single(import_name))
        ] if include_path == "./mylib.srt"
            && name == "add"
            && segments.as_slice() == ["Kernel"]
            && import_name == "add"
    ));
}

#[test]
fn test_script_compile_unit_accepts_namespace_types_traits_and_impls() {
    let ast = parse_with_context(
        r#"const LIMIT = 1

namespace Auth {
  defrecord User(name: String)
  defmod Repo {
    def load() -> Unit { () }
  }
}

deferror Oops(reason: String) { |reason: String| Self(message: reason, reason: reason) }

defenum Role { Admin }

deftrait Named {
  def name(self: Self) -> String
}

impl Auth::User {
  def rename(self: Self, next: String) -> Self { self }
}

impl Show for Auth::User {
  def to_string(self: Self) -> String { "ok" }
}"#,
        ParserContext::script(1),
    )
    .expect("script compile unit should accept widened top-level declarations");

    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::ConstDef(_, name, _, _, _) if name == "LIMIT")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::RecordDef(_, name, _, _) if name == "Auth::User")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::Defmod(_, name, _, _) if name == "Auth::Repo")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::DeferrorDef(_, name, _, _, _) if name == "Global::Oops")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::EnumDef(_, name, _, _, _) if name == "Global::Role")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::TraitDef(_, name, _, _, _, _) if name == "Named")));
    assert!(ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::ImplDef(_, target, _, _, _) if target == "Auth::User")));
    assert!(ast.iter().any(|stmt| matches!(
        stmt,
        Ast::TraitImplDef(_, trait_name, _, AstTy::Named(_, target), _, _, _)
            if trait_name == "Show" && target == "Auth::User"
    )));
}

#[test]
fn test_namespace_where_clause_keeps_trait_surface_references() {
    let ast = parse_with_context(
        r#"deftrait Equal {
  def equal(self: Self, rhs: Self) -> Boolean
}

deftrait Functor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

namespace Auth {
  deftrait Comparable
  where
    Self: Equal + Functor
  {
    def compare(self: Self, rhs: Self) -> Boolean
  }
}"#,
        ParserContext::script(1),
    )
    .expect("namespace trait constraints should parse");

    let clause = ast
        .iter()
        .find_map(|node| match node {
            Ast::TraitDef(_, name, _, Some(clause), _, _) if name == "Auth::Comparable" => {
                Some(clause)
            }
            _ => None,
        })
        .expect("namespaced Comparable where clause");
    assert!(matches!(
        clause.constraints[0].bounds.as_slice(),
        [
            WhereConstraintRhs::Trait(_, trait_name),
            WhereConstraintRhs::Trait(_, constructor_trait)
        ] if trait_name == "Equal" && constructor_trait == "Functor"
    ));
}

#[test]
fn test_module_compile_unit_rejects_top_level_include() {
    let err = parse_with_context("include './mylib.srt'", ParserContext::module(1, None))
        .expect_err("module compile unit should reject include");
    assert!(err
        .message()
        .contains("This top-level declaration is not allowed in the current source policy"));
}

#[test]
fn test_script_compile_unit_rejects_top_level_defmod() {
    let err = parse_with_context(
        "defmod User { def label() -> String { \"x\" } }",
        ParserContext::script(1),
    )
    .expect_err("script compile unit should reject explicit top-level defmod");
    assert!(err
        .message()
        .contains("defmod is not allowed at script top-level"));
}

#[test]
fn test_script_compile_unit_rejects_declaration_after_top_level_expression() {
    let err = parse_with_context(
        "print(\"start\")\ndefrecord User(name: String)",
        ParserContext::script(1),
    )
    .expect_err("script compile unit should reject declarations after expressions");
    assert!(err
        .message()
        .contains("top-level definition cannot appear after top-level expression"));
}

#[test]
fn test_repl_compile_unit_rejects_top_level_impl_block() {
    let err = parse_with_context(
        "impl User { def new(name: String) -> Self { User { name: name } } }",
        ParserContext::repl(1),
    )
    .expect_err("repl chunk should reject top-level impl declarations");
    assert!(err.message().contains("REPL"));
}

#[test]
fn test_repl_compile_unit_rejects_top_level_const() {
    let err = parse_with_context("const LIMIT = 1", ParserContext::repl(1))
        .expect_err("repl chunk should reject top-level const declarations");
    assert!(err.message().contains("REPL"));
}

#[test]
fn test_project_parser_context_sets_unit_kind() {
    let context = ParserContext::project(7);
    assert_eq!(context.unit_kind, ParseUnitKind::Project);
    assert_eq!(context.source_id, 7);
    assert_eq!(context.module_path, None);
}

#[test]
fn test_project_compile_unit_accepts_top_level_expression() {
    let ast = parse_with_context("x = 42", ParserContext::project(1))
        .expect("project compile unit should accept top-level expressions");
    assert!(matches!(ast.as_slice(), [Ast::Bind(_, _, _)]));
}

#[test]
fn test_project_compile_unit_rejects_top_level_defextractor() {
    let err = parse_with_context(
        "defextractor never(self: Int) -> MatchResult<Int> { MatchResult::Err(NoneError()) }",
        ParserContext::project(1),
    )
    .expect_err("project compile unit should reject top-level extractor declarations");
    assert!(err
        .message()
        .contains("This top-level declaration is not allowed in the current source policy"));
}

#[test]
fn test_declaration_inside_function_body_is_rejected() {
    let err = parse(
        r#"def outer() -> Unit {
  def inner() -> Unit { () }
}"#,
    )
    .expect_err("declaration inside expression level should be rejected");
    assert!(err
        .message()
        .contains("Declarations are only allowed at the top level"));
}

#[test]
fn test_constructor_like_capture_parses_and_is_left_for_later_validation() {
    let ast = parse("f = &Some").expect("constructor-like capture should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::Bind(_, _, rhs)]
            if matches!(rhs.as_ref(), Ast::Capture(_, target, args)
                if args.is_empty() && matches!(target.as_ref(), Ast::Var(_, name) if name == "Some"))
    ));
}

#[test]
fn test_assignment_is_rejected_in_argument_position() {
    let err = parse("f(x: y = 1)").expect_err("Expected parse error");
    assert!(err.message().contains("cannot appear in argument position"));
}

#[test]
fn test_many_top_level_declarations_parse_successfully() {
    let mut source = String::new();
    for idx in 0..256 {
        source.push_str(&format!("def value_{idx}() -> Int {{ {idx} }}\n"));
    }

    let ast = parse(&source).expect("many top-level declarations should parse");
    assert_eq!(ast.len(), 256);
}

#[test]
fn test_defagent_lowering_preserves_runtime_process_spec() {
    let ast = parse_with_context(
        r#"@doc """Counter agent docs."""
defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def fetch(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def replace(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defagent should parse");

    match &ast[0] {
        Ast::Defagent(_, name, body, process_spec, attrs) => {
            assert_eq!(name, "Global::Counter");
            assert_eq!(attrs.doc.as_deref(), Some("Counter agent docs."));
            assert_eq!(process_spec.process_name, "Global::Counter");
            assert_eq!(process_spec.kind, crate::ast::ProcessKind::Agent);
            assert_eq!(
                process_spec.instance,
                crate::ast::ProcessInstance::Singleton
            );
            assert!(!process_spec.boot);
            assert!(!process_spec.standby);
            assert!(process_spec.registry);

            let pid_wrapper = body
                .iter()
                .find(|node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "pid"))
                .expect("lowered module should include pid wrapper");
            match pid_wrapper {
                Ast::Def(_, _, _, params, Some(AstTy::Generic(_, ty_name, ty_args)), _, _, _) => {
                    assert!(params.is_empty());
                    assert_eq!(ty_name, "PID");
                    assert!(
                        matches!(ty_args.as_slice(), [AstTy::Named(_, inner)] if inner == "Global::Counter")
                    );
                }
                other => panic!("expected pid wrapper to return PID<Counter>, got {other:?}"),
            }

            assert!(body.iter().all(
                |node| !matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "spawn")
            ));

            let get_wrapper = body
                .iter()
                .find(|node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "fetch"))
                .expect("lowered module should include @get wrapper using the user function name");
            match get_wrapper {
                Ast::Def(_, _, _, params, _, _, _, _) => {
                    assert!(matches!(
                        params.as_slice(),
                        [ValueParameter { name, ty: AstTy::Named(_, ty_name), .. }]
                            if name == "_field" && ty_name == "String"
                    ));
                }
                other => panic!("expected get wrapper definition, got {other:?}"),
            }

            let set_wrapper = body
                .iter()
                .find(|node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "replace"))
                .expect("lowered module should include @set wrapper using the user function name");
            match set_wrapper {
                Ast::Def(_, _, _, params, Some(AstTy::Generic(_, ty_name, _)), _, _, _) => {
                    assert_eq!(ty_name, "Result");
                    assert!(matches!(
                        params.as_slice(),
                        [ValueParameter { name, ty: AstTy::Named(_, ty_name), .. }]
                            if name == "next" && ty_name == "Int"
                    ));
                }
                other => panic!("expected set wrapper definition, got {other:?}"),
            }

            assert_eq!(process_spec.handler_specs.len(), 3);
            assert_eq!(process_spec.handler_specs[0].name, "init");
            assert_eq!(process_spec.handler_specs[1].name, "fetch");
            assert_eq!(process_spec.handler_specs[2].name, "replace");
        }
        other => panic!("Expected Defagent, got {other:?}"),
    }
}

#[test]
fn test_defagent_parses_as_dedicated_process_ast_node() {
    let ast = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def fetch(state: Int, _field: String) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defagent should parse");

    match &ast[0] {
        Ast::Defagent(_, name, body, process_spec, attrs) => {
            assert_eq!(name, "Global::Counter");
            assert_eq!(attrs.doc, None);
            assert_eq!(process_spec.process_name, "Global::Counter");
            assert_eq!(process_spec.kind, crate::ast::ProcessKind::Agent);
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "fetch")
            ));
        }
        other => panic!("Expected Defagent, got {other:?}"),
    }
}

#[test]
fn test_process_meta_requires_explicit_init_policy() {
    for (kind, handler) in [
        (
            "defagent",
            "@get def read(state: Int) -> Result<Int> { Ok(state) }",
        ),
        (
            "defgenserver",
            "@call def read(state: Int) -> Result<CallResult<Int, Int>> { Ok(Reply(state, state)) }",
        ),
    ] {
        for instance in ["Singleton", "Worker"] {
            let source = format!(
                "{kind} Counter {{\n  meta {{\n    instance: {instance}\n    state: Int\n  }}\n  @init def init() -> Result<Int> {{ Ok(0) }}\n  {handler}\n}}"
            );
            let error = parse_with_context(&source, ParserContext::module(1, None))
                .expect_err("process meta must declare init_policy");
            assert_eq!(error.message(), "meta requires init_policy", "{source}");
            assert_eq!(
                error.reason(),
                crate::error::ParseErrorReason::DeclarationSyntax
            );
            assert_eq!(
                error.guidance(),
                Some(&crate::error::ParseErrorGuidance::MissingMetaInitPolicy)
            );
            assert_eq!(
                error.span(),
                &Span {
                    start: source.find("meta").unwrap(),
                    end: source.find("meta {").unwrap() + "meta {".len(),
                },
                "{source}"
            );
        }
    }
}

#[test]
fn test_defagent_accepts_standby_init_policy() {
    let ast = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Standby
    state: Int
  }

  @init
  def init() -> Result<StandbyInit<Int>> { Ok(Ready(0)) }

  @get
  def fetch(state: Int, _field: String) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("standby singleton agent should parse");

    match &ast[0] {
        Ast::Defagent(_, _, _, process_spec, _) => {
            assert!(process_spec.standby);
        }
        other => panic!("Expected Defagent, got {other:?}"),
    }
}

#[test]
fn test_defagent_rejects_legacy_lazy_init_policy() {
    let err = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Lazy
    state: Int
  }

  @init
  def init() -> Result<StandbyInit<Int>> { Ok(Ready(0)) }

  @get
  def fetch(state: Int, _field: String) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("legacy lazy init policy should be rejected");

    assert!(err
        .message()
        .contains("init_policy must be Eager or Standby"));
}

#[test]
fn test_defagent_rejects_standby_readonly_worker_agent() {
    let err = parse_with_context(
        r#"defagent CacheReader {
  meta {
    instance: Worker
    init_policy: Standby
    state: Int
  }

  @init
  def init() -> Result<StandbyInit<Int>> { Ok(Ready(0)) }

  @get
  def fetch(state: Int) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("standby read-only worker agent should be rejected");

    assert!(err
        .message()
        .contains("init_policy: Standby is only allowed for Singleton Agent"));
}

#[test]
fn test_defagent_meta_handlers_are_preserved_in_process_spec() {
    let ast = parse_with_context(
        r#"defagent Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
    handlers {
      out: OutHandler = StdOut
    }
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defagent should parse");

    match &ast[0] {
        Ast::Defagent(_, _, _, process_spec, _) => {
            assert!(matches!(
                &process_spec.state,
                crate::ast::AstTy::Named(_, name) if name == "Int"
            ));
            assert_eq!(process_spec.handlers.len(), 1);
            assert_eq!(process_spec.handlers[0].slot, "out");
            assert_eq!(process_spec.handlers[0].capability, "OutHandler");
            assert_eq!(process_spec.handlers[0].default_target.name, "StdOut");
        }
        other => panic!("Expected Defagent, got {other:?}"),
    }
}

#[test]
fn test_defgenserver_preserves_runtime_handler_specs() {
    let ast = parse_with_context(
        r#"defgenserver Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def info(state: Int, message: String) -> Result<(String, Int)> {
    Ok((message, state))
  }

  @cast
  def reset(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defgenserver should parse");

    match &ast[0] {
        Ast::Defgenserver(_, _, _, process_spec, _) => {
            assert_eq!(process_spec.kind, crate::ast::ProcessKind::GenServer);
            assert_eq!(process_spec.handler_specs.len(), 3);
            assert_eq!(process_spec.handler_specs[0].name, "init");
            assert_eq!(
                process_spec.handler_specs[0].kind,
                crate::ast::ProcessRuntimeHandlerKind::Init
            );
            assert_eq!(process_spec.handler_specs[1].name, "info");
            assert_eq!(
                process_spec.handler_specs[1].kind,
                crate::ast::ProcessRuntimeHandlerKind::Call
            );
            assert_eq!(process_spec.handler_specs[2].name, "reset");
            assert_eq!(
                process_spec.handler_specs[2].kind,
                crate::ast::ProcessRuntimeHandlerKind::Cast
            );
        }
        other => panic!("Expected Defgenserver, got {other:?}"),
    }
}

#[test]
fn test_process_meta_requires_state() {
    let err = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int) -> Result<Int> { Ok(state) }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("process meta without state should fail");

    assert!(err.message().contains("meta requires state"));
}

#[test]
fn test_defgenserver_preserves_multiple_call_and_cast_handler_specs() {
    let ast = parse_with_context(
        r#"defgenserver Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def info(state: Int, message: String) -> Result<(String, Int)> {
    Ok((message, state))
  }

  @call
  def count(state: Int) -> Result<(Int, Int)> {
    Ok((state, state))
  }

  @cast
  def reset(_state: Int, next: Int) -> Result<Int> { Ok(next) }

  @cast
  def increment(state: Int) -> Result<Int> { Ok(state + 1) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defgenserver should parse multiple call and cast handlers");

    match &ast[0] {
        Ast::Defgenserver(_, _, body, process_spec, _) => {
            assert_eq!(process_spec.kind, crate::ast::ProcessKind::GenServer);
            assert_eq!(process_spec.handler_specs.len(), 5);
            assert_eq!(process_spec.handler_specs[0].name, "init");
            assert_eq!(process_spec.handler_specs[1].name, "info");
            assert_eq!(process_spec.handler_specs[2].name, "count");
            assert_eq!(process_spec.handler_specs[3].name, "reset");
            assert_eq!(process_spec.handler_specs[4].name, "increment");
            assert_eq!(
                process_spec.handler_specs[1].kind,
                crate::ast::ProcessRuntimeHandlerKind::Call
            );
            assert_eq!(
                process_spec.handler_specs[2].kind,
                crate::ast::ProcessRuntimeHandlerKind::Call
            );
            assert_eq!(
                process_spec.handler_specs[3].kind,
                crate::ast::ProcessRuntimeHandlerKind::Cast
            );
            assert_eq!(
                process_spec.handler_specs[4].kind,
                crate::ast::ProcessRuntimeHandlerKind::Cast
            );
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "info")
            ));
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "count")
            ));
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "reset")
            ));
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "increment")
            ));
        }
        other => panic!("Expected Defgenserver, got {other:?}"),
    }
}

fn process_execution_statements(body: &Ast) -> &[Ast] {
    let Ast::Block(_, outer) = body else {
        panic!("process wrapper must be a block");
    };
    let Ast::App(_, callee, args) = outer.last().expect("wrapper result") else {
        panic!("process wrapper must end at the common execution boundary");
    };
    assert!(matches!(callee.as_ref(), Ast::InternalVar(_, name) if name == "__process_execute"));
    let [RecordLitArg::Positional(Ast::Var(_, pid)), RecordLitArg::Positional(Ast::Closure(_, params, callback))] =
        args.as_slice()
    else {
        panic!(
            "execution boundary must receive the target PID and a zero-argument wrapper closure"
        );
    };
    assert_eq!(pid, "pid");
    assert!(params.is_empty());
    let Ast::Block(_, stmts) = callback.as_ref() else {
        panic!("wrapper callback must contain state reading and all postprocessing");
    };
    assert!(matches!(stmts.first(), Some(Ast::SafeBind(_, _, rhs, _))
        if matches!(rhs.as_ref(), Ast::App(_, callee, _)
            if matches!(callee.as_ref(), Ast::InternalVar(_, name)
                if name == "Agent::state" || name == "GenServer::state"))));
    stmts
}

#[test]
fn test_process_message_wrappers_use_common_execution_boundary() {
    for (kind, instance, handlers, wrappers) in [
        ("defagent", "Singleton", "@get def read(state: Int) -> Result<Int> { Ok(state) }", vec!["read"]),
        ("defagent", "Singleton", "@get def read(state: Int) -> Result<Int> { Ok(state) } @set def write(_state: Int, next: Int) -> Result<Int> { Ok(next) }", vec!["read", "write"]),
        ("defagent", "Worker", "@get def read(state: Int) -> Result<Int> { Ok(state) } @set def write(_state: Int, next: Int) -> Result<Int> { Ok(next) }", vec!["read", "write"]),
        ("defgenserver", "Singleton", "@call def read(state: Int) -> Result<CallResult<Int, Int>> { Ok(Reply(state, state)) } @cast def write(_state: Int, next: Int) -> Result<CastResult<Int>> { Ok(Next(next)) }", vec!["read", "write"]),
        ("defgenserver", "Worker", "@call def read(state: Int) -> Result<CallResult<Int, Int>> { Ok(Reply(state, state)) } @cast def write(_state: Int, next: Int) -> Result<CastResult<Int>> { Ok(Next(next)) }", vec!["read", "write"]),
    ] {
        let handlers = handlers
            .replace("@get def", "\n@get\ndef")
            .replace("@set def", "\n@set\ndef")
            .replace("@call def", "\n@call\ndef")
            .replace("@cast def", "\n@cast\ndef");
        let source = format!("{kind} Counter {{\nmeta {{\ninstance: {instance}\ninit_policy: Eager\nstate: Int\n}}\n@init\ndef boot() -> Result<Int> {{ Ok(0) }}\n{handlers}\n}}");
        let ast = parse_with_context(&source, ParserContext::module(1, None))
            .expect("process declaration");
        let body = match &ast[0] {
            Ast::Defagent(_, _, body, _, _) | Ast::Defgenserver(_, _, body, _, _) => body,
            other => panic!("expected process declaration, got {other:?}"),
        };
        for wrapper in wrappers {
            let wrapper_body = body.iter().find_map(|node| match node {
                Ast::Def(_, name, _, _, _, _, body, _) if name == wrapper => Some(body.as_ref()),
                _ => None,
            }).expect("generated message wrapper");
            let stmts = process_execution_statements(wrapper_body);
            assert!(matches!(stmts, [Ast::SafeBind(..), Ast::SafeBind(..), Ast::App(_, marker, args), _]
                if matches!(marker.as_ref(), Ast::InternalVar(_, name) if name == "__process_postprocess")
                    && matches!(args.as_slice(), [RecordLitArg::Positional(Ast::Var(_, name))] if name == "pid")),
                "state read, successful handler result, postprocessing transition, and final result must occur in order");
            if kind == "defagent" && wrapper == "read" {
                assert!(matches!(stmts.last(), Some(Ast::ConstructorCall(_, name, args))
                    if name == "Global::Result::Ok"
                        && matches!(args.as_slice(), [RecordLitArg::Positional(Ast::Var(_, reply))] if reply == "reply")),
                    "Agent success must use the canonical payload constructor call");
            }
        }
    }
}

#[test]
fn test_defagent_worker_init_route_is_public_surface() {
    let ast = parse_with_context(
        r#"defagent Worker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("worker defagent should parse");

    match &ast[0] {
        Ast::Defagent(_, name, body, _, _) => {
            assert_eq!(name, "Global::Worker");
            assert!(body.iter().all(
                |node| !matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "pid")
            ));
            let init_wrapper = body
                .iter()
                .find(
                    |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "init"),
                )
                .expect("worker agent should include init wrapper");
            let set_wrapper = body
                .iter()
                .find(
                    |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "set"),
                )
                .expect("worker agent should include set wrapper");
            match init_wrapper {
                Ast::Def(
                    _,
                    _,
                    _,
                    params,
                    Some(AstTy::Generic(_, ty_name, ty_args)),
                    _,
                    body,
                    _,
                ) => {
                    assert_eq!(params.len(), 1);
                    assert!(
                        ty_name == "Result"
                            && matches!(
                                ty_args.as_slice(),
                                [AstTy::Generic(_, inner_name, inner_args)]
                                    if inner_name == "PID"
                                        && matches!(inner_args.as_slice(), [AstTy::Named(_, process_name)] if process_name == "Global::Worker")
                            )
                    );
                    assert!(matches!(
                        body.as_ref(),
                        Ast::Block(_, stmts)
                            if matches!(
                                stmts.as_slice(),
                                [Ast::App(_, callee, _)]
                                    if matches!(
                                        callee.as_ref(),
                                        Ast::Path(_, path)
                                            if path.segments.as_slice() == ["DynamicSupervisor", "spawn"]
                                    )
                            )
                    ));
                }
                other => {
                    panic!("expected init wrapper to return Result<PID<Worker>>, got {other:?}")
                }
            }
            match set_wrapper {
                Ast::Def(_, _, _, _, _, _, body, _) => {
                    let execution_body = Ast::Block(
                        body.span().clone(),
                        process_execution_statements(body).to_vec(),
                    );
                    assert!(matches!(
                        &execution_body,
                        Ast::Block(_, stmts)
                            if stmts.iter().any(|stmt| matches!(
                                    stmt,
                                    Ast::SafeBind(_, _, rhs, _)
                                        if matches!(
                                            rhs.as_ref(),
                                            Ast::App(_, callee, _)
                                                if matches!(
                                                    callee.as_ref(),
                                                    Ast::InternalVar(_, name)
                                                        if name == "Agent::state"
                                                )
                                        )
                                ))
                                && stmts.iter().any(|stmt| matches!(
                                    stmt,
                                    Ast::App(_, callee, _)
                                        if matches!(
                                            callee.as_ref(),
                                            Ast::InternalVar(_, name)
                                                if name == "Agent::store"
                                        )
                                ))
                    ));
                }
                other => panic!("expected set wrapper body, got {other:?}"),
            }
        }
        other => panic!("Expected Defagent, got {other:?}"),
    }
}

#[test]
fn test_defgenserver_worker_init_route_uses_user_defined_name() {
    let ast = parse_with_context(
        r#"defgenserver QueueServer {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def boot(seed: Int) -> Result<Int> { Ok(seed) }

  @call
  def size(state: Int) -> Result<(Int, Int)> {
    Ok((state, state))
  }

  @cast
  def reset(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ParserContext::module(1, None),
    )
    .expect("worker defgenserver should parse");

    match &ast[0] {
        Ast::Defgenserver(_, name, body, _, _) => {
            assert_eq!(name, "Global::QueueServer");
            let init_wrapper = body
                .iter()
                .find(|node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "boot"))
                .expect("worker genserver should expose @init name as public surface");
            assert!(body.iter().all(
                |node| !matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "spawn")
            ));
            let size_wrapper = body
                .iter()
                .find(|node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "size"))
                .expect("worker genserver should include @call wrapper");
            match init_wrapper {
                Ast::Def(
                    _,
                    _,
                    _,
                    params,
                    Some(AstTy::Generic(_, ty_name, ty_args)),
                    _,
                    body,
                    _,
                ) => {
                    assert_eq!(params.len(), 1);
                    assert!(
                        ty_name == "Result"
                            && matches!(
                                ty_args.as_slice(),
                                [AstTy::Generic(_, inner_name, inner_args)]
                                    if inner_name == "PID"
                                        && matches!(inner_args.as_slice(), [AstTy::Named(_, process_name)] if process_name == "Global::QueueServer")
                            )
                    );
                    assert!(matches!(
                        body.as_ref(),
                        Ast::Block(_, stmts)
                            if matches!(
                                stmts.as_slice(),
                                [Ast::App(_, callee, _)]
                                    if matches!(
                                        callee.as_ref(),
                                        Ast::Path(_, path)
                                            if path.segments.as_slice() == ["DynamicSupervisor", "spawn"]
                                    )
                            )
                    ));
                }
                other => panic!(
                    "expected worker genserver init wrapper to return Result<PID<QueueServer>>, got {other:?}"
                ),
            }
            match size_wrapper {
                Ast::Def(_, _, _, params, _, _, _, _) => {
                    assert!(matches!(
                        params.as_slice(),
                        [ValueParameter { name, ty: AstTy::Generic(_, ty_name, ty_args), .. }]
                            if name == "pid"
                                && ty_name == "PID"
                                && matches!(ty_args.as_slice(), [AstTy::Named(_, process_name)] if process_name == "Global::QueueServer")
                    ));
                }
                other => panic!(
                    "expected worker genserver call wrapper with pid receiver, got {other:?}"
                ),
            }
        }
        other => panic!("Expected Defgenserver, got {other:?}"),
    }
}

#[test]
fn test_defsupervisor_generates_compiler_managed_surface_from_policy_meta() {
    let ast = parse_with_context(
        r#"defsupervisor AppSup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect("defsupervisor should parse");

    match &ast[0] {
        Ast::Defsupervisor(_, name, body, process_spec, _) => {
            assert_eq!(name, "Global::AppSup");
            assert_eq!(process_spec.kind, crate::ast::ProcessKind::Supervisor);
            assert!(body.iter().any(
                |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "__agent_init")
            ));
            let generated_defs = body
                .iter()
                .filter_map(|node| match node {
                    Ast::Def(_, def_name, _, _, _, _, _, _) => Some(def_name.as_str()),
                    _ => None,
                })
                .collect::<Vec<_>>();
            assert!(generated_defs.contains(&"spawn"));
            assert!(generated_defs.contains(&"adopt"));
            assert!(generated_defs.contains(&"status"));
            assert!(generated_defs.contains(&"workers"));
            let spawn_wrapper = body
                .iter()
                .find(
                    |node| matches!(node, Ast::Def(_, def_name, _, _, _, _, _, _) if def_name == "spawn"),
                )
                .expect("supervisor should include spawn wrapper");
            match spawn_wrapper {
                Ast::Def(_, _, _, _, _, _, body, _) => {
                    assert!(matches!(
                        body.as_ref(),
                        Ast::Block(_, stmts)
                            if matches!(
                                stmts.as_slice(),
                                [Ast::App(_, callee, args)]
                                    if args.len() == 2
                                        && matches!(
                                            callee.as_ref(),
                                            Ast::InternalVar(_, name)
                                                if name == "Supervisor::spawn"
                                        )
                            )
                    ));
                }
                other => panic!("expected spawn wrapper body, got {other:?}"),
            }
        }
        other => panic!("Expected Defsupervisor, got {other:?}"),
    }
}

#[test]
fn test_defsupervisor_rejects_process_meta_keys_and_manual_surface_defs() {
    let err = parse_with_context(
        r#"defsupervisor AppSup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }

  def spawn(worker_init: (-> Result<Int>)) -> Result<PID<$Process>> { Ok(Process::self()) }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("manual supervisor spawn should be rejected");

    assert!(err.message().contains("spawn"));
    assert!(err.message().contains("compiler-managed"));
}

#[test]
fn test_defsupervisor_rejects_instance_and_init_policy_meta_keys() {
    let err = parse_with_context(
        r#"defsupervisor AppSup {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("legacy process meta should be rejected for supervisors");

    assert!(
        err.message().contains("policy"),
        "unexpected error: {err:?}"
    );
}

#[test]
fn test_defagent_rejects_compiler_managed_surface_names() {
    let err = parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int) -> Result<Int> { Ok(state) }

  defp spawn() -> Int { 1 }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("compiler-managed process surface name should be reserved");

    assert!(err.message().contains("compiler-managed"));
    assert!(err.message().contains("spawn"));
}

#[test]
fn test_defgenserver_rejects_compiler_managed_surface_names() {
    let err = parse_with_context(
        r#"defgenserver CounterServer {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def view(state: Int) -> Result<(Int, Int)> { Ok((state, state)) }

  defp workers() -> Int { 1 }
}"#,
        ParserContext::module(1, None),
    )
    .expect_err("compiler-managed process surface name should be reserved");

    assert!(err.message().contains("compiler-managed"));
    assert!(err.message().contains("workers"));
}

#[test]
fn test_supervisor_init_parses_entries_in_any_order() {
    let ast = parse_with_context(
        r#"supervisor_init {
  ImageWorkerSupervisor {
    max_restarts: 10
    allow_adopt: True
  }

  Logger {
    timeout: 5s
    handlers {
      out: FileOutHandler(path: "./logs/app.log")
      err: NullOutHandler
    }
  }

  DynamicSupervisor {}
}"#,
        ParserContext::project(1),
    )
    .expect("supervisor_init should parse");

    match &ast[0] {
        Ast::SupervisorInit(_, spec) => {
            assert_eq!(spec.entries.len(), 3);
            let supervisor = &spec.entries[0];
            assert_eq!(supervisor.process_name, "ImageWorkerSupervisor");
            assert_eq!(supervisor.overrides.max_restarts, Some(10));
            assert_eq!(supervisor.overrides.allow_adopt, Some(true));

            let logger = &spec.entries[1];
            assert_eq!(logger.process_name, "Logger");
            assert_eq!(logger.timeout_ms, Some(5_000));
            assert_eq!(logger.handlers.len(), 2);
            assert_eq!(logger.handlers[0].slot, "out");
            assert_eq!(logger.handlers[0].target.name, "FileOutHandler");
            assert_eq!(logger.handlers[0].target.named_args[0].name, "path");
            assert_eq!(
                logger.handlers[0].target.named_args[0].value,
                "./logs/app.log"
            );
            assert_eq!(logger.handlers[1].slot, "err");
            assert_eq!(logger.handlers[1].target.name, "NullOutHandler");

            let dynsup = &spec.entries[2];
            assert_eq!(dynsup.process_name, "DynamicSupervisor");
            assert_eq!(dynsup.timeout_ms, None);
            assert!(dynsup.handlers.is_empty());
            assert_eq!(dynsup.overrides, Default::default());
        }
        other => panic!("expected SupervisorInit, got {other:?}"),
    }
}

#[test]
fn test_supervisor_init_rejects_duplicate_entry() {
    let err = parse_with_context(
        r#"supervisor_init {
  Logger {}
  Logger {}
}"#,
        ParserContext::project(1),
    )
    .expect_err("duplicate supervisor_init entries should fail");

    assert!(err
        .message()
        .contains("supervisor_init entry is duplicated"));
}

#[test]
fn test_supervisor_init_rejects_legacy_singleton_keyword() {
    let err = parse_with_context(
        r#"supervisor_init {
  singleton Logger {}
}"#,
        ParserContext::project(1),
    )
    .expect_err("legacy singleton keyword should fail");

    assert!(err
        .message()
        .contains("`singleton` keyword is no longer used"));
}

#[test]
fn test_supervisor_init_rejects_parent_override() {
    let err = parse_with_context(
        r#"supervisor_init {
  AppSup {
    parent: RootSupervisor
  }
}"#,
        ParserContext::project(1),
    )
    .expect_err("parent override should be rejected");

    assert!(err.message().contains("parent"));
}

#[test]
fn test_task_timeout_literal_parses_in_project_context() {
    let ast = parse_with_context(
        r#"value = Task::call({|| Ok(())}) @timeout(100ms)"#,
        ParserContext::project(1),
    )
    .expect("task timeout literal should parse");
    assert!(!ast.is_empty());
}

#[test]
fn test_workers_submit_timeout_literal_parses_in_project_context() {
    let ast = parse_with_context(
        r#"value = Workers::submit(workers, Worker::assign(job)) @timeout(100ms)"#,
        ParserContext::project(1),
    )
    .expect("workers submit timeout literal should parse");
    assert!(!ast.is_empty());
}

#[test]
fn test_task_await_timeout_literal_parses_in_project_context() {
    let ast = parse_with_context(
        r#"value = Task::await(task) @timeout(100ms)"#,
        ParserContext::project(1),
    )
    .expect("task await timeout literal should parse");
    assert!(!ast.is_empty());
}

#[test]
fn test_explicit_type_arguments_parse_on_calls_and_captures() {
    let ast = parse(
        r#"value = TryConvert::try_to::<Int>("1")
fn = &TryConvert::try_to::<Int>"#,
    )
    .expect("explicit type arguments should parse");

    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::App(_, callee, _)
                if matches!(callee.as_ref(), Ast::ReturnTypeArgumentApply(_, target, args)
                    if matches!(target.as_ref(), Ast::Path(_, _))
                        && matches!(args.as_slice(), [argument] if matches!(argument.ty, AstTy::Named(_, ref name) if name == "Int"))))
    ));
    assert!(matches!(
        &ast[1],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::Capture(_, target, args)
                if args.is_empty()
                    && matches!(target.as_ref(), Ast::ReturnTypeArgumentApply(_, _, type_args)
                        if type_args.len() == 1))
    ));
}

#[test]
fn enum_constructor_type_arguments_parse_separately_from_callable_type_arguments() {
    let ast = parse(
        r#"left = Either<_, Int>::Left("term")
none = Option<Int>::None
nested = Either<List<Int>, Result<String>>::Left([1])
multiline = Either<
  _,
  Int
>::Left("line")"#,
    )
    .expect("enum constructor type arguments should parse");

    assert!(matches!(
        &ast[0],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::EnumConstructorCall(_, owner, type_args, variant, args)
                if owner == "Either"
                    && variant == "Left"
                    && type_args.len() == 2
                    && matches!(&type_args[0], AstTy::Named(_, name) if name == "_")
                    && args.len() == 1)
    ));
    assert!(matches!(
        &ast[1],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::EnumConstructorCall(_, owner, type_args, variant, args)
                if owner == "Option"
                    && variant == "None"
                    && type_args.len() == 1
                    && args.is_empty())
    ));
    assert!(matches!(
        &ast[2],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::EnumConstructorCall(_, owner, type_args, variant, _)
                if owner == "Either"
                    && variant == "Left"
                    && matches!(&type_args[0], AstTy::Generic(_, name, _) if name == "List")
                    && matches!(&type_args[1], AstTy::Generic(_, name, _) if name == "Result"))
    ));
    assert!(matches!(
        &ast[3],
        Ast::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Ast::EnumConstructorCall(_, owner, type_args, variant, _)
                if owner == "Either"
                    && variant == "Left"
                    && type_args.len() == 2
                    && matches!(&type_args[0], AstTy::Named(_, name) if name == "_"))
    ));
}

#[test]
fn canonical_return_type_arguments_and_value_parameters_are_preserved() {
    let parsed = parse(
        r#"def identity::<$A>(value: $A) -> $A { value }
call = identity::<Int>(1)"#,
    )
    .expect("canonical signature roles should parse");

    match parsed.as_slice() {
        [Ast::Def(_, _, return_type_arguments, value_parameters, ..), ..] => {
            assert_eq!(return_type_arguments.len(), 1);
            assert_eq!(value_parameters.len(), 1);
        }
        other => panic!("expected definition with canonical parameter roles: {other:?}"),
    }

    let call = match &parsed[1] {
        Ast::Bind(_, _, rhs) => match rhs.as_ref() {
            Ast::App(_, callee, _) => callee.as_ref(),
            other => panic!("expected call expression, got {other:?}"),
        },
        other => panic!("expected call binding, got {other:?}"),
    };
    assert!(matches!(
        call,
        Ast::ReturnTypeArgumentApply(_, _, ref args) if args.len() == 1
    ));
}

#[test]
fn definition_return_type_arguments_reject_empty_lists() {
    let error = parse(r#"def make::<>() -> Int { 0 }"#)
        .expect_err("empty definition return type argument lists should fail");

    assert!(error
        .message()
        .contains("return type argument list must not be empty"));
}

#[test]
fn definition_return_type_arguments_reject_duplicate_abstract_inputs() {
    let error = parse(r#"def make::<$A, $A>() -> $A { panic("test") }"#)
        .expect_err("duplicate definition return type arguments should fail");

    assert!(
        error
            .message()
            .contains("return type argument `$A` is duplicated"),
        "{}",
        error.message()
    );
}

#[test]
fn definition_return_type_arguments_reject_concrete_or_composite_items() {
    let error = parse(r#"def zeros::<List<$T>>() -> List<$T> { [] }"#)
        .expect_err("composite definition return type arguments should fail");

    assert!(error
        .message()
        .contains("return type arguments must declare abstract type inputs"));
}

#[test]
fn definition_return_type_arguments_reject_inline_constraints_at_the_bound() {
    let source = r#"def stop::<$F: Monad>() -> $F<Unit> { panic("test") }"#;
    let error =
        parse(source).expect_err("inline definition return type argument constraints should fail");

    assert!(
        error
            .message()
            .contains("inline constraints are not allowed in return type arguments"),
        "{}",
        error.message()
    );
    assert_eq!(&source[error.span().start..error.span().end], "Monad");
}

#[test]
fn trait_impl_return_type_arguments_accept_concrete_substitutions() {
    parse(
        r#"deftrait Factory {
  def make::<$A>() -> $A
}
impl Factory for Int {
  def make::<List<Int>>() -> List<Int> { [] }
}"#,
    )
    .expect("trait impl methods may spell contract-substituted concrete RTA structure");
}

#[test]
fn callable_signatures_accept_type_constructor_variable_applications() {
    let parsed = parse(
        r#"def valid(value: $F<$A>, mapper: ($A -> $B)) -> $F<$B>
where
  $F: Functor
{
  value
}"#,
    )
    .expect("constructor variables should apply recursively in callable signatures");

    assert!(matches!(
        parsed.as_slice(),
        [Ast::Def(_, _, _, parameters, Some(AstTy::Generic(_, return_head, _)), ..)]
            if matches!(&parameters[0].ty, AstTy::Generic(_, parameter_head, _) if parameter_head == "$F")
                && return_head == "$F"
    ));
}

#[test]
fn type_constructor_variable_applications_remain_rejected_outside_callable_signatures() {
    for source in ["value: $F<$A> = []", "defstruct Invalid { value: $F<$A> }"] {
        let error =
            parse(source).expect_err("constructor variable applications are signature-only syntax");
        assert!(
            error.message().contains(
                "type constructor variables may only be applied in callable signatures or nominal fields with an explicit declaration constraint"
            ),
            "{source}: {}",
            error.message()
        );
    }
}

#[test]
fn bounded_nominal_constructor_parameters_apply_in_declared_fields_and_payloads() {
    parse(
        r#"defstruct Wrapped<$M, $A> where $M: Monad { value: $M<$A> }
defenum Layer<$M, $A> where $M: Monad { Layer($M<Option<$A>>), }"#,
    )
    .expect("a constrained declaration parameter should apply in its own nominal definition");
}

#[test]
fn declaration_constraints_use_where_instead_of_inline_bounds() {
    for source in [
        "deftrait MonadT<$M: Monad> {}",
        "deftrait MonadT<Monad> {}",
        "defstruct OptionT<$M: Monad, $A> { inner: $A }",
        "defenum Layer<$M: Monad, $A> { Layer($A), }",
    ] {
        let error = parse(source).expect_err("inline declaration constraints must be rejected");
        assert!(
            error.message().contains("where $M: Monad"),
            "unexpected error for {source}: {error}"
        );
    }

    parse(
        r#"deftrait MonadT<$M>
where
  $M: Monad
{}

defstruct OptionT<$M, $A>
where
  $M: Monad
{
  inner: $M<$A>
}

defenum Layer<$M, $A>
where
  $M: Monad
{
  Layer($M<$A>),
}"#,
    )
    .expect("declaration binders and constraints should be separate");
}

#[test]
fn unbounded_nominal_parameters_do_not_gain_constructor_application_syntax() {
    let error = parse("defstruct Invalid<$M, $A> { value: $M<$A> }")
        .expect_err("a nominal parameter needs an explicit declaration constraint");
    assert!(
        error
            .message()
            .contains("type constructor variables may only be applied in callable signatures or nominal fields with an explicit declaration constraint"),
        "{}",
        error.message()
    );
}

#[test]
fn test_explicit_type_arguments_reject_empty_self_constructor_and_repetition() {
    for source in [
        "id::<>()",
        "id::<Self>()",
        "List::<Int>(1)",
        "id::<Int>::<String>(1)",
    ] {
        assert!(parse(source).is_err(), "{source} should fail");
    }
}

#[test]
fn test_list_monoid_helpers_parse() {
    parse(
        r#"defstruct Monoid<$A> { empty: $A, combine: ($A, $A -> $A) }
impl List {
  def fold(values: List<$A>, monoid: Monoid<$A>) -> $A { reduce(values, monoid.empty, monoid.combine) }
  def fold_map(values: List<$A>, monoid: Monoid<$B>, mapper: ($A -> $B)) -> $B { combine = monoid.combine
    reduce(values, monoid.empty, {|acc, value| combine(acc, mapper(value))}) }
  def reduce_with(values: List<$A>, combine: ($A, $A -> $A)) -> Option<$A> { match values { [] => Option::None, [head, ..tail] => Option::Some(reduce(tail, head, combine)), } }
}"#,
    )
    .expect("Monoid List helpers should parse");
}

#[test]
fn test_function_signature_type_alias_parses() {
    let ast = parse("type Mapper<$A, $B> = ($A -> $B)").expect("signature alias should parse");
    assert!(matches!(
        ast.as_slice(),
        [Ast::TypeAlias(_, name, params, AstTy::Func(_, _, _))]
            if name == "Mapper" && params.len() == 2
    ));
}

#[test]
fn do_expression_preserves_carrier_and_statement_kinds() {
    let source = r#"result = do::<Either<String, _>> {
  value <- source
  parsed =? parse(value)
  cached = source
  finish(parsed, cached)
}"#;
    let ast = parse(source).expect("do expression should parse");

    let Ast::Bind(_, _, rhs) = &ast[0] else {
        panic!("expected outer binding");
    };
    let Ast::Do(_, return_type_arguments, statements, _) = rhs.as_ref() else {
        panic!("expected do expression, got {rhs:?}");
    };
    assert!(matches!(
        return_type_arguments.as_slice(),
        [ReturnTypeArgument {
            ordinal: 0,
            ty: AstTy::Generic(_, name, args),
            ..
        }] if name == "Either"
            && matches!(args.as_slice(), [AstTy::Named(_, left), AstTy::Named(_, hole)] if left == "String" && hole == "_")
    ));
    assert!(matches!(
        statements.as_slice(),
        [
            AstDoStatement::Extract { .. },
            AstDoStatement::SafeBind { .. },
            AstDoStatement::Statement(Ast::Bind(..)),
            AstDoStatement::Statement(Ast::App(..)),
        ]
    ));
    let AstDoStatement::Extract { operator_span, .. } = &statements[0] else {
        unreachable!()
    };
    assert_eq!(&source[operator_span.start..operator_span.end], "<-");
    let AstDoStatement::SafeBind { operator_span, .. } = &statements[1] else {
        unreachable!()
    };
    assert_eq!(&source[operator_span.start..operator_span.end], "=?");
}

#[test]
fn do_expression_preserves_annotated_safebind_pattern() {
    let source = r#"result = do::<Result> {
  value: Int =? source
  Result::Ok(value)
}"#;
    let ast = parse(source).expect("annotated do SafeBind should parse");
    let Ast::Bind(_, _, rhs) = &ast[0] else {
        panic!("expected outer binding");
    };
    let Ast::Do(_, _, statements, _) = rhs.as_ref() else {
        panic!("expected do expression");
    };
    assert!(matches!(
        statements.as_slice(),
        [
            AstDoStatement::SafeBind {
                pattern: AstPattern::Annotated(_, name, AstTy::Named(_, ty)),
                ..
            },
            AstDoStatement::Statement(_),
        ] if name == "value" && ty == "Int"
    ));
}

#[test]
fn do_expression_accepts_omitted_hole_head_and_full_carriers() {
    for source in [
        "do { finish() }",
        "do::<_> { finish() }",
        "do::<Option> { finish() }",
        "do::<Either<String, Int>> { finish() }",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error}"));
        assert!(matches!(ast.as_slice(), [Ast::Do(..)]), "{source}: {ast:?}");
    }
}

#[test]
fn do_expression_rejects_noncanonical_carrier_syntax_and_arity() {
    let cases = [
        (
            "do<Option> { finish() }",
            "not valid carrier syntax",
            ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
            "<Option>",
        ),
        (
            "do::<> { finish() }",
            "cannot be empty",
            ParseErrorReason::ReturnTypeArgumentArityMismatch,
            "::<>",
        ),
        (
            "do::<Option, List> { finish() }",
            "exactly one",
            ParseErrorReason::ReturnTypeArgumentArityMismatch,
            "::<Option, List>",
        ),
        (
            "do::<$F> { finish() }",
            "outer constructor variable",
            ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
            "$F",
        ),
        (
            "do::<(Int, Int)> { finish() }",
            "constructor head, applied carrier",
            ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
            "(Int, Int)",
        ),
        (
            "do::<(Int -> Int)> { finish() }",
            "constructor head, applied carrier",
            ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
            "(Int -> Int)",
        ),
    ];
    for (source, expected, reason, expected_span) in cases {
        let error = parse(source).expect_err(source);
        assert!(
            error.message().contains(expected),
            "source={source:?}, error={error}"
        );
        assert_eq!(error.reason(), reason, "source={source:?}");
        assert_eq!(
            &source[error.span().start..error.span().end],
            expected_span,
            "source={source:?}"
        );
    }
}

#[test]
fn do_pattern_statements_accept_semicolon_separators_and_nested_do() {
    parse("do { value <- source; finish(value) }")
        .expect("extract should accept an explicit separator");
    parse("do { value =? source; do { nested =? value; finish(nested) } }")
        .expect("SafeBind should stay owned by each enclosing do block");
}

#[test]
fn do_keyword_is_reserved_except_for_the_compiler_owned_intrinsic_surface() {
    let mut context = ParserContext::module(0, None);
    context.parse_rules = ParseRules::permissive_for_tests();
    parse_with_context(
        "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>",
        context,
    )
    .expect("canonical compiler-owned intrinsic declaration should parse");
    parse("def do() -> Unit { () }").expect_err("ordinary callable name must stay reserved");
    parse("do = 1").expect_err("ordinary variable name must stay reserved");
}

#[test]
fn tolerant_parser_classifies_do_as_a_keyword_and_keeps_the_do_ast() {
    let source = "do { finish() }";
    let result = parse_tolerant_with_context(source, ParserContext::default(), None);
    assert!(result.diagnostics.is_empty(), "{:?}", result.diagnostics);
    assert!(matches!(result.ast.as_slice(), [Ast::Do(..)]));
    assert!(matches!(
        result.tokens.first(),
        Some(SyntaxToken {
            kind: SyntaxTokenKind::Keyword,
            span: Span { start: 0, end: 2 },
        })
    ));
}

#[test]
fn do_expression_requires_final_value_expression() {
    for source in [
        "do {}",
        "do { value <- source }",
        "do { value =? source }",
        "do { value = source }",
        "do { source; }",
    ] {
        let error = parse(source).expect_err(source);
        assert!(
            error.message().contains("final monadic expression"),
            "source={source:?}, error={error}"
        );
    }
}

#[test]
fn left_arrow_remains_owned_by_enclosing_syntax() {
    parse("do { value <- source\nfinish(value) }").expect("do owns extract arrow");
    parse(
        r#"Facet::bulk_update(user) {
  name <- set("new")
}"#,
    )
    .expect("Facet bulk_update keeps owning update arrows");
    parse(
        r#"Facet::bulk_update(user) {
  name <- set(do { set("new") })
}"#,
    )
    .expect_err("a nested operation call inside do must still be rejected by bulk_update");
    parse("value <- source").expect_err("left arrow outside an owner must be rejected");
}

#[test]
fn extractor_accepts_multiple_inputs_and_expression_prearguments() {
    parse_with_context("defmod Bounds { defextractor between(min: Int, max: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) } }", ParserContext::project(0)).expect("multiple Extractor inputs");
    parse("match value { Bounds::between(1 + 2, limit(), item) => item, _ => 0 }")
        .expect("expression candidates in Pattern application");
}

#[test]
fn extractor_inputs_require_unique_names_and_a_final_self() {
    parse("impl Int { defextractor deconstruct(offset: Int, self: Int) -> MatchResult<Int> { MatchResult::Ok(self) } }")
        .expect("self is the final target input");
    for (source, message) in [
        ("defextractor read(self: Int, offset: Int) -> MatchResult<Int> { MatchResult::Ok(self) }", "self parameter must be the final input"),
        ("defextractor read(value: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }", "Duplicate Extractor parameter"),
    ] {
        let error = parse(source).expect_err(source);
        assert!(error.message().contains(message), "{error:?}");
    }
    parse("defextractor read() -> MatchResult<Int> { MatchResult::Ok(1) }")
        .expect_err("an Extractor must have a target input");
}

#[test]
fn extractor_rejects_trait_where_generalization() {
    let error = parse(
        "defmod Matchers { defextractor ext(value: $T) -> MatchResult<$T> where $T: Eq { MatchResult::Ok(value) } }",
    )
    .expect_err("Extractor must not use a Trait constraint to generalize its target");
    assert!(
        error
            .message()
            .contains("Extractor definitions do not support `where` clauses"),
        "{error:?}"
    );
}

#[test]
fn extractor_closure_literal_requires_explicit_nonempty_parameters() {
    parse("extract = *{|value: Int| MatchResult::Ok(value)}").expect("ExtractorClosure literal");
    for source in ["*{1}", "*{|| MatchResult::Ok(1)}"] {
        parse(source).expect_err("ExtractorClosure needs at least one explicit parameter");
    }
    for source in [
        "*{|value| MatchResult::Ok(value)}(1)",
        "match 1 { *{|value| MatchResult::Ok(value)}(_) => 1, _ => 0 }",
        "match 1 { (make())(_) => 1, _ => 0 }",
    ] {
        parse(source)
            .expect_err("anonymous expressions cannot be immediate callable or Pattern heads");
    }
}

#[test]
fn pattern_consumers_reserve_names_and_accept_projection_syntax() {
    parse("apply_pattern([1, 2], [_1: Int, .._2: List<Int>])").expect("projection syntax");
    for source in [
        "is_match = 1",
        "def apply_pattern(value: Int) -> Int { value }",
        "f = {|if_let| if_let}",
    ] {
        parse(source).expect_err("Pattern consumer names are reserved");
    }
}

#[test]
fn qualified_bare_names_remain_distinct_from_constructor_calls() {
    let names = parse("Result::recover_kind(value, Left::Retry, handler)").unwrap();
    let Ast::App(_, _, args) = &names[0] else {
        panic!("call")
    };
    assert!(matches!(&args[1], RecordLitArg::Positional(Ast::Path(..))));
    let calls = parse("Result::recover_kind(value, Left::Retry(), handler)").unwrap();
    let Ast::App(_, _, args) = &calls[0] else {
        panic!("call")
    };
    assert!(matches!(
        &args[1],
        RecordLitArg::Positional(Ast::ConstructorCall(..))
    ));
}

#[test]
fn pattern_consumers_choose_argument_grammar_directly_in_all_call_forms() {
    for callee in [
        "is_match",
        "Kernel::is_match",
        "`is_match`",
        "`Kernel::is_match`",
    ] {
        let source = format!("{callee}(input, Ok(_) | Err(_))");
        let ast = parse(&source).expect(&source);
        let Ast::PatternConsumerCall(_, _, args) = &ast[0] else {
            panic!("{source}: {:?}", ast[0])
        };
        assert!(
            args[0].expression.is_some() && args[0].pattern.is_none(),
            "{source}"
        );
        assert!(
            args[1].expression.is_none() && args[1].pattern.is_some(),
            "{source}"
        );
    }
    for callee in ["Regex::matches", "`Regex::matches`"] {
        let source = format!("{callee}(regex, input)");
        assert!(
            matches!(&parse(&source).unwrap()[0], Ast::App(..)),
            "{source}"
        );
    }
    for source in ["is_match(^input, _)", "if_let(input, _, 1 | 2, 0)"] {
        parse(source).expect_err(source);
    }
}

#[test]
fn pattern_consumer_infix_rhs_returns_to_expression_grammar() {
    for callee in ["is_match", "Kernel::is_match"] {
        let source = format!("input `{callee}` Ok(_) | Err(_) `and` flag");
        let ast = parse(&source).expect(&source);
        let Ast::App(_, _, args) = &ast[0] else {
            panic!("and Call")
        };
        let RecordLitArg::Positional(Ast::PatternConsumerCall(_, _, args)) = &args[0] else {
            panic!("consumer LHS")
        };
        assert!(matches!(
            args[1].pattern.as_deref(),
            Some(AstPattern::Or(..))
        ));
        let source = format!("input `{callee}` _ + 1");
        assert!(
            matches!(&parse(&source).unwrap()[0], Ast::BinOp(_, BinOp::Add, lhs, _) if matches!(lhs.as_ref(), Ast::PatternConsumerCall(..)))
        );
    }
    parse("input `apply_pattern` [_1, .._]").expect("projection RHS");
    for source in [
        "input `if_let` _",
        "input `if_let_then` _",
        "apply_pattern(input, 1 | 2)",
        "apply_pattern(input, Some(1 | 2))",
    ] {
        parse(source).expect_err(source);
    }
    assert!(matches!(
        &parse("regex `Regex::matches` input").unwrap()[0],
        Ast::App(..)
    ));
}

#[test]
fn pattern_consumer_pipe_context_applies_only_to_outer_call() {
    for callee in [
        "apply_pattern",
        "Kernel::apply_pattern",
        "`apply_pattern`",
        "`Kernel::apply_pattern`",
    ] {
        let source = format!("input |> {callee}([_, _1])");
        let ast = parse(&source).expect(&source);
        let Ast::Pipe(_, _, rhs) = &ast[0] else {
            panic!("Pipe")
        };
        let Ast::PatternConsumerCall(_, _, args) = rhs.as_ref() else {
            panic!("consumer")
        };
        assert!(
            args[0].expression.is_none() && args[0].pattern.is_some(),
            "{source}"
        );
    }
    let ast = parse("True |> Boolean::eqv(is_match(Ok(1), Ok(_)))").unwrap();
    let Ast::Pipe(_, _, rhs) = &ast[0] else {
        panic!("Pipe")
    };
    let Ast::App(_, _, args) = rhs.as_ref() else {
        panic!("ordinary Call")
    };
    let RecordLitArg::Positional(Ast::PatternConsumerCall(_, _, args)) = &args[0] else {
        panic!("nested consumer")
    };
    assert!(args[0].expression.is_some() && args[1].pattern.is_some());
    let ast = parse("input |> apply_pattern(_1, [_, _2])").unwrap();
    let Ast::Pipe(_, _, rhs) = &ast[0] else {
        panic!("Pipe")
    };
    let Ast::PatternConsumerCall(_, _, args) = rhs.as_ref() else {
        panic!("consumer")
    };
    assert!(args[0].expression.is_some() && args[1].pattern.is_some());
}

#[test]
fn pattern_or_alias_and_newline_follow_atomic_grammar() {
    let ast = parse("match input { 1 | 2 @ whole => whole, _ => 0 }").unwrap();
    let Ast::Match(_, _, arms) = &ast[0] else {
        panic!("Match")
    };
    assert!(
        matches!(&arms[0].pattern, AstPattern::As(_, inner, _, _, _) if matches!(inner.as_ref(), AstPattern::Or(..)))
    );
    for source in [
        "match input { _ @ first @ second => 0 }",
        "match input { 1\n | 2 => 0 }",
        "match input { 1 |\n 2 => 0 }",
        "input `is_match`\n _",
    ] {
        parse(source).expect_err(source);
    }
}

#[test]
fn named_comparisons_share_compare_precedence() {
    for name in ["eq", "neq", "lt", "lte", "gt", "gte"] {
        let source = format!("1 `{name}` 2 + 3");
        let ast = parse(&source).unwrap();
        let Ast::App(_, callee, args) = &ast[0] else {
            panic!("comparison Call: {source}")
        };
        assert!(matches!(callee.as_ref(), Ast::NamedInfixRef(_, path) if path.segments == [name]));
        assert!(
            matches!(
                &args[1],
                RecordLitArg::Positional(Ast::BinOp(_, BinOp::Add, _, _))
            ),
            "{source}"
        );
        let source = format!("1 `User::{name}` 2 + 3");
        assert!(
            matches!(&parse(&source).unwrap()[0], Ast::BinOp(_, BinOp::Add, lhs, _) if matches!(lhs.as_ref(), Ast::App(..)))
        );
    }
}

#[test]
fn pattern_consumer_pipe_recognizes_every_direct_slot_without_projection_confusion() {
    for source in [
        "input |> apply_pattern(_1, _1)",
        "input |> apply_pattern(input, _1)",
    ] {
        let ast = parse(source).unwrap();
        let Ast::Pipe(_, _, rhs) = &ast[0] else {
            panic!("Pipe")
        };
        let Ast::PatternConsumerCall(_, _, args) = rhs.as_ref() else {
            panic!("consumer")
        };
        assert!(
            args[1].expression.is_some() && args[1].pattern.is_none(),
            "{source}"
        );
    }
}

#[test]
fn grouped_pipe_placeholder_preserves_expression_and_pattern_grammar() {
    let ast = parse("input |> apply_pattern((_1))").unwrap();
    let Ast::Pipe(_, _, rhs) = &ast[0] else {
        panic!("Pipe")
    };
    let Ast::PatternConsumerCall(_, _, args) = rhs.as_ref() else {
        panic!("consumer")
    };
    assert!(args[0].expression.is_none() && args[0].pattern.is_some());
    let ast = parse("input |> ordinary((_1))").unwrap();
    let Ast::Pipe(_, _, rhs) = &ast[0] else {
        panic!("Pipe")
    };
    assert!(
        matches!(rhs.as_ref(), Ast::App(_, _, args) if matches!(&args[0], RecordLitArg::Positional(Ast::Grouped(_, inner)) if matches!(inner.as_ref(), Ast::NumberedPlaceholder(..))))
    );
}

#[test]
fn reserved_callable_pattern_heads_preserve_application_without_bindings() {
    for name in ["on", "and", "or", "eq", "neq", "lt", "lte", "gt", "gte"] {
        for head in [
            format!("{name}(_)"),
            format!("User::{name}(_)"),
            format!("User::{name}()"),
        ] {
            parse(&format!("match input {{ {head} => 1, _ => 0 }}"))
                .expect("callable Pattern head");
            parse(&format!("{head} =? input")).expect("callable binding Pattern head");
        }
        for pattern in [
            name.to_string(),
            format!("{name}: Int"),
            format!("_ @{name}"),
            format!("User::{name}"),
        ] {
            parse(&format!("match input {{ {pattern} => 1 }}"))
                .expect_err("reserved binding or noncallable path");
        }
    }
}

#[test]
fn pattern_capture_rejects_direct_pattern_placeholder_in_parser() {
    for source in ["f = &is_match(&1, &2)", "f = &is_match(&1, (&2))"] {
        let error = parse(source).expect_err("Pattern cannot be a capture placeholder");
        assert_eq!(error.reason(), ParseErrorReason::PatternSyntax, "{source}");
    }
    let error = parse("f = &is_match(&1, &2)").unwrap_err();
    assert!(error
        .message()
        .contains("Pattern argument cannot be a capture placeholder"));
}

#[test]
fn grouped_and_tuple_pipe_rhs_do_not_forward_injection_to_inner_calls() {
    for source in [
        "True |> (is_match(Ok(1), Ok(_)))",
        "True |> (Boolean::eqv(is_match(Ok(1), Ok(_))))",
        "True |> (is_match(Ok(1), Ok(_)), False)",
    ] {
        fn find_consumer(node: &Ast) -> &[AstPatternArgument] {
            match node {
                Ast::PatternConsumerCall(_, _, args) => args,
                Ast::Grouped(_, inner) => find_consumer(inner),
                Ast::TupleLiteral(_, items) => find_consumer(&items[0]),
                Ast::App(_, _, args) => match &args[0] {
                    RecordLitArg::Positional(expr) => find_consumer(expr),
                    _ => panic!("positional argument"),
                },
                _ => panic!("expected consumer within grouped/tuple expression"),
            }
        }
        let ast = parse(source).expect(source);
        let Ast::Pipe(_, _, rhs) = &ast[0] else {
            panic!("Pipe")
        };
        let args = find_consumer(rhs);
        assert_eq!(args.len(), 2, "{source}");
        assert!(
            args[0].expression.is_some() && args[0].pattern.is_none(),
            "{source}"
        );
        assert!(
            args[1].expression.is_none() && args[1].pattern.is_some(),
            "{source}"
        );
    }
}

#[test]
fn pipe_consumer_grammar_applies_only_when_call_is_entire_rhs() {
    fn find_consumer(node: &Ast) -> &[AstPatternArgument] {
        match node {
            Ast::PatternConsumerCall(_, _, args) => args,
            Ast::Pipe(_, _, rhs) => find_consumer(rhs),
            Ast::BinOp(_, _, lhs, _) | Ast::FieldAccess(_, lhs, _) => find_consumer(lhs),
            Ast::App(_, _, args) => match &args[0] {
                RecordLitArg::Positional(expr) => find_consumer(expr),
                _ => panic!("positional argument"),
            },
            _ => panic!("consumer nested inside RHS wrapper"),
        }
    }
    for callee in ["is_match", "Kernel::is_match", "`Kernel::is_match`"] {
        for tail in ["+ 1", "`helper` 2", ".flag", "`MyMod::on` projector"] {
            let source = format!("True |> {callee}(Ok(1), Ok(_)) {tail}");
            let ast = parse(&source).expect(&source);
            let args = find_consumer(&ast[0]);
            assert_eq!(args.len(), 2, "{source}");
            assert!(
                args[0].expression.is_some() && args[0].pattern.is_none(),
                "{source}"
            );
            assert!(
                args[1].expression.is_none() && args[1].pattern.is_some(),
                "{source}"
            );
        }
    }
    for tail in ["`on` projector", "`Function::on` projector", "|> next()"] {
        let source = format!("input |> apply_pattern([_1]) {tail}");
        let ast = parse(&source).expect(&source);
        let Ast::Pipe(_, _, rhs) = (match &ast[0] {
            Ast::App(_, _, args) => match &args[0] {
                RecordLitArg::Positional(pipe) => pipe,
                _ => panic!("on lhs"),
            },
            Ast::Pipe(_, lhs, _) => lhs.as_ref(),
            _ => panic!("outer lower precedence operator"),
        }) else {
            panic!("consumer pipe")
        };
        let Ast::PatternConsumerCall(_, _, args) = rhs.as_ref() else {
            panic!("outer consumer call")
        };
        assert_eq!(args.len(), 1, "{source}");
        assert!(
            args[0].expression.is_none() && args[0].pattern.is_some(),
            "{source}"
        );
    }
}

#[test]
fn consumer_pipe_context_respects_cond_and_match_delimiters() {
    for source in [
        "cond { input |> is_match(_) => 1, True => 0 }",
        "match input |> apply_pattern([_1]) { _ => 0 }",
    ] {
        parse(source).expect(source);
    }
    let error = parse("input |> is_match([_").expect_err("unfinished Pattern");
    assert!(error.is_incomplete());
}

#[test]
fn test_facet_arrow_chain_precedence_and_left_association() {
    let ast = parse("value = outer -> middle.field -> inner() + rhs").unwrap();
    let Ast::Bind(_, _, value) = &ast[0] else {
        panic!("expected binding")
    };
    let Ast::BinOp(_, BinOp::Add, left, _) = value.as_ref() else {
        panic!("expected outer addition: {value:?}")
    };
    let Ast::BinOp(_, BinOp::FacetChain, first, inner) = left.as_ref() else {
        panic!("expected outer chain")
    };
    assert!(
        matches!(first.as_ref(), Ast::BinOp(_, BinOp::FacetChain, _, right) if matches!(right.as_ref(), Ast::FieldAccess(_, _, _)))
    );
    assert!(matches!(inner.as_ref(), Ast::App(_, _, _)));
}

#[test]
fn test_facet_arrow_capture_keeps_operand_boundary() {
    let ast = parse("value = &User.profile -> Profile.name").unwrap();
    let Ast::Bind(_, _, value) = &ast[0] else {
        panic!("expected binding")
    };
    assert!(
        matches!(value.as_ref(), Ast::BinOp(_, BinOp::FacetChain, lhs, rhs) if matches!(lhs.as_ref(), Ast::Capture(_, target, args) if args.is_empty() && matches!(target.as_ref(), Ast::FieldAccess(_, _, field) if field == "profile")) && matches!(rhs.as_ref(), Ast::FieldAccess(_, _, field) if field == "name")),
        "{value:?}"
    );
}

#[test]
fn test_bulk_update_arrow_chain_parses_and_slash_is_rejected() {
    parse("Facet::bulk_update(user){User.profile -> Profile.name <- set(\"bob\")}").unwrap();
    parse("Facet::bulk_update(user){User.profile / Profile.name <- set(\"bob\")}")
        .expect_err("old path chain is rejected");
}

#[test]
fn safe_arithmetic_operators_share_expr_precedence() {
    let ast = parse("value = 8 / 2 % 3 + 1").expect("safe division and modulo parse");
    let Ast::Bind(_, _, value) = &ast[0] else {
        panic!("binding")
    };
    let Ast::BinOp(_, BinOp::Add, left, _) = value.as_ref() else {
        panic!("left associative Expr operators")
    };
    let Ast::BinOp(_, BinOp::Mod(mod_span), dividend, _) = left.as_ref() else {
        panic!("modulo follows division in the Expr group")
    };
    assert_eq!(*mod_span, Span { start: 14, end: 15 });
    let Ast::BinOp(_, BinOp::Div(div_span), _, _) = dividend.as_ref() else {
        panic!("division is the leftmost operation")
    };
    assert_eq!(*div_span, Span { start: 10, end: 11 });
}

#[test]
fn safe_arithmetic_quoted_calls_and_captures_parse() {
    parse("quot = `/`(8, 2)\nrem = 7 `%` 3\nf = &`%`(&1, 3)")
        .expect("quoted arithmetic uses the operator contract");
}

#[test]
fn safe_arithmetic_preserves_quoted_operator_span() {
    let ast = parse("value = 8 `%` 3").unwrap();
    let Ast::Bind(_, _, value) = &ast[0] else {
        panic!("binding")
    };
    assert!(
        matches!(value.as_ref(), Ast::BinOp(_, BinOp::Mod(span), _, _) if *span == Span { start: 10, end: 13 })
    );
}

#[test]
fn statement_question_accepts_whole_statements_and_existing_separators() {
    for source in [
        "operation()?",
        "operation(\n  1,\n  2,\n)?\nnext()",
        "operation()?; next()",
        "1 + operation()?",
        "do::<Result> { operation()?\n Ok(()) }",
    ] {
        let ast = parse(source).unwrap_or_else(|err| panic!("{source}: {err:?}"));
        let node = match &ast[0] {
            Ast::Semi(_, inner) => inner.as_ref(),
            Ast::Do(_, _, statements, _) => match &statements[0] {
                AstDoStatement::Statement(node) => node,
                other => panic!("expected question statement, got {other:?}"),
            },
            node => node,
        };
        let Ast::StatementQuestion(span, rhs) = node else {
            panic!("expected question statement, got {node:?}");
        };
        assert_eq!(source.chars().nth(span.end - 1), Some('?'));
        assert_eq!(rhs.span().start, span.start);
    }
}

#[test]
fn statement_question_rejects_expression_positions_and_repeated_suffixes() {
    for source in [
        "value = operation()?",
        "value =? operation()?",
        "consume(operation()?)",
        "operation()? + 1",
        "operation()??",
        "(operation()?)",
        "[operation()?]",
        "do::<Result> { value <- operation()?\n Ok(()) }",
    ] {
        assert!(parse(source).is_err(), "must reject {source}");
    }
}

#[test]
fn statement_question_retains_optional_type_and_plain_facet() {
    let ast = parse("value: Int? = input\nconsume(Option.Some, value)?").unwrap();
    assert!(
        matches!(&ast[0], Ast::Bind(_, AstPattern::Annotated(_, _, AstTy::Generic(_, name, _)), _) if name == "Option")
    );
    let Ast::StatementQuestion(_, rhs) = &ast[1] else {
        panic!("expected outer question statement");
    };
    let Ast::App(_, _, args) = rhs.as_ref() else {
        panic!("expected call");
    };
    assert!(matches!(
        &args[0],
        RecordLitArg::Positional(Ast::FieldAccess(_, _, name)) if name == "Some"
    ));
}

#[test]
fn special_enum_aliases_normalize_to_canonical_constructor_calls() {
    for (input, canonical) in [
        ("Ok(1)", "Result::Ok"),
        ("Err(NoneError())", "Result::Err"),
        ("True", "Boolean::True"),
        ("False", "Boolean::False"),
        ("Boolean::True", "Boolean::True"),
        ("Boolean::False", "Boolean::False"),
    ] {
        let ast = parse(input).unwrap();
        assert!(
            matches!(&ast[0], Ast::ConstructorCall(_, name, _) if name == canonical),
            "{input}: {:?}",
            ast[0]
        );
    }
}

#[test]
fn special_enum_capture_aliases_normalize_to_canonical_paths() {
    for (input, canonical) in [
        ("&Ok", "Result::Ok"),
        ("&`Ok`", "Result::Ok"),
        ("&`True`", "Boolean::True"),
        ("&Err", "Result::Err"),
        ("&True", "Boolean::True"),
        ("&False", "Boolean::False"),
        ("&Boolean::True", "Boolean::True"),
    ] {
        let ast = parse(input).unwrap();
        assert!(
            matches!(&ast[0], Ast::Capture(_, target, _) if matches!(target.as_ref(), Ast::Path(_, path) if path.segments.join("::") == canonical)),
            "{input}: {:?}",
            ast[0]
        );
    }
}

#[test]
fn old_result_constructor_contracts_are_rejected_independent_of_module_path() {
    for module in [None, Some("Bootstrap".into())] {
        for input in [
            "def Ok($T) -> Result<$T>",
            "@builtin type Ok($T) -> Result<$T>",
        ] {
            assert!(
                parse_with_context(
                    input,
                    ParserContext::module(1, module.clone()).with_rules(ParseRules::std_module())
                )
                .is_err(),
                "{input} must be rejected"
            );
        }
    }
}

#[test]
fn special_enum_pattern_aliases_normalize_without_confusing_other_owners() {
    for (input, canonical) in [
        ("Ok(value) = item", "Result::Ok"),
        ("Err(error) = item", "Result::Err"),
        ("True =? item", "Boolean::True"),
        ("Boolean::False =? item", "Boolean::False"),
        ("Other::Ok(value) = item", "Other::Ok"),
        ("MatchResult::Err = item", "MatchResult::Err"),
    ] {
        let ast = parse(input).unwrap();
        let (Ast::Bind(_, pattern, _) | Ast::SafeBind(_, pattern, _, _)) = &ast[0] else {
            panic!("binding expected");
        };
        assert!(
            matches!(pattern, AstPattern::Call(_, name, _) | AstPattern::Constructor(_, name, _) if name == canonical),
            "{input}: {pattern:?}"
        );
    }
}

#[test]
fn special_enum_bare_alias_bindings_and_arguments_are_reserved() {
    for input in [
        "Err: Int = 1",
        "def helper(Ok: Int) -> Int { Ok }",
        "def helper(Err: Int) -> Int { Err }",
    ] {
        assert!(
            parse(input).is_err(),
            "{input} must not shadow a canonical alias"
        );
    }
}

#[test]
fn generic_enum_boolean_named_variants_use_the_ordinary_constructor_grammar() {
    for (owner, variant) in [
        ("Other", "True"),
        ("Other", "False"),
        ("Boolean", "True"),
        ("Boolean", "False"),
    ] {
        let source = format!("{owner}<Int>::{variant}");
        let ast = parse(&source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        assert!(
            matches!(&ast[0], Ast::EnumConstructorCall(_, actual_owner, args, actual_variant, values) if actual_owner == owner && matches!(args.as_slice(), [AstTy::Named(_, name)] if name == "Int") && actual_variant == variant && values.is_empty())
        );
        let source = format!("&{owner}<Int>::{variant}");
        let ast = parse(&source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        assert!(
            matches!(&ast[0], Ast::Capture(_, target, captures) if captures.is_empty() && matches!(target.as_ref(), Ast::EnumConstructorCall(_, actual_owner, args, actual_variant, values) if actual_owner == owner && matches!(args.as_slice(), [AstTy::Named(_, name)] if name == "Int") && actual_variant == variant && values.is_empty()))
        );
    }
}

#[test]
fn ordinary_enums_may_declare_qualified_boolean_named_variants() {
    let declarations = parse("defenum Other<$T> { True($T), False }")
        .expect("qualified variants do not redefine bare aliases");
    assert!(
        matches!(&declarations[0], Ast::EnumDef(_, owner, _, variants, _) if owner.ends_with("Other") && variants.iter().map(|variant| variant.name.as_str()).collect::<Vec<_>>() == ["True", "False"])
    );
    let direct = parse("Other::True(1)").unwrap();
    assert!(
        matches!(&direct[0], Ast::ConstructorCall(_, owner, values) if owner == "Other::True" && values.len() == 1)
    );
    let qualified = parse("Other::False").unwrap();
    assert!(matches!(&qualified[0], Ast::Path(_, path) if path.segments == ["Other", "False"]));
    let captures = parse("&Other::True(&1)\n&Other<Int>::True").unwrap();
    assert!(
        matches!(&captures[0], Ast::Capture(_, target, values) if matches!(target.as_ref(), Ast::Path(_, path) if path.segments == ["Other", "True"]) && values.len() == 1)
    );
    assert!(
        matches!(&captures[1], Ast::Capture(_, target, _) if matches!(target.as_ref(), Ast::EnumConstructorCall(_, owner, args, variant, _) if owner == "Other" && args.len() == 1 && variant == "True"))
    );
    let patterns = parse("match value { Other::True(item) => item, Other::False => 0 }").unwrap();
    assert!(
        matches!(&patterns[0], Ast::Match(_, _, arms) if matches!(&arms[0].pattern, AstPattern::Call(_, owner, _) if owner == "Other::True") && matches!(&arms[1].pattern, AstPattern::Constructor(_, owner, _) if owner == "Other::False"))
    );
}

#[test]
fn special_block_call_match_forms_share_target_and_arms() {
    for source in [
        "match value { Some(item) => item, _ => 0 }",
        "match(value) { Some(item) => item, _ => 0 }",
        "match(value, { Some(item) => item, _ => 0 })",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        let Ast::Match(span, target, arms) = &ast[0] else {
            panic!("{source}: {:?}", ast[0])
        };
        assert_eq!((span.start, span.end), (0, source.len()));
        assert!(matches!(target.as_ref(), Ast::Var(_, name) if name == "value"));
        assert_eq!(arms.len(), 2);
        assert!(matches!(&arms[0].body, Ast::Var(_, name) if name == "item"));
        assert!(matches!(&arms[1].body, Ast::Lit(_, Lit::Int(value)) if value == &int(0)));
    }
}

#[test]
fn special_block_call_cond_forms_share_ordered_clauses() {
    for source in [
        "cond { ready => 1, True => 2 }",
        "cond({ ready => 1, True => 2 })",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        let Ast::Cond(span, clauses) = &ast[0] else {
            panic!("{source}: {:?}", ast[0])
        };
        assert_eq!((span.start, span.end), (0, source.len()));
        assert_eq!(clauses.len(), 2);
        assert!(matches!(&clauses[0].0, Ast::Var(_, name) if name == "ready"));
        assert!(matches!(&clauses[0].1, Ast::Lit(_, Lit::Int(value)) if value == &int(1)));
        assert!(Parser::is_true_literal(&clauses[1].0));
    }
}

#[test]
fn special_block_call_bulk_update_forms_share_source_and_entries() {
    for source in [
        "bulk_update(value) { name <- set(1) }",
        "bulk_update(value, { name <- set(1) })",
        "Facet::bulk_update(value) { name <- set(1) }",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        let Ast::BulkUpdate(span, target, entries) = &ast[0] else {
            panic!("{source}: {:?}", ast[0])
        };
        assert_eq!((span.start, span.end), (0, source.len()));
        assert!(matches!(target.as_ref(), Ast::Var(_, name) if name == "value"));
        assert_eq!(entries.len(), 1);
        assert_eq!(
            bulk_path_segments(&entries[0].path),
            [FacetPathSegment::field("name")]
        );
        assert!(
            matches!(&entries[0].kind, BulkUpdateEntryKind::Set(Ast::Lit(_, Lit::Int(value))) if value == &int(1))
        );
    }
}

#[test]
fn special_block_call_bulk_update_keyword_cannot_be_shadowed() {
    for source in [
        "bulk_update = 1",
        "def bulk_update(value) { value }",
        "def use(bulk_update: Int) { bulk_update }",
        "{|bulk_update| bulk_update}",
        "defmod Custom { def bulk_update(value) { value } }",
    ] {
        assert!(
            parse(source).is_err(),
            "reserved keyword accepted: {source}"
        );
    }
}

#[test]
fn special_block_call_nested_blocks_and_existing_tuple_targets() {
    for source in [
        "match(cond({ True => value }), { item => bulk_update(item, { name <- set(1) }) })",
        "cond({ True => match(value, { _ => 1 }) })",
        "match (1, 2) { (a, b) => a }",
        "match (1, { 2 }) { (a, b) => a }",
        "match (value, {|x| x}) { _ => 1 }",
        "match (value, { cond { True => 2 } }) { _ => 1 }",
        "match\n(value, { _ => 1 })",
        "match (a) + b { _ => 1 }",
        "match(value, { _ => 1 },)",
        "cond({ True => 1 },)",
        "bulk_update(value, { name <- set(1) },)",
        "Facet::bulk_update(value,) { name <- set(1) }",
    ] {
        parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
    }
}

#[test]
fn special_block_call_rejects_invalid_arguments_and_blocks() {
    for source in [
        "match (value, {}) { _ => 1 }",
        "bulk_update value { name <- set(1) }",
        "bulk_update(value)",
        "bulk_update(value, { name <- set(1) }, extra)",
        "bulk_update(source: value) { name <- set(1) }",
        "bulk_update(value, {})",
        "bulk_update(value, { name <- replace(1) })",
        "match(value, {})",
        "cond({})",
        "cond({ ready => 1 })",
        "cond({ True => 1 }, extra)",
    ] {
        assert!(
            parse(source).is_err(),
            "invalid special call accepted: {source}"
        );
    }
}

#[test]
fn special_block_call_bulk_update_keyword_preserves_intrinsic_declaration() {
    let ast = parse_with_context(
        "@intrinsic def bulk_update(source: $S, updates: BulkUpdateEntries<$S>) -> Result<$S>",
        ParserContext::module(0, None).with_rules(ParseRules::std_module()),
    )
    .expect("compiler intrinsic can declare the keyword");
    assert!(matches!(&ast[0], Ast::IntrinsicDecl(_, name, _, _) if name == "bulk_update"));
}

#[test]
fn named_infix_origin_is_preserved_by_strict_and_tolerant_parsing() {
    for source in [
        "2 `combine` 3",
        "2 `User::combine` 3",
        "True `Kernel::and` False",
    ] {
        let strict = parse(source).unwrap();
        let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
        assert!(tolerant.diagnostics.is_empty(), "{source}");
        assert_eq!(strict, tolerant.ast, "{source}");
        assert!(
            matches!(&strict[0], Ast::App(_, callee, _) if matches!(callee.as_ref(), Ast::NamedInfixRef(..)))
        );
    }
}

#[test]
fn pattern_consumer_names_reject_ordinary_qualified_callables() {
    for consumer in sindr::pattern::PatternConsumer::ALL {
        let name = consumer.name();
        for owner in ["Regex", "Custom", "Nested::Kernel"] {
            let callee = format!("{owner}::{name}");
            for source in [
                format!("{callee}(value, input)"),
                format!("`{callee}`(value, input)"),
                format!("value `{callee}` input"),
                format!("&{callee}"),
                format!("&`{callee}`"),
                format!("&{callee}(&1, input)"),
                format!("value |> {callee}(input)"),
            ] {
                let error = parse(&source).expect_err(&source);
                assert!(
                    error
                        .message()
                        .contains("reserved for the canonical Kernel consumer"),
                    "{source}: {error:?}"
                );
            }
        }
    }
}

#[test]
fn boolean_function_suffix_call_surfaces() {
    for source in [
        "def predicate?(value: Int) -> Boolean { value > 0 }",
        "defp predicate?() -> Boolean { True }",
        "answer = predicate?(1)",
        "predicate?::<Int>(1)",
        "M::predicate?(1)",
        "M::predicate?::<Int>(1)",
        "f = &predicate?",
        "f = &M::predicate?",
        "`predicate?`(1)",
        "1 `predicate?` 2",
        "1 `M::predicate?` 2",
        "import M::predicate?",
        "import M::{predicate?, plain}",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        assert!(
            format!("{ast:?}").contains("predicate?"),
            "{source}: {ast:?}"
        );
    }
    let ast = parse("predicate?(1)?").unwrap();
    assert!(
        matches!(&ast[0], Ast::StatementQuestion(_, call) if matches!(call.as_ref(), Ast::App(_, callee, _) if matches!(callee.as_ref(), Ast::Var(_, name) if name == "predicate?")))
    );
    assert!(matches!(
        &parse("value ?").unwrap()[0],
        Ast::StatementQuestion(..)
    ));
    assert!(matches!(
        &parse("value?").unwrap()[0],
        Ast::StatementQuestion(..)
    ));
}

#[test]
fn boolean_function_suffix_rejects_non_callable_positions() {
    for source in [
        "def predicate??() -> Boolean { True }",
        "def predicate ?() -> Boolean { True }",
        "def ordinary(value?: Int) -> Boolean { True }",
        "value? = True",
        "[value?] = input",
        "predicate?() = rhs",
        "M::predicate?() = rhs",
        "predicate ?(1)",
        "import M?::predicate",
        "1 `M?::predicate` 2",
        "match value { predicate?() => 1 }",
    ] {
        assert!(parse(source).is_err(), "must reject {source}");
    }
}

#[test]
fn boolean_function_suffix_in_extractor_pre_argument() {
    let ast = parse("extract(predicate?(1), item) = value").unwrap();
    assert!(
        matches!(&ast[0], Ast::Bind(_, AstPattern::Call(..), _)),
        "{ast:?}"
    );
    assert!(format!("{ast:?}").contains("predicate?"));
}

#[test]
fn boolean_function_suffix_rejects_optional_selectors() {
    for source in [
        "value.field?",
        "value.field ?",
        "Boolean.True?",
        "Option.Some?",
        "Facet::view(Option.Some?, value)",
    ] {
        assert!(parse(source).is_err(), "must reject {source}");
    }
}

#[test]
fn boolean_function_suffix_declarations_and_tolerant_parser() {
    for source in [
        "deftrait Check { def predicate?(self) -> Boolean }",
        "def predicate?() -> Boolean { True }\npredicate?()",
        "1 `M::predicate?` 2",
        "import M::{predicate?, plain}",
    ] {
        let strict = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
        assert!(
            tolerant.diagnostics.is_empty(),
            "{source}: {:?}",
            tolerant.diagnostics
        );
        assert_eq!(strict, tolerant.ast, "{source}");
    }
    for source in [
        "impl Int { def predicate?(self) -> Boolean { True } }",
        "impl Check for Int { def predicate?(self) -> Boolean { True } }",
    ] {
        let ast = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        assert!(format!("{ast:?}").contains("predicate?"));
    }
    let source = "@builtin def predicate?(value: Int) -> Boolean";
    let context = ParserContext::module(1, None).with_rules(ParseRules::std_module());
    let strict = parse_with_context(source, context.clone()).unwrap();
    let tolerant = parse_tolerant_with_context(source, context, None);
    assert!(
        tolerant.diagnostics.is_empty(),
        "{:?}",
        tolerant.diagnostics
    );
    assert_eq!(strict, tolerant.ast);
}

#[test]
fn tolerant_impl_methods_reuse_strict_signatures_and_recover() {
    for source in [
        "impl Int { def predicate(self) -> Boolean { True } }",
        "impl Int { def predicate?(self) -> Boolean { True } }",
        "impl Int { @doc \"\"\"Predicate.\"\"\" def predicate?(self) -> Boolean { True } }",
    ] {
        let strict = parse(source).unwrap();
        let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
        assert!(
            tolerant.diagnostics.is_empty(),
            "{source}: {:?}",
            tolerant.diagnostics
        );
        assert_eq!(strict, tolerant.ast, "{source}");
    }
    let source = "impl Int { @builtin def predicate?(value: Int) -> Boolean }";
    let context = ParserContext::module(1, None).with_rules(ParseRules::std_module());
    let strict = parse_with_context(source, context.clone()).unwrap();
    let tolerant = parse_tolerant_with_context(source, context, None);
    assert!(
        tolerant.diagnostics.is_empty(),
        "{:?}",
        tolerant.diagnostics
    );
    assert_eq!(strict, tolerant.ast);
    let source = "impl Int {\n def bad?(value: Int, self) -> Boolean { True }\n def good?(self) -> Boolean { True }\n}";
    let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
    assert_eq!(tolerant.diagnostics.len(), 1, "{:?}", tolerant.diagnostics);
    assert!(
        format!("{:?}", tolerant.ast).contains("good?"),
        "{:?}",
        tolerant.ast
    );
    assert!(!format!("{:?}", tolerant.ast).contains("bad?"));
}

#[test]
fn statement_question_keeps_numbered_facet_access() {
    let ast = parse("tuple._0?").unwrap();
    assert!(matches!(&ast[0], Ast::StatementQuestion(_, expression)
        if matches!(expression.as_ref(), Ast::FieldAccess(_, _, name) if name == "_0")));
}

#[test]
fn boolean_function_suffix_self_name_keeps_receiver_boundary() {
    for source in [
        "def self?() -> Boolean { True }\nself?()",
        "def self?(value: Int) -> Boolean { True }\nf = &self?",
        "def self?(left: Int, right: Int) -> Boolean { True }\n1 `self?` 2",
    ] {
        let strict = parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        assert!(format!("{strict:?}").contains("self?"));
        let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
        assert!(
            tolerant.diagnostics.is_empty(),
            "{source}: {:?}",
            tolerant.diagnostics
        );
        assert_eq!(strict, tolerant.ast);
    }
    for source in [
        "self",
        "self()",
        "self?",
        "self::predicate()",
        "self::predicate?()",
    ] {
        let error = parse(source).expect_err(source);
        assert!(
            error
                .message()
                .contains("`self` can only be used inside impl methods"),
            "{source}: {error:?}"
        );
    }
    let source = "impl Int { def same(self) -> Self { self } }";
    let strict = parse(source).unwrap();
    assert!(matches!(&strict[0], Ast::ImplDef(_, _, _, methods, _)
        if matches!(&methods[0], Ast::Def(_, _, _, _, _, _, body, _)
            if matches!(body.as_ref(), Ast::Block(_, stmts)
                if matches!(stmts.as_slice(), [Ast::Var(_, name)] if name == "self")))));
    let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
    assert!(tolerant.diagnostics.is_empty());
    assert_eq!(strict, tolerant.ast);
}

#[test]
fn removed_result_effect_annotation_is_rejected() {
    let error =
        parse("@result_effect\ndefstruct Legacy { value: Int }").expect_err("removed annotation");
    assert!(error.message().contains("Unknown annotation"));
}

#[test]
fn safe_bind_operator_and_do_keyword_spans_survive_rebasing() {
    for source in ["x =? Ok(1)", "x: Int =? Ok(1)", "(a, b) =? Ok((1, 2))"] {
        let ast = parse(source).unwrap().remove(0);
        let original_span = ast.span().clone();
        let shifted = shift_ast_span(ast, 100);
        let Ast::SafeBind(span, _, _, operator_span) = shifted else {
            panic!("expected SafeBind");
        };
        assert_eq!(
            span,
            Span {
                start: original_span.start + 100,
                end: original_span.end + 100
            }
        );
        let start = source.find("=?").unwrap() + 100;
        assert_eq!(
            operator_span,
            Span {
                start,
                end: start + 2
            }
        );
    }
    let source = "do::<Identity> { 2 =? Ok(3); Identity(5) }";
    let ast = parse(source).unwrap().remove(0);
    let shifted = shift_ast_span(ast, 100);
    let Ast::Do(_, _, _, keyword_span) = shifted else {
        panic!("expected do");
    };
    assert_eq!(
        keyword_span,
        Span {
            start: 100,
            end: 102
        }
    );
}

#[test]
fn test_deferror_payload_header_and_constructor_block_arguments_are_distinct() {
    let parsed = parse_with_context(
        r#"deferror Trouble(code: Int) { |input: String| Self(message: input, code: 1) }
        deferror Empty() { Self(message: "empty") }
        deferror Text { "text" }"#,
        ParserContext::script(1),
    )
    .unwrap();
    let Ast::DeferrorDef(_, _, fields, body, _) = &parsed[0] else {
        panic!("expected Error declaration")
    };
    assert_eq!(fields[0].name, "code");
    let Ast::Closure(_, inputs, _) = body.as_ref() else {
        panic!("expected constructor block")
    };
    assert_eq!(inputs[0].name, "input");
    for declaration in &parsed[1..] {
        let Ast::DeferrorDef(_, _, fields, body, _) = declaration else {
            panic!("expected Error declaration")
        };
        assert!(fields.is_empty());
        assert!(matches!(body.as_ref(), Ast::Closure(_, params, _) if params.is_empty()));
    }
}

#[test]
fn struct_field_rejects_multiple_visibility_modifiers() {
    for annotation in ["", "@readonly\n"] {
        for modifiers in [
            "public private",
            "private public",
            "public public",
            "private private",
            "public readonly private",
            "private readonly public",
        ] {
            let source = format!("{annotation}defstruct User {{ {modifiers} name: String }}");
            let err = parse_with_context(&source, ParserContext::project(0))
                .expect_err("field visibility may only be specified once");
            assert!(err
                .message()
                .contains("field visibility may only be specified once"));
        }
    }
}

#[test]
fn readonly_struct_rejects_explicit_public_field() {
    for modifiers in ["public", "readonly public", "public readonly"] {
        let source = format!("@readonly\ndefstruct User {{ {modifiers} name: String }}");
        let err = parse_with_context(&source, ParserContext::project(0))
            .expect_err("explicit public conflicts with readonly struct");
        assert!(err
            .message()
            .contains("@readonly struct fields cannot be explicitly public"));
    }
}

#[test]
fn hashmap_structural_pattern_syntax() {
    parse("match map { hash![^key => [x, ..xs], \"nested\" => hash![]] => x, _ => 0 }")
        .expect("HashMap structural patterns accept expressions, pins and nested children");
    parse("hash![] = map").expect("empty HashMap pattern is valid binding syntax");
    assert!(parse("match map { hash![\"a\" x] => 1, _ => 0 }").is_err());
}

#[test]
fn function_expression_bodies_accept_all_definition_contexts() {
    for source in [
        "def name(user: User) -> String = user.name",
        "defp value() -> Int = 1",
        "impl Int { def value(self: Self) -> Self = self }",
        "impl Show for Int { def show(self: Self) -> String = to_string(self) }",
        "deftrait Show { def show(self: Self) -> String = to_string(self)\n def other(self: Self) -> String }",
        "deftrait Show { defp value() -> Int = 1 }",
        "def value() -> Unit = 1;",
        "def value() -> Int = if(True, 1, 0)",
        "def value() -> Int = apply({ |x| print(x); x }, 1)",
        "def value() -> String = \"日本語\"\ndef next() -> Int = 2",
    ] {
        parse(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
    }
    parse_with_context(
        "defmod Values { def value() -> Int = 1 }",
        ParserContext::module(1, None),
    )
    .unwrap();
    let ast = parse("def value() -> Unit = 1;").unwrap();
    assert!(matches!(&ast[0], Ast::Def(_, _, _, _, _, _, body, _)
        if matches!(body.as_ref(), Ast::Block(_, statements)
            if matches!(statements.as_slice(), [Ast::Semi(_, _)]))));
}

#[test]
fn function_expression_bodies_accept_structured_multiline_expressions() {
    for body in [
        "do {\n value <- Ok(1)\n Ok(value)\n}",
        "do::<Result> {\n Ok(1)\n}",
        "match value {\n 0 => 0,\n _ => 1\n}",
        "cond {\n value > 0 => 1,\n True => 0\n}",
        "cond({\n True => 0\n})",
    ] {
        for source in [
            format!("def value() -> Int = {body}"),
            format!("impl Int {{ def value(self: Self) -> Int = {body}\n}}"),
            format!("deftrait Value {{ def value() -> Int = {body}\n}}"),
        ] {
            parse(&source).unwrap_or_else(|error| panic!("{source}: {error:?}"));
        }
    }
}

#[test]
fn function_expression_bodies_reject_invalid_boundaries() {
    for source in [
        "def value() -> Int =\n 1",
        "def value() -> Int = (\n 1\n)",
        "def value() -> Int = call(\n 1\n)",
        "def value() -> Int = value\n |> next()",
        "def value() -> Int = value |>\n next()",
        "def value() -> Int = apply({\n 1\n})",
        "def value() -> String = \"\"\"\n  text\n  \"\"\"",
        "def value() -> Int = if(True,\n 1, 0)",
        "def value() -> Int = (cond {\n True => 1\n})",
        "def value() -> Int = x = 1",
        "def value() -> Int = x =? Ok(1)",
        "def value() -> Unit = operation()?",
        "def value() -> Unit = 1;;",
        "def value() -> Unit = 1; print(\"outside\")",
        "def value() -> Int = 1 2",
        "def value() -> Int = cond { True => 1 } + 1",
        "def value() -> Int = match 1 { _ => 1 };",
        "defextractor value(input: Int) -> MatchResult<Int> = MatchResult::Ok(input)",
        "@builtin def value() -> Int = 1",
    ] {
        parse(source).expect_err(source);
    }
}

#[test]
fn function_expression_bodies_tolerant_parser_preserves_definitions() {
    let source = "def value() -> Int = 1\ndef other() -> Int = cond {\n True => 2\n}";
    let parsed = parse(source).unwrap();
    let tolerant = parse_tolerant_with_context(source, ParserContext::default(), None);
    assert_eq!(tolerant.ast, parsed);
    assert!(tolerant.diagnostics.is_empty());
}

#[test]
fn function_expression_bodies_report_multiline_source_span() {
    let source = "def value() -> String = call(\"日本語\",\n 1)";
    let error = parse(source).expect_err("multiline argument must be rejected");
    assert_eq!(error.reason(), ParseErrorReason::DeclarationSyntax);
    assert!(error.message().contains("must stay on one source line"));
    assert_eq!(error.span().start, source.find('=').unwrap() + 1);
    assert_eq!(error.span().end, source.chars().count());
}

#[test]
fn source_reflections_reject_reserved_env_and_repl_expressions() {
    for source in ["__ENV__", "__ENV__()", "\"#{__ENV__}\""] {
        assert!(parse(source).is_err(), "{source}");
    }
    for source in ["__FILE__", "__DIR__", "__LINE__", "\"#{__LINE__}\""] {
        assert!(
            parse_with_context(source, ParserContext::repl(0)).is_err(),
            "{source}"
        );
    }
}

#[test]
fn source_reflections_cannot_be_shadowed() {
    for source in [
        "__LINE__ = 1",
        "def __FILE__() -> String { \"x\" }",
        "def f(__DIR__: String) -> String { __DIR__ }",
        "const __LINE__ = 1",
        "__ENV__ = 1",
        "def __ENV__() -> String { \"x\" }",
        "def f(__ENV__: String) -> String { \"x\" }",
    ] {
        assert!(parse(source).is_err(), "{source}");
    }
}

#[test]
fn source_reflections_materialize_original_positions_and_paths() {
    let source = "# あいう\n(__FILE__, __DIR__, __LINE__, \"#{__LINE__}\")";
    let ast = materialize_reflections(
        parse(source).unwrap(),
        source,
        Some(std::path::Path::new("/repo/src/example.srt")),
    )
    .unwrap();
    let [Ast::TupleLiteral(_, items)] = ast.as_slice() else {
        panic!("tuple expected");
    };
    assert!(matches!(&items[0], Ast::Lit(_, Lit::Str(value)) if value == "example.srt"));
    assert!(matches!(&items[1], Ast::Lit(_, Lit::Str(value)) if value == "/repo/src"));
    assert!(matches!(&items[2], Ast::Lit(_, Lit::Int(value)) if *value == int(2)));
    assert!(
        matches!(&items[3], Ast::InterpolatedStr(_, parts) if matches!(&parts[0], InterpolatedPart::Expr(expr) if matches!(expr.as_ref(), Ast::Lit(_, Lit::Int(value)) if *value == int(2))))
    );
    assert!(materialize_reflections(parse("__FILE__").unwrap(), "__FILE__", None).is_err());
    assert!(materialize_reflections(parse("__DIR__").unwrap(), "__DIR__", None).is_err());
}

#[test]
fn source_reflections_in_triple_interpolations_keep_original_line() {
    let source = "# header\n\"\"\"\n  text\n  #{__LINE__}\n\"\"\"";
    let ast = materialize_reflections(parse(source).unwrap(), source, None).unwrap();
    let [Ast::InterpolatedStr(_, parts)] = ast.as_slice() else {
        panic!("interpolation expected");
    };
    assert!(parts.iter().any(|part| matches!(part, InterpolatedPart::Expr(expr) if matches!(expr.as_ref(), Ast::Lit(_, Lit::Int(value)) if *value == int(4)))));
}

#[test]
fn source_reflections_validate_builtin_function_declarations() {
    let context = ParserContext::module(0, None).with_rules(ParseRules::std_module());
    for source in [
        "@builtin def __FILE__() -> String",
        "@builtin def __DIR__() -> String",
        "@builtin def __LINE__() -> Int",
    ] {
        assert!(
            parse_with_context(source, context.clone()).is_ok(),
            "{source}"
        );
        assert!(parse(source).is_err(), "user source: {source}");
    }
    for source in [
        "@builtin def __FILE__() -> Int",
        "@builtin def __LINE__() -> Int = 1",
        "@builtin def __ENV__()",
        "@builtin def __ENV__() -> String",
        "@builtin def __FILE__() -> String\n{ \"x\" }",
        "@builtin const FOO: Int",
        "@builtin const __FILE__: String",
        "@builtin def __FILE__(x: String) -> String",
        "@builtin def __FILE__() -> String { \"x\" }",
    ] {
        assert!(
            parse_with_context(source, context.clone()).is_err(),
            "{source}"
        );
    }
    for source in ["__LINE__()", "__DIR__(1)", "&__LINE__", "^__LINE__"] {
        assert!(parse(source).is_err(), "{source}");
    }
}
