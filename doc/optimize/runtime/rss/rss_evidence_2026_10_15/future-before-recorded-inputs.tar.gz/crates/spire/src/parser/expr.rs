use crate::ast::*;
use crate::error::ParseError;
use crate::func_literal::{
    func_literal_operator, func_literal_operator_token, parse_func_literal_path,
    FuncLiteralOperator, FuncLiteralOperatorKind, FuncLiteralOperatorTier,
};
use crate::token::Token;
use sindr::primitives::ToPrimitive;

use super::{ast_ty_span, Parser};

#[derive(Debug, Clone, PartialEq)]
enum FuncLiteralBodyKind {
    Name(Symbol),
    Path(AstPath),
    Operator(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum FlowOpKind {
    PipeApply,
    PipeMap,
    PipeApplyContext,
    PipeBind,
    Compose,
    LiftCompose,
    KleisliCompose,
    Choice,
}

const MAX_CAPTURE_PLACEHOLDER_INDEX: usize = 16;

impl Parser<'_> {
    pub(super) fn assignment_ast(
        assign_tok: Token,
        operator_span: Span,
        span: Span,
        pat: AstPattern,
        rhs: Ast,
    ) -> Result<Ast, ParseError> {
        match assign_tok {
            Token::Bind => Ok(Ast::Bind(span, pat, Box::new(rhs))),
            Token::SafeBind => Ok(Ast::SafeBind(span, pat, Box::new(rhs), operator_span)),
            other => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                format!("Expected assignment operator (= or =?), got {:?}", other),
                span,
            )),
        }
    }

    fn function_on_path(span: Span) -> Ast {
        Ast::Path(
            span.clone(),
            AstPath {
                span,
                segments: vec!["Function".into(), "on".into()],
            },
        )
    }

    fn is_function_on_path(path: &AstPath) -> bool {
        matches!(path.segments.as_slice(), [module, name] if module == "Function" && name == "on")
    }

    fn low_precedence_on_target_callee(kind: &FuncLiteralBodyKind, span: &Span) -> Option<Ast> {
        match kind {
            FuncLiteralBodyKind::Name(name) if name == "on" => {
                Some(Self::function_on_path(span.clone()))
            }
            FuncLiteralBodyKind::Path(path) if Self::is_function_on_path(path) => {
                Some(Ast::Path(path.span.clone(), path.clone()))
            }
            _ => None,
        }
    }

    fn validate_pattern_consumer_path(segments: &[String], span: Span) -> Result<(), ParseError> {
        if let Some(kind) = segments
            .iter()
            .find_map(|segment| sindr::pattern::PatternConsumer::from_name(segment))
        {
            if sindr::pattern::PatternConsumer::from_source_path(segments) != Some(kind) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    format!(
                        "Pattern consumer name `{}` is reserved for the canonical Kernel consumer",
                        kind.name()
                    ),
                    span,
                ));
            }
        }
        Ok(())
    }

    fn parse_func_literal_body(body: &str, span: Span) -> Result<FuncLiteralBodyKind, ParseError> {
        if func_literal_operator(body).is_some() {
            return Ok(FuncLiteralBodyKind::Operator(body.to_string()));
        }

        if let Some(segments) = parse_func_literal_path(body) {
            Self::validate_pattern_consumer_path(&segments, span.clone())?;
            return Ok(FuncLiteralBodyKind::Path(AstPath { span, segments }));
        }

        if !crate::func_literal::is_func_literal_ident(body) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                format!("Unsupported FuncLiteral body: `{}`", body),
                span,
            ));
        }

        Ok(FuncLiteralBodyKind::Name(body.to_string()))
    }

    fn flow_op_kind(tok: &Token) -> Option<FlowOpKind> {
        match tok {
            Token::PipeApply => Some(FlowOpKind::PipeApply),
            Token::PipeMap => Some(FlowOpKind::PipeMap),
            Token::PipeApplyContext => Some(FlowOpKind::PipeApplyContext),
            Token::PipeBind => Some(FlowOpKind::PipeBind),
            Token::Compose => Some(FlowOpKind::Compose),
            Token::LiftCompose => Some(FlowOpKind::LiftCompose),
            Token::KleisliCompose => Some(FlowOpKind::KleisliCompose),
            Token::Choice => Some(FlowOpKind::Choice),
            _ => None,
        }
    }

    fn flow_op_injects_first_argument(kind: FlowOpKind) -> bool {
        matches!(
            kind,
            FlowOpKind::PipeApply | FlowOpKind::PipeMap | FlowOpKind::PipeBind
        )
    }

    fn skip_newlines_before_flow_op(&mut self) {
        if !matches!(self.peek(), Token::Newline) {
            return;
        }

        let save = self.pos;
        self.skip_newlines();
        if Self::flow_op_kind(self.peek()).is_none() {
            self.pos = save;
        }
    }

    pub(super) fn parse_expr(&mut self) -> Result<Ast, ParseError> {
        self.parse_on_expr()
    }

    pub(super) fn parse_on_expr(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_flow_expr()?;

        loop {
            let Some(Token::FuncLiteral(body)) = self.peek_n(0).cloned() else {
                break;
            };
            let func_span = self.peek_span();
            let func_kind = Self::parse_func_literal_body(&body, func_span.clone())?;
            let Some(func) = Self::low_precedence_on_target_callee(&func_kind, &func_span) else {
                break;
            };

            self.advance();
            let right = self.parse_flow_expr()?;
            left = Self::lower_func_literal_call(left, func, right);
        }

        Ok(left)
    }

    pub(super) fn parse_flow_expr(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_and_or_expr()?;
        loop {
            // Choice deliberately does not inherit flow's newline-continuation
            // rule: `<|>` must remain on a single source line.
            if !matches!(self.peek(), Token::Newline) {
                // Already at an operator or ordinary expression token.
            } else {
                let save = self.pos;
                self.skip_newlines_before_flow_op();
                if matches!(self.peek(), Token::Choice) {
                    self.pos = save;
                    break;
                }
            }

            let next = match Self::flow_op_kind(self.peek()) {
                Some(kind) => kind,
                None => break,
            };
            self.advance();
            if matches!(next, FlowOpKind::Choice) && matches!(self.peek(), Token::Newline) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "`<|>` must have its right operand on the same line",
                    self.peek_span(),
                ));
            }
            if !matches!(next, FlowOpKind::Choice) {
                self.skip_newlines();
            }
            let direct_partial_pair_call = if Self::flow_op_injects_first_argument(next) {
                match self.peek().clone() {
                    Token::FuncLiteral(body) if Self::is_pair_constructor_func_literal(&body) => {
                        Some((self.peek_span(), body))
                    }
                    _ => None,
                }
            } else {
                None
            };
            let right = if let Some((func_span, body)) = direct_partial_pair_call {
                let pair_call = self.parse_quoted_callee_call(func_span, body, true, false)?;
                if !matches!(
                    self.peek(),
                    Token::Newline
                        | Token::Semicolon
                        | Token::Comma
                        | Token::RParen
                        | Token::RBrack
                        | Token::RBrace
                        | Token::Eof
                ) && Self::flow_op_kind(self.peek()).is_none()
                {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "quoted pair constructor partial call must be the complete pipeline RHS",
                        pair_call.span().clone(),
                    ));
                }
                pair_call
            } else {
                let saved = self.pending_pipe_outer_call;
                self.pending_pipe_outer_call = Self::flow_op_injects_first_argument(next);
                let result = self.parse_and_or_expr();
                self.pending_pipe_outer_call = saved;
                result?
            };
            let span = Span {
                start: left.span().start,
                end: right.span().end,
            };
            left = match next {
                FlowOpKind::PipeApply => Ast::Pipe(span, Box::new(left), Box::new(right)),
                FlowOpKind::PipeMap => Ast::ContextMap(span, Box::new(left), Box::new(right)),
                FlowOpKind::PipeApplyContext => {
                    Ast::ContextApply(span, Box::new(left), Box::new(right))
                }
                FlowOpKind::PipeBind => Ast::ContextBind(span, Box::new(left), Box::new(right)),
                FlowOpKind::Compose => Ast::Compose(span, Box::new(left), Box::new(right)),
                FlowOpKind::LiftCompose => {
                    Ast::LiftedCompose(span, Box::new(left), Box::new(right))
                }
                FlowOpKind::KleisliCompose => {
                    Ast::KleisliCompose(span, Box::new(left), Box::new(right))
                }
                FlowOpKind::Choice => {
                    Ast::BinOp(span, BinOp::Choice, Box::new(left), Box::new(right))
                }
            };
        }
        Ok(left)
    }

    pub(super) fn stmt_has_top_level_assignment_from(&self, start: usize) -> bool {
        self.stmt_has_top_level_token_from(start, |token| {
            matches!(token, Token::Bind | Token::SafeBind)
        })
    }

    pub(super) fn stmt_has_top_level_at_from(&self, start: usize) -> bool {
        self.stmt_has_top_level_token_from(start, |token| matches!(token, Token::At))
    }

    fn stmt_has_top_level_token_from(
        &self,
        start: usize,
        predicate: impl Fn(&Token) -> bool,
    ) -> bool {
        let mut paren_depth = 0usize;
        let mut bracket_depth = 0usize;
        let mut brace_depth = 0usize;

        for token in self.tokens.iter().skip(start).map(|sp| &sp.token) {
            match token {
                Token::LParen => paren_depth += 1,
                Token::RParen => paren_depth = paren_depth.saturating_sub(1),
                Token::LBrack => bracket_depth += 1,
                Token::RBrack => bracket_depth = bracket_depth.saturating_sub(1),
                Token::LBrace => brace_depth += 1,
                Token::RBrace => {
                    if paren_depth == 0 && bracket_depth == 0 && brace_depth == 0 {
                        break;
                    }
                    brace_depth = brace_depth.saturating_sub(1);
                }
                Token::Newline | Token::Semicolon | Token::Eof
                    if paren_depth == 0 && bracket_depth == 0 && brace_depth == 0 =>
                {
                    break;
                }
                _ if paren_depth == 0
                    && bracket_depth == 0
                    && brace_depth == 0
                    && predicate(token) =>
                {
                    return true;
                }
                _ => {}
            }
        }

        false
    }

    // ── Infix operators grouped by OpKind ──

    pub(super) fn expr_binop(tok: &Token, operator_span: Span) -> Option<BinOp> {
        match tok {
            Token::Plus => Some(BinOp::Add),
            Token::Minus => Some(BinOp::Sub),
            Token::Star => Some(BinOp::Mul),
            Token::Slash => Some(BinOp::Div(operator_span)),
            Token::Percent => Some(BinOp::Mod(operator_span)),
            Token::Concat => Some(BinOp::Concat),
            _ => None,
        }
    }

    pub(super) fn logical_binop(tok: &Token) -> Option<BinOp> {
        match tok {
            Token::EqEq => Some(BinOp::Eq),
            Token::BangEq => Some(BinOp::Neq),
            Token::Lt => Some(BinOp::Lt),
            Token::Gt => Some(BinOp::Gt),
            Token::LtEq => Some(BinOp::Lte),
            Token::GtEq => Some(BinOp::Gte),
            _ => None,
        }
    }

    pub(super) fn and_or_name(tok: &Token) -> Option<&'static str> {
        match tok {
            // Keep symbolic logical operators distinguishable until resolution
            // so local `and` / `or` bindings cannot retarget `&&` / `||`.
            Token::AndAnd => Some("&&"),
            Token::OrOr => Some("||"),
            _ => None,
        }
    }

    pub(super) fn expr_binop_from_func_literal(body: &str, operator_span: Span) -> Option<BinOp> {
        let operator = func_literal_operator(body)?;
        match (operator.tier, operator.kind) {
            (FuncLiteralOperatorTier::Expr, FuncLiteralOperatorKind::BinOp(op)) => Some(op),
            (FuncLiteralOperatorTier::Expr, FuncLiteralOperatorKind::SafeDivision) => {
                Some(BinOp::Div(operator_span))
            }
            (FuncLiteralOperatorTier::Expr, FuncLiteralOperatorKind::SafeModulo) => {
                Some(BinOp::Mod(operator_span))
            }
            _ => None,
        }
    }

    pub(super) fn logical_binop_from_func_literal(body: &str) -> Option<BinOp> {
        let operator = func_literal_operator(body)?;
        match (operator.tier, operator.kind) {
            (FuncLiteralOperatorTier::Logical, FuncLiteralOperatorKind::BinOp(op)) => Some(op),
            _ => None,
        }
    }

    fn is_pair_constructor_func_literal(body: &str) -> bool {
        matches!(
            func_literal_operator(body),
            Some(FuncLiteralOperator {
                kind: FuncLiteralOperatorKind::PairConstructor,
                ..
            })
        )
    }

    fn pair_constructor_at(&self) -> bool {
        matches!(
            (self.peek(), self.peek_n(1), self.peek_n(2)),
            (Token::LParen, Some(Token::Comma), Some(Token::RParen))
        )
    }

    fn pair_constructor_span(&self) -> Span {
        Span {
            start: self.peek_span().start,
            end: self.tokens[self.pos + 2].span.end,
        }
    }

    fn consume_pair_constructor(&mut self) -> Span {
        let start = self.advance().span.start;
        self.advance();
        let end = self.advance().span.end;
        Span { start, end }
    }

    pub(super) fn and_or_func_literal_name(body: &str) -> bool {
        matches!(body, "and" | "or")
    }

    pub(super) fn comparison_func_literal_name(body: &str) -> bool {
        matches!(body, "eq" | "neq" | "lt" | "lte" | "gt" | "gte")
    }

    pub(super) fn logical_func_literal_name(body: &str) -> bool {
        Self::and_or_func_literal_name(body) || Self::comparison_func_literal_name(body)
    }

    pub(super) fn lower_binop(left: Ast, op: BinOp, right: Ast) -> Ast {
        let span = Span {
            start: left.span().start,
            end: right.span().end,
        };
        Ast::BinOp(span, op, Box::new(left), Box::new(right))
    }

    pub(super) fn lower_pair_constructor(left: Ast, right: Ast) -> Ast {
        let span = Span {
            start: left.span().start,
            end: right.span().end,
        };
        Ast::TupleLiteral(span, vec![left, right])
    }

    pub(super) fn lower_func_literal_call(left: Ast, func: Ast, right: Ast) -> Ast {
        let func = match func {
            Ast::Var(span, name) if name != "&&" && name != "||" => Ast::NamedInfixRef(
                span.clone(),
                AstPath {
                    span,
                    segments: vec![name],
                },
            ),
            Ast::Path(span, path) => Ast::NamedInfixRef(span, path),
            other => other,
        };
        let span = Span {
            start: left.span().start,
            end: right.span().end,
        };
        Ast::App(
            span,
            Box::new(func),
            vec![
                RecordLitArg::Positional(left),
                RecordLitArg::Positional(right),
            ],
        )
    }

    // Dot/call operands are completed before fixed, left-associative path
    // composition. Capture keeps its existing postfix operand boundary.
    fn parse_facet_chain(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_postfix()?;
        while matches!(self.peek(), Token::Arrow) {
            self.advance();
            let right = self.parse_postfix()?;
            left = Self::lower_binop(left, BinOp::FacetChain, right);
        }
        Ok(left)
    }

    pub(super) fn parse_expr_class_expr(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_facet_chain()?;

        loop {
            if let Some(op) = Self::expr_binop(self.peek(), self.peek_span()) {
                self.advance();
                let right = self.parse_facet_chain()?;
                left = Self::lower_binop(left, op, right);
                continue;
            }

            let Some(Token::FuncLiteral(body)) = self.peek_n(0).cloned() else {
                break;
            };
            let func_span = self.peek_span();
            let func_kind = Self::parse_func_literal_body(&body, func_span.clone())?;

            if matches!(func_kind, FuncLiteralBodyKind::Operator(ref op_body)
                if Self::logical_binop_from_func_literal(op_body).is_some()
                    || Self::is_pair_constructor_func_literal(op_body))
                || matches!(func_kind, FuncLiteralBodyKind::Name(ref name)
                    if Self::logical_func_literal_name(name))
                || Self::low_precedence_on_target_callee(&func_kind, &func_span).is_some()
            {
                break;
            }

            self.advance();
            let callee = match &func_kind {
                FuncLiteralBodyKind::Name(name) => Some(Ast::Var(func_span.clone(), name.clone())),
                FuncLiteralBodyKind::Path(path) => Some(Ast::Path(path.span.clone(), path.clone())),
                FuncLiteralBodyKind::Operator(_) => None,
            };
            if let Some(callee) = callee {
                if let Some(kind) = Self::source_pattern_consumer(&callee) {
                    if kind.arity() != 2 {
                        return Err(ParseError::syntax(
                            crate::error::ParseErrorReason::ExpressionSyntax,
                            format!(
                                "{} requires a complete prefix call with {} arguments",
                                kind.name(),
                                kind.arity()
                            ),
                            func_span,
                        ));
                    }
                    let pattern = self.parse_consumer_pattern(kind)?;
                    let span = Span {
                        start: left.span().start,
                        end: super::pattern_span(&pattern).end,
                    };
                    left = Ast::PatternConsumerCall(
                        span,
                        Box::new(callee),
                        vec![
                            Self::consumer_expression_argument(left),
                            Self::consumer_pattern_argument(pattern),
                        ],
                    );
                    continue;
                }
            }
            let right = self.parse_facet_chain()?;
            match func_kind {
                FuncLiteralBodyKind::Operator(op_body) => {
                    let Some(op) = Self::expr_binop_from_func_literal(&op_body, func_span.clone())
                    else {
                        return Err(ParseError::syntax(
                            crate::error::ParseErrorReason::ExpressionSyntax,
                            format!("Unsupported FuncLiteral body: `{}`", op_body),
                            func_span,
                        ));
                    };
                    left = Self::lower_binop(left, op, right);
                }
                FuncLiteralBodyKind::Name(name) => {
                    left = Self::lower_func_literal_call(left, Ast::Var(func_span, name), right);
                }
                FuncLiteralBodyKind::Path(path) => {
                    left = Self::lower_func_literal_call(
                        left,
                        Ast::Path(path.span.clone(), path),
                        right,
                    );
                }
            }
        }

        Ok(left)
    }

    /// Parse the pair-constructor tier: `Expr > (,) > Compare`.
    /// The recursive RHS preserves right associativity and nested tuple shape.
    pub(super) fn parse_pair_expr(&mut self) -> Result<Ast, ParseError> {
        let left = self.parse_expr_class_expr()?;
        let is_pair = self.pair_constructor_at()
            || matches!(self.peek(), Token::FuncLiteral(body) if Self::is_pair_constructor_func_literal(body));
        if !is_pair {
            return Ok(left);
        }

        if self.pair_constructor_at() {
            self.consume_pair_constructor();
        } else {
            self.advance();
        }
        let right = self.parse_pair_expr()?;
        Ok(Self::lower_pair_constructor(left, right))
    }

    pub(super) fn parse_logical_expr(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_pair_expr()?;

        loop {
            if let Some(op) = Self::logical_binop(self.peek()) {
                self.advance();
                let right = self.parse_pair_expr()?;
                left = Self::lower_binop(left, op, right);
                continue;
            }

            let Some(Token::FuncLiteral(body)) = self.peek_n(0).cloned() else {
                break;
            };
            let func_span = self.peek_span();
            let func_kind = Self::parse_func_literal_body(&body, func_span.clone())?;

            if let FuncLiteralBodyKind::Operator(ref op_body) = func_kind {
                if let Some(op) = Self::logical_binop_from_func_literal(op_body) {
                    self.advance();
                    let right = self.parse_pair_expr()?;
                    left = Self::lower_binop(left, op, right);
                    continue;
                }
            }

            if matches!(func_kind, FuncLiteralBodyKind::Name(ref name)
                if Self::comparison_func_literal_name(name))
            {
                self.advance();
                let right = self.parse_pair_expr()?;
                left = Self::lower_func_literal_call(left, Ast::Var(func_span, body), right);
                continue;
            }

            break;
        }

        Ok(left)
    }

    pub(super) fn parse_and_or_expr(&mut self) -> Result<Ast, ParseError> {
        let mut left = self.parse_logical_expr()?;

        loop {
            if let Some(name) = Self::and_or_name(self.peek()) {
                let func_span = self.peek_span();
                self.advance();
                let right = self.parse_logical_expr()?;
                left = Self::lower_func_literal_call(
                    left,
                    Ast::Var(func_span, name.to_string()),
                    right,
                );
                continue;
            }

            let Some(Token::FuncLiteral(body)) = self.peek_n(0).cloned() else {
                break;
            };
            let func_span = self.peek_span();
            let func_kind = Self::parse_func_literal_body(&body, func_span.clone())?;
            let FuncLiteralBodyKind::Name(name) = func_kind else {
                break;
            };
            if !Self::and_or_func_literal_name(&name) {
                break;
            }

            self.advance();
            let right = self.parse_logical_expr()?;
            left = Self::lower_func_literal_call(left, Ast::Var(func_span, name), right);
        }

        Ok(left)
    }

    // ── Postfix (field access: expr.field) ──

    pub(super) fn parse_postfix(&mut self) -> Result<Ast, ParseError> {
        let mut expr = self.parse_primary()?;

        while matches!(self.peek(), Token::Dot) {
            self.advance();
            let (segment, segment_span) = self.parse_facet_path_segment_after_dot()?;
            let span = Span {
                start: expr.span().start,
                end: segment_span.end,
            };
            expr = match segment {
                FacetPathSegment::Field {
                    name,
                    optional: false,
                } => Ast::FieldAccess(span, Box::new(expr), name),
                other => Ast::FacetSegmentAccess(span, Box::new(expr), other),
            };
        }

        if self.is_timeout_modifier_start() {
            expr = self.parse_timeout_modifier(expr)?;
        }

        Ok(expr)
    }

    fn explicit_type_args_start(&self) -> bool {
        self.has_path_separator() && matches!(self.peek_n(2), Some(Token::Lt))
    }

    fn enum_constructor_type_args_start(&self) -> bool {
        if !matches!(self.peek(), Token::Lt) {
            return false;
        }
        let mut depth = 0usize;
        let mut offset = 0usize;
        loop {
            let Some(token) = self.tokens.get(self.pos + offset).map(|token| &token.token) else {
                return false;
            };
            match token {
                Token::Lt => depth += 1,
                Token::Gt => {
                    depth = depth.saturating_sub(1);
                }
                Token::Compose if depth >= 2 => depth -= 2,
                Token::Eof if depth > 0 => return false,
                Token::Newline => {}
                _ => {}
            }
            if depth == 0 {
                return matches!(
                    (
                        self.tokens
                            .get(self.pos + offset + 1)
                            .map(|token| &token.token),
                        self.tokens
                            .get(self.pos + offset + 2)
                            .map(|token| &token.token),
                    ),
                    (Some(Token::Colon), Some(Token::Colon))
                );
            }
            offset += 1;
        }
    }

    fn parse_explicit_return_type_argument_apply(
        &mut self,
        target: Ast,
    ) -> Result<Ast, ParseError> {
        let start = target.span().start;
        let (span, args) = self.parse_explicit_return_type_arguments(
            start,
            crate::error::ParseErrorReason::ExpressionSyntax,
        )?;
        Ok(Ast::ReturnTypeArgumentApply(span, Box::new(target), args))
    }

    fn parse_explicit_return_type_arguments(
        &mut self,
        start: usize,
        empty_reason: crate::error::ParseErrorReason,
    ) -> Result<(Span, Vec<ReturnTypeArgument>), ParseError> {
        let list_start = self.peek_span().start;
        self.consume_path_separator()?;
        self.expect(&Token::Lt)?;
        self.skip_newlines();
        if matches!(self.peek(), Token::Gt) {
            return Err(ParseError::syntax(
                empty_reason,
                "Explicit type arguments cannot be empty",
                Span {
                    start: list_start,
                    end: self.peek_span().end,
                },
            ));
        }
        let first = self.parse_type_in_impl_context(None)?;
        let mut args = vec![ReturnTypeArgument {
            ordinal: 0,
            span: ast_ty_span(&first).clone(),
            ty: first,
        }];
        self.skip_newlines();
        while matches!(self.peek(), Token::Comma) {
            self.advance();
            self.skip_newlines();
            if matches!(self.peek(), Token::Gt) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Explicit type arguments cannot end with a comma",
                    self.peek_span(),
                ));
            }
            let ty = self.parse_type_in_impl_context(None)?;
            args.push(ReturnTypeArgument {
                ordinal: args.len() as u32,
                span: ast_ty_span(&ty).clone(),
                ty,
            });
            self.skip_newlines();
        }
        let end = self.expect_type_gt()?;
        Ok((
            Span {
                start,
                end: end.end,
            },
            args,
        ))
    }

    fn parse_enum_constructor_call(
        &mut self,
        owner_name: Symbol,
        start: usize,
    ) -> Result<Ast, ParseError> {
        self.expect(&Token::Lt)?;
        self.skip_newlines();
        if matches!(self.peek(), Token::Gt) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Enum constructor type arguments cannot be empty",
                self.peek_span(),
            ));
        }
        let mut type_args = vec![self.parse_type()?];
        self.skip_newlines();
        while matches!(self.peek(), Token::Comma) {
            self.advance();
            self.skip_newlines();
            if matches!(self.peek(), Token::Gt) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Enum constructor type arguments cannot end with a comma",
                    self.peek_span(),
                ));
            }
            type_args.push(self.parse_type()?);
            self.skip_newlines();
        }
        self.expect_type_gt()?;
        self.consume_path_separator()?;
        let (variant_name, variant_span) = self.expect_member_ident()?;

        let (args, end) = if matches!(self.peek(), Token::LParen) {
            self.advance();
            let args = self.parse_call_args()?;
            self.skip_newlines();
            let end = self.expect(&Token::RParen)?.end;
            (args, end)
        } else if matches!(self.peek(), Token::Unit) {
            (Vec::new(), self.advance().span.end)
        } else {
            (Vec::new(), variant_span.end)
        };
        self.reject_constructor_trailing_block()?;
        Ok(Ast::EnumConstructorCall(
            Span { start, end },
            owner_name,
            type_args,
            variant_name,
            args,
        ))
    }

    /// Parse only the target portion of a generic enum constructor capture.
    /// The capture's own positional argument block is parsed by
    /// `parse_capture_expr`, so `&Either<_, Int>::Left(&1)` remains a capture
    /// rather than becoming an ordinary constructor call in the AST.
    fn parse_enum_constructor_capture_target(
        &mut self,
        owner_name: Symbol,
        start: usize,
    ) -> Result<Ast, ParseError> {
        self.expect(&Token::Lt)?;
        self.skip_newlines();
        if matches!(self.peek(), Token::Gt) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Enum constructor type arguments cannot be empty",
                self.peek_span(),
            ));
        }
        let mut type_args = vec![self.parse_type()?];
        self.skip_newlines();
        while matches!(self.peek(), Token::Comma) {
            self.advance();
            self.skip_newlines();
            if matches!(self.peek(), Token::Gt) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Enum constructor type arguments cannot end with a comma",
                    self.peek_span(),
                ));
            }
            type_args.push(self.parse_type()?);
            self.skip_newlines();
        }
        let end = self.expect_type_gt()?.end;
        self.consume_path_separator()?;
        let (variant_name, variant_span) = self.expect_member_ident()?;
        Ok(Ast::EnumConstructorCall(
            Span {
                start,
                end: variant_span.end.max(end),
            },
            owner_name,
            type_args,
            variant_name,
            Vec::new(),
        ))
    }

    fn parse_facet_path_segment_after_dot(
        &mut self,
    ) -> Result<(FacetPathSegment, Span), ParseError> {
        match self.peek() {
            Token::NumberedPlaceholder(digits) => {
                let name = format!("_{digits}");
                let span = self.advance().span;
                Ok((FacetPathSegment::field(name), span))
            }
            Token::Ident(_) => {
                let (name, name_span) = self.expect_ident()?;
                if matches!(self.peek(), Token::Question) {
                    Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "OptionalSelector is no longer supported",
                        self.peek_span(),
                    ))
                } else {
                    Ok((FacetPathSegment::field(name), name_span))
                }
            }
            Token::True | Token::False => {
                let token = self.advance();
                let name = match token.token {
                    Token::True => "True",
                    Token::False => "False",
                    _ => unreachable!("matched Boolean variant token"),
                };
                if matches!(self.peek(), Token::Question) {
                    Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "OptionalSelector is no longer supported",
                        self.peek_span(),
                    ))
                } else {
                    Ok((FacetPathSegment::field(name.to_string()), token.span))
                }
            }
            Token::LBrack => {
                self.advance();
                let start_expr = self.parse_expr()?;
                let expr = if matches!(self.peek(), Token::DotDot) {
                    self.advance();
                    let end_expr = self.parse_expr()?;
                    let span = Span {
                        start: start_expr.span().start,
                        end: end_expr.span().end,
                    };
                    Ast::RangeLiteral(span, Box::new(start_expr), Box::new(end_expr))
                } else {
                    start_expr
                };
                let rbrack = self.expect(&Token::RBrack)?;
                let display = self.source[expr.span().start..expr.span().end].to_string();
                Ok((
                    FacetPathSegment::Bracket(FacetBracketExpr {
                        expr: Box::new(expr),
                        display,
                    }),
                    rbrack,
                ))
            }
            Token::Int(_) => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Expected field name after '.'. Tuple access uses ._0, ._1, ...",
                self.peek_span(),
            )),
            other => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                format!(
                    "Facet path segment after `.` expects identifier or bracket segment, got {other:?}"
                ),
                self.peek_span(),
            )),
        }
    }

    // ── Primary ──

    pub(super) fn parse_primary(&mut self) -> Result<Ast, ParseError> {
        let sp = self.peek_span();
        let pipe_outer_call = std::mem::take(&mut self.pending_pipe_outer_call);

        match self.peek().clone() {
            Token::Bang => {
                self.advance();
                let inner = self.parse_primary()?;
                let span = Span {
                    start: sp.start,
                    end: inner.span().end,
                };
                Ok(Ast::App(
                    span.clone(),
                    Box::new(Ast::Path(
                        span.clone(),
                        AstPath {
                            span: span.clone(),
                            segments: vec!["Boolean".into(), "not".into()],
                        },
                    )),
                    vec![RecordLitArg::Positional(inner)],
                ))
            }

            Token::ReservedEnv => Err(ParseError::syntax(
                crate::error::ParseErrorReason::PositionRule,
                "`__ENV__` is reserved and cannot be used",
                sp,
            )),
            Token::Reflection(value) => {
                self.advance();
                if self.context.unit_kind == super::context::ParseUnitKind::Repl {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::PositionRule,
                        "source reflections are disabled in REPL expressions; use :doc or :sig",
                        sp,
                    ));
                }
                if matches!(
                    self.peek(),
                    Token::Unit | Token::LParen | Token::Bind | Token::SafeBind | Token::Colon
                ) {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::PositionRule,
                        "source reflection functions must be called without parentheses and cannot be bound",
                        sp,
                    ));
                }
                Ok(Ast::Reflection(sp, value))
            }

            // Literals
            Token::Int(n) => {
                self.advance();
                if self.is_duration_suffix_here() {
                    let suffix_span = self.advance().span.clone();
                    let int_expr = Ast::Lit(sp.clone(), Lit::Int(n));
                    return Ok(self.duration_literal(
                        int_expr,
                        Span {
                            start: sp.start,
                            end: suffix_span.end,
                        },
                    ));
                }
                Ok(Ast::Lit(sp, Lit::Int(n)))
            }
            Token::Float(f) => {
                self.advance();
                Ok(Ast::Lit(sp, Lit::Float(f)))
            }
            Token::Str(s) => {
                self.advance();
                self.parse_string_or_interpolated(sp, s)
            }
            Token::DocString(s) => {
                self.advance();
                self.parse_triple_string_or_interpolated(sp, s)
            }
            Token::True => {
                self.advance();
                self.parse_ident_continuation("True".into(), sp, pipe_outer_call)
            }
            Token::False => {
                self.advance();
                self.parse_ident_continuation("False".into(), sp, pipe_outer_call)
            }
            Token::Unit => {
                self.advance();
                Ok(Ast::Lit(sp, Lit::Unit))
            }

            // Negative number: unary minus
            Token::Minus => {
                self.advance();
                if let Token::Ident(name) = self.peek().clone() {
                    let name_span = self.peek_span();
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        format!(
                            "Unary minus on variables is not supported in Phase 1; write `0 - {}` instead of `-{}`",
                            name, name
                        ),
                        Span {
                            start: sp.start,
                            end: name_span.end,
                        },
                    ));
                }
                let inner = self.parse_primary()?;
                let end = inner.span().end;
                // Fold negative literals directly
                match inner {
                    Ast::Lit(_, Lit::Int(n)) => Ok(Ast::Lit(
                        Span {
                            start: sp.start,
                            end,
                        },
                        Lit::Int(-n),
                    )),
                    Ast::Lit(_, Lit::Float(f)) => Ok(Ast::Lit(
                        Span {
                            start: sp.start,
                            end,
                        },
                        Lit::Float(-f),
                    )),
                    _ => {
                        // General unary minus: desugar to 0 - expr (for Int)
                        // For now, only support literal negation
                        Err(ParseError::syntax(
                            crate::error::ParseErrorReason::ExpressionSyntax,
                            "Unary minus is only supported on numeric literals in Phase 1; write `0 - expr` for general subtraction",
                            Span {
                                start: sp.start,
                                end,
                            },
                        ))
                    }
                }
            }

            // List expression: [], [a, b, c], [head, ..tail]
            Token::LBrack => self.parse_list_expr(sp),

            // Parenthesized expression
            Token::LParen if self.pair_constructor_at() => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "bare `(,)` is only valid in infix position",
                self.pair_constructor_span(),
            )
            .with_guidance(crate::error::ParseErrorGuidance::PairConstructorCapture)),
            Token::LParen => self.with_parse_nesting(sp.clone(), |parser| {
                parser.advance();
                parser.skip_newlines();
                let first = parser.parse_expr()?;
                parser.skip_newlines();
                if matches!(parser.peek(), Token::Comma) {
                    parser.advance();
                    parser.skip_newlines();
                    if matches!(parser.peek(), Token::RParen) {
                        return Err(ParseError::syntax(
                            crate::error::ParseErrorReason::ExpressionSyntax,
                            "1-tuple literals are not supported",
                            Span {
                                start: sp.start,
                                end: parser.peek_span().end,
                            },
                        ));
                    }
                    let mut items = vec![first, parser.parse_expr()?];
                    parser.skip_newlines();
                    while matches!(parser.peek(), Token::Comma) {
                        parser.advance();
                        parser.skip_newlines();
                        if matches!(parser.peek(), Token::RParen) {
                            break;
                        }
                        items.push(parser.parse_expr()?);
                        parser.skip_newlines();
                    }
                    let end = parser.expect(&Token::RParen)?;
                    Ok(Ast::TupleLiteral(
                        Span {
                            start: sp.start,
                            end: end.end,
                        },
                        items,
                    ))
                } else {
                    let end = parser.expect(&Token::RParen)?;
                    Ok(Ast::Grouped(
                        Span {
                            start: sp.start,
                            end: end.end,
                        },
                        Box::new(first),
                    ))
                }
            }),

            Token::Star => self.with_parse_nesting(sp.clone(), |parser| {
                parser.advance();
                parser.expect(&Token::LBrace)?;
                parser.skip_newlines();
                let Ast::Closure(span, params, body) = parser.parse_closure_literal(sp)? else {
                    unreachable!()
                };
                if params.is_empty() {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "ExtractorClosure requires at least one input",
                        span,
                    ));
                }
                Ok(Ast::ExtractorClosure(span, params, body))
            }),

            // Zero-argument closure expression: { stmt; stmt; expr }
            Token::LBrace => self.parse_trailing_block_expr_from_lbrace(sp),

            // Capture / placeholder capture: &foo, &foo(&1), &1
            Token::Amp => self.parse_capture_expr(sp),
            Token::Tilde => self.parse_facet_capture_expr(sp),
            Token::Caret => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Pin operator ^ is only allowed in MatchBlock patterns and bulk_update paths.",
                sp,
            )),

            Token::FuncLiteral(body) => {
                self.parse_quoted_callee_call(sp, body, false, pipe_outer_call)
            }

            // Match expression
            Token::Match => self.parse_match_expr(),

            // Cond expression
            Token::Cond => self.parse_cond_expr(),
            Token::BulkUpdate => {
                self.advance();
                self.parse_bulk_update_call(sp.start)
            }

            // Compiler-owned monadic sequencing expression
            Token::Do => self.parse_do_expr(sp),

            // Identifier — could be: variable, binding, function call
            Token::Ident(name) => {
                self.advance();
                self.parse_ident_continuation(name, sp, pipe_outer_call)
            }
            Token::ReservedCallName(kind) => {
                self.advance();
                self.parse_ident_continuation(kind.name().to_string(), sp, pipe_outer_call)
            }
            Token::PatternConsumer(kind) => {
                self.advance();
                self.parse_ident_continuation(kind.name().to_string(), sp, pipe_outer_call)
            }
            Token::NumberedPlaceholder(digits) => {
                self.advance();
                Ok(Ast::NumberedPlaceholder(
                    sp.clone(),
                    Self::numbered_placeholder_index(&digits, sp)?,
                ))
            }

            Token::Eof => Err(ParseError::incomplete("expression", sp)),
            _ => {
                let token_kind = format!("{:?}", self.peek());
                Err(ParseError::syntax(
                    crate::error::ParseErrorReason::UnexpectedToken,
                    format!("Unexpected token: {token_kind}"),
                    sp,
                )
                .with_token_kind(token_kind)
                .with_guidance(crate::error::ParseErrorGuidance::UnexpectedToken))
            }
        }
    }

    fn parse_do_expr(&mut self, do_span: Span) -> Result<Ast, ParseError> {
        self.advance();

        if matches!(self.peek(), Token::Lt) {
            let invalid_span = self.do_angle_argument_span();
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
                "`do<...>` is not valid carrier syntax",
                invalid_span,
            )
            .with_guidance(crate::error::ParseErrorGuidance::DoCarrierReturnTypeArgument));
        }

        let return_type_arguments = if self.explicit_type_args_start() {
            let rta_start = self.peek_span().start;
            let (rta_span, arguments) = self.parse_explicit_return_type_arguments(
                do_span.start,
                crate::error::ParseErrorReason::ReturnTypeArgumentArityMismatch,
            )?;
            if arguments.len() != 1 {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ReturnTypeArgumentArityMismatch,
                    "`do` expects exactly one return type argument",
                    Span {
                        start: rta_start,
                        end: rta_span.end,
                    },
                ));
            }
            let carrier_ty = &arguments[0].ty;
            let outer_constructor_variable = matches!(
                carrier_ty,
                AstTy::Named(_, name) | AstTy::Generic(_, name, _) if name.starts_with('$')
            );
            let valid_carrier_shape = matches!(
                carrier_ty,
                AstTy::Named(_, name) | AstTy::Generic(_, name, _) if !name.starts_with('$')
            );
            if !valid_carrier_shape {
                let message = if outer_constructor_variable {
                    "`do` return type argument must be a constructor head, applied carrier, or `_`; an outer constructor variable is not a valid carrier type input"
                } else {
                    "`do` return type argument must be a constructor head, applied carrier, or `_`"
                };
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::InvalidDoCarrierReturnTypeArgument,
                    message,
                    arguments[0].span.clone(),
                )
                .with_guidance(crate::error::ParseErrorGuidance::DoCarrierReturnTypeArgument));
            }
            arguments
        } else {
            Vec::new()
        };

        if !matches!(self.peek(), Token::LBrace) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "`do` requires a block",
                self.peek_span(),
            ));
        }

        self.with_parse_nesting(do_span.clone(), |parser| {
            parser.advance();
            parser.skip_newlines();
            let mut statements = Vec::new();
            while !matches!(parser.peek(), Token::RBrace) {
                if matches!(parser.peek(), Token::Eof) {
                    return Err(ParseError::incomplete("}", parser.peek_span()));
                }

                let start = parser.pos;
                let is_do_pattern_statement = parser.is_pattern_bind_stmt_start()
                    && parser.stmt_has_top_level_token_from(start, |token| {
                        matches!(token, Token::LeftArrow | Token::SafeBind)
                    });
                let statement = if is_do_pattern_statement {
                    parser.parse_do_pattern_statement()?
                } else {
                    AstDoStatement::Statement(parser.parse_stmt()?)
                };
                let boundary_ast = match &statement {
                    AstDoStatement::Extract { rhs, .. } | AstDoStatement::SafeBind { rhs, .. } => {
                        rhs
                    }
                    AstDoStatement::Statement(statement) => statement,
                };
                if is_do_pattern_statement && matches!(parser.peek(), Token::Semicolon) {
                    parser.advance();
                } else {
                    parser.ensure_stmt_boundary(boundary_ast, true)?;
                }
                statements.push(statement);
                while matches!(parser.peek(), Token::Newline) {
                    parser.advance();
                }
            }

            let end = parser.expect(&Token::RBrace)?;
            let has_final_expression = matches!(
                statements.last(),
                Some(AstDoStatement::Statement(statement))
                    if !matches!(statement, Ast::Bind(..) | Ast::SafeBind(..) | Ast::Semi(..))
            );
            if !has_final_expression {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "A do block must end with a final monadic expression",
                    Span {
                        start: do_span.start,
                        end: end.end,
                    },
                ));
            }

            Ok(Ast::Do(
                Span {
                    start: do_span.start,
                    end: end.end,
                },
                return_type_arguments,
                statements,
                do_span,
            ))
        })
    }

    fn do_angle_argument_span(&self) -> Span {
        let start = self.peek_span();
        let mut depth = 0usize;
        let mut end = start.end;
        for token in self.tokens.iter().skip(self.pos) {
            end = token.span.end;
            match &token.token {
                Token::Lt => depth += 1,
                Token::Gt => {
                    depth = depth.saturating_sub(1);
                    if depth == 0 {
                        break;
                    }
                }
                Token::Compose => {
                    if depth <= 2 {
                        break;
                    }
                    depth -= 2;
                }
                Token::Newline | Token::LBrace | Token::RBrace | Token::Eof => break,
                _ => {}
            }
        }
        Span {
            start: start.start,
            end,
        }
    }

    /// Parse a backtick-quoted callee such as `` `Add::add`(1, 2) ``.
    /// Quoting is syntactic only: it never creates a function value.
    fn parse_quoted_callee_call(
        &mut self,
        span: Span,
        body: String,
        allow_partial_pair_constructor_call: bool,
        pipe_outer_call: bool,
    ) -> Result<Ast, ParseError> {
        let func_span = self.advance().span.clone();
        if !matches!(self.peek(), Token::LParen | Token::Unit) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "FuncLiteral must appear in infix position or be followed by a call",
                func_span,
            ));
        }

        let kind = Self::parse_func_literal_body(&body, func_span.clone())?;
        let callee = match &kind {
            FuncLiteralBodyKind::Name(name) => Some(Ast::Var(func_span.clone(), name.clone())),
            FuncLiteralBodyKind::Path(path) => Some(Ast::Path(path.span.clone(), path.clone())),
            FuncLiteralBodyKind::Operator(_) => None,
        };
        if let Some(callee) = callee {
            if let Some(consumer) = Self::source_pattern_consumer(&callee) {
                return self.parse_pattern_consumer_call(
                    callee,
                    consumer,
                    span.start,
                    pipe_outer_call,
                );
            }
        }

        let args = if matches!(self.peek(), Token::Unit) {
            self.advance();
            Vec::new()
        } else {
            self.advance();
            let args = self.parse_call_args()?;
            self.skip_newlines();
            self.expect(&Token::RParen)?;
            args
        };
        let end = self.tokens[self.pos - 1].span.end;
        match Self::parse_func_literal_body(&body, func_span.clone())? {
            FuncLiteralBodyKind::Operator(op_body) => {
                if Self::is_pair_constructor_func_literal(&op_body) {
                    let [RecordLitArg::Positional(left), RecordLitArg::Positional(right)] =
                        args.as_slice()
                    else {
                        if allow_partial_pair_constructor_call
                            && matches!(args.as_slice(), [RecordLitArg::Positional(_)])
                        {
                            return Ok(Ast::App(
                                Span {
                                    start: span.start,
                                    end,
                                },
                                Box::new(Ast::FuncLiteralRef(
                                    func_span.clone(),
                                    FuncLiteralRef {
                                        span: func_span,
                                        body: op_body,
                                    },
                                )),
                                args,
                            ));
                        }

                        return Err(ParseError::syntax(
                            crate::error::ParseErrorReason::ExpressionSyntax,
                            "quoted pair constructor call `(,)` expects exactly 2 positional arguments",
                            Span {
                                start: span.start,
                                end,
                            },
                        ));
                    };
                    return Ok(Self::lower_pair_constructor(left.clone(), right.clone()));
                }
                let [RecordLitArg::Positional(left), RecordLitArg::Positional(right)] =
                    args.as_slice()
                else {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        format!(
                            "quoted operator call `{}` expects exactly 2 positional arguments",
                            op_body
                        ),
                        Span {
                            start: span.start,
                            end,
                        },
                    ));
                };
                let Some(op) = Self::expr_binop_from_func_literal(&op_body, func_span.clone())
                else {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        format!("quoted operator call `{}` is not supported", op_body),
                        func_span,
                    ));
                };
                Ok(Self::lower_binop(left.clone(), op, right.clone()))
            }
            FuncLiteralBodyKind::Name(name) => Ok(Ast::App(
                Span {
                    start: span.start,
                    end,
                },
                Box::new(Ast::Var(func_span, name)),
                args,
            )),
            FuncLiteralBodyKind::Path(path) => Ok(Ast::App(
                Span {
                    start: span.start,
                    end,
                },
                Box::new(Ast::Path(path.span.clone(), path)),
                args,
            )),
        }
    }

    pub(super) fn is_duration_suffix_here(&self) -> bool {
        matches!(self.peek(), Token::Ident(name) if name == "ms")
    }

    fn is_timeout_modifier_start(&self) -> bool {
        matches!(self.peek(), Token::Annotator(name) if name == "timeout")
    }

    fn hidden_call(&self, name: &str, args: Vec<RecordLitArg>, span: Span) -> Ast {
        Ast::App(
            span.clone(),
            Box::new(Ast::InternalVar(
                Span {
                    start: span.start,
                    end: span.start,
                },
                name.to_string(),
            )),
            args,
        )
    }

    fn duration_literal(&self, value: Ast, span: Span) -> Ast {
        Ast::InternalStructLit(
            span,
            "Duration".into(),
            vec![crate::ast::StructLitField::Explicit("millis".into(), value)],
        )
    }

    fn std_hidden_ref(&self, span: Span, name: Symbol) -> Ast {
        if name.starts_with("__")
            && self
                .context
                .parse_rules
                .allowed_top_level_decl_kinds
                .allows(super::context::TopLevelDeclKind::BuiltinDecl)
        {
            Ast::InternalVar(span, name)
        } else {
            Ast::Var(span, name)
        }
    }

    fn parse_timeout_duration_literal(&mut self) -> Result<Ast, ParseError> {
        let sp = self.peek_span();
        let Token::Int(n) = self.peek().clone() else {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "@timeout(...) requires a duration literal like `100ms`",
                sp,
            ));
        };
        self.advance();
        if !self.is_duration_suffix_here() {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "@timeout(...) requires a duration literal like `100ms`",
                sp,
            ));
        }
        let suffix_span = self.advance().span.clone();
        let int_expr = Ast::Lit(sp.clone(), Lit::Int(n));
        Ok(self.duration_literal(
            int_expr,
            Span {
                start: sp.start,
                end: suffix_span.end,
            },
        ))
    }

    fn parse_timeout_modifier(&mut self, expr: Ast) -> Result<Ast, ParseError> {
        let start = expr.span().start;
        let modifier_span = self.peek_span();
        let Token::Annotator(modifier) = self.peek().clone() else {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Expected @timeout(...)",
                self.peek_span(),
            ));
        };
        self.advance();
        if modifier != "timeout" {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                format!("Unsupported call modifier: @{modifier}"),
                modifier_span,
            ));
        }
        self.expect(&Token::LParen)?;
        let timeout_arg = self.parse_timeout_duration_literal()?;
        self.skip_newlines();
        let end_span = self.expect(&Token::RParen)?;

        let (target, mut args) = match expr {
            Ast::App(_, func, args) => (*func, args),
            _ => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "@timeout(...) can only be applied to runtime-managed calls",
                    Span {
                        start,
                        end: end_span.end,
                    },
                ));
            }
        };

        let hidden_name = match &target {
            Ast::Path(_, path) if path.segments.as_slice() == ["Task", "call"] => {
                "__task_call_timeout"
            }
            Ast::Path(_, path) if path.segments.as_slice() == ["Task", "await"] => {
                "__task_await_timeout"
            }
            Ast::Path(_, path) if path.segments.as_slice() == ["Workers", "submit"] => {
                "__workers_submit_timeout"
            }
            Ast::Path(_, path) if path.segments.as_slice() == ["Workers", "broadcast"] => {
                "__workers_broadcast_timeout"
            }
            _ => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "@timeout(...) is only supported on Task::call/await and Workers::submit/broadcast",
                    Span {
                        start,
                        end: end_span.end,
                    },
                ));
            }
        };

        let expected_arity = match hidden_name {
            "__task_call_timeout" | "__task_await_timeout" => 1,
            "__workers_submit_timeout" | "__workers_broadcast_timeout" => 2,
            _ => 1,
        };

        if args.len() != expected_arity
            || args
                .iter()
                .any(|arg| matches!(arg, RecordLitArg::Named(_, _)))
        {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "@timeout(...) expects positional arguments for the runtime-managed call",
                Span {
                    start,
                    end: end_span.end,
                },
            ));
        }

        args.insert(0, RecordLitArg::Positional(timeout_arg));
        Ok(self.hidden_call(
            hidden_name,
            args,
            Span {
                start,
                end: end_span.end,
            },
        ))
    }

    fn source_pattern_consumer(callee: &Ast) -> Option<sindr::pattern::PatternConsumer> {
        match callee {
            Ast::Var(_, name) => sindr::pattern::PatternConsumer::from_name(name),
            Ast::Path(_, path) => sindr::pattern::PatternConsumer::from_source_path(&path.segments),
            _ => None,
        }
    }

    fn consumer_expression_argument(expression: Ast) -> AstPatternArgument {
        AstPatternArgument {
            span: expression.span().clone(),
            expression: Some(Box::new(expression)),
            pattern: None,
            named_pattern: None,
            expression_error: None,
            pattern_error: None,
        }
    }

    fn consumer_pattern_argument(pattern: AstPattern) -> AstPatternArgument {
        AstPatternArgument {
            span: super::pattern_span(&pattern).clone(),
            pattern: Some(Box::new(pattern)),
            expression: None,
            named_pattern: None,
            expression_error: None,
            pattern_error: None,
        }
    }

    fn parse_consumer_pattern(
        &mut self,
        kind: sindr::pattern::PatternConsumer,
    ) -> Result<AstPattern, ParseError> {
        if matches!(self.peek(), Token::Amp) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::PatternSyntax,
                "Pattern argument cannot be a capture placeholder",
                self.peek_span(),
            ));
        }
        let pattern = self.parse_pattern()?;
        if !kind.allows_or() {
            self.reject_binding_or(&pattern)?;
        }
        Ok(pattern)
    }

    /// Locate slots only in direct argument syntax. Nested expressions and Pattern
    /// projections do not participate in the outer pipe operation.
    fn direct_pipe_argument_slots(&self) -> Vec<usize> {
        let mut slots = Vec::new();
        if !matches!(self.peek(), Token::LParen) {
            return slots;
        }
        let mut depth = 0usize;
        let mut start = self.pos + 1;
        let mut ordinal = 0usize;
        for index in start..self.tokens.len() {
            let token = &self.tokens[index].token;
            if depth == 0 && matches!(token, Token::Comma | Token::RParen) {
                let mut argument = &self.tokens[start..index];
                while argument
                    .first()
                    .is_some_and(|token| matches!(token.token, Token::Newline))
                {
                    argument = &argument[1..];
                }
                while argument
                    .last()
                    .is_some_and(|token| matches!(token.token, Token::Newline))
                {
                    argument = &argument[..argument.len() - 1];
                }
                if matches!(argument, [token] if matches!(token.token, Token::NumberedPlaceholder(_)))
                {
                    slots.push(ordinal);
                }
                if matches!(token, Token::RParen) {
                    return slots;
                }
                ordinal += 1;
                start = index + 1;
            } else {
                match token {
                    Token::LParen | Token::LBrack | Token::LBrace => depth += 1,
                    Token::RParen | Token::RBrack | Token::RBrace => {
                        depth = depth.saturating_sub(1)
                    }
                    Token::Eof => return slots,
                    _ => {}
                }
            }
        }
        slots
    }

    /// A prefix call receives pipe argument mapping only when it is the RHS
    /// expression itself. Look ahead through delimiters; never reparse arguments
    /// after choosing their grammar, and keep unfinished calls in that grammar.
    fn pipe_consumer_is_outer_call(&self) -> Result<bool, ParseError> {
        let next_index = if matches!(self.peek(), Token::Unit) {
            self.pos + 1
        } else {
            let mut depth = 0usize;
            let mut end = None;
            for (index, spanned) in self.tokens.iter().enumerate().skip(self.pos) {
                match spanned.token {
                    Token::LParen => depth += 1,
                    Token::RParen => {
                        depth = depth.saturating_sub(1);
                        if depth == 0 {
                            end = Some(index + 1);
                            break;
                        }
                    }
                    Token::Eof => return Ok(true),
                    _ => {}
                }
            }
            let Some(end) = end else {
                return Ok(true);
            };
            end
        };
        let Some(next) = self.tokens.get(next_index) else {
            return Ok(true);
        };
        if Self::expr_binop(&next.token, next.span.clone()).is_some()
            || Self::logical_binop(&next.token).is_some()
            || Self::and_or_name(&next.token).is_some()
            || matches!(next.token, Token::Dot)
            || matches!(&next.token, Token::Annotator(name) if name == "timeout")
            || matches!(
                (
                    &next.token,
                    self.tokens.get(next_index + 1).map(|token| &token.token),
                    self.tokens.get(next_index + 2).map(|token| &token.token)
                ),
                (Token::LParen, Some(Token::Comma), Some(Token::RParen))
            )
        {
            return Ok(false);
        }
        if let Token::FuncLiteral(body) = &next.token {
            let kind = Self::parse_func_literal_body(body, next.span.clone())?;
            return Ok(Self::low_precedence_on_target_callee(&kind, &next.span).is_some());
        }
        Ok(true)
    }

    fn parse_pattern_consumer_call(
        &mut self,
        callee: Ast,
        kind: sindr::pattern::PatternConsumer,
        start: usize,
        pipe_outer_call: bool,
    ) -> Result<Ast, ParseError> {
        let pipe_outer_call = pipe_outer_call && self.pipe_consumer_is_outer_call()?;
        let slots = if pipe_outer_call {
            self.direct_pipe_argument_slots()
        } else {
            Vec::new()
        };
        let inject_first = pipe_outer_call && slots.is_empty();
        let mut args = Vec::new();
        let end = if matches!(self.peek(), Token::Unit) {
            self.advance().span.end
        } else {
            self.expect(&Token::LParen)?;
            self.skip_newlines();
            while !matches!(self.peek(), Token::RParen) {
                let written_index = args.len();
                let parameter_index = written_index + usize::from(inject_first);
                let arg =
                    if parameter_index == kind.pattern_index() && !slots.contains(&written_index) {
                        Self::consumer_pattern_argument(self.parse_consumer_pattern(kind)?)
                    } else {
                        Self::consumer_expression_argument(self.parse_expr()?)
                    };
                args.push(arg);
                self.skip_newlines();
                if !matches!(self.peek(), Token::Comma) {
                    break;
                }
                self.advance();
                self.skip_newlines();
            }
            self.expect(&Token::RParen)?.end
        };
        Ok(Ast::PatternConsumerCall(
            Span { start, end },
            Box::new(callee),
            args,
        ))
    }

    /// After seeing an identifier, figure out what it is:
    /// - `Name { field: val }` → StructLit (uppercase start + `{`)
    /// - `Name(args)` → ConstructorCall if uppercase, App if lowercase
    /// - `name()` / `Name()` → zero-arg call
    /// - `name: Type = expr` → Bind (annotated)
    /// - `name = expr` → Bind
    /// - otherwise → Var
    pub(super) fn parse_ident_continuation(
        &mut self,
        mut name: Symbol,
        mut name_span: Span,
        pipe_outer_call: bool,
    ) -> Result<Ast, ParseError> {
        if sindr::names::is_reserved_value_name(&name)
            && matches!(self.peek(), Token::Bind | Token::SafeBind | Token::Colon)
        {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::DeclarationSyntax,
                if sindr::pattern::PatternConsumer::from_name(&name).is_some() {
                    "Pattern consumer names cannot be bound or shadowed"
                } else {
                    "Reserved call names cannot be bound or shadowed"
                },
                name_span,
            ));
        }
        if name == "dbg" && matches!(self.peek(), Token::Bang) {
            return self.parse_dbg_special_form(name_span);
        }
        if name == "hash" && matches!(self.peek(), Token::Bang) {
            return self.parse_hash_map_literal(name_span);
        }

        let mut path_segments = vec![name.clone()];
        let mut path_end = name_span.end;
        while self.has_path_separator()
            && (matches!(
                self.peek_n(2),
                Some(
                    Token::Ident(_)
                        | Token::PatternConsumer(_)
                        | Token::ReservedCallName(_)
                        | Token::True
                        | Token::False
                )
            ) || (path_segments.as_slice() == ["Facet"]
                && matches!(self.peek_n(2), Some(Token::BulkUpdate))))
        {
            self.consume_path_separator()?;
            let (seg, seg_span) = if matches!(self.peek(), Token::BulkUpdate) {
                ("bulk_update".into(), self.advance().span)
            } else {
                self.expect_member_ident()?
            };
            path_end = seg_span.end;
            path_segments.push(seg);
        }

        // A suffix belongs to a callable only when the following syntax is a call
        // or an explicit return-type application. Bare `value?` remains statement unwrap.
        if matches!(self.peek(), Token::Question)
            && path_end == self.peek_span().start
            && (matches!(self.peek_n(1), Some(Token::LParen | Token::Unit))
                || (matches!(self.peek_n(1), Some(Token::Colon))
                    && matches!(self.peek_n(2), Some(Token::Colon))
                    && matches!(self.peek_n(3), Some(Token::Lt))))
        {
            let last = path_segments
                .last_mut()
                .expect("identifier path is nonempty");
            last.push('?');
            path_end = self.advance().span.end;
            if path_segments.len() == 1 {
                name = path_segments[0].clone();
                name_span.end = path_end;
            }
        }

        if name == "self" && self.impl_target_stack.is_empty() {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "`self` can only be used inside impl methods",
                name_span,
            ));
        }

        Self::validate_pattern_consumer_path(
            &path_segments,
            Span {
                start: name_span.start,
                end: path_end,
            },
        )?;

        if let Some(meta) =
            sindr::names::special_enum_variant_surface_meta(&path_segments.join("::"))
        {
            debug_assert_eq!(
                meta.identity(),
                sindr::names::TypeIdentity::SpecialEnumVariant
            );
            path_segments = meta
                .qualified_name
                .split("::")
                .map(str::to_string)
                .collect();
        }

        let path_ast = if path_segments.len() > 1 {
            Some(Ast::Path(
                Span {
                    start: name_span.start,
                    end: path_end,
                },
                AstPath {
                    span: Span {
                        start: name_span.start,
                        end: path_end,
                    },
                    segments: path_segments.clone(),
                },
            ))
        } else {
            None
        };

        if let Some(consumer) = sindr::pattern::PatternConsumer::from_source_path(&path_segments) {
            if matches!(self.peek(), Token::LParen | Token::Unit) {
                let callee = path_ast.unwrap_or_else(|| Ast::Var(name_span.clone(), name.clone()));
                return self.parse_pattern_consumer_call(
                    callee,
                    consumer,
                    name_span.start,
                    pipe_outer_call,
                );
            }
        }

        let path_last_is_uppercase = path_segments
            .last()
            .and_then(|segment| segment.chars().next())
            .is_some_and(|ch| ch.is_uppercase());
        if path_last_is_uppercase && self.enum_constructor_type_args_start() {
            return self.parse_enum_constructor_call(path_segments.join("::"), name_span.start);
        }

        if let Some(mut path_expr) = path_ast {
            let path_name = path_segments.join("::");
            if path_name == "Facet::bulk_update" {
                return self.parse_bulk_update_call(name_span.start);
            }
            if self.explicit_type_args_start() {
                if path_last_is_uppercase {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "Explicit type arguments apply to callables, not constructors",
                        self.peek_span(),
                    ));
                }
                path_expr = self.parse_explicit_return_type_argument_apply(path_expr)?;
            }
            if matches!(self.peek(), Token::LParen) {
                self.advance();
                let args = self.parse_call_args()?;
                self.skip_newlines();
                let end_span = self.expect(&Token::RParen)?;
                if path_last_is_uppercase {
                    self.reject_constructor_trailing_block()?;
                    let span = Span {
                        start: name_span.start,
                        end: end_span.end,
                    };
                    return Ok(Ast::ConstructorCall(span, path_name, args));
                }
                let (args, call_end) =
                    self.attach_trailing_block_arg(&path_expr, args, end_span.end)?;
                let span = Span {
                    start: name_span.start,
                    end: call_end,
                };
                return Ok(Ast::App(span, Box::new(path_expr), args));
            }

            if matches!(self.peek(), Token::Unit) {
                let end_span = self.advance().span.clone();
                if path_last_is_uppercase {
                    self.reject_constructor_trailing_block()?;
                    let span = Span {
                        start: name_span.start,
                        end: end_span.end,
                    };
                    return Ok(Ast::ConstructorCall(span, path_name, Vec::new()));
                }
                let (args, call_end) =
                    self.attach_trailing_block_arg(&path_expr, Vec::new(), end_span.end)?;
                let span = Span {
                    start: name_span.start,
                    end: call_end,
                };
                return Ok(Ast::App(span, Box::new(path_expr), args));
            }

            if sindr::names::special_enum_variant_meta(&path_name)
                .is_some_and(|meta| meta.payload_arity == 0)
            {
                return Ok(Ast::ConstructorCall(
                    path_expr.span().clone(),
                    path_name,
                    Vec::new(),
                ));
            }

            // Keep a bare qualified name distinct from an explicit constructor call.
            // Standard marker positions inspect this syntax before value resolution.
            return Ok(path_expr);
        }

        let is_uppercase = name
            .chars()
            .next()
            .map(|c| c.is_uppercase())
            .unwrap_or(false);

        if self.explicit_type_args_start() {
            if is_uppercase {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Explicit type arguments apply to callables, not constructors",
                    self.peek_span(),
                ));
            }
            let func = self.parse_explicit_return_type_argument_apply(
                self.std_hidden_ref(name_span.clone(), name.clone()),
            )?;
            if matches!(self.peek(), Token::LParen) {
                self.advance();
                let args = self.parse_call_args()?;
                self.skip_newlines();
                let end_span = self.expect(&Token::RParen)?;
                let (args, call_end) = self.attach_trailing_block_arg(&func, args, end_span.end)?;
                return Ok(Ast::App(
                    Span {
                        start: name_span.start,
                        end: call_end,
                    },
                    Box::new(func),
                    args,
                ));
            }
            if matches!(self.peek(), Token::Unit) {
                let end_span = self.advance().span.clone();
                let (args, call_end) =
                    self.attach_trailing_block_arg(&func, Vec::new(), end_span.end)?;
                return Ok(Ast::App(
                    Span {
                        start: name_span.start,
                        end: call_end,
                    },
                    Box::new(func),
                    args,
                ));
            }
            return Ok(func);
        }

        // Regex generated literal sugar:
        //   re"pattern" / re'pattern'  => Regex::compile("pattern")
        if name == "re" {
            if let Token::Str(raw) = self.peek().clone() {
                let str_span = self.advance().span.clone();
                let pattern_expr = self.parse_string_or_interpolated(str_span.clone(), raw)?;
                let call_span = Span {
                    start: name_span.start,
                    end: pattern_expr.span().end,
                };
                let path = Ast::Path(
                    call_span.clone(),
                    AstPath {
                        span: call_span.clone(),
                        segments: vec!["Regex".into(), "compile".into()],
                    },
                );
                return Ok(Ast::App(
                    call_span,
                    Box::new(path),
                    vec![RecordLitArg::Positional(pattern_expr)],
                ));
            }
        }

        // Struct literal: Name { field: val, shorthand, ... }
        if is_uppercase && matches!(self.peek(), Token::LBrace) {
            use crate::ast::StructLitField;
            self.advance();
            self.skip_newlines();
            let mut fields = Vec::new();
            if !matches!(self.peek(), Token::RBrace) {
                loop {
                    self.skip_newlines();
                    let (field_name, _) = self.expect_ident()?;
                    if matches!(self.peek(), Token::Colon) {
                        self.advance();
                        let val = self.parse_non_assignment_expr()?;
                        fields.push(StructLitField::Explicit(field_name, val));
                    } else {
                        fields.push(StructLitField::Shorthand(field_name));
                    }
                    self.skip_newlines();
                    if matches!(self.peek(), Token::Comma) {
                        self.advance();
                        self.skip_newlines();
                        if matches!(self.peek(), Token::RBrace) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
            self.skip_newlines();
            let end_span = self.expect(&Token::RBrace)?;
            let span = Span {
                start: name_span.start,
                end: end_span.end,
            };
            return Ok(Ast::StructLit(span, name, fields));
        }

        // Function call or constructor call: name(args)
        if matches!(self.peek(), Token::LParen) && !self.pair_constructor_at() {
            self.advance();
            let args = self.parse_call_args()?;
            self.skip_newlines();
            let end_span = self.expect(&Token::RParen)?;
            let func = self.std_hidden_ref(name_span.clone(), name.clone());

            if is_uppercase {
                self.reject_constructor_trailing_block()?;
                let span = Span {
                    start: name_span.start,
                    end: end_span.end,
                };
                // Constructor call: Name(val, ...) or Name(field: val, ...)
                return Ok(Ast::ConstructorCall(span, name, args));
            } else {
                let (args, call_end) = self.attach_trailing_block_arg(&func, args, end_span.end)?;
                let span = Span {
                    start: name_span.start,
                    end: call_end,
                };
                // Normal function call
                return Ok(Ast::App(span, Box::new(func), args));
            }
        }

        // Zero-arg call: name() / Name()
        // Lexer tokenizes `()` as Token::Unit.
        if matches!(self.peek(), Token::Unit) {
            let end_span = self.advance().span.clone();
            let func = self.std_hidden_ref(name_span.clone(), name.clone());
            if is_uppercase {
                self.reject_constructor_trailing_block()?;
                let span = Span {
                    start: name_span.start,
                    end: end_span.end,
                };
                return Ok(Ast::ConstructorCall(span, name, Vec::new()));
            }
            let (args, call_end) =
                self.attach_trailing_block_arg(&func, Vec::new(), end_span.end)?;
            let span = Span {
                start: name_span.start,
                end: call_end,
            };
            return Ok(Ast::App(span, Box::new(func), args));
        }

        // Annotated binding: name: Type = expr / name: Type =? expr
        if matches!(self.peek(), Token::Colon) {
            self.advance();
            let ty = self.parse_type()?;
            if matches!(self.peek(), Token::Arrow) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Parenthesized type signatures must choose tuple or function syntax after the first element: use `,` and another type for a tuple, or put `->` before `)` for a function type (for example, `(Int -> String)`, not `(Int) -> String`).",
                    self.peek_span(),
                ));
            }
            let assign_tok = self.peek().clone();
            let operator_span = self.peek_span();
            match assign_tok {
                Token::Bind | Token::SafeBind => {
                    self.advance();
                }
                Token::Eof => {
                    return Err(ParseError::incomplete(
                        "assignment operator (= or =?)",
                        self.peek_span(),
                    ));
                }
                _ => {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        format!(
                            "Expected assignment operator (= or =?), got {:?}",
                            self.peek()
                        ),
                        self.peek_span(),
                    ));
                }
            }
            let rhs = self.parse_expr()?;
            self.ensure_non_associative_assignment(&rhs)?;
            let span = Span {
                start: name_span.start,
                end: rhs.span().end,
            };
            let pat = AstPattern::Annotated(name_span, name, ty);
            return Self::assignment_ast(assign_tok, operator_span, span, pat, rhs);
        }

        // Simple binding: name = expr / name =? expr
        if matches!(self.peek(), Token::Bind | Token::SafeBind) {
            let assign_tok = self.peek().clone();
            let operator_span = self.advance().span;
            let rhs = self.parse_expr()?;
            self.ensure_non_associative_assignment(&rhs)?;
            let span = Span {
                start: name_span.start,
                end: rhs.span().end,
            };
            let pat = AstPattern::Var(name_span, name);
            return Self::assignment_ast(assign_tok, operator_span, span, pat, rhs);
        }

        // Just a variable
        Ok(self.std_hidden_ref(name_span, name))
    }

    fn parse_dbg_special_form(&mut self, name_span: Span) -> Result<Ast, ParseError> {
        let bang_span = self.advance().span.clone();
        if matches!(self.peek(), Token::Unit) {
            let unit_span = self.advance().span.clone();
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "`dbg!` expects at least one argument",
                Span {
                    start: name_span.start,
                    end: unit_span.end,
                },
            ));
        }
        if !matches!(self.peek(), Token::LParen) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Expected `(` after `dbg!`",
                Span {
                    start: name_span.start,
                    end: bang_span.end,
                },
            ));
        }

        self.advance();
        self.skip_newlines();
        if matches!(self.peek(), Token::RParen) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "`dbg!` expects at least one argument",
                self.peek_span(),
            ));
        }

        let mut args = Vec::new();
        loop {
            let expr = self.parse_non_assignment_expr()?;
            args.push(DbgArg {
                span: expr.span().clone(),
                expr,
            });
            self.skip_newlines();
            if matches!(self.peek(), Token::Comma) {
                self.advance();
                self.skip_newlines();
                if matches!(self.peek(), Token::RParen) {
                    break;
                }
                continue;
            }
            break;
        }

        self.skip_newlines();
        let end_span = self.expect(&Token::RParen)?;
        Ok(Ast::Dbg(
            Span {
                start: name_span.start,
                end: end_span.end,
            },
            args,
        ))
    }

    /// `=` / `=?` are non-associative in a single statement.
    pub(super) fn ensure_non_associative_assignment(&self, rhs: &Ast) -> Result<(), ParseError> {
        if matches!(rhs, Ast::Bind(_, _, _) | Ast::SafeBind(_, _, _, _)) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "`=` and `=?` are non-associative; a statement can contain only one assignment operator",
                rhs.span().clone(),
            ));
        }
        Ok(())
    }

    pub(super) fn with_trailing_call_block_disabled<T>(
        &mut self,
        f: impl FnOnce(&mut Self) -> Result<T, ParseError>,
    ) -> Result<T, ParseError> {
        let prev = self.allow_trailing_call_block;
        self.allow_trailing_call_block = false;
        let result = f(self);
        self.allow_trailing_call_block = prev;
        result
    }

    pub(super) fn parse_call_args(&mut self) -> Result<Vec<RecordLitArg>, ParseError> {
        self.skip_newlines();

        let mut args = Vec::new();
        if !matches!(self.peek(), Token::RParen) {
            args.push(self.parse_record_lit_arg()?);
            while matches!(self.peek(), Token::Comma) {
                self.advance();
                self.skip_newlines();
                if matches!(self.peek(), Token::RParen) {
                    break;
                }
                args.push(self.parse_record_lit_arg()?);
            }
        }

        Ok(args)
    }

    pub(super) fn parse_trailing_block_expr_from_lbrace(
        &mut self,
        sp: Span,
    ) -> Result<Ast, ParseError> {
        self.with_parse_nesting(sp.clone(), |parser| {
            parser.expect(&Token::LBrace)?;
            parser.skip_newlines();

            if matches!(parser.peek(), Token::Pipe) {
                return parser.parse_closure_literal(sp);
            }

            let body_stmts = parser.parse_block_stmts()?;
            if body_stmts.is_empty() {
                return Err(ParseError::incomplete("expression", parser.peek_span()));
            }
            let end = parser.expect(&Token::RBrace)?;
            let body = block_stmts_to_expr(body_stmts);
            Ok(Ast::Closure(
                Span {
                    start: sp.start,
                    end: end.end,
                },
                Vec::new(),
                Box::new(body),
            ))
        })
    }

    pub(super) fn parse_match_arm_body(&mut self) -> Result<Ast, ParseError> {
        if matches!(self.peek(), Token::LBrace) {
            let sp = self.peek_span();
            return self.parse_match_arm_block_expr_from_lbrace(sp);
        }
        self.parse_expr()
    }

    pub(super) fn parse_match_arm_block_expr_from_lbrace(
        &mut self,
        sp: Span,
    ) -> Result<Ast, ParseError> {
        self.with_parse_nesting(sp.clone(), |parser| {
            parser.expect(&Token::LBrace)?;
            parser.skip_newlines();

            if matches!(parser.peek(), Token::Pipe) {
                return parser.parse_closure_literal(sp);
            }

            let stmts = parser.parse_block_stmts()?;
            if stmts.is_empty() {
                return Err(ParseError::incomplete("expression", parser.peek_span()));
            }
            let end = parser.expect(&Token::RBrace)?;
            Ok(Ast::Block(
                Span {
                    start: sp.start,
                    end: end.end,
                },
                stmts,
            ))
        })
    }

    pub(super) fn reject_constructor_trailing_block(&self) -> Result<(), ParseError> {
        if self.allow_trailing_call_block && matches!(self.peek(), Token::LBrace) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Trailing block sugar is not supported for constructor calls",
                self.peek_span(),
            ));
        }
        Ok(())
    }

    pub(super) fn attach_trailing_block_arg(
        &mut self,
        _callee: &Ast,
        mut args: Vec<RecordLitArg>,
        mut call_end: usize,
    ) -> Result<(Vec<RecordLitArg>, usize), ParseError> {
        if !self.allow_trailing_call_block || !matches!(self.peek(), Token::LBrace) {
            return Ok((args, call_end));
        }

        if args
            .iter()
            .any(|arg| matches!(arg, RecordLitArg::Named(_, _)))
        {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Trailing block sugar cannot follow named arguments",
                self.peek_span(),
            ));
        }

        let trailing = self.parse_trailing_block_expr_from_lbrace(self.peek_span())?;
        call_end = trailing.span().end;
        args.push(RecordLitArg::Positional(trailing));
        Ok((args, call_end))
    }

    /// Parse a record literal argument: either positional or named.
    pub(super) fn parse_record_lit_arg(&mut self) -> Result<RecordLitArg, ParseError> {
        // Peek ahead: if IDENT followed by `:`, it's named
        if let Token::Ident(name) = self.peek().clone() {
            let save = self.pos;
            let _name_span = self.peek_span();
            self.advance();
            if matches!(self.peek(), Token::Colon) && !self.has_path_separator() {
                self.advance();
                let val = self.parse_non_assignment_expr()?;
                return Ok(RecordLitArg::Named(name, val));
            }
            // Not named, restore and parse as expression
            self.pos = save;
        }
        let expr = self.parse_non_assignment_expr()?;
        Ok(RecordLitArg::Positional(expr))
    }

    pub(super) fn parse_non_assignment_expr(&mut self) -> Result<Ast, ParseError> {
        let expr = self.parse_expr()?;
        if matches!(expr, Ast::Bind(_, _, _) | Ast::SafeBind(_, _, _, _)) {
            Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Assignments (`=` and `=?`) are statements and cannot appear in argument position",
                expr.span().clone(),
            ))
        } else {
            Ok(expr)
        }
    }

    pub(super) fn parse_list_expr(&mut self, sp: Span) -> Result<Ast, ParseError> {
        self.with_parse_nesting(sp.clone(), |parser| {
            parser.expect(&Token::LBrack)?;
            parser.skip_newlines();

            if matches!(parser.peek(), Token::RBrack) {
                let end = parser.expect(&Token::RBrack)?;
                return Ok(Ast::ListNil(Span {
                    start: sp.start,
                    end: end.end,
                }));
            }

            let first = parser.parse_expr()?;
            parser.skip_newlines();
            if matches!(parser.peek(), Token::DotDot) {
                parser.advance();
                parser.skip_newlines();
                let stop = parser.parse_expr()?;
                parser.skip_newlines();
                let end = parser.expect(&Token::RBrack)?;
                return Ok(Ast::RangeLiteral(
                    Span {
                        start: sp.start,
                        end: end.end,
                    },
                    Box::new(first),
                    Box::new(stop),
                ));
            }
            if matches!(parser.peek(), Token::Comma) {
                parser.advance();
                parser.skip_newlines();
                if matches!(parser.peek(), Token::DotDot) {
                    parser.advance();
                    parser.skip_newlines();
                    let tail = parser.parse_expr()?;
                    parser.skip_newlines();
                    let end = parser.expect(&Token::RBrack)?;
                    return Ok(Ast::ListCons(
                        Span {
                            start: sp.start,
                            end: end.end,
                        },
                        Box::new(first),
                        Box::new(tail),
                    ));
                }

                let mut elems = vec![first];
                if matches!(parser.peek(), Token::RBrack) {
                    let end = parser.expect(&Token::RBrack)?;
                    return Ok(Ast::ListLiteral(
                        Span {
                            start: sp.start,
                            end: end.end,
                        },
                        elems,
                    ));
                }
                elems.push(parser.parse_expr()?);
                while matches!(parser.peek(), Token::Comma) {
                    parser.advance();
                    parser.skip_newlines();
                    if matches!(parser.peek(), Token::RBrack) {
                        break;
                    }
                    elems.push(parser.parse_expr()?);
                }
                parser.skip_newlines();
                let end = parser.expect(&Token::RBrack)?;
                return Ok(Ast::ListLiteral(
                    Span {
                        start: sp.start,
                        end: end.end,
                    },
                    elems,
                ));
            }

            let end = parser.expect(&Token::RBrack)?;
            Ok(Ast::ListLiteral(
                Span {
                    start: sp.start,
                    end: end.end,
                },
                vec![first],
            ))
        })
    }

    fn parse_hash_map_literal(&mut self, name_span: Span) -> Result<Ast, ParseError> {
        self.advance();
        let bracket_start = self.expect(&Token::LBrack)?;
        self.with_parse_nesting(bracket_start.clone(), |parser| {
            parser.skip_newlines();
            if matches!(parser.peek(), Token::RBrack) {
                let end = parser.expect(&Token::RBrack)?;
                return Ok(Ast::HashMapLiteral(
                    Span {
                        start: name_span.start,
                        end: end.end,
                    },
                    Vec::new(),
                ));
            }

            let mut entries = Vec::new();
            loop {
                parser.skip_newlines();
                let key = parser.parse_non_assignment_expr()?;
                parser.skip_newlines();
                if !matches!(parser.peek(), Token::FatArrow) {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        "expected `=>` in hash! literal",
                        parser.peek_span(),
                    ));
                }
                parser.advance();
                parser.skip_newlines();
                let value = parser.parse_non_assignment_expr()?;
                entries.push(HashMapLiteralEntry { key, value });
                parser.skip_newlines();

                if matches!(parser.peek(), Token::Comma) {
                    parser.advance();
                    parser.skip_newlines();
                    if matches!(parser.peek(), Token::RBrack) {
                        break;
                    }
                    continue;
                }
                break;
            }

            parser.skip_newlines();
            let end = parser.expect(&Token::RBrack)?;
            Ok(Ast::HashMapLiteral(
                Span {
                    start: name_span.start,
                    end: end.end,
                },
                entries,
            ))
        })
    }

    // ── Type annotation parsing ──

    pub(super) fn parse_closure_literal(&mut self, sp: Span) -> Result<Ast, ParseError> {
        self.expect(&Token::Pipe)?;
        self.skip_newlines();

        let mut params = Vec::new();
        if !matches!(self.peek(), Token::Pipe) {
            loop {
                let (name, pspan) = self.expect_ident()?;
                let ty = if matches!(self.peek(), Token::Colon) {
                    self.advance();
                    self.skip_newlines();
                    Some(self.parse_type()?)
                } else {
                    None
                };
                params.push(ClosureParam {
                    name,
                    ty,
                    span: pspan,
                });
                self.skip_newlines();
                if matches!(self.peek(), Token::Comma) {
                    self.advance();
                    self.skip_newlines();
                    continue;
                }
                break;
            }
        }

        self.expect(&Token::Pipe)?;
        self.skip_newlines();
        let body_stmts = self.parse_block_stmts()?;
        if body_stmts.is_empty() {
            return Err(ParseError::incomplete("expression", self.peek_span()));
        }
        let body = block_stmts_to_expr(body_stmts);
        let end = self.expect(&Token::RBrace)?;
        Ok(Ast::Closure(
            Span {
                start: sp.start,
                end: end.end,
            },
            params,
            Box::new(body),
        ))
    }

    pub(super) fn parse_capture_expr(&mut self, sp: Span) -> Result<Ast, ParseError> {
        self.expect(&Token::Amp)?;
        if let Token::Int(n) = self.peek().clone() {
            let span = self.advance().span.clone();
            let Some(index) = n.to_usize() else {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    format!(
                        "capture placeholder index must be between &1 and &{}",
                        MAX_CAPTURE_PLACEHOLDER_INDEX
                    ),
                    span,
                ));
            };
            if !(1..=MAX_CAPTURE_PLACEHOLDER_INDEX).contains(&index) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    format!(
                        "capture placeholder index must be between &1 and &{}",
                        MAX_CAPTURE_PLACEHOLDER_INDEX
                    ),
                    span,
                ));
            }
            return Ok(Ast::CapturePlaceholder(
                Span {
                    start: sp.start,
                    end: span.end,
                },
                index,
            ));
        }
        if self.pair_constructor_at() {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "bare `(,)` is only valid in infix position",
                Span {
                    start: sp.start,
                    end: self.pair_constructor_span().end,
                },
            )
            .with_guidance(crate::error::ParseErrorGuidance::PairConstructorCapture));
        }
        if matches!(self.peek(), Token::LParen) {
            self.advance();
            self.skip_newlines();
            let inner = self.parse_expr()?;
            self.skip_newlines();
            let end_span = self.expect(&Token::RParen)?;
            let (message, guidance) = match inner {
                Ast::CapturePlaceholder(_, 1) => (
                    "anonymous capture is not supported; use `&id` instead".to_string(),
                    crate::error::ParseErrorGuidance::AnonymousCaptureIdentity,
                ),
                _ => (
                    "anonymous capture is not supported; extract a named function and capture it like `&fun_name(&1, &2)`".to_string(),
                    crate::error::ParseErrorGuidance::AnonymousCaptureRequiresHelper,
                ),
            };
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                message,
                Span {
                    start: sp.start,
                    end: end_span.end,
                },
            )
            .with_guidance(guidance));
        }
        if let Some(operator) = func_literal_operator_token(self.peek()) {
            let operator_span = self.peek_span();
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                format!("Unquoted operator capture: {operator}"),
                Span {
                    start: sp.start,
                    end: operator_span.end,
                },
            )
            .with_guidance(crate::error::ParseErrorGuidance::OperatorCapture(
                operator.to_string(),
            )));
        }
        let (mut target, mut end) = match self.peek().clone() {
            Token::Ident(_)
            | Token::PatternConsumer(_)
            | Token::ReservedCallName(_)
            | Token::True
            | Token::False => {
                let (name, name_span) = self.expect_member_ident()?;
                let mut path_segments = vec![name.clone()];
                let mut path_end = name_span.end;
                while self.has_path_separator()
                    && matches!(
                        self.peek_n(2),
                        Some(
                            Token::Ident(_)
                                | Token::PatternConsumer(_)
                                | Token::ReservedCallName(_)
                                | Token::True
                                | Token::False
                        )
                    )
                {
                    self.consume_path_separator()?;
                    let (seg, seg_span) = self.expect_member_ident()?;
                    path_end = seg_span.end;
                    path_segments.push(seg);
                }

                let last = path_segments.last_mut().expect("capture path is nonempty");
                let (suffixed, suffix_span) = self.parse_callable_suffix(
                    last.clone(),
                    Span {
                        start: name_span.start,
                        end: path_end,
                    },
                );
                *last = suffixed;
                path_end = suffix_span.end;
                let name = path_segments[0].clone();
                let name_span = Span {
                    start: name_span.start,
                    end: path_end,
                };

                Self::validate_pattern_consumer_path(
                    &path_segments,
                    Span {
                        start: name_span.start,
                        end: path_end,
                    },
                )?;

                if path_segments
                    .last()
                    .and_then(|segment| segment.chars().next())
                    .is_some_and(|ch| ch.is_uppercase())
                    && self.enum_constructor_type_args_start()
                {
                    let owner_name = path_segments.join("::");
                    let target =
                        self.parse_enum_constructor_capture_target(owner_name, name_span.start)?;
                    let end = target.span().end;
                    (target, end)
                } else {
                    let target = if path_segments.len() == 1 {
                        Ast::Var(name_span.clone(), name)
                    } else {
                        Ast::Path(
                            Span {
                                start: name_span.start,
                                end: path_end,
                            },
                            AstPath {
                                span: Span {
                                    start: name_span.start,
                                    end: path_end,
                                },
                                segments: path_segments,
                            },
                        )
                    };
                    (target, path_end)
                }
            }
            Token::FuncLiteral(body) => {
                let func_span = self.advance().span.clone();
                match Self::parse_func_literal_body(&body, func_span.clone())? {
                    FuncLiteralBodyKind::Name(name) => {
                        (Ast::Var(func_span.clone(), name), func_span.end)
                    }
                    FuncLiteralBodyKind::Path(path) => {
                        let end = path.span.end;
                        (Ast::Path(path.span.clone(), path), end)
                    }
                    FuncLiteralBodyKind::Operator(body) => (
                        Ast::FuncLiteralRef(
                            func_span.clone(),
                            FuncLiteralRef {
                                span: func_span.clone(),
                                body,
                            },
                        ),
                        func_span.end,
                    ),
                }
            }
            _ => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    format!("Expected identifier, got {:?}", self.peek()),
                    self.peek_span(),
                ));
            }
        };

        let special_variant = match &target {
            Ast::Var(_, name) => sindr::names::special_enum_variant_surface_meta(name),
            Ast::Path(_, path) => {
                sindr::names::special_enum_variant_surface_meta(&path.segments.join("::"))
            }
            _ => None,
        };
        if let Some(meta) = special_variant {
            debug_assert_eq!(
                meta.identity(),
                sindr::names::TypeIdentity::SpecialEnumVariant
            );
            let span = target.span().clone();
            target = Ast::Path(
                span.clone(),
                AstPath {
                    span,
                    segments: meta
                        .qualified_name
                        .split("::")
                        .map(str::to_string)
                        .collect(),
                },
            );
        }

        while matches!(self.peek(), Token::Dot) {
            self.advance();
            let (segment, segment_span) = self.parse_facet_path_segment_after_dot()?;
            end = segment_span.end;
            let span = Span {
                start: target.span().start,
                end,
            };
            target = match segment {
                FacetPathSegment::Field {
                    name,
                    optional: false,
                } => Ast::FieldAccess(span, Box::new(target), name),
                other => Ast::FacetSegmentAccess(span, Box::new(target), other),
            };
        }

        if self.explicit_type_args_start() {
            target = self.parse_explicit_return_type_argument_apply(target)?;
            end = target.span().end;
        }

        if let Some(kind) = Self::source_pattern_consumer(&target)
            .filter(|_| matches!(self.peek(), Token::LParen | Token::Unit))
        {
            let call = self.parse_pattern_consumer_call(target, kind, sp.start, false)?;
            let span = call.span().clone();
            return Ok(Ast::Capture(span, Box::new(call), Vec::new()));
        }

        let mut parsed_args = Vec::new();
        if matches!(self.peek(), Token::LParen) {
            self.advance();
            self.skip_newlines();
            if !matches!(self.peek(), Token::RParen) {
                parsed_args.push(self.parse_record_lit_arg()?);
                while matches!(self.peek(), Token::Comma) {
                    self.advance();
                    self.skip_newlines();
                    if matches!(self.peek(), Token::RParen) {
                        break;
                    }
                    parsed_args.push(self.parse_record_lit_arg()?);
                }
            }
            self.skip_newlines();
            let end_span = self.expect(&Token::RParen)?;
            end = end_span.end;
        }

        let mut args = Vec::new();
        for arg in parsed_args {
            match arg {
                RecordLitArg::Positional(expr) => args.push(expr),
                RecordLitArg::Named(arg_name, _) => {
                    return Err(ParseError::syntax(
                        crate::error::ParseErrorReason::ExpressionSyntax,
                        format!("capture does not accept named argument '{}'", arg_name),
                        Span {
                            start: sp.start,
                            end,
                        },
                    ));
                }
            }
        }

        Ok(Ast::Capture(
            Span {
                start: sp.start,
                end,
            },
            Box::new(target),
            args,
        ))
    }

    pub(super) fn parse_facet_capture_expr(&mut self, sp: Span) -> Result<Ast, ParseError> {
        self.expect(&Token::Tilde)?;
        let inner = self.parse_postfix()?;
        Ok(Ast::FacetCapture(
            Span {
                start: sp.start,
                end: inner.span().end,
            },
            Box::new(inner),
        ))
    }

    pub(super) fn parse_match_expr(&mut self) -> Result<Ast, ParseError> {
        let sp = self.peek_span();
        self.expect(&Token::Match)?;
        self.skip_newlines();
        let block_inside_call = self.match_has_parenthesized_arm_block();
        let scrutinee = if block_inside_call {
            self.expect(&Token::LParen)?;
            self.skip_newlines();
            let target = self.with_trailing_call_block_disabled(|parser| parser.parse_expr())?;
            self.skip_newlines();
            self.expect(&Token::Comma)?;
            target
        } else {
            match self.with_trailing_call_block_disabled(|parser| parser.parse_expr())? {
                Ast::Grouped(_, target) => *target,
                target => target,
            }
        };
        self.skip_newlines();
        let lbrace = self.expect(&Token::LBrace)?;
        self.skip_newlines();

        if matches!(self.peek(), Token::RBrace) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Match expression must contain at least one arm",
                lbrace,
            ));
        }

        let mut arms = Vec::new();
        while !matches!(self.peek(), Token::RBrace) {
            if matches!(self.peek(), Token::Eof) {
                return Err(ParseError::incomplete("}", self.peek_span()));
            }
            self.skip_newlines();
            let pattern = self.parse_pattern()?;
            let guard = if matches!(self.peek(), Token::When) {
                self.advance();
                self.skip_newlines();
                Some(self.parse_non_assignment_expr()?)
            } else {
                None
            };
            self.expect(&Token::FatArrow)?;
            let body = self.parse_match_arm_body()?;
            arms.push(AstMatchArm {
                pattern,
                guard,
                body,
            });
            self.skip_newlines();
            if matches!(self.peek(), Token::Comma) {
                self.advance();
                self.skip_newlines();
            }
        }
        let mut end = self.expect(&Token::RBrace)?;
        if block_inside_call {
            end = self.finish_special_block_call()?;
        }
        Ok(Ast::Match(
            Span {
                start: sp.start,
                end: end.end,
            },
            Box::new(scrutinee),
            arms,
        ))
    }

    // The top-level arm arrow distinguishes an arm block from a closure in
    // an existing tuple target such as `match (value, { 1 }) { ... }`.
    fn match_has_parenthesized_arm_block(&self) -> bool {
        if !matches!(self.peek(), Token::LParen) {
            return false;
        }
        let mut depth = 0usize;
        let mut offset = 1;
        while let Some(token) = self.peek_n(offset) {
            match token {
                Token::LParen | Token::LBrack | Token::LBrace => depth += 1,
                Token::RParen | Token::RBrack | Token::RBrace if depth == 0 => return false,
                Token::RParen | Token::RBrack | Token::RBrace => depth -= 1,
                Token::Comma if depth == 0 => {
                    offset += 1;
                    while matches!(self.peek_n(offset), Some(Token::Newline)) {
                        offset += 1;
                    }
                    if !matches!(self.peek_n(offset), Some(Token::LBrace)) {
                        return false;
                    }
                    offset += 1;
                    while matches!(self.peek_n(offset), Some(Token::Newline)) {
                        offset += 1;
                    }
                    if matches!(self.peek_n(offset), Some(Token::RBrace)) {
                        return true;
                    }
                    while let Some(token) = self.peek_n(offset) {
                        match token {
                            Token::FatArrow if depth == 0 => return true,
                            Token::LParen | Token::LBrack | Token::LBrace => depth += 1,
                            Token::RParen | Token::RBrack | Token::RBrace if depth == 0 => {
                                return false
                            }
                            Token::RParen | Token::RBrack | Token::RBrace => depth -= 1,
                            Token::Eof => return false,
                            _ => {}
                        }
                        offset += 1;
                    }
                    return false;
                }
                Token::Eof => return false,
                _ => {}
            }
            offset += 1;
        }
        false
    }

    fn finish_special_block_call(&mut self) -> Result<Span, ParseError> {
        self.skip_newlines();
        if matches!(self.peek(), Token::Comma) {
            self.advance();
            self.skip_newlines();
        }
        self.expect(&Token::RParen)
    }

    fn parse_bulk_update_call(&mut self, start: usize) -> Result<Ast, ParseError> {
        self.expect(&Token::LParen)?;
        self.skip_newlines();
        let source = match self.parse_record_lit_arg()? {
            RecordLitArg::Positional(source) => source,
            RecordLitArg::Named(_, _) => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "bulk_update expects exactly 1 positional source argument",
                    self.peek_span(),
                ))
            }
        };
        self.skip_newlines();
        let block_inside_call = if matches!(self.peek(), Token::Comma) {
            self.advance();
            self.skip_newlines();
            !matches!(self.peek(), Token::RParen)
        } else {
            false
        };
        if !block_inside_call {
            self.expect(&Token::RParen)?;
        }
        let mut update = self.parse_bulk_update_expr(start, source)?;
        if block_inside_call {
            let end = self.finish_special_block_call()?;
            let Ast::BulkUpdate(span, _, _) = &mut update else {
                unreachable!()
            };
            span.end = end.end;
        }
        Ok(update)
    }

    fn parse_bulk_update_expr(&mut self, start: usize, source: Ast) -> Result<Ast, ParseError> {
        self.skip_newlines();
        let lbrace = self.expect(&Token::LBrace)?;
        self.skip_newlines();

        if matches!(self.peek(), Token::RBrace) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Facet::bulk_update must contain at least one entry",
                lbrace,
            ));
        }

        let mut entries = Vec::new();
        while !matches!(self.peek(), Token::RBrace) {
            if matches!(self.peek(), Token::Eof) {
                return Err(ParseError::incomplete("}", self.peek_span()));
            }
            self.skip_newlines();
            if matches!(self.peek(), Token::RBrace) {
                break;
            }
            entries.push(self.parse_bulk_update_entry()?);
            self.skip_newlines();
        }

        let end = self.expect(&Token::RBrace)?;
        Ok(Ast::BulkUpdate(
            Span {
                start,
                end: end.end,
            },
            Box::new(source),
            entries,
        ))
    }

    fn parse_bulk_update_entry(&mut self) -> Result<BulkUpdateEntry, ParseError> {
        let start = self.peek_span().start;
        let path = self.parse_bulk_update_path()?;
        self.skip_newlines();

        if matches!(self.peek(), Token::LBrace) {
            let lbrace = self.advance().span.clone();
            self.skip_newlines();
            if matches!(self.peek(), Token::RBrace) {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Bulk update nested path must contain at least one entry",
                    lbrace,
                ));
            }

            let mut entries = Vec::new();
            while !matches!(self.peek(), Token::RBrace) {
                if matches!(self.peek(), Token::Eof) {
                    return Err(ParseError::incomplete("}", self.peek_span()));
                }
                self.skip_newlines();
                if matches!(self.peek(), Token::RBrace) {
                    break;
                }
                entries.push(self.parse_bulk_update_entry()?);
                self.skip_newlines();
            }
            let end = self.expect(&Token::RBrace)?;
            return Ok(BulkUpdateEntry {
                span: Span {
                    start,
                    end: end.end,
                },
                path,
                kind: BulkUpdateEntryKind::Nested(entries),
            });
        }

        self.expect(&Token::LeftArrow)?;
        let (kind, end) = self.parse_bulk_update_leaf()?;
        Ok(BulkUpdateEntry {
            span: Span { start, end },
            path,
            kind,
        })
    }

    fn parse_bulk_update_path(&mut self) -> Result<BulkUpdatePath, ParseError> {
        self.parse_bulk_update_path_chain()
    }

    fn parse_bulk_update_path_chain(&mut self) -> Result<BulkUpdatePath, ParseError> {
        let mut path = self.parse_bulk_update_path_primary()?;
        while matches!(self.peek(), Token::Arrow) {
            self.advance();
            self.skip_newlines();
            let right = self.parse_bulk_update_path_primary()?;
            let span = Span {
                start: path.span().start,
                end: right.span().end,
            };
            path = BulkUpdatePath::Chain(span, Box::new(path), Box::new(right));
            self.skip_newlines();
        }
        Ok(path)
    }

    fn parse_bulk_update_path_primary(&mut self) -> Result<BulkUpdatePath, ParseError> {
        let start_span = self.peek_span();
        match self.peek().clone() {
            Token::Caret => {
                self.advance();
                let (name, name_span) = self.expect_ident()?;
                Ok(BulkUpdatePath::Pin(
                    Span {
                        start: start_span.start,
                        end: name_span.end,
                    },
                    name,
                ))
            }
            Token::Ident(name) if name == "Facet" => {
                let save = self.pos;
                self.advance();
                if self.has_path_separator() {
                    self.consume_path_separator()?;
                    if let Token::Ident(method) = self.peek().clone() {
                        if matches!(method.as_str(), "strip_left" | "strip_right") {
                            return self.parse_bulk_update_path_operation(start_span, method);
                        }
                    }
                }
                self.pos = save;
                self.parse_bulk_update_relative_path()
            }
            Token::Ident(_) => self.parse_bulk_update_relative_path(),
            _ => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Bulk update path must start with a path segment, pinned FacetPath (^name), or whitelisted Facet path operation",
                start_span,
            )),
        }
    }

    fn parse_bulk_update_relative_path(&mut self) -> Result<BulkUpdatePath, ParseError> {
        let start = self.peek_span().start;
        let (first, first_span) = self.expect_ident()?;
        let mut path = BulkUpdatePath::Segments(
            Span {
                start,
                end: first_span.end,
            },
            vec![FacetPathSegment::field(first)],
        );
        while matches!(self.peek(), Token::Dot) {
            self.advance();
            if matches!(self.peek(), Token::Caret) {
                let pin_start = self.peek_span();
                self.advance();
                let (name, name_span) = self.expect_ident()?;
                let pin = BulkUpdatePath::Pin(
                    Span {
                        start: pin_start.start,
                        end: name_span.end,
                    },
                    name,
                );
                let span = Span {
                    start: path.span().start,
                    end: pin.span().end,
                };
                path = BulkUpdatePath::Chain(span, Box::new(path), Box::new(pin));
                continue;
            }
            let (segment, segment_span) = self.parse_facet_path_segment_after_dot()?;
            match &mut path {
                BulkUpdatePath::Segments(span, segments) => {
                    span.end = segment_span.end;
                    segments.push(segment);
                }
                _ => {
                    let right = BulkUpdatePath::Segments(segment_span.clone(), vec![segment]);
                    let span = Span {
                        start: path.span().start,
                        end: segment_span.end,
                    };
                    path = BulkUpdatePath::Chain(span, Box::new(path), Box::new(right));
                }
            }
        }
        Ok(path)
    }

    fn parse_bulk_update_path_operation(
        &mut self,
        start_span: Span,
        method: Symbol,
    ) -> Result<BulkUpdatePath, ParseError> {
        let method_span = self.advance().span.clone();
        self.skip_newlines();
        self.expect(&Token::LParen)?;
        self.skip_newlines();
        let inner = self.parse_bulk_update_path_chain()?;
        self.skip_newlines();
        self.expect(&Token::Comma)?;
        self.skip_newlines();
        let count_span = self.peek_span();
        let Token::Int(count) = self.peek().clone() else {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Facet path operation count must be an integer literal",
                count_span,
            ));
        };
        self.advance();
        let Some(count) = count.to_usize() else {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Facet path operation count must fit in usize",
                count_span,
            ));
        };
        self.skip_newlines();
        let end = self.expect(&Token::RParen)?;
        let span = Span {
            start: start_span.start,
            end: end.end,
        };
        match method.as_str() {
            "strip_left" => Ok(BulkUpdatePath::StripLeft(span, Box::new(inner), count)),
            "strip_right" => Ok(BulkUpdatePath::StripRight(span, Box::new(inner), count)),
            _ => Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Unsupported bulk_update path operation",
                method_span,
            )),
        }
    }

    fn parse_bulk_update_leaf(&mut self) -> Result<(BulkUpdateEntryKind, usize), ParseError> {
        self.skip_newlines();
        let (name, name_span) = self.expect_ident()?;
        let entry_kind = match name.as_str() {
            "set" => BulkUpdateEntryKind::Set,
            "over" => BulkUpdateEntryKind::Over,
            "over_result" => BulkUpdateEntryKind::OverResult,
            "case_set" => BulkUpdateEntryKind::CaseSet,
            "case_over" => BulkUpdateEntryKind::CaseOver,
            _ => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Bulk update entries must use set(value), over(update_fun), over_result(update_fun), case_set(payload), or case_over(update_fun)",
                    name_span,
                ));
            }
        };
        self.skip_newlines();
        self.expect(&Token::LParen)?;
        let args = self.with_trailing_call_block_disabled(|parser| parser.parse_call_args())?;
        let call_end = self.expect(&Token::RParen)?;

        if args.len() != 1
            || args
                .iter()
                .any(|arg| matches!(arg, RecordLitArg::Named(_, _)))
        {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Bulk update entries must use set(value), over(update_fun), over_result(update_fun), case_set(payload), or case_over(update_fun)",
                Span {
                    start: name_span.start,
                    end: call_end.end,
                },
            ));
        }

        let inner = match <[RecordLitArg; 1]>::try_from(args) {
            Ok([RecordLitArg::Positional(expr)]) => expr,
            _ => {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "Bulk update entries must use set(value), over(update_fun), over_result(update_fun), case_set(payload), or case_over(update_fun)",
                    Span {
                        start: name_span.start,
                        end: call_end.end,
                    },
                ));
            }
        };
        if bulk_update_proc_contains_operation_call(&inner) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "bulk_update operation calls cannot be nested. Use a single whitelisted operation at the leaf.",
                inner.span().clone(),
            ));
        }

        let end = inner.span().end;
        Ok((entry_kind(inner), end))
    }

    /// `cond { cond1 => expr1, ..., True => exprN }`
    pub(super) fn parse_cond_expr(&mut self) -> Result<Ast, ParseError> {
        let sp = self.peek_span();
        self.expect(&Token::Cond)?;
        self.skip_newlines();
        let block_inside_call = matches!(self.peek(), Token::LParen);
        if block_inside_call {
            self.advance();
            self.skip_newlines();
        }
        let lbrace = self.expect(&Token::LBrace)?;
        self.skip_newlines();

        if matches!(self.peek(), Token::RBrace) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Cond expression must contain at least one clause",
                lbrace,
            ));
        }

        let mut clauses = Vec::new();
        while !matches!(self.peek(), Token::RBrace) {
            if matches!(self.peek(), Token::Eof) {
                return Err(ParseError::incomplete("}", self.peek_span()));
            }
            self.skip_newlines();
            let cond = self.parse_expr()?;
            self.expect(&Token::FatArrow)?;
            let body = self.parse_expr()?;
            clauses.push((cond, body));
            self.skip_newlines();
            if matches!(self.peek(), Token::Comma) {
                self.advance();
                self.skip_newlines();
            }
        }
        let mut end = self.expect(&Token::RBrace)?;
        if block_inside_call {
            end = self.finish_special_block_call()?;
        }

        for (idx, (cond, _)) in clauses.iter().enumerate() {
            if Self::is_true_literal(cond) && idx + 1 != clauses.len() {
                return Err(ParseError::syntax(
                    crate::error::ParseErrorReason::ExpressionSyntax,
                    "`True` clause must be the final cond clause",
                    cond.span().clone(),
                ));
            }
        }

        let Some((last_cond, last_body)) = clauses.pop() else {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Cond expression must contain at least one clause",
                lbrace,
            ));
        };
        if !Self::is_true_literal(&last_cond) {
            return Err(ParseError::syntax(
                crate::error::ParseErrorReason::ExpressionSyntax,
                "Final cond clause must use `True` as its condition",
                last_cond.span().clone(),
            ));
        }

        clauses.push((last_cond, last_body));
        Ok(Ast::Cond(
            Span {
                start: sp.start,
                end: end.end,
            },
            clauses,
        ))
    }

    /// Match pattern now reuses the same grammar as bind/safe-bind patterns.
    pub(super) fn is_true_literal(expr: &Ast) -> bool {
        matches!(expr, Ast::ConstructorCall(_, name, args)
            if args.is_empty() && sindr::names::special_enum_variant_meta(name)
                .is_some_and(|meta| meta.lowering == sindr::names::SpecialEnumVariantLowering::Boolean(true)))
    }
}

fn bulk_update_proc_contains_operation_call(expr: &Ast) -> bool {
    match expr {
        Ast::NumberedPlaceholder(..) => false,
        Ast::PatternConsumerCall(_, callee, args) => {
            bulk_update_proc_contains_operation_call(callee)
                || args
                    .iter()
                    .filter_map(|arg| arg.expression.as_deref())
                    .any(bulk_update_proc_contains_operation_call)
        }
        Ast::Cond(_, clauses) => clauses.iter().any(|(condition, body)| {
            bulk_update_proc_contains_operation_call(condition)
                || bulk_update_proc_contains_operation_call(body)
        }),
        Ast::App(_, func, args) => {
            let is_bulk_proc = match func.as_ref() {
                Ast::Var(_, name) => {
                    matches!(
                        name.as_str(),
                        "set" | "over" | "over_result" | "case_set" | "case_over"
                    )
                }
                Ast::Path(_, path) => {
                    matches!(
                        path.segments.as_slice(),
                        [module, name]
                            if module == "Facet"
                                && matches!(
                                    name.as_str(),
                                    "set" | "over" | "over_result" | "case_set" | "case_over"
                                )
                    )
                }
                _ => false,
            };
            is_bulk_proc
                || bulk_update_proc_contains_operation_call(func)
                || args.iter().any(|arg| match arg {
                    RecordLitArg::Positional(inner) | RecordLitArg::Named(_, inner) => {
                        bulk_update_proc_contains_operation_call(inner)
                    }
                })
        }
        Ast::ReturnTypeArgumentApply(_, target, _) => {
            bulk_update_proc_contains_operation_call(target)
        }
        Ast::Do(_, _, statements, _) => statements.iter().any(|statement| match statement {
            AstDoStatement::Extract { rhs, .. } | AstDoStatement::SafeBind { rhs, .. } => {
                bulk_update_proc_contains_operation_call(rhs)
            }
            AstDoStatement::Statement(statement) => {
                bulk_update_proc_contains_operation_call(statement)
            }
        }),
        Ast::Block(_, stmts) | Ast::ListLiteral(_, stmts) | Ast::TupleLiteral(_, stmts) => {
            stmts.iter().any(bulk_update_proc_contains_operation_call)
        }
        Ast::HashMapLiteral(_, entries) => entries.iter().any(|entry| {
            bulk_update_proc_contains_operation_call(&entry.key)
                || bulk_update_proc_contains_operation_call(&entry.value)
        }),
        Ast::Bind(_, _, rhs)
        | Ast::SafeBind(_, _, rhs, _)
        | Ast::StatementQuestion(_, rhs)
        | Ast::Grouped(_, rhs)
        | Ast::FacetCapture(_, rhs)
        | Ast::Semi(_, rhs) => bulk_update_proc_contains_operation_call(rhs),
        Ast::BinOp(_, _, lhs, rhs)
        | Ast::Pipe(_, lhs, rhs)
        | Ast::ContextMap(_, lhs, rhs)
        | Ast::ContextApply(_, lhs, rhs)
        | Ast::ContextBind(_, lhs, rhs)
        | Ast::Compose(_, lhs, rhs)
        | Ast::LiftedCompose(_, lhs, rhs)
        | Ast::KleisliCompose(_, lhs, rhs)
        | Ast::ListCons(_, lhs, rhs)
        | Ast::RangeLiteral(_, lhs, rhs) => {
            bulk_update_proc_contains_operation_call(lhs)
                || bulk_update_proc_contains_operation_call(rhs)
        }
        Ast::FieldAccess(_, target, _) => bulk_update_proc_contains_operation_call(target),
        Ast::Match(_, scrutinee, arms) => {
            bulk_update_proc_contains_operation_call(scrutinee)
                || arms.iter().any(|arm| {
                    arm.guard
                        .as_ref()
                        .is_some_and(bulk_update_proc_contains_operation_call)
                        || bulk_update_proc_contains_operation_call(&arm.body)
                })
        }
        Ast::BulkUpdate(_, source, entries) => {
            bulk_update_proc_contains_operation_call(source)
                || entries
                    .iter()
                    .any(|entry| bulk_update_entry_contains_operation_call(entry))
        }
        Ast::Capture(_, target, args) => {
            bulk_update_proc_contains_operation_call(target)
                || args.iter().any(bulk_update_proc_contains_operation_call)
        }
        Ast::Closure(_, _, body) | Ast::ExtractorClosure(_, _, body) => {
            bulk_update_proc_contains_operation_call(body)
        }
        Ast::Dbg(_, args) => args
            .iter()
            .any(|arg| bulk_update_proc_contains_operation_call(&arg.expr)),
        Ast::StructLit(_, _, fields) => fields.iter().any(|field| match field {
            StructLitField::Explicit(_, expr) => bulk_update_proc_contains_operation_call(expr),
            StructLitField::Shorthand(_) => false,
        }),
        Ast::InternalStructLit(_, _, fields) => fields.iter().any(|field| match field {
            StructLitField::Explicit(_, expr) => bulk_update_proc_contains_operation_call(expr),
            StructLitField::Shorthand(_) => false,
        }),
        Ast::ConstructorCall(_, _, args) | Ast::EnumConstructorCall(_, _, _, _, args) => {
            args.iter().any(|arg| match arg {
                RecordLitArg::Positional(inner) | RecordLitArg::Named(_, inner) => {
                    bulk_update_proc_contains_operation_call(inner)
                }
            })
        }
        Ast::FacetSegmentAccess(_, target, segment) => {
            bulk_update_proc_contains_operation_call(target)
                || match segment {
                    FacetPathSegment::Bracket(bracket) => {
                        bulk_update_proc_contains_operation_call(&bracket.expr)
                    }
                    FacetPathSegment::Field { .. } => false,
                }
        }
        Ast::InterpolatedStr(_, parts) => parts.iter().any(|part| match part {
            InterpolatedPart::Text(_) => false,
            InterpolatedPart::Expr(expr) => bulk_update_proc_contains_operation_call(expr),
        }),
        Ast::Reflection(..)
        | Ast::BuiltinReflectionDecl(..)
        | Ast::Lit(_, _)
        | Ast::Var(_, _)
        | Ast::InternalVar(_, _)
        | Ast::Path(_, _)
        | Ast::FuncLiteralRef(_, _)
        | Ast::NamedInfixRef(_, _)
        | Ast::ListNil(_)
        | Ast::CapturePlaceholder(_, _)
        | Ast::StructDef(..)
        | Ast::RecordDef(..)
        | Ast::EnumDef(..)
        | Ast::ConstDef(..)
        | Ast::SupervisorInit(..)
        | Ast::BuiltinDecl(..)
        | Ast::IntrinsicDecl(..)
        | Ast::BuiltinExtractorDecl(..)
        | Ast::BuiltinTypeDecl(..)
        | Ast::TypeAlias(..)
        | Ast::Def(..)
        | Ast::DeferrorDef(..)
        | Ast::ExtractorDef(..)
        | Ast::TraitDef(..)
        | Ast::ImplDef(..)
        | Ast::TraitImplDef(..)
        | Ast::Import(..)
        | Ast::Include(..)
        | Ast::Defmod(..)
        | Ast::Defagent(..)
        | Ast::Defgenserver(..)
        | Ast::Defsupervisor(..)
        | Ast::DefdynamicSupervisor(..)
        | Ast::Namespace(..) => false,
    }
}

fn block_stmts_to_expr(mut body_stmts: Vec<Ast>) -> Ast {
    if body_stmts.len() == 1 {
        return body_stmts.remove(0);
    }
    Ast::Block(
        Span {
            start: body_stmts[0].span().start,
            end: body_stmts[body_stmts.len() - 1].span().end,
        },
        body_stmts,
    )
}

fn bulk_update_entry_contains_operation_call(entry: &BulkUpdateEntry) -> bool {
    match &entry.kind {
        BulkUpdateEntryKind::Set(expr)
        | BulkUpdateEntryKind::Over(expr)
        | BulkUpdateEntryKind::OverResult(expr)
        | BulkUpdateEntryKind::CaseSet(expr)
        | BulkUpdateEntryKind::CaseOver(expr) => bulk_update_proc_contains_operation_call(expr),
        BulkUpdateEntryKind::Nested(entries) => entries
            .iter()
            .any(bulk_update_entry_contains_operation_call),
    }
}
