use super::*;
use diagnostics::{
    DiagnosticData, DiagnosticOrigin, EnumConstructorConstraintStatus,
    EnumConstructorTypeArgumentData, Remediation, ReturnTypeArgumentData, SourceFact, SourceId,
    SourceRole, StructuredDiagnostic, TypeDiagnosticReason,
};

enum UnresolvedExecutableTypeArgument {
    ReturnTypeArgument {
        callable: String,
        ordinal: u32,
        unresolved: String,
        span: Span,
    },
    EnumConstructor {
        enum_name: String,
        constructor: String,
        ordinal: u32,
        span: Span,
    },
}

enum ResolvedDeferredDoFailure {
    Result(MonadFailTarget),
    Alternative(TypedNode),
}

#[derive(Clone)]
struct CallableSpecializationRequirements {
    tyvars: Vec<u32>,
    requires_concrete: bool,
}

struct SpecializationContext<'a> {
    defs_by_fun_idx: &'a SpecializableDefinitions,
    bound_tyvars_by_fun_idx: &'a HashMap<u32, CallableSpecializationRequirements>,
    needs_specialization: &'a HashSet<u32>,
    specialization_fun_idxs: &'a mut HashMap<CallableInstantiationKey, u32>,
    generated_defs: &'a mut Vec<TypedNode>,
}

impl Checker {
    fn specialization_type_is_concrete(ty: &Ty) -> bool {
        let mut variables = Vec::new();
        Self::collect_ty_vars(ty, &mut variables);
        variables.is_empty()
    }

    fn propagate_callable_specialization_requirements(
        &self,
        definitions: &SpecializableDefinitions,
        requirements: &mut HashMap<u32, CallableSpecializationRequirements>,
    ) -> Result<(), TypeError> {
        use std::cell::RefCell;
        let mut signatures = HashMap::new();
        let mut edges = Vec::new();
        let mut indices = definitions.keys().copied().collect::<Vec<_>>();
        indices.sort_unstable();
        for index in indices {
            let definition = &definitions[&index];
            let mut variables = Vec::new();
            match &definition.node {
                TypedInner::Def(_, _, arguments, parameters, result, ..) => {
                    for argument in arguments {
                        Self::collect_ty_vars(&argument.ty, &mut variables);
                    }
                    for parameter in parameters {
                        Self::collect_ty_vars(&parameter.ty, &mut variables);
                    }
                    Self::collect_ty_vars(result, &mut variables);
                }
                TypedInner::ExtractorDef(_, _, _, parameters, result, ..) => {
                    for parameter in parameters {
                        Self::collect_ty_vars(&parameter.ty, &mut variables);
                    }
                    Self::collect_ty_vars(result, &mut variables);
                }
                _ => {
                    return Err(self.typecheck_invariant_error(
                        "specialization requirements must name a callable definition",
                        &definition.span,
                    ))
                }
            }
            signatures.insert(index, variables.into_iter().collect::<HashSet<_>>());
            let calls = RefCell::new(Vec::new());
            self.find_typed_node(definition, &|_, node| {
                let mut types = Self::pattern_callable_types(node);
                if !matches!(
                    node.node,
                    TypedInner::Def(..) | TypedInner::ExtractorDef(..)
                ) {
                    types.push((&node.ty, &node.span));
                }
                for (ty, span) in types {
                    if let Ty::UserFunc {
                        fun_idx,
                        call_substitution,
                        ..
                    } = ty
                    {
                        if definitions.contains_key(fun_idx) {
                            calls.borrow_mut().push((
                                *fun_idx,
                                call_substitution.clone(),
                                span.clone(),
                            ));
                        }
                    }
                }
                None::<()>
            });
            edges.push((index, calls.into_inner()));
        }

        // The graph and saved substitutions are immutable. Propagate only
        // declaration-owned slots until the finite sets reach a fixed point.
        loop {
            let mut changed = false;
            for (caller, calls) in &edges {
                let mut forwarded = requirements[caller].clone();
                for (callee, substitution, span) in calls {
                    let required = &requirements[callee];
                    forwarded.requires_concrete |= required.requires_concrete;
                    for variable in &required.tyvars {
                        let Some((_, input)) =
                            substitution.iter().find(|(slot, _)| slot == variable)
                        else {
                            return Err(self.typecheck_invariant_error(
                                "Missing call substitution for ordinary specialization",
                                span,
                            ));
                        };
                        let mut inputs = Vec::new();
                        Self::collect_ty_vars(&self.resolve_ty(input), &mut inputs);
                        for input in inputs {
                            if signatures[caller].contains(&input)
                                && !forwarded.tyvars.contains(&input)
                            {
                                forwarded.tyvars.push(input);
                            }
                        }
                    }
                }
                // Stable keys do not depend on hash iteration or definition order.
                forwarded.tyvars.sort_unstable();
                if forwarded.tyvars != requirements[caller].tyvars
                    || forwarded.requires_concrete != requirements[caller].requires_concrete
                {
                    requirements.insert(*caller, forwarded);
                    changed = true;
                }
            }
            if !changed {
                break;
            }
        }
        Ok(())
    }

    fn resolve_deferred_do_failure(
        &mut self,
        deferred: DeferredDoFailureTarget,
    ) -> Result<ResolvedDeferredDoFailure, Box<TypeError>> {
        let target = self.resolve_pattern_failure_target(
            &deferred.carrier_ty,
            &deferred.propagated_error_tys,
            &deferred.failure_span,
            Some((
                &deferred.alternative_trait_key,
                &deferred.alternative_method_name,
                &deferred.do_keyword_span,
            )),
            false,
        )?;
        match target {
            SafeBindFailureTarget::DoMonadFail(target) => {
                Ok(ResolvedDeferredDoFailure::Result(*target))
            }
            SafeBindFailureTarget::DoAlternative { empty } => {
                Ok(ResolvedDeferredDoFailure::Alternative(*empty))
            }
            _ => unreachable!("resolved do failure context"),
        }
    }

    fn collect_direct_pattern_requirements(
        &self,
        definitions: &SpecializableDefinitions,
    ) -> Result<HashMap<u32, Vec<u32>>, TypeError> {
        use std::cell::RefCell;
        let mut signatures = HashMap::new();
        let mut requirements = HashMap::<u32, Vec<u32>>::new();
        for (index, definition) in definitions {
            let mut variables = Vec::new();
            match &definition.node {
                TypedInner::Def(_, _, arguments, parameters, result, _, _, _) => {
                    for argument in arguments {
                        Self::collect_ty_vars(&argument.ty, &mut variables);
                    }
                    for parameter in parameters {
                        Self::collect_ty_vars(&parameter.ty, &mut variables);
                    }
                    Self::collect_ty_vars(result, &mut variables);
                }
                TypedInner::ExtractorDef(_, _, _, parameters, result, _, _) => {
                    for parameter in parameters {
                        Self::collect_ty_vars(&parameter.ty, &mut variables);
                    }
                    Self::collect_ty_vars(result, &mut variables);
                }
                _ => {
                    return Err(self.typecheck_invariant_error(
                        "specializable definition metadata must name a callable definition",
                        &definition.span,
                    ))
                }
            }
            let signature = variables.into_iter().collect::<HashSet<_>>();
            let own = RefCell::new(Vec::new());
            if let Some(error) = self.find_typed_node(definition, &|checker, node| {
                if let TypedInner::Match(_, arms) = &node.node {
                    for arm in arms {
                        match checker.deferred_direct_pattern_variable(arm) {
                            Ok(Some(variable)) if signature.contains(&variable) => {
                                if !own.borrow().contains(&variable) {
                                    own.borrow_mut().push(variable);
                                }
                            }
                            Err(error) => return Some(error),
                            _ => {}
                        }
                    }
                }
                None
            }) {
                return Err(error);
            }
            let mut own = own.into_inner();
            own.sort_unstable();
            if !own.is_empty() {
                requirements.insert(*index, own);
            }
            signatures.insert(*index, signature);
        }
        if requirements.is_empty() {
            return Ok(requirements);
        }

        // Definitions and substitutions do not change during propagation.
        // Collect their forwarding edges once, then iterate only those edges.
        let mut forwarding = HashMap::new();
        for (index, definition) in definitions {
            let calls = RefCell::new(Vec::new());
            self.find_typed_node(definition, &|_, node| {
                if let Ty::UserFunc {
                    fun_idx,
                    call_substitution,
                    ..
                } = &node.ty
                {
                    calls.borrow_mut().push((*fun_idx, call_substitution));
                }
                None::<()>
            });
            forwarding.insert(*index, calls.into_inner());
        }

        // Forwarding a generic callable forwards its deferred Pattern contract.
        // Add only declaration-owned slots, using each resolved call substitution.
        loop {
            let mut changed = false;
            for (index, calls) in &forwarding {
                let mut found = requirements.get(index).cloned().unwrap_or_default();
                for (fun_idx, call_substitution) in calls {
                    if let Some(required) = requirements.get(fun_idx) {
                        for variable in required {
                            if let Some((_, Ty::Var(forwarded))) =
                                call_substitution.iter().find(|(slot, _)| slot == variable)
                            {
                                if signatures[index].contains(forwarded)
                                    && !found.contains(forwarded)
                                {
                                    found.push(*forwarded);
                                }
                            }
                        }
                    }
                }
                found.sort_unstable();
                if !found.is_empty() && requirements.get(index) != Some(&found) {
                    requirements.insert(*index, found);
                    changed = true;
                }
            }
            if !changed {
                break;
            }
        }
        Ok(requirements)
    }

    pub(super) fn specialize_program(
        &mut self,
        stmts: Vec<TypedNode>,
    ) -> Result<Vec<TypedNode>, TypeError> {
        let mut defs_by_fun_idx = self.specializable_defs.clone();
        for stmt in &stmts {
            if let Some(fun_idx) = Self::def_fun_idx(stmt) {
                defs_by_fun_idx.insert(fun_idx, Arc::new(stmt.clone()));
            }
        }

        self.direct_pattern_requirement_tyvars =
            self.collect_direct_pattern_requirements(&defs_by_fun_idx)?;

        let mut needs_specialization = HashSet::new();
        let mut bound_tyvars_by_fun_idx = HashMap::new();
        // Method identities are unchanged while classifying this compile unit.
        // Build their membership index once instead of scanning every impl per definition.
        let trait_impl_method_uids = self
            .trait_impls
            .values()
            .flat_map(|info| {
                info.methods
                    .values()
                    .map(|method| method.function_id.unique_id)
            })
            .collect::<HashSet<_>>();
        for (fun_idx, def) in &defs_by_fun_idx {
            let mut bound_tyvars = self.collect_bound_tyvars_for_def(def, &trait_impl_method_uids);
            if let Some(required) = self.direct_pattern_requirement_tyvars.get(fun_idx) {
                for variable in required {
                    if !bound_tyvars.contains(variable) {
                        bound_tyvars.push(*variable);
                    }
                }
            }
            let requires_concrete = Self::typed_node_has_pending_trait_call(def)
                || self.direct_pattern_requirement_tyvars.contains_key(fun_idx);
            bound_tyvars_by_fun_idx.insert(
                *fun_idx,
                CallableSpecializationRequirements {
                    tyvars: bound_tyvars,
                    requires_concrete,
                },
            );
        }

        self.propagate_callable_specialization_requirements(
            &defs_by_fun_idx,
            &mut bound_tyvars_by_fun_idx,
        )?;
        for (fun_idx, requirements) in &bound_tyvars_by_fun_idx {
            if requirements.requires_concrete || !requirements.tyvars.is_empty() {
                needs_specialization.insert(*fun_idx);
            }
        }

        let mut rewritten = Vec::new();
        let mut generated_defs = Vec::new();
        let mut specialization_fun_idxs = self.specialization_fun_idxs.clone();
        let mut unresolved_definition = None;

        for stmt in stmts {
            if let Some(fun_idx) = Self::def_fun_idx(&stmt) {
                if needs_specialization.contains(&fun_idx) {
                    if unresolved_definition.is_none() {
                        unresolved_definition = self.first_unresolved_executable_type_argument(
                            &stmt,
                            &HashSet::new(),
                            &HashSet::new(),
                        );
                    }
                    self.specializable_defs.insert(fun_idx, Arc::new(stmt));
                    continue;
                }
            }
            let rewritten_stmt = self
                .rewrite_specializations_in_node(
                    stmt,
                    &defs_by_fun_idx,
                    &bound_tyvars_by_fun_idx,
                    &needs_specialization,
                    &mut specialization_fun_idxs,
                    &mut generated_defs,
                )
                .map(|node| *node)
                .map_err(|error| *error)?;
            rewritten.push(rewritten_stmt);
        }

        rewritten.extend(generated_defs);
        if let Some((trait_name, method, subject, span)) = rewritten
            .iter()
            .find_map(|node| self.first_pending_trait_helper(node))
        {
            return Err(self.pending_trait_helper_error(trait_name, method, subject, span));
        }
        if let Some(unresolved) = unresolved_definition.or_else(|| {
            rewritten.iter().find_map(|node| {
                self.first_unresolved_executable_type_argument(
                    node,
                    &HashSet::new(),
                    &HashSet::new(),
                )
            })
        }) {
            return Err(match unresolved {
                UnresolvedExecutableTypeArgument::ReturnTypeArgument {
                    callable,
                    ordinal,
                    unresolved,
                    span,
                } => {
                    let message =
                        format!("return type arguments for `{callable}` cannot be inferred");
                    let help = format!("Provide an expected result type for `{callable}`.");
                    TypeError {
                        message,
                        span: span.clone(),
                        hint: Some(help.clone()),
                        structured: Some(StructuredDiagnostic {
                            reason: TypeDiagnosticReason::AmbiguousReturnTypeArgument.into(),
                            origin: DiagnosticOrigin::ReturnTypeArgument { ordinal },
                            data: DiagnosticData::ReturnTypeArgument(ReturnTypeArgumentData {
                                declared_origin: None,
                                value_parameter_origin: None,
                                return_origin: None,
                                left_origin: None,
                                right_origin: Some(SourceFact::typed(
                                    SourceRole::ReturnTypeArgument,
                                    SourceId(0),
                                    span.clone(),
                                    unresolved.clone(),
                                )),
                                required_trait: None,
                                expected_count: None,
                                actual_count: None,
                                callable,
                                ordinal: Some(ordinal),
                                expected_type: Some("concrete return type argument".into()),
                                actual_type: Some(unresolved.clone()),
                            }),
                            primary: SourceFact::typed(
                                SourceRole::ReturnTypeArgument,
                                SourceId(0),
                                span,
                                unresolved,
                            ),
                            related: Vec::new(),
                            remediation: Some(Remediation::Help { text: help }),
                        }),
                    }
                }
                UnresolvedExecutableTypeArgument::EnumConstructor {
                    enum_name,
                    constructor,
                    ordinal,
                    span,
                } => {
                    let message = format!(
                        "type argument {ordinal} for enum constructor `{constructor}` cannot be inferred"
                    );
                    let help = format!(
                        "Add an expected `{enum_name}<...>` type or specify every constructor type argument."
                    );
                    TypeError {
                        message,
                        span: span.clone(),
                        hint: Some(help.clone()),
                        structured: Some(StructuredDiagnostic {
                            reason: TypeDiagnosticReason::UnresolvedEnumConstructorTypeArgument
                                .into(),
                            origin: DiagnosticOrigin::EnumConstructor { ordinal },
                            data: DiagnosticData::EnumConstructorTypeArgument(
                                EnumConstructorTypeArgumentData {
                                    enum_name,
                                    constructor,
                                    ordinal,
                                    constraint_status:
                                        EnumConstructorConstraintStatus::Insufficient,
                                },
                            ),
                            primary: SourceFact::untyped(SourceRole::Value, SourceId(0), span),
                            related: Vec::new(),
                            remediation: Some(Remediation::Help { text: help }),
                        }),
                    }
                }
            });
        }
        // Generic templates are not executable function-table entries. Validate
        // after all enclosing calls have supplied their substitutions, so an
        // unresolved template reference cannot escape to Forge.
        let executable_functions = rewritten
            .iter()
            .filter_map(Self::def_fun_idx)
            .collect::<HashSet<_>>();
        for executable in &rewritten {
            if let Some(error) = self.find_typed_node(executable, &|checker, node| {
                // A definition's type describes its declaration; only value
                // references carry an executable function index.
                if matches!(
                    node.node,
                    TypedInner::Def(..) | TypedInner::ExtractorDef(..)
                ) {
                    return None;
                }
                let mut types = Self::pattern_callable_types(node);
                types.push((&node.ty, &node.span));
                for (ty, reference_span) in types {
                    let Ty::UserFunc {
                        fun_idx,
                        call_substitution,
                        ..
                    } = ty
                    else {
                        continue;
                    };
                    if !needs_specialization.contains(fun_idx)
                        || executable_functions.contains(fun_idx)
                    {
                        continue;
                    }
                    let definition = defs_by_fun_idx
                        .get(fun_idx)
                        .expect("specialization template has a definition");
                    let pending =
                        checker.find_typed_node(definition, &|_, call| match &call.node {
                            TypedInner::TraitCall {
                                trait_name,
                                method_name,
                                receiver_ty,
                                dispatch,
                                ..
                            } if matches!(dispatch, TraitDispatch::Pending)
                                || matches!(dispatch, TraitDispatch::Selected(instantiation)
                                if Self::selected_instantiation_has_pending_input(instantiation)) =>
                            {
                                Some((trait_name, method_name, receiver_ty))
                            }
                            _ => None,
                        });
                    if let Some((trait_name, method, subject)) = pending {
                        let mapping = call_substitution.iter().cloned().collect();
                        let subject = checker.substitute_ty_with_mapping(subject, &mapping);
                        return Some(checker.pending_trait_helper_error(
                            trait_name,
                            method,
                            &subject,
                            reference_span,
                        ));
                    }
                    return Some(
                        TypeError::new(
                            "Callable specialization requires concrete type arguments",
                            reference_span.clone(),
                        )
                        .with_hint("Add parameter or result type annotations at this call."),
                    );
                }
                None
            }) {
                return Err(error);
            }
        }
        self.specialization_fun_idxs = specialization_fun_idxs;
        Ok(rewritten)
    }

    fn first_unresolved_executable_type_argument(
        &self,
        node: &TypedNode,
        allowed_vars: &HashSet<u32>,
        allowed_enum_constructor_vars: &HashSet<u32>,
    ) -> Option<UnresolvedExecutableTypeArgument> {
        if let Some(found) = node.monad_fail_call().and_then(|call| {
            self.first_unresolved_executable_type_argument(
                call,
                allowed_vars,
                allowed_enum_constructor_vars,
            )
        }) {
            return Some(found);
        }
        if let Some(pending) = Self::pattern_expression_nodes(node)
            .into_iter()
            .find_map(|expr| {
                self.first_unresolved_executable_type_argument(
                    expr,
                    allowed_vars,
                    allowed_enum_constructor_vars,
                )
            })
        {
            return Some(pending);
        }
        if let TypedInner::ConstructorCall(tag, _) = &node.node {
            let enum_application = match self.resolve_ty(&node.ty) {
                Ty::Enum(enum_name, arguments) => Some((enum_name, arguments)),
                _ => None,
            };
            if let Some((enum_name, arguments)) = enum_application {
                if let Some(ordinal) = arguments.iter().position(|argument| {
                    let mut variables = Vec::new();
                    Self::collect_ty_vars(&self.resolve_ty(argument), &mut variables);
                    variables
                        .iter()
                        .any(|variable| !allowed_enum_constructor_vars.contains(variable))
                }) {
                    let variant = self
                        .env
                        .enum_variant_by_tag(*tag)
                        .expect("typed enum constructor tag has canonical metadata");
                    return Some(UnresolvedExecutableTypeArgument::EnumConstructor {
                        enum_name: Self::surface_name(&enum_name).into(),
                        constructor: Self::surface_name(&variant.constructor_name).into(),
                        ordinal: ordinal as u32,
                        span: node.span.clone(),
                    });
                }
            }
        }
        if let TypedInner::App(func, _) = &node.node {
            if let TypedInner::Var(id) = &func.node {
                // Compiler-generated process helpers carry synthetic generic
                // signatures whose variables are resolved by their lowering
                // path rather than by source-level return-type inference.
                if !id.compiler_generated {
                    if let Some(signature) = self.callable_signatures.get(&id.unique_id) {
                        if !signature.return_type_arguments.is_empty() {
                            let resolved = self.resolve_ty(&node.ty);
                            let mut unresolved = Vec::new();
                            Self::collect_ty_vars(&resolved, &mut unresolved);
                            let call_substitution = match &func.ty {
                                Ty::UserFunc {
                                    call_substitution, ..
                                } => call_substitution.as_slice(),
                                _ => &[],
                            };
                            let argument = signature
                                .return_type_arguments
                                .iter()
                                .find(|argument| {
                                    let mut declared = Vec::new();
                                    Self::collect_ty_vars(&argument.ty, &mut declared);
                                    declared.into_iter().any(|declared_var| {
                                        call_substitution
                                            .iter()
                                            .find(|(original, _)| *original == declared_var)
                                            .is_some_and(|(_, instantiated)| {
                                                let mut instantiated_vars = Vec::new();
                                                Self::collect_ty_vars(
                                                    &self.resolve_ty(instantiated),
                                                    &mut instantiated_vars,
                                                );
                                                instantiated_vars.iter().any(|var| {
                                                    unresolved.contains(var)
                                                        && !allowed_vars.contains(var)
                                                })
                                            })
                                    })
                                })
                                .unwrap_or(&signature.return_type_arguments[0]);
                            let result_can_receive_a_later_call_witness = matches!(
                                &resolved,
                                Ty::Func(..) | Ty::BuiltinFunc { .. } | Ty::UserFunc { .. }
                            );
                            if !result_can_receive_a_later_call_witness
                                && unresolved.iter().any(|var| !allowed_vars.contains(var))
                            {
                                return Some(
                                    UnresolvedExecutableTypeArgument::ReturnTypeArgument {
                                        callable: id.name.clone(),
                                        ordinal: argument.ordinal,
                                        unresolved: self.diagnostic_ty_name(&resolved),
                                        span: node.span.clone(),
                                    },
                                );
                            }
                        }
                    }
                }
            }
        }

        let visit = |child: &TypedNode| {
            self.first_unresolved_executable_type_argument(
                child,
                allowed_vars,
                allowed_enum_constructor_vars,
            )
        };
        match &node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => visit(message).or_else(|| payload.iter().find_map(visit)),
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                visit(func).or_else(|| args.iter().find_map(visit))
            }
            TypedInner::TraitCall { args, .. }
            | TypedInner::ListLiteral(args)
            | TypedInner::TupleLiteral(args)
            | TypedInner::StructLit(_, args)
            | TypedInner::ConstructorCall(_, args) => args.iter().find_map(visit),
            TypedInner::Block(stmts) => stmts.iter().find_map(visit),
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs)
            | TypedInner::EagerBoundary(rhs)
            | TypedInner::FieldAccess(rhs, _) => visit(rhs),
            TypedInner::DoSafeBind(control) => visit(&control.rhs)
                .or_else(|| match &control.failure_target {
                    SafeBindFailureTarget::DoAlternative { empty } => visit(empty),
                    _ => None,
                })
                .or_else(|| visit(&control.continuation)),
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right)
            | TypedInner::Cause(left, right) => visit(left).or_else(|| visit(right)),
            TypedInner::If(cond, then_branch, else_branch) => visit(cond)
                .or_else(|| visit(then_branch))
                .or_else(|| else_branch.as_deref().and_then(visit)),
            TypedInner::Match(scrutinee, arms) => visit(scrutinee).or_else(|| {
                arms.iter().find_map(|arm| {
                    arm.guard
                        .as_ref()
                        .and_then(visit)
                        .or_else(|| visit(&arm.body))
                })
            }),
            TypedInner::InterpolatedStr(parts) => parts.iter().find_map(|part| match part {
                TypedInterpolatedPart::Text(_) => None,
                TypedInterpolatedPart::Expr(expr) => visit(expr),
            }),
            TypedInner::Dbg(args) => args.iter().find_map(|arg| visit(&arg.expr)),
            TypedInner::HashMapLiteral(entries) => entries
                .iter()
                .find_map(|(key, value)| visit(key).or_else(|| visit(value))),
            TypedInner::SupervisorSpawn { init, .. }
            | TypedInner::FacetView { source: init, .. } => visit(init),
            TypedInner::SupervisorAdopt { pid, .. } => visit(pid),
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                visit(init).or_else(|| visit(strategy))
            }
            TypedInner::FacetSet { source, value, .. } => visit(source).or_else(|| visit(value)),
            TypedInner::FacetOver {
                source, update_fun, ..
            } => visit(source).or_else(|| visit(update_fun)),
            TypedInner::Def(_, _, return_type_arguments, params, ret_ty, _, body, _) => {
                let mut allowed = allowed_vars.clone();
                let mut allowed_enum_constructors = allowed_enum_constructor_vars.clone();
                for argument in return_type_arguments {
                    self.extend_allowed_vars(&argument.ty, &mut allowed);
                    self.extend_allowed_vars(&argument.ty, &mut allowed_enum_constructors);
                }
                for param in params {
                    self.extend_allowed_vars(&param.ty, &mut allowed);
                    self.extend_allowed_vars(&param.ty, &mut allowed_enum_constructors);
                }
                self.extend_allowed_vars(ret_ty, &mut allowed);
                self.first_unresolved_executable_type_argument(
                    body,
                    &allowed,
                    &allowed_enum_constructors,
                )
            }
            TypedInner::ExtractorDef(_, _, type_params, param, ret_ty, body, _) => {
                let mut allowed = allowed_vars.clone();
                let mut allowed_enum_constructors = allowed_enum_constructor_vars.clone();
                for type_param in type_params {
                    allowed.insert(type_param.ty_var);
                    allowed_enum_constructors.insert(type_param.ty_var);
                }
                for param in param {
                    self.extend_allowed_vars(&param.ty, &mut allowed);
                    self.extend_allowed_vars(&param.ty, &mut allowed_enum_constructors);
                }
                self.extend_allowed_vars(ret_ty, &mut allowed);
                self.first_unresolved_executable_type_argument(
                    body,
                    &allowed,
                    &allowed_enum_constructors,
                )
            }
            TypedInner::DeferrorDef(_, _, _, params, body) => {
                let mut allowed = allowed_vars.clone();
                let mut allowed_enum_constructors = allowed_enum_constructor_vars.clone();
                for parameter in params {
                    self.extend_allowed_vars(&parameter.ty, &mut allowed);
                    self.extend_allowed_vars(&parameter.ty, &mut allowed_enum_constructors);
                }
                self.first_unresolved_executable_type_argument(
                    body,
                    &allowed,
                    &allowed_enum_constructors,
                )
            }
            TypedInner::Closure(params, _, body)
            | TypedInner::ExtractorClosure(params, _, body)
            | TypedInner::CaptureClosure(params, _, body) => {
                let mut allowed_enum_constructors = allowed_enum_constructor_vars.clone();
                for parameter in params {
                    self.extend_allowed_vars(&parameter.ty, &mut allowed_enum_constructors);
                }
                self.first_unresolved_executable_type_argument(
                    body,
                    allowed_vars,
                    &allowed_enum_constructors,
                )
            }
            TypedInner::CaptureConstructorClosure(_, params, _, body) => {
                let mut allowed_enum_constructors = allowed_enum_constructor_vars.clone();
                for parameter in params {
                    self.extend_allowed_vars(&parameter.ty, &mut allowed_enum_constructors);
                }
                self.first_unresolved_executable_type_argument(
                    body,
                    allowed_vars,
                    &allowed_enum_constructors,
                )
            }
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::ProcessContextHandler { .. }
            | TypedInner::SupervisorStatus { .. }
            | TypedInner::FacetPath(_)
            | TypedInner::PendingFacetPath(_)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..) => None,
        }
    }

    fn extend_allowed_vars(&self, ty: &Ty, allowed: &mut HashSet<u32>) {
        let mut vars = Vec::new();
        Self::collect_ty_vars(&self.resolve_ty(ty), &mut vars);
        allowed.extend(vars);
    }

    fn rewrite_do_safebind_specializations(
        &mut self,
        control: Box<TypedDoSafeBind>,
        span: &Span,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedDoSafeBind>, Box<TypeError>> {
        let TypedDoSafeBind {
            pattern,
            rhs,
            projection,
            failure_target,
            continuation,
            origins,
        } = *control;
        let rhs = self.rewrite_specializations_in_node(
            *rhs,
            defs_by_fun_idx,
            bound_tyvars_by_fun_idx,
            needs_specialization,
            specialization_fun_idxs,
            generated_defs,
        )?;
        let pattern_input_ty = match &projection {
            SafeBindRhsProjection::CanonicalResultOnce { payload_ty, .. } => payload_ty,
            SafeBindRhsProjection::PatternInput { pattern_input_ty } => pattern_input_ty,
        };
        let pattern = self.concretize_specialized_typed_pattern(
            pattern,
            Some(pattern_input_ty),
            span,
            &mut SpecializationContext {
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            },
        )?;
        let failure_target = match failure_target {
            SafeBindFailureTarget::DoMonadFail(mut target) => {
                target.call = self.rewrite_specializations_in_node(
                    *target.call,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                SafeBindFailureTarget::DoMonadFail(target)
            }
            SafeBindFailureTarget::EnclosingMonadFail(mut target) => {
                target.call = self.rewrite_specializations_in_node(
                    *target.call,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                SafeBindFailureTarget::EnclosingMonadFail(target)
            }
            SafeBindFailureTarget::DoAlternative { empty } => {
                SafeBindFailureTarget::DoAlternative {
                    empty: self.rewrite_specializations_in_node(
                        *empty,
                        defs_by_fun_idx,
                        bound_tyvars_by_fun_idx,
                        needs_specialization,
                        specialization_fun_idxs,
                        generated_defs,
                    )?,
                }
            }
            SafeBindFailureTarget::Deferred(deferred) => {
                let deferred = DeferredDoFailureTarget {
                    carrier_ty: deferred.carrier_ty,
                    alternative_trait_key: deferred.alternative_trait_key,
                    alternative_method_name: deferred.alternative_method_name,
                    propagated_error_tys: deferred.propagated_error_tys,
                    failure_span: deferred.failure_span,
                    do_keyword_span: deferred.do_keyword_span,
                };
                match self.resolve_deferred_do_failure(deferred)? {
                    ResolvedDeferredDoFailure::Result(mut target) => {
                        target.call = self.rewrite_specializations_in_node(
                            *target.call,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )?;
                        SafeBindFailureTarget::DoMonadFail(Box::new(target))
                    }
                    ResolvedDeferredDoFailure::Alternative(empty) => {
                        let empty = self.rewrite_specializations_in_node(
                            empty,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )?;
                        SafeBindFailureTarget::DoAlternative { empty }
                    }
                }
            }
            other => other,
        };
        let continuation = self.rewrite_specializations_in_node(
            *continuation,
            defs_by_fun_idx,
            bound_tyvars_by_fun_idx,
            needs_specialization,
            specialization_fun_idxs,
            generated_defs,
        )?;
        Ok(Box::new(TypedDoSafeBind {
            pattern,
            rhs,
            projection,
            failure_target,
            continuation,
            origins,
        }))
    }

    fn rewrite_bind_specializations(
        &mut self,
        pattern: TypedPattern,
        rhs: Box<TypedNode>,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<Box<TypedInner>, Box<TypeError>> {
        let rhs = self.rewrite_specializations_in_node(
            *rhs,
            context.defs_by_fun_idx,
            context.bound_tyvars_by_fun_idx,
            context.needs_specialization,
            context.specialization_fun_idxs,
            context.generated_defs,
        )?;
        let pattern =
            self.concretize_specialized_typed_pattern(pattern, Some(&rhs.ty), span, context)?;
        Ok(Box::new(TypedInner::Bind(pattern, rhs)))
    }

    // Keep the large Pattern result and error temporaries out of every recursive
    // specialization frame, including trees which never contain apply_pattern.
    fn rewrite_apply_pattern_specializations(
        &mut self,
        value: Box<TypedNode>,
        pattern: TypedPattern,
        projections: Vec<(ResolvedId, Ty)>,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<Box<TypedInner>, Box<TypeError>> {
        let value = self.rewrite_specializations_in_node(
            *value,
            context.defs_by_fun_idx,
            context.bound_tyvars_by_fun_idx,
            context.needs_specialization,
            context.specialization_fun_idxs,
            context.generated_defs,
        )?;
        let pattern =
            self.concretize_specialized_typed_pattern(pattern, Some(&value.ty), span, context)?;
        Ok(Box::new(TypedInner::ApplyPattern {
            value,
            pattern,
            projections: projections
                .into_iter()
                .map(|(id, ty)| (id, self.resolve_ty(&ty)))
                .collect(),
        }))
    }

    // Retain a small dispatcher while descending structural expression trees.
    // Specialization temporaries belong to separate helper frames; both sides
    // of the recursive result remain pointer-sized.
    fn rewrite_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        match &node.node {
            TypedInner::App(..) => self.rewrite_app_specializations_in_node(
                node,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            ),
            TypedInner::Block(..) => self.rewrite_block_specializations_in_node(
                node,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            ),
            TypedInner::Match(..) => self.rewrite_match_specializations_in_node(
                node,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            ),
            TypedInner::Closure(..)
            | TypedInner::ExtractorClosure(..)
            | TypedInner::CaptureClosure(..)
            | TypedInner::CaptureConstructorClosure(..) => self
                .rewrite_closure_specializations_in_node(
                    node,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                ),
            TypedInner::Lit(..)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(..)
            | TypedInner::SupervisorSpawn { .. }
            | TypedInner::SupervisorAdopt { .. }
            | TypedInner::SupervisorStatus { .. }
            | TypedInner::SupervisorWorkers { .. }
            | TypedInner::TraitCall { .. }
            | TypedInner::InjectCall(..)
            | TypedInner::Bind(..)
            | TypedInner::ApplyPattern { .. }
            | TypedInner::SafeBind(..)
            | TypedInner::DoSafeBind(..)
            | TypedInner::BinOp(..)
            | TypedInner::Pipe(..)
            | TypedInner::Compose(..)
            | TypedInner::ListNil
            | TypedInner::ListCons(..)
            | TypedInner::ListLiteral(..)
            | TypedInner::HashMapLiteral(..)
            | TypedInner::TupleLiteral(..)
            | TypedInner::InterpolatedStr(..)
            | TypedInner::Dbg(..)
            | TypedInner::EagerBoundary(..)
            | TypedInner::If(..)
            | TypedInner::Cause(..)
            | TypedInner::FieldAccess(..)
            | TypedInner::ProcessContextHandler { .. }
            | TypedInner::FacetPath(..)
            | TypedInner::PendingFacetPath(..)
            | TypedInner::FacetView { .. }
            | TypedInner::FacetSet { .. }
            | TypedInner::FacetOver { .. }
            | TypedInner::StructLit(..)
            | TypedInner::ConstructorCall(..)
            | TypedInner::DeferrorDef(..)
            | TypedInner::ErrorConstruct { .. }
            | TypedInner::Def(..)
            | TypedInner::ExtractorDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::Capture(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::Semi(..) => self.rewrite_other_specializations_in_node(
                node,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            ),
        }
    }

    #[inline(never)]
    fn rewrite_app_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        let span = node.span.clone();
        let mut ty = node.ty.clone();
        let node = match node.node {
            TypedInner::App(func, args) => {
                let func = *self.rewrite_specializations_in_node(
                    *func,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                let args = args
                    .into_iter()
                    .map(|arg| {
                        self.rewrite_specializations_in_node(
                            arg,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?;

                if let Ty::UserFunc { fun_idx, .. } = &func.ty {
                    if needs_specialization.contains(fun_idx) {
                        let original_def =
                            defs_by_fun_idx.get(fun_idx).ok_or_else(|| TypeError {
                                structured: None,
                                message: format!(
                                    "Missing generic definition for fun_idx {}",
                                    fun_idx
                                ),
                                span: span.clone(),
                                hint: None,
                            })?;
                        let requirements = bound_tyvars_by_fun_idx
                            .get(fun_idx)
                            .expect("specialization requirements exist for every definition");
                        let bound_tyvars = &requirements.tyvars;
                        let mapping = self.infer_specialization_mapping(
                            original_def,
                            &args,
                            Some(&func.ty),
                            false,
                            &bound_tyvars,
                        )?;
                        let fully_concrete = mapping.len() == bound_tyvars.len()
                            && bound_tyvars.iter().all(|var| {
                                mapping
                                    .get(var)
                                    .is_some_and(Self::specialization_type_is_concrete)
                            });
                        // Type variables are erased at runtime. A definition
                        // without pending trait dispatch can therefore be
                        // materialized safely even while a callable result is
                        // still waiting for a later type witness. This keeps a
                        // valid function-table entry instead of leaking the
                        // pre-normalization generic index into Forge.
                        if fully_concrete || !requirements.requires_concrete {
                            let concrete_tys = bound_tyvars
                                .iter()
                                .map(|var| mapping.get(var).cloned().unwrap_or(Ty::Var(*var)))
                                .collect::<Vec<_>>();
                            let specialized_fun_idx = self.ensure_specialized_def(
                                *fun_idx,
                                &concrete_tys,
                                &mapping,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )?;
                            let specialized_func_ty = match func.ty.clone() {
                                Ty::UserFunc {
                                    type_params,
                                    call_substitution,
                                    params,
                                    ret,
                                    ..
                                } => {
                                    let call_site_mapping = call_substitution
                                        .iter()
                                        .map(|(variable, ty)| (*variable, self.resolve_ty(ty)))
                                        .collect::<HashMap<_, _>>();
                                    let (params, ret) = if fully_concrete {
                                        match &original_def.node {
                                            TypedInner::Def(
                                                _,
                                                _,
                                                _,
                                                declared_params,
                                                declared_ret,
                                                ..,
                                            ) => (
                                                declared_params
                                                    .iter()
                                                    .map(|parameter| {
                                                        self.substitute_ty_with_mapping(
                                                            &parameter.ty,
                                                            &call_site_mapping,
                                                        )
                                                    })
                                                    .collect(),
                                                Box::new(self.substitute_ty_with_mapping(
                                                    declared_ret,
                                                    &call_site_mapping,
                                                )),
                                            ),
                                            TypedInner::ExtractorDef(
                                                _,
                                                _,
                                                _,
                                                declared_param,
                                                declared_ret,
                                                ..,
                                            ) => (
                                                declared_param
                                                    .iter()
                                                    .map(|param| {
                                                        self.substitute_ty_with_mapping(
                                                            &param.ty,
                                                            &call_site_mapping,
                                                        )
                                                    })
                                                    .collect(),
                                                Box::new(self.substitute_ty_with_mapping(
                                                    declared_ret,
                                                    &call_site_mapping,
                                                )),
                                            ),
                                            _ => (params, ret),
                                        }
                                    } else {
                                        (params, ret)
                                    };
                                    Ty::UserFunc {
                                        fun_idx: specialized_fun_idx,
                                        type_params,
                                        call_substitution: if fully_concrete {
                                            Vec::new()
                                        } else {
                                            call_substitution
                                        },
                                        params,
                                        ret,
                                    }
                                }
                                other => other,
                            };
                            if let Ty::UserFunc { ret, .. } = &specialized_func_ty {
                                ty = ret.as_ref().clone();
                            }
                            let specialized_func = TypedNode {
                                ty: specialized_func_ty,
                                span: func.span.clone(),
                                node: func.node,
                            };
                            TypedInner::App(Box::new(specialized_func), args)
                        } else {
                            TypedInner::App(Box::new(func), args)
                        }
                    } else {
                        TypedInner::App(Box::new(func), args)
                    }
                } else {
                    TypedInner::App(Box::new(func), args)
                }
            }
            _ => unreachable!("specialization dispatcher selected a non-app node"),
        };

        Ok(Box::new(TypedNode { ty, span, node }))
    }

    #[inline(never)]
    fn rewrite_block_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        let span = node.span.clone();
        let mut ty = node.ty.clone();
        let node = match node.node {
            TypedInner::Block(stmts) => {
                let stmts = stmts
                    .into_iter()
                    .map(|stmt| {
                        self.rewrite_specializations_in_node(
                            stmt,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?;
                if let Some(last) = stmts.last() {
                    ty = last.ty.clone();
                }
                TypedInner::Block(stmts)
            }
            _ => unreachable!("specialization dispatcher selected a non-block node"),
        };

        Ok(Box::new(TypedNode { ty, span, node }))
    }

    #[inline(never)]
    fn rewrite_match_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        let span = node.span.clone();
        let ty = node.ty.clone();
        let node = match node.node {
            TypedInner::Match(scrutinee, arms) => TypedInner::Match(
                self.rewrite_specializations_in_node(
                    *scrutinee,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                arms.into_iter()
                    .map(|arm| {
                        Ok(TypedMatchArm {
                            direct_expression: arm.direct_expression,
                            pattern: self.concretize_specialized_match_pattern(
                                arm.pattern,
                                &span,
                                &mut SpecializationContext {
                                    defs_by_fun_idx,
                                    bound_tyvars_by_fun_idx,
                                    needs_specialization,
                                    specialization_fun_idxs,
                                    generated_defs,
                                },
                            )?,
                            guard: arm
                                .guard
                                .map(|guard| {
                                    self.rewrite_specializations_in_node(
                                        guard,
                                        defs_by_fun_idx,
                                        bound_tyvars_by_fun_idx,
                                        needs_specialization,
                                        specialization_fun_idxs,
                                        generated_defs,
                                    )
                                })
                                .transpose()?
                                .map(|node| *node),
                            body: *self.rewrite_specializations_in_node(
                                arm.body,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )?,
                        })
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?,
            ),
            _ => unreachable!("specialization dispatcher selected a non-match node"),
        };

        Ok(Box::new(TypedNode { ty, span, node }))
    }

    #[inline(never)]
    fn rewrite_closure_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        let span = node.span.clone();
        let ty = node.ty.clone();
        let node = match node.node {
            TypedInner::Closure(params, captures, body) => TypedInner::Closure(
                params,
                captures,
                self.rewrite_specializations_in_node(
                    *body,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::ExtractorClosure(params, captures, body) => TypedInner::ExtractorClosure(
                params,
                captures,
                self.rewrite_specializations_in_node(
                    *body,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::CaptureClosure(params, captures, body) => TypedInner::CaptureClosure(
                params,
                captures,
                self.rewrite_specializations_in_node(
                    *body,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::CaptureConstructorClosure(id, params, captures, body) => {
                TypedInner::CaptureConstructorClosure(
                    id,
                    params,
                    captures,
                    self.rewrite_specializations_in_node(
                        *body,
                        defs_by_fun_idx,
                        bound_tyvars_by_fun_idx,
                        needs_specialization,
                        specialization_fun_idxs,
                        generated_defs,
                    )?,
                )
            }
            _ => unreachable!("specialization dispatcher selected a non-closure node"),
        };

        Ok(Box::new(TypedNode { ty, span, node }))
    }

    #[inline(never)]
    fn rewrite_other_specializations_in_node(
        &mut self,
        node: TypedNode,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        let span = node.span.clone();
        let mut ty = node.ty.clone();
        let node = match node.node {
            TypedInner::Lit(lit) => TypedInner::Lit(lit),
            TypedInner::ErrorKind(kind) => TypedInner::ErrorKind(kind),
            TypedInner::Var(id) => TypedInner::Var(id),
            TypedInner::SupervisorSpawn {
                supervisor_process,
                worker_process,
                init,
            } => TypedInner::SupervisorSpawn {
                supervisor_process,
                worker_process,
                init: self.rewrite_specializations_in_node(
                    *init,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            },
            TypedInner::SupervisorAdopt {
                supervisor_process,
                worker_process,
                pid,
            } => TypedInner::SupervisorAdopt {
                supervisor_process,
                worker_process,
                pid: self.rewrite_specializations_in_node(
                    *pid,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            },
            TypedInner::SupervisorStatus { supervisor_process } => {
                TypedInner::SupervisorStatus { supervisor_process }
            }
            TypedInner::SupervisorWorkers {
                supervisor_process,
                worker_process,
                init,
                strategy,
            } => TypedInner::SupervisorWorkers {
                supervisor_process,
                worker_process,
                init: self.rewrite_specializations_in_node(
                    *init,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                strategy: self.rewrite_specializations_in_node(
                    *strategy,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            },
            TypedInner::TraitCall {
                trait_name,
                method_name,
                receiver_ty,
                obligation,
                dispatch,
                origin,
                args,
            } => {
                let mut args = args
                    .into_iter()
                    .map(|arg| {
                        self.rewrite_specializations_in_node(
                            arg,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                for argument in &mut args {
                    argument.ty = self.normalize_executable_constructor_identities(&argument.ty);
                }
                let receiver_ty = self.resolve_ty(&receiver_ty);
                let obligation = TraitObligation {
                    trait_id: obligation.trait_id,
                    trait_args: obligation
                        .trait_args
                        .iter()
                        .map(|arg| self.resolve_ty(arg))
                        .collect(),
                    receiver: self.resolve_ty(&obligation.receiver),
                };
                let instantiation = if let TraitDispatch::Selected(instantiation) = &dispatch {
                    Some(instantiation.as_ref().clone())
                } else if matches!(dispatch, TraitDispatch::Pending)
                    || matches!(&dispatch,
                        TraitDispatch::Static(TraitDispatchTarget::UserFunction { fun_idx, .. })
                            if needs_specialization.contains(fun_idx))
                {
                    let argument_tys = args
                        .iter()
                        .map(|arg| self.resolve_ty(&arg.ty))
                        .collect::<Vec<_>>();
                    Some(
                        match self.select_trait_method_instantiation(
                            &obligation.trait_id,
                            &method_name,
                            &obligation.receiver,
                            &obligation.trait_args,
                            &argument_tys,
                            &self.resolve_ty(&ty),
                        )? {
                            CandidateApplicability::Applicable(instantiation) => instantiation,
                            CandidateApplicability::Deferred(pending) => {
                                let mut error = self.ambiguous_constructor_result(
                                    &trait_name,
                                    &method_name,
                                    &span,
                                );
                                error.hint = Some(format!(
                                    "Add enough type information to choose among {} remaining candidate(s) and resolve {} constructor input(s).",
                                    pending.candidates.len(),
                                    pending.waiting_on.len()
                                ));
                                return Err(Box::new(error));
                            }
                            CandidateApplicability::Rejected(_) => {
                                return Err(Box::new(self.trait_dispatch_failure(
                                    TypeDiagnosticReason::NoApplicableTraitImplementation,
                                    &trait_name,
                                    &method_name,
                                    Some(&obligation.receiver),
                                    &span,
                                )));
                            }
                        },
                    )
                } else {
                    None
                };
                let dispatch = if let Some(instantiation) = instantiation {
                    self.materialize_trait_method_instantiation(
                        instantiation,
                        &span,
                        &mut SpecializationContext {
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        },
                    )?
                } else {
                    dispatch
                };
                let receiver_ty = self.normalize_executable_constructor_identities(&receiver_ty);
                let obligation = TraitObligation {
                    trait_id: obligation.trait_id.clone(),
                    trait_args: obligation
                        .trait_args
                        .iter()
                        .enumerate()
                        .map(|(ordinal, argument)| {
                            self.normalize_executable_trait_argument(
                                &obligation.trait_id,
                                ordinal,
                                argument,
                            )
                        })
                        .collect(),
                    receiver: self
                        .normalize_executable_constructor_identities(&obligation.receiver),
                };
                ty = self.normalize_executable_constructor_identities(&ty);
                TypedInner::TraitCall {
                    trait_name,
                    method_name,
                    receiver_ty,
                    obligation,
                    dispatch,
                    origin,
                    args,
                }
            }
            TypedInner::InjectCall(func, args) => {
                let mut target = *self.rewrite_specializations_in_node(
                    *func,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                let args = args
                    .into_iter()
                    .map(|arg| {
                        self.rewrite_specializations_in_node(
                            arg,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?;
                self.specialize_callable_reference(
                    &mut target,
                    &mut SpecializationContext {
                        defs_by_fun_idx,
                        bound_tyvars_by_fun_idx,
                        needs_specialization,
                        specialization_fun_idxs,
                        generated_defs,
                    },
                )?;
                TypedInner::InjectCall(Box::new(target), args)
            }
            TypedInner::Bind(pattern, rhs) => *self.rewrite_bind_specializations(
                pattern,
                rhs,
                &span,
                &mut SpecializationContext {
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                },
            )?,
            TypedInner::ApplyPattern {
                value,
                pattern,
                projections,
            } => *self.rewrite_apply_pattern_specializations(
                value,
                pattern,
                projections,
                &span,
                &mut SpecializationContext {
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                },
            )?,
            TypedInner::SafeBind(pattern, rhs, projection, failure_target) => {
                let rhs = self.rewrite_specializations_in_node(
                    *rhs,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                let pattern_input_ty = match &projection {
                    SafeBindRhsProjection::CanonicalResultOnce { payload_ty, .. } => payload_ty,
                    SafeBindRhsProjection::PatternInput { pattern_input_ty } => pattern_input_ty,
                };
                let pattern = self.concretize_specialized_typed_pattern(
                    pattern,
                    Some(pattern_input_ty),
                    &span,
                    &mut SpecializationContext {
                        defs_by_fun_idx,
                        bound_tyvars_by_fun_idx,
                        needs_specialization,
                        specialization_fun_idxs,
                        generated_defs,
                    },
                )?;
                let failure_target = match failure_target {
                    SafeBindFailureTarget::EnclosingMonadFail(mut target) => {
                        target.call = self.rewrite_specializations_in_node(
                            *target.call,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )?;
                        SafeBindFailureTarget::EnclosingMonadFail(target)
                    }
                    other => other,
                };
                TypedInner::SafeBind(pattern, rhs, projection, failure_target)
            }
            TypedInner::DoSafeBind(control) => {
                TypedInner::DoSafeBind(self.rewrite_do_safebind_specializations(
                    control,
                    &span,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?)
            }
            TypedInner::BinOp(op, left, right) => TypedInner::BinOp(
                op,
                self.rewrite_specializations_in_node(
                    *left,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *right,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::Pipe(left, right) => TypedInner::Pipe(
                self.rewrite_specializations_in_node(
                    *left,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *right,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::Compose(flavor, left, right) => TypedInner::Compose(
                flavor,
                self.rewrite_specializations_in_node(
                    *left,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *right,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::ListNil => TypedInner::ListNil,
            TypedInner::ListCons(head, tail) => TypedInner::ListCons(
                self.rewrite_specializations_in_node(
                    *head,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *tail,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::ListLiteral(items) => TypedInner::ListLiteral(
                items
                    .into_iter()
                    .map(|item| {
                        self.rewrite_specializations_in_node(
                            item,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?,
            ),
            TypedInner::HashMapLiteral(entries) => TypedInner::HashMapLiteral(
                entries
                    .into_iter()
                    .map(|(key, value)| {
                        Ok((
                            self.rewrite_specializations_in_node(
                                key,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )
                            .map(|node| *node)?,
                            self.rewrite_specializations_in_node(
                                value,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )
                            .map(|node| *node)?,
                        ))
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?,
            ),
            TypedInner::ErrorConstruct {
                kind,
                message,
                payload,
                payload_fields,
            } => TypedInner::ErrorConstruct {
                kind,
                message: self.rewrite_specializations_in_node(
                    *message,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                payload: payload
                    .into_iter()
                    .map(|value| {
                        self.rewrite_specializations_in_node(
                            value,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
                payload_fields,
            },
            TypedInner::TupleLiteral(items) => TypedInner::TupleLiteral(
                items
                    .into_iter()
                    .map(|item| {
                        self.rewrite_specializations_in_node(
                            item,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedInner::InterpolatedStr(parts) => TypedInner::InterpolatedStr(
                parts
                    .into_iter()
                    .map(|part| match part {
                        TypedInterpolatedPart::Text(text) => Ok(TypedInterpolatedPart::Text(text)),
                        TypedInterpolatedPart::Expr(expr) => Ok(TypedInterpolatedPart::Expr(
                            self.rewrite_specializations_in_node(
                                *expr,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )?,
                        )),
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?,
            ),
            TypedInner::Dbg(args) => TypedInner::Dbg(
                args.into_iter()
                    .map(|arg| {
                        Ok(TypedDbgArg {
                            span: arg.span,
                            ty_name: arg.ty_name,
                            expr: *self.rewrite_specializations_in_node(
                                arg.expr,
                                defs_by_fun_idx,
                                bound_tyvars_by_fun_idx,
                                needs_specialization,
                                specialization_fun_idxs,
                                generated_defs,
                            )?,
                        })
                    })
                    .collect::<Result<Vec<_>, Box<TypeError>>>()?,
            ),
            TypedInner::EagerBoundary(inner) => {
                TypedInner::EagerBoundary(self.rewrite_specializations_in_node(
                    *inner,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?)
            }
            TypedInner::If(cond, then_branch, else_branch) => TypedInner::If(
                self.rewrite_specializations_in_node(
                    *cond,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *then_branch,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                else_branch
                    .map(|branch| {
                        self.rewrite_specializations_in_node(
                            *branch,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                    })
                    .transpose()?,
            ),
            TypedInner::Cause(value, err) => TypedInner::Cause(
                self.rewrite_specializations_in_node(
                    *value,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                self.rewrite_specializations_in_node(
                    *err,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::FieldAccess(expr, index) => TypedInner::FieldAccess(
                self.rewrite_specializations_in_node(
                    *expr,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                index,
            ),
            TypedInner::ProcessContextHandler { process_name, slot } => {
                TypedInner::ProcessContextHandler { process_name, slot }
            }
            TypedInner::FacetPath(path) => {
                TypedInner::FacetPath(self.rewrite_specializations_in_facet_path(
                    path,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?)
            }
            TypedInner::PendingFacetPath(path) => {
                TypedInner::PendingFacetPath(self.rewrite_specializations_in_pending_facet_path(
                    path,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?)
            }
            TypedInner::FacetView {
                api,
                source,
                path,
                source_is_result,
            } => TypedInner::FacetView {
                api,
                source: self.rewrite_specializations_in_node(
                    *source,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                path: self.rewrite_specializations_in_facet_path(
                    path,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                source_is_result,
            },
            TypedInner::FacetSet {
                api,
                source,
                path,
                value,
                source_is_result,
                mode,
            } => TypedInner::FacetSet {
                api,
                source: self.rewrite_specializations_in_node(
                    *source,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                path: self.rewrite_specializations_in_facet_path(
                    path,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                value: self.rewrite_specializations_in_node(
                    *value,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                source_is_result,
                mode,
            },
            TypedInner::FacetOver {
                api,
                source,
                path,
                update_fun,
                source_is_result,
                mode,
            } => TypedInner::FacetOver {
                api,
                source: self.rewrite_specializations_in_node(
                    *source,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                path: self.rewrite_specializations_in_facet_path(
                    path,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                update_fun: self.rewrite_specializations_in_node(
                    *update_fun,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                source_is_result,
                mode,
            },
            TypedInner::StructLit(tag, fields) => TypedInner::StructLit(
                tag,
                fields
                    .into_iter()
                    .map(|field| {
                        self.rewrite_specializations_in_node(
                            field,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedInner::ConstructorCall(tag, fields) => TypedInner::ConstructorCall(
                tag,
                fields
                    .into_iter()
                    .map(|field| {
                        self.rewrite_specializations_in_node(
                            field,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedInner::DeferrorDef(tag, binding, id, params, show) => TypedInner::DeferrorDef(
                tag,
                binding,
                id,
                params,
                self.rewrite_specializations_in_node(
                    *show,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
            ),
            TypedInner::Def(
                fun_idx,
                id,
                type_params,
                params,
                ret_ty,
                where_clause,
                body,
                visibility,
            ) => TypedInner::Def(
                fun_idx,
                id,
                type_params,
                params,
                ret_ty,
                where_clause,
                self.rewrite_specializations_in_node(
                    *body,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                visibility,
            ),
            TypedInner::ExtractorDef(fun_idx, id, type_params, param, ret_ty, body, visibility) => {
                TypedInner::ExtractorDef(
                    fun_idx,
                    id,
                    type_params,
                    param,
                    ret_ty,
                    self.rewrite_specializations_in_node(
                        *body,
                        defs_by_fun_idx,
                        bound_tyvars_by_fun_idx,
                        needs_specialization,
                        specialization_fun_idxs,
                        generated_defs,
                    )?,
                    visibility,
                )
            }
            TypedInner::BuiltinExtractorDecl(id, param_ty, ret_ty) => {
                TypedInner::BuiltinExtractorDecl(id, param_ty, ret_ty)
            }
            TypedInner::Capture(target, args) => {
                let mut target = *self.rewrite_specializations_in_node(
                    *target,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?;
                let args = args
                    .into_iter()
                    .map(|arg| {
                        self.rewrite_specializations_in_node(
                            arg,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )
                        .map(|node| *node)
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                if args.is_empty() {
                    self.specialize_callable_reference(
                        &mut target,
                        &mut SpecializationContext {
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        },
                    )?;
                }
                TypedInner::Capture(Box::new(target), args)
            }
            TypedInner::StructDef(tag, name, field_names, field_policies) => {
                TypedInner::StructDef(tag, name, field_names, field_policies)
            }
            TypedInner::RecordDef(tag, name, field_names, field_policies) => {
                TypedInner::RecordDef(tag, name, field_names, field_policies)
            }
            TypedInner::EnumDef(name, variants) => TypedInner::EnumDef(name, variants),
            TypedInner::TraitDef(name, where_clause, methods) => {
                TypedInner::TraitDef(name, where_clause, methods)
            }
            TypedInner::TraitImplDef(trait_name, target_name, where_clause) => {
                TypedInner::TraitImplDef(trait_name, target_name, where_clause)
            }
            TypedInner::Semi(inner) => TypedInner::Semi(self.rewrite_specializations_in_node(
                *inner,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            )?),
            _ => unreachable!("specialization dispatcher selected a non-other node"),
        };

        Ok(Box::new(TypedNode { ty, span, node }))
    }

    fn rewrite_specializations_in_facet_path(
        &mut self,
        mut path: TypedFacetPath,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<TypedFacetPath, Box<TypeError>> {
        path.segments = path
            .segments
            .into_iter()
            .map(|segment| {
                self.rewrite_specializations_in_facet_segment(
                    segment,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(path)
    }

    fn rewrite_specializations_in_facet_segment(
        &mut self,
        segment: TypedFacetSegment,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<TypedFacetSegment, Box<TypeError>> {
        Ok(match segment {
            TypedFacetSegment::ListIndex {
                index,
                display,
                literal_index,
            } => TypedFacetSegment::ListIndex {
                index: self.rewrite_specializations_in_node(
                    *index,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                display,
                literal_index,
            },
            TypedFacetSegment::ListRange {
                start,
                end,
                display,
                literal_start,
                literal_end,
            } => TypedFacetSegment::ListRange {
                start: self.rewrite_specializations_in_node(
                    *start,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                end: self.rewrite_specializations_in_node(
                    *end,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                display,
                literal_start,
                literal_end,
            },
            TypedFacetSegment::MapKey {
                key,
                display,
                literal_key,
            } => TypedFacetSegment::MapKey {
                key: self.rewrite_specializations_in_node(
                    *key,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )?,
                display,
                literal_key,
            },
            other => other,
        })
    }

    fn rewrite_specializations_in_pending_facet_path(
        &mut self,
        mut path: PendingFacetPath,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<PendingFacetPath, Box<TypeError>> {
        path.segments = path
            .segments
            .into_iter()
            .map(|segment| {
                self.rewrite_specializations_in_pending_facet_segment(
                    segment,
                    defs_by_fun_idx,
                    bound_tyvars_by_fun_idx,
                    needs_specialization,
                    specialization_fun_idxs,
                    generated_defs,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(path)
    }

    fn rewrite_specializations_in_pending_facet_segment(
        &mut self,
        segment: PendingFacetSegment,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<PendingFacetSegment, Box<TypeError>> {
        let mut rewrite_expr =
            |this: &mut Self, expr| -> Result<PendingFacetExpr, Box<TypeError>> {
                match expr {
                    PendingFacetExpr::Resolved(expr) => Ok(PendingFacetExpr::Resolved(expr)),
                    PendingFacetExpr::Typed(expr) => Ok(PendingFacetExpr::Typed(
                        this.rewrite_specializations_in_node(
                            *expr,
                            defs_by_fun_idx,
                            bound_tyvars_by_fun_idx,
                            needs_specialization,
                            specialization_fun_idxs,
                            generated_defs,
                        )?,
                    )),
                }
            };
        Ok(match segment {
            PendingFacetSegment::Bracket { expr, display } => PendingFacetSegment::Bracket {
                expr: rewrite_expr(self, expr)?,
                display,
            },
            PendingFacetSegment::RangeBracket {
                start,
                end,
                display,
            } => PendingFacetSegment::RangeBracket {
                start: rewrite_expr(self, start)?,
                end: rewrite_expr(self, end)?,
                display,
            },
            other => other,
        })
    }

    fn specialize_callable_reference(
        &mut self,
        target: &mut TypedNode,
        context: &mut SpecializationContext<'_>,
    ) -> Result<(), TypeError> {
        if let Ty::UserFunc {
            fun_idx,
            type_params,
            call_substitution,
            params,
            ret,
        } = target.ty.clone()
        {
            if context.needs_specialization.contains(&fun_idx) {
                let original_def =
                    context
                        .defs_by_fun_idx
                        .get(&fun_idx)
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Missing generic definition for fun_idx {}", fun_idx),
                            span: target.span.clone(),
                            hint: None,
                        })?;
                let requirements = context
                    .bound_tyvars_by_fun_idx
                    .get(&fun_idx)
                    .expect("specialization requirements exist for every definition");
                let bound_tyvars = &requirements.tyvars;
                // The callable signature already carries the declaration's substitution.
                // InjectCall's bound arguments omit the injected value, so they are
                // not a complete argument list for ordinary call specialization.
                let mapping = self.infer_specialization_mapping(
                    original_def,
                    &[],
                    Some(&target.ty),
                    true,
                    &bound_tyvars,
                )?;
                let fully_concrete = mapping.len() == bound_tyvars.len()
                    && bound_tyvars.iter().all(|var| {
                        mapping
                            .get(var)
                            .is_some_and(Self::specialization_type_is_concrete)
                    });
                if fully_concrete || !requirements.requires_concrete {
                    let concrete_tys = bound_tyvars
                        .iter()
                        .map(|var| mapping.get(var).cloned().unwrap_or(Ty::Var(*var)))
                        .collect::<Vec<_>>();
                    let specialized_fun_idx = self.ensure_specialized_def(
                        fun_idx,
                        &concrete_tys,
                        &mapping,
                        context.defs_by_fun_idx,
                        context.bound_tyvars_by_fun_idx,
                        context.needs_specialization,
                        context.specialization_fun_idxs,
                        context.generated_defs,
                    )?;
                    target.ty = Ty::UserFunc {
                        fun_idx: specialized_fun_idx,
                        type_params,
                        call_substitution: if fully_concrete {
                            Vec::new()
                        } else {
                            call_substitution
                        },
                        params,
                        ret,
                    };
                }
            }
        }
        Ok(())
    }

    fn ensure_specialized_def(
        &mut self,
        original_fun_idx: u32,
        concrete_tys: &[Ty],
        mapping: &HashMap<u32, Ty>,
        defs_by_fun_idx: &SpecializableDefinitions,
        bound_tyvars_by_fun_idx: &HashMap<u32, CallableSpecializationRequirements>,
        needs_specialization: &HashSet<u32>,
        specialization_fun_idxs: &mut HashMap<CallableInstantiationKey, u32>,
        generated_defs: &mut Vec<TypedNode>,
    ) -> Result<u32, TypeError> {
        let original_def = defs_by_fun_idx
            .get(&original_fun_idx)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!(
                    "Missing generic definition for fun_idx {}",
                    original_fun_idx
                ),
                span: Span { start: 0, end: 0 },
                hint: None,
            })?;
        let key = self.specialization_key_for_def(original_def, concrete_tys, mapping)?;
        if let Some(existing) = specialization_fun_idxs.get(&key).copied() {
            let is_available = defs_by_fun_idx.contains_key(&existing)
                || generated_defs
                    .iter()
                    .any(|def| Self::def_fun_idx(def) == Some(existing));
            if is_available {
                return Ok(existing);
            }
            // Persistent sessions can retain a specialization key after the
            // corresponding generated definition was discarded with an older
            // compilation unit.  Never emit a stale function index.
            specialization_fun_idxs.remove(&key);
        }

        let specialized_fun_idx = self.env.next_fun_idx;
        self.env.next_fun_idx += 1;
        specialization_fun_idxs.insert(key, specialized_fun_idx);

        let substituted_def = self.substitute_specialized_def(
            original_def.as_ref().clone(),
            specialized_fun_idx,
            mapping,
        )?;
        // Reserve the definition before rewriting its body. A specialization
        // can refer to itself while its body is being rewritten; without the
        // reservation that recursive lookup mistakes the fresh cache entry
        // for a stale persistent-session entry and allocates a second index.
        let generated_index = generated_defs.len();
        generated_defs.push(substituted_def.clone());
        let rewritten_def = self
            .rewrite_specializations_in_node(
                substituted_def,
                defs_by_fun_idx,
                bound_tyvars_by_fun_idx,
                needs_specialization,
                specialization_fun_idxs,
                generated_defs,
            )
            .map(|node| *node)
            .map_err(|error| *error)?;
        self.specializable_defs
            .insert(specialized_fun_idx, Arc::new(rewritten_def.clone()));
        generated_defs[generated_index] = rewritten_def;
        Ok(specialized_fun_idx)
    }

    fn specialization_key_for_def(
        &self,
        def: &TypedNode,
        concrete_tys: &[Ty],
        substitution: &CanonicalSubstitution,
    ) -> Result<CallableInstantiationKey, TypeError> {
        let callable = match &def.node {
            TypedInner::Def(_, id, ..) | TypedInner::ExtractorDef(_, id, ..) => {
                Some(MethodDeclarationId(id.unique_id))
            }
            _ => None,
        }
        .ok_or_else(|| TypeError {
            structured: None,
            message: "Expected def/extractor for specialization key".into(),
            span: def.span.clone(),
            hint: None,
        })?;
        let mut implementation = None;
        let mut trait_inputs = Vec::new();
        if let Some((info, method)) = self.trait_impls.values().find_map(|info| {
            info.methods
                .values()
                .find(|method| method.function_id.unique_id == callable.0)
                .map(|method| (info, method))
        }) {
            implementation = Some(self.trait_implementation_identity(info, method)?);
            let contract = method.instantiation_contract.as_ref().ok_or_else(|| {
                self.trait_dispatch_failure(
                    TypeDiagnosticReason::UnresolvedTraitMethodInstantiation,
                    &info.trait_id.name,
                    &method.function_id.name,
                    Some(&info.target_ty),
                    &def.span,
                )
            })?;
            let constructor_bounds = self.constructor_bounds_for_contract(contract);
            for entry in contract
                .head
                .entries
                .iter()
                .chain(&contract.signature.entries)
            {
                let ty = self.instantiate_contract_canonical_type(
                    &entry.ty,
                    substitution,
                    &constructor_bounds,
                )?;
                let ty = self.normalize_executable_contract_type(&entry.ty, ty)?;
                if ty.has_pending_instantiation() {
                    return Err(self.trait_dispatch_failure(
                        TypeDiagnosticReason::UnresolvedTraitMethodInstantiation,
                        &info.trait_id.name,
                        &method.function_id.name,
                        Some(&info.target_ty),
                        &def.span,
                    ));
                }
                trait_inputs.push((entry.role, entry.ordinal, ty));
            }
            trait_inputs.sort_by_key(|(role, ordinal, _)| (*role, *ordinal));
        }
        Ok(CallableInstantiationKey {
            callable,
            implementation,
            trait_inputs,
            type_args: concrete_tys
                .iter()
                .map(|ty| self.canonical_ty_key(ty))
                .collect(),
        })
    }

    pub(super) fn canonical_ty_key(&self, ty: &Ty) -> CanonicalTyKey {
        match self.resolve_ty(ty) {
            Ty::Int => CanonicalTyKey::Int,
            Ty::Float => CanonicalTyKey::Float,
            Ty::Str => CanonicalTyKey::String,
            Ty::Bool => CanonicalTyKey::Boolean,
            Ty::Unit => CanonicalTyKey::Unit,
            Ty::Error => CanonicalTyKey::Error,
            Ty::Hole => CanonicalTyKey::Hole,
            Ty::Var(var) => CanonicalTyKey::Var(var),
            Ty::SelfApp(args) => {
                CanonicalTyKey::SelfApp(args.iter().map(|arg| self.canonical_ty_key(arg)).collect())
            }
            Ty::ExtractorClosure(inner) => {
                CanonicalTyKey::ExtractorClosure(Box::new(self.canonical_ty_key(&inner)))
            }
            Ty::MatchResult(inner) => {
                CanonicalTyKey::MatchResult(Box::new(self.canonical_ty_key(&inner)))
            }
            Ty::List(inner) => CanonicalTyKey::List(Box::new(self.canonical_ty_key(&inner))),
            Ty::Tuple(items) => CanonicalTyKey::Tuple(
                items
                    .iter()
                    .map(|item| self.canonical_ty_key(item))
                    .collect(),
            ),
            Ty::Func(params, ret) => CanonicalTyKey::Func {
                params: params
                    .iter()
                    .map(|param| self.canonical_ty_key(param))
                    .collect(),
                ret: Box::new(self.canonical_ty_key(&ret)),
            },
            Ty::Lazy(inner) => CanonicalTyKey::Lazy(Box::new(self.canonical_ty_key(&inner))),
            Ty::Facet(kind, source, focus, update_source, update_focus) => CanonicalTyKey::Facet {
                kind,
                source: Box::new(self.canonical_ty_key(&source)),
                focus: Box::new(self.canonical_ty_key(&focus)),
                update_source: Box::new(self.canonical_ty_key(&update_source)),
                update_focus: Box::new(self.canonical_ty_key(&update_focus)),
            },
            Ty::Pid(marker) => CanonicalTyKey::Pid(Box::new(self.canonical_ty_key(&marker))),
            Ty::ProcessMarker(name) => CanonicalTyKey::ProcessMarker(name),
            Ty::BuiltinFunc { name, params, ret } => CanonicalTyKey::BuiltinFunc {
                name,
                params: params
                    .iter()
                    .map(|param| self.canonical_ty_key(param))
                    .collect(),
                ret: Box::new(self.canonical_ty_key(&ret)),
            },
            Ty::UserFunc {
                type_params,
                params,
                ret,
                ..
            } => CanonicalTyKey::UserFunc {
                type_params,
                params: params
                    .iter()
                    .map(|param| self.canonical_ty_key(param))
                    .collect(),
                ret: Box::new(self.canonical_ty_key(&ret)),
            },
            Ty::Struct(name, fields) => CanonicalTyKey::Struct {
                name: Self::canonical_specialization_name(&name),
                args: fields
                    .arguments
                    .iter()
                    .map(|argument| self.canonical_ty_key(argument))
                    .collect(),
                fields: self.canonical_field_keys(&fields),
            },
            Ty::Record(name, fields) => CanonicalTyKey::Record {
                name: Self::canonical_specialization_name(&name),
                args: fields
                    .arguments
                    .iter()
                    .map(|argument| self.canonical_ty_key(argument))
                    .collect(),
                fields: self.canonical_field_keys(&fields),
            },
            Ty::Enum(name, args) => CanonicalTyKey::Enum {
                name: Self::canonical_specialization_name(&name),
                args: args.iter().map(|arg| self.canonical_ty_key(arg)).collect(),
            },
            Ty::Result(ok, err) => CanonicalTyKey::Result {
                ok: Box::new(self.canonical_ty_key(&ok)),
                err: Box::new(self.canonical_ty_key(&err)),
            },
        }
    }

    fn canonical_field_keys(&self, fields: &[(String, Ty)]) -> Vec<(String, CanonicalTyKey)> {
        let mut fields = fields
            .iter()
            .map(|(name, ty)| (name.clone(), self.canonical_ty_key(ty)))
            .collect::<Vec<_>>();
        fields.sort_by(|(left, _), (right, _)| left.cmp(right));
        fields
    }

    fn canonical_specialization_name(name: &str) -> String {
        if name.starts_with('$') || name.contains("::") {
            name.to_string()
        } else {
            format!("Global::{name}")
        }
    }

    fn substitute_specialized_def(
        &self,
        def: TypedNode,
        specialized_fun_idx: u32,
        mapping: &HashMap<u32, Ty>,
    ) -> Result<TypedNode, TypeError> {
        let span = def.span.clone();
        let ty = self.substitute_ty_with_mapping(&def.ty, mapping);
        let node = match def.node {
            TypedInner::Def(
                _,
                id,
                _type_params,
                params,
                ret_ty,
                where_clause,
                body,
                visibility,
            ) => TypedInner::Def(
                specialized_fun_idx,
                id,
                Vec::new(),
                params
                    .into_iter()
                    .map(|param| TypedValueParameter {
                        id: param.id,
                        mode: param.mode,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                        span: param.span,
                    })
                    .collect(),
                self.substitute_ty_with_mapping(&ret_ty, mapping),
                where_clause,
                Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
                visibility,
            ),
            TypedInner::ExtractorDef(_, id, _type_params, param, ret_ty, body, visibility) => {
                TypedInner::ExtractorDef(
                    specialized_fun_idx,
                    id,
                    Vec::new(),
                    param
                        .into_iter()
                        .map(|param| TypedValueParameter {
                            id: param.id,
                            mode: param.mode,
                            ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                            span: param.span,
                        })
                        .collect(),
                    self.substitute_ty_with_mapping(&ret_ty, mapping),
                    Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
                    visibility,
                )
            }
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!("Expected def/extractor for specialization, got {:?}", other),
                    span,
                    hint: None,
                });
            }
        };
        Ok(TypedNode {
            ty,
            span: def.span,
            node,
        })
    }

    fn infer_specialization_mapping(
        &mut self,
        def: &TypedNode,
        args: &[TypedNode],
        instantiated_callable: Option<&Ty>,
        allow_omitted_args: bool,
        bound_tyvars: &[u32],
    ) -> Result<HashMap<u32, Ty>, TypeError> {
        let mut mapping = HashMap::new();
        if let Some(Ty::UserFunc {
            call_substitution, ..
        }) = instantiated_callable
        {
            if !call_substitution.is_empty() {
                for (var, ty) in call_substitution {
                    if bound_tyvars.contains(var) {
                        mapping.insert(*var, self.resolve_ty(ty));
                    }
                }
            }
        }
        let param_tys = match &def.node {
            TypedInner::Def(_, _, _, params, _, _, _, _) => params
                .iter()
                .map(|param| param.ty.clone())
                .collect::<Vec<_>>(),
            TypedInner::ExtractorDef(_, _, _, param, _, _, _) => {
                param.iter().map(|param| param.ty.clone()).collect()
            }
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!("Expected def/extractor for specialization, got {:?}", other),
                    span: def.span.clone(),
                    hint: None,
                });
            }
        };

        if param_tys.len() != args.len() && !(allow_omitted_args && args.is_empty()) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Cannot specialize call: expected {} argument(s), got {}",
                    param_tys.len(),
                    args.len()
                ),
                span: def.span.clone(),
                hint: None,
            });
        }

        if !matches!(instantiated_callable, Some(Ty::UserFunc { .. }))
            || bound_tyvars.iter().any(|var| !mapping.contains_key(var))
        {
            return Err(TypeError {
                structured: None,
                message: "Missing call substitution for ordinary specialization".into(),
                span: def.span.clone(),
                hint: None,
            });
        }
        Ok(mapping)
    }

    fn trait_specialization_arguments(
        &self,
        def: &TypedNode,
        bound_tyvars: &[u32],
        mapping: &HashMap<u32, Ty>,
    ) -> Result<Vec<Ty>, TypeError> {
        bound_tyvars
            .iter()
            .map(|var| {
                let concrete = mapping.get(var).map(|ty| self.resolve_ty(ty));
                if let Some(ty) = concrete {
                    let mut unresolved = Vec::new();
                    Self::collect_ty_vars(&ty, &mut unresolved);
                    if unresolved.is_empty() {
                        return Ok(ty);
                    }
                }
                Err(TypeError {
                    structured: None,
                    message: format!(
                        "Incomplete trait method substitution for specialization variable {}",
                        var
                    ),
                    span: def.span.clone(),
                    hint: None,
                })
            })
            .collect()
    }

    fn collect_bound_tyvars_for_def(
        &self,
        def: &TypedNode,
        trait_impl_method_uids: &HashSet<u32>,
    ) -> Vec<u32> {
        let mut ordered = Vec::new();
        let mut seen = HashSet::new();
        match &def.node {
            TypedInner::Def(_, id, return_type_arguments, params, ret_ty, _, _body, _) => {
                let is_trait_impl_method = trait_impl_method_uids.contains(&id.unique_id);
                for argument in return_type_arguments {
                    let mut declared = Vec::new();
                    Self::collect_ty_vars(&argument.ty, &mut declared);
                    for var in declared {
                        if seen.insert(var) {
                            ordered.push(var);
                        }
                    }
                }
                for param in params {
                    if is_trait_impl_method {
                        let mut declared = Vec::new();
                        Self::collect_ty_vars(&param.ty, &mut declared);
                        for var in declared {
                            if seen.insert(var) {
                                ordered.push(var);
                            }
                        }
                    } else {
                        self.collect_bound_tyvars_in_ty(&param.ty, &mut ordered, &mut seen);
                    }
                }
                if is_trait_impl_method {
                    let mut declared = Vec::new();
                    Self::collect_ty_vars(ret_ty, &mut declared);
                    for var in declared {
                        if seen.insert(var) {
                            ordered.push(var);
                        }
                    }
                } else {
                    self.collect_bound_tyvars_in_ty(ret_ty, &mut ordered, &mut seen);
                }
                let mut signature_vars = Vec::new();
                for argument in return_type_arguments {
                    Self::collect_ty_vars(&argument.ty, &mut signature_vars);
                }
                for param in params {
                    Self::collect_ty_vars(&param.ty, &mut signature_vars);
                }
                Self::collect_ty_vars(ret_ty, &mut signature_vars);
                let signature_vars = signature_vars.into_iter().collect::<HashSet<_>>();
                let already_bound = seen.clone();
                self.collect_pending_trait_receiver_tyvars_in_node(_body, &mut ordered, &mut seen);
                ordered.retain(|var| already_bound.contains(var) || signature_vars.contains(var));
                seen.retain(|var| already_bound.contains(var) || signature_vars.contains(var));
                // Function-local inference variables can carry trait bounds,
                // but callers cannot infer them from a call site. Only the
                // declared signature determines a valid specialization key.
            }
            TypedInner::ExtractorDef(_, _, type_params, param, ret_ty, _body, _) => {
                for type_param in type_params {
                    if type_param.bound.is_some() && seen.insert(type_param.ty_var) {
                        ordered.push(type_param.ty_var);
                    }
                }
                for param in param {
                    self.collect_bound_tyvars_in_ty(&param.ty, &mut ordered, &mut seen);
                }
                self.collect_bound_tyvars_in_ty(ret_ty, &mut ordered, &mut seen);
                let mut signature_vars = type_params
                    .iter()
                    .map(|type_param| type_param.ty_var)
                    .collect::<Vec<_>>();
                for param in param {
                    Self::collect_ty_vars(&param.ty, &mut signature_vars);
                }
                Self::collect_ty_vars(ret_ty, &mut signature_vars);
                let signature_vars = signature_vars.into_iter().collect::<HashSet<_>>();
                let already_bound = seen.clone();
                self.collect_pending_trait_receiver_tyvars_in_node(_body, &mut ordered, &mut seen);
                ordered.retain(|var| already_bound.contains(var) || signature_vars.contains(var));
                seen.retain(|var| already_bound.contains(var) || signature_vars.contains(var));
                // See `Def` above: exclude function-local inference variables.
            }
            _ => {}
        }
        ordered
    }

    /// A generic trait instance may be pending in a definition body even when
    /// the current surface syntax cannot express that fully-instantiated
    /// bound in the enclosing signature. It still has to participate in the
    /// definition's specialization key, otherwise Forge sees a Pending call.
    fn collect_pending_trait_receiver_tyvars_in_node(
        &self,
        node: &TypedNode,
        ordered: &mut Vec<u32>,
        seen: &mut HashSet<u32>,
    ) {
        if let Some(call) = node.monad_fail_call() {
            self.collect_pending_trait_receiver_tyvars_in_node(call, ordered, seen);
        }
        for expr in Self::pattern_expression_nodes(node) {
            self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
        }
        match &node.node {
            TypedInner::TraitCall {
                dispatch,
                receiver_ty,
                obligation,
                args,
                ..
            } => {
                let mut vars = Vec::new();
                match dispatch {
                    TraitDispatch::Pending => {
                        Self::collect_ty_vars(receiver_ty, &mut vars);
                        Self::collect_ty_vars(&obligation.receiver, &mut vars);
                        for ty in &obligation.trait_args {
                            Self::collect_ty_vars(ty, &mut vars);
                        }
                        for arg in args {
                            Self::collect_ty_vars(&arg.ty, &mut vars);
                        }
                        Self::collect_ty_vars(&node.ty, &mut vars);
                    }
                    TraitDispatch::Selected(instantiation) => {
                        Self::collect_ty_vars(receiver_ty, &mut vars);
                        for ty in instantiation
                            .substitution
                            .values()
                            .chain(instantiation.caller_substitution.values())
                        {
                            Self::collect_ty_vars(ty, &mut vars);
                        }
                        let signature = &instantiation.callable_signature;
                        for ty in signature
                            .return_type_arguments
                            .iter()
                            .map(|argument| &argument.ty)
                            .chain(
                                signature
                                    .value_parameters
                                    .iter()
                                    .map(|parameter| &parameter.ty),
                            )
                            .chain(std::iter::once(&signature.return_type.ty))
                            .chain(
                                signature
                                    .where_constraints
                                    .constraints
                                    .iter()
                                    .map(|constraint| &constraint.subject),
                            )
                        {
                            Self::collect_canonical_tyvars(ty, &mut vars);
                        }
                    }
                    TraitDispatch::Static(_) => {}
                }
                for var in vars {
                    if seen.insert(var) {
                        ordered.push(var);
                    }
                }
                for arg in args {
                    self.collect_pending_trait_receiver_tyvars_in_node(arg, ordered, seen);
                }
            }
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => {
                self.collect_pending_trait_receiver_tyvars_in_node(message, ordered, seen);
                for value in payload {
                    self.collect_pending_trait_receiver_tyvars_in_node(value, ordered, seen);
                }
            }
            TypedInner::ListLiteral(args) | TypedInner::TupleLiteral(args) => {
                for arg in args {
                    self.collect_pending_trait_receiver_tyvars_in_node(arg, ordered, seen);
                }
            }
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                self.collect_pending_trait_receiver_tyvars_in_node(func, ordered, seen);
                for arg in args {
                    self.collect_pending_trait_receiver_tyvars_in_node(arg, ordered, seen);
                }
            }
            TypedInner::Block(stmts) => {
                for stmt in stmts {
                    self.collect_pending_trait_receiver_tyvars_in_node(stmt, ordered, seen);
                }
            }
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs) => {
                self.collect_pending_trait_receiver_tyvars_in_node(rhs, ordered, seen)
            }
            TypedInner::DoSafeBind(control) => {
                self.collect_pending_trait_receiver_tyvars_in_node(&control.rhs, ordered, seen);
                match &control.failure_target {
                    SafeBindFailureTarget::DoAlternative { empty } => {
                        self.collect_pending_trait_receiver_tyvars_in_node(empty, ordered, seen);
                    }
                    SafeBindFailureTarget::Deferred(deferred) => {
                        let mut vars = Vec::new();
                        Self::collect_ty_vars(&deferred.carrier_ty, &mut vars);
                        for error_ty in &deferred.propagated_error_tys {
                            Self::collect_ty_vars(error_ty, &mut vars);
                        }
                        for var in vars {
                            if seen.insert(var) {
                                ordered.push(var);
                            }
                        }
                    }
                    _ => {}
                }
                self.collect_pending_trait_receiver_tyvars_in_node(
                    &control.continuation,
                    ordered,
                    seen,
                );
            }
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right) => {
                self.collect_pending_trait_receiver_tyvars_in_node(left, ordered, seen);
                self.collect_pending_trait_receiver_tyvars_in_node(right, ordered, seen);
            }
            TypedInner::HashMapLiteral(entries) => {
                for (key, value) in entries {
                    self.collect_pending_trait_receiver_tyvars_in_node(key, ordered, seen);
                    self.collect_pending_trait_receiver_tyvars_in_node(value, ordered, seen);
                }
            }
            TypedInner::InterpolatedStr(parts) => {
                for part in parts {
                    if let TypedInterpolatedPart::Expr(expr) = part {
                        self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                    }
                }
            }
            TypedInner::Dbg(args) => {
                for arg in args {
                    self.collect_pending_trait_receiver_tyvars_in_node(&arg.expr, ordered, seen);
                }
            }
            TypedInner::EagerBoundary(inner)
            | TypedInner::FieldAccess(inner, _)
            | TypedInner::SupervisorSpawn { init: inner, .. }
            | TypedInner::SupervisorAdopt { pid: inner, .. } => {
                self.collect_pending_trait_receiver_tyvars_in_node(inner, ordered, seen)
            }
            TypedInner::If(cond, then_branch, else_branch) => {
                self.collect_pending_trait_receiver_tyvars_in_node(cond, ordered, seen);
                self.collect_pending_trait_receiver_tyvars_in_node(then_branch, ordered, seen);
                if let Some(branch) = else_branch {
                    self.collect_pending_trait_receiver_tyvars_in_node(branch, ordered, seen);
                }
            }
            TypedInner::Cause(value, err) => {
                self.collect_pending_trait_receiver_tyvars_in_node(value, ordered, seen);
                self.collect_pending_trait_receiver_tyvars_in_node(err, ordered, seen);
            }
            TypedInner::Match(scrutinee, arms) => {
                self.collect_pending_trait_receiver_tyvars_in_node(scrutinee, ordered, seen);
                for arm in arms {
                    if let Some(guard) = &arm.guard {
                        self.collect_pending_trait_receiver_tyvars_in_node(guard, ordered, seen);
                    }
                    self.collect_pending_trait_receiver_tyvars_in_node(&arm.body, ordered, seen);
                }
            }
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                self.collect_pending_trait_receiver_tyvars_in_node(init, ordered, seen);
                self.collect_pending_trait_receiver_tyvars_in_node(strategy, ordered, seen);
            }
            TypedInner::FacetPath(path) => {
                for expr in Self::typed_facet_path_expression_nodes(path) {
                    self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                }
            }
            TypedInner::PendingFacetPath(path) => {
                for expr in Self::pending_facet_path_expression_nodes(path) {
                    self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                }
            }
            TypedInner::FacetView { source, path, .. } => {
                self.collect_pending_trait_receiver_tyvars_in_node(source, ordered, seen);
                for expr in Self::typed_facet_path_expression_nodes(path) {
                    self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                }
            }
            TypedInner::FacetSet {
                source,
                path,
                value,
                ..
            } => {
                self.collect_pending_trait_receiver_tyvars_in_node(source, ordered, seen);
                for expr in Self::typed_facet_path_expression_nodes(path) {
                    self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                }
                self.collect_pending_trait_receiver_tyvars_in_node(value, ordered, seen);
            }
            TypedInner::FacetOver {
                source,
                path,
                update_fun,
                ..
            } => {
                self.collect_pending_trait_receiver_tyvars_in_node(source, ordered, seen);
                for expr in Self::typed_facet_path_expression_nodes(path) {
                    self.collect_pending_trait_receiver_tyvars_in_node(expr, ordered, seen);
                }
                self.collect_pending_trait_receiver_tyvars_in_node(update_fun, ordered, seen);
            }
            TypedInner::StructLit(_, fields) | TypedInner::ConstructorCall(_, fields) => {
                for field in fields {
                    self.collect_pending_trait_receiver_tyvars_in_node(field, ordered, seen);
                }
            }
            TypedInner::DeferrorDef(_, _, _, _, show) => {
                self.collect_pending_trait_receiver_tyvars_in_node(show, ordered, seen)
            }
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body) => {
                self.collect_pending_trait_receiver_tyvars_in_node(body, ordered, seen)
            }
            TypedInner::CaptureConstructorClosure(_, _, _, body) => {
                self.collect_pending_trait_receiver_tyvars_in_node(body, ordered, seen)
            }
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::SupervisorStatus { .. }
            | TypedInner::ProcessContextHandler { .. } => {}
        }
    }

    fn collect_canonical_tyvars(ty: &CanonicalTy, out: &mut Vec<u32>) {
        if let CanonicalTypeHead::Variable(var) = ty.head {
            if !out.contains(&var) {
                out.push(var);
            }
        }
        for argument in &ty.arguments {
            Self::collect_canonical_tyvars(argument, out);
        }
    }

    #[allow(dead_code)]
    fn collect_bound_tyvars_in_node(
        &self,
        node: &TypedNode,
        ordered: &mut Vec<u32>,
        seen: &mut HashSet<u32>,
    ) {
        if let Some(call) = node.monad_fail_call() {
            self.collect_bound_tyvars_in_node(call, ordered, seen);
        }
        for expr in Self::pattern_expression_nodes(node) {
            self.collect_bound_tyvars_in_node(expr, ordered, seen);
        }
        self.collect_bound_tyvars_in_ty(&node.ty, ordered, seen);
        match &node.node {
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                self.collect_bound_tyvars_in_node(func, ordered, seen);
                for arg in args {
                    self.collect_bound_tyvars_in_node(arg, ordered, seen);
                }
            }
            TypedInner::TraitCall { args, .. } => {
                for arg in args {
                    self.collect_bound_tyvars_in_node(arg, ordered, seen);
                }
            }
            TypedInner::Block(stmts) => {
                for stmt in stmts {
                    self.collect_bound_tyvars_in_node(stmt, ordered, seen);
                }
            }
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs) => self.collect_bound_tyvars_in_node(rhs, ordered, seen),
            TypedInner::DoSafeBind(control) => {
                self.collect_bound_tyvars_in_node(&control.rhs, ordered, seen);
                if let SafeBindFailureTarget::DoAlternative { empty } = &control.failure_target {
                    self.collect_bound_tyvars_in_node(empty, ordered, seen);
                }
                self.collect_bound_tyvars_in_node(&control.continuation, ordered, seen);
            }
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right) => {
                self.collect_bound_tyvars_in_node(left, ordered, seen);
                self.collect_bound_tyvars_in_node(right, ordered, seen);
            }
            TypedInner::ListCons(head, tail) => {
                self.collect_bound_tyvars_in_node(head, ordered, seen);
                self.collect_bound_tyvars_in_node(tail, ordered, seen);
            }
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => {
                self.collect_bound_tyvars_in_node(message, ordered, seen);
                for value in payload {
                    self.collect_bound_tyvars_in_node(value, ordered, seen);
                }
            }
            TypedInner::ListLiteral(items) | TypedInner::TupleLiteral(items) => {
                for item in items {
                    self.collect_bound_tyvars_in_node(item, ordered, seen);
                }
            }
            TypedInner::HashMapLiteral(entries) => {
                for (key, value) in entries {
                    self.collect_bound_tyvars_in_node(key, ordered, seen);
                    self.collect_bound_tyvars_in_node(value, ordered, seen);
                }
            }
            TypedInner::InterpolatedStr(parts) => {
                for part in parts {
                    if let TypedInterpolatedPart::Expr(expr) = part {
                        self.collect_bound_tyvars_in_node(expr, ordered, seen);
                    }
                }
            }
            TypedInner::Dbg(args) => {
                for arg in args {
                    self.collect_bound_tyvars_in_node(&arg.expr, ordered, seen);
                }
            }
            TypedInner::EagerBoundary(inner) => {
                self.collect_bound_tyvars_in_node(inner, ordered, seen)
            }
            TypedInner::If(cond, then_branch, else_branch) => {
                self.collect_bound_tyvars_in_node(cond, ordered, seen);
                self.collect_bound_tyvars_in_node(then_branch, ordered, seen);
                if let Some(else_branch) = else_branch {
                    self.collect_bound_tyvars_in_node(else_branch, ordered, seen);
                }
            }
            TypedInner::Cause(value, err) => {
                self.collect_bound_tyvars_in_node(value, ordered, seen);
                self.collect_bound_tyvars_in_node(err, ordered, seen);
            }
            TypedInner::Match(scrutinee, arms) => {
                self.collect_bound_tyvars_in_node(scrutinee, ordered, seen);
                for arm in arms {
                    if let Some(guard) = &arm.guard {
                        self.collect_bound_tyvars_in_node(guard, ordered, seen);
                    }
                    self.collect_bound_tyvars_in_node(&arm.body, ordered, seen);
                }
            }
            TypedInner::FieldAccess(expr, _) => {
                self.collect_bound_tyvars_in_node(expr, ordered, seen);
            }
            TypedInner::ProcessContextHandler { .. } => {}
            TypedInner::SupervisorSpawn { init, .. } => {
                self.collect_bound_tyvars_in_node(init, ordered, seen);
            }
            TypedInner::SupervisorAdopt { pid, .. } => {
                self.collect_bound_tyvars_in_node(pid, ordered, seen);
            }
            TypedInner::SupervisorStatus { .. } => {}
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                self.collect_bound_tyvars_in_node(init, ordered, seen);
                self.collect_bound_tyvars_in_node(strategy, ordered, seen);
            }
            TypedInner::FacetPath(path) => {
                self.collect_bound_tyvars_in_ty(&path.source_ty, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.focus_ty, ordered, seen);
            }
            TypedInner::PendingFacetPath(path) => {
                if let Some(source_ty_hint) = &path.source_ty_hint {
                    self.collect_bound_tyvars_in_ty(source_ty_hint, ordered, seen);
                }
            }
            TypedInner::FacetView { source, path, .. } => {
                self.collect_bound_tyvars_in_node(source, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.source_ty, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.focus_ty, ordered, seen);
            }
            TypedInner::FacetSet {
                source,
                path,
                value,
                ..
            } => {
                self.collect_bound_tyvars_in_node(source, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.source_ty, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.focus_ty, ordered, seen);
                self.collect_bound_tyvars_in_node(value, ordered, seen);
            }
            TypedInner::FacetOver {
                source,
                path,
                update_fun,
                ..
            } => {
                self.collect_bound_tyvars_in_node(source, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.source_ty, ordered, seen);
                self.collect_bound_tyvars_in_ty(&path.focus_ty, ordered, seen);
                self.collect_bound_tyvars_in_node(update_fun, ordered, seen);
            }
            TypedInner::StructLit(_, fields) | TypedInner::ConstructorCall(_, fields) => {
                for field in fields {
                    self.collect_bound_tyvars_in_node(field, ordered, seen);
                }
            }
            TypedInner::DeferrorDef(_, _, _, _, show) => {
                self.collect_bound_tyvars_in_node(show, ordered, seen);
            }
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body) => {
                self.collect_bound_tyvars_in_node(body, ordered, seen);
            }
            TypedInner::CaptureConstructorClosure(_, _, _, body) => {
                self.collect_bound_tyvars_in_node(body, ordered, seen);
            }
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..) => {}
        }
    }

    fn collect_bound_tyvars_in_ty(&self, ty: &Ty, ordered: &mut Vec<u32>, seen: &mut HashSet<u32>) {
        match self.resolve_ty(ty) {
            Ty::Var(var) => {
                if !self.tyvar_bound_names(var).is_empty() && seen.insert(var) {
                    ordered.push(var);
                }
            }
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => self.collect_bound_tyvars_in_ty(&inner, ordered, seen),
            Ty::Facet(_, source, focus, update_source, update_focus) => {
                self.collect_bound_tyvars_in_ty(&source, ordered, seen);
                self.collect_bound_tyvars_in_ty(&focus, ordered, seen);
                self.collect_bound_tyvars_in_ty(&update_source, ordered, seen);
                self.collect_bound_tyvars_in_ty(&update_focus, ordered, seen);
            }
            Ty::Tuple(items) => {
                for item in items {
                    self.collect_bound_tyvars_in_ty(&item, ordered, seen);
                }
            }
            Ty::SelfApp(items) => {
                if let Some((witness, slots)) = Self::constructor_application_parts(&items) {
                    if let Ty::Var(var) = self.resolve_ty(witness) {
                        if seen.insert(var) {
                            ordered.push(var);
                        }
                    }
                    for slot in slots {
                        self.collect_bound_tyvars_in_ty(slot, ordered, seen);
                    }
                } else {
                    for item in items {
                        self.collect_bound_tyvars_in_ty(&item, ordered, seen);
                    }
                }
            }
            Ty::Func(params, ret) => {
                for param in params {
                    self.collect_bound_tyvars_in_ty(&param, ordered, seen);
                }
                self.collect_bound_tyvars_in_ty(&ret, ordered, seen);
            }
            Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                for param in params {
                    self.collect_bound_tyvars_in_ty(&param, ordered, seen);
                }
                self.collect_bound_tyvars_in_ty(&ret, ordered, seen);
            }
            Ty::Result(ok, err) => {
                self.collect_bound_tyvars_in_ty(&ok, ordered, seen);
                self.collect_bound_tyvars_in_ty(&err, ordered, seen);
            }
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                for argument in &nominal.arguments {
                    self.collect_bound_tyvars_in_ty(argument, ordered, seen);
                }
                for (_, field_ty) in nominal {
                    self.collect_bound_tyvars_in_ty(&field_ty, ordered, seen);
                }
            }
            Ty::Enum(_, args) => {
                for arg in args {
                    self.collect_bound_tyvars_in_ty(&arg, ordered, seen);
                }
            }
            Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::Hole
            | Ty::ProcessMarker(_) => {}
        }
    }

    fn substitute_typed_node_with_mapping(
        &self,
        node: TypedNode,
        mapping: &HashMap<u32, Ty>,
    ) -> TypedNode {
        let span = node.span.clone();
        let ty = self.substitute_ty_with_mapping(&node.ty, mapping);
        let node = match node.node {
            TypedInner::Lit(lit) => TypedInner::Lit(lit),
            TypedInner::ErrorKind(kind) => TypedInner::ErrorKind(kind),
            TypedInner::Var(id) => TypedInner::Var(id),
            TypedInner::SupervisorSpawn {
                supervisor_process,
                worker_process,
                init,
            } => TypedInner::SupervisorSpawn {
                supervisor_process,
                worker_process,
                init: Box::new(self.substitute_typed_node_with_mapping(*init, mapping)),
            },
            TypedInner::SupervisorAdopt {
                supervisor_process,
                worker_process,
                pid,
            } => TypedInner::SupervisorAdopt {
                supervisor_process,
                worker_process,
                pid: Box::new(self.substitute_typed_node_with_mapping(*pid, mapping)),
            },
            TypedInner::SupervisorStatus { supervisor_process } => {
                TypedInner::SupervisorStatus { supervisor_process }
            }
            TypedInner::SupervisorWorkers {
                supervisor_process,
                worker_process,
                init,
                strategy,
            } => TypedInner::SupervisorWorkers {
                supervisor_process,
                worker_process,
                init: Box::new(self.substitute_typed_node_with_mapping(*init, mapping)),
                strategy: Box::new(self.substitute_typed_node_with_mapping(*strategy, mapping)),
            },
            TypedInner::App(func, args) => TypedInner::App(
                Box::new(self.substitute_typed_node_with_mapping(*func, mapping)),
                args.into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
            ),
            TypedInner::TraitCall {
                trait_name,
                method_name,
                receiver_ty,
                obligation,
                dispatch,
                origin,
                args,
            } => TypedInner::TraitCall {
                trait_name,
                method_name,
                receiver_ty: self.substitute_ty_with_mapping(&receiver_ty, mapping),
                obligation: TraitObligation {
                    trait_id: obligation.trait_id,
                    trait_args: obligation
                        .trait_args
                        .iter()
                        .map(|arg| self.substitute_ty_with_mapping(arg, mapping))
                        .collect(),
                    receiver: self.substitute_ty_with_mapping(&obligation.receiver, mapping),
                },
                dispatch: self.substitute_selected_dispatch(dispatch, mapping),
                origin: self.substitute_trait_call_origin_with_mapping(origin, mapping),
                args: args
                    .into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
            },
            TypedInner::InjectCall(func, args) => TypedInner::InjectCall(
                Box::new(self.substitute_typed_node_with_mapping(*func, mapping)),
                args.into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
            ),
            TypedInner::Block(stmts) => TypedInner::Block(
                stmts
                    .into_iter()
                    .map(|stmt| self.substitute_typed_node_with_mapping(stmt, mapping))
                    .collect(),
            ),
            TypedInner::Bind(pattern, rhs) => TypedInner::Bind(
                self.substitute_typed_pattern_with_mapping(pattern, mapping),
                Box::new(self.substitute_typed_node_with_mapping(*rhs, mapping)),
            ),
            TypedInner::ApplyPattern {
                value,
                pattern,
                projections,
            } => TypedInner::ApplyPattern {
                value: Box::new(self.substitute_typed_node_with_mapping(*value, mapping)),
                pattern: self.substitute_typed_pattern_with_mapping(pattern, mapping),
                projections: projections
                    .into_iter()
                    .map(|(id, ty)| (id, self.substitute_ty_with_mapping(&ty, mapping)))
                    .collect(),
            },
            TypedInner::SafeBind(pattern, rhs, projection, failure_target) => TypedInner::SafeBind(
                self.substitute_typed_pattern_with_mapping(pattern, mapping),
                Box::new(self.substitute_typed_node_with_mapping(*rhs, mapping)),
                match projection {
                    SafeBindRhsProjection::CanonicalResultOnce {
                        payload_ty,
                        error_ty,
                    } => SafeBindRhsProjection::CanonicalResultOnce {
                        payload_ty: self.substitute_ty_with_mapping(&payload_ty, mapping),
                        error_ty: self.substitute_ty_with_mapping(&error_ty, mapping),
                    },
                    SafeBindRhsProjection::PatternInput { pattern_input_ty } => {
                        SafeBindRhsProjection::PatternInput {
                            pattern_input_ty: self
                                .substitute_ty_with_mapping(&pattern_input_ty, mapping),
                        }
                    }
                },
                match failure_target {
                    SafeBindFailureTarget::EnclosingMonadFail(mut target) => {
                        target.carrier_ty =
                            self.substitute_ty_with_mapping(&target.carrier_ty, mapping);
                        target.call = Box::new(
                            self.substitute_typed_node_with_mapping(*target.call, mapping),
                        );
                        SafeBindFailureTarget::EnclosingMonadFail(target)
                    }
                    SafeBindFailureTarget::EnclosingMatchResultContext { err_tag } => {
                        SafeBindFailureTarget::EnclosingMatchResultContext { err_tag }
                    }
                    SafeBindFailureTarget::TopLevel => SafeBindFailureTarget::TopLevel,
                    SafeBindFailureTarget::DoMonadFail(mut target) => {
                        target.carrier_ty =
                            self.substitute_ty_with_mapping(&target.carrier_ty, mapping);
                        target.call = Box::new(
                            self.substitute_typed_node_with_mapping(*target.call, mapping),
                        );
                        SafeBindFailureTarget::DoMonadFail(target)
                    }
                    SafeBindFailureTarget::DoAlternative { empty } => {
                        SafeBindFailureTarget::DoAlternative {
                            empty: Box::new(
                                self.substitute_typed_node_with_mapping(*empty, mapping),
                            ),
                        }
                    }
                    SafeBindFailureTarget::Deferred(mut deferred) => {
                        deferred.carrier_ty =
                            self.substitute_ty_with_mapping(&deferred.carrier_ty, mapping);
                        deferred.propagated_error_tys = deferred
                            .propagated_error_tys
                            .iter()
                            .map(|ty| self.substitute_ty_with_mapping(ty, mapping))
                            .collect();
                        SafeBindFailureTarget::Deferred(deferred)
                    }
                },
            ),
            TypedInner::DoSafeBind(control) => {
                let TypedDoSafeBind {
                    pattern,
                    rhs,
                    projection,
                    failure_target,
                    continuation,
                    origins,
                } = *control;
                TypedInner::DoSafeBind(Box::new(TypedDoSafeBind {
                    pattern: self.substitute_typed_pattern_with_mapping(pattern, mapping),
                    rhs: Box::new(self.substitute_typed_node_with_mapping(*rhs, mapping)),
                    projection: match projection {
                        SafeBindRhsProjection::CanonicalResultOnce {
                            payload_ty,
                            error_ty,
                        } => SafeBindRhsProjection::CanonicalResultOnce {
                            payload_ty: self.substitute_ty_with_mapping(&payload_ty, mapping),
                            error_ty: self.substitute_ty_with_mapping(&error_ty, mapping),
                        },
                        SafeBindRhsProjection::PatternInput { pattern_input_ty } => {
                            SafeBindRhsProjection::PatternInput {
                                pattern_input_ty: self
                                    .substitute_ty_with_mapping(&pattern_input_ty, mapping),
                            }
                        }
                    },
                    failure_target: match failure_target {
                        SafeBindFailureTarget::DoMonadFail(mut target) => {
                            target.carrier_ty =
                                self.substitute_ty_with_mapping(&target.carrier_ty, mapping);
                            target.call = Box::new(
                                self.substitute_typed_node_with_mapping(*target.call, mapping),
                            );
                            SafeBindFailureTarget::DoMonadFail(target)
                        }
                        SafeBindFailureTarget::DoAlternative { empty } => {
                            SafeBindFailureTarget::DoAlternative {
                                empty: Box::new(
                                    self.substitute_typed_node_with_mapping(*empty, mapping),
                                ),
                            }
                        }
                        SafeBindFailureTarget::Deferred(mut deferred) => {
                            deferred.carrier_ty =
                                self.substitute_ty_with_mapping(&deferred.carrier_ty, mapping);
                            deferred.propagated_error_tys = deferred
                                .propagated_error_tys
                                .iter()
                                .map(|ty| self.substitute_ty_with_mapping(ty, mapping))
                                .collect();
                            SafeBindFailureTarget::Deferred(deferred)
                        }
                        other => other,
                    },
                    continuation: Box::new(
                        self.substitute_typed_node_with_mapping(*continuation, mapping),
                    ),
                    origins,
                }))
            }
            TypedInner::BinOp(op, left, right) => TypedInner::BinOp(
                op,
                Box::new(self.substitute_typed_node_with_mapping(*left, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*right, mapping)),
            ),
            TypedInner::Pipe(left, right) => TypedInner::Pipe(
                Box::new(self.substitute_typed_node_with_mapping(*left, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*right, mapping)),
            ),
            TypedInner::Compose(flavor, left, right) => TypedInner::Compose(
                flavor,
                Box::new(self.substitute_typed_node_with_mapping(*left, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*right, mapping)),
            ),
            TypedInner::ListNil => TypedInner::ListNil,
            TypedInner::ListCons(head, tail) => TypedInner::ListCons(
                Box::new(self.substitute_typed_node_with_mapping(*head, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*tail, mapping)),
            ),
            TypedInner::ListLiteral(items) => TypedInner::ListLiteral(
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_node_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedInner::HashMapLiteral(entries) => TypedInner::HashMapLiteral(
                entries
                    .into_iter()
                    .map(|(key, value)| {
                        (
                            self.substitute_typed_node_with_mapping(key, mapping),
                            self.substitute_typed_node_with_mapping(value, mapping),
                        )
                    })
                    .collect(),
            ),
            TypedInner::ErrorConstruct {
                kind,
                message,
                payload,
                payload_fields,
            } => TypedInner::ErrorConstruct {
                kind,
                message: Box::new(self.substitute_typed_node_with_mapping(*message, mapping)),
                payload: payload
                    .into_iter()
                    .map(|value| self.substitute_typed_node_with_mapping(value, mapping))
                    .collect(),
                payload_fields: payload_fields
                    .into_iter()
                    .map(|(name, ty)| (name, self.substitute_ty_with_mapping(&ty, mapping)))
                    .collect(),
            },
            TypedInner::TupleLiteral(items) => TypedInner::TupleLiteral(
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_node_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedInner::InterpolatedStr(parts) => TypedInner::InterpolatedStr(
                parts
                    .into_iter()
                    .map(|part| match part {
                        TypedInterpolatedPart::Text(text) => TypedInterpolatedPart::Text(text),
                        TypedInterpolatedPart::Expr(expr) => TypedInterpolatedPart::Expr(Box::new(
                            self.substitute_typed_node_with_mapping(*expr, mapping),
                        )),
                    })
                    .collect(),
            ),
            TypedInner::Dbg(args) => TypedInner::Dbg(
                args.into_iter()
                    .map(|arg| TypedDbgArg {
                        span: arg.span,
                        ty_name: arg.ty_name,
                        expr: self.substitute_typed_node_with_mapping(arg.expr, mapping),
                    })
                    .collect(),
            ),
            TypedInner::EagerBoundary(inner) => TypedInner::EagerBoundary(Box::new(
                self.substitute_typed_node_with_mapping(*inner, mapping),
            )),
            TypedInner::If(cond, then_branch, else_branch) => TypedInner::If(
                Box::new(self.substitute_typed_node_with_mapping(*cond, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*then_branch, mapping)),
                else_branch.map(|branch| {
                    Box::new(self.substitute_typed_node_with_mapping(*branch, mapping))
                }),
            ),
            TypedInner::Cause(value, err) => TypedInner::Cause(
                Box::new(self.substitute_typed_node_with_mapping(*value, mapping)),
                Box::new(self.substitute_typed_node_with_mapping(*err, mapping)),
            ),
            TypedInner::Match(scrutinee, arms) => TypedInner::Match(
                Box::new(self.substitute_typed_node_with_mapping(*scrutinee, mapping)),
                arms.into_iter()
                    .map(|arm| TypedMatchArm {
                        direct_expression: arm.direct_expression,
                        pattern: self
                            .substitute_typed_match_pattern_with_mapping(arm.pattern, mapping),
                        guard: arm
                            .guard
                            .map(|guard| self.substitute_typed_node_with_mapping(guard, mapping)),
                        body: self.substitute_typed_node_with_mapping(arm.body, mapping),
                    })
                    .collect(),
            ),
            TypedInner::FieldAccess(expr, index) => TypedInner::FieldAccess(
                Box::new(self.substitute_typed_node_with_mapping(*expr, mapping)),
                index,
            ),
            TypedInner::ProcessContextHandler { process_name, slot } => {
                TypedInner::ProcessContextHandler { process_name, slot }
            }
            TypedInner::FacetPath(path) => {
                TypedInner::FacetPath(self.substitute_typed_facet_path_with_mapping(path, mapping))
            }
            TypedInner::PendingFacetPath(path) => TypedInner::PendingFacetPath(
                self.substitute_pending_facet_path_with_mapping(path, mapping),
            ),
            TypedInner::FacetView {
                api,
                source,
                path,
                source_is_result,
            } => TypedInner::FacetView {
                api,
                source: Box::new(self.substitute_typed_node_with_mapping(*source, mapping)),
                path: self.substitute_typed_facet_path_with_mapping(path, mapping),
                source_is_result,
            },
            TypedInner::FacetSet {
                api,
                source,
                path,
                value,
                source_is_result,
                mode,
            } => TypedInner::FacetSet {
                api,
                source: Box::new(self.substitute_typed_node_with_mapping(*source, mapping)),
                path: self.substitute_typed_facet_path_with_mapping(path, mapping),
                value: Box::new(self.substitute_typed_node_with_mapping(*value, mapping)),
                source_is_result,
                mode,
            },
            TypedInner::FacetOver {
                api,
                source,
                path,
                update_fun,
                source_is_result,
                mode,
            } => TypedInner::FacetOver {
                api,
                source: Box::new(self.substitute_typed_node_with_mapping(*source, mapping)),
                path: self.substitute_typed_facet_path_with_mapping(path, mapping),
                update_fun: Box::new(self.substitute_typed_node_with_mapping(*update_fun, mapping)),
                source_is_result,
                mode,
            },
            TypedInner::StructLit(tag, fields) => TypedInner::StructLit(
                tag,
                fields
                    .into_iter()
                    .map(|field| self.substitute_typed_node_with_mapping(field, mapping))
                    .collect(),
            ),
            TypedInner::ConstructorCall(tag, fields) => TypedInner::ConstructorCall(
                tag,
                fields
                    .into_iter()
                    .map(|field| self.substitute_typed_node_with_mapping(field, mapping))
                    .collect(),
            ),
            TypedInner::DeferrorDef(tag, binding, id, params, show) => TypedInner::DeferrorDef(
                tag,
                binding,
                id,
                params
                    .into_iter()
                    .map(|param| TypedValueParameter {
                        id: param.id,
                        mode: param.mode,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                        span: param.span,
                    })
                    .collect(),
                Box::new(self.substitute_typed_node_with_mapping(*show, mapping)),
            ),
            TypedInner::Def(
                fun_idx,
                id,
                type_params,
                params,
                ret_ty,
                where_clause,
                body,
                visibility,
            ) => TypedInner::Def(
                fun_idx,
                id,
                type_params
                    .into_iter()
                    .map(|argument| TypedReturnTypeArgument {
                        ordinal: argument.ordinal,
                        ty: self.substitute_ty_with_mapping(&argument.ty, mapping),
                        span: argument.span,
                    })
                    .collect(),
                params
                    .into_iter()
                    .map(|param| TypedValueParameter {
                        id: param.id,
                        mode: param.mode,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                        span: param.span,
                    })
                    .collect(),
                self.substitute_ty_with_mapping(&ret_ty, mapping),
                where_clause,
                Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
                visibility,
            ),
            TypedInner::ExtractorDef(fun_idx, id, type_params, param, ret_ty, body, visibility) => {
                TypedInner::ExtractorDef(
                    fun_idx,
                    id,
                    type_params
                        .into_iter()
                        .map(|typed_param| TypedTypeParam {
                            name: typed_param.name,
                            ty_var: typed_param.ty_var,
                            bound: typed_param.bound,
                        })
                        .collect(),
                    param
                        .into_iter()
                        .map(|param| TypedValueParameter {
                            id: param.id,
                            mode: param.mode,
                            ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                            span: param.span,
                        })
                        .collect(),
                    self.substitute_ty_with_mapping(&ret_ty, mapping),
                    Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
                    visibility,
                )
            }
            TypedInner::BuiltinExtractorDecl(id, param_ty, ret_ty) => {
                TypedInner::BuiltinExtractorDecl(
                    id,
                    param_ty
                        .iter()
                        .map(|ty| self.substitute_ty_with_mapping(ty, mapping))
                        .collect(),
                    self.substitute_ty_with_mapping(&ret_ty, mapping),
                )
            }
            TypedInner::Closure(params, captures, body) => TypedInner::Closure(
                params
                    .into_iter()
                    .map(|param| TypedClosureParam {
                        id: param.id,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                    })
                    .collect(),
                captures,
                Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
            ),
            TypedInner::ExtractorClosure(params, captures, body) => TypedInner::ExtractorClosure(
                params
                    .into_iter()
                    .map(|param| TypedClosureParam {
                        id: param.id,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                    })
                    .collect(),
                captures,
                Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
            ),
            TypedInner::CaptureClosure(params, captures, body) => TypedInner::CaptureClosure(
                params
                    .into_iter()
                    .map(|param| TypedClosureParam {
                        id: param.id,
                        ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                    })
                    .collect(),
                captures,
                Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
            ),
            TypedInner::CaptureConstructorClosure(id, params, captures, body) => {
                TypedInner::CaptureConstructorClosure(
                    id,
                    params
                        .into_iter()
                        .map(|param| TypedClosureParam {
                            id: param.id,
                            ty: self.substitute_ty_with_mapping(&param.ty, mapping),
                        })
                        .collect(),
                    captures,
                    Box::new(self.substitute_typed_node_with_mapping(*body, mapping)),
                )
            }
            TypedInner::Capture(target, args) => TypedInner::Capture(
                Box::new(self.substitute_typed_node_with_mapping(*target, mapping)),
                args.into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
            ),
            TypedInner::StructDef(tag, name, field_names, field_policies) => {
                TypedInner::StructDef(tag, name, field_names, field_policies)
            }
            TypedInner::RecordDef(tag, name, field_names, field_policies) => {
                TypedInner::RecordDef(tag, name, field_names, field_policies)
            }
            TypedInner::EnumDef(name, variants) => TypedInner::EnumDef(name, variants),
            TypedInner::TraitDef(name, where_clause, methods) => {
                TypedInner::TraitDef(name, where_clause, methods)
            }
            TypedInner::TraitImplDef(trait_name, target_name, where_clause) => {
                TypedInner::TraitImplDef(trait_name, target_name, where_clause)
            }
            TypedInner::Semi(inner) => TypedInner::Semi(Box::new(
                self.substitute_typed_node_with_mapping(*inner, mapping),
            )),
        };

        TypedNode { ty, span, node }
    }

    fn substitute_typed_facet_path_with_mapping(
        &self,
        path: TypedFacetPath,
        mapping: &HashMap<u32, Ty>,
    ) -> TypedFacetPath {
        TypedFacetPath {
            source_ty: self.substitute_ty_with_mapping(&path.source_ty, mapping),
            focus_ty: self.substitute_ty_with_mapping(&path.focus_ty, mapping),
            update_source_ty: self.substitute_ty_with_mapping(&path.update_source_ty, mapping),
            update_focus_ty: self.substitute_ty_with_mapping(&path.update_focus_ty, mapping),
            path_kind: path.path_kind,
            may_fail: path.may_fail,
            segments: path
                .segments
                .into_iter()
                .map(|segment| self.substitute_typed_facet_segment_with_mapping(segment, mapping))
                .collect(),
        }
    }

    fn substitute_typed_facet_segment_with_mapping(
        &self,
        segment: TypedFacetSegment,
        mapping: &HashMap<u32, Ty>,
    ) -> TypedFacetSegment {
        match segment {
            TypedFacetSegment::ListIndex {
                index,
                display,
                literal_index,
            } => TypedFacetSegment::ListIndex {
                index: Box::new(self.substitute_typed_node_with_mapping(*index, mapping)),
                display,
                literal_index,
            },
            TypedFacetSegment::ListRange {
                start,
                end,
                display,
                literal_start,
                literal_end,
            } => TypedFacetSegment::ListRange {
                start: Box::new(self.substitute_typed_node_with_mapping(*start, mapping)),
                end: Box::new(self.substitute_typed_node_with_mapping(*end, mapping)),
                display,
                literal_start,
                literal_end,
            },
            TypedFacetSegment::MapKey {
                key,
                display,
                literal_key,
            } => TypedFacetSegment::MapKey {
                key: Box::new(self.substitute_typed_node_with_mapping(*key, mapping)),
                display,
                literal_key,
            },
            other => other,
        }
    }

    fn substitute_pending_facet_path_with_mapping(
        &self,
        path: PendingFacetPath,
        mapping: &HashMap<u32, Ty>,
    ) -> PendingFacetPath {
        PendingFacetPath {
            root_path_name: path.root_path_name,
            source_ty_hint: path
                .source_ty_hint
                .map(|ty| self.substitute_ty_with_mapping(&ty, mapping)),
            segments: path
                .segments
                .into_iter()
                .map(|segment| self.substitute_pending_facet_segment_with_mapping(segment, mapping))
                .collect(),
        }
    }

    fn substitute_pending_facet_segment_with_mapping(
        &self,
        segment: PendingFacetSegment,
        mapping: &HashMap<u32, Ty>,
    ) -> PendingFacetSegment {
        let substitute_expr = |expr| match expr {
            PendingFacetExpr::Resolved(expr) => PendingFacetExpr::Resolved(expr),
            PendingFacetExpr::Typed(expr) => PendingFacetExpr::Typed(Box::new(
                self.substitute_typed_node_with_mapping(*expr, mapping),
            )),
        };
        match segment {
            PendingFacetSegment::Bracket { expr, display } => PendingFacetSegment::Bracket {
                expr: substitute_expr(expr),
                display,
            },
            PendingFacetSegment::RangeBracket {
                start,
                end,
                display,
            } => PendingFacetSegment::RangeBracket {
                start: substitute_expr(start),
                end: substitute_expr(end),
                display,
            },
            other => other,
        }
    }

    fn substitute_typed_pattern_with_mapping(
        &self,
        pattern: TypedPattern,
        mapping: &HashMap<u32, Ty>,
    ) -> TypedPattern {
        match pattern {
            TypedPattern::Located(source, inner) => TypedPattern::Located(
                source,
                Box::new(self.substitute_typed_pattern_with_mapping(*inner, mapping)),
            ),
            TypedPattern::HashMap(ty, entries) => TypedPattern::HashMap(
                self.substitute_ty_with_mapping(&ty, mapping),
                entries
                    .into_iter()
                    .map(|entry| TypedHashMapPatternEntry {
                        key: self.substitute_typed_node_with_mapping(entry.key, mapping),
                        pattern: self.substitute_typed_pattern_with_mapping(entry.pattern, mapping),
                        key_span: entry.key_span,
                    })
                    .collect(),
            ),
            TypedPattern::Var(ty, id) => {
                TypedPattern::Var(self.substitute_ty_with_mapping(&ty, mapping), id)
            }
            TypedPattern::Pin(ty, id, dispatch) => TypedPattern::Pin(
                self.substitute_ty_with_mapping(&ty, mapping),
                id,
                self.substitute_selected_dispatch(dispatch, mapping),
            ),
            TypedPattern::As(ty, inner, id) => TypedPattern::As(
                self.substitute_ty_with_mapping(&ty, mapping),
                Box::new(self.substitute_typed_pattern_with_mapping(*inner, mapping)),
                id,
            ),
            TypedPattern::Wildcard(ty) => {
                TypedPattern::Wildcard(self.substitute_ty_with_mapping(&ty, mapping))
            }
            TypedPattern::ListNil(ty) => {
                TypedPattern::ListNil(self.substitute_ty_with_mapping(&ty, mapping))
            }
            TypedPattern::ListCons(ty, head, tail) => TypedPattern::ListCons(
                self.substitute_ty_with_mapping(&ty, mapping),
                Box::new(self.substitute_typed_pattern_with_mapping(*head, mapping)),
                Box::new(self.substitute_typed_pattern_with_mapping(*tail, mapping)),
            ),
            TypedPattern::IntLit(ty, value) => {
                TypedPattern::IntLit(self.substitute_ty_with_mapping(&ty, mapping), value)
            }
            TypedPattern::StrLit(ty, value) => {
                TypedPattern::StrLit(self.substitute_ty_with_mapping(&ty, mapping), value)
            }
            TypedPattern::BoolLit(ty, value) => {
                TypedPattern::BoolLit(self.substitute_ty_with_mapping(&ty, mapping), value)
            }
            TypedPattern::DurationLit(ty, value) => {
                TypedPattern::DurationLit(self.substitute_ty_with_mapping(&ty, mapping), value)
            }
            TypedPattern::Tuple(ty, items) => TypedPattern::Tuple(
                self.substitute_ty_with_mapping(&ty, mapping),
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_pattern_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedPattern::Constructor {
                ty,
                tag,
                field_tys,
                fields,
                field_offset,
            } => TypedPattern::Constructor {
                ty: self.substitute_ty_with_mapping(&ty, mapping),
                tag,
                field_tys: field_tys
                    .into_iter()
                    .map(|ty| self.substitute_ty_with_mapping(&ty, mapping))
                    .collect(),
                fields: fields
                    .into_iter()
                    .map(|field| self.substitute_typed_pattern_with_mapping(field, mapping))
                    .collect(),
                field_offset,
            },
            TypedPattern::Extractor {
                input_ty,
                extractor,
                extractor_ty,
                pre_args,
                success_tag,
                err_tag,
                seq_tys,
                items,
            } => TypedPattern::Extractor {
                input_ty: self.substitute_ty_with_mapping(&input_ty, mapping),
                extractor,
                extractor_ty: self.substitute_ty_with_mapping(&extractor_ty, mapping),
                pre_args: pre_args
                    .into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
                success_tag,
                err_tag,
                seq_tys: seq_tys
                    .into_iter()
                    .map(|ty| self.substitute_ty_with_mapping(&ty, mapping))
                    .collect(),
                items: items
                    .into_iter()
                    .map(|item| self.substitute_typed_pattern_with_mapping(item, mapping))
                    .collect(),
            },
        }
    }

    fn substitute_typed_match_pattern_with_mapping(
        &self,
        pattern: TypedMatchPattern,
        mapping: &HashMap<u32, Ty>,
    ) -> TypedMatchPattern {
        match pattern {
            TypedMatchPattern::HashMap(entries) => TypedMatchPattern::HashMap(
                entries
                    .into_iter()
                    .map(|entry| TypedHashMapMatchPatternEntry {
                        key: self.substitute_typed_node_with_mapping(entry.key, mapping),
                        pattern: self
                            .substitute_typed_match_pattern_with_mapping(entry.pattern, mapping),
                        key_span: entry.key_span,
                    })
                    .collect(),
            ),
            TypedMatchPattern::Binding(id) => TypedMatchPattern::Binding(id),
            TypedMatchPattern::Pin { id, ty, dispatch } => TypedMatchPattern::Pin {
                id,
                ty: self.substitute_ty_with_mapping(&ty, mapping),
                dispatch: self.substitute_selected_dispatch(dispatch, mapping),
            },
            TypedMatchPattern::As(inner, id) => TypedMatchPattern::As(
                Box::new(self.substitute_typed_match_pattern_with_mapping(*inner, mapping)),
                id,
            ),
            TypedMatchPattern::Wildcard => TypedMatchPattern::Wildcard,
            TypedMatchPattern::BoolLit(value) => TypedMatchPattern::BoolLit(value),
            TypedMatchPattern::IntLit(value) => TypedMatchPattern::IntLit(value),
            TypedMatchPattern::StrLit(value) => TypedMatchPattern::StrLit(value),
            TypedMatchPattern::DurationLit(value) => TypedMatchPattern::DurationLit(value),
            TypedMatchPattern::ErrorKind(value) => TypedMatchPattern::ErrorKind(value),
            TypedMatchPattern::Or(items) => TypedMatchPattern::Or(
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_match_pattern_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedMatchPattern::ErrorPayload {
                kind,
                fields: items,
            } => TypedMatchPattern::ErrorPayload {
                kind,
                fields: items
                    .into_iter()
                    .map(|item| self.substitute_typed_match_pattern_with_mapping(item, mapping))
                    .collect(),
            },
            TypedMatchPattern::Tuple(items) => TypedMatchPattern::Tuple(
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_match_pattern_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedMatchPattern::Record(items) => TypedMatchPattern::Record(
                items
                    .into_iter()
                    .map(|item| self.substitute_typed_match_pattern_with_mapping(item, mapping))
                    .collect(),
            ),
            TypedMatchPattern::Constructor {
                tag,
                fields,
                field_offset,
            } => TypedMatchPattern::Constructor {
                tag,
                fields: fields
                    .into_iter()
                    .map(|field| self.substitute_typed_match_pattern_with_mapping(field, mapping))
                    .collect(),
                field_offset,
            },
            TypedMatchPattern::ListNil => TypedMatchPattern::ListNil,
            TypedMatchPattern::ListCons(head, tail) => TypedMatchPattern::ListCons(
                Box::new(self.substitute_typed_match_pattern_with_mapping(*head, mapping)),
                Box::new(self.substitute_typed_match_pattern_with_mapping(*tail, mapping)),
            ),
            TypedMatchPattern::Extractor {
                input_ty,
                extractor,
                extractor_ty,
                pre_args,
                success_tag,
                err_tag,
                seq_tys,
                items,
            } => TypedMatchPattern::Extractor {
                input_ty: self.substitute_ty_with_mapping(&input_ty, mapping),
                extractor,
                extractor_ty: self.substitute_ty_with_mapping(&extractor_ty, mapping),
                pre_args: pre_args
                    .into_iter()
                    .map(|arg| self.substitute_typed_node_with_mapping(arg, mapping))
                    .collect(),
                success_tag,
                err_tag,
                seq_tys: seq_tys
                    .into_iter()
                    .map(|ty| self.substitute_ty_with_mapping(&ty, mapping))
                    .collect(),
                items: items
                    .into_iter()
                    .map(|item| self.substitute_typed_match_pattern_with_mapping(item, mapping))
                    .collect(),
            },
        }
    }

    pub(super) fn substitute_ty_with_mapping(&self, ty: &Ty, mapping: &HashMap<u32, Ty>) -> Ty {
        match ty {
            Ty::Var(var) => {
                if let Some(mapped) = mapping.get(var) {
                    self.resolve_ty(mapped)
                } else {
                    let resolved = self.resolve_ty(ty);
                    if resolved == *ty {
                        resolved
                    } else {
                        self.substitute_ty_with_mapping(&resolved, mapping)
                    }
                }
            }
            Ty::ExtractorClosure(inner) => {
                Ty::ExtractorClosure(Box::new(self.substitute_ty_with_mapping(inner, mapping)))
            }
            Ty::MatchResult(inner) => {
                Ty::MatchResult(Box::new(self.substitute_ty_with_mapping(inner, mapping)))
            }
            Ty::List(inner) => Ty::List(Box::new(self.substitute_ty_with_mapping(inner, mapping))),
            Ty::Lazy(inner) => Ty::Lazy(Box::new(self.substitute_ty_with_mapping(inner, mapping))),
            Ty::Pid(inner) => Ty::Pid(Box::new(self.substitute_ty_with_mapping(inner, mapping))),
            Ty::Facet(kind, source, focus, update_source, update_focus) => Ty::Facet(
                *kind,
                Box::new(self.substitute_ty_with_mapping(source, mapping)),
                Box::new(self.substitute_ty_with_mapping(focus, mapping)),
                Box::new(self.substitute_ty_with_mapping(update_source, mapping)),
                Box::new(self.substitute_ty_with_mapping(update_focus, mapping)),
            ),
            Ty::Tuple(items) => Ty::Tuple(
                items
                    .iter()
                    .map(|item| self.substitute_ty_with_mapping(item, mapping))
                    .collect(),
            ),
            Ty::SelfApp(items) => {
                let source_witness =
                    Self::constructor_application_parts(items).map(|(witness, _)| witness.clone());
                let substituted = items
                    .iter()
                    .map(|item| self.substitute_ty_with_mapping(item, mapping))
                    .collect::<Vec<_>>();
                if let Some((witness, slots)) = Self::constructor_application_parts(&substituted) {
                    if let Some(source) = source_witness.as_ref() {
                        if let ConstructorApplicationOutcome::Applied(applied) =
                            self.apply_constructor_application(source, witness, slots)
                        {
                            return applied;
                        }
                    }
                }
                Ty::SelfApp(substituted)
            }
            Ty::Func(params, ret) => Ty::Func(
                params
                    .iter()
                    .map(|param| self.substitute_ty_with_mapping(param, mapping))
                    .collect(),
                Box::new(self.substitute_ty_with_mapping(ret, mapping)),
            ),
            Ty::BuiltinFunc { name, params, ret } => Ty::BuiltinFunc {
                name: name.clone(),
                params: params
                    .iter()
                    .map(|param| self.substitute_ty_with_mapping(param, mapping))
                    .collect(),
                ret: Box::new(self.substitute_ty_with_mapping(ret, mapping)),
            },
            Ty::UserFunc {
                fun_idx,
                type_params,
                call_substitution,
                params,
                ret,
            } => Ty::UserFunc {
                fun_idx: *fun_idx,
                type_params: type_params.clone(),
                call_substitution: call_substitution
                    .iter()
                    .map(|(var, ty)| (*var, self.substitute_ty_with_mapping(ty, mapping)))
                    .collect(),
                params: params
                    .iter()
                    .map(|param| self.substitute_ty_with_mapping(param, mapping))
                    .collect(),
                ret: Box::new(self.substitute_ty_with_mapping(ret, mapping)),
            },
            Ty::Struct(name, fields) => Ty::Struct(
                name.clone(),
                fields.map_types(|ty| self.substitute_ty_with_mapping(ty, mapping)),
            ),
            Ty::Record(name, fields) => Ty::Record(
                name.clone(),
                fields.map_types(|ty| self.substitute_ty_with_mapping(ty, mapping)),
            ),
            Ty::Enum(name, args) => Ty::Enum(
                name.clone(),
                args.iter()
                    .map(|arg| self.substitute_ty_with_mapping(arg, mapping))
                    .collect(),
            ),
            Ty::Result(ok, err) => Ty::Result(
                Box::new(self.substitute_ty_with_mapping(ok, mapping)),
                Box::new(self.substitute_ty_with_mapping(err, mapping)),
            ),
            other => other.clone(),
        }
    }

    fn substitute_trait_call_origin_with_mapping(
        &self,
        origin: TraitCallOrigin,
        mapping: &HashMap<u32, Ty>,
    ) -> TraitCallOrigin {
        match origin {
            TraitCallOrigin::Explicit => TraitCallOrigin::Explicit,
            TraitCallOrigin::Operator { op, lhs_ty, rhs_ty } => TraitCallOrigin::Operator {
                op,
                lhs_ty: self.substitute_ty_with_mapping(&lhs_ty, mapping),
                rhs_ty: self.substitute_ty_with_mapping(&rhs_ty, mapping),
            },
            TraitCallOrigin::Comparison { op, lhs_ty, rhs_ty } => TraitCallOrigin::Comparison {
                op,
                lhs_ty: self.substitute_ty_with_mapping(&lhs_ty, mapping),
                rhs_ty: self.substitute_ty_with_mapping(&rhs_ty, mapping),
            },
        }
    }

    fn substitute_selected_dispatch(
        &self,
        dispatch: TraitDispatch,
        mapping: &CanonicalSubstitution,
    ) -> TraitDispatch {
        let TraitDispatch::Selected(mut instantiation) = dispatch else {
            return dispatch;
        };
        for ty in instantiation.substitution.values_mut() {
            *ty = self.substitute_ty_with_mapping(ty, mapping);
        }
        for ty in instantiation.caller_substitution.values_mut() {
            *ty = self.substitute_ty_with_mapping(ty, mapping);
        }
        let signature = &mut instantiation.callable_signature;
        for ty in signature
            .return_type_arguments
            .iter_mut()
            .map(|argument| &mut argument.ty)
            .chain(
                signature
                    .value_parameters
                    .iter_mut()
                    .map(|parameter| &mut parameter.ty),
            )
            .chain(std::iter::once(&mut signature.return_type.ty))
            .chain(
                signature
                    .where_constraints
                    .constraints
                    .iter_mut()
                    .map(|constraint| &mut constraint.subject),
            )
        {
            *ty = self
                .substitute_canonical_type(ty, mapping)
                .expect("selected canonical substitution must preserve canonical types");
        }
        TraitDispatch::Selected(instantiation)
    }

    fn materialize_trait_method_instantiation(
        &mut self,
        mut instantiation: TraitMethodInstantiation,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<TraitDispatch, TypeError> {
        for (variable, ty) in &mut instantiation.substitution {
            *ty = self.normalize_executable_constructor_binding(*variable, ty);
        }
        for (variable, ty) in &mut instantiation.caller_substitution {
            *ty = self.normalize_executable_constructor_binding(*variable, ty);
        }
        let signature = &instantiation.callable_signature;
        if signature
            .return_type_arguments
            .iter()
            .map(|argument| &argument.ty)
            .chain(
                signature
                    .value_parameters
                    .iter()
                    .map(|parameter| &parameter.ty),
            )
            .chain(std::iter::once(&signature.return_type.ty))
            .chain(
                signature
                    .where_constraints
                    .constraints
                    .iter()
                    .map(|constraint| &constraint.subject),
            )
            .any(CanonicalTy::has_pending_instantiation)
        {
            return Err(self.trait_dispatch_failure(
                TypeDiagnosticReason::UnresolvedTraitMethodInstantiation,
                signature
                    .identity
                    .owner
                    .as_deref()
                    .expect("trait method signature owner"),
                &signature.identity.name,
                None,
                span,
            ));
        }
        match instantiation.dispatch_target {
            TraitDispatchTarget::UserFunction { name, fun_idx }
                if context.needs_specialization.contains(&fun_idx) =>
            {
                let original_def = context.defs_by_fun_idx.get(&fun_idx).ok_or_else(|| {
                    TypeError::new(
                        format!("Missing generic definition for fun_idx {}", fun_idx),
                        span.clone(),
                    )
                })?;
                let bound_tyvars =
                    context
                        .bound_tyvars_by_fun_idx
                        .get(&fun_idx)
                        .ok_or_else(|| {
                            TypeError::new(
                                format!("Missing specialization binders for fun_idx {}", fun_idx),
                                span.clone(),
                            )
                        })?;
                let concrete_tys = self.trait_specialization_arguments(
                    original_def,
                    &bound_tyvars.tyvars,
                    &instantiation.substitution,
                )?;
                let fun_idx = self.ensure_specialized_def(
                    fun_idx,
                    &concrete_tys,
                    &instantiation.substitution,
                    context.defs_by_fun_idx,
                    context.bound_tyvars_by_fun_idx,
                    context.needs_specialization,
                    context.specialization_fun_idxs,
                    context.generated_defs,
                )?;
                Ok(TraitDispatch::Static(TraitDispatchTarget::UserFunction {
                    name,
                    fun_idx,
                }))
            }
            target => Ok(TraitDispatch::Static(target)),
        }
    }

    fn specialize_pattern_pin_dispatch(
        &mut self,
        ty: &Ty,
        dispatch: TraitDispatch,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<TraitDispatch, TypeError> {
        if let TraitDispatch::Selected(instantiation) = dispatch {
            return self.materialize_trait_method_instantiation(*instantiation, span, context);
        }
        if !matches!(dispatch, TraitDispatch::Pending)
            && !matches!(&dispatch, TraitDispatch::Static(TraitDispatchTarget::UserFunction { fun_idx, .. })
                if context.needs_specialization.contains(fun_idx))
        {
            return Ok(dispatch);
        }
        let receiver = self.resolve_ty(ty);
        let eq_trait = self
            .trait_key_by_short_name("Eq")
            .ok_or_else(|| TypeError::new("Unknown trait: Eq", span.clone()))?;
        let trait_info = self
            .traits
            .get(&eq_trait)
            .cloned()
            .ok_or_else(|| TypeError::new("Missing Eq trait contract", span.clone()))?;
        let method = trait_info
            .methods
            .get("eq")
            .ok_or_else(|| TypeError::new("Missing Eq::eq method contract", span.clone()))?;
        let (_, result_ty, trait_args, _, _) =
            self.resolve_trait_method_signature(&trait_info, method, &receiver)?;
        match self.select_trait_method_instantiation(
            &eq_trait,
            "eq",
            &receiver,
            &trait_args,
            &[receiver.clone(), receiver.clone()],
            &result_ty,
        )? {
            CandidateApplicability::Applicable(instantiation) => {
                self.materialize_trait_method_instantiation(instantiation, span, context)
            }
            CandidateApplicability::Deferred(pending) => {
                let mut error = self.ambiguous_constructor_result("Eq", "eq", span);
                error.hint = Some(format!(
                    "Add enough type information to choose among {} remaining candidate(s) and resolve {} constructor input(s).",
                    pending.candidates.len(),
                    pending.waiting_on.len()
                ));
                Err(error)
            }
            CandidateApplicability::Rejected(_) => Err(self.trait_dispatch_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                &eq_trait,
                "eq",
                Some(&receiver),
                span,
            )),
        }
    }

    fn specialize_extractor_head(
        &mut self,
        extractor: &ResolvedId,
        extractor_ty: Ty,
        context: &mut SpecializationContext<'_>,
    ) -> Result<Ty, TypeError> {
        let mut reference = TypedNode {
            ty: self.resolve_ty(&extractor_ty),
            span: extractor.span.clone(),
            node: TypedInner::Var(extractor.clone()),
        };
        self.specialize_callable_reference(&mut reference, context)?;
        Ok(reference.ty)
    }

    fn specialize_extractor_pre_args(
        &mut self,
        args: Vec<TypedNode>,
        context: &mut SpecializationContext<'_>,
    ) -> Result<Vec<TypedNode>, TypeError> {
        args.into_iter()
            .map(|arg| {
                self.rewrite_specializations_in_node(
                    arg,
                    context.defs_by_fun_idx,
                    context.bound_tyvars_by_fun_idx,
                    context.needs_specialization,
                    context.specialization_fun_idxs,
                    context.generated_defs,
                )
                .map(|node| *node)
                .map_err(|error| *error)
            })
            .collect()
    }

    fn validate_extractor_payload_shape(
        &self,
        extractor_ty: &Ty,
        seq_tys: &[Ty],
        children: usize,
        span: &Span,
    ) -> Result<(), TypeError> {
        let resolved = self.resolve_ty(extractor_ty);
        let ret = match Self::extractor_signature_ty(&resolved) {
            Ty::UserFunc { ret, .. } | Ty::BuiltinFunc { ret, .. } | Ty::Func(_, ret) => ret,
            _ => {
                return Err(TypeError::new(
                    "Extractor callable contract is unresolved",
                    span.clone(),
                ))
            }
        };
        let Ty::MatchResult(payload) = ret.as_ref() else {
            return Err(TypeError::new(
                "Extractor payload requires canonical MatchResult",
                span.clone(),
            ));
        };
        // Only the outer payload constructor determines child arity. Generic
        // types inside a known tuple or single-value container do not change
        // the runtime layout and remain valid under ordinary type erasure.
        if matches!(payload.as_ref(), Ty::Var(_) | Ty::SelfApp(_)) {
            return Err(TypeError::new(
                "Extractor payload shape must be resolved before execution",
                span.clone(),
            ));
        }
        let shape = match payload.as_ref() {
            Ty::Tuple(items) => items.clone(),
            other => vec![other.clone()],
        };
        let resolved_seq = seq_tys
            .iter()
            .map(|ty| self.resolve_ty(ty))
            .collect::<Vec<_>>();
        if shape != resolved_seq
            || (children != shape.len() && !(children == 0 && shape == [Ty::Unit]))
        {
            return Err(TypeError::new(
                "Extractor payload shape does not match its child patterns",
                span.clone(),
            ));
        }
        Ok(())
    }

    fn concretize_specialized_typed_pattern(
        &mut self,
        pattern: TypedPattern,
        expected_ty: Option<&Ty>,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<TypedPattern, TypeError> {
        let normalized_ty = |checker: &Checker, ty: &Ty, expected: Option<&Ty>| {
            checker.resolve_ty(expected.unwrap_or(ty))
        };
        Ok(match pattern {
            TypedPattern::Located(source, inner) => TypedPattern::Located(
                source,
                Box::new(self.concretize_specialized_typed_pattern(
                    *inner,
                    expected_ty,
                    span,
                    context,
                )?),
            ),
            TypedPattern::Pin(ty, id, dispatch) => {
                let ty = normalized_ty(self, &ty, expected_ty);
                let dispatch =
                    self.specialize_pattern_pin_dispatch(&ty, dispatch, span, context)?;
                TypedPattern::Pin(ty, id, dispatch)
            }
            TypedPattern::HashMap(ty, entries) => {
                let ty = normalized_ty(self, &ty, expected_ty);
                let value_ty = self.hash_map_pattern_value_ty(&ty, span)?;
                let entries = entries
                    .into_iter()
                    .map(|entry| {
                        Ok(TypedHashMapPatternEntry {
                            key: self
                                .specialize_extractor_pre_args(vec![entry.key], context)?
                                .remove(0),
                            pattern: self.concretize_specialized_typed_pattern(
                                entry.pattern,
                                Some(&value_ty),
                                span,
                                context,
                            )?,
                            key_span: entry.key_span,
                        })
                    })
                    .collect::<Result<_, TypeError>>()?;
                TypedPattern::HashMap(ty, entries)
            }
            TypedPattern::Var(ty, id) => {
                TypedPattern::Var(normalized_ty(self, &ty, expected_ty), id)
            }
            TypedPattern::As(ty, inner, id) => {
                let ty = normalized_ty(self, &ty, expected_ty);
                TypedPattern::As(
                    ty.clone(),
                    Box::new(self.concretize_specialized_typed_pattern(
                        *inner,
                        Some(&ty),
                        span,
                        context,
                    )?),
                    id,
                )
            }
            TypedPattern::Wildcard(ty) => {
                TypedPattern::Wildcard(normalized_ty(self, &ty, expected_ty))
            }
            TypedPattern::ListNil(ty) => {
                TypedPattern::ListNil(normalized_ty(self, &ty, expected_ty))
            }
            TypedPattern::ListCons(ty, head, tail) => {
                let ty = normalized_ty(self, &ty, expected_ty);
                let item_ty = match &ty {
                    Ty::List(inner) => Some(inner.as_ref()),
                    _ => None,
                };
                let head =
                    self.concretize_specialized_typed_pattern(*head, item_ty, span, context)?;
                let tail =
                    self.concretize_specialized_typed_pattern(*tail, Some(&ty), span, context)?;
                TypedPattern::ListCons(ty, Box::new(head), Box::new(tail))
            }
            TypedPattern::IntLit(ty, value) => {
                TypedPattern::IntLit(normalized_ty(self, &ty, expected_ty), value)
            }
            TypedPattern::StrLit(ty, value) => {
                TypedPattern::StrLit(normalized_ty(self, &ty, expected_ty), value)
            }
            TypedPattern::BoolLit(ty, value) => {
                TypedPattern::BoolLit(normalized_ty(self, &ty, expected_ty), value)
            }
            TypedPattern::DurationLit(ty, value) => {
                TypedPattern::DurationLit(normalized_ty(self, &ty, expected_ty), value)
            }
            TypedPattern::Tuple(ty, items) => {
                let ty = normalized_ty(self, &ty, expected_ty);
                let expected_items = match &ty {
                    Ty::Tuple(items) => Some(items.as_slice()),
                    _ => None,
                };
                TypedPattern::Tuple(
                    ty.clone(),
                    items
                        .into_iter()
                        .enumerate()
                        .map(|(index, item)| {
                            self.concretize_specialized_typed_pattern(
                                item,
                                expected_items.and_then(|items| items.get(index)),
                                span,
                                context,
                            )
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                )
            }
            TypedPattern::Constructor {
                ty,
                tag,
                field_tys,
                fields,
                field_offset,
            } => {
                let ty = normalized_ty(self, &ty, expected_ty);
                let field_tys = field_tys
                    .into_iter()
                    .map(|field_ty| normalized_ty(self, &field_ty, None))
                    .collect::<Vec<_>>();
                let fields = fields
                    .into_iter()
                    .enumerate()
                    .map(|(index, field)| {
                        self.concretize_specialized_typed_pattern(
                            field,
                            field_tys.get(index),
                            span,
                            context,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                TypedPattern::Constructor {
                    ty,
                    tag,
                    field_tys,
                    fields,
                    field_offset,
                }
            }
            TypedPattern::Extractor {
                input_ty,
                extractor,
                extractor_ty,
                pre_args,
                success_tag,
                err_tag,
                seq_tys,
                items,
            } => {
                self.validate_extractor_payload_shape(
                    &extractor_ty,
                    &seq_tys,
                    items.len(),
                    &extractor.span,
                )?;
                let extractor_ty =
                    self.specialize_extractor_head(&extractor, extractor_ty, context)?;
                TypedPattern::Extractor {
                    input_ty: self.resolve_ty(&input_ty),
                    extractor,
                    extractor_ty,
                    pre_args: self.specialize_extractor_pre_args(pre_args, context)?,
                    success_tag,
                    err_tag,
                    seq_tys: seq_tys.iter().map(|ty| self.resolve_ty(ty)).collect(),
                    items: items
                        .into_iter()
                        .map(|item| {
                            self.concretize_specialized_typed_pattern(item, None, span, context)
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                }
            }
        })
    }

    fn concretize_specialized_match_pattern(
        &mut self,
        pattern: TypedMatchPattern,
        span: &Span,
        context: &mut SpecializationContext<'_>,
    ) -> Result<TypedMatchPattern, TypeError> {
        Ok(match pattern {
            TypedMatchPattern::HashMap(entries) => TypedMatchPattern::HashMap(
                entries
                    .into_iter()
                    .map(|entry| {
                        Ok(TypedHashMapMatchPatternEntry {
                            key: self
                                .specialize_extractor_pre_args(vec![entry.key], context)?
                                .remove(0),
                            pattern: self.concretize_specialized_match_pattern(
                                entry.pattern,
                                span,
                                context,
                            )?,
                            key_span: entry.key_span,
                        })
                    })
                    .collect::<Result<_, TypeError>>()?,
            ),
            TypedMatchPattern::Pin { id, ty, dispatch } => {
                let dispatch =
                    self.specialize_pattern_pin_dispatch(&ty, dispatch, span, context)?;
                TypedMatchPattern::Pin { id, ty, dispatch }
            }
            TypedMatchPattern::As(inner, id) => TypedMatchPattern::As(
                Box::new(self.concretize_specialized_match_pattern(*inner, span, context)?),
                id,
            ),
            TypedMatchPattern::Or(items) => TypedMatchPattern::Or(
                items
                    .into_iter()
                    .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedMatchPattern::ErrorPayload {
                kind,
                fields: items,
            } => TypedMatchPattern::ErrorPayload {
                kind,
                fields: items
                    .into_iter()
                    .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                    .collect::<Result<Vec<_>, _>>()?,
            },
            TypedMatchPattern::Tuple(items) => TypedMatchPattern::Tuple(
                items
                    .into_iter()
                    .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedMatchPattern::Record(items) => TypedMatchPattern::Record(
                items
                    .into_iter()
                    .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                    .collect::<Result<Vec<_>, _>>()?,
            ),
            TypedMatchPattern::Constructor {
                tag,
                fields,
                field_offset,
            } => TypedMatchPattern::Constructor {
                tag,
                fields: fields
                    .into_iter()
                    .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                    .collect::<Result<Vec<_>, _>>()?,
                field_offset,
            },
            TypedMatchPattern::ListCons(head, tail) => TypedMatchPattern::ListCons(
                Box::new(self.concretize_specialized_match_pattern(*head, span, context)?),
                Box::new(self.concretize_specialized_match_pattern(*tail, span, context)?),
            ),
            TypedMatchPattern::Extractor {
                input_ty,
                extractor,
                extractor_ty,
                pre_args,
                success_tag,
                err_tag,
                seq_tys,
                items,
            } => {
                self.validate_extractor_payload_shape(
                    &extractor_ty,
                    &seq_tys,
                    items.len(),
                    &extractor.span,
                )?;
                let extractor_ty =
                    self.specialize_extractor_head(&extractor, extractor_ty, context)?;
                TypedMatchPattern::Extractor {
                    input_ty,
                    extractor,
                    extractor_ty,
                    pre_args: self.specialize_extractor_pre_args(pre_args, context)?,
                    success_tag,
                    err_tag,
                    seq_tys,
                    items: items
                        .into_iter()
                        .map(|item| self.concretize_specialized_match_pattern(item, span, context))
                        .collect::<Result<Vec<_>, _>>()?,
                }
            }
            other => other,
        })
    }

    fn typed_match_pattern_has_pending_dispatch(pattern: &TypedMatchPattern) -> bool {
        match pattern {
            TypedMatchPattern::HashMap(entries) => entries.iter().any(|entry| {
                Self::typed_node_has_pending_trait_call(&entry.key)
                    || Self::typed_match_pattern_has_pending_dispatch(&entry.pattern)
            }),
            TypedMatchPattern::Pin { dispatch, .. } => {
                matches!(
                    dispatch,
                    TraitDispatch::Pending | TraitDispatch::Selected(_)
                )
            }
            TypedMatchPattern::As(inner, _) => {
                Self::typed_match_pattern_has_pending_dispatch(inner)
            }
            TypedMatchPattern::Or(items)
            | TypedMatchPattern::Tuple(items)
            | TypedMatchPattern::ErrorPayload { fields: items, .. } => items
                .iter()
                .any(Self::typed_match_pattern_has_pending_dispatch),
            TypedMatchPattern::Constructor { fields, .. } => fields
                .iter()
                .any(Self::typed_match_pattern_has_pending_dispatch),
            TypedMatchPattern::ListCons(head, tail) => {
                Self::typed_match_pattern_has_pending_dispatch(head)
                    || Self::typed_match_pattern_has_pending_dispatch(tail)
            }
            TypedMatchPattern::Extractor { items, .. } => items
                .iter()
                .any(Self::typed_match_pattern_has_pending_dispatch),
            _ => false,
        }
    }

    fn typed_pattern_has_pending_dispatch(pattern: &TypedPattern) -> bool {
        match pattern {
            TypedPattern::HashMap(_, entries) => entries.iter().any(|entry| {
                Self::typed_node_has_pending_trait_call(&entry.key)
                    || Self::typed_pattern_has_pending_dispatch(&entry.pattern)
            }),
            TypedPattern::Located(_, inner) => Self::typed_pattern_has_pending_dispatch(inner),
            TypedPattern::Pin(_, _, dispatch) => matches!(dispatch, TraitDispatch::Pending),
            TypedPattern::As(_, inner, _) => Self::typed_pattern_has_pending_dispatch(inner),
            TypedPattern::ListCons(_, head, tail) => {
                Self::typed_pattern_has_pending_dispatch(head)
                    || Self::typed_pattern_has_pending_dispatch(tail)
            }
            TypedPattern::Tuple(_, items)
            | TypedPattern::Constructor { fields: items, .. }
            | TypedPattern::Extractor { items, .. } => {
                items.iter().any(Self::typed_pattern_has_pending_dispatch)
            }
            _ => false,
        }
    }

    fn typed_facet_path_has_pending_trait_call(path: &TypedFacetPath) -> bool {
        Self::typed_facet_path_expression_nodes(path).any(Self::typed_node_has_pending_trait_call)
    }

    fn pending_facet_path_has_pending_trait_call(path: &PendingFacetPath) -> bool {
        Self::pending_facet_path_expression_nodes(path).any(Self::typed_node_has_pending_trait_call)
    }

    fn typed_node_has_pending_trait_call(node: &TypedNode) -> bool {
        if node
            .monad_fail_call()
            .is_some_and(Self::typed_node_has_pending_trait_call)
        {
            return true;
        }
        if Self::pattern_expression_nodes(node)
            .into_iter()
            .any(Self::typed_node_has_pending_trait_call)
        {
            return true;
        }
        match &node.node {
            TypedInner::TraitCall {
                dispatch,
                receiver_ty,
                args,
                ..
            } => {
                matches!(dispatch, TraitDispatch::Pending)
                    || matches!(dispatch, TraitDispatch::Selected(instantiation)
                        if Self::selected_instantiation_has_pending_input(instantiation))
                    || matches!(receiver_ty, Ty::Var(_))
                    || args.iter().any(Self::typed_node_has_pending_trait_call)
            }
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                Self::typed_node_has_pending_trait_call(func)
                    || args.iter().any(Self::typed_node_has_pending_trait_call)
            }
            TypedInner::Block(stmts) => stmts.iter().any(Self::typed_node_has_pending_trait_call),
            TypedInner::Bind(pattern, rhs)
            | TypedInner::SafeBind(pattern, rhs, _, _)
            | TypedInner::ApplyPattern {
                pattern,
                value: rhs,
                ..
            } => {
                Self::typed_pattern_has_pending_dispatch(pattern)
                    || Self::typed_node_has_pending_trait_call(rhs)
            }
            TypedInner::DoSafeBind(control) => {
                Self::typed_pattern_has_pending_dispatch(&control.pattern)
                    || Self::typed_node_has_pending_trait_call(&control.rhs)
                    || match &control.failure_target {
                        SafeBindFailureTarget::DoAlternative { empty } => {
                            Self::typed_node_has_pending_trait_call(empty)
                        }
                        SafeBindFailureTarget::Deferred(_) => true,
                        _ => false,
                    }
                    || Self::typed_node_has_pending_trait_call(&control.continuation)
            }
            TypedInner::Semi(rhs) => Self::typed_node_has_pending_trait_call(rhs),
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right) => {
                Self::typed_node_has_pending_trait_call(left)
                    || Self::typed_node_has_pending_trait_call(right)
            }
            TypedInner::ListCons(head, tail) => {
                Self::typed_node_has_pending_trait_call(head)
                    || Self::typed_node_has_pending_trait_call(tail)
            }
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => {
                Self::typed_node_has_pending_trait_call(message)
                    || payload.iter().any(Self::typed_node_has_pending_trait_call)
            }
            TypedInner::ListLiteral(items) | TypedInner::TupleLiteral(items) => {
                items.iter().any(Self::typed_node_has_pending_trait_call)
            }
            TypedInner::HashMapLiteral(entries) => entries.iter().any(|(key, value)| {
                Self::typed_node_has_pending_trait_call(key)
                    || Self::typed_node_has_pending_trait_call(value)
            }),
            TypedInner::InterpolatedStr(parts) => parts.iter().any(|part| match part {
                TypedInterpolatedPart::Text(_) => false,
                TypedInterpolatedPart::Expr(expr) => Self::typed_node_has_pending_trait_call(expr),
            }),
            TypedInner::Dbg(args) => args
                .iter()
                .any(|arg| Self::typed_node_has_pending_trait_call(&arg.expr)),
            TypedInner::EagerBoundary(inner) => Self::typed_node_has_pending_trait_call(inner),
            TypedInner::If(cond, then_branch, else_branch) => {
                Self::typed_node_has_pending_trait_call(cond)
                    || Self::typed_node_has_pending_trait_call(then_branch)
                    || else_branch
                        .as_ref()
                        .is_some_and(|branch| Self::typed_node_has_pending_trait_call(branch))
            }
            TypedInner::Cause(value, err) => {
                Self::typed_node_has_pending_trait_call(value)
                    || Self::typed_node_has_pending_trait_call(err)
            }
            TypedInner::Match(scrutinee, arms) => {
                Self::typed_node_has_pending_trait_call(scrutinee)
                    || arms.iter().any(|arm| {
                        Self::typed_match_pattern_has_pending_dispatch(&arm.pattern)
                            || arm
                                .guard
                                .as_ref()
                                .is_some_and(Self::typed_node_has_pending_trait_call)
                            || Self::typed_node_has_pending_trait_call(&arm.body)
                    })
            }
            TypedInner::FieldAccess(expr, _) => Self::typed_node_has_pending_trait_call(expr),
            TypedInner::SupervisorSpawn { init, .. } => {
                Self::typed_node_has_pending_trait_call(init)
            }
            TypedInner::SupervisorAdopt { pid, .. } => Self::typed_node_has_pending_trait_call(pid),
            TypedInner::SupervisorStatus { .. } => false,
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                Self::typed_node_has_pending_trait_call(init)
                    || Self::typed_node_has_pending_trait_call(strategy)
            }
            TypedInner::ProcessContextHandler { .. } => false,
            TypedInner::FacetPath(path) => Self::typed_facet_path_has_pending_trait_call(path),
            TypedInner::PendingFacetPath(path) => {
                Self::pending_facet_path_has_pending_trait_call(path)
            }
            TypedInner::FacetView { source, path, .. } => {
                Self::typed_node_has_pending_trait_call(source)
                    || Self::typed_facet_path_has_pending_trait_call(path)
            }
            TypedInner::FacetSet {
                source,
                path,
                value,
                ..
            } => {
                Self::typed_node_has_pending_trait_call(source)
                    || Self::typed_facet_path_has_pending_trait_call(path)
                    || Self::typed_node_has_pending_trait_call(value)
            }
            TypedInner::FacetOver {
                source,
                path,
                update_fun,
                ..
            } => {
                Self::typed_node_has_pending_trait_call(source)
                    || Self::typed_facet_path_has_pending_trait_call(path)
                    || Self::typed_node_has_pending_trait_call(update_fun)
            }
            TypedInner::StructLit(_, fields) | TypedInner::ConstructorCall(_, fields) => {
                fields.iter().any(Self::typed_node_has_pending_trait_call)
            }
            TypedInner::DeferrorDef(_, _, _, _, show) => {
                Self::typed_node_has_pending_trait_call(show)
            }
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body) => {
                Self::typed_node_has_pending_trait_call(body)
            }
            TypedInner::CaptureConstructorClosure(_, _, _, body) => {
                Self::typed_node_has_pending_trait_call(body)
            }
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..) => false,
        }
    }

    fn selected_instantiation_has_pending_input(instantiation: &TraitMethodInstantiation) -> bool {
        let signature = &instantiation.callable_signature;
        signature
            .return_type_arguments
            .iter()
            .map(|argument| &argument.ty)
            .chain(
                signature
                    .value_parameters
                    .iter()
                    .map(|parameter| &parameter.ty),
            )
            .chain(std::iter::once(&signature.return_type.ty))
            .chain(
                signature
                    .where_constraints
                    .constraints
                    .iter()
                    .map(|constraint| &constraint.subject),
            )
            .any(CanonicalTy::has_pending_instantiation)
            || instantiation
                .substitution
                .values()
                .chain(instantiation.caller_substitution.values())
                .any(|ty| {
                    let mut variables = Vec::new();
                    Self::collect_ty_vars(ty, &mut variables);
                    !variables.is_empty()
                })
    }

    fn def_fun_idx(node: &TypedNode) -> Option<u32> {
        match &node.node {
            TypedInner::Def(fun_idx, ..) | TypedInner::ExtractorDef(fun_idx, ..) => Some(*fun_idx),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use spire::ast::Visibility;

    fn test_span() -> Span {
        Span { start: 0, end: 0 }
    }

    fn resolved_id(name: &str, qualified_name: Option<&str>, unique_id: u32) -> ResolvedId {
        ResolvedId {
            name: name.to_string(),
            qualified_name: qualified_name.map(str::to_string),
            symbol_info: None,
            unique_id,
            compiler_generated: false,
            span: test_span(),
        }
    }

    fn generic_identity_ty(fun_idx: u32, ty_var: u32) -> Ty {
        Ty::UserFunc {
            fun_idx,
            type_params: vec![ty_var],
            call_substitution: Vec::new(),
            params: vec![Ty::Var(ty_var)],
            ret: Box::new(Ty::Var(ty_var)),
        }
    }

    fn generic_identity_def(
        fun_idx: u32,
        id: ResolvedId,
        param_id: ResolvedId,
        ty_var: u32,
    ) -> TypedNode {
        TypedNode {
            ty: generic_identity_ty(fun_idx, ty_var),
            span: test_span(),
            node: TypedInner::Def(
                fun_idx,
                id,
                vec![TypedReturnTypeArgument {
                    ordinal: 0,
                    ty: Ty::Var(ty_var),
                    span: test_span(),
                }],
                vec![TypedValueParameter {
                    id: param_id.clone(),
                    mode: spire::ast::ValueParameterMode::PositionalOrNamed,
                    ty: Ty::Var(ty_var),
                    span: test_span(),
                }],
                Ty::Var(ty_var),
                None,
                Box::new(TypedNode {
                    ty: Ty::Var(ty_var),
                    span: test_span(),
                    node: TypedInner::Var(param_id),
                }),
                Visibility::Public,
            ),
        }
    }

    fn typed_arg(unique_id: u32, ty: Ty) -> TypedNode {
        TypedNode {
            ty,
            span: test_span(),
            node: TypedInner::Var(resolved_id("arg", None, unique_id)),
        }
    }

    fn call_generic(id: ResolvedId, fun_idx: u32, ty_var: u32, arg: TypedNode) -> TypedNode {
        let ret_ty = arg.ty.clone();
        let mut callable_ty = generic_identity_ty(fun_idx, ty_var);
        if let Ty::UserFunc {
            call_substitution, ..
        } = &mut callable_ty
        {
            *call_substitution = vec![(ty_var, ret_ty.clone())];
        }
        TypedNode {
            ty: ret_ty,
            span: test_span(),
            node: TypedInner::App(
                Box::new(TypedNode {
                    ty: callable_ty,
                    span: test_span(),
                    node: TypedInner::Var(id),
                }),
                vec![arg],
            ),
        }
    }

    fn generated_def_fun_idxs(nodes: &[TypedNode], qualified_name: &str) -> Vec<u32> {
        nodes
            .iter()
            .filter_map(|node| match &node.node {
                TypedInner::Def(fun_idx, id, ..)
                    if id.qualified_name.as_deref() == Some(qualified_name) =>
                {
                    Some(*fun_idx)
                }
                _ => None,
            })
            .collect()
    }

    fn app_fun_idxs(nodes: &[TypedNode]) -> Vec<u32> {
        nodes
            .iter()
            .filter_map(|node| match &node.node {
                TypedInner::App(func, _) => match &func.ty {
                    Ty::UserFunc { fun_idx, .. } => Some(*fun_idx),
                    _ => None,
                },
                _ => None,
            })
            .collect()
    }

    #[test]
    fn do_safebind_specializes_pattern_against_projected_payload() {
        let mut checker = Checker::new(TypecheckContext::default());
        let result_ty = Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error));
        let control = Box::new(TypedDoSafeBind {
            pattern: TypedPattern::Located(
                Span { start: 11, end: 14 },
                Box::new(TypedPattern::Wildcard(Ty::Var(91_200))),
            ),
            rhs: Box::new(TypedNode {
                ty: result_ty.clone(),
                span: test_span(),
                node: TypedInner::Lit(Lit::Unit),
            }),
            projection: SafeBindRhsProjection::CanonicalResultOnce {
                payload_ty: Ty::Int,
                error_ty: Ty::Error,
            },
            failure_target: SafeBindFailureTarget::DoMonadFail(Box::new(MonadFailTarget {
                carrier_ty: result_ty.clone(),
                error_id: sigil::resolved::ResolvedId {
                    name: "error".into(),
                    qualified_name: None,
                    unique_id: 91999,
                    compiler_generated: true,
                    symbol_info: None,
                    span: spire::ast::Span { start: 0, end: 0 },
                },
                call: Box::new(TypedNode {
                    ty: Ty::Error,
                    span: spire::ast::Span { start: 0, end: 0 },
                    node: TypedInner::ConstructorCall(
                        1,
                        vec![TypedNode {
                            ty: Ty::Error,
                            span: spire::ast::Span { start: 0, end: 0 },
                            node: TypedInner::Var(sigil::resolved::ResolvedId {
                                name: "error".into(),
                                qualified_name: None,
                                unique_id: 91999,
                                compiler_generated: true,
                                symbol_info: None,
                                span: spire::ast::Span { start: 0, end: 0 },
                            }),
                        }],
                    ),
                }),
            })),
            continuation: Box::new(TypedNode {
                ty: result_ty,
                span: test_span(),
                node: TypedInner::Lit(Lit::Unit),
            }),
            origins: DoSafeBindOrigins {
                do_span: test_span(),
                operator_span: test_span(),
                pattern_span: test_span(),
                rhs_span: test_span(),
                result_span: test_span(),
            },
        });

        let rewritten = checker
            .rewrite_do_safebind_specializations(
                control,
                &test_span(),
                &HashMap::new(),
                &HashMap::new(),
                &HashSet::new(),
                &mut HashMap::new(),
                &mut Vec::new(),
            )
            .expect("do SafeBind specialization should succeed");

        assert!(
            matches!(&rewritten.pattern, TypedPattern::Located(source, _) if *source == Span { start: 11, end: 14 })
        );
        assert!(matches!(
            rewritten.pattern.unlocated(),
            TypedPattern::Wildcard(Ty::Int)
        ));
    }

    #[test]
    fn injected_callable_specialization_materializes_target_with_bound_arguments() {
        for bound_arg_count in [0, 1] {
            let mut checker = Checker::new(TypecheckContext::default());
            checker.env.next_fun_idx = 100;
            let function_id = resolved_id("first", Some("Global::first"), 10);
            let mut definition =
                generic_identity_def(20, function_id.clone(), resolved_id("value", None, 11), 1);
            if bound_arg_count == 1 {
                let TypedInner::Def(_, _, _, parameters, _, _, _, _) = &mut definition.node else {
                    unreachable!()
                };
                parameters.push(TypedValueParameter {
                    id: resolved_id("other", None, 12),
                    mode: spire::ast::ValueParameterMode::PositionalOrNamed,
                    ty: Ty::Var(1),
                    span: test_span(),
                });
                let Ty::UserFunc { params, .. } = &mut definition.ty else {
                    unreachable!()
                };
                params.push(Ty::Var(1));
            }
            let injected = TypedNode {
                ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
                span: test_span(),
                node: TypedInner::InjectCall(
                    Box::new(TypedNode {
                        ty: Ty::UserFunc {
                            fun_idx: 20,
                            type_params: vec![1],
                            call_substitution: vec![(1, Ty::Int)],
                            params: vec![Ty::Int; bound_arg_count + 1],
                            ret: Box::new(Ty::Int),
                        },
                        span: test_span(),
                        node: TypedInner::Var(function_id),
                    }),
                    (0..bound_arg_count)
                        .map(|_| typed_arg(13, Ty::Int))
                        .collect(),
                ),
            };
            let nodes = checker
                .specialize_program(vec![definition, injected])
                .expect("injected callable specialization should succeed");
            let generated = generated_def_fun_idxs(&nodes, "Global::first");
            assert_eq!(
                generated.len(),
                1,
                "injected callable must materialize a definition"
            );
            let injected = nodes
                .iter()
                .find(|node| matches!(node.node, TypedInner::InjectCall(..)))
                .expect("injected callable remains in the program");
            assert_eq!(injected.ty, Ty::Func(vec![Ty::Int], Box::new(Ty::Int)));
            let TypedInner::InjectCall(target, args) = &injected.node else {
                unreachable!()
            };
            assert_eq!(args.len(), bound_arg_count);
            assert!(
                matches!(&target.ty, Ty::UserFunc { fun_idx, call_substitution, .. }
                if *fun_idx == generated[0] && call_substitution.is_empty())
            );
        }
    }

    #[test]
    fn specializations_reuse_identity_across_incremental_runs() {
        let mut checker = Checker::new(TypecheckContext::default());
        checker.env.next_fun_idx = 100;
        let ty_var = 1;
        let original_fun_idx = 20;
        let function_id = resolved_id("id", Some("Global::id"), 10);
        let param_id = resolved_id("x", None, 11);
        let original_def =
            generic_identity_def(original_fun_idx, function_id.clone(), param_id, ty_var);

        let first = checker
            .specialize_program(vec![
                original_def,
                call_generic(
                    function_id.clone(),
                    original_fun_idx,
                    ty_var,
                    typed_arg(1000, Ty::Int),
                ),
            ])
            .expect("first specialization should succeed");
        let first_generated = generated_def_fun_idxs(&first, "Global::id");
        assert_eq!(first_generated.len(), 1);

        let second = checker
            .specialize_program(vec![call_generic(
                function_id,
                original_fun_idx,
                ty_var,
                typed_arg(1001, Ty::Int),
            )])
            .expect("second specialization should succeed");

        assert!(
            generated_def_fun_idxs(&second, "Global::id").is_empty(),
            "incremental reuse should not emit another specialization def"
        );
        assert_eq!(app_fun_idxs(&second), first_generated);
    }

    #[test]
    fn ordinary_specialization_rejects_missing_call_substitution() {
        let mut checker = Checker::new(TypecheckContext::default());
        let def = generic_identity_def(
            20,
            resolved_id("id", Some("Global::id"), 10),
            resolved_id("x", None, 11),
            1,
        );
        let callable = generic_identity_ty(20, 1);
        let error = checker
            .infer_specialization_mapping(
                &def,
                &[typed_arg(12, Ty::Int)],
                Some(&callable),
                false,
                &[1],
            )
            .expect_err("ordinary calls must retain the solver substitution");
        assert!(error.message.contains("Missing call substitution"));
    }

    #[test]
    fn named_extractor_specialization_rejects_missing_saved_substitution() {
        let mut checker = Checker::new(TypecheckContext::default());
        let id = resolved_id("relay", Some("Int::relay"), 10);
        let definitions = HashMap::from([(
            20,
            Arc::new(generic_identity_def(
                20,
                id.clone(),
                resolved_id("source", None, 11),
                1,
            )),
        )]);
        let requirements = HashMap::from([(
            20,
            CallableSpecializationRequirements {
                tyvars: vec![1],
                requires_concrete: true,
            },
        )]);
        let needs = HashSet::from([20]);
        let mut instances = HashMap::new();
        let mut generated = Vec::new();
        let mut context = SpecializationContext {
            defs_by_fun_idx: &definitions,
            bound_tyvars_by_fun_idx: &requirements,
            needs_specialization: &needs,
            specialization_fun_idxs: &mut instances,
            generated_defs: &mut generated,
        };
        let error = checker
            .specialize_extractor_head(&id, generic_identity_ty(20, 1), &mut context)
            .expect_err("named heads must retain their solver substitution");
        assert!(error.message.contains("Missing call substitution"));
        assert!(generated.is_empty());
    }

    #[test]
    fn specialization_mapping_rejects_argument_count_mismatch_before_zip() {
        let mut checker = Checker::new(TypecheckContext::default());
        let def = generic_identity_def(
            20,
            resolved_id("id", Some("Global::id"), 10),
            resolved_id("x", None, 11),
            1,
        );

        let err = checker
            .infer_specialization_mapping(&def, &[], None, false, &[1])
            .expect_err("specialization must not infer from a partial argument zip");

        assert_eq!(
            err.message,
            "Cannot specialize call: expected 1 argument(s), got 0"
        );
    }

    #[test]
    fn trait_specialization_requires_complete_concrete_solver_substitution() {
        let checker = Checker::new(TypecheckContext::default());
        let def = generic_identity_def(
            20,
            resolved_id("id", Some("Global::id"), 10),
            resolved_id("x", None, 11),
            1,
        );
        for mapping in [
            HashMap::new(),
            HashMap::from([(1, Ty::List(Box::new(Ty::Var(2))))]),
        ] {
            let error = checker
                .trait_specialization_arguments(&def, &[1], &mapping)
                .expect_err("missing or nested unresolved solver substitutions must fail");
            assert!(error
                .message
                .contains("Incomplete trait method substitution"));
        }
        let mapping = HashMap::from([(1, Ty::List(Box::new(Ty::Int))), (2, Ty::Bool)]);
        assert_eq!(
            checker
                .trait_specialization_arguments(&def, &[1], &mapping)
                .unwrap(),
            vec![Ty::List(Box::new(Ty::Int))],
            "impl head variables outside the body binders must not invalidate the substitution",
        );
    }

    #[test]
    fn callable_instantiations_with_equal_display_names_remain_distinct() {
        let checker = Checker::new(TypecheckContext::default());
        let first = generic_identity_def(
            20,
            resolved_id("same", Some("Global::same"), 10),
            resolved_id("x", None, 11),
            1,
        );
        let second = generic_identity_def(
            21,
            resolved_id("same", Some("Global::same"), 12),
            resolved_id("x", None, 13),
            2,
        );
        assert_ne!(
            checker
                .specialization_key_for_def(&first, &[Ty::Int], &HashMap::from([(1, Ty::Int)]))
                .unwrap(),
            checker
                .specialization_key_for_def(&second, &[Ty::Int], &HashMap::from([(2, Ty::Int)]))
                .unwrap(),
            "canonical declaration identity must distinguish callables"
        );
    }

    #[test]
    fn specialization_keys_distinguish_structural_type_arguments() {
        let mut checker = Checker::new(TypecheckContext::default());
        checker.env.next_fun_idx = 100;
        let ty_var = 1;
        let original_fun_idx = 20;
        let function_id = resolved_id("id", Some("Global::id"), 10);
        let param_id = resolved_id("x", None, 11);
        let original_def =
            generic_identity_def(original_fun_idx, function_id.clone(), param_id, ty_var);

        let box_int = Ty::Struct(
            "Global::Box".to_string(),
            NominalType::new(vec![Ty::Int], vec![("value".to_string(), Ty::Int)]),
        );
        let box_string = Ty::Struct(
            "Global::Box".to_string(),
            NominalType::new(vec![Ty::Str], vec![("value".to_string(), Ty::Str)]),
        );
        let typed = checker
            .specialize_program(vec![
                original_def,
                call_generic(
                    function_id.clone(),
                    original_fun_idx,
                    ty_var,
                    typed_arg(1000, box_int),
                ),
                call_generic(
                    function_id,
                    original_fun_idx,
                    ty_var,
                    typed_arg(1001, box_string),
                ),
            ])
            .expect("specialization should succeed");

        let generated = generated_def_fun_idxs(&typed, "Global::id");
        assert_eq!(generated.len(), 2);
        let app_fun_idxs = app_fun_idxs(&typed);
        assert_eq!(app_fun_idxs.len(), 2);
        assert_ne!(app_fun_idxs[0], app_fun_idxs[1]);
    }
}
