use diagnostics::{StructuredDiagnostic, TypeDiagnosticReason};
use spire::ast::Span;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeError {
    pub message: String,
    pub span: Span,
    pub hint: Option<String>,
    /// Structured facts are populated incrementally by migrated checker
    /// families. `None` is the explicit legacy-message boundary.
    pub structured: Option<StructuredDiagnostic>,
}

impl TypeError {
    pub fn from_structured(diagnostic: StructuredDiagnostic) -> Self {
        let spec = diagnostics::structured_type_error_spec(&diagnostic);
        Self {
            message: spec.message,
            span: diagnostic.primary.span.clone(),
            hint: diagnostic.remediation_text(),
            structured: Some(diagnostic),
        }
    }

    pub fn reason(&self) -> Option<TypeDiagnosticReason> {
        self.structured
            .as_ref()
            .and_then(|diagnostic| diagnostic.reason.type_reason())
    }

    pub fn new(message: impl Into<String>, span: Span) -> Self {
        Self {
            message: message.into(),
            span,
            hint: None,
            structured: None,
        }
    }

    pub(crate) fn at_span(mut self, span: &Span) -> Self {
        self.span = span.clone();
        if let Some(diagnostic) = &mut self.structured {
            diagnostic.primary.span = span.clone();
        }
        self
    }

    pub fn with_hint(mut self, hint: impl Into<String>) -> Self {
        let hint = hint.into();
        if let Some(diagnostic) = &mut self.structured {
            diagnostic.remediation = Some(diagnostics::Remediation::Help { text: hint.clone() });
        }
        self.hint = Some(hint);
        self
    }

    pub fn with_structured(mut self, diagnostic: StructuredDiagnostic) -> Self {
        self.structured = Some(diagnostic);
        self
    }
}

impl std::fmt::Display for TypeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "TypeError at {}..{}: {}",
            self.span.start, self.span.end, self.message
        )?;
        if let Some(hint) = &self.hint {
            write!(f, "\n  hint: {}", hint)?;
        }
        Ok(())
    }
}

impl std::error::Error for TypeError {}
