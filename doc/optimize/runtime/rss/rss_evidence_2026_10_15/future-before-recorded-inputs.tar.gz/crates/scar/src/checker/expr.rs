use super::*;
use diagnostics::{
    CandidateFailureData, CandidateSelectionData, DiagnosticData, DiagnosticOrigin, SourceFact,
    SourceId, SourceRole, StructuredDiagnostic, TypeConstructorCarrierData, TypeDiagnosticReason,
};
use sindr::names::{ConstructorCapturePolicy, FacetRootKind};
use sindr::primitives::int;
use spire::ast::Symbol;
use std::sync::atomic::{AtomicU32, Ordering};

mod do_block;
mod lazy_calls;

static SYNTHETIC_RANGE_UID: AtomicU32 = AtomicU32::new(3_000_000_000);

/// A source Lazy input before its single closure shell is consumed.
/// Shells describe evaluation semantics; they do not each require a runtime allocation.
pub(super) struct LazyInput {
    pub(super) node: TypedNode,
    /// A direct capture parameter, including its grouping, already denotes a normalized input.
    placeholder: bool,
    /// A bare call contributes one delayed shell regardless of its return type.
    call_shell: bool,
}

enum FacetPathInput<'a> {
    Expr(&'a Resolved),
    Capture(PendingFacetPath),
}

enum OrderedCallArgument<'a> {
    Present(&'a Resolved),
    Missing(&'a str),
}

#[derive(Clone, Copy)]
enum CallArgumentMode {
    User {
        defer_constructor_conflicts: bool,
        callee_uid: u32,
    },
    Positional,
}

struct PreparedFacetInput {
    typed_source: TypedNode,
    source_is_result: bool,
    path: TypedFacetPath,
}

#[derive(Clone)]
struct TraitInvocationContext<'a> {
    span: &'a Span,
    trait_name: &'a str,
    method_name: &'a str,
    args: &'a [ResolvedRecordLitArg],
    receiver_owner_hint: Option<&'a str>,
    expected_ret_ty: Option<&'a Ty>,
    expected_ret_relation: Option<(&'a ExpectedTypeRelation, &'a Span)>,
    argument_expected_relation: Option<&'a ExpectedTypeRelation>,
    constructor_failure_reason: Option<TypeDiagnosticReason>,
    explicit_type_args: Option<&'a [AstTy]>,
    operator: Option<OperatorTraitOp>,
    receiver_hint: Option<&'a Ty>,
    defer_incompatible_result_context: bool,
}

struct PreparedTraitInvocation {
    param_tys: Vec<Ty>,
    ret_ty: Ty,
    trait_arg_tys: Vec<Ty>,
    self_ty: Ty,
    declared_param_tys: Vec<Ty>,
    constructor_receiver_index: Option<usize>,
    prepared_args: Vec<Option<TypedNode>>,
}

enum TraitInvocationPreparation {
    Complete(TypedNode),
    Arguments(PreparedTraitInvocation),
}

struct CheckedSafeBindInput {
    typed_pattern: TypedPattern,
    pattern_ty: Ty,
    typed_rhs: TypedNode,
    projection: SafeBindRhsProjection,
    propagated_error_tys: Vec<Ty>,
}

#[derive(Clone)]
pub(super) struct ExpectedTypeRelation {
    span: Span,
    role: SourceRole,
    reason: TypeDiagnosticReason,
    origin: DiagnosticOrigin,
    callable: &'static str,
    ordinal: u32,
    explicit_carrier_span: Option<Span>,
    synthetic_do_match_pending: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum DoStatementKind {
    Monadic,
    Plain,
}

#[derive(Clone, Copy)]
enum CompositionOperator {
    Plain,
    Lifted,
    Kleisli,
}

impl ExpectedTypeRelation {
    fn contextual(span: &Span) -> Self {
        Self {
            span: span.clone(),
            role: SourceRole::Expected,
            reason: TypeDiagnosticReason::TypePayloadMismatch,
            origin: DiagnosticOrigin::Intrinsic,
            callable: "do",
            ordinal: 0,
            explicit_carrier_span: None,
            synthetic_do_match_pending: false,
        }
    }

    fn function_return(span: &Span) -> Self {
        Self {
            span: span.clone(),
            role: SourceRole::Expected,
            reason: TypeDiagnosticReason::ReturnTypeMismatch,
            origin: DiagnosticOrigin::Return,
            callable: "function",
            ordinal: 0,
            explicit_carrier_span: None,
            synthetic_do_match_pending: false,
        }
    }

    fn annotation(span: &Span) -> Self {
        Self {
            span: span.clone(),
            role: SourceRole::Annotation,
            reason: TypeDiagnosticReason::AnnotationTypeMismatch,
            origin: DiagnosticOrigin::Annotation,
            callable: "binding",
            ordinal: 0,
            explicit_carrier_span: None,
            synthetic_do_match_pending: false,
        }
    }

    fn return_type_argument(span: &Span) -> Self {
        Self {
            span: span.clone(),
            role: SourceRole::ReturnTypeArgument,
            reason: TypeDiagnosticReason::ReturnTypeArgumentMismatch,
            origin: DiagnosticOrigin::ReturnTypeArgument { ordinal: 0 },
            callable: "do",
            ordinal: 0,
            explicit_carrier_span: Some(span.clone()),
            synthetic_do_match_pending: false,
        }
    }

    fn for_do_continuation(&self) -> Self {
        let mut relation = self.clone();
        relation.synthetic_do_match_pending = true;
        relation
    }

    fn after_synthetic_do_match(&self) -> Self {
        let mut relation = self.clone();
        relation.synthetic_do_match_pending = false;
        relation
    }
}

#[derive(Clone, Copy)]
enum ExpectedCallableSlot {
    Plain,
    Contextual,
}

struct ExpectedCallableContract {
    input: Ty,
    ret: Option<Ty>,
    slot: ExpectedCallableSlot,
}

#[derive(Clone)]
pub(super) struct CandidateProbeCheckpoint {
    lazy_capture_bindings: HashMap<u32, LazyCaptureDiagnostic>,
    active_lazy_capture: Option<ActiveLazyCapture>,
    env: TypeEnv,
    substitutions: HashMap<u32, Ty>,
    tyvar_bounds: HashMap<u32, Vec<String>>,
    pending_trait_obligations: HashMap<u32, Vec<PendingTraitObligation>>,
    active_capabilities: Vec<CapabilityUse>,
    constructor_capabilities: HashMap<u32, ConstructorCapabilityProvenance>,
    explicit_closure_parameters: HashMap<u32, Ty>,
    constructor_witness_traits: HashMap<u32, String>,
    process_marker_tyvars: HashSet<u32>,
    safe_operator_results: HashMap<(usize, usize), SourceFact>,
    warnings: WarningBuffer,
    pattern_binding_aliases: HashMap<u32, Option<ResolvedId>>,
}

impl Checker {
    fn type_contains_constructor_application(ty: &Ty) -> bool {
        match ty {
            Ty::SelfApp(items) => Self::constructor_application_parts(items).is_some(),
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => Self::type_contains_constructor_application(inner),
            Ty::Tuple(items) => items
                .iter()
                .any(Self::type_contains_constructor_application),
            Ty::Func(parameters, ret)
            | Ty::BuiltinFunc {
                params: parameters,
                ret,
                ..
            }
            | Ty::UserFunc {
                params: parameters,
                ret,
                ..
            } => {
                parameters
                    .iter()
                    .any(Self::type_contains_constructor_application)
                    || Self::type_contains_constructor_application(ret)
            }
            Ty::Facet(_, source, focus, update_source, update_focus) => [
                source.as_ref(),
                focus.as_ref(),
                update_source.as_ref(),
                update_focus.as_ref(),
            ]
            .into_iter()
            .any(Self::type_contains_constructor_application),
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                nominal
                    .arguments
                    .iter()
                    .any(Self::type_contains_constructor_application)
                    || nominal
                        .iter()
                        .any(|(_, field)| Self::type_contains_constructor_application(field))
            }
            Ty::Enum(_, arguments) => arguments
                .iter()
                .any(Self::type_contains_constructor_application),
            Ty::Result(ok, error) => {
                Self::type_contains_constructor_application(ok)
                    || Self::type_contains_constructor_application(error)
            }
            Ty::Var(_)
            | Ty::Hole
            | Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::ProcessMarker(_) => false,
        }
    }

    fn unresolved_constructor_application_in_type(
        &self,
        ty: &Ty,
    ) -> Option<ConstructorApplicationOutcome> {
        match ty {
            Ty::SelfApp(items) => {
                let Some((source, slots)) = Self::constructor_application_parts(items) else {
                    return Some(ConstructorApplicationOutcome::Rejected {
                        failures: vec![ConstructorProjectionFailure::UnsupportedConstructor],
                    });
                };
                let resolved_witness = self.resolve_ty(source);
                let resolved_slots = slots
                    .iter()
                    .map(|slot| self.resolve_ty(slot))
                    .collect::<Vec<_>>();
                match self.apply_constructor_application(source, &resolved_witness, &resolved_slots)
                {
                    ConstructorApplicationOutcome::Applied(applied) => {
                        self.unresolved_constructor_application_in_type(&applied)
                    }
                    outcome => Some(outcome),
                }
            }
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => self.unresolved_constructor_application_in_type(inner),
            Ty::Tuple(items) => items
                .iter()
                .find_map(|item| self.unresolved_constructor_application_in_type(item)),
            Ty::Func(parameters, ret) => parameters
                .iter()
                .find_map(|parameter| self.unresolved_constructor_application_in_type(parameter))
                .or_else(|| self.unresolved_constructor_application_in_type(ret)),
            // User and builtin callable signatures are declaration schemes. Their
            // constructor applications are instantiated at each executable call
            // site, so they are not unresolved runtime values by themselves.
            Ty::BuiltinFunc { .. } | Ty::UserFunc { .. } => None,
            Ty::Facet(_, source, focus, update_source, update_focus) => [
                source.as_ref(),
                focus.as_ref(),
                update_source.as_ref(),
                update_focus.as_ref(),
            ]
            .into_iter()
            .find_map(|part| self.unresolved_constructor_application_in_type(part)),
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => nominal
                .arguments
                .iter()
                .find_map(|argument| self.unresolved_constructor_application_in_type(argument))
                .or_else(|| {
                    nominal.iter().find_map(|(_, field)| {
                        self.unresolved_constructor_application_in_type(field)
                    })
                }),
            Ty::Enum(_, arguments) => arguments
                .iter()
                .find_map(|argument| self.unresolved_constructor_application_in_type(argument)),
            Ty::Result(ok, error) => self
                .unresolved_constructor_application_in_type(ok)
                .or_else(|| self.unresolved_constructor_application_in_type(error)),
            Ty::Var(_)
            | Ty::Hole
            | Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::ProcessMarker(_) => None,
        }
    }

    pub(super) fn unresolved_executable_constructor_application(
        &self,
        node: &TypedNode,
    ) -> Option<(ConstructorApplicationOutcome, Span)> {
        if let Some(pending) = Self::pattern_expression_nodes(node)
            .into_iter()
            .find_map(|expr| self.unresolved_executable_constructor_application(expr))
        {
            return Some(pending);
        }
        let declaration_scheme_has_constructor_application =
            match &node.node {
                TypedInner::TraitDef(..)
                | TypedInner::TraitImplDef(..)
                | TypedInner::PendingFacetPath(_)
                | TypedInner::StructDef(..)
                | TypedInner::RecordDef(..)
                | TypedInner::EnumDef(..) => return None,
                TypedInner::Def(_, _, return_arguments, parameters, ret, _, _, _)
                    if return_arguments.iter().any(|argument| {
                        Self::type_contains_constructor_application(&argument.ty)
                    }) || parameters.iter().any(|parameter| {
                        Self::type_contains_constructor_application(&parameter.ty)
                    }) || Self::type_contains_constructor_application(ret) =>
                {
                    true
                }
                _ => false,
            };
        // A generic declaration scheme may retain abstract constructor
        // applications, but its specialized executable body may not.  Skip
        // only the declaration node's own type and continue into the body.
        if !declaration_scheme_has_constructor_application {
            if let Some(outcome) = self.unresolved_constructor_application_in_type(&node.ty) {
                return Some((outcome, node.span.clone()));
            }
        }
        let recurse = |child: &TypedNode| self.unresolved_executable_constructor_application(child);
        if let Some(found) = node.monad_fail_call().and_then(recurse) {
            return Some(found);
        }
        match &node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => recurse(message).or_else(|| payload.iter().find_map(recurse)),
            TypedInner::TraitCall {
                receiver_ty, args, ..
            } => self
                .unresolved_constructor_application_in_type(receiver_ty)
                .map(|outcome| (outcome, node.span.clone()))
                .or_else(|| args.iter().find_map(recurse)),
            TypedInner::App(function, arguments)
            | TypedInner::InjectCall(function, arguments)
            | TypedInner::Capture(function, arguments) => {
                recurse(function).or_else(|| arguments.iter().find_map(recurse))
            }
            TypedInner::Block(items)
            | TypedInner::TupleLiteral(items)
            | TypedInner::ListLiteral(items)
            | TypedInner::ConstructorCall(_, items)
            | TypedInner::StructLit(_, items) => items.iter().find_map(recurse),
            TypedInner::HashMapLiteral(entries) => entries
                .iter()
                .find_map(|(key, value)| recurse(key).or_else(|| recurse(value))),
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs)
            | TypedInner::FieldAccess(rhs, _)
            | TypedInner::EagerBoundary(rhs) => recurse(rhs),
            TypedInner::DoSafeBind(control) => recurse(&control.rhs)
                .or_else(|| match &control.failure_target {
                    SafeBindFailureTarget::DoAlternative { empty } => recurse(empty),
                    _ => None,
                })
                .or_else(|| recurse(&control.continuation)),
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right)
            | TypedInner::Cause(left, right) => recurse(left).or_else(|| recurse(right)),
            TypedInner::If(condition, then_branch, else_branch) => recurse(condition)
                .or_else(|| recurse(then_branch))
                .or_else(|| else_branch.as_deref().and_then(recurse)),
            TypedInner::Match(scrutinee, arms) => recurse(scrutinee).or_else(|| {
                arms.iter().find_map(|arm| {
                    arm.guard
                        .as_ref()
                        .and_then(recurse)
                        .or_else(|| recurse(&arm.body))
                })
            }),
            TypedInner::InterpolatedStr(parts) => parts.iter().find_map(|part| match part {
                TypedInterpolatedPart::Text(_) => None,
                TypedInterpolatedPart::Expr(expr) => recurse(expr),
            }),
            TypedInner::Dbg(arguments) => arguments
                .iter()
                .find_map(|argument| recurse(&argument.expr)),
            TypedInner::DeferrorDef(_, _, _, _, body)
            | TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body) => recurse(body),
            TypedInner::CaptureConstructorClosure(_, _, _, body) => recurse(body),
            TypedInner::SupervisorSpawn { init, .. } => recurse(init),
            TypedInner::SupervisorAdopt { pid, .. } => recurse(pid),
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                recurse(init).or_else(|| recurse(strategy))
            }
            TypedInner::FacetView { source, .. } => recurse(source),
            TypedInner::FacetSet { source, value, .. } => {
                recurse(source).or_else(|| recurse(value))
            }
            TypedInner::FacetOver {
                source, update_fun, ..
            } => recurse(source).or_else(|| recurse(update_fun)),
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::ProcessContextHandler { .. }
            | TypedInner::SupervisorStatus { .. }
            | TypedInner::FacetPath(_)
            | TypedInner::PendingFacetPath(_)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..) => None,
        }
    }

    pub(super) fn candidate_probe_checkpoint(&self) -> CandidateProbeCheckpoint {
        #[cfg(test)]
        self.candidate_probe_checkpoint_count
            .set(self.candidate_probe_checkpoint_count.get() + 1);
        CandidateProbeCheckpoint {
            lazy_capture_bindings: self.lazy_capture_bindings.clone(),
            active_lazy_capture: self.active_lazy_capture.clone(),
            env: self.env.clone(),
            substitutions: self.substitutions.clone(),
            tyvar_bounds: self.tyvar_bounds.clone(),
            pending_trait_obligations: self.pending_trait_obligations.clone(),
            active_capabilities: self.active_capabilities.clone(),
            constructor_capabilities: self.constructor_capabilities.clone(),
            explicit_closure_parameters: self.explicit_closure_parameters.clone(),
            constructor_witness_traits: self.constructor_witness_traits.clone(),
            process_marker_tyvars: self.process_marker_tyvars.clone(),
            safe_operator_results: self.safe_operator_results.clone(),
            warnings: self.warnings.clone(),
            pattern_binding_aliases: self.pattern_binding_aliases.clone(),
        }
    }

    pub(super) fn rollback_candidate_probe(&mut self, checkpoint: CandidateProbeCheckpoint) {
        self.lazy_capture_bindings = checkpoint.lazy_capture_bindings;
        self.active_lazy_capture = checkpoint.active_lazy_capture;
        self.env = checkpoint.env;
        self.substitutions = checkpoint.substitutions;
        self.tyvar_bounds = checkpoint.tyvar_bounds;
        self.pending_trait_obligations = checkpoint.pending_trait_obligations;
        self.active_capabilities = checkpoint.active_capabilities;
        self.constructor_capabilities = checkpoint.constructor_capabilities;
        self.explicit_closure_parameters = checkpoint.explicit_closure_parameters;
        self.constructor_witness_traits = checkpoint.constructor_witness_traits;
        self.process_marker_tyvars = checkpoint.process_marker_tyvars;
        self.safe_operator_results = checkpoint.safe_operator_results;
        self.warnings = checkpoint.warnings;
        self.pattern_binding_aliases = checkpoint.pattern_binding_aliases;
    }

    fn collect_callable_value_tyvars(ty: &Ty, variables: &mut Vec<u32>) {
        match ty {
            Ty::Func(..) | Ty::ExtractorClosure(_) => Self::collect_ty_vars(ty, variables),
            Ty::List(inner) | Ty::Pid(inner) | Ty::Lazy(inner) | Ty::MatchResult(inner) => {
                Self::collect_callable_value_tyvars(inner, variables);
            }
            Ty::Tuple(items) | Ty::Enum(_, items) | Ty::SelfApp(items) => {
                for item in items {
                    Self::collect_callable_value_tyvars(item, variables);
                }
            }
            Ty::Result(ok, err) => {
                Self::collect_callable_value_tyvars(ok, variables);
                Self::collect_callable_value_tyvars(err, variables);
            }
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                for argument in &nominal.arguments {
                    Self::collect_callable_value_tyvars(argument, variables);
                }
            }
            Ty::Facet(_, source, focus, update_source, update_focus) => {
                for item in [source, focus, update_source, update_focus] {
                    Self::collect_callable_value_tyvars(item, variables);
                }
            }
            Ty::BuiltinFunc { .. }
            | Ty::UserFunc { .. }
            | Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::ProcessMarker(_)
            | Ty::Hole
            | Ty::Var(_)
            | Ty::Error => {}
        }
    }

    fn require_concrete_callable_binding(&self, ty: &Ty, span: &Span) -> Result<(), TypeError> {
        let ty = self.resolve_ty(ty);
        let mut variables = Vec::new();
        Self::collect_callable_value_tyvars(&ty, &mut variables);
        if variables
            .iter()
            .all(|variable| self.rigid_tyvars.contains(variable))
        {
            return Ok(());
        }
        Err(TypeError {
            structured: None,
            message: "Callable binding requires a concrete signature".into(),
            span: span.clone(),
            hint: Some(
                "Add a concrete callable annotation, annotate the literal parameters, or pass the callable directly to a higher-order argument with a known expected type."
                    .into(),
            ),
        })
    }

    fn parse_tuple_index_name(name: &str) -> Option<usize> {
        let suffix = name.strip_prefix('_')?;
        if suffix.is_empty() || !suffix.chars().all(|ch| ch.is_ascii_digit()) {
            return None;
        }
        suffix.parse::<usize>().ok()
    }

    pub(super) fn trait_obligations_depend_on(&self, node: &TypedNode, inputs: &[Ty]) -> bool {
        let mut permitted = Vec::new();
        for input in inputs {
            Self::collect_ty_vars(&self.resolve_ty(input), &mut permitted);
        }
        let mut waiting = Vec::new();
        for obligation in Self::full_trait_obligations(node) {
            for ty in obligation
                .trait_args
                .iter()
                .chain(std::iter::once(&obligation.receiver))
            {
                Self::collect_ty_vars(&self.resolve_ty(ty), &mut waiting);
            }
        }
        !waiting.is_empty() && waiting.iter().all(|var| permitted.contains(var))
    }

    fn local_callable_obligations_depend_on(&self, node: &TypedNode, inputs: &[Ty]) -> bool {
        Self::full_trait_obligations(node)
            .iter()
            .all(|obligation| !matches!(self.resolve_ty(&obligation.receiver), Ty::Var(_)))
            && self.trait_obligations_depend_on(node, inputs)
    }

    pub(super) fn validate_pending_body_dependencies(
        &self,
        body: &TypedNode,
        inputs: &[Ty],
    ) -> Result<(), TypeError> {
        if self.trait_obligations_depend_on(body, inputs) {
            return Ok(());
        }
        if let Some((trait_name, method, subject, span)) = self.first_pending_trait_helper(body) {
            return Err(self.pending_trait_helper_error(trait_name, method, subject, span));
        }
        Ok(())
    }

    pub(super) fn pending_trait_helper_error(
        &self,
        trait_name: &str,
        method_name: &str,
        subject: &Ty,
        span: &Span,
    ) -> TypeError {
        self.trait_dispatch_failure(TypeDiagnosticReason::UnresolvedTraitMethodInstantiation, trait_name, method_name, Some(subject), span)
            .with_hint("Add parameter or binding type annotations, or pass the callable where an expected function type is available.")
    }

    pub(super) fn constructor_capability_allows(
        &self,
        actual: &str,
        required: &str,
        visiting: &mut HashSet<String>,
    ) -> bool {
        if actual == required || !visiting.insert(actual.to_string()) {
            return actual == required;
        }
        let allowed = self.traits.get(actual).is_some_and(|info| {
            info.parents.iter().any(|parent| {
                let parent_key = parent
                    .trait_id
                    .qualified_name
                    .as_deref()
                    .unwrap_or(parent.trait_id.name.as_str());
                self.constructor_capability_allows(parent_key, required, visiting)
            })
        });
        visiting.remove(actual);
        allowed
    }

    fn check_constructor_capability(
        &self,
        required_trait: &str,
        method_name: &str,
        arg: &TypedNode,
        failure_reason: Option<TypeDiagnosticReason>,
    ) -> Result<(), TypeError> {
        let actual = self.constructor_capability_for_node(arg);
        let Some(required_info) = self.traits.get(required_trait) else {
            return Ok(());
        };
        if required_info.constructor_slots.is_empty() {
            return Ok(());
        }
        if let Some(outcome) = self.constructor_provenance_application_outcome(&actual) {
            self.require_constructor_projection_type(
                outcome,
                required_trait,
                &arg.ty,
                &arg.span,
                method_name,
            )?;
        }
        if self
            .constructor_provenance_allows(&actual, required_trait, &arg.ty)
            .map_err(|error| error.at_span(&arg.span))?
        {
            return Ok(());
        }
        Err(self.trait_failure(
            failure_reason.unwrap_or(TypeDiagnosticReason::MissingTypeConstructorCapability),
            required_trait,
            &arg.ty,
            &arg.span,
            DiagnosticOrigin::TraitCall,
        ))
    }

    fn constructor_capability_failure_reason(&self, ty: &Ty) -> TypeDiagnosticReason {
        match self.resolve_ty(ty) {
            Ty::SelfApp(items)
                if Self::constructor_application_parts(&items).is_some_and(|(witness, _)| {
                    matches!(self.resolve_ty(witness), Ty::Var(var) if self.rigid_tyvars.contains(&var))
                }) =>
            {
                TypeDiagnosticReason::MissingGenericBound
            }
            _ => TypeDiagnosticReason::MissingTypeConstructorCapability,
        }
    }

    pub(super) fn constructor_annotation_compatible(
        &mut self,
        trait_key: &str,
        expected: &Ty,
        actual: &Ty,
    ) -> Result<bool, TypeError> {
        let expected = self.resolve_ty(expected);
        let actual = self.resolve_ty(actual);
        // A concrete value can expose a constructor capability. An abstract
        // caller-owned carrier cannot be chosen by a nominal body annotation.
        let Ty::SelfApp(items) = &expected else {
            return Ok(false);
        };
        let Some((_, abstract_slots)) = Self::constructor_application_parts(items) else {
            return Ok(false);
        };
        let concrete_slots = match self
            .constructor_application_slots_for_trait(trait_key, &actual)
            .into_checked()?
        {
            ConstructorSlotsOutcome::Projected(slots) => slots,
            ConstructorSlotsOutcome::Deferred { .. } | ConstructorSlotsOutcome::Rejected { .. } => {
                return Ok(false)
            }
        };
        if abstract_slots.len() != concrete_slots.len() {
            return Ok(false);
        }

        let substitutions = self.substitutions.clone();
        let slots_ok = try_all(
            abstract_slots.iter().zip(concrete_slots.iter()),
            |(expected_slot, actual_slot)| self.types_compatible(expected_slot, actual_slot),
        );
        self.substitutions = substitutions;
        slots_ok
    }

    fn check_expected_constructor_capability(
        &self,
        expected: &Ty,
        callee_label: &str,
        arg: &TypedNode,
    ) -> Result<(), TypeError> {
        self.check_parameter_constructor_provenance(expected, arg, callee_label)
    }

    fn check_trait_method_constructor_capabilities(
        &self,
        trait_name: &str,
        method_name: &str,
        param_tys: &[Ty],
        receiver_index: Option<usize>,
        args: &[TypedNode],
        failure_reason: Option<TypeDiagnosticReason>,
    ) -> Result<(), TypeError> {
        for (index, (expected, arg)) in param_tys.iter().zip(args).enumerate() {
            if receiver_index == Some(index) {
                self.check_constructor_capability(trait_name, method_name, arg, failure_reason)?;
                continue;
            }
            if !matches!(expected, Ty::SelfApp(items)
                if Self::constructor_application_parts(items).is_some())
            {
                continue;
            }
            let required_trait = self
                .constructor_capability_for_type(expected)
                .unwrap_or_else(|| trait_name.to_string());
            self.check_constructor_capability(&required_trait, method_name, arg, failure_reason)?;
        }
        Ok(())
    }

    pub(super) fn first_pending_trait_helper<'a>(
        &self,
        node: &'a TypedNode,
    ) -> Option<(&'a str, &'a str, &'a Ty, &'a Span)> {
        self.find_typed_node(node, &|_, node| match &node.node {
            TypedInner::TraitCall {
                trait_name,
                method_name,
                receiver_ty,
                dispatch,
                ..
            } if matches!(dispatch, crate::typed::TraitDispatch::Pending) => Some((
                trait_name.as_str(),
                method_name.as_str(),
                receiver_ty,
                &node.span,
            )),
            _ => None,
        })
    }

    pub(super) fn typed_facet_path_expression_nodes(
        path: &TypedFacetPath,
    ) -> impl Iterator<Item = &TypedNode> {
        path.segments.iter().flat_map(|segment| {
            let nodes: [Option<&TypedNode>; 2] = match segment {
                TypedFacetSegment::ListIndex { index, .. }
                | TypedFacetSegment::MapKey { key: index, .. } => [Some(index), None],
                TypedFacetSegment::ListRange { start, end, .. } => [Some(start), Some(end)],
                TypedFacetSegment::Field { .. }
                | TypedFacetSegment::Tuple { .. }
                | TypedFacetSegment::ReadonlyBuiltin { .. }
                | TypedFacetSegment::ErrorPayload { .. }
                | TypedFacetSegment::Variant { .. } => [None, None],
            };
            nodes.into_iter().flatten()
        })
    }

    pub(super) fn pending_facet_path_expression_nodes(
        path: &PendingFacetPath,
    ) -> impl Iterator<Item = &TypedNode> {
        fn typed_expr(expr: &PendingFacetExpr) -> Option<&TypedNode> {
            match expr {
                PendingFacetExpr::Typed(node) => Some(node),
                PendingFacetExpr::Resolved(_) => None,
            }
        }
        path.segments.iter().flat_map(|segment| {
            let nodes = match segment {
                PendingFacetSegment::Field { .. } => [None, None],
                PendingFacetSegment::Bracket { expr, .. } => [typed_expr(expr), None],
                PendingFacetSegment::RangeBracket { start, end, .. } => {
                    [typed_expr(start), typed_expr(end)]
                }
            };
            nodes.into_iter().flatten()
        })
    }

    pub(super) fn find_typed_node<'a, T>(
        &self,
        node: &'a TypedNode,
        inspect: &impl Fn(&Self, &'a TypedNode) -> Option<T>,
    ) -> Option<T> {
        if let Some(found) = inspect(self, node) {
            return Some(found);
        }
        if let Some(pending) = Self::pattern_expression_nodes(node)
            .into_iter()
            .find_map(|expr| self.find_typed_node(expr, inspect))
        {
            return Some(pending);
        }
        if let Some(found) = node
            .monad_fail_call()
            .and_then(|call| self.find_typed_node(call, inspect))
        {
            return Some(found);
        }
        match &node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => self.find_typed_node(message, inspect).or_else(|| {
                payload
                    .iter()
                    .find_map(|value| self.find_typed_node(value, inspect))
            }),
            TypedInner::TraitCall { args, .. } => args
                .iter()
                .find_map(|arg| self.find_typed_node(arg, inspect)),
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                self.find_typed_node(func, inspect).or_else(|| {
                    args.iter()
                        .find_map(|arg| self.find_typed_node(arg, inspect))
                })
            }
            TypedInner::Block(stmts)
            | TypedInner::TupleLiteral(stmts)
            | TypedInner::ListLiteral(stmts)
            | TypedInner::ConstructorCall(_, stmts)
            | TypedInner::StructLit(_, stmts) => stmts
                .iter()
                .find_map(|stmt| self.find_typed_node(stmt, inspect)),
            TypedInner::HashMapLiteral(entries) => entries.iter().find_map(|(key, value)| {
                self.find_typed_node(key, inspect)
                    .or_else(|| self.find_typed_node(value, inspect))
            }),
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs)
            | TypedInner::FieldAccess(rhs, _) => self.find_typed_node(rhs, inspect),
            TypedInner::DoSafeBind(control) => {
                self.find_typed_node(&control.rhs, inspect).or_else(|| {
                    match &control.failure_target {
                        SafeBindFailureTarget::DoAlternative { empty } => {
                            self.find_typed_node(empty, inspect)
                        }
                        _ => None,
                    }
                    .or_else(|| self.find_typed_node(&control.continuation, inspect))
                })
            }
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right) => self
                .find_typed_node(left, inspect)
                .or_else(|| self.find_typed_node(right, inspect)),
            TypedInner::If(cond, then_branch, else_branch) => self
                .find_typed_node(cond, inspect)
                .or_else(|| self.find_typed_node(then_branch, inspect))
                .or_else(|| {
                    else_branch
                        .as_deref()
                        .and_then(|branch| self.find_typed_node(branch, inspect))
                }),
            TypedInner::Cause(value, err) => self
                .find_typed_node(value, inspect)
                .or_else(|| self.find_typed_node(err, inspect)),
            TypedInner::Match(scrutinee, arms) => {
                self.find_typed_node(scrutinee, inspect).or_else(|| {
                    arms.iter().find_map(|arm| {
                        arm.guard
                            .as_ref()
                            .and_then(|guard| self.find_typed_node(guard, inspect))
                            .or_else(|| self.find_typed_node(&arm.body, inspect))
                    })
                })
            }
            TypedInner::InterpolatedStr(parts) => parts.iter().find_map(|part| match part {
                crate::typed::TypedInterpolatedPart::Text(_) => None,
                crate::typed::TypedInterpolatedPart::Expr(expr) => {
                    self.find_typed_node(expr, inspect)
                }
            }),
            TypedInner::Dbg(args) => args
                .iter()
                .find_map(|arg| self.find_typed_node(&arg.expr, inspect)),
            TypedInner::EagerBoundary(inner) => self.find_typed_node(inner, inspect),
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body) => self.find_typed_node(body, inspect),
            TypedInner::CaptureConstructorClosure(_, _, _, body) => {
                self.find_typed_node(body, inspect)
            }
            TypedInner::SupervisorSpawn { init, .. } => self.find_typed_node(init, inspect),
            TypedInner::SupervisorAdopt { pid, .. } => self.find_typed_node(pid, inspect),
            TypedInner::SupervisorWorkers { init, strategy, .. } => self
                .find_typed_node(init, inspect)
                .or_else(|| self.find_typed_node(strategy, inspect)),
            TypedInner::FacetPath(path) => Self::typed_facet_path_expression_nodes(path)
                .find_map(|expr| self.find_typed_node(expr, inspect)),
            TypedInner::PendingFacetPath(path) => Self::pending_facet_path_expression_nodes(path)
                .find_map(|expr| self.find_typed_node(expr, inspect)),
            TypedInner::FacetView { source, path, .. } => {
                self.find_typed_node(source, inspect).or_else(|| {
                    Self::typed_facet_path_expression_nodes(path)
                        .find_map(|expr| self.find_typed_node(expr, inspect))
                })
            }
            TypedInner::FacetSet {
                source,
                path,
                value,
                ..
            } => self
                .find_typed_node(source, inspect)
                .or_else(|| {
                    Self::typed_facet_path_expression_nodes(path)
                        .find_map(|expr| self.find_typed_node(expr, inspect))
                })
                .or_else(|| self.find_typed_node(value, inspect)),
            TypedInner::FacetOver {
                source,
                path,
                update_fun,
                ..
            } => self
                .find_typed_node(source, inspect)
                .or_else(|| {
                    Self::typed_facet_path_expression_nodes(path)
                        .find_map(|expr| self.find_typed_node(expr, inspect))
                })
                .or_else(|| self.find_typed_node(update_fun, inspect)),
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::ProcessContextHandler { .. }
            | TypedInner::SupervisorStatus { .. }
            | TypedInner::DeferrorDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..) => None,
        }
    }

    pub(super) fn full_trait_obligations(node: &TypedNode) -> Vec<TraitObligation> {
        fn collect(node: &TypedNode, obligations: &mut Vec<TraitObligation>) {
            if let Some(call) = node.monad_fail_call() {
                collect(call, obligations);
            }
            for expr in Checker::pattern_expression_nodes(node) {
                collect(expr, obligations);
            }
            match &node.node {
                TypedInner::ErrorConstruct {
                    message, payload, ..
                } => {
                    collect(message, obligations);
                    for value in payload {
                        collect(value, obligations);
                    }
                }
                TypedInner::TraitCall {
                    obligation, args, ..
                } => {
                    obligations.push(obligation.clone());
                    for arg in args {
                        collect(arg, obligations);
                    }
                }
                TypedInner::App(func, args)
                | TypedInner::InjectCall(func, args)
                | TypedInner::Capture(func, args) => {
                    collect(func, obligations);
                    for arg in args {
                        collect(arg, obligations);
                    }
                }
                TypedInner::Block(items)
                | TypedInner::ListLiteral(items)
                | TypedInner::TupleLiteral(items)
                | TypedInner::ConstructorCall(_, items)
                | TypedInner::StructLit(_, items) => {
                    for item in items {
                        collect(item, obligations);
                    }
                }
                TypedInner::HashMapLiteral(entries) => {
                    for (key, value) in entries {
                        collect(key, obligations);
                        collect(value, obligations);
                    }
                }
                TypedInner::DoSafeBind(control) => {
                    collect(&control.rhs, obligations);
                    if let SafeBindFailureTarget::DoAlternative { empty } = &control.failure_target
                    {
                        collect(empty, obligations);
                    }
                    collect(&control.continuation, obligations);
                }
                TypedInner::Bind(_, rhs)
                | TypedInner::ApplyPattern { value: rhs, .. }
                | TypedInner::SafeBind(_, rhs, _, _)
                | TypedInner::Semi(rhs)
                | TypedInner::FieldAccess(rhs, _)
                | TypedInner::EagerBoundary(rhs) => collect(rhs, obligations),
                TypedInner::BinOp(_, left, right)
                | TypedInner::Pipe(left, right)
                | TypedInner::Compose(_, left, right)
                | TypedInner::ListCons(left, right)
                | TypedInner::Cause(left, right) => {
                    collect(left, obligations);
                    collect(right, obligations);
                }
                TypedInner::If(cond, then_branch, else_branch) => {
                    collect(cond, obligations);
                    collect(then_branch, obligations);
                    if let Some(branch) = else_branch {
                        collect(branch, obligations);
                    }
                }
                TypedInner::Match(scrutinee, arms) => {
                    collect(scrutinee, obligations);
                    for arm in arms {
                        if let Some(guard) = &arm.guard {
                            collect(guard, obligations);
                        }
                        collect(&arm.body, obligations);
                    }
                }
                TypedInner::InterpolatedStr(parts) => {
                    for part in parts {
                        if let TypedInterpolatedPart::Expr(expr) = part {
                            collect(expr, obligations);
                        }
                    }
                }
                TypedInner::Dbg(args) => {
                    for arg in args {
                        collect(&arg.expr, obligations);
                    }
                }
                TypedInner::DeferrorDef(_, _, _, _, body)
                | TypedInner::Def(_, _, _, _, _, _, body, _)
                | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
                | TypedInner::Closure(_, _, body)
                | TypedInner::ExtractorClosure(_, _, body)
                | TypedInner::CaptureClosure(_, _, body) => collect(body, obligations),
                TypedInner::SupervisorSpawn { init, .. } => collect(init, obligations),
                TypedInner::SupervisorAdopt { pid, .. } => collect(pid, obligations),
                TypedInner::SupervisorWorkers { init, strategy, .. } => {
                    collect(init, obligations);
                    collect(strategy, obligations);
                }
                TypedInner::FacetPath(path) => {
                    for expr in Checker::typed_facet_path_expression_nodes(path) {
                        collect(expr, obligations);
                    }
                }
                TypedInner::PendingFacetPath(path) => {
                    for expr in Checker::pending_facet_path_expression_nodes(path) {
                        collect(expr, obligations);
                    }
                }
                TypedInner::FacetView { source, path, .. } => {
                    collect(source, obligations);
                    for expr in Checker::typed_facet_path_expression_nodes(path) {
                        collect(expr, obligations);
                    }
                }
                TypedInner::FacetSet {
                    source,
                    path,
                    value,
                    ..
                } => {
                    collect(source, obligations);
                    for expr in Checker::typed_facet_path_expression_nodes(path) {
                        collect(expr, obligations);
                    }
                    collect(value, obligations);
                }
                TypedInner::FacetOver {
                    source,
                    path,
                    update_fun,
                    ..
                } => {
                    collect(source, obligations);
                    for expr in Checker::typed_facet_path_expression_nodes(path) {
                        collect(expr, obligations);
                    }
                    collect(update_fun, obligations);
                }
                _ => {}
            }
        }

        let mut obligations = Vec::new();
        collect(node, &mut obligations);
        obligations
    }

    pub(super) fn concretize_pending_trait_calls(
        &mut self,
        mut node: TypedNode,
    ) -> Result<Box<TypedNode>, Box<TypeError>> {
        self.concretize_pending_trait_calls_in_place(&mut node)?;
        Ok(Box::new(node))
    }

    // Borrow children in place: rebuilding the large enum at every level keeps
    // all variant temporaries live on the stack of long continuation chains.
    fn concretize_pending_trait_calls_in_place(
        &mut self,
        node: &mut TypedNode,
    ) -> Result<(), Box<TypeError>> {
        for expr in Self::pattern_expression_nodes_mut(node) {
            self.concretize_pending_trait_calls_in_place(expr)?;
        }
        match &mut node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => {
                self.concretize_pending_trait_calls_in_place(message)?;
                for value in payload {
                    self.concretize_pending_trait_calls_in_place(value)?;
                }
            }
            TypedInner::SafeBind(
                _,
                _,
                _,
                SafeBindFailureTarget::EnclosingMonadFail(target)
                | SafeBindFailureTarget::DoMonadFail(target),
            ) => self.concretize_pending_trait_calls_in_place(&mut target.call)?,
            TypedInner::DoSafeBind(control) => {
                if let SafeBindFailureTarget::DoMonadFail(target) = &mut control.failure_target {
                    self.concretize_pending_trait_calls_in_place(&mut target.call)?;
                }
            }
            _ => {}
        }
        node.ty = self.resolve_ty(&node.ty);
        match &mut node.node {
            TypedInner::TraitCall {
                receiver_ty,
                obligation,
                args,
                dispatch,
                method_name,
                ..
            } => {
                *receiver_ty = self.resolve_ty(receiver_ty);
                obligation.trait_args = obligation
                    .trait_args
                    .iter()
                    .map(|ty| self.resolve_ty(ty))
                    .collect();
                obligation.receiver = self.resolve_ty(&obligation.receiver);
                for arg in args.iter_mut() {
                    self.concretize_pending_trait_calls_in_place(arg)?;
                }
                self.concretize_trait_dispatch(
                    &node.span,
                    &node.ty,
                    method_name,
                    obligation,
                    args,
                    dispatch,
                )?;
            }
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                self.concretize_pending_trait_calls_in_place(func)?;
                for arg in args {
                    self.concretize_pending_trait_calls_in_place(arg)?;
                }
            }
            TypedInner::Block(items)
            | TypedInner::TupleLiteral(items)
            | TypedInner::ListLiteral(items)
            | TypedInner::ConstructorCall(_, items)
            | TypedInner::StructLit(_, items) => {
                for item in items {
                    self.concretize_pending_trait_calls_in_place(item)?;
                }
            }
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::EagerBoundary(rhs)
            | TypedInner::FieldAccess(rhs, _)
            | TypedInner::Semi(rhs)
            | TypedInner::SupervisorSpawn { init: rhs, .. }
            | TypedInner::SupervisorAdopt { pid: rhs, .. }
            | TypedInner::FacetView { source: rhs, .. }
            | TypedInner::Closure(_, _, rhs)
            | TypedInner::ExtractorClosure(_, _, rhs)
            | TypedInner::CaptureClosure(_, _, rhs)
            | TypedInner::DeferrorDef(_, _, _, _, rhs)
            | TypedInner::Def(_, _, _, _, _, _, rhs, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, rhs, _) => {
                self.concretize_pending_trait_calls_in_place(rhs)?;
            }
            TypedInner::DoSafeBind(control) => {
                self.concretize_pending_trait_calls_in_place(&mut control.rhs)?;
                match &mut control.failure_target {
                    SafeBindFailureTarget::DoAlternative { empty } => {
                        self.concretize_pending_trait_calls_in_place(empty)?
                    }
                    SafeBindFailureTarget::Deferred(deferred) => {
                        deferred.carrier_ty = self.resolve_ty(&deferred.carrier_ty);
                        deferred.propagated_error_tys = deferred
                            .propagated_error_tys
                            .iter()
                            .map(|ty| self.resolve_ty(ty))
                            .collect();
                    }
                    _ => {}
                }
                self.concretize_pending_trait_calls_in_place(&mut control.continuation)?;
            }
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right)
            | TypedInner::Cause(left, right)
            | TypedInner::SupervisorWorkers {
                init: left,
                strategy: right,
                ..
            }
            | TypedInner::FacetSet {
                source: left,
                value: right,
                ..
            }
            | TypedInner::FacetOver {
                source: left,
                update_fun: right,
                ..
            } => {
                self.concretize_pending_trait_calls_in_place(left)?;
                self.concretize_pending_trait_calls_in_place(right)?;
            }
            TypedInner::HashMapLiteral(entries) => {
                for (key, value) in entries {
                    self.concretize_pending_trait_calls_in_place(key)?;
                    self.concretize_pending_trait_calls_in_place(value)?;
                }
            }
            TypedInner::InterpolatedStr(parts) => {
                for part in parts {
                    if let crate::typed::TypedInterpolatedPart::Expr(expr) = part {
                        self.concretize_pending_trait_calls_in_place(expr)?;
                    }
                }
            }
            TypedInner::Dbg(args) => {
                for arg in args {
                    self.concretize_pending_trait_calls_in_place(&mut arg.expr)?;
                }
            }
            TypedInner::If(condition, then_branch, else_branch) => {
                self.concretize_pending_trait_calls_in_place(condition)?;
                self.concretize_pending_trait_calls_in_place(then_branch)?;
                if let Some(branch) = else_branch {
                    self.concretize_pending_trait_calls_in_place(branch)?;
                }
            }
            TypedInner::Match(scrutinee, arms) => {
                self.concretize_pending_trait_calls_in_place(scrutinee)?;
                for arm in arms {
                    if let Some(guard) = &mut arm.guard {
                        self.concretize_pending_trait_calls_in_place(guard)?;
                    }
                    self.concretize_pending_trait_calls_in_place(&mut arm.body)?;
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn concretize_trait_dispatch(
        &mut self,
        span: &Span,
        ty: &Ty,
        method_name: &str,
        obligation: &TraitObligation,
        args: &[TypedNode],
        dispatch: &mut TraitDispatch,
    ) -> Result<(), Box<TypeError>> {
        let abstract_constructor_receiver = match &obligation.receiver {
            Ty::SelfApp(items) => Self::constructor_application_parts(items)
                .map(|(witness, _)| {
                    self.constructor_witness_supports_trait(witness, &obligation.trait_id)
                })
                .unwrap_or(false),
            _ => false,
        };
        let mut unresolved = Vec::new();
        for ty in obligation
            .trait_args
            .iter()
            .chain(std::iter::once(&obligation.receiver))
        {
            Self::collect_ty_vars(ty, &mut unresolved);
        }
        if matches!(dispatch, TraitDispatch::Pending)
            && unresolved.is_empty()
            && !abstract_constructor_receiver
        {
            let argument_tys = args
                .iter()
                .map(|arg| self.resolve_ty(&arg.ty))
                .collect::<Vec<_>>();
            *dispatch = match self.select_trait_method_instantiation(
                &obligation.trait_id,
                method_name,
                &obligation.receiver,
                &obligation.trait_args,
                &argument_tys,
                ty,
            )? {
                CandidateApplicability::Applicable(instantiation) => {
                    TraitDispatch::Selected(Box::new(instantiation))
                }
                CandidateApplicability::Deferred(_) => TraitDispatch::Pending,
                CandidateApplicability::Rejected(_) => {
                    return Err(Box::new(self.trait_failure(
                        TypeDiagnosticReason::NoApplicableTraitImplementation,
                        &obligation.trait_id,
                        &obligation.receiver,
                        span,
                        DiagnosticOrigin::TraitCall,
                    )));
                }
            };
        }
        Ok(())
    }

    // Recursive block/callable traversal must not retain the large temporary
    // frame used to check declarations and other individual expressions.
    pub(super) fn check_node(&mut self, node: &Resolved) -> Result<TypedNode, TypeError> {
        match node {
            Resolved::Block(span, stmts) => self.check_block(span, stmts, None, None),
            Resolved::ExtractorClosure(span, params, captures, body) => {
                self.check_extractor_closure(span, params, captures, body, None, None)
            }
            Resolved::Closure(span, params, captures, body) => {
                self.check_closure(span, params, captures, body, None, None)
            }
            Resolved::CaptureClosure(span, params, captures, body) => {
                self.check_capture_closure(span, params, captures, body, None)
            }
            Resolved::Do(span, intrinsic, contract, return_type_arguments, statements) => self
                .check_do(
                    span,
                    *intrinsic,
                    contract,
                    return_type_arguments,
                    statements,
                    None,
                    None,
                ),
            Resolved::App(span, func, args) => self.check_app(span, func, args),
            Resolved::LazyApp(span, kind, func, args) => {
                self.check_lazy_app(span, *kind, func, args, None)
            }
            Resolved::Match(span, scrutinee, arms) | Resolved::IsMatch(span, scrutinee, arms) => {
                self.check_match(span, scrutinee, arms, None, None)
            }
            _ => self.check_non_structural_node(node),
        }
    }

    #[inline(never)]
    fn check_non_structural_node(&mut self, node: &Resolved) -> Result<TypedNode, TypeError> {
        match node {
            Resolved::Lit(span, lit) => {
                let ty = self.lit_type(lit);
                Ok(TypedNode {
                    ty,
                    span: span.clone(),
                    node: TypedInner::Lit(lit.clone()),
                })
            }

            Resolved::ErrorKind(span, id) => {
                if !self.env.is_error_constructor(id.unique_id) {
                    return Err(TypeError::new("ErrorKind requires a canonical deferror declaration", span.clone()));
                }
                let kind = id.qualified_name.clone().ok_or_else(|| {
                    TypeError::new("ErrorKind identity has no canonical declaration name", span.clone())
                })?;
                Ok(TypedNode {
                    ty: Ty::Enum("ErrorKind".into(), Vec::new()),
                    span: span.clone(),
                    node: TypedInner::ErrorKind(kind),
                })
            }

            Resolved::Var(span, id) => {
                let canonical = self.canonical_pattern_id(id)?;
                if canonical.unique_id != id.unique_id { return self.check_node(&Resolved::Var(span.clone(), canonical)); }
                if self.trait_method_ref(node).is_some() {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait helper `{}` cannot be referenced directly",
                            id.name
                        ),
                        span: span.clone(),
                        hint: Some(
                            "Call the helper with arguments so the receiver type can choose an impl."
                                .into(),
                        ),
                    });
                }

                if let Some(const_meta) = self.consts.get(&id.unique_id) {
                    return Ok(match &const_meta.value {
                        StoredConstValue::Literal(lit) => TypedNode {
                            ty: const_meta.ty.clone(),
                            span: span.clone(),
                            node: TypedInner::Lit(lit.clone()),
                        },
                        StoredConstValue::FacetPath(path) => TypedNode {
                            ty: const_meta.ty.clone(),
                            span: span.clone(),
                            node: TypedInner::FacetPath(path.clone()),
                        },
                    });
                }

                if let Some(stored_ty) = self.env.lookup_var(id.unique_id).cloned() {
                    let ty = match &stored_ty {
                        Ty::BuiltinFunc { .. } | Ty::UserFunc { .. } => {
                            self.instantiate_callable_ty(&stored_ty)
                        }
                        _ => self.resolve_ty(&stored_ty),
                    };
                    if matches!(ty, Ty::Facet(..)) {
                        if let Some(path) = self.facet_bindings.get(&id.unique_id).cloned() {
                            return Ok(match path {
                                StoredFacetPath::Concrete(path) => {
                                    let source_ty = self.resolve_ty(&path.source_ty);
                                    let focus_ty = self.resolve_ty(&path.focus_ty);
                                    let update_source_ty = self.resolve_ty(&path.update_source_ty);
                                    let update_focus_ty = self.resolve_ty(&path.update_focus_ty);
                                    TypedNode {
                                        ty: Ty::Facet(
                                            Self::facet_kind_from_path_kind(path.path_kind),
                                            Box::new(source_ty.clone()),
                                            Box::new(focus_ty.clone()),
                                            Box::new(update_source_ty.clone()),
                                            Box::new(update_focus_ty.clone()),
                                        ),
                                        span: span.clone(),
                                        node: TypedInner::FacetPath(TypedFacetPath {
                                            source_ty,
                                            focus_ty,
                                            update_source_ty,
                                            update_focus_ty,
                                            path_kind: path.path_kind,
                                            may_fail: path.may_fail,
                                            segments: path.segments,
                                        }),
                                    }
                                }
                                StoredFacetPath::Pending(path) => TypedNode {
                                    ty,
                                    span: span.clone(),
                                    node: TypedInner::PendingFacetPath(path),
                                },
                            });
                        }
                        return Err(TypeError {
                            structured: None,
                            message: "Facet value is not statically resolvable at this usage site"
                                .into(),
                            span: span.clone(),
                            hint: Some(
                                "Use a concrete path expression like User.name or pair._0.".into(),
                            ),
                        });
                    }
                    return Ok(TypedNode {
                        ty,
                        span: span.clone(),
                        node: TypedInner::Var(id.clone()),
                    });
                }

                if let Some(variant) = self.lookup_enum_variant_by_constructor_id(id.unique_id) {
                    let variant = self.instantiate_enum_variant(&variant);
                    if let Some(sindr::names::SpecialEnumVariantLowering::Boolean(value)) = variant.special_variant {
                        if !variant.payload.is_empty() {
                            return Err(TypeError {
                                structured: None,
                                message: format!(
                                    "Builtin Boolean variant {} unexpectedly requires payload",
                                    id.name
                                ),
                                span: span.clone(),
                                hint: None,
                            });
                        }
                        return Ok(TypedNode {
                            ty: Ty::Bool,
                            span: span.clone(),
                            node: TypedInner::Lit(Lit::Bool(value)),
                        });
                    }
                    if matches!(
                        Self::surface_name(&variant.enum_name),
                        "StopReply" | "StopReason"
                    ) && !self.stop_constructor_allowed()
                    {
                        return Err(self.stop_constructor_error(span, &variant.enum_name));
                    }
                    if !variant.payload.is_empty() {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Enum constructor {} expects {} argument(s)",
                                id.name,
                                variant.payload.len()
                            ),
                            span: span.clone(),
                            hint: Some("Call it as `Enum::Variant(...)`".into()),
                        });
                    }
                    let idx_node = TypedNode {
                        ty: Ty::Int,
                        span: span.clone(),
                        node: TypedInner::Lit(Lit::Int(variant.discriminant.clone())),
                    };
                    return Ok(TypedNode {
                        ty: self.resolve_ty(&variant.enum_ty),
                        span: span.clone(),
                        node: TypedInner::ConstructorCall(variant.tag, vec![idx_node]),
                    });
                }

                if let Some(index) = Self::parse_tuple_index_name(id.name.as_str()) {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Standalone tuple root _{} is not allowed; use tuple access with ._{}",
                            index, index
                        ),
                        span: span.clone(),
                        hint: Some("Tuple elements are accessed as value._0, value._1, ...".into()),
                    });
                }

                Err(TypeError {
                    structured: None,
                    message: format!("Undefined variable: {}", id.name),
                    span: span.clone(),
                    hint: None,
                })
            }

            Resolved::ReturnTypeArgumentApply(span, target, args) => {
                self.check_explicit_return_type_argument_apply(
                    span,
                    target,
                    &args
                        .iter()
                        .map(|argument| argument.ty.syntax.clone())
                        .collect::<Vec<_>>(),
                )
            }

            Resolved::Bind(span, pat, rhs) => {
                if !Self::is_total_bind_pattern(pat) {
                    return Err(self
                        .pattern_error(
                            TypeDiagnosticReason::NonTotalBindingPattern,
                            diagnostics::PatternKind::Other,
                            Some("=".into()),
                            None,
                            None,
                            None,
                            None,
                            Vec::new(),
                            span,
                        )
                        .with_hint(
                            "Use `=?` for partial destructuring and extractor-driven matches.",
                        ));
                }
                let inherited_error_kind = self.resolved_concrete_error_identity(rhs).map(str::to_string);
                if let ResolvedPattern::Annotated(_, ast_ty) = pat {
                    let annotation_kind = self.concrete_error_annotation_identity(ast_ty);
                    if let Some(kind) = inherited_error_kind.as_deref() {
                        if annotation_kind.as_deref() != Some(kind) {
                            return Err(TypeError::new("A narrowed Error local annotation must match its concrete declaration", Self::ast_ty_span(ast_ty).clone()));
                        }
                    } else if annotation_kind.is_some() {
                        return Err(TypeError::new("A common Error cannot be cast by a concrete Error annotation", Self::ast_ty_span(ast_ty).clone()));
                    }
                }
                let typed_rhs = if let ResolvedPattern::Annotated(_, ast_ty) = pat {
                    let expected =
                        self.resolve_ast_ty_in_context(ast_ty, if inherited_error_kind.is_some() {
                            TypeSyntaxContext::ConcreteErrorLocal
                        } else { self.local_type_syntax_context() })?;
                    let relation = ExpectedTypeRelation::annotation(Self::ast_ty_span(ast_ty));
                    let mut typed_rhs = self.check_node_with_expected_relation(
                        rhs,
                        Some(&expected),
                        Some(&relation),
                    )?;
                    self.apply_facet_annotation(&mut typed_rhs, &expected, span)?;
                    let relation = self.assert_type_relation(&expected, &typed_rhs.ty,
                        self.type_fact(SourceRole::Annotation, Self::ast_ty_span(ast_ty), &expected), self.type_fact(SourceRole::Value, &typed_rhs.span, &typed_rhs.ty),
                        TypeDiagnosticReason::AnnotationTypeMismatch, DiagnosticOrigin::Annotation, "binding", 0);
                    if let Err(error) = relation {
                        if error.reason() != Some(TypeDiagnosticReason::AnnotationTypeMismatch) {
                            return Err(error);
                        }
                        let constructor_coercion = self
                            .constructor_trait_key_for_ast_ty(ast_ty)
                            .map(|trait_key| {
                                self.constructor_annotation_compatible(
                                    &trait_key,
                                    &expected,
                                    &typed_rhs.ty,
                                )
                            }).transpose().map_err(|error| error.at_span(Self::ast_ty_span(ast_ty)))?.unwrap_or(false);
                        if constructor_coercion {
                            typed_rhs.ty = expected.clone();
                        } else {
                            return Err(error);
                        }
                    }
                    typed_rhs
                } else {
                    self.check_node(rhs)?
                };
                let typed_rhs = *self.concretize_pending_trait_calls(typed_rhs).map_err(|error| *error)?;
                if self.current_function_symbol.is_none() {
                    let can_instantiate = match self.resolve_ty(&typed_rhs.ty) {
                        Ty::Func(inputs, _) => self.local_callable_obligations_depend_on(&typed_rhs, &inputs),
                        _ => false,
                    };
                    if !can_instantiate {
                    if let Some((trait_name, method_name, subject, pending_span)) = self.first_pending_trait_helper(&typed_rhs) {
                        return Err(self.pending_trait_helper_error(trait_name, method_name, subject, pending_span));
                    }
                    }
                }
                self.require_concrete_callable_binding(&typed_rhs.ty, &typed_rhs.span).map_err(|error| self.lazy_unknown_binding_error(error, rhs))?;
                self.ensure_no_match_result_value(&typed_rhs.ty, &typed_rhs.span)?;
                let facet_path = if matches!(typed_rhs.ty, Ty::Facet(..)) {
                    Some(self.stored_facet_path_from_node(typed_rhs.clone(), span)?)
                } else {
                    None
                };
                let inherited_constructor_provenance =
                    self.constructor_capability_for_node(&typed_rhs);
                if let (Some(kind), ResolvedPattern::Annotated(binding, _)) = (&inherited_error_kind, pat) {
                    self.env.concrete_error_bindings.insert(binding.unique_id, kind.clone());
                }
                let (typed_pat, pat_ty) = self.check_pattern(pat, &typed_rhs.ty, span)?;
                self.ensure_self_rebinding_types(&typed_pat, span)?;

                self.bind_typed_pattern(&typed_pat, &self.resolve_ty(&pat_ty));
                if let Some(kind) = inherited_error_kind {
                    self.bind_local_error_identity(&typed_pat, &kind);
                }
                let binding_constructor_provenance = match pat {
                    ResolvedPattern::Annotated(_, ast_ty) => self
                        .constructor_trait_key_for_ast_ty(ast_ty)
                        .map(ConstructorCapabilityProvenance::constrained)
                        .unwrap_or(inherited_constructor_provenance),
                    _ => inherited_constructor_provenance,
                };
                self.bind_constructor_provenance(
                    &typed_pat,
                    (binding_constructor_provenance, typed_rhs.ty.clone()),
                );
                if let Some(path) = &facet_path {
                    self.bind_facet_pattern_bindings(&typed_pat, path, span)?;
                } else {
                    self.clear_facet_pattern_bindings(&typed_pat);
                }
                self.bind_lazy_capture_diagnostic(&typed_pat, rhs, &typed_rhs);
                self.normalize_env_bindings();

                Ok(TypedNode {
                    ty: Ty::Unit,
                    span: span.clone(),
                    node: TypedInner::Bind(typed_pat, Box::new(typed_rhs)),
                })
            }

            Resolved::ApplyPattern(span, value, pattern) => self.check_apply_pattern(span, value, pattern, None),
            Resolved::SafeBind(span, pat, rhs, operator_span) => self.check_safebind(span, operator_span, pat, rhs, false),
            Resolved::StatementQuestion(span, rhs) => self.check_safebind(
                span,
                span,
                &ResolvedPattern::Wildcard(span.clone()),
                rhs,
                true,
            ),

            Resolved::BinOp(span, op, left, right) => self.check_binop(span, op, left, right),
            Resolved::Pipe(span, left, right) => self.check_pipe(span, left, right),
            Resolved::ContextMap(span, left, right) => self.check_context_map(span, left, right),
            Resolved::ContextApply(span, left, right) => {
                self.check_context_apply(span, left, right)
            }
            Resolved::ContextBind(span, left, right) => self.check_context_bind(span, left, right),
            Resolved::Compose(span, left, right) => self.check_compose(span, left, right),
            Resolved::LiftedCompose(span, left, right) => {
                self.check_lifted_compose(span, left, right)
            }
            Resolved::KleisliCompose(span, left, right) => {
                self.check_kleisli_compose(span, left, right)
            }

            Resolved::ListNil(span) => self.check_list_nil(span),
            Resolved::ListCons(span, head, tail) => self.check_list_cons(span, head, tail),
            Resolved::ListLiteral(span, elems) => self.check_list_literal(span, elems),
            Resolved::HashMapLiteral(span, entries) => self.check_hash_map_literal(span, entries),
            Resolved::RangeLiteral(span, start, stop) => {
                self.check_range_literal(span, start, stop)
            }
            Resolved::TupleLiteral(span, elems) => self.check_tuple_literal(span, elems),
            Resolved::Grouped(span, inner) => {
                let mut typed = self.check_node(inner)?;
                self.propagate_safe_operator_result(&typed.span, span);
                typed.span = span.clone();
                Ok(typed)
            }

            Resolved::InterpolatedStr(span, parts) => self.check_interpolated_str(span, parts),
            Resolved::Dbg(span, args) => self.check_dbg(span, args),

            Resolved::Cond(span, clauses) => self.check_cond(span, clauses, None),
            Resolved::If(span, cond, then, else_opt) => self.check_if(span, cond, then, else_opt),
            Resolved::Cause(span, value, err) => self.check_cause(span, value, err),
            Resolved::IfLet(span, scrutinee, arms, then_only) => {
                self.check_if_let(span, scrutinee, arms, None, *then_only)
            }

            Resolved::FieldAccess(span, expr, field) => self.check_field_access(span, expr, field),
            Resolved::FacetSegmentAccess(span, expr, segment) => {
                self.check_facet_segment_access_with_expected(span, expr, segment, None)
            }
            Resolved::InferredFacetCapture(span, segments) => Err(TypeError {
                structured: None,
                message: format!(
                    "{} requires expected unary function context",
                    Self::inferred_facet_capture_display(segments)
                ),
                span: span.clone(),
                hint: Some(
                    "Use inferred capture where a unary function is expected, or use an explicit capture such as `&Type.field`."
                        .into(),
                ),
            }),
            Resolved::FacetCapture(span, _) => Err(TypeError {
                structured: None,
                message: "`~source.path` is Facet API shorthand and must be consumed as the first argument of Facet::view/preview/put/set/over/over_result".into(),
                span: span.clone(),
                hint: Some(
                    "Use the shorthand only inside a Facet API call such as `Facet::set(~user.name, value)`."
                        .into(),
                ),
            }),
            Resolved::ProcessContextHandler(span, slot) => {
                self.check_process_context_handler(span, slot)
            }

            Resolved::Semi(span, inner) => {
                let typed_inner = self.check_node(inner)?;
                Ok(TypedNode {
                    ty: Ty::Unit,
                    span: span.clone(),
                    node: TypedInner::Semi(Box::new(typed_inner)),
                })
            }

            Resolved::StructDef(span, id, type_params, fields, _) => {
                self.check_struct_def(span, id, type_params, fields)
            }
            Resolved::RecordDef(span, id, fields, _) => self.check_record_def(span, id, fields),
            Resolved::EnumDef(span, id, type_params, variants, attrs) => {
                self.check_enum_def(span, id, type_params, variants, attrs)
            }
            Resolved::StructLit(span, id, field_vals) => {
                self.check_struct_lit(span, id, field_vals)
            }
            Resolved::ConstructorCall(span, id, args) => {
                self.check_constructor_call(span, id, args, None)
            }
            Resolved::EnumConstructorCall(span, id, type_args, args) => {
                self.check_explicit_enum_constructor_call(span, id, type_args, args, None)
            }
            Resolved::DeferrorDef(span, id, fields, show_expr) => {
                self.check_deferror_def(span, id, fields, show_expr)
            }
            Resolved::Def(span, id, return_type_arguments, params, ret_ty, where_clause, body, attrs) => {
                self.check_def(
                    span,
                    id,
                    return_type_arguments,
                    params,
                    ret_ty,
                    where_clause.as_ref(),
                    body,
                    attrs,
                )
            }
            Resolved::ConstDef(span, _id, _ast_ty, _value, _) => Ok(TypedNode {
                ty: Ty::Unit,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Unit),
            }),
            Resolved::ExtractorDef(span, id, type_params, param, ret_ty, body, attrs) => {
                self.check_extractor_def(span, id, type_params, param, ret_ty, body, attrs)
            }
            Resolved::TraitDef(span, id, _, where_clause, methods, _) => {
                let trait_key = self.trait_key(id);
                let trait_info = self.traits.get(&trait_key).cloned().ok_or_else(|| TypeError {
                    structured: None,
                    message: format!("Unknown trait: {}", id.name),
                    span: span.clone(),
                    hint: None,
                })?;
                let deferred_self = self.env.fresh_tyvar();
                if let Ty::Var(var) = deferred_self { self.register_tyvar_bound(var, &trait_key); }
                let mut typed_methods = Vec::with_capacity(methods.len());
                for method in methods {
                    let method_info = trait_info.methods.get(&method.id.name).ok_or_else(|| {
                        TypeError {
                            structured: None,
                            message: format!("Unknown trait method: {}::{}", id.name, method.id.name),
                            span: method.span.clone(),
                            hint: None,
                        }
                    })?;
                    let (params, mut ret_ty, _, _, _) = self.resolve_trait_method_signature(
                        &trait_info,
                        method_info,
                        &deferred_self,
                    )?;
                    if let Some(body) = &method.body {
                        // Default bodies need an application witness for abstract
                        // Self, just as generic constructor parameters do.
                        let (body_self, slot_vars) = if trait_info.constructor_slots.is_empty() {
                            (deferred_self.clone(), Vec::new())
                        } else {
                            let witness = self.env.fresh_tyvar();
                            let Ty::Var(variable) = witness else { unreachable!() };
                            self.register_tyvar_bound(variable, &trait_key);
                            self.constructor_witness_traits.insert(variable, trait_key.clone());
                            let mut application = vec![Ty::Hole, witness];
                            let mut slots = Vec::new();
                            for _ in &trait_info.constructor_slots {
                                let slot = self.env.fresh_tyvar();
                                let Ty::Var(variable) = slot else { unreachable!() };
                                slots.push(variable);
                                application.push(slot);
                            }
                            (Ty::SelfApp(application), slots)
                        };
                        let (body_params, body_ret) = if trait_info.constructor_slots.is_empty() {
                            (params.clone(), ret_ty.clone())
                        } else {
                            let (body_params, body_ret, _, _, _) = self.resolve_trait_method_signature(
                                &trait_info,
                                method_info,
                                &body_self,
                            )?;
                            let body_params = body_params.into_iter()
                                .map(|ty| self.expand_trait_self_apps(ty, &body_self, &slot_vars))
                                .collect::<Result<Vec<_>, _>>()?;
                            let body_ret = self.expand_trait_self_apps(body_ret, &body_self, &slot_vars)?;
                            (body_params, body_ret)
                        };
                        let mut tyvars = HashMap::from([("Self".into(), body_self)]);
                        for (param, resolved) in method.value_parameters.iter().zip(body_params.iter()) {
                            self.collect_signature_ty_bindings(
                                &param.ty,
                                resolved,
                                &mut tyvars,
                            );
                        }
                        self.collect_signature_ty_bindings(
                            &method.ret_ty,
                            &body_ret,
                            &mut tyvars,
                        );
                        self.seed_missing_method_type_params(&method.type_params, &mut tyvars);
                        let declaration_capabilities = self.resolved_capability_uses(
                            method.where_clause.as_ref(),
                            &tyvars,
                        )?;
                        let local_bindings = method
                            .value_parameters
                            .iter()
                            .zip(body_params.iter())
                            .map(|(param, ty)| (param.id.unique_id, ty.clone()))
                            .collect::<Vec<_>>();
                        let rigid_tyvars = Self::signature_tyvar_ids(&tyvars);
                        let typed_body = self.check_body_in_isolated_scope(
                            &local_bindings,
                            &[],
                            &declaration_capabilities,
                            &mut [],
                            tyvars.clone(),
                            rigid_tyvars.clone(),
                            body_ret.clone(),
                            Self::ast_ty_span(method.ret_ty.syntax()),
                            Some(Self::ast_ty_span(method.ret_ty.syntax())),
                            method.id.name.clone(),
                            None,
                            None,
                            false,
                            body,
                        )?;
                        if let Some(concrete) = self.resolve_contextual_return_body(
                            &method.ret_ty,
                            &body_ret,
                            &typed_body,
                            &rigid_tyvars,
                        )? {
                            ret_ty = concrete;
                        }
                    }
                    typed_methods.push(TypedTraitMethodInfo {
                        name: method.id.name.clone(),
                        params,
                        ret_ty,
                        where_clause: method
                            .where_clause
                            .as_ref()
                            .map(TypedWhereClause::from),
                    });
                }
                Ok(TypedNode {
                    ty: Ty::Unit,
                    span: span.clone(),
                    node: TypedInner::TraitDef(
                        trait_key,
                        where_clause.as_ref().map(TypedWhereClause::from),
                        typed_methods,
                    ),
                })
            }
            Resolved::TraitImplDef(
                span,
                _,
                trait_id,
                trait_args,
                target_ty,
                where_clause,
                methods,
            ) => {
                self.check_trait_impl_def(
                    span,
                    trait_id,
                    trait_args,
                    target_ty,
                    where_clause.as_ref(),
                    methods,
                )
            }
            Resolved::BuiltinDecl(
                span,
                id,
                return_type_arguments,
                params,
                ret_ty,
                where_clause,
                _,
            ) => {
                self.check_builtin_decl(
                    span,
                    id,
                    return_type_arguments,
                    params,
                    ret_ty,
                    where_clause.as_ref(),
                )
            }
            Resolved::BuiltinExtractorDecl(span, id, param, ret_ty, _) => {
                self.check_builtin_extractor_decl(span, id, param, ret_ty)
            }
            Resolved::BuiltinTypeDecl(span, id, params, attrs) => {
                self.check_builtin_type_decl(span, id, params, attrs)
            }
            Resolved::TypeAlias(span, _, _, _, _) => Ok(TypedNode {
                ty: Ty::Unit,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Unit),
            }),

            Resolved::Capture(span, target, args) => self.check_capture(span, target, args, None),
            Resolved::Block(..)
            | Resolved::ExtractorClosure(..)
            | Resolved::Closure(..)
            | Resolved::CaptureClosure(..)
            | Resolved::Do(..)
            | Resolved::App(..)
            | Resolved::LazyApp(..)
            | Resolved::Match(..)
            | Resolved::IsMatch(..) => unreachable!("structural expressions are dispatched by check_node"),
        }
    }

    fn check_explicit_return_type_argument_apply(
        &mut self,
        span: &Span,
        target: &Resolved,
        args: &[AstTy],
    ) -> Result<TypedNode, TypeError> {
        if self.trait_method_ref(target).is_some() {
            return Err(TypeError {
                structured: None,
                message: "A specialized trait helper needs call or capture context".into(),
                span: span.clone(),
                hint: Some(
                    "Call it with arguments or capture it with an expected callable type.".into(),
                ),
            });
        }
        let (mut typed, signature, return_type_arguments) =
            self.instantiate_named_callable_signature(span, target, Some(args))?;
        let constraints =
            self.call_constraint_set(signature, return_type_arguments, None, span, &typed.ty);
        self.apply_return_type_argument_constraints(&constraints)?;
        typed.ty = self.callable_ty_from_signature(&typed.ty, &constraints.signature);
        Ok(typed)
    }

    fn instantiate_named_callable_signature(
        &mut self,
        span: &Span,
        target: &Resolved,
        explicit: Option<&[AstTy]>,
    ) -> Result<
        (
            TypedNode,
            sindr::signature::CallableSignature<Ty>,
            Vec<super::signatures::TypeConstraint>,
        ),
        TypeError,
    > {
        let Resolved::Var(_, id) = target else {
            return Err(TypeError {
                structured: None,
                message: "Return type arguments require a named callable".into(),
                span: span.clone(),
                hint: None,
            });
        };
        let mut typed = self.check_node(target)?;
        let signature = self
            .callable_signatures
            .get(&id.unique_id)
            .cloned()
            .ok_or_else(|| super::signatures::missing_canonical_callable_signature(id, span))?;
        let (mut signature, call_substitution) =
            super::signatures::instantiate_callable_signature(self, &signature);
        let return_type_arguments =
            self.apply_call_site_return_type_arguments(span, &mut signature, explicit)?;
        if let Ty::UserFunc {
            call_substitution: target,
            ..
        } = &mut typed.ty
        {
            *target = call_substitution;
        }
        typed.ty = self.callable_ty_from_signature(&typed.ty, &signature);
        Ok((typed, signature, return_type_arguments))
    }

    pub(super) fn check_registered_callable_application(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        args: &[ResolvedRecordLitArg],
        expected_return: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let target = Resolved::Var(id.span.clone(), id.clone());
        let (mut typed_func, signature, return_type_arguments) =
            self.instantiate_named_callable_signature(span, &target, None)?;
        let signature_params = signature
            .value_parameters
            .iter()
            .map(|parameter| parameter.ty.clone())
            .collect::<Vec<_>>();
        let callable_hint = self.call_target_signature_hint_for_id(
            id,
            &signature_params,
            &signature.return_type.ty,
        );
        let mut constraints = self.call_constraint_set(
            signature,
            return_type_arguments,
            expected_return,
            span,
            &typed_func.ty,
        );
        self.apply_return_type_argument_constraints(&constraints)?;
        self.apply_concrete_expected_call_constraint(&constraints, span, None)?;
        let typed_args = self.check_callable_application(
            id.unique_id,
            &id.name,
            &constraints.signature,
            args,
            span,
            Some(&callable_hint),
        )?;
        let substitution =
            match self.complete_call_constraint_set(&mut constraints, &typed_args, span, None) {
                super::signatures::SolveState::Solved(substitution) => substitution,
                super::signatures::SolveState::Deferred(pending) => pending.substitution,
                super::signatures::SolveState::Failed(error) => {
                    return Err(if error.hint.is_some() {
                        error
                    } else {
                        error.with_hint(callable_hint)
                    });
                }
            };
        if let Ty::UserFunc {
            call_substitution, ..
        } = &mut typed_func.ty
        {
            *call_substitution = substitution;
        }
        typed_func.ty = self.callable_ty_from_signature(&typed_func.ty, &constraints.signature);
        Ok(TypedNode {
            ty: self.resolve_ty(&constraints.signature.return_type.ty),
            span: span.clone(),
            node: TypedInner::App(Box::new(typed_func), typed_args),
        })
    }

    fn apply_call_site_return_type_arguments(
        &mut self,
        span: &Span,
        signature: &mut sindr::signature::CallableSignature<Ty>,
        explicit: Option<&[AstTy]>,
    ) -> Result<Vec<super::signatures::TypeConstraint>, TypeError> {
        let Some(explicit) = explicit else {
            return Ok(signature
                .return_type_arguments
                .iter()
                .map(|_| super::signatures::TypeConstraint::Infer { span: span.clone() })
                .collect());
        };
        if explicit.len() != signature.return_type_arguments.len() {
            return Err(super::signatures::return_type_argument_arity_error(
                &signature.identity.name,
                signature.return_type_arguments.len(),
                explicit.len(),
                span,
            ));
        }

        let mut constraints = Vec::with_capacity(explicit.len());
        for (slot, ast_ty) in signature.return_type_arguments.iter().zip(explicit) {
            let argument_span = Self::ast_ty_span(ast_ty).clone();
            if matches!(ast_ty, AstTy::Named(_, name) if Self::surface_name(name) == "_") {
                constraints.push(super::signatures::TypeConstraint::Infer {
                    span: argument_span,
                });
                continue;
            }
            let explicit_ty = self.resolve_call_site_return_type_argument(&slot.ty, ast_ty)?;
            constraints.push(super::signatures::TypeConstraint::Explicit {
                ty: explicit_ty,
                span: argument_span,
            });
        }
        Ok(constraints)
    }

    fn apply_return_type_argument_constraints(
        &mut self,
        constraints: &super::signatures::CallConstraintSet,
    ) -> Result<(), TypeError> {
        for (slot, constraint) in constraints
            .signature
            .return_type_arguments
            .iter()
            .zip(&constraints.return_type_arguments)
        {
            let Some(explicit_ty) = constraint.explicit_ty() else {
                continue;
            };
            let relation_failed = match slot.ty {
                Ty::Var(variable) if self.constructor_witness_traits.contains_key(&variable) => {
                    let checkpoint = self.candidate_probe_checkpoint();
                    let matched = self.match_explicit_constructor_occurrence(variable, explicit_ty);
                    if !matches!(matched, Ok(true)) {
                        self.rollback_candidate_probe(checkpoint);
                    }
                    !matched.map_err(|error| error.at_span(constraint.span()))?
                }
                _ => self
                    .assert_type_relation(
                        &slot.ty,
                        explicit_ty,
                        self.type_fact(SourceRole::Contract, constraint.span(), &slot.ty),
                        self.type_fact(
                            SourceRole::ReturnTypeArgument,
                            constraint.span(),
                            explicit_ty,
                        ),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::Call,
                        &constraints.signature.identity.name,
                        slot.ordinal,
                    )
                    .is_err(),
            };
            if relation_failed {
                return Err(super::signatures::return_type_argument_mismatch_error(
                    &constraints.signature.identity.name,
                    slot.ordinal,
                    &self.diagnostic_ty_name(&slot.ty),
                    &self.diagnostic_ty_name(explicit_ty),
                    constraint.span(),
                    SourceRole::Contract,
                    constraint.span(),
                ));
            }
        }
        Ok(())
    }

    fn callable_ty_from_signature(
        &self,
        original: &Ty,
        signature: &sindr::signature::CallableSignature<Ty>,
    ) -> Ty {
        let params = signature
            .value_parameters
            .iter()
            .map(|parameter| self.resolve_ty(&parameter.ty))
            .collect::<Vec<_>>();
        let ret = Box::new(self.resolve_ty(&signature.return_type.ty));
        match original {
            Ty::BuiltinFunc { name, .. } => Ty::BuiltinFunc {
                name: name.clone(),
                params,
                ret,
            },
            Ty::UserFunc {
                fun_idx,
                type_params,
                call_substitution,
                ..
            } => Ty::UserFunc {
                fun_idx: *fun_idx,
                type_params: type_params.clone(),
                call_substitution: call_substitution
                    .iter()
                    .map(|(var, ty)| (*var, self.resolve_ty(ty)))
                    .collect(),
                params,
                ret,
            },
            _ => Ty::Func(params, ret),
        }
    }

    fn call_constraint_set(
        &self,
        signature: sindr::signature::CallableSignature<Ty>,
        return_type_arguments: Vec<super::signatures::TypeConstraint>,
        expected_return: Option<&Ty>,
        span: &Span,
        callable_ty: &Ty,
    ) -> super::signatures::CallConstraintSet {
        let expected_return =
            expected_return.map(|ty| super::signatures::TypeConstraint::Explicit {
                ty: ty.clone(),
                span: span.clone(),
            });
        let mut origins = return_type_arguments
            .iter()
            .map(|constraint| {
                super::signatures::ConstraintOrigin::ReturnTypeArgument(constraint.span().clone())
            })
            .collect::<Vec<_>>();
        if let Some(constraint) = &expected_return {
            origins.push(super::signatures::ConstraintOrigin::ExpectedReturn(
                constraint.span().clone(),
            ));
        }
        origins.extend(
            signature
                .where_constraints
                .constraints
                .iter()
                .map(|constraint| {
                    super::signatures::ConstraintOrigin::Obligation(constraint.origin.clone())
                }),
        );
        super::signatures::CallConstraintSet {
            obligations: signature.where_constraints.constraints.clone(),
            substitution: match callable_ty {
                Ty::UserFunc {
                    call_substitution, ..
                } => call_substitution.clone(),
                _ => Vec::new(),
            },
            signature,
            return_type_arguments,
            value_arguments: Vec::new(),
            expected_return,
            origins,
        }
    }

    fn apply_expected_call_constraint(
        &mut self,
        constraints: &super::signatures::CallConstraintSet,
        span: &Span,
        explicit: Option<&[AstTy]>,
    ) -> Result<(), TypeError> {
        let Some(expected) = constraints
            .expected_return
            .as_ref()
            .and_then(super::signatures::TypeConstraint::explicit_ty)
        else {
            return Ok(());
        };
        self.assert_type_relation(
            expected,
            &constraints.signature.return_type.ty,
            self.type_fact(SourceRole::Expected, span, expected),
            self.type_fact(
                SourceRole::Value,
                span,
                &constraints.signature.return_type.ty,
            ),
            TypeDiagnosticReason::ReturnTypeMismatch,
            DiagnosticOrigin::Return,
            &constraints.signature.identity.name,
            0,
        )
        .map_err(|_| {
            self.call_expected_return_mismatch_error(constraints, expected, span, explicit)
        })
    }

    /// A result context whose variables are fixed by the enclosing declaration
    /// may safely shape closure and constructor arguments before their bodies
    /// are checked.  Fresh inference variables must wait until value arguments
    /// have contributed their constraints, otherwise generic bounds are proved
    /// too early.
    fn apply_concrete_expected_call_constraint(
        &mut self,
        constraints: &super::signatures::CallConstraintSet,
        span: &Span,
        explicit: Option<&[AstTy]>,
    ) -> Result<(), TypeError> {
        let Some(expected) = constraints
            .expected_return
            .as_ref()
            .and_then(super::signatures::TypeConstraint::explicit_ty)
        else {
            return Ok(());
        };
        let normalized_expected =
            self.normalize_executable_constructor_identities(&self.resolve_ty(expected));
        let Ok(canonical_expected) = self.canonical_request(&normalized_expected) else {
            return Ok(());
        };
        fn is_stable_context(ty: &CanonicalTy, rigid: &HashSet<u32>) -> bool {
            match ty.head {
                CanonicalTypeHead::Variable(variable) => rigid.contains(&variable),
                CanonicalTypeHead::SelfApplication => false,
                _ => ty
                    .arguments
                    .iter()
                    .all(|argument| is_stable_context(argument, rigid)),
            }
        }
        fn needs_context(ty: &Ty) -> bool {
            match ty {
                Ty::Func(..) | Ty::BuiltinFunc { .. } | Ty::UserFunc { .. } => true,
                Ty::SelfApp(items) => Checker::constructor_application_parts(items).is_some(),
                Ty::List(inner)
                | Ty::MatchResult(inner)
                | Ty::ExtractorClosure(inner)
                | Ty::Lazy(inner)
                | Ty::Pid(inner) => needs_context(inner),
                Ty::Result(ok, error) => needs_context(ok) || needs_context(error),
                Ty::Tuple(items) => items.iter().any(needs_context),
                Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                    nominal.arguments.iter().any(needs_context)
                        || nominal.iter().any(|(_, field)| needs_context(field))
                }
                Ty::Enum(_, arguments) => arguments.iter().any(needs_context),
                Ty::Facet(_, source, focus, update_source, update_focus) => {
                    needs_context(source)
                        || needs_context(focus)
                        || needs_context(update_source)
                        || needs_context(update_focus)
                }
                Ty::Var(_)
                | Ty::Hole
                | Ty::Int
                | Ty::Float
                | Ty::Str
                | Ty::Bool
                | Ty::Unit
                | Ty::Error
                | Ty::ProcessMarker(_) => false,
            }
        }
        if !constraints
            .signature
            .value_parameters
            .iter()
            .any(|parameter| needs_context(&parameter.ty))
        {
            return Ok(());
        }
        if !is_stable_context(&canonical_expected, &self.rigid_tyvars) {
            return Ok(());
        }
        self.assert_type_relation(
            &normalized_expected,
            &constraints.signature.return_type.ty,
            self.type_fact(SourceRole::Expected, span, &normalized_expected),
            self.type_fact(
                SourceRole::Value,
                span,
                &constraints.signature.return_type.ty,
            ),
            TypeDiagnosticReason::ReturnTypeMismatch,
            DiagnosticOrigin::Return,
            &constraints.signature.identity.name,
            0,
        )
        .map_err(|_| {
            self.call_expected_return_mismatch_error(constraints, expected, span, explicit)
        })
    }

    fn complete_call_constraint_set(
        &mut self,
        constraints: &mut super::signatures::CallConstraintSet,
        typed_args: &[TypedNode],
        span: &Span,
        explicit: Option<&[AstTy]>,
    ) -> super::signatures::SolveState<Vec<(u32, Ty)>> {
        constraints.value_arguments = constraints
            .signature
            .value_parameters
            .iter()
            .zip(typed_args)
            .enumerate()
            .map(
                |(ordinal, (parameter, argument))| super::signatures::ValueArgumentConstraint {
                    ordinal: ordinal as u32,
                    expected: parameter.ty.clone(),
                    actual: argument.ty.clone(),
                    span: argument.span.clone(),
                },
            )
            .collect();
        constraints
            .origins
            .extend(constraints.value_arguments.iter().map(|argument| {
                super::signatures::ConstraintOrigin::ValueArgument(argument.span.clone())
            }));

        if let Err(error) = self.apply_expected_call_constraint(constraints, span, explicit) {
            return super::signatures::SolveState::Failed(error);
        }

        for argument in &constraints.value_arguments {
            let relation = self.assert_type_relation(
                &argument.expected,
                &argument.actual,
                self.type_fact(SourceRole::Expected, span, &argument.expected),
                self.type_fact(SourceRole::Value, &argument.span, &argument.actual),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                &constraints.signature.identity.name,
                argument.ordinal,
            );
            if let Err(error) = relation {
                if error.reason() != Some(TypeDiagnosticReason::ArgumentTypeMismatch) {
                    return super::signatures::SolveState::Failed(error);
                }
                if let Some(ordinal) = self.conflicting_return_type_argument_ordinal(
                    &argument.expected,
                    &argument.actual,
                    &constraints.signature,
                    &constraints.return_type_arguments,
                ) {
                    if let Some((_, ast_ty)) = explicit.and_then(|items| {
                        constraints
                            .signature
                            .return_type_arguments
                            .iter()
                            .position(|slot| slot.ordinal == ordinal)
                            .and_then(|index| items.get(index).map(|item| (index, item)))
                    }) {
                        return super::signatures::SolveState::Failed(
                            super::signatures::return_type_argument_mismatch_error(
                                &constraints.signature.identity.name,
                                ordinal,
                                &self.diagnostic_ty_name(&argument.actual),
                                &Self::surface_ast_ty(ast_ty),
                                Self::ast_ty_span(ast_ty),
                                SourceRole::Value,
                                &argument.span,
                            ),
                        );
                    }
                }
                if explicit.is_none() {
                    if let Ty::SelfApp(items) = &argument.expected {
                        if let Some((witness, _)) = Self::constructor_application_parts(items) {
                            let shared_witness_argument = match witness {
                                Ty::Var(witness_var) => constraints
                                    .value_arguments
                                    .iter()
                                    .take(argument.ordinal as usize)
                                    .find(|previous| {
                                        let Ty::SelfApp(previous_items) = &previous.expected else {
                                            return false;
                                        };
                                        matches!(
                                            Self::constructor_application_parts(previous_items),
                                            Some((Ty::Var(previous_var), _)) if previous_var == witness_var
                                        )
                                    }),
                                _ => None,
                            };
                            let family_trait = self
                                .constructor_capability_for_type(&argument.expected)
                                .expect(
                                    "constructor occurrence retains canonical capability metadata",
                                );
                            let expected_carrier = shared_witness_argument
                                .map(|previous| self.resolve_ty(&previous.actual))
                                .unwrap_or_else(|| self.resolve_ty(witness));
                            let actual_carrier = self.resolve_ty(&argument.actual);
                            let relation = self
                                .constructor_carrier_relation(
                                    &family_trait,
                                    &expected_carrier,
                                    &actual_carrier,
                                )
                                .into_checked();
                            let relation = match relation {
                                Ok(relation) => relation,
                                Err(error) => {
                                    return super::signatures::SolveState::Failed(
                                        error.at_span(&argument.span),
                                    )
                                }
                            };
                            let reason = match relation {
                                ConstructorCarrierRelation::SameCarrier => {
                                    TypeDiagnosticReason::TypePayloadMismatch
                                }
                                ConstructorCarrierRelation::DifferentCarrier => {
                                    TypeDiagnosticReason::TypeConstructorFamilyMismatch
                                }
                                ConstructorCarrierRelation::Deferred { .. }
                                | ConstructorCarrierRelation::Rejected { .. } => {
                                    return super::signatures::SolveState::Failed(error);
                                }
                            };
                            let left_ty = shared_witness_argument
                                .map(|previous| &previous.actual)
                                .unwrap_or(&argument.expected);
                            let left_span = shared_witness_argument
                                .map(|previous| &previous.span)
                                .unwrap_or(span);
                            return super::signatures::SolveState::Failed(
                                TypeError::from_structured(StructuredDiagnostic {
                                    reason: reason.into(),
                                    origin: DiagnosticOrigin::Call,
                                    data: DiagnosticData::TypeConstructorCarrier(
                                        TypeConstructorCarrierData {
                                            left_type: Some(
                                                self.diagnostic_ty_name(&self.resolve_ty(left_ty)),
                                            ),
                                            right_type: Some(
                                                self.diagnostic_ty_name(&actual_carrier),
                                            ),
                                            left_origin: Some(self.type_fact(
                                                SourceRole::LeftValue,
                                                left_span,
                                                left_ty,
                                            )),
                                            right_origin: Some(self.type_fact(
                                                SourceRole::RightValue,
                                                &argument.span,
                                                &actual_carrier,
                                            )),
                                            required_capability: self
                                                .trait_display_name(&family_trait),
                                            family: self.trait_display_name(&family_trait),
                                            family_id: self
                                                .diagnostic_constructor_family_id(&family_trait),
                                            expected_carrier: self.diagnostic_ty_name(
                                                &self.resolve_ty(&argument.expected),
                                            ),
                                            actual_carrier: self
                                                .diagnostic_ty_name(&actual_carrier),
                                        },
                                    ),
                                    primary: self.type_fact(
                                        SourceRole::RightValue,
                                        &argument.span,
                                        &actual_carrier,
                                    ),
                                    related: vec![self.type_fact(
                                        SourceRole::LeftValue,
                                        left_span,
                                        left_ty,
                                    )],
                                    remediation: None,
                                }),
                            );
                        }
                    }
                }
                return super::signatures::SolveState::Failed(error);
            }
        }

        for obligation in &constraints.obligations {
            let subject = self.resolve_ty(&obligation.subject);
            let trait_key = &obligation.trait_name;
            let obligation_satisfied = (|| -> Result<bool, TypeError> {
                let constructor_head_satisfies = matches!(
                    &obligation.subject,
                    Ty::Var(variable) if self.constructor_witness_traits.contains_key(variable)
                ) && matches!(
                    self.constructor_head_projection(trait_key, &subject)
                        .into_checked()?,
                    ConstructorProjectionOutcome::Applicable { .. }
                );
                Ok(constructor_head_satisfies
                    || self.ty_satisfies_bounds(&subject, std::slice::from_ref(trait_key))?)
            })();
            let obligation_satisfied = match obligation_satisfied {
                Ok(satisfied) => satisfied,
                Err(error) => return super::signatures::SolveState::Failed(error.at_span(span)),
            };
            if !obligation_satisfied {
                let reason = if matches!(subject, Ty::Var(var) if self.rigid_tyvars.contains(&var))
                {
                    TypeDiagnosticReason::MissingGenericBound
                } else {
                    TypeDiagnosticReason::MissingTraitCapability
                };
                return super::signatures::SolveState::Failed(self.trait_failure(
                    reason,
                    trait_key,
                    &subject,
                    span,
                    DiagnosticOrigin::Call,
                ));
            }
        }

        // Reading the closed provenance envelope here ensures every call path
        // retains origins for RTA, values, expected return, and obligations.
        for origin in &constraints.origins {
            let _ = (origin.span(), origin.signature_origin());
        }
        let mut unresolved_return_type_arguments = Vec::new();
        for (slot, constraint) in constraints
            .signature
            .return_type_arguments
            .iter()
            .zip(&constraints.return_type_arguments)
        {
            let resolved = self.resolve_ty(&slot.ty);
            if self.return_type_argument_is_unresolved(&slot.ty)
                && constraint.explicit_ty().is_none()
            {
                unresolved_return_type_arguments.push((slot.ordinal, resolved));
            }
        }
        let substitution = constraints
            .substitution
            .iter()
            .map(|(var, ty)| (*var, self.resolve_ty(ty)))
            .collect::<Vec<_>>();
        if unresolved_return_type_arguments.is_empty() {
            super::signatures::SolveState::Solved(substitution)
        } else {
            super::signatures::SolveState::Deferred(super::signatures::PendingConstraints {
                unresolved_return_type_arguments,
                substitution,
            })
        }
    }

    fn return_type_argument_is_unresolved(&self, ty: &Ty) -> bool {
        if let Ty::SelfApp(items) = ty {
            if let Some((witness, _)) = Self::constructor_application_parts(items) {
                let mut unresolved = Vec::new();
                Self::collect_ty_vars(&self.resolve_ty(witness), &mut unresolved);
                return !unresolved.is_empty();
            }
        }
        let mut unresolved = Vec::new();
        Self::collect_ty_vars(&self.resolve_ty(ty), &mut unresolved);
        !unresolved.is_empty()
    }

    fn call_expected_return_mismatch_error(
        &self,
        constraints: &super::signatures::CallConstraintSet,
        expected: &Ty,
        span: &Span,
        explicit: Option<&[AstTy]>,
    ) -> TypeError {
        let signature = &constraints.signature;
        let conflicting_ordinal = self.conflicting_return_type_argument_ordinal(
            &signature.return_type.ty,
            expected,
            signature,
            &constraints.return_type_arguments,
        );
        let explicit_item = explicit.and_then(|items| {
            conflicting_ordinal
                .and_then(|ordinal| {
                    signature
                        .return_type_arguments
                        .iter()
                        .position(|slot| slot.ordinal == ordinal)
                })
                .and_then(|index| items.get(index).map(|item| (index, item)))
        });
        if let Some((slot, ast_ty)) = explicit_item {
            let ordinal = signature
                .return_type_arguments
                .get(slot)
                .map(|argument| argument.ordinal)
                .unwrap_or(slot as u32);
            return super::signatures::return_type_argument_mismatch_error(
                &signature.identity.name,
                ordinal,
                &self.diagnostic_ty_name(expected),
                &Self::surface_ast_ty(ast_ty),
                Self::ast_ty_span(ast_ty),
                SourceRole::Expected,
                span,
            );
        }
        let error = self.type_relation_error(
            expected,
            &signature.return_type.ty,
            self.type_fact(SourceRole::Expected, span, expected),
            self.type_fact(SourceRole::Value, span, &signature.return_type.ty),
            TypeDiagnosticReason::ReturnTypeMismatch,
            DiagnosticOrigin::Return,
            &signature.identity.name,
            0,
        );
        if matches!(self.resolve_ty(&signature.return_type.ty), Ty::Unit) && error.hint.is_none() {
            let params = signature
                .value_parameters
                .iter()
                .map(|parameter| parameter.ty.clone())
                .collect::<Vec<_>>();
            return error.with_hint(format!(
                "{}\nThis call returns Unit; the surrounding context expects {}.",
                self.format_signature(
                    &signature.identity.name,
                    &params,
                    &signature.return_type.ty,
                ),
                self.diagnostic_ty_name(expected),
            ));
        }
        error
    }

    fn conflicting_return_type_argument_ordinal(
        &self,
        actual: &Ty,
        expected: &Ty,
        signature: &sindr::signature::CallableSignature<Ty>,
        constraints: &[super::signatures::TypeConstraint],
    ) -> Option<u32> {
        let explicit_slot_for_var = |var| {
            signature
                .return_type_arguments
                .iter()
                .zip(constraints)
                .find_map(|(slot, constraint)| {
                    constraint.explicit_ty()?;
                    let mut vars = Vec::new();
                    Self::collect_ty_vars(&slot.ty, &mut vars);
                    vars.into_iter()
                        .any(|slot_var| slot_var == var)
                        .then_some(slot.ordinal)
                })
        };

        fn find(
            checker: &Checker,
            actual: &Ty,
            expected: &Ty,
            explicit_slot_for_var: &impl Fn(u32) -> Option<u32>,
        ) -> Option<u32> {
            if let Ty::Var(var) = actual {
                return (checker.resolve_ty(actual) != checker.resolve_ty(expected))
                    .then(|| explicit_slot_for_var(*var))
                    .flatten();
            }
            if let Ty::SelfApp(items) = actual {
                if let Some((witness, _)) = Checker::constructor_application_parts(items) {
                    if checker.resolve_ty(actual) != checker.resolve_ty(expected) {
                        let mut vars = Vec::new();
                        Checker::collect_ty_vars(witness, &mut vars);
                        if let Some(ordinal) = vars.into_iter().find_map(explicit_slot_for_var) {
                            return Some(ordinal);
                        }
                    }
                }
            }
            match (actual, expected) {
                (Ty::MatchResult(left), Ty::MatchResult(right))
                | (Ty::ExtractorClosure(left), Ty::ExtractorClosure(right))
                | (Ty::List(left), Ty::List(right))
                | (Ty::Lazy(left), Ty::Lazy(right))
                | (Ty::Pid(left), Ty::Pid(right)) => {
                    find(checker, left, right, explicit_slot_for_var)
                }
                (Ty::Result(left_ok, left_err), Ty::Result(right_ok, right_err)) => {
                    find(checker, left_ok, right_ok, explicit_slot_for_var)
                        .or_else(|| find(checker, left_err, right_err, explicit_slot_for_var))
                }
                (Ty::Tuple(left), Ty::Tuple(right))
                | (Ty::SelfApp(left), Ty::SelfApp(right))
                | (Ty::Enum(_, left), Ty::Enum(_, right)) => left
                    .iter()
                    .zip(right)
                    .find_map(|(left, right)| find(checker, left, right, explicit_slot_for_var)),
                (Ty::Func(left_params, left_ret), Ty::Func(right_params, right_ret)) => left_params
                    .iter()
                    .zip(right_params)
                    .find_map(|(left, right)| find(checker, left, right, explicit_slot_for_var))
                    .or_else(|| find(checker, left_ret, right_ret, explicit_slot_for_var)),
                (Ty::Struct(_, left), Ty::Struct(_, right))
                | (Ty::Record(_, left), Ty::Record(_, right)) => {
                    if !left.arguments.is_empty() || !right.arguments.is_empty() {
                        left.arguments
                            .iter()
                            .zip(&right.arguments)
                            .find_map(|(left, right)| {
                                find(checker, left, right, explicit_slot_for_var)
                            })
                    } else {
                        left.iter().zip(right).find_map(|((_, left), (_, right))| {
                            find(checker, left, right, explicit_slot_for_var)
                        })
                    }
                }
                _ => None,
            }
        }

        find(self, actual, expected, &explicit_slot_for_var)
    }

    pub(super) fn check_node_with_expected(
        &mut self,
        node: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let relation = expected.map(|_| ExpectedTypeRelation::contextual(self.resolved_span(node)));
        self.check_node_with_expected_relation(node, expected, relation.as_ref())
    }

    pub(super) fn check_node_with_return_expected(
        &mut self,
        node: &Resolved,
        expected: &Ty,
        expected_span: &Span,
    ) -> Result<TypedNode, TypeError> {
        let relation = ExpectedTypeRelation::function_return(expected_span);
        self.check_node_with_expected_relation(node, Some(expected), Some(&relation))
    }

    // Recursive structural nodes must not retain the temporary frame used by
    // contextual collection inference and the other individual expressions.
    pub(super) fn check_node_with_expected_relation(
        &mut self,
        node: &Resolved,
        expected: Option<&Ty>,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        match (node, expected) {
            (Resolved::Block(span, stmts), expected) => {
                self.check_block(span, stmts, expected, expected_relation)
            }
            (Resolved::ExtractorClosure(span, params, captures, body), Some(expected_ty)) => self
                .check_extractor_closure(
                    span,
                    params,
                    captures,
                    body,
                    Some(expected_ty),
                    expected_relation,
                ),
            (Resolved::Closure(span, params, captures, body), Some(expected_ty)) => self
                .check_literal_closure_with_expected_relation(
                    span,
                    params,
                    captures,
                    body,
                    expected_ty,
                    expected_relation,
                ),
            (Resolved::CaptureClosure(span, params, captures, body), Some(expected_ty)) => self
                .check_capture_closure_with_expected_type(
                    span,
                    params,
                    captures,
                    body,
                    expected_ty,
                ),
            (
                Resolved::Do(span, intrinsic, contract, return_type_arguments, statements),
                expected,
            ) => self.check_do(
                span,
                *intrinsic,
                contract,
                return_type_arguments,
                statements,
                expected,
                expected_relation,
            ),
            (Resolved::LazyApp(span, kind, func, args), Some(expected_ty)) => {
                self.check_lazy_app(span, *kind, func, args, Some(expected_ty))
            }
            (Resolved::App(span, func, args), Some(expected_ty)) => {
                self.check_application_with_expected_type(span, func, args, expected_ty)
            }
            (Resolved::FieldAccess(span, expr, field), expected_ty) => {
                self.check_field_access_with_expected(span, expr, field, expected_ty)
            }
            (Resolved::FacetSegmentAccess(span, expr, segment), expected_ty) => {
                self.check_facet_segment_access_with_expected(span, expr, segment, expected_ty)
            }
            (Resolved::Grouped(span, inner), Some(expected_ty)) => {
                let mut typed = self.check_node_with_expected_relation(
                    inner,
                    Some(expected_ty),
                    expected_relation,
                )?;
                self.propagate_safe_operator_result(&typed.span, span);
                typed.span = span.clone();
                Ok(typed)
            }
            (
                Resolved::Match(span, scrutinee, arms) | Resolved::IsMatch(span, scrutinee, arms),
                Some(expected_ty),
            ) => {
                let branch_relation = expected_relation
                    .filter(|relation| relation.synthetic_do_match_pending)
                    .map(ExpectedTypeRelation::after_synthetic_do_match);
                self.check_match(
                    span,
                    scrutinee,
                    arms,
                    Some(expected_ty),
                    branch_relation.as_ref(),
                )
            }
            (Resolved::ProcessContextHandler(span, slot), _) => {
                self.check_process_context_handler(span, slot)
            }
            (_, None) => self.check_node(node),
            (_, Some(expected_ty)) => {
                self.check_non_structural_node_with_expected(node, expected_ty)
            }
        }
    }

    #[inline(never)]
    fn check_literal_closure_with_expected_relation(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected_ty: &Ty,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        let expected_ty = self.resolve_ty(expected_ty);
        if matches!(expected_ty, Ty::Var(var) if !self.rigid_tyvars.contains(&var)) {
            let typed = self.check_closure(span, params, captures, body, None, None)?;
            self.assert_type_relation(
                &expected_ty,
                &typed.ty,
                self.type_fact(SourceRole::Expected, span, &expected_ty),
                self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                "closure",
                0,
            )?;
            Ok(typed)
        } else {
            self.check_closure(
                span,
                params,
                captures,
                body,
                Some(&expected_ty),
                expected_relation,
            )
        }
    }

    #[inline(never)]
    fn check_capture_closure_with_expected_type(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected_ty: &Ty,
    ) -> Result<TypedNode, TypeError> {
        let expected_ty = self.resolve_ty(expected_ty);
        if matches!(expected_ty, Ty::Var(var) if !self.rigid_tyvars.contains(&var)) {
            let typed = self.check_capture_closure(span, params, captures, body, None)?;
            self.assert_type_relation(
                &expected_ty,
                &typed.ty,
                self.type_fact(SourceRole::Expected, span, &expected_ty),
                self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                "closure",
                0,
            )?;
            Ok(typed)
        } else {
            self.check_capture_closure(span, params, captures, body, Some(&expected_ty))
        }
    }

    #[inline(never)]
    fn check_application_with_expected_type(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        expected_ty: &Ty,
    ) -> Result<TypedNode, TypeError> {
        // Keep the original contextual dispatch priority: constructors,
        // trait helpers, Function on calls, and then ordinary applications.
        if matches!(func, Resolved::Var(_, id)
            if self.lookup_enum_variant_by_constructor_id(id.unique_id).is_some())
        {
            let Resolved::Var(_, id) = func else {
                unreachable!("constructor guard requires a variable callee")
            };
            self.check_constructor_call(span, id, args, Some(expected_ty))
        } else if self.trait_method_ref(func).is_some() {
            let (id, trait_name, method_name) = self
                .trait_method_ref(func)
                .expect("guard established a trait method reference");
            let receiver_owner_hint = id
                .name
                .strip_suffix(&format!("::{}", method_name))
                .filter(|owner| *owner == "JsonValue");
            let explicit_type_arguments = Self::explicit_type_args(func);
            self.check_trait_method_call(
                span,
                &trait_name,
                &method_name,
                args,
                receiver_owner_hint,
                Some(expected_ty),
                explicit_type_arguments.as_deref(),
            )
        } else if self.is_function_on_callee(func) {
            self.check_function_on_with_expected(span, func, args, expected_ty)
        } else {
            self.check_app_with_expected(span, func, args, Some(expected_ty))
        }
    }

    #[inline(never)]
    fn check_non_structural_node_with_expected(
        &mut self,
        node: &Resolved,
        expected_ty: &Ty,
    ) -> Result<TypedNode, TypeError> {
        match node {
            Resolved::ApplyPattern(span, value, pattern) => {
                self.check_apply_pattern(span, value, pattern, Some(expected_ty))
            }
            Resolved::Capture(span, target, args) => {
                self.check_capture(span, target, args, Some(expected_ty))
            }
            Resolved::ListLiteral(span, elems) => {
                let expected_ty = self.resolve_ty(expected_ty);
                let Ty::List(element_ty) = expected_ty else {
                    return self.check_list_literal(span, elems);
                };
                if matches!(self.resolve_ty(element_ty.as_ref()), Ty::Var(_)) {
                    return self.check_list_literal(span, elems);
                }
                let typed_elems = elems
                    .iter()
                    .map(|elem| self.check_node_with_expected(elem, Some(element_ty.as_ref())))
                    .collect::<Result<Vec<_>, _>>()?;
                for (ordinal, typed) in typed_elems.iter().enumerate() {
                    self.ensure_no_runtime_facet_value(typed, "List literal")?;
                    self.assert_type_relation(
                        element_ty.as_ref(),
                        &typed.ty,
                        self.type_fact(SourceRole::Expected, span, element_ty.as_ref()),
                        self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::Call,
                        "list element",
                        ordinal as u32,
                    )?;
                }
                Ok(TypedNode {
                    ty: Ty::List(element_ty),
                    span: span.clone(),
                    node: TypedInner::ListLiteral(typed_elems),
                })
            }
            Resolved::TupleLiteral(span, elems) => {
                let expected_ty = self.resolve_ty(expected_ty);
                let Ty::Tuple(item_tys) = expected_ty else {
                    return self.check_tuple_literal(span, elems);
                };
                if elems.len() != item_tys.len() {
                    return self.check_tuple_literal(span, elems);
                }
                let typed_elems = elems
                    .iter()
                    .zip(item_tys.iter())
                    .map(|(elem, expected)| self.check_node_with_expected(elem, Some(expected)))
                    .collect::<Result<Vec<_>, _>>()?;
                for (ordinal, (expected, typed)) in item_tys.iter().zip(&typed_elems).enumerate() {
                    self.ensure_no_runtime_facet_value(typed, "Tuple literal")?;
                    self.assert_type_relation(
                        expected,
                        &typed.ty,
                        self.type_fact(SourceRole::Expected, span, expected),
                        self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::Call,
                        "tuple element",
                        ordinal as u32,
                    )?;
                }
                Ok(TypedNode {
                    ty: Ty::Tuple(item_tys),
                    span: span.clone(),
                    node: TypedInner::TupleLiteral(typed_elems),
                })
            }
            Resolved::InferredFacetCapture(span, segments) => {
                self.check_inferred_facet_capture(span, segments, expected_ty)
            }
            Resolved::Pipe(span, left, right) => {
                self.check_pipe_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::ContextMap(span, left, right) => {
                self.check_context_map_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::ContextApply(span, left, right) => {
                self.check_context_apply_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::ContextBind(span, left, right) => {
                self.check_context_bind_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::Cond(span, clauses) => self.check_cond(span, clauses, Some(expected_ty)),
            Resolved::If(span, cond, then, else_opt) => {
                self.check_if_with_expected(span, cond, then, else_opt, expected_ty)
            }
            Resolved::IfLet(span, scrutinee, arms, then_only) => {
                self.check_if_let(span, scrutinee, arms, Some(expected_ty), *then_only)
            }
            Resolved::BinOp(span, op, left, right) => {
                self.check_binop_with_expected(span, op, left, right, Some(expected_ty))
            }
            Resolved::Compose(span, left, right) => {
                self.check_compose_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::LiftedCompose(span, left, right) => {
                self.check_lifted_compose_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::KleisliCompose(span, left, right) => {
                self.check_kleisli_compose_with_expected(span, left, right, Some(expected_ty))
            }
            Resolved::ConstructorCall(span, id, args) => {
                self.check_constructor_call(span, id, args, Some(expected_ty))
            }
            Resolved::EnumConstructorCall(span, id, type_args, args) => self
                .check_explicit_enum_constructor_call(span, id, type_args, args, Some(expected_ty)),
            _ => {
                let typed = self.check_node(node)?;
                Ok(typed)
            }
        }
    }

    fn check_block(
        &mut self,
        span: &Span,
        stmts: &[Resolved],
        expected: Option<&Ty>,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        let inherited_substitutions = self.substitutions.clone();
        let mut typed_stmts = Vec::new();
        let mut last_ty = Ty::Unit;
        for (index, stmt) in stmts.iter().enumerate() {
            // Inference substitutions are statement-local inside blocks too.
            // Retain the surrounding callable contract while preventing an
            // earlier generic call from monomorphizing later siblings.
            self.substitutions = inherited_substitutions.clone();
            let is_last = index + 1 == stmts.len();
            let typed = if is_last {
                match expected {
                    Some(expected_ty) => self.check_node_with_expected_relation(
                        stmt,
                        Some(expected_ty),
                        expected_relation,
                    )?,
                    None => self.check_node(stmt)?,
                }
            } else {
                self.check_node(stmt)?
            };
            last_ty = typed.ty.clone();
            typed_stmts.push(typed);
        }
        if let Some(last) = typed_stmts.last() {
            self.propagate_safe_operator_result(&last.span, span);
        }
        Ok(TypedNode {
            ty: last_ty,
            span: span.clone(),
            node: TypedInner::Block(typed_stmts),
        })
    }

    /// A user-facing Facet annotation describes a path template; it does not
    /// coerce or select a different path.  Preserve concrete update slots on
    /// the compile-time path so every later API use can validate them against
    /// its independently-derived rebuild result.
    fn apply_facet_annotation(
        &mut self,
        typed: &mut TypedNode,
        expected: &Ty,
        span: &Span,
    ) -> Result<(), TypeError> {
        let expected = self.resolve_ty(expected);
        let actual = self.resolve_ty(&typed.ty);
        let (
            Ty::Facet(
                expected_kind,
                expected_source,
                expected_focus,
                expected_update_source,
                expected_update_focus,
            ),
            Ty::Facet(actual_kind, actual_source, actual_focus, _, _),
        ) = (&expected, &actual)
        else {
            return Ok(());
        };

        if !expected_kind.is_atomic()
            || expected_kind != actual_kind
            || !self.types_compatible(expected_source, actual_source)?
            || !self.types_compatible(expected_focus, actual_focus)?
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet annotation does not match this path: expected {}, got {}",
                    self.ty_name(&expected),
                    self.ty_name(&actual)
                ),
                span: span.clone(),
                hint: Some(
                    "Facet K, S, and A are derived from the path and must match exactly.".into(),
                ),
            });
        }

        match &mut typed.node {
            TypedInner::FacetPath(path) => {
                path.update_source_ty = expected_update_source.as_ref().clone();
                path.update_focus_ty = expected_update_focus.as_ref().clone();
            }
            // A pending path will be specialized with the annotated source
            // before it can be bound.  Its update slots remain on `typed.ty`.
            TypedInner::PendingFacetPath(_) => {}
            _ => return Ok(()),
        }
        typed.ty = expected;
        Ok(())
    }

    fn stored_facet_path_from_node(
        &self,
        typed: TypedNode,
        span: &Span,
    ) -> Result<StoredFacetPath, TypeError> {
        let slots = match self.resolve_ty(&typed.ty) {
            Ty::Facet(_, _, _, update_source, update_focus) => (
                update_source.as_ref().clone(),
                update_focus.as_ref().clone(),
            ),
            _ => (Ty::Hole, Ty::Hole),
        };
        match typed.node {
            TypedInner::FacetPath(path) => Ok(StoredFacetPath::Concrete(TypedFacetPath {
                source_ty: self.resolve_ty(&path.source_ty),
                focus_ty: self.resolve_ty(&path.focus_ty),
                update_source_ty: self.resolve_ty(&slots.0),
                update_focus_ty: self.resolve_ty(&slots.1),
                path_kind: path.path_kind,
                may_fail: path.may_fail,
                segments: path.segments,
            })),
            TypedInner::PendingFacetPath(path) => Ok(StoredFacetPath::Pending(path)),
            _ => Err(self.policy_error(
                TypeDiagnosticReason::FacetCompileTimeOnly,
                diagnostics::TypePolicy::FacetStageRestriction,
                Some("Facet values are compile-time only in Stage1 and cannot be stored or passed around".into()),
                None,
                Some(&typed.ty),
                Some("Stage1".into()),
                None,
                span,
                Some("Use type-root path expressions inline (e.g. User.name).".into()),
            )),
        }
    }

    fn bind_facet_pattern_bindings(
        &mut self,
        pattern: &TypedPattern,
        path: &StoredFacetPath,
        span: &Span,
    ) -> Result<(), TypeError> {
        match pattern {
            TypedPattern::Located(_, inner) => self.bind_facet_pattern_bindings(inner, path, span),
            TypedPattern::Var(_, id) => {
                self.facet_bindings.insert(id.unique_id, path.clone());
                Ok(())
            }
            TypedPattern::As(_, inner, alias) => {
                self.bind_facet_pattern_bindings(inner, path, span)?;
                self.facet_bindings.insert(alias.unique_id, path.clone());
                Ok(())
            }
            TypedPattern::Wildcard(_) => Ok(()),
            _ => Err(self.policy_error(
                TypeDiagnosticReason::FacetPatternBindingForbidden,
                diagnostics::TypePolicy::FacetPatternBinding,
                Some("Facet value binding pattern".into()),
                None,
                None,
                Some("Stage1".into()),
                None,
                span,
                Some("Use `facet = User.name` or `_ = User.name`.".into()),
            )),
        }
    }

    fn clear_facet_pattern_bindings(&mut self, pattern: &TypedPattern) {
        match pattern {
            TypedPattern::HashMap(_, entries) => {
                for entry in entries {
                    self.clear_facet_pattern_bindings(&entry.pattern);
                }
            }
            TypedPattern::Located(_, inner) => self.clear_facet_pattern_bindings(inner),
            TypedPattern::Var(_, id) => {
                self.facet_bindings.remove(&id.unique_id);
            }
            TypedPattern::As(_, inner, alias) => {
                self.clear_facet_pattern_bindings(inner);
                self.facet_bindings.remove(&alias.unique_id);
            }
            TypedPattern::ListCons(_, head, tail) => {
                self.clear_facet_pattern_bindings(head);
                self.clear_facet_pattern_bindings(tail);
            }
            TypedPattern::Tuple(_, items) => {
                for item in items {
                    self.clear_facet_pattern_bindings(item);
                }
            }
            TypedPattern::Constructor { fields, .. } => {
                for field in fields {
                    self.clear_facet_pattern_bindings(field);
                }
            }
            TypedPattern::Extractor { items, .. } => {
                for item in items {
                    self.clear_facet_pattern_bindings(item);
                }
            }
            TypedPattern::Wildcard(_)
            | TypedPattern::Pin(_, _, _)
            | TypedPattern::ListNil(_)
            | TypedPattern::IntLit(_, _)
            | TypedPattern::StrLit(_, _)
            | TypedPattern::BoolLit(_, _)
            | TypedPattern::DurationLit(_, _) => {}
        }
    }

    fn require_statement_question_unit_success(
        &self,
        rhs_ty: &Ty,
        span: &Span,
    ) -> Result<(), TypeError> {
        let rhs_ty = self.resolve_ty(rhs_ty);
        let Ty::Result(success, _) = &rhs_ty else {
            return Err(TypeError::new(
                format!(
                    "Statement `?` requires a canonical Result with terminal success type Unit; got {}.",
                    self.ty_name(&rhs_ty),
                ),
                span.clone(),
            ));
        };
        let mut terminal = self.resolve_ty(success);
        while let Ty::Result(success, _) = terminal {
            terminal = self.resolve_ty(&success);
        }
        if terminal != Ty::Unit {
            return Err(TypeError::new(
                format!(
                    "Statement `?` requires terminal success type Unit; got {} in {}.",
                    self.ty_name(&terminal),
                    self.ty_name(&rhs_ty),
                ),
                span.clone(),
            ));
        }
        Ok(())
    }

    fn check_safebind_input(
        &mut self,
        span: &Span,
        pat: &ResolvedPattern,
        rhs: &Resolved,
        unit_success_only: bool,
    ) -> Result<CheckedSafeBindInput, TypeError> {
        let typed_rhs = self.check_node(rhs)?;
        if unit_success_only {
            self.require_statement_question_unit_success(&typed_rhs.ty, span)?;
        }
        if matches!(typed_rhs.ty, Ty::Facet(..)) {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetSafeBindForbidden,
                diagnostics::TypePolicy::SafeBindFacet,
                Some("Facet value".into()),
                None,
                Some(&typed_rhs.ty),
                Some("Stage1".into()),
                None,
                &typed_rhs.span,
                Some("Use `=` for compile-time Facet bindings.".into()),
            ));
        }
        let rhs_ty = self.resolve_ty(&typed_rhs.ty);
        let (ok_ty, mut propagated_err_tys, rhs_projection) = match rhs_ty {
            Ty::Result(ok, err) => {
                let payload_ty = ok.as_ref().clone();
                let error_ty = err.as_ref().clone();
                (
                    payload_ty.clone(),
                    vec![error_ty.clone()],
                    SafeBindRhsProjection::CanonicalResultOnce {
                        payload_ty,
                        error_ty,
                    },
                )
            }
            other => (
                other.clone(),
                Vec::new(),
                SafeBindRhsProjection::PatternInput {
                    pattern_input_ty: other,
                },
            ),
        };

        let (typed_pat, pat_ty) = self.check_pattern(pat, &ok_ty, span)?;
        let pattern_can_nomatch = !Self::is_total_bind_pattern(pat);
        if pattern_can_nomatch {
            propagated_err_tys.push(Ty::Error);
        } else if !matches!(self.resolve_ty(&typed_rhs.ty), Ty::Result(_, _)) {
            let monad = self
                .trait_key_by_short_name("Monad")
                .ok_or_else(|| TypeError::new("Missing canonical Monad trait", span.clone()))?;
            let proof = self.prove_trait_capability(&monad, &ok_ty)?;
            if type_contains_unresolved_vars(&ok_ty) {
                match proof {
                    ApplicabilityProof::Satisfied(_) => {}
                    ApplicabilityProof::Deferred(_) => {
                        return Err(self.trait_obligation_failure(
                            TypeDiagnosticReason::MissingTraitCapability,
                            &monad,
                            &[],
                            None,
                            &ok_ty,
                            &typed_rhs.span,
                            DiagnosticOrigin::Intrinsic,
                        ));
                    }
                    ApplicabilityProof::Unsatisfied => {
                        return Err(self.trait_obligation_failure(
                            TypeDiagnosticReason::MissingGenericBound,
                            &monad,
                            &[],
                            None,
                            &ok_ty,
                            &typed_rhs.span,
                            DiagnosticOrigin::Intrinsic,
                        ));
                    }
                }
            }
            let (reason, monad_capability) = match proof {
                ApplicabilityProof::Satisfied(_) => (
                    TypeDiagnosticReason::SafeBindTotalPatternNonResultMonadRhs,
                    "satisfied",
                ),
                ApplicabilityProof::Unsatisfied => (
                    TypeDiagnosticReason::SafeBindTotalPatternNonMonadRhs,
                    "unsatisfied",
                ),
                ApplicabilityProof::Deferred(_) => {
                    unreachable!("a deferred Monad proof must retain unresolved type variables")
                }
            };
            let rhs_name = self.ty_name(&ok_ty);
            return Err(TypeError::from_structured(StructuredDiagnostic {
                reason: reason.into(),
                origin: DiagnosticOrigin::Intrinsic,
                data: DiagnosticData::SafeBindRelation(diagnostics::SafeBindRelationData {
                    lhs_type: self.ty_name(&pat_ty),
                    rhs_type: rhs_name,
                    lhs_is_total: true,
                    rhs_is_canonical_result: false,
                    monad_capability: monad_capability.into(),
                }),
                primary: self.type_fact(SourceRole::Value, &typed_rhs.span, &ok_ty),
                related: vec![self.type_fact(SourceRole::Pattern, span, &pat_ty)],
                remediation: None,
            }));
        }
        self.ensure_self_rebinding_types(&typed_pat, span)?;
        Ok(CheckedSafeBindInput {
            typed_pattern: typed_pat,
            pattern_ty: pat_ty,
            typed_rhs,
            projection: rhs_projection,
            propagated_error_tys: propagated_err_tys,
        })
    }

    fn check_safebind(
        &mut self,
        span: &Span,
        operator_span: &Span,
        pat: &ResolvedPattern,
        rhs: &Resolved,
        unit_success_only: bool,
    ) -> Result<TypedNode, TypeError> {
        let mut checked = self.check_safebind_input(span, pat, rhs, unit_success_only)?;
        let failure_target = if matches!(
            self.callable_context,
            CallableContext::Extractor | CallableContext::ExtractorClosure
        ) {
            let (_, err_tag) = self.match_result_variant_tags(span)?;
            SafeBindFailureTarget::EnclosingMatchResultContext { err_tag }
        } else if let Some(ret_ty) = self.function_return_ty.clone() {
            self.collect_pattern_result_error_types(
                &checked.typed_pattern,
                &mut checked.propagated_error_tys,
            );
            self.resolve_pattern_failure_target(
                &ret_ty,
                &checked.propagated_error_tys,
                operator_span,
                None,
                false,
            )?
        } else {
            SafeBindFailureTarget::TopLevel
        };

        self.bind_typed_pattern(&checked.typed_pattern, &checked.pattern_ty);
        self.bind_constructor_provenance(
            &checked.typed_pattern,
            self.result_constructor_provenance(&checked.typed_rhs),
        );

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::SafeBind(
                checked.typed_pattern,
                Box::new(checked.typed_rhs),
                checked.projection,
                failure_target,
            ),
        })
    }

    pub(super) fn check_compose_callable(
        &mut self,
        node: &Resolved,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        match node {
            Resolved::Capture(_, _, _)
            | Resolved::Closure(_, _, _, _)
            | Resolved::ExtractorClosure(_, _, _, _)
            | Resolved::CaptureClosure(_, _, _, _)
            | Resolved::Compose(_, _, _)
            | Resolved::LiftedCompose(_, _, _)
            | Resolved::KleisliCompose(_, _, _) => self.check_node(node),
            Resolved::Var(_, _)
            | Resolved::Grouped(_, _)
            | Resolved::ReturnTypeArgumentApply(_, _, _) => {
                self.check_function_value_operand(node, op_name)
            }
            _ => Err(TypeError {
                structured: None,
                message: format!("{} requires a function value", op_name),
                span: self.resolved_span(node).clone(),
                hint: Some(format!(
                    "{} composes one-argument function values. This operand is being parsed as a call/result expression first. Use `&f`, a closure, a function-typed variable, or another compose expression. If you meant to compose a function returned by a call, parenthesize the call like `(make_fn(...)) {} (other_fn(...))`.",
                    op_name, op_name
                )),
            }),
        }
    }

    pub(super) fn check_operator_compose_callable(
        &mut self,
        node: &Resolved,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        self.check_function_value_operand(node, op_name)
    }

    pub(super) fn check_apply_callable(
        &mut self,
        node: &Resolved,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        match node {
            Resolved::Capture(_, _, _)
            | Resolved::Closure(_, _, _, _)
            | Resolved::ExtractorClosure(_, _, _, _) | Resolved::CaptureClosure(_, _, _, _) => self.check_node(node),
            Resolved::Var(_, _) | Resolved::Grouped(_, _) | Resolved::ReturnTypeArgumentApply(_, _, _) => {
                self.check_function_value_operand(node, op_name)
            }
            Resolved::App(span, func, args) => {
                self.check_injected_call(span, func, args, op_name)
            }
            _ => Err(TypeError {
                structured: None,
                message: format!(
                    "{} requires a function value or a function call like `f(...)`",
                    op_name
                ),
                span: self.resolved_span(node).clone(),
                hint: Some("Use `&f`, a closure, a function-typed variable, or wrap a callable-returning call in parentheses.".into()),
            }),
        }
    }

    fn can_use_expected_callable_context(node: &Resolved) -> bool {
        matches!(
            node,
            Resolved::InferredFacetCapture(_, _)
                | Resolved::Capture(_, _, _)
                | Resolved::Closure(_, _, _, _)
                | Resolved::ExtractorClosure(_, _, _, _)
                | Resolved::CaptureClosure(_, _, _, _)
                | Resolved::Grouped(_, _)
                | Resolved::ReturnTypeArgumentApply(_, _, _)
        )
    }

    fn expected_callable_ty(&mut self, contract: &ExpectedCallableContract) -> Ty {
        match contract.slot {
            ExpectedCallableSlot::Plain | ExpectedCallableSlot::Contextual => {}
        }
        Ty::Func(
            vec![self.resolve_ty(&contract.input)],
            Box::new(
                contract
                    .ret
                    .as_ref()
                    .map(|ret| self.resolve_ty(ret))
                    .unwrap_or_else(|| self.env.fresh_tyvar()),
            ),
        )
    }

    fn callable_contract(
        &mut self,
        input_ty: &Ty,
        ret_ty: Option<Ty>,
        slot: ExpectedCallableSlot,
    ) -> ExpectedCallableContract {
        ExpectedCallableContract {
            input: self.resolve_ty(input_ty),
            ret: ret_ty.map(|ty| self.resolve_ty(&ty)),
            slot,
        }
    }

    fn check_apply_callable_with_contract(
        &mut self,
        node: &Resolved,
        contract: &ExpectedCallableContract,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        if Self::can_use_expected_callable_context(node) {
            let expected = self.expected_callable_ty(contract);
            self.check_node_with_expected(node, Some(&expected))
        } else {
            self.check_apply_callable(node, op_name)
        }
    }

    fn check_compose_callable_with_contract(
        &mut self,
        node: &Resolved,
        contract: &ExpectedCallableContract,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        if Self::can_use_expected_callable_context(node) {
            let expected = self.expected_callable_ty(contract);
            let typed = self.check_node_with_expected(node, Some(&expected))?;
            // Connect contextual output variables to the checked callable before
            // its pending method calls are finalized by the enclosing expression.
            // Input compatibility remains the composition operator's obligation.
            if let Some(output) = &contract.ret {
                let (_, actual_output) =
                    self.unary_function_parts(&typed.ty, op_name, &typed.span)?;
                self.assert_type_relation(
                    output,
                    &actual_output,
                    self.type_fact(SourceRole::Expected, &typed.span, output),
                    self.type_fact(SourceRole::Value, &typed.span, &actual_output),
                    TypeDiagnosticReason::ReturnTypeMismatch,
                    DiagnosticOrigin::Return,
                    op_name,
                    0,
                )?;
            }
            Ok(typed)
        } else {
            self.check_operator_compose_callable(node, op_name)
        }
    }

    fn expected_unary_function_parts(&mut self, expected: Option<&Ty>) -> Option<(Ty, Ty)> {
        let expected = self.resolve_ty(expected?);
        let Ty::Func(params, ret) = expected else {
            return None;
        };
        if params.len() == 1 {
            Some((self.resolve_ty(&params[0]), self.resolve_ty(ret.as_ref())))
        } else {
            None
        }
    }

    fn pending_segment_from_syntax(segment: &ResolvedFacetPathSegment) -> PendingFacetSegment {
        match segment {
            ResolvedFacetPathSegment::Field { name, optional } => PendingFacetSegment::Field {
                name: name.clone(),
                optional: *optional,
            },
            ResolvedFacetPathSegment::Bracket(expr) => match expr.expr.as_ref() {
                Resolved::RangeLiteral(_, start, end) => PendingFacetSegment::RangeBracket {
                    start: PendingFacetExpr::Resolved(start.clone()),
                    end: PendingFacetExpr::Resolved(end.clone()),
                    display: expr.display.clone(),
                },
                _ => PendingFacetSegment::Bracket {
                    expr: PendingFacetExpr::Resolved(expr.expr.clone()),
                    display: expr.display.clone(),
                },
            },
        }
    }

    fn pending_field_segment(name: impl Into<String>) -> PendingFacetSegment {
        PendingFacetSegment::Field {
            name: name.into(),
            optional: false,
        }
    }

    fn pending_segment_display(segment: &PendingFacetSegment) -> String {
        match segment {
            PendingFacetSegment::Field { name, optional } => {
                if *optional {
                    format!("{name}?")
                } else {
                    name.clone()
                }
            }
            PendingFacetSegment::Bracket { display, .. }
            | PendingFacetSegment::RangeBracket { display, .. } => format!("[{display}]"),
        }
    }

    fn inferred_facet_capture_display(segments: &[ResolvedFacetPathSegment]) -> String {
        if segments.is_empty() {
            "_".to_string()
        } else {
            format!(
                "_.{}",
                segments
                    .iter()
                    .map(|segment| match segment {
                        ResolvedFacetPathSegment::Field { name, optional } => {
                            if *optional {
                                format!("{name}?")
                            } else {
                                name.clone()
                            }
                        }
                        ResolvedFacetPathSegment::Bracket(expr) => format!("[{}]", expr.display),
                    })
                    .collect::<Vec<_>>()
                    .join(".")
            )
        }
    }

    fn inferred_capture_body(
        span: &Span,
        param_id: &ResolvedId,
        segments: &[ResolvedFacetPathSegment],
    ) -> Resolved {
        segments.iter().fold(
            Resolved::Var(span.clone(), param_id.clone()),
            |expr, segment| match segment {
                ResolvedFacetPathSegment::Field {
                    name,
                    optional: false,
                } => Resolved::FieldAccess(span.clone(), Box::new(expr), name.clone()),
                other => Resolved::FacetSegmentAccess(span.clone(), Box::new(expr), other.clone()),
            },
        )
    }

    fn check_inferred_facet_capture(
        &mut self,
        span: &Span,
        segments: &[ResolvedFacetPathSegment],
        expected_ty: &Ty,
    ) -> Result<TypedNode, TypeError> {
        let expected_ty = self.resolve_ty(expected_ty);
        let Ty::Func(params, _) = &expected_ty else {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} requires expected unary function context",
                    Self::inferred_facet_capture_display(segments)
                ),
                span: span.clone(),
                hint: Some(format!(
                    "Expected a function type like `(A -> B)`, got {}. Use an explicit capture such as `&Type.field` when no context is available.",
                    self.ty_name(&expected_ty)
                )),
            });
        };
        if params.len() != 1 {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} requires expected unary function context",
                    Self::inferred_facet_capture_display(segments)
                ),
                span: span.clone(),
                hint: Some(format!(
                    "Expected a one-argument function type, got {}.",
                    self.ty_name(&expected_ty)
                )),
            });
        }

        let param_id = ResolvedId {
            name: "__inferred_facet_capture_arg".to_string(),
            qualified_name: None,
            symbol_info: None,
            unique_id: Self::next_synthetic_range_uid(),
            compiler_generated: true,
            span: span.clone(),
        };
        let body = Self::inferred_capture_body(span, &param_id, segments);
        let synthetic = Resolved::CaptureClosure(
            span.clone(),
            vec![ResolvedClosureParam {
                lazy_capture: None,
                id: param_id,
                ty: None,
            }],
            Vec::new(),
            Box::new(body),
        );
        let typed = self.check_node_with_expected(&synthetic, Some(&expected_ty))?;
        if !self.types_compatible(&expected_ty, &typed.ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} inferred type mismatch: expected {}, got {}",
                    Self::inferred_facet_capture_display(segments),
                    self.ty_name(&expected_ty),
                    self.ty_name(&typed.ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }
        Ok(typed)
    }

    // Imported references retain their declaration UID; same-named local bindings do not.
    // Select standard type-dependent behavior by that UID, never by call-site spelling.
    fn is_standard_callable(&self, func: &Resolved, qualified_name: &str) -> bool {
        let target = match func {
            Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
            _ => func,
        };
        let Resolved::Var(_, id) = target else {
            return false;
        };
        self.function_ids_by_name
            .get(qualified_name)
            .is_some_and(|declaration| declaration.unique_id == id.unique_id)
    }

    fn is_function_on_callee(&self, func: &Resolved) -> bool {
        self.is_standard_callable(func, "Function::on")
    }

    fn is_function_curry_callee(&self, func: &Resolved) -> bool {
        self.is_standard_callable(func, "Function::curry")
    }

    fn curry_source_captures(node: &TypedNode, out: &mut Vec<ResolvedId>) {
        let mut add = |id: &ResolvedId| {
            if !out
                .iter()
                .any(|existing| existing.unique_id == id.unique_id)
            {
                out.push(id.clone());
            }
        };
        match &node.node {
            TypedInner::Var(id) => add(id),
            TypedInner::Capture(target, _) => Self::curry_source_captures(target, out),
            TypedInner::Closure(_, captures, _)
            | TypedInner::ExtractorClosure(_, captures, _)
            | TypedInner::CaptureClosure(_, captures, _) => captures.iter().for_each(&mut add),
            TypedInner::CaptureConstructorClosure(_, _, captures, _) => {
                captures.iter().for_each(&mut add)
            }
            _ => {}
        }
    }

    fn check_function_curry(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let [ResolvedRecordLitArg::Positional(source)] = args else {
            return Err(TypeError {
                structured: None,
                message: "Function::curry expects exactly one positional callable".into(),
                span: span.clone(),
                hint: None,
            });
        };
        if matches!(source, Resolved::App(..)) {
            return Err(TypeError {
                structured: None,
                message: "Function::curry requires a function value, not a function call".into(),
                span: self.resolved_span(source).clone(),
                hint: Some(
                    "Use `&f`, `&Type::method`, a closure, or a bound callable value.".into(),
                ),
            });
        }

        let trait_capture = match source {
            Resolved::Capture(_, target, _) => self.trait_method_ref(target).is_some(),
            _ => false,
        };
        let typed_source = if trait_capture {
            // Trait helper captures need a callable context to resolve their
            // receiver. The current trait-helper surface used by Function is
            // binary; the resulting signature is then validated below.
            let expected = Ty::Func(
                vec![self.env.fresh_tyvar(), self.env.fresh_tyvar()],
                Box::new(self.env.fresh_tyvar()),
            );
            self.check_node_with_expected(source, Some(&expected))?
        } else {
            self.check_node(source)?
        };
        let source_ty = self.resolve_ty(&typed_source.ty);
        let (params, ret) = match &source_ty {
            Ty::Func(params, ret) => (params.clone(), ret.as_ref().clone()),
            // A named function is only a valid curry input through an explicit
            // capture. A bare function name must retain the language's existing
            // function-value restriction.
            Ty::UserFunc { .. } | Ty::BuiltinFunc { .. } => {
                return Err(TypeError {
                    structured: None,
                    message: "Function::curry requires an explicit function capture".into(),
                    span: self.resolved_span(source).clone(),
                    hint: Some(
                        "Use `curry(&function)` or bind a closure/callable value first.".into(),
                    ),
                });
            }
            _ => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Function::curry requires a function value, got {}",
                        self.ty_name(&source_ty)
                    ),
                    span: typed_source.span.clone(),
                    hint: None,
                });
            }
        };
        if params.len() < 2 {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Function::curry requires a function with at least two arguments, got {}",
                    params.len()
                ),
                span: typed_source.span.clone(),
                hint: None,
            });
        }

        let mut source_captures = Vec::new();
        Self::curry_source_captures(&typed_source, &mut source_captures);
        let mut parameter_ids = Vec::with_capacity(params.len());
        for index in 0..params.len() {
            parameter_ids.push(ResolvedId {
                name: format!("__curry_arg_{index}"),
                qualified_name: None,
                symbol_info: None,
                unique_id: Self::next_synthetic_range_uid(),
                compiler_generated: true,
                span: span.clone(),
            });
        }

        let mut callable = typed_source;
        let mut result_ty = ret;
        for index in (0..params.len()).rev() {
            let mut call_args = Vec::with_capacity(params.len());
            for (arg_index, param_ty) in params.iter().enumerate() {
                let arg_ty = self.resolve_ty(param_ty);
                call_args.push(TypedNode {
                    ty: arg_ty,
                    span: span.clone(),
                    node: TypedInner::Var(parameter_ids[arg_index].clone()),
                });
            }
            if index < params.len() - 1 {
                // The nested closure is already the value produced by the
                // suffix of the chain; only the outermost body calls the
                // original callable.
                call_args.clear();
            }
            let body = if index == params.len() - 1 {
                TypedNode {
                    ty: self.resolve_ty(&result_ty),
                    span: span.clone(),
                    node: TypedInner::App(Box::new(callable.clone()), call_args),
                }
            } else {
                callable
            };
            let mut captures = source_captures.clone();
            captures.extend(parameter_ids[..index].iter().cloned());
            let closure_ty = Ty::Func(
                vec![self.resolve_ty(&params[index])],
                Box::new(self.resolve_ty(&result_ty)),
            );
            callable = TypedNode {
                ty: closure_ty,
                span: span.clone(),
                node: TypedInner::Closure(
                    vec![TypedClosureParam {
                        id: parameter_ids[index].clone(),
                        ty: self.resolve_ty(&params[index]),
                    }],
                    captures,
                    Box::new(body),
                ),
            };
            result_ty = callable.ty.clone();
        }
        Ok(callable)
    }

    fn check_function_on_with_expected(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        expected_ty: &Ty,
    ) -> Result<TypedNode, TypeError> {
        let expected_ty = self.resolve_ty(expected_ty);
        let Ty::Func(params, ret) = &expected_ty else {
            return self.check_app(span, func, args);
        };
        if params.len() != 2 || !self.types_compatible(&params[0], &params[1])? {
            return self.check_app(span, func, args);
        }
        let [ResolvedRecordLitArg::Positional(compare_expr), ResolvedRecordLitArg::Positional(key_expr)] =
            args
        else {
            return self.check_app(span, func, args);
        };

        let source_ty = self.resolve_ty(&params[0]);
        let key_ty = self.env.fresh_tyvar();
        let key_expected = Ty::Func(vec![source_ty.clone()], Box::new(key_ty.clone()));
        let typed_key = self.check_node_with_expected(key_expr, Some(&key_expected))?;
        self.assert_type_relation(
            &key_expected,
            &typed_key.ty,
            self.type_fact(SourceRole::Expected, span, &key_expected),
            self.type_fact(SourceRole::Value, &typed_key.span, &typed_key.ty),
            TypeDiagnosticReason::ArgumentTypeMismatch,
            DiagnosticOrigin::Call,
            "Function::on",
            1,
        )?;
        let key_ty = self.resolve_ty(&key_ty);
        let compare_expected = Ty::Func(
            vec![self.resolve_ty(&key_ty), self.resolve_ty(&key_ty)],
            Box::new(self.resolve_ty(ret.as_ref())),
        );
        let typed_compare = self.check_node_with_expected(compare_expr, Some(&compare_expected))?;
        self.assert_type_relation(
            &compare_expected,
            &typed_compare.ty,
            self.type_fact(SourceRole::Expected, span, &compare_expected),
            self.type_fact(SourceRole::Value, &typed_compare.span, &typed_compare.ty),
            TypeDiagnosticReason::ArgumentTypeMismatch,
            DiagnosticOrigin::Call,
            "Function::on",
            0,
        )?;

        let typed_func = self.check_node(func)?;
        let result_ty = Ty::Func(
            vec![source_ty.clone(), source_ty],
            Box::new(self.resolve_ty(ret)),
        );
        Ok(TypedNode {
            ty: result_ty,
            span: span.clone(),
            node: TypedInner::App(Box::new(typed_func), vec![typed_compare, typed_key]),
        })
    }

    pub(super) fn check_function_value_operand(
        &mut self,
        node: &Resolved,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        let typed = self.check_node(node)?;
        if matches!(self.resolve_ty(&typed.ty), Ty::Func(_, _)) {
            Ok(typed)
        } else {
            Err(self
                .callable_shape_error(&typed.ty, op_name, &typed.span, Some(1))
                .with_hint(self.compose_function_value_hint(&typed, op_name)))
        }
    }

    fn compose_call_signature_hint(&self, func: &TypedNode) -> Option<String> {
        match (&func.node, self.resolve_ty(&func.ty)) {
            (TypedInner::Var(id), Ty::BuiltinFunc { params, ret, .. })
            | (TypedInner::Var(id), Ty::UserFunc { params, ret, .. }) => {
                Some(self.call_target_signature_hint_for_id(id, &params, ret.as_ref()))
            }
            (_, Ty::BuiltinFunc { name, params, ret }) => {
                Some(self.call_target_signature_hint(&name, &params, ret.as_ref(), None))
            }
            (_, Ty::UserFunc { params, ret, .. }) => {
                self.callable_definition_signature_hint(func, &params, ret.as_ref())
            }
            (_, Ty::Func(params, ret)) => {
                self.callable_signature_hint(&Ty::Func(params.clone(), ret.clone()))
            }
            _ => None,
        }
    }

    fn compose_function_value_hint(&self, typed: &TypedNode, op_name: &str) -> String {
        if let TypedInner::App(func, _) = &typed.node {
            let signature = self
                .compose_call_signature_hint(func)
                .unwrap_or_else(|| "Call target signature: <unknown>".into());
            format!(
                "{}\n`{}` evaluates this call before composition; the result type {} is not a function value.",
                signature,
                op_name,
                self.diagnostic_ty_name(&typed.ty)
            )
        } else {
            format!(
                "{} works on one-argument function values. Bare function names are not function values; use `&name`, a closure, a function-typed variable, or a call that returns a function value.",
                op_name
            )
        }
    }

    fn tuple_index_hint(tuple_len: usize) -> String {
        if tuple_len == 0 {
            "This tuple has 0 elements, so no tuple selectors are available.".into()
        } else {
            let selectors = (0..tuple_len)
                .map(|idx| format!("._{}", idx))
                .collect::<Vec<_>>()
                .join(", ");
            format!(
                "This tuple has {} element(s); valid selectors are {}.",
                tuple_len, selectors
            )
        }
    }

    pub(super) fn resolved_span<'a>(&self, node: &'a Resolved) -> &'a Span {
        match node {
            Resolved::Lit(span, _)
            | Resolved::Var(span, _)
            | Resolved::ErrorKind(span, _)
            | Resolved::App(span, _, _)
            | Resolved::LazyApp(span, _, _, _)
            | Resolved::ReturnTypeArgumentApply(span, _, _)
            | Resolved::Block(span, _)
            | Resolved::Bind(span, _, _)
            | Resolved::ApplyPattern(span, _, _)
            | Resolved::SafeBind(span, _, _, _)
            | Resolved::StatementQuestion(span, _)
            | Resolved::Do(span, _, _, _, _)
            | Resolved::BinOp(span, _, _, _)
            | Resolved::Pipe(span, _, _)
            | Resolved::ContextMap(span, _, _)
            | Resolved::ContextApply(span, _, _)
            | Resolved::ContextBind(span, _, _)
            | Resolved::Compose(span, _, _)
            | Resolved::LiftedCompose(span, _, _)
            | Resolved::KleisliCompose(span, _, _)
            | Resolved::ListNil(span)
            | Resolved::ListCons(span, _, _)
            | Resolved::ListLiteral(span, _)
            | Resolved::HashMapLiteral(span, _)
            | Resolved::RangeLiteral(span, _, _)
            | Resolved::TupleLiteral(span, _)
            | Resolved::Grouped(span, _)
            | Resolved::InterpolatedStr(span, _)
            | Resolved::Dbg(span, _)
            | Resolved::Cond(span, _)
            | Resolved::If(span, _, _, _)
            | Resolved::Cause(span, _, _)
            | Resolved::IfLet(span, _, _, _)
            | Resolved::Match(span, _, _)
            | Resolved::IsMatch(span, _, _)
            | Resolved::FieldAccess(span, _, _)
            | Resolved::FacetSegmentAccess(span, _, _)
            | Resolved::InferredFacetCapture(span, _)
            | Resolved::FacetCapture(span, _)
            | Resolved::ProcessContextHandler(span, _)
            | Resolved::StructLit(span, _, _)
            | Resolved::ConstructorCall(span, _, _)
            | Resolved::EnumConstructorCall(span, _, _, _)
            | Resolved::StructDef(span, ..)
            | Resolved::RecordDef(span, _, _, _)
            | Resolved::DeferrorDef(span, _, _, _)
            | Resolved::EnumDef(span, _, _, _, _)
            | Resolved::Def(span, _, _, _, _, _, _, _)
            | Resolved::ConstDef(span, _, _, _, _)
            | Resolved::ExtractorDef(span, _, _, _, _, _, _)
            | Resolved::BuiltinDecl(span, _, _, _, _, _, _)
            | Resolved::BuiltinExtractorDecl(span, _, _, _, _)
            | Resolved::BuiltinTypeDecl(span, _, _, _)
            | Resolved::TypeAlias(span, _, _, _, _)
            | Resolved::TraitDef(span, _, _, _, _, _)
            | Resolved::TraitImplDef(span, _, _, _, _, _, _)
            | Resolved::Closure(span, _, _, _)
            | Resolved::ExtractorClosure(span, _, _, _)
            | Resolved::CaptureClosure(span, _, _, _)
            | Resolved::Capture(span, _, _)
            | Resolved::Semi(span, _) => span,
        }
    }

    pub(super) fn function_parts<'a>(&'a self, ty: &'a Ty) -> Option<(&'a [Ty], &'a Ty)> {
        match ty {
            Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                Some((params.as_slice(), ret.as_ref()))
            }
            Ty::Func(params, ret) => Some((params.as_slice(), ret.as_ref())),
            _ => None,
        }
    }

    pub(super) fn callable_signature_from_parts(&self, params: &[Ty], ret: &Ty) -> String {
        let ty_refs = params
            .iter()
            .map(|ty| ty as &Ty)
            .chain(std::iter::once(ret))
            .collect::<Vec<_>>();
        let rendered = self.diagnostic_ty_names(&ty_refs);
        let (rendered_params, rendered_ret) = rendered.split_at(params.len());
        let param_str = rendered_params.join(", ");
        if param_str.is_empty() {
            format!("(-> {})", rendered_ret[0])
        } else {
            format!("({} -> {})", param_str, rendered_ret[0])
        }
    }

    pub(super) fn callable_signature_for_ty(&self, ty: &Ty) -> Option<String> {
        self.function_parts(ty)
            .map(|(params, ret)| self.callable_signature_from_parts(params, ret))
    }

    pub(super) fn callable_signature_hint(&self, ty: &Ty) -> Option<String> {
        self.callable_signature_for_ty(ty)
            .map(|sig| format!("Callable type signature: {}", sig))
    }

    pub(super) fn call_target_signature_hint(
        &self,
        display_name: &str,
        params: &[Ty],
        ret: &Ty,
        first_param_name: Option<&str>,
    ) -> String {
        let ty_refs = params
            .iter()
            .map(|ty| ty as &Ty)
            .chain(std::iter::once(ret))
            .collect::<Vec<_>>();
        let rendered = self.diagnostic_ty_names(&ty_refs);
        let (rendered_params, rendered_ret) = rendered.split_at(params.len());
        let param_list = params
            .iter()
            .enumerate()
            .map(|(idx, ty)| {
                let name = match (idx, first_param_name) {
                    (0, Some(name)) => name.to_string(),
                    _ => format!("arg{}", idx + 1),
                };
                let rendered_ty = &rendered_params[idx];
                let _ = ty;
                format!("{}: {}", name, rendered_ty)
            })
            .collect::<Vec<_>>()
            .join(", ");
        format!(
            "Call target signature: {}({}) -> {}",
            display_name, param_list, rendered_ret[0]
        )
    }

    pub(super) fn callable_target_display_name(&self, id: &ResolvedId) -> String {
        if let Some(qualified_name) = id.qualified_name.as_deref() {
            return callable_definition_display_name(qualified_name, &id.name);
        }
        if sindr::builtin::builtin_meta_by_name(&id.name).is_some() {
            return format!("Kernel::{}", id.name);
        }
        id.name.clone()
    }

    pub(super) fn call_target_signature_hint_for_id(
        &self,
        id: &ResolvedId,
        params: &[Ty],
        ret: &Ty,
    ) -> String {
        let display_name = self.callable_target_display_name(id);
        self.call_target_signature_hint(&display_name, params, ret, None)
    }

    pub(super) fn trait_method_signature_hint(
        &self,
        trait_display_name: &str,
        method_name: &str,
        params: &[Ty],
        ret: &Ty,
    ) -> String {
        self.call_target_signature_hint(
            &format!("{}::{}", trait_display_name, method_name),
            params,
            ret,
            Some("self"),
        )
    }

    pub(super) fn callable_definition_signature_hint(
        &self,
        func: &TypedNode,
        params: &[Ty],
        ret: &Ty,
    ) -> Option<String> {
        let TypedInner::Var(id) = &func.node else {
            return None;
        };
        let qualified_name = id.qualified_name.as_deref().unwrap_or(&id.name);
        let display_name = callable_definition_display_name(qualified_name, &id.name);
        let mut hint = format!(
            "Callable definition signature: {}",
            self.callable_definition_signature(&display_name, id.unique_id, params, ret)
        );
        if let Some(def_span) = self
            .function_ids_by_name
            .values()
            .find(|decl| decl.unique_id == id.unique_id)
            .map(|decl| decl.span.clone())
        {
            hint.push_str(&format!(
                "\nCallable definition span: {}..{}",
                def_span.start, def_span.end
            ));
        }
        Some(hint)
    }

    fn callable_definition_signature(
        &self,
        qualified_name: &str,
        uid: u32,
        params: &[Ty],
        ret: &Ty,
    ) -> String {
        let param_names = self.user_func_params.get(&uid);
        let param_list = params
            .iter()
            .enumerate()
            .map(|(idx, ty)| {
                let name = param_names
                    .and_then(|names| names.get(idx))
                    .map(String::as_str)
                    .unwrap_or("_");
                format!("{}: {}", name, self.ty_name(ty))
            })
            .collect::<Vec<_>>()
            .join(", ");
        let ret = self.ty_name(ret);

        if let Some(display) = trait_impl_signature_display(qualified_name, &param_list, &ret) {
            return display;
        }

        format!("{}({}) -> {}", qualified_name, param_list, ret)
    }

    pub(super) fn unary_function_parts(
        &self,
        ty: &Ty,
        callable: &str,
        span: &Span,
    ) -> Result<(Ty, Ty), TypeError> {
        let Some((params, ret)) = self.function_parts(ty) else {
            return Err(self.callable_shape_error(ty, callable, span, Some(1)));
        };
        if params.len() != 1 {
            return Err(self.callable_shape_error(ty, callable, span, Some(1)));
        }
        Ok((self.resolve_ty(&params[0]), self.resolve_ty(ret)))
    }

    pub(super) fn trait_method_ref<'a>(
        &self,
        func: &'a Resolved,
    ) -> Option<(&'a ResolvedId, String, String)> {
        let func = match func {
            Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
            other => other,
        };
        let Resolved::Var(_, id) = func else {
            return None;
        };
        let qualified_name = id.qualified_name.as_ref()?;
        let (trait_name, method_name) = self
            .trait_methods_by_qualified_name
            .get(qualified_name)?
            .clone();
        Some((id, trait_name, method_name))
    }

    fn explicit_type_args(func: &Resolved) -> Option<Vec<AstTy>> {
        match func {
            Resolved::ReturnTypeArgumentApply(_, _, args) => Some(
                args.iter()
                    .map(|argument| argument.ty.syntax.clone())
                    .collect(),
            ),
            _ => None,
        }
    }

    pub(super) fn trait_dispatch_target_for_args(
        &mut self,
        trait_name: &str,
        _method_name: &str,
        receiver_ty: &Ty,
        requested_trait_args: &[Ty],
    ) -> Result<Option<TraitDispatch>, TypeError> {
        let receiver_ty = self.resolve_ty(receiver_ty);
        Ok(
            match self.probe_trait_head(trait_name, requested_trait_args, &receiver_ty)? {
                ApplicabilityProof::Satisfied(evidence) => {
                    for index in evidence {
                        self.active_capabilities[index].consumed = true;
                    }
                    Some(TraitDispatch::Pending)
                }
                ApplicabilityProof::Deferred(waiting_on) => {
                    for var in waiting_on {
                        let pending = self.pending_trait_obligations.entry(var).or_default();
                        let obligation = PendingTraitObligation {
                            trait_id: trait_name.into(),
                            args: requested_trait_args.to_vec(),
                            receiver: receiver_ty.clone(),
                        };
                        if !pending.contains(&obligation) {
                            pending.push(obligation);
                        }
                    }
                    Some(TraitDispatch::Pending)
                }
                ApplicabilityProof::Unsatisfied => None,
            },
        )
    }

    fn operator_trait_dispatch_for_args(
        &mut self,
        trait_name: &str,
        method_name: &str,
        receiver_ty: &Ty,
        requested_trait_args: &[Ty],
        argument_tys: &[Ty],
        result_ty: &Ty,
    ) -> Result<Option<(TraitDispatch, Vec<Ty>)>, TypeError> {
        let profile = self.profiler.start();
        let dispatch = self.select_method_dispatch(
            trait_name,
            method_name,
            receiver_ty,
            requested_trait_args,
            argument_tys,
            result_ty,
        );
        self.profiler
            .finish(ProfileEvent::OperatorTraitCandidateScan, profile);
        Ok(dispatch?.map(|dispatch| {
            (
                dispatch,
                requested_trait_args
                    .iter()
                    .map(|ty| self.resolve_ty(ty))
                    .collect(),
            )
        }))
    }

    fn constructor_target_dispatch(
        &mut self,
        trait_name: &str,
        method_name: &str,
        expected_ty: &Ty,
    ) -> Result<Option<TraitDispatch>, TypeError> {
        if let Ty::Var(var) = self.resolve_ty(expected_ty) {
            return Ok(
                if !self.rigid_tyvars.contains(&var)
                    || self.tyvar_has_bound(var, trait_name)
                    || self.tyvar_satisfies_compiler_trait(var, trait_name)
                {
                    Some(TraitDispatch::Pending)
                } else {
                    None
                },
            );
        }
        let expected_ty = self.resolve_ty(expected_ty);
        if let Ty::SelfApp(items) = &expected_ty {
            if let Some((witness, _)) = Self::constructor_application_parts(items) {
                return Ok(match self.resolve_ty(witness) {
                    Ty::Var(_) if self.constructor_witness_supports_trait(witness, trait_name) => {
                        Some(TraitDispatch::Pending)
                    }
                    _ => None,
                });
            }
            // A plain Self application is the declaration-owned abstract
            // carrier used while checking a generic constructor helper body.
            // Its dispatch must remain pending until the enclosing call site
            // supplies a concrete carrier.
            return Ok(Some(TraitDispatch::Pending));
        }
        self.select_method_dispatch(
            trait_name,
            method_name,
            &expected_ty,
            &[],
            &[],
            &expected_ty,
        )
    }

    fn constructor_witness_supports_trait(&mut self, witness: &Ty, trait_name: &str) -> bool {
        let Ty::Var(var) = self.resolve_ty(witness) else {
            return false;
        };
        if self.tyvar_has_bound(var, trait_name)
            || self.tyvar_satisfies_compiler_trait(var, trait_name)
        {
            return true;
        }
        let Some(source_trait) = self.constructor_witness_traits.get(&var).cloned() else {
            return false;
        };
        self.constructor_capability_allows(&source_trait, trait_name, &mut HashSet::new())
    }

    fn constructor_slot_type_for(
        &mut self,
        trait_name: &str,
        container_ty: &Ty,
    ) -> ConstructorApplicationOutcome {
        if let Ty::SelfApp(items) = self.resolve_ty(container_ty) {
            return match Self::constructor_application_parts(&items) {
                Some((witness, [slot]))
                    if self.constructor_witness_supports_trait(witness, trait_name) =>
                {
                    ConstructorApplicationOutcome::Applied(slot.clone())
                }
                Some((_, slots)) if slots.len() != 1 => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::SlotCountMismatch {
                        expected: 1,
                        actual: slots.len(),
                    }],
                },
                Some(_) => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::NoApplicableImplementation],
                },
                None => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::UnsupportedConstructor],
                },
            };
        }
        match self.constructor_projection(trait_name, container_ty) {
            ConstructorProjectionOutcome::Applicable { info, mapping } => {
                let [slot] = info.constructor_slot_vars.as_slice() else {
                    return ConstructorApplicationOutcome::Rejected {
                        failures: vec![ConstructorProjectionFailure::SlotCountMismatch {
                            expected: 1,
                            actual: info.constructor_slot_vars.len(),
                        }],
                    };
                };
                match mapping.get(slot).cloned() {
                    Some(slot) => ConstructorApplicationOutcome::Applied(slot),
                    None => ConstructorApplicationOutcome::Rejected {
                        failures: vec![
                            ConstructorProjectionFailure::MissingConstructorSlotMapping {
                                variable: *slot,
                            },
                        ],
                    },
                }
            }
            ConstructorProjectionOutcome::Deferred { waiting_on } => {
                ConstructorApplicationOutcome::Deferred { waiting_on }
            }
            ConstructorProjectionOutcome::Rejected { failures } => {
                ConstructorApplicationOutcome::Rejected { failures }
            }
        }
    }

    fn constructor_context_type_for(
        &mut self,
        trait_name: &str,
        container_ty: &Ty,
        slot_ty: &Ty,
    ) -> ConstructorApplicationOutcome {
        if let Ty::SelfApp(items) = self.resolve_ty(container_ty) {
            return match Self::constructor_application_parts(&items) {
                Some((witness, [_]))
                    if self.constructor_witness_supports_trait(witness, trait_name) =>
                {
                    ConstructorApplicationOutcome::Applied(Ty::SelfApp(vec![
                        Ty::Hole,
                        witness.clone(),
                        slot_ty.clone(),
                    ]))
                }
                Some((_, slots)) if slots.len() != 1 => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::SlotCountMismatch {
                        expected: 1,
                        actual: slots.len(),
                    }],
                },
                Some(_) => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::NoApplicableImplementation],
                },
                None => ConstructorApplicationOutcome::Rejected {
                    failures: vec![ConstructorProjectionFailure::UnsupportedConstructor],
                },
            };
        }
        match self.constructor_projection(trait_name, container_ty) {
            ConstructorProjectionOutcome::Applicable { info, mut mapping } => {
                let [slot] = info.constructor_slot_vars.as_slice() else {
                    return ConstructorApplicationOutcome::Rejected {
                        failures: vec![ConstructorProjectionFailure::SlotCountMismatch {
                            expected: 1,
                            actual: info.constructor_slot_vars.len(),
                        }],
                    };
                };
                mapping.insert(*slot, slot_ty.clone());
                ConstructorApplicationOutcome::Applied(
                    self.resolve_ty(&self.substitute_ty_with_mapping(&info.target_ty, &mapping)),
                )
            }
            ConstructorProjectionOutcome::Deferred { waiting_on } => {
                ConstructorApplicationOutcome::Deferred { waiting_on }
            }
            ConstructorProjectionOutcome::Rejected { failures } => {
                ConstructorApplicationOutcome::Rejected { failures }
            }
        }
    }

    pub(super) fn require_constructor_projection_type(
        &self,
        outcome: ConstructorApplicationOutcome,
        trait_name: &str,
        subject: &Ty,
        span: &Span,
        operation: &str,
    ) -> Result<Ty, TypeError> {
        match outcome
            .into_checked()
            .map_err(|error| error.at_span(span))?
        {
            ConstructorApplicationOutcome::Applied(ty) => Ok(ty),
            ConstructorApplicationOutcome::Deferred { waiting_on } => {
                let mut error = self.ambiguous_constructor_result(trait_name, operation, span);
                error.hint = Some(format!(
                    "Resolve all {} constructor input(s) before using this operation.",
                    waiting_on.len()
                ));
                Err(error)
            }
            ConstructorApplicationOutcome::Rejected { failures }
                if Self::constructor_projection_failures_are_metadata(&failures) =>
            {
                Err(signatures::constructor_signature_metadata_error(
                    operation,
                    span,
                    Self::constructor_projection_failure_detail(&failures),
                ))
            }
            ConstructorApplicationOutcome::Rejected { .. } => Err(self.trait_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                trait_name,
                subject,
                span,
                DiagnosticOrigin::TraitCall,
            )),
        }
    }

    /// Enumerate the concrete constructor contexts which can carry `slot_ty`.
    /// This is used when a constructor helper appears on the opposite side of
    /// an operator and the other operand must provide the missing `Self`.
    fn constructor_context_candidates(
        &mut self,
        trait_name: &str,
        slot_ty: &Ty,
    ) -> Result<Vec<Ty>, TypeError> {
        let mut candidates = Vec::new();
        for impl_key in self.trait_impl_candidate_keys(trait_name) {
            let Some(impl_info) = self.trait_impls.get(&impl_key).cloned() else {
                continue;
            };
            if impl_info.constructor_slot_vars.len() != 1 {
                continue;
            }
            let mut fresh = HashMap::new();
            let _target = self.instantiate_ty_with_fresh(&impl_info.target_ty, &mut fresh);
            let slot = impl_info.constructor_slot_vars[0];
            let mapping = impl_info
                .type_param_vars
                .iter()
                .copied()
                .map(|var| {
                    let replacement = if var == slot {
                        slot_ty.clone()
                    } else {
                        fresh
                            .get(&var)
                            .map(|ty| self.resolve_ty(ty))
                            .ok_or_else(|| {
                                TypeError::new(
                                    "Constructor candidate lacks fresh type input metadata",
                                    impl_info.trait_id.span.clone(),
                                )
                            })?
                    };
                    Ok((var, replacement))
                })
                .collect::<Result<HashMap<_, _>, TypeError>>()?;
            candidates.push(
                self.resolve_ty(&self.substitute_ty_with_mapping(&impl_info.target_ty, &mapping)),
            );
        }
        Ok(candidates)
    }

    fn opposite_conversion_hint(
        &self,
        trait_name: &str,
        method_name: &str,
        receiver_ty: &Ty,
        requested_trait_args: &[Ty],
        span: &Span,
    ) -> Option<TypeError> {
        let requested_trait = if self.trait_matches_short_name(trait_name, "Convert") {
            "Convert"
        } else if self.trait_matches_short_name(trait_name, "TryConvert") {
            "TryConvert"
        } else {
            return None;
        };
        let opposite_trait = if requested_trait == "Convert" {
            "TryConvert"
        } else {
            "Convert"
        };
        let receiver_name = self.trait_target_name(receiver_ty)?;
        let target_ty = self.resolve_ty(requested_trait_args.first()?);
        let opposite_trait_key = self.trait_key_by_short_name(opposite_trait)?;
        let receiver_ty = self.resolve_ty(receiver_ty);
        let has_opposite_impl = self.trait_impls.values().any(|impl_info| {
            self.trait_key(&impl_info.trait_id) == opposite_trait_key
                && impl_info.trait_arg_tys == [target_ty.clone()]
                && impl_info.target_ty == receiver_ty
        });
        if !has_opposite_impl {
            return None;
        }

        let target_name = self.ty_name(&target_ty);
        let opposite_method = if opposite_trait == "Convert" {
            "to"
        } else {
            "try_to"
        };
        Some(TypeError {
            structured: None,
            message: format!(
                "{} -> {} implements {}, not {}. Use {}::<{}>(value).",
                receiver_name,
                target_name,
                opposite_trait,
                requested_trait,
                opposite_method,
                target_name
            ),
            span: span.clone(),
            hint: Some(format!(
                "{}::{} is not available for this conversion pair.",
                self.trait_display_name(trait_name),
                method_name
            )),
        })
    }

    pub(super) fn check_trait_method_call(
        &mut self,
        span: &Span,
        trait_name: &str,
        method_name: &str,
        args: &[ResolvedRecordLitArg],
        receiver_owner_hint: Option<&str>,
        expected_ret_ty: Option<&Ty>,
        explicit_type_args: Option<&[AstTy]>,
    ) -> Result<TypedNode, TypeError> {
        self.check_trait_invocation(
            span,
            trait_name,
            method_name,
            args,
            receiver_owner_hint,
            expected_ret_ty,
            None,
            None,
            None,
            explicit_type_args,
            None,
            None,
        )
    }

    fn constructor_trait_arguments_shared_with_target(info: &TraitImplInfo) -> Vec<usize> {
        let mut target_variables = Vec::new();
        Self::collect_ty_vars(&info.target_ty, &mut target_variables);
        let target_variables = target_variables.into_iter().collect::<HashSet<_>>();
        info.trait_arg_tys
            .iter()
            .enumerate()
            .filter_map(|(index, argument)| {
                let mut argument_variables = Vec::new();
                Self::collect_ty_vars(argument, &mut argument_variables);
                let argument_variables = argument_variables.into_iter().collect::<HashSet<_>>();
                (!argument_variables.is_empty() && argument_variables.is_subset(&target_variables))
                    .then_some(index)
            })
            .collect()
    }

    fn apply_receiverless_target_candidate(
        &mut self,
        implementation: &TraitImplInfo,
        sourceable_trait_arguments: &[usize],
        span: &Span,
        trait_name: &str,
        method_name: &str,
        args: &[ResolvedRecordLitArg],
        declared_params: &[Ty],
        trait_args: &[Ty],
        self_ty: &Ty,
        expected: &Ty,
        operator: Option<OperatorTraitOp>,
    ) -> Result<Option<Vec<TypedNode>>, TypeError> {
        let mut fresh = HashMap::new();
        let target = self.instantiate_ty_with_fresh(&implementation.target_ty, &mut fresh);
        if self
            .assert_type_relation(
                expected,
                &target,
                self.type_fact(SourceRole::Expected, span, expected),
                self.type_fact(SourceRole::Contract, &implementation.trait_id.span, &target),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::TraitCall,
                &format!("{trait_name}::{method_name}"),
                0,
            )
            .is_err()
        {
            return Ok(None);
        }
        self.assert_type_relation(
            self_ty,
            expected,
            self.type_fact(SourceRole::Expected, span, expected),
            self.type_fact(SourceRole::Contract, &implementation.trait_id.span, self_ty),
            TypeDiagnosticReason::ReturnTypeMismatch,
            DiagnosticOrigin::TraitCall,
            &format!("{trait_name}::{method_name}"),
            0,
        )?;
        if implementation.trait_arg_tys.len() != trait_args.len() {
            return Err(TypeError::new(
                "Trait implementation argument metadata mismatch",
                implementation.trait_id.span.clone(),
            ));
        }
        for index in sourceable_trait_arguments {
            let inferred =
                self.instantiate_ty_with_fresh(&implementation.trait_arg_tys[*index], &mut fresh);
            self.assert_type_relation(
                &trait_args[*index],
                &inferred,
                self.type_fact(
                    SourceRole::Contract,
                    &implementation.trait_id.span,
                    &trait_args[*index],
                ),
                self.type_fact(
                    SourceRole::Expected,
                    &implementation.trait_id.span,
                    &inferred,
                ),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::TraitCall,
                &format!("{trait_name}::{method_name}"),
                *index as u32,
            )?;
        }

        let mut typed_args = Vec::with_capacity(args.len());
        for (index, (argument, parameter)) in args.iter().zip(declared_params).enumerate() {
            let ResolvedRecordLitArg::Positional(argument) = argument else {
                return Ok(None);
            };
            let parameter = self.resolve_ty(parameter);
            let typed = self.check_invocation_argument(
                argument,
                &parameter,
                operator.clone(),
                index,
                None,
            )?;
            self.assert_type_relation(
                &parameter,
                &typed.ty,
                self.type_fact(SourceRole::Expected, &typed.span, &parameter),
                self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::TraitCall,
                &format!("{trait_name}::{method_name}"),
                index as u32,
            )?;
            typed_args.push(typed);
        }
        self.check_trait_method_constructor_capabilities(
            trait_name,
            method_name,
            declared_params,
            None,
            &typed_args,
            None,
        )?;

        let resolved_trait_args = trait_args
            .iter()
            .map(|argument| self.resolve_ty(argument))
            .collect::<Vec<_>>();
        let argument_types = typed_args
            .iter()
            .map(|argument| self.resolve_ty(&argument.ty))
            .collect::<Vec<_>>();
        match self.select_trait_method_instantiation(
            trait_name,
            method_name,
            expected,
            &resolved_trait_args,
            &argument_types,
            expected,
        )? {
            CandidateApplicability::Applicable(instantiation)
                if matches!(
                    instantiation.implementation,
                    TraitImplementationId::Declared { ref declaration, .. }
                        if declaration == &implementation.declaration_key
                ) =>
            {
                Ok(Some(typed_args))
            }
            CandidateApplicability::Applicable(_) => Ok(None),
            CandidateApplicability::Deferred(_) => Err(self.trait_dispatch_failure(
                TypeDiagnosticReason::UnresolvedTraitMethodInstantiation,
                trait_name,
                method_name,
                Some(expected),
                &implementation.trait_id.span,
            )),
            CandidateApplicability::Rejected(_) => Err(self.trait_dispatch_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                trait_name,
                method_name,
                Some(expected),
                &implementation.trait_id.span,
            )),
        }
    }

    fn contextual_receiverless_target_arguments(
        &mut self,
        trait_name: &str,
        method_name: &str,
        span: &Span,
        args: &[ResolvedRecordLitArg],
        declared_params: &[Ty],
        trait_args: &[Ty],
        self_ty: &Ty,
        expected: &Ty,
        operator: Option<OperatorTraitOp>,
    ) -> Result<Option<Vec<TypedNode>>, TypeError> {
        let mut accepted = Vec::new();
        let mut failures = Vec::new();
        for key in self.trait_impl_candidate_keys(trait_name) {
            let Some(implementation) = self.trait_impls.get(&key).cloned() else {
                continue;
            };
            let sourceable = Self::constructor_trait_arguments_shared_with_target(&implementation);
            if sourceable.len() != trait_args.len() || sourceable.is_empty() {
                continue;
            }
            let checkpoint = self.candidate_probe_checkpoint();
            let result = self.apply_receiverless_target_candidate(
                &implementation,
                &sourceable,
                span,
                trait_name,
                method_name,
                args,
                declared_params,
                trait_args,
                self_ty,
                expected,
                operator.clone(),
            );
            match result {
                Ok(Some(_)) => accepted.push((implementation, sourceable)),
                Ok(None) => {}
                Err(error) => failures.push(error),
            }
            self.rollback_candidate_probe(checkpoint);
        }
        match accepted.as_slice() {
            [(implementation, sourceable)] => self
                .apply_receiverless_target_candidate(
                    implementation,
                    sourceable,
                    span,
                    trait_name,
                    method_name,
                    args,
                    declared_params,
                    trait_args,
                    self_ty,
                    expected,
                    operator,
                )
                .map(|arguments| Some(arguments.unwrap_or_default())),
            [] => match failures.into_iter().next() {
                Some(error) => Err(error),
                None => Ok(None),
            },
            _ => Err(self.ambiguous_constructor_result(trait_name, method_name, span)),
        }
    }

    fn assert_trait_return_context(
        &mut self,
        expected: &Ty,
        ret_ty: &Ty,
        span: &Span,
        trait_name: &str,
        expected_ret_relation: Option<(&ExpectedTypeRelation, &Span)>,
    ) -> Result<(), TypeError> {
        let (expected_fact, actual_fact, reason, origin, callable, ordinal) =
            match expected_ret_relation {
                Some((relation, actual_span)) => (
                    self.type_fact(relation.role, &relation.span, expected),
                    self.type_fact(SourceRole::Value, actual_span, &ret_ty),
                    relation.reason,
                    relation.origin.clone(),
                    relation.callable,
                    relation.ordinal,
                ),
                None => (
                    self.type_fact(SourceRole::Expected, span, expected),
                    self.type_fact(SourceRole::Value, span, &ret_ty),
                    TypeDiagnosticReason::ReturnTypeMismatch,
                    DiagnosticOrigin::TraitCall,
                    trait_name,
                    0,
                ),
            };
        let relation_result = self.assert_type_relation(
            expected,
            &ret_ty,
            expected_fact,
            actual_fact,
            reason,
            origin,
            callable,
            ordinal,
        );
        if relation_result.is_err() && reason == TypeDiagnosticReason::ReturnTypeArgumentMismatch {
            let (_, actual_span) =
                expected_ret_relation.expect("return-type-argument relation has source origins");
            return Err(super::signatures::return_type_argument_mismatch_error(
                callable,
                ordinal,
                &self.diagnostic_ty_name(&ret_ty),
                &self.diagnostic_ty_name(expected),
                &expected_ret_relation
                    .expect("return-type-argument relation has explicit origin")
                    .0
                    .span,
                SourceRole::Value,
                actual_span,
            ));
        }
        relation_result?;
        Ok(())
    }

    pub(super) fn check_trait_invocation(
        &mut self,
        span: &Span,
        trait_name: &str,
        method_name: &str,
        args: &[ResolvedRecordLitArg],
        receiver_owner_hint: Option<&str>,
        expected_ret_ty: Option<&Ty>,
        expected_ret_relation: Option<(&ExpectedTypeRelation, &Span)>,
        argument_expected_relation: Option<&ExpectedTypeRelation>,
        constructor_failure_reason: Option<TypeDiagnosticReason>,
        explicit_type_args: Option<&[AstTy]>,
        operator: Option<OperatorTraitOp>,
        receiver_hint: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_trait_invocation_with_result_context(
            span,
            trait_name,
            method_name,
            args,
            receiver_owner_hint,
            expected_ret_ty,
            expected_ret_relation,
            argument_expected_relation,
            constructor_failure_reason,
            explicit_type_args,
            operator,
            receiver_hint,
            false,
        )
    }

    fn check_trait_invocation_with_result_context(
        &mut self,
        span: &Span,
        trait_name: &str,
        method_name: &str,
        args: &[ResolvedRecordLitArg],
        receiver_owner_hint: Option<&str>,
        expected_ret_ty: Option<&Ty>,
        expected_ret_relation: Option<(&ExpectedTypeRelation, &Span)>,
        argument_expected_relation: Option<&ExpectedTypeRelation>,
        constructor_failure_reason: Option<TypeDiagnosticReason>,
        explicit_type_args: Option<&[AstTy]>,
        operator: Option<OperatorTraitOp>,
        receiver_hint: Option<&Ty>,
        defer_incompatible_result_context: bool,
    ) -> Result<TypedNode, TypeError> {
        let call = TraitInvocationContext {
            span,
            trait_name,
            method_name,
            args,
            receiver_owner_hint,
            expected_ret_ty,
            expected_ret_relation,
            argument_expected_relation,
            constructor_failure_reason,
            explicit_type_args,
            operator,
            receiver_hint,
            defer_incompatible_result_context,
        };
        // Release signature/projection temporaries before recursively checking
        // argument bodies (notably the next continuation in a do block).
        let mut prepared = match self.prepare_trait_invocation(&call)? {
            TraitInvocationPreparation::Complete(typed) => return Ok(typed),
            TraitInvocationPreparation::Arguments(prepared) => prepared,
        };
        let typed_args = self.check_prepared_trait_arguments(&call, &mut prepared)?;
        self.finish_trait_invocation(&call, prepared, typed_args)
    }

    #[inline(never)]
    fn prepare_trait_invocation(
        &mut self,
        call: &TraitInvocationContext<'_>,
    ) -> Result<TraitInvocationPreparation, TypeError> {
        let TraitInvocationContext {
            span,
            trait_name,
            method_name,
            args,
            expected_ret_ty,
            expected_ret_relation,
            argument_expected_relation,
            constructor_failure_reason,
            explicit_type_args,
            operator,
            receiver_hint,
            defer_incompatible_result_context,
            ..
        } = call.clone();
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError::from_structured(
                self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    &format!("{trait_name}::{method_name}"),
                    None,
                    0,
                    args.len(),
                    span,
                    DiagnosticOrigin::TraitCall,
                ),
            ));
        }

        let trait_info = self
            .traits
            .get(trait_name)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait: {}", trait_name),
                span: span.clone(),
                hint: None,
            })?;
        let method = trait_info
            .methods
            .get(method_name)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait method: {}::{}", trait_name, method_name),
                span: span.clone(),
                hint: None,
            })?;

        let positional_args = args
            .iter()
            .filter_map(|arg| match arg {
                ResolvedRecordLitArg::Positional(expr) => Some(expr),
                ResolvedRecordLitArg::Named(_, _) => None,
            })
            .collect::<Vec<_>>();
        // Generic zero-argument constructor helpers (for example
        // `Monoid::mempty()`) use the same expected-result dispatch.  Keep
        // this signature-driven rather than growing another trait-name list.
        if positional_args.is_empty() && method.value_parameters.is_empty() {
            let probe_self = self.env.fresh_tyvar();
            let (_, probe_ret, _, probe_slots, _) =
                self.resolve_trait_method_signature(&trait_info, &method, &probe_self)?;
            if let Some(arguments) = explicit_type_args {
                if arguments.len() != probe_slots.len() {
                    return Err(super::signatures::return_type_argument_arity_error(
                        &format!("{trait_name}::{method_name}"),
                        probe_slots.len(),
                        arguments.len(),
                        span,
                    ));
                }
            }
            if self.resolve_ty(&probe_ret) == self.resolve_ty(&probe_self)
                || matches!(probe_ret, Ty::SelfApp(_))
                || (self.trait_matches_short_name(trait_name, "Default")
                    && method_name == "default"
                    && (explicit_type_args.is_some() || expected_ret_ty.is_some()))
            {
                let explicit_target = match explicit_type_args.and_then(|arguments| {
                    probe_slots
                        .iter()
                        .position(|slot| slot == &probe_self)
                        .map(|position| &arguments[position])
                }) {
                    Some(argument) if !trait_info.constructor_slots.is_empty() => {
                        Some(self.resolve_type_constructor_return_type_argument(argument)?)
                    }
                    Some(argument) => Some(
                        self.resolve_trait_call_site_return_type_argument(&probe_self, argument)?,
                    ),
                    None => None,
                };
                let expected = explicit_target
                    .as_ref()
                    .or(expected_ret_ty)
                    .ok_or_else(|| {
                        self.ambiguous_constructor_result(trait_name, method_name, span)
                    })?
                    .clone();
                if let Some(expected_ret_ty) = expected_ret_ty {
                    self.assert_type_relation(
                        expected_ret_ty,
                        &expected,
                        self.type_fact(SourceRole::Expected, span, expected_ret_ty),
                        self.type_fact(SourceRole::ReturnTypeArgument, span, &expected),
                        TypeDiagnosticReason::ReturnTypeMismatch,
                        DiagnosticOrigin::Return,
                        &format!("{trait_name}::{method_name}"),
                        0,
                    )?;
                }
                let expected = self.resolve_ty(&expected);
                let mut unresolved = Vec::new();
                Self::collect_ty_vars(&expected, &mut unresolved);
                if explicit_target.is_some()
                    && expected_ret_ty.is_none()
                    && unresolved
                        .iter()
                        .any(|variable| !self.rigid_tyvars.contains(variable))
                {
                    return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
                }
                if !self.trait_matches_short_name(trait_name, "Default") {
                    if let Some(arguments) = explicit_type_args {
                        if let ConstructorProjectionOutcome::Applicable {
                            info: implementation,
                            mapping,
                        } = self.constructor_projection(trait_name, &expected)
                        {
                            let expanded = self.expand_trait_self_apps(
                                probe_ret.clone(),
                                &implementation.target_ty,
                                &implementation.constructor_slot_vars,
                            )?;
                            let return_type = self.substitute_ty_with_mapping(&expanded, &mapping);
                            self.assert_type_relation(
                                &expected,
                                &return_type,
                                self.type_fact(SourceRole::Expected, span, &expected),
                                self.type_fact(SourceRole::Value, span, &return_type),
                                TypeDiagnosticReason::ReturnTypeMismatch,
                                DiagnosticOrigin::Return,
                                &format!("{trait_name}::{method_name}"),
                                0,
                            )?;
                        }
                        for (ordinal, (slot, argument)) in
                            probe_slots.iter().zip(arguments).enumerate()
                        {
                            let explicit = if slot == &probe_self
                                && !trait_info.constructor_slots.is_empty()
                            {
                                self.resolve_type_constructor_return_type_argument(argument)?
                            } else {
                                self.resolve_trait_call_site_return_type_argument(slot, argument)?
                            };
                            let target = if slot == &probe_self { &expected } else { slot };
                            if self
                                .assert_type_relation(
                                    target,
                                    &explicit,
                                    self.type_fact(SourceRole::Expected, span, target),
                                    self.type_fact(
                                        SourceRole::ReturnTypeArgument,
                                        Self::ast_ty_span(argument),
                                        &explicit,
                                    ),
                                    TypeDiagnosticReason::ArgumentTypeMismatch,
                                    DiagnosticOrigin::TraitCall,
                                    &format!("{trait_name}::{method_name}"),
                                    ordinal as u32,
                                )
                                .is_err()
                            {
                                return Err(
                                    super::signatures::return_type_argument_mismatch_error(
                                        &format!("{trait_name}::{method_name}"),
                                        ordinal as u32,
                                        &self.diagnostic_ty_name(target),
                                        &Self::surface_ast_ty(argument),
                                        Self::ast_ty_span(argument),
                                        SourceRole::Expected,
                                        span,
                                    ),
                                );
                            }
                        }
                    }
                }
                let dispatch = self
                    .constructor_target_dispatch(trait_name, method_name, &expected)?
                    .ok_or_else(|| {
                        if self.constructor_capability_failure_reason(&expected)
                            == TypeDiagnosticReason::MissingGenericBound
                        {
                            self.trait_obligation_failure(
                                TypeDiagnosticReason::MissingGenericBound,
                                trait_name,
                                &[],
                                Some(method_name),
                                &expected,
                                span,
                                DiagnosticOrigin::TraitCall,
                            )
                        } else {
                            self.trait_dispatch_failure(
                                TypeDiagnosticReason::NoApplicableTraitImplementation,
                                trait_name,
                                method_name,
                                Some(&expected),
                                span,
                            )
                        }
                    })?;
                let typed = TypedNode {
                    ty: expected.clone(),
                    span: span.clone(),
                    node: TypedInner::TraitCall {
                        trait_name: trait_name.to_string(),
                        method_name: method_name.to_string(),
                        receiver_ty: expected.clone(),
                        obligation: TraitObligation {
                            trait_id: trait_name.to_string(),
                            trait_args: Vec::new(),
                            receiver: expected.clone(),
                        },
                        dispatch,
                        origin: TraitCallOrigin::Explicit,
                        args: Vec::new(),
                    },
                };
                return Ok(TraitInvocationPreparation::Complete(typed));
            }
        }
        let self_ty = if method.attrs.visibility == spire::ast::Visibility::Private {
            self.local_annotation_tyvars
                .get("Self")
                .cloned()
                .ok_or_else(|| {
                    TypeError::new(
                        "Internal error: private trait helper has no lexical Self owner",
                        span.clone(),
                    )
                })?
        } else {
            self.env.fresh_tyvar()
        };
        let (mut param_tys, mut ret_ty, trait_arg_tys, explicit_slots, _) =
            self.resolve_trait_method_signature(&trait_info, &method, &self_ty)?;
        if let Some(explicit_args) = explicit_type_args {
            if explicit_args.len() != explicit_slots.len() {
                return Err(super::signatures::return_type_argument_arity_error(
                    &format!("{trait_name}::{method_name}"),
                    explicit_slots.len(),
                    explicit_args.len(),
                    span,
                ));
            }
        }
        if let Some(explicit_args) = explicit_type_args {
            for (ordinal, (slot, arg)) in explicit_slots.iter().zip(explicit_args).enumerate() {
                let explicit_ty = if slot == &self_ty && !trait_info.constructor_slots.is_empty() {
                    self.resolve_type_constructor_return_type_argument(arg)?
                } else {
                    self.resolve_trait_call_site_return_type_argument(slot, arg)?
                };
                if self
                    .assert_type_relation(
                        slot,
                        &explicit_ty,
                        self.type_fact(SourceRole::Contract, span, slot),
                        self.type_fact(
                            SourceRole::ReturnTypeArgument,
                            Self::ast_ty_span(arg),
                            &explicit_ty,
                        ),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::TraitCall,
                        &format!("{trait_name}::{method_name}"),
                        ordinal as u32,
                    )
                    .is_err()
                {
                    return Err(super::signatures::return_type_argument_mismatch_error(
                        &format!("{trait_name}::{method_name}"),
                        ordinal as u32,
                        &self.diagnostic_ty_name(slot),
                        &self.diagnostic_ty_name(&explicit_ty),
                        Self::ast_ty_span(arg),
                        SourceRole::Contract,
                        span,
                    ));
                }
            }
        }

        // Return-only inputs cannot be inferred from value arguments. Report
        // that missing context before dispatch so branch checking can supply its
        // expected result through the ordinary ReturnTypeArgument protocol.
        if explicit_type_args.is_none()
            && expected_ret_ty.is_none()
            && explicit_slots.iter().any(|slot| {
                let mut variables = Vec::new();
                Self::collect_ty_vars(&self.resolve_ty(slot), &mut variables);
                variables
                    .iter()
                    .any(|variable| !self.rigid_tyvars.contains(variable))
            })
        {
            return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
        }

        let declared_param_tys = param_tys.clone();
        let mut constructor_receiver_index = None;
        let mut prepared_args = vec![None; args.len()];
        let declared_receiver_index = param_tys.iter().enumerate().rev().find_map(|(index, ty)| {
            matches!(ty, Ty::SelfApp(items) if Self::constructor_application_parts(items).is_none())
                .then_some(index)
        });
        fn contains_trait_constructor_input(ty: &Ty, trait_args: &[Ty]) -> bool {
            match ty {
                Ty::SelfApp(items) => {
                    Checker::constructor_application_parts(items).is_some_and(|(witness, _)| {
                        trait_args.iter().any(|argument| argument == witness)
                    }) || items
                        .iter()
                        .any(|item| contains_trait_constructor_input(item, trait_args))
                }
                Ty::List(inner)
                | Ty::MatchResult(inner)
                | Ty::ExtractorClosure(inner)
                | Ty::Lazy(inner)
                | Ty::Pid(inner) => contains_trait_constructor_input(inner, trait_args),
                Ty::Result(ok, error) => {
                    contains_trait_constructor_input(ok, trait_args)
                        || contains_trait_constructor_input(error, trait_args)
                }
                Ty::Tuple(items) | Ty::Enum(_, items) => items
                    .iter()
                    .any(|item| contains_trait_constructor_input(item, trait_args)),
                Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                    nominal
                        .arguments
                        .iter()
                        .any(|item| contains_trait_constructor_input(item, trait_args))
                        || nominal
                            .iter()
                            .any(|(_, field)| contains_trait_constructor_input(field, trait_args))
                }
                Ty::Func(inputs, output)
                | Ty::BuiltinFunc {
                    params: inputs,
                    ret: output,
                    ..
                }
                | Ty::UserFunc {
                    params: inputs,
                    ret: output,
                    ..
                } => {
                    inputs
                        .iter()
                        .any(|item| contains_trait_constructor_input(item, trait_args))
                        || contains_trait_constructor_input(output, trait_args)
                }
                Ty::Facet(_, source, focus, update_source, update_focus) => [
                    source.as_ref(),
                    focus.as_ref(),
                    update_source.as_ref(),
                    update_focus.as_ref(),
                ]
                .into_iter()
                .any(|item| contains_trait_constructor_input(item, trait_args)),
                Ty::Var(_)
                | Ty::Hole
                | Ty::Int
                | Ty::Float
                | Ty::Str
                | Ty::Bool
                | Ty::Unit
                | Ty::Error
                | Ty::ProcessMarker(_) => false,
            }
        }
        // When a receiverless constructor method's value parameter carries a
        // trait-head constructor (for example MonadT<$M>::lift($M<$A>)), let
        // concrete value arguments constrain the trait head before projecting
        // the result carrier. Projecting from the result alone can otherwise
        // choose an implementation and feed its input type back into an
        // underconstrained argument.
        let direct_self_result = match &ret_ty {
            Ty::Var(variable) => matches!(
                self.resolve_ty(&self_ty),
                Ty::Var(self_variable) if self_variable == *variable
            ),
            Ty::SelfApp(items) => Self::constructor_application_parts(items).is_none(),
            _ => false,
        };
        let receiverless_head_input = explicit_type_args.is_none()
            && declared_receiver_index.is_none()
            && !trait_info.constructor_slots.is_empty()
            && direct_self_result
            && declared_param_tys
                .iter()
                .any(|parameter| contains_trait_constructor_input(parameter, &trait_arg_tys));
        if receiverless_head_input && args.len() == declared_param_tys.len() {
            if expected_ret_ty.is_none() {
                return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
            }
            for (param, argument) in trait_info.type_params.iter().zip(&trait_arg_tys) {
                let constructor_trait =
                    self.trait_head_parameter_constructor_bound(&trait_info, &param.name);
                if let (Some(constructor_trait), Ty::Var(variable)) =
                    (constructor_trait, self.resolve_ty(argument))
                {
                    if !self.rigid_tyvars.contains(&variable) {
                        self.constructor_witness_traits
                            .entry(variable)
                            .or_insert(constructor_trait);
                    }
                }
            }
            if let Some(expected) = expected_ret_ty {
                let normalized = self.resolve_ty(expected);
                let mut variables = Vec::new();
                Self::collect_ty_vars(&normalized, &mut variables);
                let stable_context = variables
                    .iter()
                    .all(|variable| self.rigid_tyvars.contains(variable));
                let contextual_args = if stable_context {
                    self.contextual_receiverless_target_arguments(
                        trait_name,
                        method_name,
                        span,
                        args,
                        &declared_param_tys,
                        &trait_arg_tys,
                        &self_ty,
                        &normalized,
                        operator.clone(),
                    )?
                } else {
                    None
                };
                if let Some(contextual_args) = contextual_args {
                    prepared_args = contextual_args.into_iter().map(Some).collect();
                } else {
                    for (index, (argument, parameter)) in
                        args.iter().zip(&declared_param_tys).enumerate()
                    {
                        if !contains_trait_constructor_input(parameter, &trait_arg_tys) {
                            continue;
                        }
                        let ResolvedRecordLitArg::Positional(argument) = argument else {
                            continue;
                        };
                        let typed = self.check_node(argument)?;
                        self.assert_type_relation(
                            parameter,
                            &typed.ty,
                            self.type_fact(SourceRole::Contract, span, parameter),
                            self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                            TypeDiagnosticReason::ArgumentTypeMismatch,
                            DiagnosticOrigin::TraitCall,
                            &format!("{trait_name}::{method_name}"),
                            index as u32,
                        )?;
                        prepared_args[index] = Some(typed);
                    }
                    self.assert_type_relation(
                        &self_ty,
                        &normalized,
                        self.type_fact(SourceRole::Expected, span, &normalized),
                        self.type_fact(SourceRole::Contract, span, &self_ty),
                        TypeDiagnosticReason::ReturnTypeMismatch,
                        DiagnosticOrigin::TraitCall,
                        &format!("{trait_name}::{method_name}"),
                        0,
                    )?;
                }
                ret_ty = self.resolve_ty(expected);
            }
        }
        if !trait_info.constructor_slots.is_empty()
            && args.len() == param_tys.len()
            && !receiverless_head_input
        {
            let receiver_index = declared_receiver_index;
            let typed_receiver = if let Some(index) = receiver_index {
                constructor_receiver_index = Some(index);
                if receiver_hint.is_none() {
                    if let Some(typed) = self.try_constructor_invocation_from_arguments(
                        span,
                        trait_name,
                        method_name,
                        args,
                        &declared_param_tys,
                        expected_ret_ty,
                        expected_ret_relation,
                        argument_expected_relation,
                        constructor_failure_reason,
                        explicit_type_args,
                        operator.clone(),
                        index,
                    )? {
                        return Ok(TraitInvocationPreparation::Complete(typed));
                    }
                }
                Some(self.check_node_with_expected(positional_args[index], receiver_hint)?)
            } else {
                None
            };
            let receiver_ty = if let Some(typed) = &typed_receiver {
                self.resolve_ty(&typed.ty)
            } else if receiverless_head_input {
                let contextual = expected_ret_ty
                    .map(|ty| self.resolve_ty(ty))
                    .unwrap_or_else(|| self.resolve_ty(&self_ty));
                if matches!(contextual, Ty::Var(_) | Ty::Hole) {
                    return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
                }
                contextual
            } else if matches!(ret_ty, Ty::SelfApp(_)) {
                let contextual = expected_ret_ty
                    .map(|ty| self.resolve_ty(ty))
                    .unwrap_or_else(|| self.resolve_ty(&self_ty));
                if matches!(contextual, Ty::Var(_) | Ty::Hole) {
                    return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
                }
                contextual
            } else {
                self.resolve_ty(&self_ty)
            };
            if !matches!(receiver_ty, Ty::Var(_) | Ty::Hole) {
                let receiver_span = typed_receiver
                    .as_ref()
                    .map(|typed| &typed.span)
                    .unwrap_or(span);
                let (target, slots, captured, implementation_trait_args) =
                    if let Ty::SelfApp(items) = &receiver_ty {
                        let (witness, payloads) = Self::constructor_application_parts(items)
                            .ok_or_else(|| {
                                TypeError::new(
                                    "Constructor application has no witness",
                                    receiver_span.clone(),
                                )
                            })?;
                        let mut target = vec![Ty::Hole, witness.clone()];
                        let mut slots = Vec::new();
                        for _ in payloads {
                            let slot = self.env.fresh_tyvar();
                            let Ty::Var(var) = slot else { unreachable!() };
                            slots.push(var);
                            target.push(slot);
                        }
                        (Ty::SelfApp(target), slots, HashMap::new(), None)
                    } else {
                        let (implementation, mut captured) = match self
                            .constructor_capability_projection(trait_name, &receiver_ty)
                        {
                            ConstructorProjectionOutcome::Applicable { info, mapping } => {
                                (info, mapping)
                            }
                            ConstructorProjectionOutcome::Deferred { .. } => {
                                return Err(self.trait_dispatch_failure(
                                    TypeDiagnosticReason::UnresolvedTraitMethodInstantiation,
                                    trait_name,
                                    method_name,
                                    Some(&receiver_ty),
                                    receiver_span,
                                ));
                            }
                            ConstructorProjectionOutcome::Rejected { failures } => {
                                if Self::constructor_projection_failures_are_metadata(&failures) {
                                    return Err(signatures::constructor_signature_metadata_error(
                                        method_name,
                                        receiver_span,
                                        Self::constructor_projection_failure_detail(&failures),
                                    ));
                                }
                                if let Some(reason) = constructor_failure_reason {
                                    return Err(self.trait_obligation_failure(
                                        reason,
                                        trait_name,
                                        &[],
                                        None,
                                        &receiver_ty,
                                        receiver_span,
                                        DiagnosticOrigin::TraitCall,
                                    ));
                                }
                                return Err(self.trait_dispatch_failure(
                                    TypeDiagnosticReason::NoApplicableTraitImplementation,
                                    trait_name,
                                    method_name,
                                    Some(&receiver_ty),
                                    receiver_span,
                                ));
                            }
                        };
                        let implementation_trait_args = implementation
                            .trait_arg_tys
                            .iter()
                            .map(|argument| {
                                self.resolve_ty(
                                    &self.substitute_ty_with_mapping(argument, &captured),
                                )
                            })
                            .collect::<Vec<_>>();
                        for slot in &implementation.constructor_slot_vars {
                            captured.remove(slot);
                        }
                        (
                            implementation.target_ty.clone(),
                            implementation.constructor_slot_vars.clone(),
                            captured,
                            Some(implementation_trait_args),
                        )
                    };
                if let Some(implementation_trait_args) = implementation_trait_args {
                    if implementation_trait_args.len() != trait_arg_tys.len() {
                        return Err(TypeError::new(
                            "Trait implementation argument metadata mismatch",
                            receiver_span.clone(),
                        ));
                    }
                    for (ordinal, (declared, inferred)) in trait_arg_tys
                        .iter()
                        .zip(&implementation_trait_args)
                        .enumerate()
                    {
                        let constructor_trait = self
                            .traits
                            .get(trait_name)
                            .and_then(|info| {
                                info.type_params.get(ordinal).map(|param| (info, param))
                            })
                            .and_then(|(info, param)| {
                                self.trait_head_parameter_constructor_bound(info, &param.name)
                            });
                        if let (Some(constructor_trait), Ty::Var(variable)) =
                            (constructor_trait, self.resolve_ty(declared))
                        {
                            if !self.rigid_tyvars.contains(&variable) {
                                self.constructor_witness_traits
                                    .entry(variable)
                                    .or_insert(constructor_trait);
                            }
                        }
                        let declared =
                            self.normalize_executable_trait_argument(trait_name, ordinal, declared);
                        let inferred =
                            self.normalize_executable_trait_argument(trait_name, ordinal, inferred);
                        self.assert_type_relation(
                            &declared,
                            &inferred,
                            self.type_fact(SourceRole::Contract, span, &declared),
                            self.type_fact(SourceRole::Value, receiver_span, &inferred),
                            TypeDiagnosticReason::ArgumentTypeMismatch,
                            DiagnosticOrigin::TraitCall,
                            &format!("{trait_name}::{method_name}"),
                            0,
                        )?;
                    }
                }
                if let Some(typed) = &typed_receiver {
                    self.check_constructor_capability(
                        trait_name,
                        method_name,
                        typed,
                        constructor_failure_reason,
                    )?;
                }
                let expand = |ty| {
                    self.expand_trait_self_apps(ty, &target, &slots)
                        .map(|ty| self.substitute_ty_with_mapping(&ty, &captured))
                };
                param_tys = param_tys
                    .into_iter()
                    .map(&expand)
                    .collect::<Result<_, _>>()?;
                ret_ty = expand(ret_ty)?;
                self.assert_type_relation(
                    &self_ty,
                    &receiver_ty,
                    self.type_fact(SourceRole::Expected, span, &self_ty),
                    self.type_fact(SourceRole::Value, receiver_span, &receiver_ty),
                    TypeDiagnosticReason::ArgumentTypeMismatch,
                    DiagnosticOrigin::TraitCall,
                    &format!("{trait_name}::{method_name}"),
                    receiver_index.unwrap_or(0) as u32,
                )?;
                if let (Some(index), Some(typed)) = (receiver_index, typed_receiver) {
                    self.assert_type_relation(
                        &param_tys[index],
                        &typed.ty,
                        self.type_fact(SourceRole::Expected, span, &param_tys[index]),
                        self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::TraitCall,
                        &format!("{trait_name}::{method_name}"),
                        index as u32,
                    )?;
                    prepared_args[index] = Some(typed);
                } else {
                    self.assert_type_relation(
                        &self_ty,
                        &ret_ty,
                        self.type_fact(SourceRole::Expected, span, &self_ty),
                        self.type_fact(SourceRole::Value, span, &ret_ty),
                        TypeDiagnosticReason::ReturnTypeMismatch,
                        DiagnosticOrigin::TraitCall,
                        &format!("{trait_name}::{method_name}"),
                        0,
                    )?;
                }
            }
        }
        if !defer_incompatible_result_context {
            if let Some(expected) = expected_ret_ty {
                self.assert_trait_return_context(
                    expected,
                    &ret_ty,
                    span,
                    trait_name,
                    expected_ret_relation,
                )?;
            }
        }

        let trait_display_name = self.trait_display_name(trait_name);
        let trait_signature_hint = |checker: &Self| {
            let params = param_tys
                .iter()
                .map(|ty| checker.resolve_ty(ty))
                .collect::<Vec<_>>();
            let ret = checker.resolve_ty(&ret_ty);
            checker.trait_method_signature_hint(&trait_display_name, method_name, &params, &ret)
        };

        if args.len() != param_tys.len() {
            return Err(
                TypeError::from_structured(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    &format!("{trait_name}::{method_name}"),
                    None,
                    param_tys.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::TraitCall,
                ))
                .with_hint(trait_signature_hint(self)),
            );
        }

        Ok(TraitInvocationPreparation::Arguments(
            PreparedTraitInvocation {
                param_tys,
                ret_ty,
                trait_arg_tys,
                self_ty,
                declared_param_tys,
                constructor_receiver_index,
                prepared_args,
            },
        ))
    }

    fn check_prepared_trait_arguments(
        &mut self,
        call: &TraitInvocationContext<'_>,
        prepared: &mut PreparedTraitInvocation,
    ) -> Result<Vec<TypedNode>, TypeError> {
        let mut remaining = prepared
            .prepared_args
            .iter()
            .filter(|arg| arg.is_none())
            .count();
        while remaining > 0 {
            let before = remaining;
            for (index, (argument, expected)) in
                call.args.iter().zip(&prepared.param_tys).enumerate()
            {
                if prepared.prepared_args[index].is_some() {
                    continue;
                }
                let ResolvedRecordLitArg::Positional(expr) = argument else {
                    unreachable!("named arguments rejected");
                };
                let inputs = if Self::has_contextual_callback_parameters(expr) {
                    self.callback_input_provenance(
                        &prepared.param_tys,
                        &prepared.prepared_args,
                        index,
                        self.resolved_span(expr),
                    )?
                } else {
                    Some(Vec::new())
                };
                let Some(inputs) = inputs else {
                    continue;
                };
                let typed = self
                    .with_callback_parameter_provenance(expr, &inputs, |checker| {
                        if checker.trait_parameter_is_lazy(call.trait_name, call.method_name, index)
                        {
                            return checker.check_trait_lazy_argument(expr, expected, call.span);
                        }
                        checker.check_invocation_argument(
                            expr,
                            expected,
                            call.operator.clone(),
                            index,
                            call.argument_expected_relation.filter(|_| index == 1),
                        )
                    })
                    .map_err(|mut error| {
                        if let Some(diagnostic) = &mut error.structured {
                            if diagnostic.origin == DiagnosticOrigin::Call
                                && diagnostic.primary.span == *self.resolved_span(expr)
                            {
                                diagnostic.origin = DiagnosticOrigin::TraitCall;
                            }
                        }
                        error
                    })?;
                prepared.prepared_args[index] = Some(typed);
                remaining -= 1;
            }
            if remaining == before {
                return Err(self.unresolved_callback_provenance_error(call.span));
            }
        }
        let typed_args = prepared
            .prepared_args
            .iter_mut()
            .map(|arg| arg.take().expect("all trait arguments were checked"))
            .collect::<Vec<_>>();
        self.check_callback_argument_provenance(&prepared.param_tys, &typed_args)?;
        Ok(typed_args)
    }

    fn has_contextual_callback_parameters(expression: &Resolved) -> bool {
        match expression {
            Resolved::Grouped(_, inner) => Self::has_contextual_callback_parameters(inner),
            Resolved::Closure(_, parameters, _, _)
            | Resolved::CaptureClosure(_, parameters, _, _)
            | Resolved::ExtractorClosure(_, parameters, _, _) => parameters
                .iter()
                .any(|parameter| parameter.ty.is_none() || parameter.id.compiler_generated),
            _ => false,
        }
    }

    /// Install input views by resolved parameter identity, before checking a
    /// contextual closure body. Declared nominal parameters retain their own
    /// contract; inferred and compiler-generated parameters inherit the source.
    fn with_callback_parameter_provenance<T>(
        &mut self,
        expression: &Resolved,
        inputs: &[(ConstructorCapabilityProvenance, Ty)],
        check: impl FnOnce(&mut Self) -> Result<T, TypeError>,
    ) -> Result<T, TypeError> {
        let mut expression = expression;
        while let Resolved::Grouped(_, inner) = expression {
            expression = inner;
        }
        let parameters = match expression {
            Resolved::Closure(_, parameters, _, _)
            | Resolved::CaptureClosure(_, parameters, _, _)
            | Resolved::ExtractorClosure(_, parameters, _, _) => parameters.as_slice(),
            _ => &[],
        };
        let saved = parameters
            .iter()
            .zip(inputs)
            .filter_map(|(parameter, source)| {
                (parameter.ty.is_none() || parameter.id.compiler_generated).then(|| {
                    let id = parameter.id.unique_id;
                    (
                        id,
                        self.constructor_capabilities.insert(id, source.0.clone()),
                    )
                })
            })
            .collect::<Vec<_>>();
        let result = check(self);
        for (id, previous) in saved {
            if let Some(previous) = previous {
                self.constructor_capabilities.insert(id, previous);
            } else {
                self.constructor_capabilities.remove(&id);
            }
        }
        result
    }

    #[inline(never)]
    fn finish_trait_invocation(
        &mut self,
        call: &TraitInvocationContext<'_>,
        prepared: PreparedTraitInvocation,
        typed_args: Vec<TypedNode>,
    ) -> Result<TypedNode, TypeError> {
        let TraitInvocationContext {
            span,
            trait_name,
            method_name,
            receiver_owner_hint,
            expected_ret_ty,
            expected_ret_relation,
            constructor_failure_reason,
            defer_incompatible_result_context,
            ..
        } = call.clone();
        let PreparedTraitInvocation {
            param_tys,
            ret_ty,
            trait_arg_tys,
            self_ty,
            declared_param_tys,
            constructor_receiver_index,
            ..
        } = prepared;
        self.ensure_no_runtime_facet_args(&typed_args, span, "Trait method call")?;

        self.check_trait_method_constructor_capabilities(
            trait_name,
            method_name,
            &declared_param_tys,
            constructor_receiver_index,
            &typed_args,
            constructor_failure_reason,
        )?;

        if let Some(owner_hint) = receiver_owner_hint {
            if let Some(receiver) = typed_args.first() {
                let receiver_ty = self.resolve_ty(&receiver.ty);
                if let Some(receiver_name) = self.trait_target_name(&receiver_ty) {
                    if Self::surface_name(&receiver_name) != owner_hint {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "{}::{} helper requires receiver type {}, got {}",
                                owner_hint,
                                method_name,
                                owner_hint,
                                self.ty_name(&receiver_ty)
                            ),
                            span: receiver.span.clone(),
                            hint: Some(format!(
                                "Use {}::{} only for {} values.",
                                owner_hint, method_name, owner_hint
                            )),
                        });
                    }
                }
            }
        }

        for (idx, (expected, arg)) in param_tys.iter().zip(&typed_args).enumerate() {
            let contextual_policy = if constructor_receiver_index.is_some()
                && matches!(declared_param_tys[idx], Ty::Func(..))
            {
                Some((
                    trait_name,
                    matches!(&declared_param_tys[idx], Ty::Func(_, output) if matches!(output.as_ref(), Ty::SelfApp(_))),
                ))
            } else {
                None
            };
            if let Some((capability, contextual_return)) = contextual_policy {
                let source_index = constructor_receiver_index.unwrap_or(0);
                self.assert_contextual_callable_argument(
                    expected,
                    arg,
                    &typed_args[source_index],
                    capability,
                    contextual_return,
                    &format!("{trait_name}::{method_name}"),
                    idx as u32,
                )?;
            } else {
                let expected_fact = if idx > 0 {
                    self.type_fact(
                        SourceRole::LeftValue,
                        &typed_args[0].span,
                        &typed_args[0].ty,
                    )
                } else {
                    self.type_fact(SourceRole::Expected, span, expected)
                };
                self.assert_type_relation(
                    expected,
                    &arg.ty,
                    expected_fact,
                    self.type_fact(
                        if idx > 0 {
                            SourceRole::RightValue
                        } else {
                            SourceRole::Value
                        },
                        &arg.span,
                        &arg.ty,
                    ),
                    TypeDiagnosticReason::ArgumentTypeMismatch,
                    DiagnosticOrigin::TraitCall,
                    &format!("{trait_name}::{method_name}"),
                    idx as u32,
                )?;
            }
        }

        if defer_incompatible_result_context {
            if let Some(expected) = expected_ret_ty {
                // A Result context may finish payload inference after the operands
                // establish Self. Probe without committing failed substitutions.
                // An incompatible context is necessarily rejected by the outside
                // annotation, return, or argument relation; it is not accepted here.
                let compatible = self
                    .with_type_relation_probe(&[expected, &ret_ty], |checker| {
                        checker.types_compatible(expected, &ret_ty)
                    })?;
                if compatible {
                    self.assert_trait_return_context(
                        expected,
                        &ret_ty,
                        span,
                        trait_name,
                        expected_ret_relation,
                    )?;
                }
            }
        }

        let trait_call_name = self.trait_instance_key_from_tys(trait_name, &trait_arg_tys);
        let receiver_ty = self.resolve_ty(&self_ty);
        if let Ty::Var(var) = receiver_ty {
            if self.rigid_tyvars.contains(&var)
                && !self.tyvar_has_bound(var, trait_name)
                && !self.tyvar_satisfies_compiler_trait(var, trait_name)
            {
                return Err(self.trait_obligation_failure(
                    TypeDiagnosticReason::MissingGenericBound,
                    trait_name,
                    &trait_arg_tys,
                    Some(method_name),
                    &receiver_ty,
                    &typed_args
                        .first()
                        .map(|arg| arg.span.clone())
                        .unwrap_or_else(|| span.clone()),
                    DiagnosticOrigin::TraitCall,
                ));
            }
            if !self.rigid_tyvars.contains(&var) {
                let obligations = self.pending_trait_obligations.entry(var).or_default();
                let obligation = PendingTraitObligation {
                    trait_id: trait_name.to_string(),
                    args: trait_arg_tys.clone(),
                    receiver: Ty::Var(var),
                };
                if !obligations.contains(&obligation) {
                    obligations.push(obligation);
                }
            }
        }
        let receiver_span = typed_args
            .first()
            .map(|arg| arg.span.clone())
            .unwrap_or_else(|| span.clone());

        if let Some(err) = self.opposite_conversion_hint(
            trait_name,
            method_name,
            &receiver_ty,
            &trait_arg_tys,
            &receiver_span,
        ) {
            if self
                .trait_dispatch_target_for_args(
                    trait_name,
                    method_name,
                    &receiver_ty,
                    &trait_arg_tys,
                )?
                .is_none()
            {
                return Err(self
                    .trait_obligation_failure(
                        TypeDiagnosticReason::NoApplicableTraitImplementation,
                        trait_name,
                        &trait_arg_tys,
                        Some(method_name),
                        &receiver_ty,
                        &receiver_span,
                        DiagnosticOrigin::TraitCall,
                    )
                    .with_hint(err.message));
            }
        }

        let receiver_ty = self.resolve_ty(&self_ty);
        self.consume_matching_capability(&receiver_ty, trait_name);
        let argument_tys = typed_args
            .iter()
            .map(|arg| self.resolve_ty(&arg.ty))
            .collect::<Vec<_>>();
        let mut rejection_note = None;
        let mut rejection_facts = Vec::new();
        let abstract_constructor = match &receiver_ty {
            Ty::SelfApp(items) => Self::constructor_application_parts(items)
                .map(|(witness, _)| self.constructor_witness_supports_trait(witness, trait_name))
                .unwrap_or(false),
            _ => false,
        };
        let dispatch = if abstract_constructor {
            Some(TraitDispatch::Pending)
        } else {
            match self.select_trait_method_instantiation(
                trait_name,
                method_name,
                &receiver_ty,
                &trait_arg_tys,
                &argument_tys,
                &ret_ty,
            )? {
                CandidateApplicability::Applicable(instantiation) => {
                    Some(TraitDispatch::Selected(Box::new(instantiation)))
                }
                CandidateApplicability::Deferred(_) => self.trait_dispatch_target_for_args(
                    trait_name,
                    method_name,
                    &receiver_ty,
                    &trait_arg_tys,
                )?,
                CandidateApplicability::Rejected(rejection) => {
                    rejection_note = self.candidate_rejection_note(&rejection);
                    rejection_facts = self.candidate_rejection_facts(&rejection);
                    self.consume_matching_capability(&receiver_ty, trait_name)
                        .then_some(TraitDispatch::Pending)
                }
            }
        }
        .ok_or_else(|| {
            let mut error = self.trait_obligation_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                trait_name,
                &trait_arg_tys,
                Some(method_name),
                &receiver_ty,
                &receiver_span,
                DiagnosticOrigin::TraitCall,
            );
            if let Some(diagnostic) = &mut error.structured {
                diagnostic.related.extend(rejection_facts);
            }
            let forbidden_dependency = error.structured.as_ref().is_some_and(|diagnostic| {
                matches!(
                    &diagnostic.data,
                    diagnostics::DiagnosticData::TraitDispatch(dispatch)
                        if dispatch.dependency.as_ref().is_some_and(|dependency| {
                            dependency.leaf_policy
                                == diagnostics::TraitDependencyLeafPolicy::TraitImplementationForbidden
                        })
                )
            });
            if let Some(note) = rejection_note.filter(|_| !forbidden_dependency) {
                error = error.with_hint(note);
            }
            error
        })?;

        Ok(TypedNode {
            ty: self.resolve_ty(&ret_ty),
            span: span.clone(),
            node: TypedInner::TraitCall {
                trait_name: trait_call_name,
                method_name: method_name.into(),
                receiver_ty: receiver_ty.clone(),
                obligation: TraitObligation {
                    trait_id: trait_name.to_string(),
                    trait_args: trait_arg_tys.iter().map(|ty| self.resolve_ty(ty)).collect(),
                    receiver: receiver_ty,
                },
                dispatch,
                origin: TraitCallOrigin::Explicit,
                args: typed_args,
            },
        })
    }

    pub(super) fn check_injected_call(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    op_name,
                    None,
                    args.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{} does not support named arguments on the right-hand side",
                    op_name
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let explicit = Self::explicit_type_args(func);
        let named_target = match func {
            Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
            other => other,
        };
        let has_named_signature = match named_target {
            Resolved::Var(_, id) => {
                self.callable_signatures.contains_key(&id.unique_id)
                    || self.is_registered_callable_declaration(id.unique_id)
            }
            _ => false,
        };
        let typed_func = if explicit.is_some() || has_named_signature {
            let (mut typed, signature, return_type_arguments) =
                self.instantiate_named_callable_signature(span, named_target, explicit.as_deref())?;
            let constraints =
                self.call_constraint_set(signature, return_type_arguments, None, span, &typed.ty);
            self.apply_return_type_argument_constraints(&constraints)?;
            typed.ty = self.callable_ty_from_signature(&typed.ty, &constraints.signature);
            typed
        } else {
            self.check_node(func)?
        };
        let (params, ret) = match self.resolve_ty(&typed_func.ty) {
            Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                (params, ret.as_ref().clone())
            }
            Ty::Func(params, ret) => (params, ret.as_ref().clone()),
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "{} right-hand side is not a function call target: {}",
                        op_name,
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }
        };

        if params.len() != args.len() + 1 {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} injects the left value as the first argument, so the call expects {} explicit argument(s), got {}",
                    op_name,
                    params.len().saturating_sub(1),
                    args.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }

        if matches!(self.resolve_ty(&params[0]), Ty::Lazy(_)) {
            return Err(TypeError {
                structured: None,
                message: "pipe injection into a Lazy parameter is not allowed".into(),
                span: span.clone(),
                hint: Some(
                    "Lazy parameters are evaluated under the callee's control. Bind the value first, then pass that binding explicitly, or use a closure to make the evaluation order explicit."
                        .into(),
                ),
            });
        }

        let typed_args: Vec<TypedNode> = args
            .iter()
            .zip(params.iter().skip(1))
            .map(|(arg, expected)| match arg {
                ResolvedRecordLitArg::Positional(expr) => {
                    self.check_node_with_expected(expr, Some(expected))
                }
                ResolvedRecordLitArg::Named(_, _) => unreachable!("validated above"),
            })
            .collect::<Result<Vec<_>, _>>()?;
        self.ensure_no_runtime_facet_args(&typed_args, span, op_name)?;

        for (ordinal, (expected, arg)) in params.iter().skip(1).zip(&typed_args).enumerate() {
            if !matches!(self.resolve_ty(expected), Ty::Hole) {
                self.assert_type_relation(
                    expected,
                    &arg.ty,
                    self.type_fact(SourceRole::Expected, span, expected),
                    self.type_fact(SourceRole::Value, &arg.span, &arg.ty),
                    TypeDiagnosticReason::ArgumentTypeMismatch,
                    DiagnosticOrigin::Operator {
                        operator: op_name.trim_matches('`').into(),
                    },
                    op_name,
                    (ordinal + 1) as u32,
                )?;
            }
        }

        Ok(TypedNode {
            ty: Ty::Func(
                vec![self.resolve_ty(&params[0])],
                Box::new(self.resolve_ty(&ret)),
            ),
            span: span.clone(),
            node: TypedInner::InjectCall(Box::new(typed_func), typed_args),
        })
    }

    fn check_trait_helper_pipe_callable(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        input_ty: Ty,
        ret_ty: Option<Ty>,
        op_name: &str,
    ) -> Result<Option<TypedNode>, TypeError> {
        if self.trait_method_ref(func).is_none() {
            return Ok(None);
        }
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} does not support named arguments on the right-hand side",
                    op_name
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let param_id = ResolvedId {
            name: "__pipe_trait_helper_arg".into(),
            qualified_name: None,
            symbol_info: None,
            unique_id: Self::next_synthetic_range_uid(),
            compiler_generated: true,
            span: span.clone(),
        };
        let mut body_args = Vec::with_capacity(args.len() + 1);
        body_args.push(ResolvedRecordLitArg::Positional(Resolved::Var(
            span.clone(),
            param_id.clone(),
        )));
        body_args.extend(args.iter().cloned());

        let synthetic = Resolved::Closure(
            span.clone(),
            vec![ResolvedClosureParam {
                lazy_capture: None,
                id: param_id,
                ty: None,
            }],
            Vec::new(),
            Box::new(Resolved::App(
                span.clone(),
                Box::new(func.clone()),
                body_args,
            )),
        );
        let contract = self.callable_contract(&input_ty, ret_ty, ExpectedCallableSlot::Contextual);
        let expected = self.expected_callable_ty(&contract);
        self.check_node_with_expected(&synthetic, Some(&expected))
            .map(Some)
    }

    fn flow_operator_trait_call(
        &mut self,
        span: &Span,
        trait_short_name: &str,
        method_name: &str,
        receiver_ty: &Ty,
        requested_trait_args: Vec<Ty>,
        op: OperatorTraitOp,
        args: Vec<TypedNode>,
        result_ty: Ty,
        op_name: &str,
    ) -> Result<TypedNode, TypeError> {
        let trait_key = self
            .trait_key_by_short_name(trait_short_name)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait: {}", trait_short_name),
                span: span.clone(),
                hint: None,
            })?;
        let Some((dispatch, resolved_trait_args)) = self.operator_trait_dispatch_for_args(
            &trait_key,
            method_name,
            receiver_ty,
            &requested_trait_args,
            &args
                .iter()
                .map(|arg| self.resolve_ty(&arg.ty))
                .collect::<Vec<_>>(),
            &result_ty,
        )?
        else {
            return Err(self.trait_obligation_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                &trait_key,
                &requested_trait_args,
                Some(method_name),
                receiver_ty,
                span,
                DiagnosticOrigin::Operator {
                    operator: op_name.trim_matches('`').into(),
                },
            ));
        };
        let trait_name = self.trait_instance_key_from_tys(&trait_key, &resolved_trait_args);
        let lhs_ty = args
            .first()
            .map(|arg| self.resolve_ty(&arg.ty))
            .unwrap_or_else(|| self.resolve_ty(receiver_ty));
        let rhs_ty = args
            .get(1)
            .map(|arg| self.resolve_ty(&arg.ty))
            .unwrap_or(Ty::Unit);
        Ok(TypedNode {
            ty: self.resolve_ty(&result_ty),
            span: span.clone(),
            node: TypedInner::TraitCall {
                trait_name,
                method_name: method_name.into(),
                receiver_ty: self.resolve_ty(receiver_ty),
                obligation: TraitObligation {
                    trait_id: trait_key,
                    trait_args: resolved_trait_args,
                    receiver: self.resolve_ty(receiver_ty),
                },
                dispatch,
                origin: TraitCallOrigin::Operator { op, lhs_ty, rhs_ty },
                args,
            },
        })
    }

    pub(super) fn check_pipe(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_pipe_with_expected(span, left, right, None)
    }

    fn check_pipe_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        (|| {
            let typed_left = self.check_node(left)?;
            let rhs_ret_expected = expected.map(|ty| self.resolve_ty(ty));
            let typed_right = match right {
                Resolved::InferredFacetCapture(_, _)
                | Resolved::Capture(_, _, _)
                | Resolved::Closure(_, _, _, _)
                | Resolved::ExtractorClosure(_, _, _, _)
                | Resolved::CaptureClosure(_, _, _, _)
                | Resolved::Grouped(_, _) => {
                    let contract = self.callable_contract(
                        &typed_left.ty,
                        rhs_ret_expected.clone(),
                        ExpectedCallableSlot::Plain,
                    );
                    self.check_apply_callable_with_contract(right, &contract, "`|>`")?
                }
                Resolved::App(call_span, func, args) => {
                    if let Some(typed) = self.check_trait_helper_pipe_callable(
                        call_span,
                        func,
                        args,
                        self.resolve_ty(&typed_left.ty),
                        rhs_ret_expected.clone(),
                        "`|>`",
                    )? {
                        typed
                    } else {
                        self.check_apply_callable(right, "`|>`")?
                    }
                }
                Resolved::ReturnTypeArgumentApply(call_span, _, _) => self
                    .check_trait_helper_pipe_callable(
                        call_span,
                        right,
                        &[],
                        self.resolve_ty(&typed_left.ty),
                        rhs_ret_expected.clone(),
                        "`|>`",
                    )?
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: "`|>` requires a specialized trait helper on the right".into(),
                        span: call_span.clone(),
                        hint: None,
                    })?,
                _ => self.check_apply_callable(right, "`|>`")?,
            };
            let (param, ret) =
                self.unary_function_parts(&typed_right.ty, "`|>`", &typed_right.span)?;
            self.assert_operand_relation(
                &param,
                &typed_left.ty,
                &typed_left,
                &typed_right,
                TypeDiagnosticReason::ArgumentTypeMismatch,
                "|>",
                "|>",
                None,
                SourceRole::RightValue,
            )?;
            Ok(TypedNode {
                ty: self.resolve_ty(&ret),
                span: span.clone(),
                node: TypedInner::Pipe(Box::new(typed_left), Box::new(typed_right)),
            })
        })()
        .map_err(|error| {
            Self::operator_operand_error(
                error,
                "|>",
                self.resolved_span(left),
                self.resolved_span(right),
            )
        })
    }

    fn assert_contextual_callable_argument(
        &mut self,
        expected: &Ty,
        argument: &TypedNode,
        source: &TypedNode,
        capability: &str,
        contextual_return: bool,
        callable: &str,
        ordinal: u32,
    ) -> Result<(), TypeError> {
        let expected = self.resolve_ty(expected);
        let actual = self.resolve_ty(&argument.ty);
        let (Some((inputs, output)), Some((actual_inputs, actual_output))) =
            (self.function_parts(&expected), self.function_parts(&actual))
        else {
            return self.assert_type_relation(
                &expected,
                &actual,
                self.type_fact(SourceRole::LeftValue, &source.span, &source.ty),
                self.type_fact(SourceRole::RightValue, &argument.span, &argument.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::TraitCall,
                callable,
                ordinal,
            );
        };
        if inputs.len() != actual_inputs.len() {
            return Err(self.callable_shape_error(
                &actual,
                callable,
                &argument.span,
                Some(inputs.len()),
            ));
        }
        let inputs = inputs.to_vec();
        let actual_inputs = actual_inputs.to_vec();
        let output = output.clone();
        let actual_output = actual_output.clone();
        for (input, actual_input) in inputs.iter().zip(&actual_inputs) {
            self.assert_operand_relation(
                input,
                actual_input,
                source,
                argument,
                TypeDiagnosticReason::TypePayloadMismatch,
                callable,
                "",
                Some(capability),
                SourceRole::LeftValue,
            )
            .map_err(Self::trait_helper_origin)?;
        }
        if contextual_return {
            self.assert_carrier_relation(
                &output,
                &actual_output,
                source,
                argument,
                capability,
                "",
                SourceRole::LeftValue,
            )
            .map_err(Self::trait_helper_origin)
        } else {
            self.assert_type_relation(
                &output,
                &actual_output,
                self.type_fact(SourceRole::LeftValue, &source.span, &source.ty),
                self.type_fact(SourceRole::RightValue, &argument.span, &argument.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::TraitCall,
                callable,
                ordinal,
            )
        }
    }

    fn trait_parameter_is_lazy(&self, trait_name: &str, method_name: &str, index: usize) -> bool {
        self.traits
            .get(trait_name)
            .filter(|declaration| declaration.standard_lazy_contract)
            .and_then(|declaration| declaration.methods.get(method_name))
            .and_then(|method| method.value_parameters.get(index))
            .is_some_and(|parameter| Self::lazy_parameter_inner(parameter.ty.syntax()).is_some())
    }

    /// Trait bodies receive the same normalized shell as special forms, but
    /// consume it themselves. Hoist an explicit eager boundary before creating it.
    fn check_trait_lazy_argument(
        &mut self,
        expression: &Resolved,
        expected: &Ty,
        span: &Span,
    ) -> Result<TypedNode, TypeError> {
        let Ty::Func(parameters, result) = self.resolve_ty(expected) else {
            return Err(TypeError::new(
                "Invalid normalized Lazy parameter contract",
                span.clone(),
            ));
        };
        if !parameters.is_empty() {
            return Err(TypeError::new(
                "Lazy parameter requires a zero-argument callable",
                span.clone(),
            ));
        }
        if matches!(expression, Resolved::Grouped(..)) && !Self::is_lazy_placeholder(expression) {
            if let Some(reference) = sigil::collect_resolved_closure_captures(expression, &[])
                .into_iter()
                .find(|id| id.compiler_generated && id.name.starts_with("__cap_"))
            {
                return Err(TypeError::new(
                    "capture placeholder is not available in a Lazy eager expression",
                    reference.span,
                ));
            }
        }
        let mut input = self.check_lazy_input(expression, Some(&result), span)?;
        let mut eager_binding = None;
        let mut outer_ids = self
            .env
            .vars
            .iter()
            .filter_map(|(id, ty)| {
                (!matches!(ty, Ty::UserFunc { .. } | Ty::BuiltinFunc { .. })
                    && !self.env.type_constructor_ids.contains(id))
                .then_some(*id)
            })
            .collect::<HashSet<_>>();
        if let TypedInner::EagerBoundary(inner) = &input.node.node {
            let id = ResolvedId {
                name: "__lazy_eager".into(),
                qualified_name: None,
                symbol_info: None,
                unique_id: Self::next_synthetic_range_uid(),
                compiler_generated: true,
                span: span.clone(),
            };
            outer_ids.insert(id.unique_id);
            eager_binding = Some(TypedNode {
                ty: Ty::Unit,
                span: input.node.span.clone(),
                node: TypedInner::Bind(
                    TypedPattern::Var(inner.ty.clone(), id.clone()),
                    inner.clone(),
                ),
            });
            input.node.node = TypedInner::Var(id);
        }
        let body = self.normalize_lazy_single(input, &result, span)?;
        let captures = Self::finalized_closure_captures(&body, &outer_ids);
        let closure = TypedNode {
            ty: Ty::Func(vec![], Box::new(body.ty.clone())),
            span: span.clone(),
            node: TypedInner::Closure(vec![], captures, Box::new(body)),
        };
        Ok(match eager_binding {
            Some(binding) => TypedNode {
                ty: closure.ty.clone(),
                span: span.clone(),
                node: TypedInner::Block(vec![binding, closure]),
            },
            None => closure,
        })
    }

    fn check_invocation_argument(
        &mut self,
        expr: &Resolved,
        expected: &Ty,
        operator: Option<OperatorTraitOp>,
        index: usize,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        if index == 1
            && matches!(
                operator,
                Some(OperatorTraitOp::PipeMap | OperatorTraitOp::PipeBind)
            )
        {
            if let Resolved::ReturnTypeArgumentApply(span, _, _) = expr {
                if let Ty::Func(inputs, output) = self.resolve_ty(expected) {
                    if let [input] = inputs.as_slice() {
                        if let Some(typed) = self.check_trait_helper_pipe_callable(
                            span,
                            expr,
                            &[],
                            input.clone(),
                            Some(*output),
                            "context operator",
                        )? {
                            return Ok(typed);
                        }
                    }
                }
            }

            if let Resolved::App(span, func, args) = expr {
                let resolved = self.resolve_ty(expected);
                if let Ty::Func(inputs, output) = resolved {
                    if let [input] = inputs.as_slice() {
                        if let Some(typed) = self.check_trait_helper_pipe_callable(
                            span,
                            func,
                            args,
                            input.clone(),
                            Some(*output),
                            "context operator",
                        )? {
                            return Ok(typed);
                        }
                    }
                }
                return self.check_apply_callable(expr, "context operator");
            }
        }
        self.check_node_with_expected_relation(expr, Some(expected), expected_relation)
    }

    fn check_operator_invocation(
        &mut self,
        span: &Span,
        trait_short_name: &str,
        method_name: &str,
        op: OperatorTraitOp,
        token: &str,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let trait_name = self
            .trait_key_by_short_name(trait_short_name)
            .ok_or_else(|| {
                TypeError::new(format!("Unknown trait: {trait_short_name}"), span.clone())
            })?;
        let args = vec![
            ResolvedRecordLitArg::Positional(left.clone()),
            ResolvedRecordLitArg::Positional(right.clone()),
        ];
        let mut typed = self
            .check_trait_invocation(
                span,
                &trait_name,
                method_name,
                &args,
                None,
                expected,
                None,
                None,
                None,
                None,
                Some(op.clone()),
                None,
            )
            .map_err(|mut error| {
                if let Some(diagnostic) = &mut error.structured {
                    if diagnostic.origin == DiagnosticOrigin::TraitCall {
                        diagnostic.origin = DiagnosticOrigin::Operator {
                            operator: token.into(),
                        };
                        diagnostic.map_source_facts(|fact| {
                            if fact.span == *self.resolved_span(left) {
                                fact.role = SourceRole::LeftValue;
                            }
                            if fact.span == *self.resolved_span(right) {
                                fact.role = SourceRole::RightValue;
                            }
                        });
                    }
                }
                Self::operator_operand_error(
                    error,
                    token,
                    self.resolved_span(left),
                    self.resolved_span(right),
                )
            })?;
        if let TypedInner::TraitCall { origin, args, .. } = &mut typed.node {
            *origin = TraitCallOrigin::Operator {
                op,
                lhs_ty: self.resolve_ty(&args[0].ty),
                rhs_ty: self.resolve_ty(&args[1].ty),
            };
        }
        Ok(typed)
    }

    pub(super) fn check_context_apply(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_context_apply_with_expected(span, left, right, None)
    }

    fn check_context_apply_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_operator_invocation(
            span,
            "Applicative",
            "ap",
            OperatorTraitOp::ContextApply,
            "|*|",
            left,
            right,
            expected,
        )
    }

    pub(super) fn check_context_map(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_context_map_with_expected(span, left, right, None)
    }

    fn check_context_map_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_operator_invocation(
            span,
            "Functor",
            "fmap",
            OperatorTraitOp::PipeMap,
            "|*>",
            left,
            right,
            expected,
        )
    }

    pub(super) fn check_context_bind(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_context_bind_with_expected(span, left, right, None)
    }

    /// Roll back speculative checking while returning source type-syntax
    /// failures separately from candidate-dependent invocation failures.
    fn probe_constructor_invocation<T>(
        &mut self,
        probe: impl FnOnce(&mut Self) -> Result<T, TypeError>,
    ) -> Result<Result<T, TypeError>, TypeError> {
        let checkpoint = self.candidate_probe_checkpoint();
        let retained = Rc::new(RefCell::new(None));
        let outer_probe = self.type_syntax_probe_error.replace(retained.clone());
        let result = probe(self);
        self.type_syntax_probe_error = outer_probe;
        self.rollback_candidate_probe(checkpoint);
        if let Some(error) = retained.borrow_mut().take() {
            if let Some(outer) = &self.type_syntax_probe_error {
                let mut retained = outer.borrow_mut();
                if retained.is_none() {
                    *retained = Some(error.clone());
                }
            }
            return Err(error);
        }
        Ok(result)
    }

    /// A receiverless constructor helper exposes its mapped input through its
    /// signature. Probe each carrier with the complete invocation constraints;
    /// only a unique successful carrier may commit its substitutions.
    fn try_constructor_invocation_from_arguments(
        &mut self,
        span: &Span,
        trait_name: &str,
        method_name: &str,
        args: &[ResolvedRecordLitArg],
        declared_params: &[Ty],
        expected: Option<&Ty>,
        expected_relation: Option<(&ExpectedTypeRelation, &Span)>,
        argument_expected_relation: Option<&ExpectedTypeRelation>,
        constructor_failure_reason: Option<TypeDiagnosticReason>,
        explicit: Option<&[AstTy]>,
        operator: Option<OperatorTraitOp>,
        receiver_index: usize,
    ) -> Result<Option<TypedNode>, TypeError> {
        let ResolvedRecordLitArg::Positional(Resolved::App(_, helper, helper_args)) =
            &args[receiver_index]
        else {
            return Ok(None);
        };
        let Some((_, helper_trait, helper_method)) = self.trait_method_ref(helper) else {
            return Ok(None);
        };
        let helper_info = self.traits[&helper_trait].clone();
        let helper_method = &helper_info.methods[&helper_method];
        if helper_info.constructor_slots.len() != 1 {
            return Ok(None);
        }
        let [ResolvedRecordLitArg::Positional(value)] = helper_args.as_slice() else {
            return Ok(None);
        };
        let helper_self = self.env.fresh_tyvar();
        let (helper_params, helper_result, _, _, _) =
            self.resolve_trait_method_signature(&helper_info, helper_method, &helper_self)?;
        let (Some(parameter), Ty::SelfApp(slots)) = (helper_params.first(), &helper_result) else {
            return Ok(None);
        };
        if helper_params.len() != 1 || slots.as_slice() != std::slice::from_ref(parameter) {
            return Ok(None);
        }
        let typed_value = self.check_node(value)?;
        let value_ty = self.resolve_ty(&typed_value.ty);
        let mut carrier_evidence = match expected {
            Some(ty) => match self
                .constructor_context_type_for(trait_name, ty, &value_ty)
                .into_checked()
                .map_err(|error| error.at_span(span))?
            {
                ConstructorApplicationOutcome::Applied(context) => Some(context),
                ConstructorApplicationOutcome::Deferred { .. }
                | ConstructorApplicationOutcome::Rejected { .. } => None,
            },
            None => None,
        };
        if carrier_evidence.is_none() && Self::explicit_type_args(helper).is_some() {
            let ResolvedRecordLitArg::Positional(receiver) = &args[receiver_index] else {
                unreachable!()
            };
            let typed = self.check_node(receiver)?;
            carrier_evidence = match self
                .constructor_context_type_for(trait_name, &typed.ty, &value_ty)
                .into_checked()
                .map_err(|error| error.at_span(&typed.span))?
            {
                ConstructorApplicationOutcome::Applied(context) => Some(context),
                ConstructorApplicationOutcome::Deferred { .. }
                | ConstructorApplicationOutcome::Rejected { .. } => None,
            };
        }
        if carrier_evidence.is_none() {
            for (index, (argument, parameter)) in args.iter().zip(declared_params).enumerate() {
                if index == receiver_index {
                    continue;
                }
                let ResolvedRecordLitArg::Positional(argument) = argument else {
                    continue;
                };
                carrier_evidence = self
                    .probe_constructor_invocation(|checker| {
                        let observed = match parameter {
                            Ty::SelfApp(_) => Some(checker.check_node(argument)?.ty),
                            Ty::Func(inputs, output)
                                if inputs.len() == 1
                                    && matches!(output.as_ref(), Ty::SelfApp(_)) =>
                            {
                                let result = checker.env.fresh_tyvar();
                                let callable = Ty::Func(vec![value_ty.clone()], Box::new(result));
                                let typed = checker.check_invocation_argument(
                                    argument,
                                    &callable,
                                    operator.clone(),
                                    index,
                                    None,
                                )?;
                                checker
                                    .function_parts(&typed.ty)
                                    .map(|(_, output)| checker.resolve_ty(output))
                            }
                            _ => None,
                        };
                        Ok(observed.and_then(|observed| {
                            match checker
                                .constructor_context_type_for(trait_name, &observed, &value_ty)
                            {
                                ConstructorApplicationOutcome::Applied(context) => Some(context),
                                ConstructorApplicationOutcome::Deferred { .. }
                                | ConstructorApplicationOutcome::Rejected { .. } => None,
                            }
                        }))
                    })?
                    .ok()
                    .flatten();
                if carrier_evidence.is_some() {
                    break;
                }
            }
        }
        let candidates = match &carrier_evidence {
            Some(carrier) => vec![carrier.clone()],
            None => self.constructor_context_candidates(trait_name, &value_ty)?,
        };
        let mut accepted = Vec::new();
        let mut failures = Vec::new();
        for candidate in candidates {
            let result = self.probe_constructor_invocation(|checker| {
                checker.check_trait_invocation(
                    span,
                    trait_name,
                    method_name,
                    args,
                    None,
                    expected,
                    expected_relation,
                    argument_expected_relation,
                    constructor_failure_reason,
                    explicit,
                    operator.clone(),
                    Some(&candidate),
                )
            })?;
            match result {
                Ok(_) => accepted.push(candidate.clone()),
                Err(error) if carrier_evidence.is_some() => return Err(error),
                Err(error) => failures.push(CandidateFailureData {
                    candidate_type: self.diagnostic_ty_name(&candidate),
                    detail: error.message,
                }),
            }
        }
        if !accepted.is_empty() && carrier_evidence.is_none() {
            return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
        }
        if let [candidate] = accepted.as_slice() {
            return self
                .check_trait_invocation(
                    span,
                    trait_name,
                    method_name,
                    args,
                    None,
                    expected,
                    expected_relation,
                    argument_expected_relation,
                    constructor_failure_reason,
                    explicit,
                    operator,
                    Some(candidate),
                )
                .map(Some);
        }
        if !accepted.is_empty() {
            return Err(self.ambiguous_constructor_result(trait_name, method_name, span));
        }
        Err(TypeError::from_structured(StructuredDiagnostic {
            reason: TypeDiagnosticReason::NoApplicableTraitImplementation.into(),
            origin: DiagnosticOrigin::TraitCall,
            data: DiagnosticData::CandidateSelection(CandidateSelectionData {
                subject_type: Some(self.diagnostic_ty_name(&value_ty)),
                trait_arguments: vec![],
                impl_declaration: None,
                trait_name: self.trait_display_name(trait_name),
                method: method_name.into(),
                failures,
            }),
            primary: self.type_fact(SourceRole::Value, &typed_value.span, &typed_value.ty),
            related: vec![],
            remediation: None,
        }))
    }

    fn check_context_bind_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_operator_invocation(
            span,
            "Monad",
            "bind",
            OperatorTraitOp::PipeBind,
            "|>=",
            left,
            right,
            expected,
        )
    }

    fn prepare_composition_invocation(
        &mut self,
        span: &Span,
        kind: &CompositionOperator,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<(Vec<TypedNode>, Vec<Ty>), TypeError> {
        let (label, capability) = match kind {
            CompositionOperator::Plain => ("Bootstrap::>>", None),
            CompositionOperator::Lifted => ("Bootstrap::>*", Some("Functor")),
            CompositionOperator::Kleisli => ("Bootstrap::>=>", Some("Monad")),
        };
        let expected_parts = self.expected_unary_function_parts(expected);
        let expected_output = expected_parts.as_ref().map(|(_, output)| output.clone());
        let typed_left = if let Some((input, output)) = &expected_parts {
            let output_hint = if let Some(capability) = capability {
                let payload = self.env.fresh_tyvar();
                match self.constructor_context_type_for(capability, output, &payload) {
                    ConstructorApplicationOutcome::Applied(context) => Some(context),
                    ConstructorApplicationOutcome::Deferred { .. }
                    | ConstructorApplicationOutcome::Rejected { .. } => None,
                }
            } else {
                None
            };
            let contract =
                self.callable_contract(input, output_hint, ExpectedCallableSlot::Contextual);
            self.check_compose_callable_with_contract(left, &contract, label)?
        } else {
            self.check_operator_compose_callable(left, label)?
        };
        let (left_input, left_output) =
            self.unary_function_parts(&typed_left.ty, label, &typed_left.span)?;
        let input = if let Some(capability) = capability {
            let outcome = self.constructor_slot_type_for(capability, &left_output);
            self.require_constructor_projection_type(
                outcome,
                capability,
                &left_output,
                &typed_left.span,
                label,
            )
            .map_err(|mut error| {
                if let Some(diagnostic) = &mut error.structured {
                    diagnostic.map_source_facts(|fact| {
                        if fact.span == typed_left.span {
                            fact.ty = Some(self.diagnostic_ty_name(&typed_left.ty));
                            fact.role = SourceRole::LeftValue;
                        }
                    });
                }
                error
            })?
        } else {
            left_output.clone()
        };
        let result_payload = self.env.fresh_tyvar();
        let result_context = if matches!(kind, CompositionOperator::Kleisli) {
            let outcome = self.constructor_context_type_for("Monad", &left_output, &result_payload);
            Some(self.require_constructor_projection_type(
                outcome,
                "Monad",
                &left_output,
                span,
                label,
            )?)
        } else {
            None
        };
        let output_hint = match kind {
            CompositionOperator::Plain => expected_output.clone(),
            CompositionOperator::Lifted => expected_output.as_ref().and_then(|ty| {
                match self.constructor_slot_type_for("Functor", ty) {
                    ConstructorApplicationOutcome::Applied(slot) => Some(slot),
                    ConstructorApplicationOutcome::Deferred { .. }
                    | ConstructorApplicationOutcome::Rejected { .. } => None,
                }
            }),
            CompositionOperator::Kleisli => {
                expected_output.clone().or_else(|| result_context.clone())
            }
        };
        let contract =
            self.callable_contract(&input, output_hint, ExpectedCallableSlot::Contextual);
        let typed_right = self.check_compose_callable_with_contract(right, &contract, label)?;
        let (_, right_output) =
            self.unary_function_parts(&typed_right.ty, label, &typed_right.span)?;
        let trait_args = match kind {
            CompositionOperator::Plain => vec![left_input, left_output, right_output],
            CompositionOperator::Lifted => {
                let outcome =
                    self.constructor_context_type_for("Functor", &left_output, &right_output);
                let mapped = self.require_constructor_projection_type(
                    outcome,
                    "Functor",
                    &left_output,
                    span,
                    label,
                )?;
                vec![left_input, input, right_output, mapped]
            }
            CompositionOperator::Kleisli => vec![
                left_input,
                input,
                result_context.expect("Kleisli contextual result"),
            ],
        };
        Ok((vec![typed_left, typed_right], trait_args))
    }

    pub(super) fn check_compose(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_compose_with_expected(span, left, right, None)
    }

    fn check_compose_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let (args, _) = self.prepare_composition_invocation(
            span,
            &CompositionOperator::Plain,
            left,
            right,
            expected,
        )?;
        let [typed_left, typed_right] =
            <[TypedNode; 2]>::try_from(args).expect("composition preparation returns two operands");
        let (input, middle) = self.unary_function_parts(&typed_left.ty, ">>", &typed_left.span)?;
        let (next_input, output) =
            self.unary_function_parts(&typed_right.ty, ">>", &typed_right.span)?;
        self.assert_operand_relation(
            &next_input,
            &middle,
            &typed_left,
            &typed_right,
            TypeDiagnosticReason::ArgumentTypeMismatch,
            ">>",
            ">>",
            None,
            SourceRole::RightValue,
        )?;
        Ok(TypedNode {
            ty: Ty::Func(
                vec![self.resolve_ty(&input)],
                Box::new(self.resolve_ty(&output)),
            ),
            span: span.clone(),
            node: TypedInner::Compose(
                ComposeFlavor::Plain,
                Box::new(typed_left),
                Box::new(typed_right),
            ),
        })
    }

    pub(super) fn check_lifted_compose(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_lifted_compose_with_expected(span, left, right, None)
    }

    fn check_lifted_compose_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_contextual_compose_with_expected(
            span,
            left,
            right,
            expected,
            CompositionOperator::Lifted,
        )
    }

    pub(super) fn check_kleisli_compose(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_kleisli_compose_with_expected(span, left, right, None)
    }

    fn check_kleisli_compose_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_contextual_compose_with_expected(
            span,
            left,
            right,
            expected,
            CompositionOperator::Kleisli,
        )
    }

    fn check_contextual_compose_with_expected(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
        kind: CompositionOperator,
    ) -> Result<TypedNode, TypeError> {
        let (values, trait_args) =
            self.prepare_composition_invocation(span, &kind, left, right, expected)?;
        let [typed_left, typed_right] = <[TypedNode; 2]>::try_from(values)
            .expect("composition preparation returns two operands");
        let (trait_name, method_name, op, token) = match kind {
            CompositionOperator::Lifted => ("Functor", "fmap", OperatorTraitOp::PipeMap, ">*"),
            CompositionOperator::Kleisli => ("Monad", "bind", OperatorTraitOp::PipeBind, ">=>"),
            _ => unreachable!("contextual composition kind"),
        };
        let input_ty = self.resolve_ty(&trait_args[0]);
        let source_ty = self.resolve_ty(&typed_left.ty);
        let (source_input, carrier_ty) =
            self.unary_function_parts(&source_ty, token, &typed_left.span)?;
        self.assert_operand_relation(
            &source_input,
            &input_ty,
            &typed_left,
            &typed_right,
            TypeDiagnosticReason::ArgumentTypeMismatch,
            token,
            token,
            None,
            SourceRole::LeftValue,
        )?;
        let output_ty = match kind {
            CompositionOperator::Lifted => self.resolve_ty(&trait_args[3]),
            CompositionOperator::Kleisli => self.resolve_ty(&trait_args[2]),
            _ => unreachable!(),
        };
        let make_id = |name: &str| ResolvedId {
            name: name.into(),
            qualified_name: None,
            symbol_info: None,
            unique_id: Self::next_synthetic_range_uid(),
            compiler_generated: true,
            span: span.clone(),
        };
        let left_id = make_id("__compose_left");
        let right_id = make_id("__compose_right");
        let input_id = make_id("__compose_input");
        let left_ref = TypedNode {
            ty: source_ty.clone(),
            span: span.clone(),
            node: TypedInner::Var(left_id.clone()),
        };
        let right_ref = TypedNode {
            ty: self.resolve_ty(&typed_right.ty),
            span: span.clone(),
            node: TypedInner::Var(right_id.clone()),
        };
        let input_ref = TypedNode {
            ty: input_ty.clone(),
            span: span.clone(),
            node: TypedInner::Var(input_id.clone()),
        };
        let produced = TypedNode {
            ty: carrier_ty.clone(),
            span: span.clone(),
            node: TypedInner::App(Box::new(left_ref), vec![input_ref]),
        };
        let body = self.flow_operator_trait_call(
            span,
            trait_name,
            method_name,
            &carrier_ty,
            vec![],
            op,
            vec![produced, right_ref],
            output_ty.clone(),
            token,
        )?;
        let closure_ty = Ty::Func(vec![input_ty.clone()], Box::new(output_ty));
        let closure = TypedNode {
            ty: closure_ty.clone(),
            span: span.clone(),
            node: TypedInner::Closure(
                vec![TypedClosureParam {
                    id: input_id,
                    ty: input_ty,
                }],
                vec![left_id.clone(), right_id.clone()],
                Box::new(body),
            ),
        };
        let bind_left = TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Bind(TypedPattern::Var(source_ty, left_id), Box::new(typed_left)),
        };
        let bind_right = TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Bind(
                TypedPattern::Var(self.resolve_ty(&typed_right.ty), right_id),
                Box::new(typed_right),
            ),
        };
        Ok(TypedNode {
            ty: closure_ty,
            span: span.clone(),
            node: TypedInner::Block(vec![bind_left, bind_right, closure]),
        })
    }

    pub(super) fn match_result_variant_tags(&self, span: &Span) -> Result<(u32, u32), TypeError> {
        let variants = self
            .lookup_enum_variants_of("MatchResult")
            .ok_or_else(|| TypeError {
                structured: None,
                message: "MatchResult enum is not available in the current environment".into(),
                span: span.clone(),
                hint: None,
            })?;
        let mut ok_tag = None;
        let mut err_tag = None;
        for variant in variants {
            match variant.short_name.as_str() {
                "Ok" => ok_tag = Some(variant.tag),
                "Err" => err_tag = Some(variant.tag),
                _ => {}
            }
        }
        match (ok_tag, err_tag) {
            (Some(ok), Some(err)) => Ok((ok, err)),
            _ => Err(TypeError {
                structured: None,
                message: "MatchResult enum must define Ok and Err variants".into(),
                span: span.clone(),
                hint: None,
            }),
        }
    }

    pub(super) fn extractor_signature_ty(ty: &Ty) -> &Ty {
        match ty {
            Ty::ExtractorClosure(signature) => signature,
            other => other,
        }
    }

    pub(super) fn extractor_contract(
        &mut self,
        extractor_id: &ResolvedId,
        extractor_ty: &Ty,
        span: &Span,
    ) -> Result<(Ty, Vec<Ty>, u32, u32), TypeError> {
        let (params, ret) = match Self::extractor_signature_ty(extractor_ty) {
            Ty::BuiltinFunc { params, ret, .. }
            | Ty::UserFunc { params, ret, .. }
            | Ty::Func(params, ret) => (params.clone(), ret.as_ref().clone()),
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Extractor {} is not callable (got {})",
                        extractor_id.name,
                        self.ty_name(other)
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }
        };
        if params.is_empty() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Extractor {} must accept at least one input value, got {} parameter(s)",
                    extractor_id.name,
                    params.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }
        let input_ty = params.last().expect("nonempty parameters checked").clone();
        let seq_tys = self.require_extractor_match_result_payload_ty(
            &self.resolve_ty(&ret),
            span,
            &extractor_id.name,
        )?;
        let (success_tag, err_tag) = self.match_result_variant_tags(span)?;
        Ok((input_ty, seq_tys, success_tag, err_tag))
    }

    pub(super) fn extractor_callable_ty(
        &mut self,
        extractor_id: &ResolvedId,
        span: &Span,
    ) -> Result<Ty, TypeError> {
        let extractor_ty = self
            .env
            .lookup_var(extractor_id.unique_id)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Undefined extractor: {}", extractor_id.name),
                span: span.clone(),
                hint: None,
            })?;
        if matches!(extractor_ty, Ty::ExtractorClosure(_)) {
            Ok(self.resolve_ty(&extractor_ty))
        } else {
            // Named Pattern heads are call sites. Preserve the fresh solver
            // substitution created with their signature for specialization.
            let mut fresh = HashMap::new();
            if let Ty::UserFunc {
                type_params,
                call_substitution,
                ..
            } = &extractor_ty
            {
                if !call_substitution.is_empty() {
                    return Err(self.typecheck_invariant_error(
                        "named Extractor binding must retain its declaration signature",
                        span,
                    ));
                }
                for variable in type_params {
                    self.instantiate_ty_with_fresh(&Ty::Var(*variable), &mut fresh);
                }
            }
            let mut instantiated = self.instantiate_ty_with_fresh(&extractor_ty, &mut fresh);
            if let Ty::UserFunc {
                type_params,
                call_substitution,
                ..
            } = &mut instantiated
            {
                *call_substitution = type_params
                    .iter()
                    .map(|variable| {
                        fresh.get(variable).cloned().map(|ty| (*variable, ty)).ok_or_else(|| {
                            self.typecheck_invariant_error(
                                "named Extractor instantiation must preserve every declaration slot",
                                span,
                            )
                        })
                    })
                    .collect::<Result<_, _>>()?;
                call_substitution.sort_unstable_by_key(|(variable, _)| *variable);
            }
            Ok(instantiated)
        }
    }

    pub(super) fn kernel_uncons_id(&self, span: &Span) -> Result<ResolvedId, TypeError> {
        let id = self
            .function_ids_by_name
            .get("Kernel::uncons")
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: "Missing helper function: Kernel::uncons".into(),
                span: span.clone(),
                hint: None,
            })?;
        Ok(ResolvedId {
            span: span.clone(),
            ..id
        })
    }

    pub(super) fn uncons_contract_for_input(
        &self,
        observed_ty: &Ty,
        span: &Span,
    ) -> Result<(Ty, Vec<Ty>), TypeError> {
        match self.resolve_ty(observed_ty) {
            Ty::List(inner) => {
                let elem_ty = inner.as_ref().clone();
                let list_ty = Ty::List(Box::new(elem_ty.clone()));
                Ok((list_ty.clone(), vec![elem_ty, list_ty]))
            }
            Ty::Str => Ok((Ty::Str, vec![Ty::Str, Ty::Str])),
            other => Err(TypeError {
                structured: None,
                message: format!(
                    "Extractor uncons expects List<...> or String, got {}",
                    self.ty_name(&other)
                ),
                span: span.clone(),
                hint: None,
            }),
        }
    }

    pub(super) fn extractor_contract_for_observed_ty(
        &mut self,
        extractor_id: &ResolvedId,
        observed_ty: &Ty,
        pre_args: &[Resolved],
        span: &Span,
    ) -> Result<(Ty, Ty, Vec<TypedNode>, Vec<Ty>, u32, u32), TypeError> {
        let mut extractor_ty = self.extractor_callable_ty(extractor_id, span)?;
        let params = match Self::extractor_signature_ty(&extractor_ty) {
            Ty::UserFunc { params, .. } | Ty::BuiltinFunc { params, .. } | Ty::Func(params, _) => {
                params.clone()
            }
            _ => {
                return Err(TypeError::new(
                    "Extractor head is not callable",
                    span.clone(),
                ));
            }
        };
        let Some((input, expected_pre_args)) = params.split_last() else {
            return Err(TypeError::new(
                "Extractor requires at least one input",
                span.clone(),
            ));
        };
        if pre_args.len() != expected_pre_args.len() {
            return Err(TypeError::new(
                format!(
                    "Extractor {} requires {} pre-argument(s), got {}",
                    extractor_id.name,
                    expected_pre_args.len(),
                    pre_args.len()
                ),
                span.clone(),
            ));
        }
        self.types_compatible(input, observed_ty)?;
        let pre_args = pre_args
            .iter()
            .cloned()
            .map(ResolvedRecordLitArg::Positional)
            .collect::<Vec<_>>();
        let typed_pre_args = self.typecheck_positional_call_args(
            span,
            &extractor_id.name,
            expected_pre_args,
            &pre_args,
            None,
            "Extractor pre-arguments must be positional".into(),
        )?;
        self.ensure_no_runtime_facet_args(&typed_pre_args, span, "Extractor pre-arguments")?;

        let (input_ty, seq_tys, success_tag, err_tag) = if self
            .function_ids_by_name
            .get("Kernel::uncons")
            .is_some_and(|id| id.unique_id == extractor_id.unique_id)
            && matches!(&extractor_ty, Ty::BuiltinFunc { .. })
        {
            let (input_ty, seq_tys) = self.uncons_contract_for_input(observed_ty, span)?;
            let Ty::BuiltinFunc { params, ret, .. } = &mut extractor_ty else {
                unreachable!()
            };
            *params = vec![input_ty.clone()];
            *ret = Box::new(Ty::MatchResult(Box::new(Ty::Tuple(seq_tys.clone()))));
            let (success_tag, err_tag) = self.match_result_variant_tags(span)?;
            (input_ty, seq_tys, success_tag, err_tag)
        } else {
            // Input and prearguments share one instantiation. Resolve their
            // constraints before choosing UnitOnly, tuple, or single-value shape.
            self.extractor_contract(extractor_id, &extractor_ty, span)?
        };
        Ok((
            self.resolve_ty(&input_ty),
            self.resolve_ty(&extractor_ty),
            typed_pre_args,
            seq_tys,
            success_tag,
            err_tag,
        ))
    }

    pub(super) fn require_extractor_match_result_payload_ty(
        &self,
        ty: &Ty,
        span: &Span,
        context: &str,
    ) -> Result<Vec<Ty>, TypeError> {
        match self.resolve_ty(ty) {
            Ty::MatchResult(payload) => match payload.as_ref() {
                Ty::Tuple(items) => Ok(items.clone()),
                other => Ok(vec![other.clone()]),
            },
            other => Err(TypeError {
                structured: None,
                message: format!(
                    "{} must return MatchResult<T>, got {}",
                    context,
                    self.ty_name(&other)
                ),
                span: span.clone(),
                hint: None,
            }),
        }
    }

    pub(super) fn typecheck_user_function_args(
        &mut self,
        span: &Span,
        callee_uid: u32,
        callee_label: &str,
        params: &[Ty],
        args: &[ResolvedRecordLitArg],
        callable_hint: Option<&str>,
        defer_constructor_conflicts: bool,
    ) -> Result<Vec<TypedNode>, TypeError> {
        let has_named = args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)));
        let has_positional = args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Positional(_)));
        if has_named && has_positional {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    callee_label,
                    None,
                    params.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: "Cannot mix positional and named arguments".into(),
                span: span.clone(),
                hint: None,
            });
        }

        let param_names = self
            .callable_signatures
            .get(&callee_uid)
            .map(|signature| {
                signature
                    .value_parameters
                    .iter()
                    .map(|parameter| parameter.name.clone())
                    .collect::<Vec<_>>()
            })
            .or_else(|| self.user_func_params.get(&callee_uid).cloned());

        if has_named {
            let names = param_names.as_ref().ok_or_else(|| TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    callee_label,
                    None,
                    params.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: "This function value does not accept named arguments".into(),
                span: span.clone(),
                hint: None,
            })?;

            let mut reordered: Vec<Option<&Resolved>> = vec![None; params.len()];
            for arg in args {
                let ResolvedRecordLitArg::Named(name, expr) = arg else {
                    return Err(TypeError {
                        structured: Some(self.argument_contract_diagnostic(
                            TypeDiagnosticReason::ArgumentModeMismatch,
                            callee_label,
                            None,
                            params.len(),
                            args.len(),
                            span,
                            DiagnosticOrigin::Call,
                        )),
                        message: "Cannot mix positional and named arguments".into(),
                        span: span.clone(),
                        hint: None,
                    });
                };
                let idx = names
                    .iter()
                    .position(|n| n == name)
                    .ok_or_else(|| TypeError {
                        structured: Some(self.argument_contract_diagnostic(
                            TypeDiagnosticReason::UnknownNamedArgument,
                            callee_label,
                            Some(name),
                            params.len(),
                            args.len(),
                            span,
                            DiagnosticOrigin::Call,
                        )),
                        message: format!("Unknown argument name '{}' for function", name),
                        span: span.clone(),
                        hint: None,
                    })?;
                if reordered[idx].is_some() {
                    return Err(TypeError {
                        structured: Some(self.argument_contract_diagnostic(
                            TypeDiagnosticReason::DuplicateArgument,
                            callee_label,
                            Some(name),
                            params.len(),
                            args.len(),
                            span,
                            DiagnosticOrigin::Call,
                        )),
                        message: format!("Duplicate argument '{}'", name),
                        span: span.clone(),
                        hint: None,
                    });
                }
                reordered[idx] = Some(expr);
            }

            let ordered = reordered
                .into_iter()
                .zip(names)
                .map(|(expr, name)| match expr {
                    Some(expr) => OrderedCallArgument::Present(expr),
                    None => OrderedCallArgument::Missing(name),
                })
                .collect::<Vec<_>>();
            return self.typecheck_ordered_call_args(
                span,
                callee_label,
                params,
                &ordered,
                callable_hint,
                CallArgumentMode::User {
                    defer_constructor_conflicts,
                    callee_uid,
                },
            );
        }

        if args.len() != params.len() {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    callee_label,
                    None,
                    params.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{} expects {} argument(s), got {}",
                    callee_label,
                    params.len(),
                    args.len()
                ),
                span: span.clone(),
                hint: callable_hint.map(str::to_string),
            });
        }

        let ordered = args
            .iter()
            .map(|arg| match arg {
                ResolvedRecordLitArg::Positional(expr) => OrderedCallArgument::Present(expr),
                ResolvedRecordLitArg::Named(_, _) => unreachable!("argument modes were validated"),
            })
            .collect::<Vec<_>>();
        self.typecheck_ordered_call_args(
            span,
            callee_label,
            params,
            &ordered,
            callable_hint,
            CallArgumentMode::User {
                defer_constructor_conflicts,
                callee_uid,
            },
        )
    }

    // Only direct unary FacetPath captures depend on a source supplied by the
    // surrounding call. Callable shape errors are checked immediately.
    fn pending_facet_capture_source(&self, expr: &Resolved, expected: &Ty) -> Option<Ty> {
        let segments = Self::facet_capture_segments(expr)?;
        let Ty::Func(params, _) = self.resolve_ty(expected) else {
            return None;
        };
        let [source] = params.as_slice() else {
            return None;
        };
        let root = Self::facet_capture_root(expr);
        if root.is_some_and(|root| Self::known_non_facet_root_name(root).is_some()) {
            return None;
        }
        if !matches!(source, Ty::Var(_) | Ty::Hole) {
            if let Some(root) = root {
                let valid_shape = match Self::facet_root_kind(root) {
                    Some(FacetRootKind::TypeRoot) => {
                        Self::facet_type_root_matches_source(root, source)
                    }
                    Some(FacetRootKind::Tuple) => matches!(source, Ty::Tuple(_)),
                    Some(FacetRootKind::List) => matches!(source, Ty::List(_)),
                    Some(FacetRootKind::HashMap) => matches!(source, Ty::Enum(name, args)
                        if Self::surface_name(name) == "HashMap" && args.len() == 1),
                    None => true,
                };
                if !valid_shape {
                    return None;
                }
            }
        }
        let mut receiver = source.clone();
        for (index, segment) in segments.iter().enumerate() {
            receiver = self.resolve_ty(&receiver);
            if matches!(&receiver, Ty::Var(var) if !self.rigid_tyvars.contains(var)) {
                return Some(receiver);
            }
            // The final focus need not be fixed: checking the capture against
            // its expected return type can determine it. Only receivers of
            // remaining segments require a known shape.
            if index + 1 == segments.len() {
                break;
            }
            receiver = self.facet_capture_dependency_focus(&receiver, segment)?;
        }
        None
    }

    fn facet_path_root(expr: &Resolved) -> &Resolved {
        match expr {
            Resolved::FieldAccess(_, inner, _)
            | Resolved::FacetSegmentAccess(_, inner, _)
            | Resolved::Grouped(_, inner) => Self::facet_path_root(inner),
            _ => expr,
        }
    }

    fn has_concrete_error_facet_root(&self, expr: &Resolved) -> bool {
        matches!(Self::facet_path_root(expr), Resolved::Var(_, root)
            if self.env.is_error_constructor(root.unique_id)
                || self.env.concrete_error_bindings.contains_key(&root.unique_id))
    }

    fn facet_capture_root(expr: &Resolved) -> Option<&Resolved> {
        match expr {
            Resolved::Grouped(_, inner) => Self::facet_capture_root(inner),
            Resolved::Capture(_, target, _) => Some(Self::facet_path_root(target)),
            _ => None,
        }
    }

    fn facet_capture_segments(expr: &Resolved) -> Option<Vec<ResolvedFacetPathSegment>> {
        fn path_segments(expr: &Resolved, segments: &mut Vec<ResolvedFacetPathSegment>) {
            match expr {
                Resolved::FieldAccess(_, inner, name) => {
                    path_segments(inner, segments);
                    segments.push(ResolvedFacetPathSegment::Field {
                        name: name.clone(),
                        optional: false,
                    });
                }
                Resolved::FacetSegmentAccess(_, inner, segment) => {
                    path_segments(inner, segments);
                    segments.push(segment.clone());
                }
                Resolved::Grouped(_, inner) => path_segments(inner, segments),
                _ => {}
            }
        }
        match expr {
            Resolved::Grouped(_, inner) => Self::facet_capture_segments(inner),
            Resolved::InferredFacetCapture(_, segments) => Some(segments.clone()),
            Resolved::Capture(_, target, args)
                if args.is_empty() && Self::capture_target_is_facet_path(target) =>
            {
                let mut segments = Vec::new();
                path_segments(target, &mut segments);
                Some(segments)
            }
            _ => None,
        }
    }

    // This reads dependencies only. Unsupported selectors return no dependency
    // and are diagnosed by the ordinary root/segment checker; no error is
    // caught and no candidate type or owner is inferred here.
    fn facet_capture_dependency_focus(
        &self,
        source: &Ty,
        segment: &ResolvedFacetPathSegment,
    ) -> Option<Ty> {
        match (source, segment) {
            (
                Ty::Tuple(items),
                ResolvedFacetPathSegment::Field {
                    name,
                    optional: false,
                },
            ) => items.get(Self::parse_tuple_index_name(name)?).cloned(),
            (
                Ty::Record(owner, fields) | Ty::Struct(owner, fields),
                ResolvedFacetPathSegment::Field {
                    name,
                    optional: false,
                },
            ) => {
                let (field_name, field_ty) = if matches!(source, Ty::Record(..)) {
                    if let Some(index) = Self::parse_tuple_index_name(name) {
                        fields.get(index)?
                    } else {
                        fields.iter().find(|(field, _)| field == name)?
                    }
                } else {
                    fields.iter().find(|(field, _)| field == name)?
                };
                if self
                    .env
                    .field_policy(owner, field_name)
                    .is_some_and(|policy| policy.private)
                    && self.current_private_field_owner.as_deref()
                        != Some(Self::surface_name(owner))
                    && !self.allow_private_facet_inspection
                {
                    return None;
                }
                Some(field_ty.clone())
            }
            (Ty::List(inner), ResolvedFacetPathSegment::Bracket(bracket)) => Some(
                if matches!(bracket.expr.as_ref(), Resolved::RangeLiteral(..)) {
                    source.clone()
                } else {
                    inner.as_ref().clone()
                },
            ),
            (Ty::Enum(name, args), ResolvedFacetPathSegment::Bracket(_))
                if Self::surface_name(name) == "HashMap" && args.len() == 1 =>
            {
                Some(args[0].clone())
            }
            (
                source,
                ResolvedFacetPathSegment::Field {
                    name,
                    optional: false,
                },
            ) => {
                let enum_name = Self::facet_enum_source_name(source)?;
                let variant = self.lookup_enum_variant_by_short_name(&enum_name, name)?;
                let (template_args, actual_args) = match (&variant.enum_ty, source) {
                    (Ty::Enum(_, template), Ty::Enum(_, actual)) => {
                        (template.clone(), actual.clone())
                    }
                    (Ty::Result(t_ok, t_err), Ty::Result(a_ok, a_err)) => (
                        vec![*t_ok.clone(), *t_err.clone()],
                        vec![*a_ok.clone(), *a_err.clone()],
                    ),
                    (Ty::Bool, Ty::Bool) => (Vec::new(), Vec::new()),
                    _ => return None,
                };
                let bindings = template_args
                    .iter()
                    .zip(actual_args)
                    .filter_map(|(template, actual)| {
                        if let Ty::Var(var) = template {
                            Some((*var, actual))
                        } else {
                            None
                        }
                    })
                    .collect::<HashMap<_, _>>();
                let payload = variant
                    .payload
                    .iter()
                    .map(|ty| self.substitute_type_def_ty(ty, &bindings))
                    .collect::<Vec<_>>();
                Some(match payload.as_slice() {
                    [] => Ty::Unit,
                    [only] => only.clone(),
                    _ => Ty::Tuple(payload),
                })
            }
            _ => None,
        }
    }

    fn typecheck_ordered_call_args(
        &mut self,
        span: &Span,
        callee_label: &str,
        params: &[Ty],
        args: &[OrderedCallArgument<'_>],
        callable_hint: Option<&str>,
        mode: CallArgumentMode,
    ) -> Result<Vec<TypedNode>, TypeError> {
        let mut typed_args = vec![None; params.len()];
        let mut remaining = params.len();
        loop {
            let before = remaining;
            let mut checked_this_pass = Vec::new();
            for (ordinal, (expected_ty, arg)) in params.iter().zip(args).enumerate() {
                if typed_args[ordinal].is_some() {
                    continue;
                }
                let expr = match arg {
                    OrderedCallArgument::Present(expr) => *expr,
                    OrderedCallArgument::Missing(name) => {
                        return Err(TypeError {
                            structured: Some(
                                self.argument_contract_diagnostic(
                                    TypeDiagnosticReason::MissingArgument,
                                    callee_label,
                                    Some(name),
                                    params.len(),
                                    args.iter()
                                        .filter(|arg| {
                                            matches!(arg, OrderedCallArgument::Present(_))
                                        })
                                        .count(),
                                    span,
                                    DiagnosticOrigin::Call,
                                ),
                            ),
                            message: format!("Missing argument '{}'", name),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                };
                if self
                    .pending_facet_capture_source(expr, expected_ty)
                    .is_some()
                {
                    continue;
                }
                let callback_inputs = if Self::has_contextual_callback_parameters(expr) {
                    self.callback_input_provenance(
                        params,
                        &typed_args,
                        ordinal,
                        self.resolved_span(expr),
                    )?
                } else {
                    Some(Vec::new())
                };
                let Some(callback_inputs) = callback_inputs else {
                    continue;
                };
                let lazy_parameter = match mode {
                    CallArgumentMode::User { callee_uid, .. } => self
                        .lazy_function_parameters
                        .get(&callee_uid)
                        .is_some_and(|positions| positions.contains(&ordinal)),
                    CallArgumentMode::Positional => false,
                };
                let (typed, defer) =
                    self.with_callback_parameter_provenance(expr, &callback_inputs, |checker| {
                        if lazy_parameter {
                            checker
                                .check_trait_lazy_argument(expr, expected_ty, span)
                                .map(|typed| (typed, false))
                        } else {
                            checker.check_ordered_call_argument(
                                expr,
                                expected_ty,
                                callee_label,
                                mode,
                            )
                        }
                    })?;
                if !defer {
                    if matches!(mode, CallArgumentMode::Positional) {
                        checked_this_pass.push(ordinal);
                    } else {
                        self.check_call_argument_relation(
                            span,
                            callee_label,
                            expected_ty,
                            &typed,
                            callable_hint,
                            ordinal,
                        )?;
                    }
                }
                typed_args[ordinal] = Some(typed);
                remaining -= 1;
            }
            // Function-value/positional calls historically check expressions
            // before relating their types. Preserve that diagnostic order while
            // making their constraints available to source-dependent captures.
            for ordinal in checked_this_pass {
                self.check_call_argument_relation(
                    span,
                    callee_label,
                    &params[ordinal],
                    typed_args[ordinal].as_ref().expect("argument was checked"),
                    callable_hint,
                    ordinal,
                )?;
            }
            if remaining == 0 {
                let typed_args = typed_args
                    .into_iter()
                    .map(|arg| arg.expect("all call arguments were checked"))
                    .collect::<Vec<_>>();
                self.check_callback_argument_provenance(params, &typed_args)?;
                return Ok(typed_args);
            }
            if remaining == before {
                let ordinal = typed_args
                    .iter()
                    .position(Option::is_none)
                    .expect("remaining call argument exists");
                let OrderedCallArgument::Present(expr) = args[ordinal] else {
                    unreachable!("missing arguments were rejected")
                };
                let Some(source) = self.pending_facet_capture_source(expr, &params[ordinal]) else {
                    return Err(self.unresolved_callback_provenance_error(self.resolved_span(expr)));
                };
                return Err(TypeError {
                    structured: None,
                    message: format!("FacetPath capture has unresolved source type: {}",
                        self.diagnostic_ty_name(&source)),
                    span: self.resolved_span(expr).clone(),
                    hint: Some("Provide the source type through another argument or a callable annotation.".into()),
                });
            }
        }
    }

    fn check_ordered_call_argument(
        &mut self,
        expr: &Resolved,
        expected_ty: &Ty,
        callee_label: &str,
        mode: CallArgumentMode,
    ) -> Result<(TypedNode, bool), TypeError> {
        Ok(match mode {
            CallArgumentMode::User {
                defer_constructor_conflicts,
                ..
            } => {
                let defer = defer_constructor_conflicts
                    && self.constructor_argument_needs_deferred_check(expected_ty);
                let typed = if defer {
                    self.check_node(expr)?
                } else {
                    self.check_node_with_expected(expr, Some(expected_ty))?
                };
                self.ensure_no_runtime_facet_value(&typed, "Function call arguments")?;
                self.check_expected_constructor_capability(expected_ty, callee_label, &typed)?;
                (typed, defer)
            }
            CallArgumentMode::Positional => (
                if matches!(self.resolve_ty(expected_ty), Ty::Hole) {
                    self.check_node(expr)?
                } else {
                    self.check_node_with_expected(expr, Some(expected_ty))?
                },
                false,
            ),
        })
    }

    fn check_call_argument_relation(
        &mut self,
        span: &Span,
        callee_label: &str,
        expected: &Ty,
        typed: &TypedNode,
        callable_hint: Option<&str>,
        ordinal: usize,
    ) -> Result<(), TypeError> {
        if matches!(self.resolve_ty(expected), Ty::Hole) {
            return Ok(());
        }
        self.assert_type_relation(
            expected,
            &typed.ty,
            self.type_fact(SourceRole::Expected, span, expected),
            self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
            TypeDiagnosticReason::ArgumentTypeMismatch,
            DiagnosticOrigin::Call,
            callee_label,
            ordinal as u32,
        )
        .map_err(|error| match callable_hint {
            Some(hint) => error.with_hint(hint),
            None => error,
        })
    }

    fn constructor_argument_needs_deferred_check(&self, expected_ty: &Ty) -> bool {
        let Ty::SelfApp(items) = expected_ty else {
            return false;
        };
        let Some((witness, _)) = Self::constructor_application_parts(items) else {
            return false;
        };
        let resolved = self.resolve_ty(witness);
        if matches!(&resolved, Ty::Var(variable) if !self.rigid_tyvars.contains(variable)) {
            return true;
        }
        let Ty::Var(variable) = witness else {
            return false;
        };
        if self.constructor_witness_traits.contains_key(variable) {
            if let Ok(canonical) = self.canonical_request(&resolved) {
                fn contains_inference_variable(ty: &CanonicalTy, rigid: &HashSet<u32>) -> bool {
                    matches!(ty.head, CanonicalTypeHead::Variable(variable) if !rigid.contains(&variable))
                        || ty
                            .arguments
                            .iter()
                            .any(|argument| contains_inference_variable(argument, rigid))
                }
                if contains_inference_variable(&canonical, &self.rigid_tyvars) {
                    return true;
                }
            }
        }
        self.constructor_witness_traits
            .get(variable)
            .and_then(|trait_key| {
                self.normalize_inferred_constructor_identity(trait_key, &resolved)
            })
            .is_some_and(|identity| identity != resolved)
    }

    fn facet_intrinsic_kind(&self, func: &Resolved) -> Option<&'static str> {
        let Resolved::Var(_, id) = func else {
            return None;
        };
        if let Some(qualified_name) = id.qualified_name.as_deref() {
            return match Self::surface_name(qualified_name) {
                "Facet::view" => Some("view"),
                "Facet::preview" => Some("preview"),
                "Facet::compose" => Some("compose"),
                "Facet::put" => Some("put"),
                "Facet::set" => Some("set"),
                "Facet::over" => Some("over"),
                "Facet::over_result" => Some("over_result"),
                "Facet::case_set" => Some("case_set"),
                "Facet::case_over" => Some("case_over"),
                _ => None,
            };
        }
        None
    }

    fn pending_segment_from_typed(segment: &TypedFacetSegment) -> PendingFacetSegment {
        Self::pending_field_segment(match segment {
            TypedFacetSegment::Field {
                origin_index: Some(index),
                ..
            } => format!("_{index}"),
            TypedFacetSegment::ReadonlyBuiltin { field_name, .. }
            | TypedFacetSegment::ErrorPayload { field_name, .. }
            | TypedFacetSegment::Field { field_name, .. } => field_name.clone(),
            TypedFacetSegment::Tuple { field_index, .. } => format!("_{field_index}"),
            TypedFacetSegment::Variant { variant_name, .. } => variant_name.clone(),
            TypedFacetSegment::ListIndex { index, display, .. } => {
                return PendingFacetSegment::Bracket {
                    expr: PendingFacetExpr::Typed(index.clone()),
                    display: display.clone(),
                };
            }
            TypedFacetSegment::ListRange {
                start,
                end,
                display,
                ..
            } => {
                return PendingFacetSegment::RangeBracket {
                    start: PendingFacetExpr::Typed(start.clone()),
                    end: PendingFacetExpr::Typed(end.clone()),
                    display: display.clone(),
                };
            }
            TypedFacetSegment::MapKey { key, display, .. } => {
                return PendingFacetSegment::Bracket {
                    expr: PendingFacetExpr::Typed(key.clone()),
                    display: display.clone(),
                };
            }
        })
    }

    fn facet_path_kind_for_segments(segments: &[TypedFacetSegment]) -> TypedFacetPathKind {
        if segments
            .iter()
            .any(|segment| matches!(segment, TypedFacetSegment::Variant { .. }))
        {
            TypedFacetPathKind::VariantPath
        } else if segments.iter().any(|segment| {
            matches!(
                segment,
                TypedFacetSegment::ListIndex { .. }
                    | TypedFacetSegment::ListRange { .. }
                    | TypedFacetSegment::MapKey { .. }
            )
        }) {
            TypedFacetPathKind::FallibleStructural
        } else {
            TypedFacetPathKind::InfallibleStructural
        }
    }

    fn facet_kind_from_path_kind(path_kind: TypedFacetPathKind) -> crate::types::FacetKind {
        match path_kind {
            TypedFacetPathKind::InfallibleStructural => {
                crate::types::FacetKind::InfallibleStructural
            }
            TypedFacetPathKind::FallibleStructural => crate::types::FacetKind::FallibleStructural,
            TypedFacetPathKind::VariantPath => crate::types::FacetKind::VariantPath,
        }
    }

    fn deferred_facet_ty(path_kind: TypedFacetPathKind, source: Ty, focus: Ty) -> Ty {
        Ty::Facet(
            Self::facet_kind_from_path_kind(path_kind),
            Box::new(source),
            Box::new(focus),
            Box::new(Ty::Hole),
            Box::new(Ty::Hole),
        )
    }

    fn pending_facet_node(&mut self, span: &Span, path: PendingFacetPath) -> TypedNode {
        let source_tv = self.env.fresh_tyvar();
        let focus_tv = self.env.fresh_tyvar();
        TypedNode {
            ty: Self::deferred_facet_ty(
                TypedFacetPathKind::InfallibleStructural,
                source_tv,
                focus_tv,
            ),
            span: span.clone(),
            node: TypedInner::PendingFacetPath(path),
        }
    }

    fn validate_pending_root_source(
        &mut self,
        root_path_name: &str,
        source_ty: &Ty,
        span: &Span,
    ) -> Result<(), TypeError> {
        match (root_path_name, self.resolve_ty(source_ty)) {
            ("Tuple", Ty::Tuple(_)) => Ok(()),
            ("List", Ty::List(_)) => Ok(()),
            ("HashMap", Ty::Enum(name, args))
                if Self::surface_name(&name) == "HashMap" && args.len() == 1 =>
            {
                Ok(())
            }
            ("Tuple", actual) => Err(TypeError {
                structured: None,
                message: format!(
                    "Tuple root Facet path requires tuple source context, got {}",
                    self.ty_name(&actual)
                ),
                span: span.clone(),
                hint: Some("Expected source type like (A, B, ...) for Tuple._N.".into()),
            }),
            ("List", actual) => Err(TypeError {
                structured: None,
                message: format!(
                    "List root Facet path requires List<T>, got {}",
                    self.ty_name(&actual)
                ),
                span: span.clone(),
                hint: Some("Use List.[N] with a List source value.".into()),
            }),
            ("HashMap", actual) => Err(TypeError {
                structured: None,
                message: format!(
                    "HashMap root Facet path requires HashMap<T>, got {}",
                    self.ty_name(&actual)
                ),
                span: span.clone(),
                hint: Some("Use HashMap.[\"key\"] with a HashMap source value.".into()),
            }),
            _ => Ok(()),
        }
    }

    fn specialize_pending_facet_path(
        &mut self,
        path: PendingFacetPath,
        span: &Span,
        expected_source: Option<&Ty>,
    ) -> Result<TypedFacetPath, TypeError> {
        let mut current_source = if let Some(source_ty_hint) = path.source_ty_hint.clone() {
            if let Some(expected_source) = expected_source {
                if !self.types_compatible(&source_ty_hint, expected_source)? {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Facet path source type mismatch: path expects {}, got {}",
                            self.ty_name(&source_ty_hint),
                            self.ty_name(expected_source)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
            }
            self.resolve_ty(&source_ty_hint)
        } else {
            let Some(expected_source) = expected_source else {
                return Err(TypeError {
                    structured: None,
                    message:
                        "Tuple._N requires Facet type context (e.g. Facet::view(Tuple._1, source_tuple))"
                            .into(),
                    span: span.clone(),
                    hint: Some(
                        "Use Tuple._N only where a Facet<K, (...), ..., T, B> is expected."
                            .into(),
                    ),
                });
            };
            self.resolve_ty(expected_source)
        };

        let source_ty = current_source.clone();
        if let Some(root_path_name) = &path.root_path_name {
            self.validate_pending_root_source(root_path_name, &source_ty, span)?;
        }
        let mut may_fail = false;
        let mut segments = Vec::with_capacity(path.segments.len());
        for pending_segment in path.segments {
            if let Ty::Result(ok, _) = self.resolve_ty(&current_source) {
                current_source = ok.as_ref().clone();
                may_fail = true;
            }
            let (segment, focus_ty, segment_may_fail) = self.resolve_facet_segment_for_source_ty(
                &current_source,
                &pending_segment,
                span,
                true,
            )?;
            segments.push(segment);
            current_source = self.resolve_ty(&focus_ty);
            may_fail |= segment_may_fail;
        }

        Ok(TypedFacetPath {
            source_ty: source_ty.clone(),
            focus_ty: current_source,
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: Self::facet_path_kind_for_segments(&segments),
            may_fail,
            segments,
        })
    }

    fn resolve_facet_path_from_node(
        &mut self,
        typed: TypedNode,
        span: &Span,
        expected_source: Option<&Ty>,
    ) -> Result<TypedFacetPath, TypeError> {
        let facet_ty = self.resolve_ty(&typed.ty);
        if !matches!(facet_ty, Ty::Facet(..)) {
            return Err(TypeError {
                structured: None,
                message: format!("Expected Facet<...> value, got {}", self.ty_name(&typed.ty)),
                span: typed.span.clone(),
                hint: None,
            });
        }
        let update_slots = match facet_ty {
            Ty::Facet(_, _, _, update_source, update_focus) => (
                update_source.as_ref().clone(),
                update_focus.as_ref().clone(),
            ),
            _ => unreachable!("Facet type checked above"),
        };
        match typed.node {
            TypedInner::FacetPath(path) => Ok(TypedFacetPath {
                source_ty: self.resolve_ty(&path.source_ty),
                focus_ty: self.resolve_ty(&path.focus_ty),
                update_source_ty: self.resolve_ty(&update_slots.0),
                update_focus_ty: self.resolve_ty(&update_slots.1),
                path_kind: path.path_kind,
                may_fail: path.may_fail,
                segments: path.segments,
            }),
            TypedInner::PendingFacetPath(path) => {
                self.specialize_pending_facet_path(path, span, expected_source)
            }
            _ => Err(self.policy_error(
                TypeDiagnosticReason::FacetCompileTimeOnly,
                diagnostics::TypePolicy::FacetStageRestriction,
                Some("Facet values are compile-time only in Stage1 and cannot be stored or passed around".into()),
                None,
                Some(&typed.ty),
                Some("Stage1".into()),
                None,
                span,
                Some("Use type-root path expressions inline (e.g. User.name).".into()),
            )),
        }
    }

    fn compose_facet_paths(
        &mut self,
        span: &Span,
        left_path: TypedFacetPath,
        right_expr: &Resolved,
        operator_name: &str,
    ) -> Result<TypedNode, TypeError> {
        self.ensure_deferred_facet_slots(operator_name, &left_path, span)?;
        let expected_right_focus = self.env.fresh_tyvar();
        let expected_right_ty = Ty::Facet(
            crate::types::FacetKind::ReadablePath,
            Box::new(self.resolve_ty(&left_path.focus_ty)),
            Box::new(expected_right_focus),
            Box::new(Ty::Hole),
            Box::new(Ty::Hole),
        );
        let right = self.check_node_with_expected(right_expr, Some(&expected_right_ty))?;
        let right_path =
            self.resolve_facet_path_from_node(right, span, Some(&left_path.focus_ty))?;
        self.ensure_deferred_facet_slots(operator_name, &right_path, span)?;

        if !self.types_compatible(&left_path.focus_ty, &right_path.source_ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} source/focus mismatch: left focus is {}, right source is {}",
                    operator_name,
                    self.ty_name(&left_path.focus_ty),
                    self.ty_name(&right_path.source_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let source_ty = self.resolve_ty(&left_path.source_ty);
        let focus_ty = self.resolve_ty(&right_path.focus_ty);
        let mut segments = left_path.segments;
        segments.extend(right_path.segments);
        let path = TypedFacetPath {
            source_ty: source_ty.clone(),
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: if left_path.path_kind == TypedFacetPathKind::VariantPath
                || right_path.path_kind == TypedFacetPathKind::VariantPath
            {
                TypedFacetPathKind::VariantPath
            } else if left_path.path_kind == TypedFacetPathKind::FallibleStructural
                || right_path.path_kind == TypedFacetPathKind::FallibleStructural
            {
                TypedFacetPathKind::FallibleStructural
            } else {
                TypedFacetPathKind::InfallibleStructural
            },
            may_fail: left_path.may_fail || right_path.may_fail,
            segments,
        };
        Ok(TypedNode {
            ty: Self::deferred_facet_ty(path.path_kind, source_ty, focus_ty),
            span: span.clone(),
            node: TypedInner::FacetPath(path),
        })
    }

    fn compose_pending_facet_paths(
        &mut self,
        span: &Span,
        mut left_path: PendingFacetPath,
        right_expr: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let right = self.check_node(right_expr)?;
        match right.node {
            TypedInner::FacetPath(path) => {
                left_path
                    .segments
                    .extend(path.segments.iter().map(Self::pending_segment_from_typed));
                Ok(self.pending_facet_node(span, left_path))
            }
            TypedInner::PendingFacetPath(path) => {
                left_path.segments.extend(path.segments);
                if left_path.root_path_name.is_none() {
                    left_path.root_path_name = path.root_path_name;
                }
                Ok(self.pending_facet_node(span, left_path))
            }
            _ => Err(self.policy_error(
                TypeDiagnosticReason::FacetCompileTimeOnly,
                diagnostics::TypePolicy::FacetStageRestriction,
                Some("Facet values are compile-time only in Stage1 and cannot be stored or passed around".into()),
                None,
                Some(&right.ty),
                Some("Stage1".into()),
                None,
                span,
                Some("Use type-root path expressions inline (e.g. User.name).".into()),
            )),
        }
    }

    fn check_facet_compose_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        if args.len() != 2 {
            return Err(TypeError {
                structured: None,
                message: format!("Facet::compose expects 2 argument(s), got {}", args.len()),
                span: span.clone(),
                hint: None,
            });
        }
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: None,
                message: "Facet::compose does not accept named arguments".into(),
                span: span.clone(),
                hint: None,
            });
        }

        let ResolvedRecordLitArg::Positional(left_expr) = &args[0] else {
            unreachable!("validated argument form above")
        };
        let ResolvedRecordLitArg::Positional(right_expr) = &args[1] else {
            unreachable!("validated argument form above")
        };

        if let Resolved::FacetCapture(capture_span, expr) = left_expr {
            let (source_expr, pending_path) =
                self.expand_facet_capture_path("Facet::compose", capture_span, expr)?;
            let (_, _, source_value_ty) =
                self.check_facet_source_value("Facet::compose", &source_expr)?;
            let left_path =
                self.specialize_pending_facet_path(pending_path, span, Some(&source_value_ty))?;
            return self.compose_facet_paths(span, left_path, right_expr, "Facet::compose");
        }

        let left = self.check_node(left_expr)?;
        match left.node {
            TypedInner::FacetPath(path) => {
                self.compose_facet_paths(span, path, right_expr, "Facet::compose")
            }
            TypedInner::PendingFacetPath(path) => {
                self.compose_pending_facet_paths(span, path, right_expr)
            }
            _ => Err(TypeError {
                structured: None,
                message: format!("Expected Facet<...> value, got {}", self.ty_name(&left.ty)),
                span: left.span.clone(),
                hint: None,
            }),
        }
    }

    fn check_facet_source_value(
        &mut self,
        op_name: &str,
        source_expr: &Resolved,
    ) -> Result<(TypedNode, bool, Ty), TypeError> {
        let typed_source = self.check_node(source_expr)?;
        if matches!(typed_source.ty, Ty::Facet(..)) {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some(format!("{} source value cannot be a Facet", op_name)),
                None,
                Some(&typed_source.ty),
                None,
                None,
                &typed_source.span,
                None,
            ));
        }

        let (source_is_result, source_value_ty) = match self.resolve_ty(&typed_source.ty) {
            Ty::Result(ok, _) => (true, ok.as_ref().clone()),
            other => (false, other),
        };

        Ok((typed_source, source_is_result, source_value_ty))
    }

    fn expand_facet_capture_path(
        &self,
        op_name: &str,
        span: &Span,
        expr: &Resolved,
    ) -> Result<(Resolved, PendingFacetPath), TypeError> {
        let mut segments = Vec::new();
        let mut current = expr.clone();
        loop {
            match current {
                Resolved::FieldAccess(_, inner, field) => {
                    segments.push(Self::pending_field_segment(field));
                    current = *inner;
                }
                Resolved::FacetSegmentAccess(_, inner, segment) => {
                    segments.push(Self::pending_segment_from_syntax(&segment));
                    current = *inner;
                }
                Resolved::Grouped(_, inner) => {
                    current = *inner;
                }
                _ => break,
            }
        }
        if self.has_concrete_error_facet_root(&current) {
            return Err(TypeError::new(
                "Concrete Error Facet paths cannot be captured",
                span.clone(),
            ));
        }
        if segments.is_empty() {
            return Err(TypeError {
                structured: None,
                message: format!("{op_name} shorthand requires a field or tuple path").into(),
                span: span.clone(),
                hint: Some(
                    "Write `~source.field` or `~source._0`. Use canonical `Facet::compose(...)` or a type-root path when you need a standalone Facet path."
                        .into(),
                ),
            });
        }
        segments.reverse();
        Ok((
            current,
            PendingFacetPath {
                root_path_name: None,
                source_ty_hint: None,
                segments,
            },
        ))
    }

    fn check_facet_path_input(
        &mut self,
        span: &Span,
        op_name: &str,
        path_input: FacetPathInput<'_>,
        source_value_ty: &Ty,
        source_input_ty: &Ty,
    ) -> Result<TypedFacetPath, TypeError> {
        match path_input {
            FacetPathInput::Expr(path_expr) => self.check_facet_path_argument(
                span,
                op_name,
                path_expr,
                source_value_ty,
                source_input_ty,
            ),
            FacetPathInput::Capture(path) => {
                let path = self.specialize_pending_facet_path(path, span, Some(source_value_ty))?;
                if !self.types_compatible(&path.source_ty, source_value_ty)? {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "{} source type mismatch: facet expects {}, got {}",
                            op_name,
                            self.ty_name(&path.source_ty),
                            self.ty_name(source_input_ty)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                Ok(path)
            }
        }
    }

    fn check_facet_path_argument(
        &mut self,
        span: &Span,
        op_name: &str,
        path_expr: &Resolved,
        source_value_ty: &Ty,
        source_input_ty: &Ty,
    ) -> Result<TypedFacetPath, TypeError> {
        let expected_focus_ty = self.env.fresh_tyvar();
        let expected_path_ty = Ty::Facet(
            crate::types::FacetKind::ReadablePath,
            Box::new(self.resolve_ty(source_value_ty)),
            Box::new(expected_focus_ty),
            Box::new(Ty::Hole),
            Box::new(Ty::Hole),
        );
        // view can obtain its plain source from a concrete path. An unresolved
        // source is not an authored owner constraint; containers still require
        // receiver structure from the ordinary expected/call context.
        let path_expected =
            if op_name == "Facet::view" && matches!(self.resolve_ty(source_value_ty), Ty::Var(_)) {
                None
            } else {
                Some(&expected_path_ty)
            };
        let path_node = self.check_node_with_expected(path_expr, path_expected)?;
        let path = self.resolve_facet_path_from_node(path_node, span, Some(source_value_ty))?;

        if !self.types_compatible(&path.source_ty, source_value_ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} source type mismatch: facet expects {}, got {}",
                    op_name,
                    self.ty_name(&path.source_ty),
                    self.ty_name(source_input_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        Ok(path)
    }

    fn parse_facet_read_intrinsic_args<'a>(
        &self,
        span: &Span,
        op_name: &str,
        args: &'a [ResolvedRecordLitArg],
    ) -> Result<(Resolved, FacetPathInput<'a>), TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: None,
                message: format!("{op_name} does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if args.len() != 1 && args.len() != 2 {
            return Err(TypeError {
                structured: None,
                message: format!("{op_name} expects 1 or 2 argument(s), got {}", args.len()),
                span: span.clone(),
                hint: None,
            });
        }

        match args {
            [ResolvedRecordLitArg::Positional(Resolved::FacetCapture(capture_span, expr))] => {
                let (source_expr, path) =
                    self.expand_facet_capture_path(op_name, capture_span, expr)?;
                Ok((source_expr, FacetPathInput::Capture(path)))
            }
            [ResolvedRecordLitArg::Positional(path_expr), ResolvedRecordLitArg::Positional(source_expr)] => {
                Ok((source_expr.clone(), FacetPathInput::Expr(path_expr)))
            }
            _ => unreachable!("validated argument form above"),
        }
    }

    fn parse_facet_mutating_intrinsic_args<'a>(
        &self,
        span: &Span,
        op_name: &str,
        args: &'a [ResolvedRecordLitArg],
    ) -> Result<(Resolved, FacetPathInput<'a>, &'a Resolved), TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: None,
                message: format!("{op_name} does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if args.len() != 2 && args.len() != 3 {
            return Err(TypeError {
                structured: None,
                message: format!("{op_name} expects 2 or 3 argument(s), got {}", args.len()),
                span: span.clone(),
                hint: None,
            });
        }

        match args {
            [ResolvedRecordLitArg::Positional(Resolved::FacetCapture(capture_span, expr)), ResolvedRecordLitArg::Positional(value_expr)] =>
            {
                let (source_expr, path) =
                    self.expand_facet_capture_path(op_name, capture_span, expr)?;
                Ok((source_expr, FacetPathInput::Capture(path), value_expr))
            }
            [ResolvedRecordLitArg::Positional(path_expr), ResolvedRecordLitArg::Positional(source_expr), ResolvedRecordLitArg::Positional(value_expr)] => {
                Ok((
                    source_expr.clone(),
                    FacetPathInput::Expr(path_expr),
                    value_expr,
                ))
            }
            _ => unreachable!("validated argument form above"),
        }
    }

    fn prepare_facet_input(
        &mut self,
        span: &Span,
        op_name: &str,
        source_expr: &Resolved,
        path_input: FacetPathInput<'_>,
    ) -> Result<PreparedFacetInput, TypeError> {
        // Common fields normalize to an Error path, so check the resolved root first.
        if self.is_capture_closure
            && matches!(&path_input, FacetPathInput::Expr(expr)
                if self.has_concrete_error_facet_root(expr))
        {
            return Err(TypeError::new(
                "Concrete Error Facet paths cannot be captured",
                span.clone(),
            ));
        }
        let (typed_source, source_is_result, source_value_ty) =
            self.check_facet_source_value(op_name, source_expr)?;
        let path = self.check_facet_path_input(
            span,
            op_name,
            path_input,
            &source_value_ty,
            &typed_source.ty,
        )?;
        if self.is_capture_closure
            && path
                .segments
                .iter()
                .any(|segment| matches!(segment, TypedFacetSegment::ErrorPayload { .. }))
        {
            return Err(TypeError::new(
                "Concrete Error Facet paths cannot be captured",
                span.clone(),
            ));
        }
        for (index, segment) in path.segments.iter().enumerate() {
            if let TypedFacetSegment::ErrorPayload { kind, .. } = segment {
                if index != 0
                    || self.resolved_concrete_error_identity(source_expr) != Some(kind.as_str())
                {
                    return Err(TypeError::new(
                        "Concrete Error Payload Facet requires a matching narrowed local binding",
                        span.clone(),
                    ));
                }
            }
        }
        Ok(PreparedFacetInput {
            typed_source,
            source_is_result,
            path,
        })
    }

    fn ensure_deferred_facet_slots(
        &self,
        op_name: &str,
        path: &TypedFacetPath,
        span: &Span,
    ) -> Result<(), TypeError> {
        if matches!(
            (&path.update_source_ty, &path.update_focus_ty),
            (Ty::Hole, Ty::Hole)
        ) {
            return Ok(());
        }
        Err(TypeError {
            structured: None,
            message: format!("{op_name} requires a Facet with deferred update slots `_, _`"),
            span: span.clone(),
            hint: Some("Use a deferred Facet path for read-only consumption.".into()),
        })
    }

    fn rebuild_facet_source_type(
        &mut self,
        source_ty: &Ty,
        segments: &[TypedFacetSegment],
        replacement_ty: &Ty,
        span: &Span,
    ) -> Result<Ty, TypeError> {
        if segments.is_empty() {
            return Ok(self.resolve_ty(replacement_ty));
        }

        let source_ty = self.resolve_ty(source_ty);
        // Result values encountered *inside* a path are transparent to
        // traversal, but remain part of the rebuilt source shape.
        if let Ty::Result(ok, err) = source_ty {
            return Ok(Ty::Result(
                Box::new(self.rebuild_facet_source_type(&ok, segments, replacement_ty, span)?),
                err,
            ));
        }

        let segment = &segments[0];
        let rest = &segments[1..];
        match (source_ty, segment) {
            (Ty::Tuple(mut items), TypedFacetSegment::Tuple { field_index, .. }) => {
                let index = *field_index as usize;
                let Some(field_ty) = items.get(index).cloned() else {
                    return Err(TypeError {
                        structured: None,
                        message: "Facet tuple path is inconsistent with its source type".into(),
                        span: span.clone(),
                        hint: None,
                    });
                };
                items[index] =
                    self.rebuild_facet_source_type(&field_ty, rest, replacement_ty, span)?;
                Ok(Ty::Tuple(items))
            }
            (Ty::Struct(name, mut fields), TypedFacetSegment::Field { field_index, .. }) => {
                let index = *field_index as usize;
                let Some((_, field_ty)) = fields.get(index).cloned() else {
                    return Err(TypeError {
                        structured: None,
                        message: "Facet field path is inconsistent with its source type".into(),
                        span: span.clone(),
                        hint: None,
                    });
                };
                let rebuilt_field =
                    self.rebuild_facet_source_type(&field_ty, rest, replacement_ty, span)?;
                self.ensure_named_facet_rebuild_is_unique(
                    &name,
                    index,
                    &fields.arguments,
                    &field_ty,
                    &rebuilt_field,
                    span,
                )?;
                fields.arguments = self.rebuild_named_facet_arguments(
                    &name,
                    index,
                    &fields.arguments,
                    &rebuilt_field,
                    span,
                )?;
                fields[index].1 = rebuilt_field;
                Ok(Ty::Struct(name, fields))
            }
            (Ty::Record(name, mut fields), TypedFacetSegment::Field { field_index, .. }) => {
                let index = *field_index as usize;
                let Some((_, field_ty)) = fields.get(index).cloned() else {
                    return Err(TypeError {
                        structured: None,
                        message: "Facet field path is inconsistent with its source type".into(),
                        span: span.clone(),
                        hint: None,
                    });
                };
                let rebuilt_field =
                    self.rebuild_facet_source_type(&field_ty, rest, replacement_ty, span)?;
                self.ensure_named_facet_rebuild_is_unique(
                    &name,
                    index,
                    &fields.arguments,
                    &field_ty,
                    &rebuilt_field,
                    span,
                )?;
                fields.arguments = self.rebuild_named_facet_arguments(
                    &name,
                    index,
                    &fields.arguments,
                    &rebuilt_field,
                    span,
                )?;
                fields[index].1 = rebuilt_field;
                Ok(Ty::Record(name, fields))
            }
            (Ty::List(inner), TypedFacetSegment::ListIndex { .. }) => {
                let rebuilt = self.rebuild_facet_source_type(&inner, rest, replacement_ty, span)?;
                if !self.types_compatible(&inner, &rebuilt)? {
                    return Err(TypeError {
                        structured: None,
                        message:
                            "Facet updates through List segments cannot change the element type"
                                .into(),
                        span: span.clone(),
                        hint: Some("Replace with the existing list element type.".into()),
                    });
                }
                Ok(Ty::List(inner))
            }
            (Ty::List(inner), TypedFacetSegment::ListRange { .. }) => {
                let expected = Ty::List(inner.clone());
                let rebuilt =
                    self.rebuild_facet_source_type(&expected, rest, replacement_ty, span)?;
                if !self.types_compatible(&expected, &rebuilt)? {
                    return Err(TypeError {
                        structured: None,
                        message:
                            "Facet updates through List segments cannot change the element type"
                                .into(),
                        span: span.clone(),
                        hint: Some("Replace with the existing list element type.".into()),
                    });
                }
                Ok(Ty::List(inner))
            }
            (Ty::Enum(name, args), TypedFacetSegment::MapKey { .. })
                if Self::surface_name(&name) == "HashMap" && args.len() == 1 =>
            {
                let value_ty = args[0].clone();
                let rebuilt =
                    self.rebuild_facet_source_type(&value_ty, rest, replacement_ty, span)?;
                if !self.types_compatible(&value_ty, &rebuilt)? {
                    return Err(TypeError {
                        structured: None,
                        message:
                            "Facet updates through HashMap segments cannot change the value type"
                                .into(),
                        span: span.clone(),
                        hint: Some("Replace with the existing HashMap value type.".into()),
                    });
                }
                Ok(Ty::Enum(name, args))
            }
            (
                source,
                TypedFacetSegment::Variant {
                    enum_name,
                    variant_name,
                    ..
                },
            ) => {
                let variant = self
                    .lookup_enum_variant_by_short_name(enum_name, variant_name)
                    .map(|variant| self.instantiate_enum_variant(&variant))
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: "Facet enum path is inconsistent with its source type".into(),
                        span: span.clone(),
                        hint: None,
                    })?;
                let enum_template = variant.enum_ty.clone();
                if !self.types_compatible(&variant.enum_ty, &source)? {
                    return Err(TypeError {
                        structured: None,
                        message: "Facet enum path is inconsistent with its source type".into(),
                        span: span.clone(),
                        hint: None,
                    });
                }
                let payload_template = match variant.payload.as_slice() {
                    [] => Ty::Unit,
                    [only] => only.clone(),
                    payload => Ty::Tuple(payload.to_vec()),
                };
                let original = self.resolve_ty(&payload_template);
                let focus =
                    self.rebuild_facet_source_type(&original, rest, replacement_ty, span)?;
                if self.resolve_ty(&original) == self.resolve_ty(&focus) {
                    return Ok(source);
                }
                let mut replacements = HashMap::new();
                self.collect_facet_rebuild_tyvar_replacements(
                    &payload_template,
                    &focus,
                    &mut replacements,
                    span,
                )?;
                self.ensure_enum_facet_rebuild_is_unique(
                    enum_name,
                    &enum_template,
                    &replacements,
                    span,
                )?;
                Ok(self.replace_facet_rebuild_tyvars(&enum_template, &replacements))
            }
            _ => Err(TypeError {
                structured: None,
                message: "Facet path is inconsistent with its source type".into(),
                span: span.clone(),
                hint: None,
            }),
        }
    }

    fn count_tyvar_occurrences(&self, ty: &Ty, needle: u32) -> usize {
        match ty {
            Ty::Var(var) => usize::from(*var == needle),
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => self.count_tyvar_occurrences(inner, needle),
            Ty::Tuple(items) | Ty::SelfApp(items) => items
                .iter()
                .map(|item| self.count_tyvar_occurrences(item, needle))
                .sum(),
            Ty::Func(params, ret) => {
                params
                    .iter()
                    .map(|param| self.count_tyvar_occurrences(param, needle))
                    .sum::<usize>()
                    + self.count_tyvar_occurrences(ret, needle)
            }
            Ty::Facet(_, source, focus, update_source, update_focus) => {
                self.count_tyvar_occurrences(source, needle)
                    + self.count_tyvar_occurrences(focus, needle)
                    + self.count_tyvar_occurrences(update_source, needle)
                    + self.count_tyvar_occurrences(update_focus, needle)
            }
            Ty::Result(ok, err) => {
                self.count_tyvar_occurrences(ok, needle) + self.count_tyvar_occurrences(err, needle)
            }
            Ty::Enum(_, args) => args
                .iter()
                .map(|arg| self.count_tyvar_occurrences(arg, needle))
                .sum(),
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => nominal
                .arguments
                .iter()
                .map(|argument| self.count_tyvar_occurrences(argument, needle))
                .sum(),
            Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                params
                    .iter()
                    .map(|param| self.count_tyvar_occurrences(param, needle))
                    .sum::<usize>()
                    + self.count_tyvar_occurrences(ret, needle)
            }
            Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::Hole
            | Ty::ProcessMarker(_) => 0,
        }
    }

    fn collect_facet_rebuild_tyvar_replacements(
        &mut self,
        template: &Ty,
        replacement: &Ty,
        replacements: &mut HashMap<u32, Ty>,
        span: &Span,
    ) -> Result<(), TypeError> {
        if self.resolve_ty(template) == self.resolve_ty(replacement) {
            return Ok(());
        }
        match (template, replacement) {
            (Ty::Var(var), _) => {
                let replacement = self.resolve_ty(replacement);
                if let Some(existing) = replacements.get(var) {
                    if self.resolve_ty(existing) != replacement {
                        return Err(TypeError {
                            structured: None,
                            message: "Facet enum case update would assign incompatible types to the same generic parameter".into(),
                            span: span.clone(),
                            hint: Some("A type-changing enum case update must determine each generic parameter exactly once.".into()),
                        });
                    }
                } else {
                    replacements.insert(*var, replacement);
                }
                Ok(())
            }
            (Ty::MatchResult(template), Ty::MatchResult(replacement))
            | (Ty::ExtractorClosure(template), Ty::ExtractorClosure(replacement))
            | (Ty::List(template), Ty::List(replacement))
            | (Ty::Lazy(template), Ty::Lazy(replacement))
            | (Ty::Pid(template), Ty::Pid(replacement)) => self
                .collect_facet_rebuild_tyvar_replacements(
                    template,
                    replacement,
                    replacements,
                    span,
                ),
            (Ty::Tuple(templates), Ty::Tuple(replacements_ty))
            | (Ty::Enum(_, templates), Ty::Enum(_, replacements_ty)) => {
                if templates.len() != replacements_ty.len() {
                    return self.facet_rebuild_not_generic_error(span);
                }
                for (template, replacement) in templates.iter().zip(replacements_ty) {
                    self.collect_facet_rebuild_tyvar_replacements(
                        template,
                        replacement,
                        replacements,
                        span,
                    )?;
                }
                Ok(())
            }
            (
                Ty::Struct(template_name, template_fields),
                Ty::Struct(replacement_name, replacement_fields),
            )
            | (
                Ty::Record(template_name, template_fields),
                Ty::Record(replacement_name, replacement_fields),
            ) if template_name == replacement_name
                && template_fields.arguments.len() == replacement_fields.arguments.len() =>
            {
                for (template, replacement) in template_fields
                    .arguments
                    .iter()
                    .zip(&replacement_fields.arguments)
                {
                    self.collect_facet_rebuild_tyvar_replacements(
                        template,
                        replacement,
                        replacements,
                        span,
                    )?;
                }
                Ok(())
            }
            (
                Ty::Result(template_ok, template_err),
                Ty::Result(replacement_ok, replacement_err),
            ) => {
                self.collect_facet_rebuild_tyvar_replacements(
                    template_ok,
                    replacement_ok,
                    replacements,
                    span,
                )?;
                self.collect_facet_rebuild_tyvar_replacements(
                    template_err,
                    replacement_err,
                    replacements,
                    span,
                )
            }
            (Ty::SelfApp(template_items), replacement) => {
                let Some((template_witness, template_slots)) =
                    Self::constructor_application_parts(template_items)
                else {
                    return self.facet_rebuild_not_generic_error(span);
                };
                let resolved_replacement = self.resolve_ty(replacement);
                let replacement_slots = match &resolved_replacement {
                    Ty::SelfApp(replacement_items) => {
                        let Some((replacement_witness, replacement_slots)) =
                            Self::constructor_application_parts(replacement_items)
                        else {
                            return self.facet_rebuild_not_generic_error(span);
                        };
                        if self.resolve_ty(template_witness) != self.resolve_ty(replacement_witness)
                        {
                            return self.facet_rebuild_not_generic_error(span);
                        }
                        replacement_slots.to_vec()
                    }
                    _ => match self
                        .constructor_application_slots_for_witness(
                            template_witness,
                            template_slots.len(),
                            &resolved_replacement,
                        )
                        .into_checked()
                        .map_err(|error| error.at_span(span))?
                    {
                        ConstructorSlotsOutcome::Projected(slots) => slots,
                        ConstructorSlotsOutcome::Deferred { .. }
                        | ConstructorSlotsOutcome::Rejected { .. } => {
                            return self.facet_rebuild_not_generic_error(span);
                        }
                    },
                };
                if template_slots.len() != replacement_slots.len() {
                    return self.facet_rebuild_not_generic_error(span);
                }
                for (template_slot, replacement_slot) in
                    template_slots.iter().zip(&replacement_slots)
                {
                    self.collect_facet_rebuild_tyvar_replacements(
                        template_slot,
                        replacement_slot,
                        replacements,
                        span,
                    )?;
                }
                Ok(())
            }
            _ => self.facet_rebuild_not_generic_error(span),
        }
    }

    fn rebuild_named_facet_arguments(
        &mut self,
        type_name: &str,
        field_index: usize,
        arguments: &[Ty],
        rebuilt_field: &Ty,
        span: &Span,
    ) -> Result<Vec<Ty>, TypeError> {
        let Some(def) = self.env.lookup_type_def(type_name).cloned() else {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet cannot derive a rebuilt type for {}",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: None,
            });
        };
        if def.type_param_vars.is_empty() {
            return Ok(arguments.to_vec());
        }
        if arguments.len() != def.type_param_vars.len() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet found inconsistent generic metadata for {}",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: Some(
                    "The nominal type argument list must match its declaration parameters.".into(),
                ),
            });
        }
        let Some((_, field_template)) = def.fields.get(field_index) else {
            return Err(TypeError {
                structured: None,
                message: "Facet field path is inconsistent with its source type".into(),
                span: span.clone(),
                hint: None,
            });
        };
        let type_param_vars = def.type_param_vars.clone();
        let field_template = field_template.clone();
        let mut replacements = HashMap::new();
        self.collect_facet_rebuild_tyvar_replacements(
            &field_template,
            rebuilt_field,
            &mut replacements,
            span,
        )?;
        let rebuilt_arguments = type_param_vars
            .iter()
            .zip(arguments)
            .map(|(variable, argument)| {
                replacements
                    .get(variable)
                    .cloned()
                    .unwrap_or_else(|| argument.clone())
            })
            .collect::<Vec<_>>();
        let rebuilt_fields = self.instantiate_type_def_fields(&def, &rebuilt_arguments);
        let Some((_, expected_field)) = rebuilt_fields.get(field_index) else {
            return Err(TypeError {
                structured: None,
                message: "Facet field path is inconsistent with its rebuilt source type".into(),
                span: span.clone(),
                hint: None,
            });
        };
        if !self.types_compatible(expected_field, rebuilt_field)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet replacement changes the constructor family of {}",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: Some(
                    "A type-changing Facet update must preserve constructor parameters and may only rebuild uniquely determined payload parameters."
                        .into(),
                ),
            });
        }
        Ok(rebuilt_arguments)
    }

    fn facet_rebuild_not_generic_error(&self, span: &Span) -> Result<(), TypeError> {
        Err(TypeError {
            structured: None,
            message: "Facet cannot change this enum case payload because it does not map to a generic parameter".into(),
            span: span.clone(),
            hint: Some("Only uniquely rebuildable generic enum cases support a type-changing Facet update.".into()),
        })
    }

    fn ensure_enum_facet_rebuild_is_unique(
        &self,
        enum_name: &str,
        enum_template: &Ty,
        replacements: &HashMap<u32, Ty>,
        span: &Span,
    ) -> Result<(), TypeError> {
        let enum_args = match enum_template {
            Ty::Enum(_, args) => args.iter().collect::<Vec<_>>(),
            Ty::Result(ok, _) => vec![ok.as_ref()],
            _ => return self.facet_rebuild_not_generic_error(span),
        };
        let variants = self
            .lookup_enum_variants_of(enum_name)
            .ok_or_else(|| TypeError {
                structured: None,
                message: "Facet enum path is inconsistent with its source type".into(),
                span: span.clone(),
                hint: None,
            })?;
        for changed_var in replacements.keys() {
            let Some(index) = enum_args
                .iter()
                .position(|arg| matches!(arg, Ty::Var(var) if *var == *changed_var))
            else {
                return self.facet_rebuild_not_generic_error(span);
            };
            let Some(original_var) = variants
                .first()
                .and_then(|variant| match &variant.enum_ty {
                    Ty::Enum(_, args) => args.get(index),
                    Ty::Result(ok, _) if index == 0 => Some(ok.as_ref()),
                    _ => None,
                })
                .and_then(|arg| match arg {
                    Ty::Var(var) => Some(*var),
                    _ => None,
                })
            else {
                return self.facet_rebuild_not_generic_error(span);
            };
            let occurrences = variants
                .iter()
                .flat_map(|variant| variant.payload.iter())
                .map(|payload| self.count_tyvar_occurrences(payload, original_var))
                .sum::<usize>();
            if occurrences != 1 {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Facet cannot rebuild {} because a generic parameter occurs outside the updated case payload",
                        Self::surface_name(enum_name)
                    ),
                    span: span.clone(),
                    hint: Some("A type-changing enum case update must determine each generic parameter uniquely.".into()),
                });
            }
        }
        Ok(())
    }

    fn replace_facet_rebuild_tyvars(&self, ty: &Ty, replacements: &HashMap<u32, Ty>) -> Ty {
        match ty {
            Ty::Var(var) => replacements
                .get(var)
                .cloned()
                .unwrap_or_else(|| self.resolve_ty(ty)),
            Ty::ExtractorClosure(inner) => Ty::ExtractorClosure(Box::new(
                self.replace_facet_rebuild_tyvars(inner, replacements),
            )),
            Ty::MatchResult(inner) => Ty::MatchResult(Box::new(
                self.replace_facet_rebuild_tyvars(inner, replacements),
            )),
            Ty::List(inner) => Ty::List(Box::new(
                self.replace_facet_rebuild_tyvars(inner, replacements),
            )),
            Ty::Lazy(inner) => Ty::Lazy(Box::new(
                self.replace_facet_rebuild_tyvars(inner, replacements),
            )),
            Ty::Pid(inner) => Ty::Pid(Box::new(
                self.replace_facet_rebuild_tyvars(inner, replacements),
            )),
            Ty::Tuple(items) => Ty::Tuple(
                items
                    .iter()
                    .map(|item| self.replace_facet_rebuild_tyvars(item, replacements))
                    .collect(),
            ),
            Ty::SelfApp(items) => Ty::SelfApp(
                items
                    .iter()
                    .map(|item| self.replace_facet_rebuild_tyvars(item, replacements))
                    .collect(),
            ),
            Ty::Func(params, ret) => Ty::Func(
                params
                    .iter()
                    .map(|param| self.replace_facet_rebuild_tyvars(param, replacements))
                    .collect(),
                Box::new(self.replace_facet_rebuild_tyvars(ret, replacements)),
            ),
            Ty::Facet(kind, source, focus, update_source, update_focus) => Ty::Facet(
                kind.clone(),
                Box::new(self.replace_facet_rebuild_tyvars(source, replacements)),
                Box::new(self.replace_facet_rebuild_tyvars(focus, replacements)),
                Box::new(self.replace_facet_rebuild_tyvars(update_source, replacements)),
                Box::new(self.replace_facet_rebuild_tyvars(update_focus, replacements)),
            ),
            Ty::Result(ok, err) => Ty::Result(
                Box::new(self.replace_facet_rebuild_tyvars(ok, replacements)),
                Box::new(self.replace_facet_rebuild_tyvars(err, replacements)),
            ),
            Ty::Enum(name, args) => Ty::Enum(
                name.clone(),
                args.iter()
                    .map(|arg| self.replace_facet_rebuild_tyvars(arg, replacements))
                    .collect(),
            ),
            Ty::Struct(name, fields) => Ty::Struct(
                name.clone(),
                fields.map_types(|ty| self.replace_facet_rebuild_tyvars(ty, replacements)),
            ),
            Ty::Record(name, fields) => Ty::Record(
                name.clone(),
                fields.map_types(|ty| self.replace_facet_rebuild_tyvars(ty, replacements)),
            ),
            Ty::BuiltinFunc { name, params, ret } => Ty::BuiltinFunc {
                name: name.clone(),
                params: params
                    .iter()
                    .map(|param| self.replace_facet_rebuild_tyvars(param, replacements))
                    .collect(),
                ret: Box::new(self.replace_facet_rebuild_tyvars(ret, replacements)),
            },
            Ty::UserFunc {
                fun_idx,
                type_params,
                call_substitution,
                params,
                ret,
            } => Ty::UserFunc {
                fun_idx: *fun_idx,
                type_params: type_params.clone(),
                call_substitution: call_substitution
                    .iter()
                    .map(|(var, ty)| (*var, self.replace_facet_rebuild_tyvars(ty, replacements)))
                    .collect(),
                params: params
                    .iter()
                    .map(|param| self.replace_facet_rebuild_tyvars(param, replacements))
                    .collect(),
                ret: Box::new(self.replace_facet_rebuild_tyvars(ret, replacements)),
            },
            _ => ty.clone(),
        }
    }

    fn ensure_named_facet_rebuild_is_unique(
        &mut self,
        type_name: &str,
        field_index: usize,
        arguments: &[Ty],
        before: &Ty,
        after: &Ty,
        span: &Span,
    ) -> Result<(), TypeError> {
        if self.resolve_ty(before) == self.resolve_ty(after) {
            return Ok(());
        }
        let Some(def) = self.env.lookup_type_def(type_name).cloned() else {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet cannot derive a rebuilt type for {}",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: None,
            });
        };
        // Concrete named records remain structurally rebuildable.  The
        // uniqueness constraint matters when a declaration-level generic
        // parameter would need a new instantiation.
        if def.type_param_vars.is_empty() {
            return Ok(());
        }
        if arguments.len() != def.type_param_vars.len() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet found inconsistent generic metadata for {}",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: Some(
                    "The nominal type argument list must match its declaration parameters.".into(),
                ),
            });
        }
        let Some((_, selected_template)) = def.fields.get(field_index) else {
            return Err(TypeError {
                structured: None,
                message: "Facet field path is inconsistent with its source type".into(),
                span: span.clone(),
                hint: None,
            });
        };
        let mut after_replacements = HashMap::new();
        self.collect_facet_rebuild_tyvar_replacements(
            selected_template,
            after,
            &mut after_replacements,
            span,
        )?;
        let changed_vars = def
            .type_param_vars
            .iter()
            .zip(arguments)
            .filter_map(|(var, current)| match after_replacements.get(var) {
                Some(after) if self.resolve_ty(current) != self.resolve_ty(after) => Some(*var),
                _ => None,
            })
            .collect::<Vec<_>>();
        let mut rebuildable = false;
        for var in &changed_vars {
            let selected_count = def
                .fields
                .get(field_index)
                .map(|(_, ty)| self.count_tyvar_occurrences(ty, *var))
                .unwrap_or(0);
            if selected_count == 0 {
                continue;
            }
            let other_count = def
                .fields
                .iter()
                .enumerate()
                .filter(|(index, _)| *index != field_index)
                .map(|(_, (_, ty))| self.count_tyvar_occurrences(ty, *var))
                .sum::<usize>();
            if selected_count == 1 && other_count == 0 {
                rebuildable = true;
                continue;
            }
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet cannot rebuild {} because a generic parameter occurs outside the updated field",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: Some("Use a path whose replacement determines each changed generic parameter uniquely.".into()),
            });
        }
        if rebuildable {
            Ok(())
        } else {
            Err(TypeError {
                structured: None,
                message: format!(
                    "Facet cannot rebuild {} because the updated field does not determine a generic parameter",
                    Self::surface_name(type_name)
                ),
                span: span.clone(),
                hint: Some("Only uniquely rebuildable generic named types support a type-changing Facet update.".into()),
            })
        }
    }

    fn finalize_facet_update(
        &mut self,
        path: &mut TypedFacetPath,
        replacement_ty: &Ty,
        span: &Span,
    ) -> Result<Ty, TypeError> {
        let replacement_ty = self.resolve_ty(replacement_ty);
        let update_source_ty =
            self.rebuild_facet_source_type(&path.source_ty, &path.segments, &replacement_ty, span)?;
        self.validate_nominal_type_well_formed(&update_source_ty, span, false)?;

        if !matches!(path.update_focus_ty, Ty::Hole)
            && !self.types_compatible(&path.update_focus_ty, &replacement_ty)?
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet replacement type mismatch: annotation requires {}, got {}",
                    self.ty_name(&path.update_focus_ty),
                    self.ty_name(&replacement_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }
        if !matches!(path.update_source_ty, Ty::Hole)
            && !self.types_compatible(&path.update_source_ty, &update_source_ty)?
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet rebuilt source type mismatch: annotation requires {}, got {}",
                    self.ty_name(&path.update_source_ty),
                    self.ty_name(&update_source_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        path.update_focus_ty = replacement_ty;
        path.update_source_ty = update_source_ty.clone();
        Ok(update_source_ty)
    }

    fn check_facet_view_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input) =
            self.parse_facet_read_intrinsic_args(span, "Facet::view", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            path,
            ..
        } = self.prepare_facet_input(span, "Facet::view", &source_expr, path_input)?;
        self.ensure_deferred_facet_slots("Facet::view", &path, span)?;

        let focus_ty = self.resolve_ty(&path.focus_ty);
        let out_ty = if source_is_result || path.may_fail {
            Ty::Result(Box::new(focus_ty.clone()), Box::new(Ty::Error))
        } else {
            focus_ty
        };

        Ok(TypedNode {
            ty: out_ty,
            span: span.clone(),
            node: TypedInner::FacetView {
                api: TypedFacetApi::View,
                source: Box::new(typed_source),
                path,
                source_is_result,
            },
        })
    }

    fn check_facet_preview_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input) =
            self.parse_facet_read_intrinsic_args(span, "Facet::preview", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            path,
            ..
        } = self.prepare_facet_input(span, "Facet::preview", &source_expr, path_input)?;
        self.ensure_deferred_facet_slots("Facet::preview", &path, span)?;
        if !path.has_variant_segment() {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some("Facet::preview requires a variant Facet".into()),
                None,
                Some(&Ty::Facet(
                    Self::facet_kind_from_path_kind(path.path_kind),
                    Box::new(path.source_ty.clone()),
                    Box::new(path.focus_ty.clone()),
                    Box::new(path.update_source_ty.clone()),
                    Box::new(path.update_focus_ty.clone()),
                )),
                None,
                None,
                span,
                Some("Use Facet::view for structural field and tuple paths.".into()),
            ));
        }

        let focus_ty = self.resolve_ty(&path.focus_ty);
        Ok(TypedNode {
            ty: Ty::Result(Box::new(focus_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetView {
                api: TypedFacetApi::Preview,
                source: Box::new(typed_source),
                path,
                source_is_result,
            },
        })
    }

    fn check_facet_set_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, value_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::set", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::set", &source_expr, path_input)?;
        self.check_mutating_facet_path_permissions("Facet::set", &path, span)?;

        let typed_value = self.check_node(value_expr)?;
        if matches!(self.resolve_ty(&path.focus_ty), Ty::Result(_, _))
            && !matches!(self.resolve_ty(&typed_value.ty), Ty::Result(_, _))
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet::set value type mismatch: expected {}, got {}",
                    self.ty_name(&path.focus_ty),
                    self.ty_name(&typed_value.ty)
                ),
                span: typed_value.span.clone(),
                hint: Some("Facet::set replaces a Result property as a whole; use Facet::over to update its Ok payload.".into()),
            });
        }
        let update_source_ty = self.finalize_facet_update(&mut path, &typed_value.ty, span)?;

        Ok(TypedNode {
            ty: Ty::Result(Box::new(update_source_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetSet {
                api: TypedFacetApi::Set,
                source: Box::new(typed_source),
                path,
                value: Box::new(typed_value),
                source_is_result,
                mode: TypedFacetSetMode::Exact,
            },
        })
    }

    fn check_facet_put_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, value_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::put", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::put", &source_expr, path_input)?;
        if source_is_result {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some("Facet::put requires a plain source value".into()),
                None,
                Some(&typed_source.ty),
                None,
                None,
                &typed_source.span,
                Some("Use Facet::set when the source is already Result<T>.".into()),
            ));
        }
        if !path.is_infallible_structural() {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some("Facet::put requires an infallible structural Facet path".into()),
                None,
                None,
                None,
                None,
                span,
                Some("Use Facet::set for fallible or variant-sensitive updates.".into()),
            ));
        }
        self.check_mutating_facet_path_permissions("Facet::put", &path, span)?;

        let typed_value = self.check_node(value_expr)?;
        let update_source_ty = self.finalize_facet_update(&mut path, &typed_value.ty, span)?;

        Ok(TypedNode {
            ty: update_source_ty,
            span: span.clone(),
            node: TypedInner::FacetSet {
                api: TypedFacetApi::Put,
                source: Box::new(typed_source),
                path,
                value: Box::new(typed_value),
                source_is_result,
                mode: TypedFacetSetMode::Exact,
            },
        })
    }

    fn check_facet_over_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, update_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::over", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::over", &source_expr, path_input)?;
        self.check_mutating_facet_path_permissions("Facet::over", &path, span)?;

        let typed_update = self.check_node(update_expr)?;
        let (mode, replacement_ty) = self.check_facet_over_callable(
            "Facet::over",
            span,
            &path.focus_ty,
            &typed_update,
            false,
            false,
        )?;
        let update_source_ty = self.finalize_facet_update(&mut path, &replacement_ty, span)?;

        Ok(TypedNode {
            ty: Ty::Result(Box::new(update_source_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetOver {
                api: TypedFacetApi::Over,
                source: Box::new(typed_source),
                path,
                update_fun: Box::new(typed_update),
                source_is_result,
                mode,
            },
        })
    }

    fn require_enum_facet_path(
        &self,
        op_name: &str,
        path: &TypedFacetPath,
        span: &Span,
    ) -> Result<(), TypeError> {
        if !path.has_variant_segment() {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some(format!("{op_name} requires an enum Facet path")),
                None,
                None,
                None,
                None,
                span,
                Some("Use Facet::set/over for structural, list, or map paths.".into()),
            ));
        }
        Ok(())
    }

    fn check_facet_case_set_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, value_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::case_set", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::case_set", &source_expr, path_input)?;
        self.require_enum_facet_path("Facet::case_set", &path, span)?;
        if !path.final_segment_is_variant() {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetOperationPolicyViolation,
                diagnostics::TypePolicy::FacetOperation,
                Some("Facet::case_set requires the final Facet segment to be an enum case".into()),
                None,
                None,
                None,
                None,
                span,
                Some("Use Facet::case_over when updating inside a selected case payload.".into()),
            ));
        }
        self.check_mutating_facet_path_permissions("Facet::case_set", &path, span)?;

        let typed_value = self.check_node(value_expr)?;
        let update_source_ty = self.finalize_facet_update(&mut path, &typed_value.ty, span)?;

        Ok(TypedNode {
            ty: Ty::Result(Box::new(update_source_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetSet {
                api: TypedFacetApi::CaseSet,
                source: Box::new(typed_source),
                path,
                value: Box::new(typed_value),
                source_is_result,
                mode: TypedFacetSetMode::CaseSet,
            },
        })
    }

    fn check_facet_case_over_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, update_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::case_over", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::case_over", &source_expr, path_input)?;
        self.require_enum_facet_path("Facet::case_over", &path, span)?;
        self.check_mutating_facet_path_permissions("Facet::case_over", &path, span)?;

        let typed_update = self.check_node(update_expr)?;
        let (mode, replacement_ty) = match self.check_facet_over_callable(
            "Facet::case_over",
            span,
            &path.focus_ty,
            &typed_update,
            false,
            true,
        )? {
            (TypedFacetOverMode::FocusValue, replacement) => {
                (TypedFacetOverMode::CaseFocusValue, replacement)
            }
            (TypedFacetOverMode::FocusResult, replacement) => {
                (TypedFacetOverMode::CaseFocusResult, replacement)
            }
            (
                mode @ (TypedFacetOverMode::CaseFocusValue | TypedFacetOverMode::CaseFocusResult),
                replacement,
            ) => (mode, replacement),
        };
        let update_source_ty = self.finalize_facet_update(&mut path, &replacement_ty, span)?;

        Ok(TypedNode {
            ty: Ty::Result(Box::new(update_source_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetOver {
                api: TypedFacetApi::CaseOver,
                source: Box::new(typed_source),
                path,
                update_fun: Box::new(typed_update),
                source_is_result,
                mode,
            },
        })
    }

    fn check_facet_over_result_intrinsic(
        &mut self,
        span: &Span,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        let (source_expr, path_input, update_expr) =
            self.parse_facet_mutating_intrinsic_args(span, "Facet::over_result", args)?;
        let PreparedFacetInput {
            typed_source,
            source_is_result,
            mut path,
            ..
        } = self.prepare_facet_input(span, "Facet::over_result", &source_expr, path_input)?;
        self.check_mutating_facet_path_permissions("Facet::over_result", &path, span)?;

        if !matches!(self.resolve_ty(&path.focus_ty), Ty::Result(_, _)) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet::over_result requires Result focus, got {}",
                    self.ty_name(&path.focus_ty)
                ),
                span: span.clone(),
                hint: Some("Use Facet::over for plain focus updates.".into()),
            });
        }

        let inner_ty = self.env.fresh_tyvar();
        let expected_update = self.callable_contract(
            &path.focus_ty,
            Some(Ty::Result(
                Box::new(Ty::Result(Box::new(inner_ty), Box::new(Ty::Error))),
                Box::new(Ty::Error),
            )),
            ExpectedCallableSlot::Plain,
        );
        let typed_update = self.check_apply_callable_with_contract(
            update_expr,
            &expected_update,
            "Facet::over_result",
        )?;
        let (mode, replacement_ty) = self.check_facet_over_callable(
            "Facet::over_result",
            span,
            &path.focus_ty,
            &typed_update,
            true,
            true,
        )?;
        let update_source_ty = self.finalize_facet_update(&mut path, &replacement_ty, span)?;

        Ok(TypedNode {
            ty: Ty::Result(Box::new(update_source_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::FacetOver {
                api: TypedFacetApi::OverResult,
                source: Box::new(typed_source),
                path,
                update_fun: Box::new(typed_update),
                source_is_result,
                mode,
            },
        })
    }

    fn check_facet_over_callable(
        &mut self,
        op_name: &str,
        span: &Span,
        focus_ty: &Ty,
        typed_update: &TypedNode,
        require_result_focus: bool,
        allow_result_focus_input: bool,
    ) -> Result<(TypedFacetOverMode, Ty), TypeError> {
        let (in_ty, out_ty) = self.unary_function_parts(&typed_update.ty, op_name, span)?;
        let resolved_focus_ty = self.resolve_ty(focus_ty);
        let value_focus_ty = match &resolved_focus_ty {
            Ty::Result(ok, _) => Some(ok.as_ref().clone()),
            _ => None,
        };

        let mode = if require_result_focus {
            TypedFacetOverMode::FocusResult
        } else if let Some(value_focus_ty) = &value_focus_ty {
            if self.types_compatible(value_focus_ty, &in_ty)? {
                TypedFacetOverMode::FocusValue
            } else if allow_result_focus_input {
                TypedFacetOverMode::FocusResult
            } else {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "{op_name} update function input mismatch: expected {}, got {}",
                        self.ty_name(value_focus_ty),
                        self.ty_name(&in_ty)
                    ),
                    span: typed_update.span.clone(),
                    hint: Some(
                        "Use Facet::over_result to update the Result property as a whole.".into(),
                    ),
                });
            }
        } else {
            TypedFacetOverMode::FocusValue
        };

        let expected_input_ty = match (&mode, &value_focus_ty) {
            (TypedFacetOverMode::FocusValue, Some(value_focus_ty)) => value_focus_ty,
            _ => &resolved_focus_ty,
        };
        if !self.types_compatible(expected_input_ty, &in_ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{op_name} update function input mismatch: expected {}, got {}",
                    self.ty_name(expected_input_ty),
                    self.ty_name(&in_ty)
                ),
                span: typed_update.span.clone(),
                hint: None,
            });
        }

        let (out_ok, out_err) = match self.resolve_ty(&out_ty) {
            Ty::Result(ok, err) => (ok.as_ref().clone(), err.as_ref().clone()),
            _ => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "{op_name} update function must return Result<...>, got {}",
                        self.ty_name(&out_ty)
                    ),
                    span: typed_update.span.clone(),
                    hint: None,
                });
            }
        };
        if require_result_focus && !matches!(out_ok, Ty::Result(_, _)) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{op_name} update function output mismatch: must return Result<Result<...>>, got {}",
                    self.ty_name(&out_ty)
                ),
                span: typed_update.span.clone(),
                hint: Some(
                    "Return an outer Result for mapper failure and an inner Result property value."
                        .into(),
                ),
            });
        }
        if !self.types_compatible(&Ty::Error, &out_err)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{op_name} update function error type must be Error-compatible, got {}",
                    self.ty_name(&out_err)
                ),
                span: typed_update.span.clone(),
                hint: None,
            });
        }

        let replacement_ty = match (&mode, &resolved_focus_ty) {
            (TypedFacetOverMode::FocusValue, Ty::Result(_, err)) => {
                Ty::Result(Box::new(out_ok), err.clone())
            }
            _ => out_ok,
        };
        Ok((mode, replacement_ty))
    }

    fn check_mutating_facet_path_permissions(
        &self,
        facet_name: &str,
        path: &TypedFacetPath,
        span: &Span,
    ) -> Result<(), TypeError> {
        for (index, segment) in path.segments.iter().enumerate() {
            let is_final = index + 1 == path.segments.len();
            match segment {
                TypedFacetSegment::ReadonlyBuiltin { field_name, .. }
                | TypedFacetSegment::ErrorPayload { field_name, .. } => {
                    return Err(TypeError::new(
                        format!("{facet_name} cannot update readonly Error.{field_name}"),
                        span.clone(),
                    ));
                }
                TypedFacetSegment::Field {
                    field_name,
                    container_type_name,
                    readonly,
                    ..
                } => {
                    if *readonly {
                        let owner_can_replace = is_final
                            && self
                                .current_impl_struct_target
                                .as_deref()
                                .map(Self::surface_name)
                                == Some(container_type_name.as_str());
                        if !owner_can_replace {
                            let hint = if is_final {
                                format!(
                                    "Only impl {} may replace the property itself.",
                                    container_type_name
                                )
                            } else {
                                format!(
                                    "Readonly field {}.{} can only be replaced as a whole; it cannot be traversed to update nested state.",
                                    container_type_name, field_name
                                )
                            };
                            return Err(TypeError {
                                structured: None,
                                message: format!(
                                    "{} cannot mutably traverse readonly field {}.{}; only the owner can replace the property itself",
                                    facet_name, container_type_name, field_name
                                ),
                                span: span.clone(),
                                hint: Some(hint),
                            });
                        }
                    }
                }
                TypedFacetSegment::Tuple { .. }
                | TypedFacetSegment::Variant { .. }
                | TypedFacetSegment::ListIndex { .. }
                | TypedFacetSegment::ListRange { .. }
                | TypedFacetSegment::MapKey { .. } => {}
            }
        }

        Ok(())
    }

    fn try_check_facet_intrinsic_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        match self.facet_intrinsic_kind(func) {
            Some("view") => Ok(Some(self.check_facet_view_intrinsic(span, args)?)),
            Some("preview") => Ok(Some(self.check_facet_preview_intrinsic(span, args)?)),
            Some("compose") => Ok(Some(self.check_facet_compose_intrinsic(span, args)?)),
            Some("put") => Ok(Some(self.check_facet_put_intrinsic(span, args)?)),
            Some("set") => Ok(Some(self.check_facet_set_intrinsic(span, args)?)),
            Some("over") => Ok(Some(self.check_facet_over_intrinsic(span, args)?)),
            Some("over_result") => Ok(Some(self.check_facet_over_result_intrinsic(span, args)?)),
            Some("case_set") => Ok(Some(self.check_facet_case_set_intrinsic(span, args)?)),
            Some("case_over") => Ok(Some(self.check_facet_case_over_intrinsic(span, args)?)),
            _ => Ok(None),
        }
    }

    pub(super) fn ensure_no_runtime_facet_args(
        &self,
        args: &[TypedNode],
        span: &Span,
        callee: &str,
    ) -> Result<(), TypeError> {
        for arg in args {
            self.ensure_no_match_result_value(&arg.ty, &arg.span)?;
        }
        if let Some(arg) = args.iter().find(|arg| self.ty_contains_facet(&arg.ty)) {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetCompileTimeOnly,
                diagnostics::TypePolicy::FacetStageRestriction,
                Some(format!(
                    "{} cannot accept Facet values in Stage1 (Facet is compile-time only)",
                    callee
                )),
                None,
                Some(&arg.ty),
                Some("Stage1".into()),
                None,
                span,
                Some("Apply Facet::view(...) before passing the value.".into()),
            ));
        }
        Ok(())
    }

    pub(super) fn ensure_no_runtime_facet_value(
        &self,
        value: &TypedNode,
        context: &str,
    ) -> Result<(), TypeError> {
        self.ensure_no_match_result_value(&value.ty, &value.span)?;
        if self.ty_contains_facet(&value.ty) {
            return Err(self.policy_error(
                TypeDiagnosticReason::FacetCompileTimeOnly,
                diagnostics::TypePolicy::FacetStageRestriction,
                Some(format!(
                    "{} cannot contain Facet values in Stage1 (Facet is compile-time only)",
                    context
                )),
                None,
                Some(&value.ty),
                Some("Stage1".into()),
                None,
                &value.span,
                Some(
                    "Consume Facet with Facet::view/set/over first, then pass the plain value."
                        .into(),
                ),
            ));
        }
        Ok(())
    }

    pub(super) fn check_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<TypedNode, TypeError> {
        self.check_app_with_expected(span, func, args, None)
    }

    // Keep curry-only temporaries out of the recursive ordinary-call frame.
    #[inline(never)]
    fn check_function_curry_with_expected(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        expected_return: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let explicit_return = if let Resolved::ReturnTypeArgumentApply(..) = func {
            let specialized = self.check_node(func)?;
            match specialized.ty {
                Ty::BuiltinFunc { ret, .. } => Some(*ret),
                _ => unreachable!("standard curry has a builtin signature"),
            }
        } else {
            None
        };
        let typed = self.check_function_curry(span, args)?;
        if let Some(expected) = explicit_return.as_ref().or(expected_return) {
            self.assert_type_relation(
                expected,
                &typed.ty,
                self.type_fact(SourceRole::Expected, span, expected),
                self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                TypeDiagnosticReason::ReturnTypeMismatch,
                DiagnosticOrigin::Call,
                "Function::curry",
                0,
            )?;
        }
        Ok(typed)
    }

    fn check_app_with_expected(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
        expected_return: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        if self.is_function_curry_callee(func) {
            return self.check_function_curry_with_expected(span, func, args, expected_return);
        }
        if let Some(typed) = self.try_check_process_intrinsic_app(span, func, args)? {
            return Ok(typed);
        }

        if let Some(typed) = self.try_check_facet_intrinsic_app(span, func, args)? {
            return Ok(typed);
        }

        if let Some((id, trait_name, method_name)) = self.trait_method_ref(func) {
            let receiver_owner_hint = id
                .name
                .strip_suffix(&format!("::{}", method_name))
                .filter(|owner| *owner == "JsonValue");
            let explicit_type_arguments = Self::explicit_type_args(func);
            return self.check_trait_method_call(
                span,
                &trait_name,
                &method_name,
                args,
                receiver_owner_hint,
                expected_return,
                explicit_type_arguments.as_deref(),
            );
        }

        let result = (|| {
            let explicit_type_arguments = Self::explicit_type_args(func);
            let call_target = match func {
                Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
                other => other,
            };
            let has_canonical_signature = match call_target {
                Resolved::Var(_, id) => self.callable_signatures.contains_key(&id.unique_id),
                _ => false,
            };
            let mut prepared_signature = None;
            let mut typed_func = if explicit_type_arguments.is_some() || has_canonical_signature {
                let (typed, signature, return_type_arguments) = self
                    .instantiate_named_callable_signature(
                        span,
                        call_target,
                        explicit_type_arguments.as_deref(),
                    )?;
                prepared_signature = Some((signature, return_type_arguments));
                typed
            } else {
                self.check_node(call_target)?
            };
            let func_ty = self.resolve_ty(&typed_func.ty);

            // A closure parameter may only reveal that it is callable when it is
            // first applied (for example `g(x)` inside a higher-order closure).
            // Turn that unconstrained type variable into a callable shape before
            // checking its arguments so inference can continue recursively.
            if let Ty::Var(var) = func_ty {
                if !self.rigid_tyvars.contains(&var) {
                    let params = (0..args.len())
                        .map(|_| self.env.fresh_tyvar())
                        .collect::<Vec<_>>();
                    let ret = self.env.fresh_tyvar();
                    if self.bind_tyvar(var, &Ty::Func(params, Box::new(ret)))? {
                        return self.check_app_with_expected(span, func, args, expected_return);
                    }
                }
            }

            match &func_ty {
                Ty::BuiltinFunc { name, params, ret } => {
                    let builtin_uid = match &typed_func.node {
                        TypedInner::Var(id) => Some(id.unique_id),
                        _ => None,
                    };
                    let callable_hint = if let TypedInner::Var(id) = &typed_func.node {
                        Some(self.call_target_signature_hint_for_id(id, params, ret.as_ref()))
                    } else {
                        Some(self.call_target_signature_hint(name, params, ret.as_ref(), None))
                    };
                    let application_constraints = prepared_signature
                        .or_else(|| {
                            builtin_uid
                                .and_then(|uid| self.callable_signatures.get(&uid).cloned())
                                .map(|signature| {
                                    let (mut signature, _) =
                                        super::signatures::instantiate_callable_signature(
                                            self, &signature,
                                        );
                                    let return_type_arguments = self
                                .apply_call_site_return_type_arguments(span, &mut signature, None)
                                .expect("omitted return type arguments cannot have an arity error");
                                    (signature, return_type_arguments)
                                })
                        })
                        .map(|(signature, return_type_arguments)| {
                            self.call_constraint_set(
                                signature,
                                return_type_arguments,
                                expected_return,
                                span,
                                &typed_func.ty,
                            )
                        });
                    if application_constraints.is_none() {
                        if let TypedInner::Var(id) = &typed_func.node {
                            if self.is_registered_callable_declaration(id.unique_id) {
                                return Err(
                                    super::signatures::missing_canonical_callable_signature(
                                        id, span,
                                    ),
                                );
                            }
                        }
                    }
                    let result = (|| {
                        let application_constraints = application_constraints;
                        if let Some(constraints) = application_constraints.as_ref() {
                            self.apply_return_type_argument_constraints(constraints)?;
                            self.apply_concrete_expected_call_constraint(
                                constraints,
                                span,
                                explicit_type_arguments.as_deref(),
                            )?;
                        }
                        let typed_args = if let (Some(uid), Some(signature)) = (
                            builtin_uid,
                            application_constraints
                                .as_ref()
                                .map(|constraints| &constraints.signature),
                        ) {
                            typed_func.ty = Ty::BuiltinFunc {
                                name: name.clone(),
                                params: signature
                                    .value_parameters
                                    .iter()
                                    .map(|parameter| parameter.ty.clone())
                                    .collect(),
                                ret: Box::new(signature.return_type.ty.clone()),
                            };
                            self.check_callable_application(
                                uid,
                                name,
                                signature,
                                args,
                                span,
                                callable_hint.as_deref(),
                            )?
                        } else {
                            self.typecheck_positional_call_args(
                                span,
                                name,
                                params,
                                args,
                                callable_hint.clone(),
                                format!("{} does not accept named arguments", name),
                            )?
                        };
                        self.ensure_no_runtime_facet_args(&typed_args, span, name)?;
                        let application_signature = match application_constraints {
                            Some(mut constraints) => {
                                let substitution = match self.complete_call_constraint_set(
                                    &mut constraints,
                                    &typed_args,
                                    span,
                                    explicit_type_arguments.as_deref(),
                                ) {
                                    super::signatures::SolveState::Solved(substitution) => {
                                        substitution
                                    }
                                    super::signatures::SolveState::Deferred(pending) => {
                                        let _ = pending.unresolved_return_type_arguments.len();
                                        pending.substitution
                                    }
                                    super::signatures::SolveState::Failed(error) => {
                                        return Err(error);
                                    }
                                };
                                if let Ty::UserFunc {
                                    call_substitution, ..
                                } = &mut typed_func.ty
                                {
                                    *call_substitution = substitution;
                                }
                                Some(constraints.signature)
                            }
                            None => None,
                        };

                        if let Some(signature) = application_signature.as_ref() {
                            typed_func.ty =
                                self.callable_ty_from_signature(&typed_func.ty, signature);
                        }

                        if name == "__process_self" {
                            let Some(process_name) = self.current_process_name() else {
                                return Err(self.policy_error(
                                    TypeDiagnosticReason::ProcessHandlerScope,
                                    diagnostics::TypePolicy::ProcessHandlerScope,
                                    Some("Process::self() is only available inside process handlers".into()),
                                    None,
                                    None,
                                    None,
                                    None,
                                    span,
                                    Some("Call Process::self() inside @init/@get/@set bodies of a defagent.".into()),
                                ));
                            };
                            return Ok(TypedNode {
                                ty: Ty::pid(process_name),
                                span: span.clone(),
                                node: TypedInner::App(Box::new(typed_func), typed_args),
                            });
                        }

                        if name == "set_exit_code" {
                            match self.runtime_policy.exit_code_policy {
                                ExitCodePolicy::Anywhere => {}
                                ExitCodePolicy::Forbidden => {
                                    return Err(self.policy_error(
                                        TypeDiagnosticReason::SourcePolicyViolation,
                                        diagnostics::TypePolicy::SourceExitCode,
                                        Some("set_exit_code".into()),
                                        None,
                                        None,
                                        Some(self.runtime_policy.exit_code_policy.as_str().into()),
                                        None,
                                        span,
                                        Some("This source kind does not allow set_exit_code. Use Result-based failure handling instead.".into()),
                                    ));
                                }
                                ExitCodePolicy::EntryOnly => {
                                    let Some(entrypoint) =
                                        self.runtime_policy.normalized_entrypoint.as_ref()
                                    else {
                                        return Err(self.policy_error(
                                            TypeDiagnosticReason::CompilePolicyViolation,
                                            diagnostics::TypePolicy::EntrypointRequirement,
                                            Some("set_exit_code".into()),
                                            None,
                                            None,
                                            Some("EntryOnly".into()),
                                            None,
                                            span,
                                            Some("Configure an entrypoint, or avoid set_exit_code in this compile unit.".into()),
                                        ));
                                    };
                                    if self.current_function_symbol.as_deref()
                                        != Some(entrypoint.as_str())
                                    {
                                        return Err(self.policy_error(
                                            TypeDiagnosticReason::SourcePolicyViolation,
                                            diagnostics::TypePolicy::EntrypointRequirement,
                                            Some("set_exit_code".into()),
                                            None,
                                            None,
                                            Some(self.runtime_policy.exit_code_policy.as_str().into()),
                                            Some(entrypoint.clone()),
                                            span,
                                            Some("Move set_exit_code into the configured entrypoint function.".into()),
                                        ));
                                    }
                                }
                            }
                        }

                        Ok(TypedNode {
                            ty: application_signature
                                .as_ref()
                                .map(|signature| self.resolve_ty(&signature.return_type.ty))
                                .unwrap_or_else(|| self.resolve_ty(ret)),
                            span: span.clone(),
                            node: TypedInner::App(Box::new(typed_func), typed_args),
                        })
                    })();
                    result
                }
                Ty::UserFunc { params, ret, .. } => {
                    let has_named = args
                        .iter()
                        .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)));
                    let callee_uid = match call_target {
                        Resolved::Var(_, id) => id.unique_id,
                        _ if !has_named => u32::MAX,
                        _ => {
                            return Err(TypeError {
                                structured: None,
                                message: "This function value does not accept named arguments"
                                    .into(),
                                span: span.clone(),
                                hint: None,
                            });
                        }
                    };
                    let callable_hint =
                        self.callable_definition_signature_hint(&typed_func, params, ret.as_ref());
                    let application_constraints = prepared_signature
                        .or_else(|| {
                            self.callable_signatures
                                .get(&callee_uid)
                                .cloned()
                                .map(|signature| {
                                    let (mut signature, _) =
                                        super::signatures::instantiate_callable_signature(
                                            self, &signature,
                                        );
                                    let return_type_arguments = self
                                .apply_call_site_return_type_arguments(span, &mut signature, None)
                                .expect("omitted return type arguments cannot have an arity error");
                                    (signature, return_type_arguments)
                                })
                        })
                        .map(|(signature, return_type_arguments)| {
                            self.call_constraint_set(
                                signature,
                                return_type_arguments,
                                expected_return,
                                span,
                                &typed_func.ty,
                            )
                        });
                    if application_constraints.is_none() {
                        if let TypedInner::Var(id) = &typed_func.node {
                            if self.is_registered_callable_declaration(id.unique_id) {
                                return Err(
                                    super::signatures::missing_canonical_callable_signature(
                                        id, span,
                                    ),
                                );
                            }
                        }
                    }
                    let result = (|| {
                        let application_constraints = application_constraints;
                        if let Some(constraints) = application_constraints.as_ref() {
                            self.apply_return_type_argument_constraints(constraints)?;
                            self.apply_concrete_expected_call_constraint(
                                constraints,
                                span,
                                explicit_type_arguments.as_deref(),
                            )?;
                        }
                        let typed_args = if let Some(signature) = application_constraints
                            .as_ref()
                            .map(|constraints| &constraints.signature)
                        {
                            if let Ty::UserFunc {
                                fun_idx,
                                type_params,
                                call_substitution,
                                ..
                            } = &typed_func.ty
                            {
                                typed_func.ty = Ty::UserFunc {
                                    fun_idx: *fun_idx,
                                    type_params: type_params.clone(),
                                    call_substitution: call_substitution.clone(),
                                    params: signature
                                        .value_parameters
                                        .iter()
                                        .map(|parameter| parameter.ty.clone())
                                        .collect(),
                                    ret: Box::new(signature.return_type.ty.clone()),
                                };
                            }
                            self.check_callable_application(
                                callee_uid,
                                "function",
                                signature,
                                args,
                                span,
                                callable_hint.as_deref(),
                            )?
                        } else {
                            self.typecheck_user_function_args(
                                span,
                                callee_uid,
                                "function",
                                params,
                                args,
                                callable_hint.as_deref(),
                                false,
                            )?
                        };
                        let typed_args = typed_args
                            .into_iter()
                            .map(|arg| {
                                self.concretize_pending_trait_calls(arg)
                                    .map(|node| *node)
                                    .map_err(|error| *error)
                            })
                            .collect::<Result<Vec<_>, _>>()?;
                        self.ensure_no_runtime_facet_args(&typed_args, span, "Function call")?;
                        let application_signature = match application_constraints {
                            Some(mut constraints) => {
                                let substitution = match self.complete_call_constraint_set(
                                    &mut constraints,
                                    &typed_args,
                                    span,
                                    explicit_type_arguments.as_deref(),
                                ) {
                                    super::signatures::SolveState::Solved(substitution) => {
                                        substitution
                                    }
                                    super::signatures::SolveState::Deferred(pending) => {
                                        let _ = pending.unresolved_return_type_arguments.len();
                                        pending.substitution
                                    }
                                    super::signatures::SolveState::Failed(error) => {
                                        return Err(error);
                                    }
                                };
                                if let Ty::UserFunc {
                                    call_substitution, ..
                                } = &mut typed_func.ty
                                {
                                    *call_substitution = substitution;
                                }
                                Some(constraints.signature)
                            }
                            None => None,
                        };

                        if let Some(signature) = application_signature.as_ref() {
                            typed_func.ty =
                                self.callable_ty_from_signature(&typed_func.ty, signature);
                        }

                        Ok(TypedNode {
                            ty: application_signature
                                .as_ref()
                                .map(|signature| self.resolve_ty(&signature.return_type.ty))
                                .unwrap_or_else(|| self.resolve_ty(ret)),
                            span: span.clone(),
                            node: TypedInner::App(Box::new(typed_func), typed_args),
                        })
                    })();
                    result
                }
                Ty::Func(params, ret) => {
                    let callable_hint =
                        self.callable_signature_hint(&Ty::Func(params.clone(), ret.clone()));
                    let typed_args = self.typecheck_positional_call_args(
                        span,
                        "function",
                        params,
                        args,
                        callable_hint.clone(),
                        "Function values do not accept named arguments".into(),
                    )?;
                    self.ensure_no_runtime_facet_args(&typed_args, span, "Function call")?;

                    Ok(TypedNode {
                        ty: self.resolve_ty(ret),
                        span: span.clone(),
                        node: TypedInner::App(Box::new(typed_func), typed_args),
                    })
                }
                _ => Err(self.callable_shape_error(
                    &typed_func.ty,
                    "function",
                    &typed_func.span,
                    None,
                )),
            }
        })();
        let result = result.and_then(|typed| {
            if let TypedInner::App(function, arguments) = &typed.node {
                self.check_callable_input_provenance(function, arguments)?;
            }
            Ok(typed)
        });
        result.map_err(|error| self.lazy_call_error(error, span, func, args))
    }

    fn is_registered_callable_declaration(&self, unique_id: u32) -> bool {
        self.function_ids_by_name
            .values()
            .any(|registered| registered.unique_id == unique_id)
    }

    fn check_callable_application(
        &mut self,
        uid: u32,
        callable_name: &str,
        signature: &sindr::signature::CallableSignature<Ty>,
        args: &[ResolvedRecordLitArg],
        span: &Span,
        callable_hint: Option<&str>,
    ) -> Result<Vec<TypedNode>, TypeError> {
        let params = signature
            .value_parameters
            .iter()
            .map(|parameter| parameter.ty.clone())
            .collect::<Vec<_>>();
        let typed_args = self.typecheck_user_function_args(
            span,
            uid,
            callable_name,
            &params,
            args,
            callable_hint,
            true,
        )?;

        Ok(typed_args)
    }

    pub(super) fn typecheck_positional_call_args(
        &mut self,
        span: &Span,
        callee_name: &str,
        params: &[Ty],
        args: &[ResolvedRecordLitArg],
        callable_hint: Option<String>,
        named_arg_error: String,
    ) -> Result<Vec<TypedNode>, TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    callee_name,
                    None,
                    params.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: named_arg_error,
                span: span.clone(),
                hint: None,
            });
        }

        if args.len() != params.len() {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    callee_name,
                    None,
                    params.len(),
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{} expects {} argument(s), got {}",
                    callee_name,
                    params.len(),
                    args.len()
                ),
                span: span.clone(),
                hint: callable_hint.clone(),
            });
        }

        let ordered = args
            .iter()
            .map(|arg| match arg {
                ResolvedRecordLitArg::Positional(expr) => OrderedCallArgument::Present(expr),
                ResolvedRecordLitArg::Named(_, _) => unreachable!("named arguments were rejected"),
            })
            .collect::<Vec<_>>();
        let typed_args = self.typecheck_ordered_call_args(
            span,
            callee_name,
            params,
            &ordered,
            callable_hint.as_deref(),
            CallArgumentMode::Positional,
        )?;

        typed_args
            .into_iter()
            .map(|arg| {
                self.concretize_pending_trait_calls(arg)
                    .map(|node| *node)
                    .map_err(|error| *error)
            })
            .collect::<Result<Vec<_>, _>>()
    }

    pub(super) fn current_process_name(&self) -> Option<String> {
        let symbol = self.current_function_symbol.as_deref()?;
        let (module, handler) = symbol.rsplit_once("::")?;
        Self::is_process_handler_name(handler).then(|| module.to_string())
    }

    fn process_policy_error(
        &self,
        subject: impl Into<String>,
        actual: Option<&Ty>,
        span: &Span,
        hint: Option<String>,
    ) -> TypeError {
        self.policy_error(
            TypeDiagnosticReason::ProcessPolicyViolation,
            diagnostics::TypePolicy::ProcessCapabilityPolicy,
            Some(subject.into()),
            None,
            actual,
            None,
            None,
            span,
            hint,
        )
    }

    fn try_check_process_intrinsic_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        if let Some(typed) = self.try_check_supervisor_spawn_app(span, func, args)? {
            return Ok(Some(typed));
        }
        if let Some(typed) = self.try_check_supervisor_adopt_app(span, func, args)? {
            return Ok(Some(typed));
        }
        if let Some(typed) = self.try_check_supervisor_status_app(span, func, args)? {
            return Ok(Some(typed));
        }
        if let Some(typed) = self.try_check_supervisor_workers_app(span, func, args)? {
            return Ok(Some(typed));
        }
        if let Some(typed) = self.try_check_worker_message_template_app(span, func, args)? {
            return Ok(Some(typed));
        }
        self.try_check_singleton_explicit_pid_app(span, func, args)
    }

    fn try_check_supervisor_spawn_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        let Some(supervisor_process) = self.supervisor_spawn_target(func) else {
            return Ok(None);
        };
        self.ensure_supervisor_registered_for_surface(span, &supervisor_process, "spawn")?;
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    &format!("{supervisor_process}::spawn"),
                    None,
                    1,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!("{supervisor_process}::spawn does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if args.len() != 1 {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    &format!("{supervisor_process}::spawn"),
                    None,
                    1,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{}::spawn expects 1 argument(s), got {}",
                    supervisor_process,
                    args.len()
                ),
                span: span.clone(),
                hint: Some(
                    "Pass a worker init route reference like `MyWorker::init(args)`.".into(),
                ),
            });
        }
        if self.in_compiler_generated_supervisor_wrapper(&supervisor_process, "spawn") {
            return Ok(None);
        }
        let ResolvedRecordLitArg::Positional(worker_init) = &args[0] else {
            unreachable!("validated named arguments above")
        };
        if matches!(worker_init, Resolved::Var(_, _)) {
            return Ok(None);
        }
        let (worker_process, typed_init) = self.synthesize_supervisor_worker_init(worker_init)?;
        match self.resolve_ty(&typed_init.ty) {
            Ty::Func(params, _) if params.is_empty() => {}
            other => {
                return Err(self.process_policy_error(
                    format!(
                        "supervisor spawn expects a zero-argument worker init route, got {}",
                        self.ty_name(&other)
                    ),
                    Some(&other),
                    &typed_init.span,
                    Some(
                        "Pass a generated worker init reference like `MyWorker::init(args)`."
                            .into(),
                    ),
                ));
            }
        }

        Ok(Some(TypedNode {
            ty: Ty::Result(
                Box::new(Ty::pid(worker_process.clone())),
                Box::new(Ty::Error),
            ),
            span: span.clone(),
            node: TypedInner::SupervisorSpawn {
                supervisor_process,
                worker_process,
                init: Box::new(typed_init),
            },
        }))
    }

    fn try_check_supervisor_adopt_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        let Some(supervisor_process) = self.supervisor_intrinsic_target(func, "adopt") else {
            return Ok(None);
        };
        self.ensure_supervisor_registered_for_surface(span, &supervisor_process, "adopt")?;
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    &format!("{supervisor_process}::adopt"),
                    None,
                    1,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!("{supervisor_process}::adopt does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if args.len() != 1 {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    &format!("{supervisor_process}::adopt"),
                    None,
                    1,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{}::adopt expects 1 argument(s), got {}",
                    supervisor_process,
                    args.len()
                ),
                span: span.clone(),
                hint: Some("Pass a worker PID.".into()),
            });
        }
        let ResolvedRecordLitArg::Positional(pid_expr) = &args[0] else {
            unreachable!("validated named arguments above")
        };
        let typed_pid = self.check_node(pid_expr)?;
        let worker_process = match self.resolve_ty(&typed_pid.ty) {
            Ty::Pid(marker) if matches!(marker.as_ref(), Ty::ProcessMarker(_)) => {
                let Ty::ProcessMarker(name) = *marker else {
                    unreachable!()
                };
                name
            }
            other => {
                return Err(self.process_policy_error(
                    format!(
                        "supervisor adopt expects PID<Worker>, got {}",
                        self.ty_name(&other)
                    ),
                    Some(&other),
                    &typed_pid.span,
                    Some("Pass a worker PID returned from a worker init route.".into()),
                ));
            }
        };
        let supervisor_spec = self
            .supervisor_spec_by_name(&supervisor_process)
            .ok_or_else(|| {
                self.typecheck_invariant_error(
                    format!("supervisor process metadata missing for `{supervisor_process}`"),
                    span,
                )
            })?;
        if !supervisor_spec
            .spec
            .supervisor_policy
            .as_ref()
            .map(|policy| policy.allow_adopt)
            .unwrap_or(false)
        {
            return Err(self.process_policy_error(
                format!(
                    "{}::adopt is not available because allow_adopt is False",
                    supervisor_process
                ),
                None,
                span,
                Some("Enable `allow_adopt: True` in the supervisor definition or override.".into()),
            ));
        }

        Ok(Some(TypedNode {
            ty: Ty::Result(Box::new(Ty::Unit), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::SupervisorAdopt {
                supervisor_process,
                worker_process,
                pid: Box::new(typed_pid),
            },
        }))
    }

    fn try_check_supervisor_status_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        let Some(supervisor_process) = self.supervisor_intrinsic_target(func, "status") else {
            return Ok(None);
        };
        self.ensure_supervisor_registered_for_surface(span, &supervisor_process, "status")?;
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    &format!("{supervisor_process}::status"),
                    None,
                    0,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!("{supervisor_process}::status does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if !args.is_empty() {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    &format!("{supervisor_process}::status"),
                    None,
                    0,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{}::status expects 0 argument(s), got {}",
                    supervisor_process,
                    args.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }
        let status_ty = self
            .env
            .lookup_type_def("SupervisorStatus")
            .map(|def| {
                Ty::Struct(
                    def.name.clone(),
                    NominalType::new(
                        def.type_param_vars.iter().copied().map(Ty::Var).collect(),
                        def.fields.clone(),
                    ),
                )
            })
            .ok_or_else(|| {
                self.typecheck_invariant_error("SupervisorStatus type metadata", span)
            })?;
        Ok(Some(TypedNode {
            ty: Ty::Result(Box::new(status_ty), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::SupervisorStatus { supervisor_process },
        }))
    }

    fn try_check_supervisor_workers_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        let Some(supervisor_process) = self.supervisor_intrinsic_target(func, "workers") else {
            return Ok(None);
        };
        self.ensure_supervisor_registered_for_surface(span, &supervisor_process, "workers")?;
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArgumentModeMismatch,
                    &format!("{supervisor_process}::workers"),
                    None,
                    2,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!("{supervisor_process}::workers does not accept named arguments"),
                span: span.clone(),
                hint: None,
            });
        }
        if args.len() != 2 {
            return Err(TypeError {
                structured: Some(self.argument_contract_diagnostic(
                    TypeDiagnosticReason::ArityMismatch,
                    &format!("{supervisor_process}::workers"),
                    None,
                    2,
                    args.len(),
                    span,
                    DiagnosticOrigin::Call,
                )),
                message: format!(
                    "{}::workers expects 2 argument(s), got {}",
                    supervisor_process,
                    args.len()
                ),
                span: span.clone(),
                hint: Some("Pass a worker init route and WorkerStrategy.".into()),
            });
        }
        if self.in_compiler_generated_supervisor_wrapper(&supervisor_process, "workers") {
            return Ok(None);
        }
        if !self.supervisor_workers_allowed_in_current_context() {
            return Err(self.process_policy_error(
                "supervisor workers can only be called from Singleton GenServer @init",
                None,
                span,
                Some("Create worker sets in the pool Singleton GenServer @init and keep the handle in state.".into()),
            ));
        }
        let ResolvedRecordLitArg::Positional(worker_init) = &args[0] else {
            unreachable!("validated named arguments above")
        };
        let ResolvedRecordLitArg::Positional(strategy_expr) = &args[1] else {
            unreachable!("validated named arguments above")
        };
        let (worker_process, typed_init) = self.synthesize_supervisor_worker_init(worker_init)?;
        match self.resolve_ty(&typed_init.ty) {
            Ty::Func(params, _) if params.is_empty() => {}
            other => {
                return Err(self.process_policy_error(
                    format!(
                        "supervisor workers expects a zero-argument worker init route, got {}",
                        self.ty_name(&other)
                    ),
                    Some(&other),
                    &typed_init.span,
                    Some(
                        "Pass a generated worker init reference like `MyWorker::init(args)`."
                            .into(),
                    ),
                ));
            }
        }
        let strategy_ty = self
            .env
            .lookup_type_def("WorkerStrategy")
            .map(|def| {
                Ty::Struct(
                    def.name.clone(),
                    NominalType::new(
                        def.type_param_vars.iter().copied().map(Ty::Var).collect(),
                        def.fields.clone(),
                    ),
                )
            })
            .ok_or_else(|| self.typecheck_invariant_error("WorkerStrategy type metadata", span))?;
        let typed_strategy = self.check_node_with_expected(strategy_expr, Some(&strategy_ty))?;
        if !self.types_compatible(&strategy_ty, &typed_strategy.ty)? {
            return Err(self.type_relation_error(
                &strategy_ty,
                &typed_strategy.ty,
                self.type_fact(SourceRole::Expected, span, &strategy_ty),
                self.type_fact(SourceRole::Value, &typed_strategy.span, &typed_strategy.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                &format!("{supervisor_process}::workers"),
                1,
            ));
        }
        Ok(Some(TypedNode {
            ty: Ty::Result(
                Box::new(Ty::Enum(
                    "Workers".into(),
                    vec![Ty::pid(worker_process.clone())],
                )),
                Box::new(Ty::Error),
            ),
            span: span.clone(),
            node: TypedInner::SupervisorWorkers {
                supervisor_process,
                worker_process,
                init: Box::new(typed_init),
                strategy: Box::new(typed_strategy),
            },
        }))
    }

    fn supervisor_workers_allowed_in_current_context(&self) -> bool {
        let Some(spec) = self.current_process_spec() else {
            return false;
        };
        if spec.spec.kind != spire::ast::ProcessKind::GenServer
            || spec.spec.instance != spire::ast::ProcessInstance::Singleton
        {
            return false;
        }
        let Some(symbol) = self.current_function_symbol.as_deref() else {
            return false;
        };
        let Some((_, handler)) = symbol.rsplit_once("::") else {
            return false;
        };
        handler == "__agent_init"
    }

    fn in_compiler_generated_supervisor_wrapper(
        &self,
        supervisor_process: &str,
        method: &str,
    ) -> bool {
        let Some(symbol) = self.current_function_symbol.as_deref() else {
            return false;
        };
        let expected = format!("{}::{method}", Self::surface_name(supervisor_process));
        Self::surface_name(symbol) == expected
    }

    fn ensure_supervisor_registered_for_surface(
        &self,
        span: &Span,
        supervisor_process: &str,
        method: &str,
    ) -> Result<(), TypeError> {
        if self.in_compiler_generated_supervisor_wrapper(supervisor_process, method) {
            return Ok(());
        }
        if Self::surface_name(supervisor_process) == "DynamicSupervisor" {
            return Ok(());
        }
        let registered = self.boot_plan.entries.iter().any(|entry| {
            Self::surface_name(&entry.process_name) == Self::surface_name(supervisor_process)
        }) || self.boot_plan.supervisors.iter().any(|entry| {
            Self::surface_name(&entry.process_name) == Self::surface_name(supervisor_process)
        });
        if registered {
            return Ok(());
        }
        Err(self.policy_error(
            TypeDiagnosticReason::CompilePolicyViolation,
            diagnostics::TypePolicy::CompileUnitAvailability,
            Some(format!(
                "supervisor surface `{}::{method}` is not available in this compile unit; add the supervisor to supervisor_init",
                Self::surface_name(supervisor_process)
            )),
            None,
            None,
            Some("compile unit".into()),
            None,
            span,
            Some("Register custom supervisors in supervisor_init before using their generated supervisor surface.".into()),
        ))
    }

    fn try_check_worker_message_template_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Ok(None);
        }
        let Resolved::Var(_, id) = func else {
            return Ok(None);
        };
        let qualified = id.qualified_name.as_deref().unwrap_or(&id.name);
        let Some((process_name, _method_name)) = qualified.rsplit_once("::") else {
            return Ok(None);
        };
        let Some(process_name) = self
            .process_specs
            .iter()
            .find(|spec| {
                spec.process_name == process_name
                    && spec.spec.instance == spire::ast::ProcessInstance::Worker
            })
            .map(|spec| spec.process_name.clone())
        else {
            return Ok(None);
        };
        let typed_func = self.check_node(func)?;
        let func_ty = self.resolve_ty(&typed_func.ty);
        let (params, ret) = match &func_ty {
            Ty::UserFunc { params, ret, .. } => (params.as_slice(), ret.clone()),
            Ty::BuiltinFunc { params, ret, .. } => (params.as_slice(), ret.clone()),
            _ => return Ok(None),
        };
        let Some((first_param, remaining_params)) = params.split_first() else {
            return Ok(None);
        };
        let Ty::Pid(pid_process) = self.resolve_ty(first_param) else {
            return Ok(None);
        };
        if !matches!(pid_process.as_ref(), Ty::ProcessMarker(name) if name == &process_name) {
            return Ok(None);
        }
        if args.len() != remaining_params.len() {
            return Ok(None);
        }
        let typed_args: Vec<TypedNode> = args
            .iter()
            .zip(remaining_params.iter())
            .map(|(arg, expected)| match arg {
                ResolvedRecordLitArg::Positional(expr) => {
                    self.check_node_with_expected(expr, Some(expected))
                }
                ResolvedRecordLitArg::Named(_, _) => unreachable!("validated above"),
            })
            .collect::<Result<Vec<_>, _>>()?;
        for (expected, actual) in remaining_params.iter().zip(typed_args.iter()) {
            if !self.types_compatible(expected, &actual.ty)? {
                return Ok(None);
            }
        }
        Ok(Some(TypedNode {
            ty: Ty::Func(vec![Ty::pid(process_name)], ret),
            span: span.clone(),
            node: TypedInner::InjectCall(Box::new(typed_func), typed_args),
        }))
    }

    fn try_check_singleton_explicit_pid_app(
        &mut self,
        span: &Span,
        func: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<Option<TypedNode>, TypeError> {
        if args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(_, _)))
        {
            return Ok(None);
        }
        let Resolved::Var(_, id) = func else {
            return Ok(None);
        };
        let qualified = id.qualified_name.as_deref().unwrap_or(&id.name);
        let Some((process_name, method_name)) = qualified.rsplit_once("::") else {
            return Ok(None);
        };
        if method_name == "pid" {
            return Ok(None);
        }
        let Some(process_name) = self
            .process_specs
            .iter()
            .find(|spec| {
                Self::surface_name(&spec.process_name) == Self::surface_name(process_name)
                    && spec.spec.instance == spire::ast::ProcessInstance::Singleton
            })
            .map(|spec| spec.process_name.clone())
        else {
            return Ok(None);
        };

        let typed_func = self.check_node(func)?;
        let func_ty = self.resolve_ty(&typed_func.ty);
        let (params, ret) = match &func_ty {
            Ty::UserFunc { params, ret, .. } => (params.as_slice(), ret.clone()),
            Ty::BuiltinFunc { params, ret, .. } => (params.as_slice(), ret.clone()),
            _ => return Ok(None),
        };
        if args.len() != params.len() + 1 {
            return Ok(None);
        }

        let pid_ty = Ty::pid(process_name.clone());
        let typed_pid = match &args[0] {
            ResolvedRecordLitArg::Positional(expr) => {
                self.check_node_with_expected(expr, Some(&pid_ty))?
            }
            ResolvedRecordLitArg::Named(_, _) => unreachable!("validated above"),
        };
        if !self.types_compatible(&pid_ty, &typed_pid.ty)? {
            return Ok(None);
        }

        let typed_args: Vec<TypedNode> = args[1..]
            .iter()
            .zip(params.iter())
            .map(|(arg, expected)| match arg {
                ResolvedRecordLitArg::Positional(expr) => {
                    self.check_node_with_expected(expr, Some(expected))
                }
                ResolvedRecordLitArg::Named(_, _) => unreachable!("validated above"),
            })
            .collect::<Result<Vec<_>, _>>()?;
        for (expected, actual) in params.iter().zip(typed_args.iter()) {
            if !self.types_compatible(expected, &actual.ty)? {
                return Ok(None);
            }
        }

        let rewritten_call = TypedNode {
            ty: (*ret).clone(),
            span: span.clone(),
            node: TypedInner::App(Box::new(typed_func), typed_args),
        };
        Ok(Some(TypedNode {
            ty: (*ret).clone(),
            span: span.clone(),
            node: TypedInner::Block(vec![typed_pid, rewritten_call]),
        }))
    }

    fn supervisor_spawn_target(&self, func: &Resolved) -> Option<String> {
        self.supervisor_intrinsic_target(func, "spawn")
    }

    fn supervisor_intrinsic_target(&self, func: &Resolved, method: &str) -> Option<String> {
        let Resolved::Var(_, id) = func else {
            return None;
        };
        let qualified = id.qualified_name.as_deref()?;
        let process_name = qualified.strip_suffix(&format!("::{method}"))?;
        if Self::surface_name(process_name) == "Supervisor" {
            return None;
        }
        // DynamicSupervisor is the compiler-managed root supervisor surface.
        // It is supplied by the standard library, but it is not necessarily
        // present in the current suffix's process-spec list. Keep its calls
        // on the intrinsic lowering path so a generic return-only wrapper is
        // never left as an unmaterialized user-function index.
        if Self::surface_name(process_name) == "DynamicSupervisor" {
            return Some(process_name.to_string());
        }
        self.supervisor_spec_by_name(process_name)
            .map(|spec| spec.process_name.clone())
    }

    fn supervisor_spec_by_name(&self, process_name: &str) -> Option<&TypedProcessSpec> {
        self.process_specs.iter().find(|spec| {
            Self::surface_name(&spec.process_name) == Self::surface_name(process_name)
                && matches!(
                    spec.spec.kind,
                    spire::ast::ProcessKind::Supervisor
                        | spire::ast::ProcessKind::DynamicSupervisor
                        | spire::ast::ProcessKind::RuntimeSupervisor
                )
        })
    }

    fn worker_process_spec_for_init_route<'a>(
        &'a self,
        qualified: &str,
    ) -> Option<(
        &'a TypedProcessSpec,
        &'a spire::ast::ProcessRuntimeHandlerSpec,
    )> {
        self.process_specs.iter().find_map(|spec| {
            if spec.spec.instance != spire::ast::ProcessInstance::Worker {
                return None;
            }
            spec.spec
                .handler_specs
                .iter()
                .find(|handler| {
                    handler.kind == spire::ast::ProcessRuntimeHandlerKind::Init
                        && Self::surface_name(qualified)
                            == Self::surface_name(&format!(
                                "{}::{}",
                                spec.process_name, handler.name
                            ))
                })
                .map(|handler| (spec, handler))
        })
    }

    fn worker_process_spec_for_internal_init_uid(&self, uid: u32) -> Option<&TypedProcessSpec> {
        self.process_specs.iter().find(|spec| {
            spec.spec.instance == spire::ast::ProcessInstance::Worker && spec.init_uid == uid
        })
    }

    fn synthesize_supervisor_worker_init(
        &mut self,
        worker_init: &Resolved,
    ) -> Result<(String, TypedNode), TypeError> {
        let span = self.resolved_span(worker_init).clone();
        if let Resolved::Closure(_, params, _, body)
        | Resolved::ExtractorClosure(_, params, _, body)
        | Resolved::CaptureClosure(_, params, _, body) = worker_init
        {
            if params.is_empty() {
                if let Resolved::App(_, func, _) = body.as_ref() {
                    if let Resolved::Var(_, id) = func.as_ref() {
                        if let Some(process_spec) =
                            self.worker_process_spec_for_internal_init_uid(id.unique_id)
                        {
                            let process_name = process_spec.process_name.clone();
                            let typed_init = self.check_node(worker_init)?;
                            return Ok((process_name, typed_init));
                        }
                    }
                }
            }
        }
        let Resolved::App(_, func, args) = worker_init else {
            return Err(self.process_policy_error(
                "supervisor spawn expects a worker init route reference",
                None,
                &span,
                Some("Use `MyWorker::init(args)`.".into()),
            ));
        };
        let Resolved::Var(_, id) = func.as_ref() else {
            return Err(self.process_policy_error(
                "supervisor spawn expects a worker init route reference",
                None,
                &span,
                Some("Use `MyWorker::init(args)`.".into()),
            ));
        };
        let qualified = id.qualified_name.as_deref().unwrap_or(&id.name);
        let Some((process_spec, init_handler)) = self.worker_process_spec_for_init_route(qualified)
        else {
            return Err(self.process_policy_error(
                "supervisor spawn expects a worker init route reference",
                None,
                &span,
                Some("Use `MyWorker::init(args)`.".into()),
            ));
        };
        let process_name = process_spec.process_name.clone();
        let internal_name = init_handler.internal_name.clone();
        let init_uid = process_spec.init_uid;
        let synthetic = Resolved::Closure(
            span.clone(),
            Vec::new(),
            Vec::new(),
            Box::new(Resolved::App(
                span.clone(),
                Box::new(Resolved::Var(
                    span.clone(),
                    ResolvedId {
                        name: internal_name.clone(),
                        qualified_name: Some(format!("{}::{}", process_name, internal_name)),
                        symbol_info: None,
                        unique_id: init_uid,
                        compiler_generated: true,
                        span: span.clone(),
                    },
                )),
                args.clone(),
            )),
        );
        let typed_init = self.check_node(&synthetic)?;
        Ok((process_name, typed_init))
    }

    fn check_process_context_handler(
        &mut self,
        span: &Span,
        slot: &str,
    ) -> Result<TypedNode, TypeError> {
        let Some(process_name) = self.current_process_name() else {
            return Err(self.policy_error(
                TypeDiagnosticReason::ProcessHandlerScope,
                diagnostics::TypePolicy::ProcessHandlerScope,
                Some("ctx.<slot> is only available inside process handlers".into()),
                None,
                None,
                None,
                None,
                span,
                Some("Use ctx.<slot> inside @init/@get/@set/@call/@cast bodies.".into()),
            ));
        };
        let Some(capability) = self
            .process_handler_dependencies
            .get(&process_name)
            .and_then(|slots| slots.get(slot))
            .cloned()
        else {
            return Err(self.policy_error(
                TypeDiagnosticReason::ProcessHandlerScope,
                diagnostics::TypePolicy::ProcessHandlerScope,
                Some(format!(
                    "handler slot `{}` is not declared for process `{}`",
                    slot,
                    Self::surface_name(&process_name)
                )),
                None,
                None,
                None,
                None,
                span,
                Some("Declare the slot in meta.handlers before using ctx.<slot>.".into()),
            ));
        };
        Ok(TypedNode {
            ty: Ty::pid(Self::canonical_user_type_name(&capability)),
            span: span.clone(),
            node: TypedInner::ProcessContextHandler {
                process_name,
                slot: slot.to_string(),
            },
        })
    }

    fn check_extractor_closure(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected: Option<&Ty>,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        if params.is_empty() {
            return Err(TypeError::new(
                "ExtractorClosure requires at least one input",
                span.clone(),
            ));
        }
        let signature = match expected.map(|ty| self.resolve_ty(ty)) {
            Some(Ty::ExtractorClosure(signature)) => *signature,
            Some(Ty::Var(_)) | None => Ty::Func(
                params
                    .iter()
                    .map(|param| match &param.ty {
                        Some(ty) => {
                            self.resolve_ast_ty_in_context(ty, self.local_type_syntax_context())
                        }
                        None => Ok(self.env.fresh_tyvar()),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
                Box::new(Ty::MatchResult(Box::new(self.env.fresh_tyvar()))),
            ),
            Some(other) => {
                return Err(TypeError::new(
                    format!("Expected {}, got ExtractorClosure", self.ty_name(&other)),
                    span.clone(),
                ));
            }
        };
        let Ty::Func(_, ret) = &signature else {
            return Err(TypeError::new(
                "ExtractorClosure requires a function signature",
                span.clone(),
            ));
        };
        if !matches!(ret.as_ref(), Ty::MatchResult(_)) {
            return Err(TypeError::new(
                "ExtractorClosure must return MatchResult",
                span.clone(),
            ));
        }
        self.check_closure_with_kind(
            span,
            params,
            captures,
            body,
            Some(&signature),
            expected_relation,
            CallableContext::ExtractorClosure,
        )
    }

    fn check_closure(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected: Option<&Ty>,
        expected_relation: Option<&ExpectedTypeRelation>,
    ) -> Result<TypedNode, TypeError> {
        let saved_capture_kind = self.is_capture_closure;
        self.is_capture_closure = false;
        let result = self.check_closure_with_kind(
            span,
            params,
            captures,
            body,
            expected,
            expected_relation,
            CallableContext::Closure,
        );
        self.is_capture_closure = saved_capture_kind;
        result
    }

    fn check_closure_with_kind(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected: Option<&Ty>,
        expected_relation: Option<&ExpectedTypeRelation>,
        kind: CallableContext,
    ) -> Result<TypedNode, TypeError> {
        let saved_function_return_ty = self.function_return_ty.clone();
        let saved_function_return_origin = self.function_return_origin.take();
        let saved_current_function_symbol = self.current_function_symbol.clone();
        let saved_current_impl_struct_target = self.current_impl_struct_target.clone();
        let saved_current_private_field_owner = self.current_private_field_owner.clone();
        let saved_callable_context = self.callable_context;
        self.callable_context = kind;
        self.function_return_ty = Some(match expected {
            Some(Ty::Func(_, expected_ret)) => expected_ret.as_ref().clone(),
            _ => self.env.fresh_tyvar(),
        });
        let saved_closure_depth = self.closure_depth;
        let saved_facet_bindings = self.facet_bindings.clone();

        let outer_ids = self
            .env
            .vars
            .iter()
            .filter_map(|(id, ty)| {
                (!matches!(ty, Ty::UserFunc { .. } | Ty::BuiltinFunc { .. })
                    && !self.env.type_constructor_ids.contains(id))
                .then_some(*id)
            })
            .collect::<HashSet<_>>();
        self.env.push_var_scope();
        self.closure_depth = self.closure_depth.saturating_add(1);
        let result = (|| -> Result<TypedNode, TypeError> {
            let mut typed_params = Vec::new();
            let param_tys = match expected {
                Some(Ty::Func(expected_params, _)) => {
                    if expected_params.len() != params.len() {
                        return Err(self.closure_arity_error(
                            expected_params.len(),
                            params.len(),
                            span,
                        ));
                    }
                    expected_params.clone()
                }
                Some(other) => {
                    return Err(TypeError::from_structured(StructuredDiagnostic {
                        reason: TypeDiagnosticReason::CallableShapeMismatch.into(),
                        origin: DiagnosticOrigin::Call,
                        data: DiagnosticData::CallableShape(diagnostics::CallableShapeData {
                            callable: "closure".into(),
                            actual_type: None,
                            expected_arity: None,
                            actual_arity: Some(params.len() as u32),
                        }),
                        primary: SourceFact::untyped(
                            SourceRole::CallTarget,
                            SourceId(0),
                            span.clone(),
                        ),
                        related: vec![self.type_fact(SourceRole::Expected, span, other)],
                        remediation: None,
                    }));
                }
                None => params
                    .iter()
                    .map(|param| match &param.ty {
                        Some(ast_ty) => {
                            self.resolve_ast_ty_in_context(ast_ty, self.local_type_syntax_context())
                        }
                        None => Ok(self.env.fresh_tyvar()),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            };

            for (param, param_ty) in params.iter().zip(param_tys.iter()) {
                let param_ty = if let Some(ast_ty) = &param.ty {
                    let annotated =
                        self.resolve_ast_ty_in_context(ast_ty, self.local_type_syntax_context())?;
                    self.assert_type_relation(
                        param_ty,
                        &annotated,
                        self.type_fact(SourceRole::Expected, span, param_ty),
                        self.type_fact(
                            SourceRole::Annotation,
                            Self::ast_ty_span(ast_ty),
                            &annotated,
                        ),
                        TypeDiagnosticReason::AnnotationTypeMismatch,
                        DiagnosticOrigin::Annotation,
                        &param.id.name,
                        typed_params.len() as u32,
                    )?;
                    self.resolve_ty(&annotated)
                } else {
                    self.resolve_ty(param_ty)
                };
                if !param.id.compiler_generated
                    && (param.ty.is_some()
                        || expected_relation.is_some_and(|relation| {
                            matches!(
                                relation.origin,
                                DiagnosticOrigin::Annotation | DiagnosticOrigin::Return
                            )
                        }))
                {
                    self.explicit_closure_parameters
                        .insert(param.id.unique_id, param_ty.clone());
                }
                self.env.bind_var(param.id.unique_id, param_ty.clone());
                typed_params.push(TypedClosureParam {
                    id: param.id.clone(),
                    ty: param_ty,
                });
            }

            for capture in captures {
                if self
                    .pattern_binding_aliases
                    .contains_key(&capture.unique_id)
                {
                    continue;
                }
                if let Some(ty) = self.env.lookup_var(capture.unique_id).cloned() {
                    let resolved_ty = self.resolve_ty(&ty);
                    self.env.bind_var(capture.unique_id, resolved_ty);
                }
            }

            let profile = self.profiler.start();
            let body_is_result_constructor = match body {
                Resolved::ConstructorCall(_, _, _) | Resolved::EnumConstructorCall(_, _, _, _) => {
                    true
                }
                Resolved::App(_, func, _) => {
                    matches!(func.as_ref(), Resolved::Var(_, id) if self.lookup_enum_variant_by_constructor_id(id.unique_id).is_some())
                }
                _ => false,
            };
            let typed_body = if kind == CallableContext::ExtractorClosure
                || body_is_result_constructor
                || matches!(
                    body,
                    Resolved::If(..)
                        | Resolved::IfLet(..)
                        | Resolved::LazyApp(_, LazyCaptureKind::If | LazyCaptureKind::IfThen, _, _)
                )
                || self.body_tail_is_return_type_argument_call(body)
            {
                if let Some(Ty::Func(_, expected_ret)) = expected {
                    self.check_node_with_expected_relation(
                        body,
                        Some(expected_ret.as_ref()),
                        expected_relation,
                    )?
                } else {
                    self.check_node(body)?
                }
            } else {
                self.check_node(body)?
            };
            self.profiler.finish(ProfileEvent::ClosureBody, profile);
            let typed_body = *self
                .concretize_pending_trait_calls(typed_body)
                .map_err(|error| *error)?;
            if expected.is_none()
                && self.current_function_symbol.is_none()
                && !self.local_callable_obligations_depend_on(&typed_body, &param_tys)
            {
                if let Some((trait_name, method_name, subject, pending_span)) =
                    self.first_pending_trait_helper(&typed_body)
                {
                    return Err(self.pending_trait_helper_error(
                        trait_name,
                        method_name,
                        subject,
                        pending_span,
                    ));
                }
            }
            if matches!(typed_body.ty, Ty::Facet(..)) {
                return Err(self.policy_error(
                    TypeDiagnosticReason::FacetCompileTimeOnly,
                    diagnostics::TypePolicy::FacetStageRestriction,
                    Some(
                        "Facet is compile-time only in Stage1 and cannot be returned from closures"
                            .into(),
                    ),
                    None,
                    Some(&typed_body.ty),
                    Some("Stage1".into()),
                    None,
                    &typed_body.span,
                    Some("Use Facet::view(...) inside the closure instead.".into()),
                ));
            }
            // The closure result type is needed immediately for inference, but
            // the body tree itself is normalized by the enclosing typed node.
            let body_ty = self.resolve_ty(&typed_body.ty);
            if let Some(Ty::Func(_, expected_ret)) = expected {
                let expected_ret = self.resolve_ty(expected_ret);
                if kind == CallableContext::ExtractorClosure || matches!(expected_ret, Ty::Unit) {
                    self.assert_type_relation(
                        &expected_ret,
                        &body_ty,
                        self.type_fact(SourceRole::Expected, span, &expected_ret),
                        self.type_fact(SourceRole::Value, &typed_body.span, &body_ty),
                        TypeDiagnosticReason::ReturnTypeMismatch,
                        DiagnosticOrigin::Return,
                        "closure",
                        0,
                    )?;
                }
            }

            let param_tys = typed_params
                .iter()
                .map(|p| self.resolve_ty(&p.ty))
                .collect::<Vec<_>>();
            Ok(TypedNode {
                ty: if kind == CallableContext::ExtractorClosure {
                    Ty::ExtractorClosure(Box::new(Ty::Func(param_tys, Box::new(body_ty))))
                } else {
                    Ty::Func(param_tys, Box::new(body_ty))
                },
                span: span.clone(),
                node: (if kind == CallableContext::ExtractorClosure {
                    TypedInner::ExtractorClosure
                } else {
                    TypedInner::Closure
                })(
                    typed_params
                        .into_iter()
                        .map(|param| TypedClosureParam {
                            id: param.id,
                            ty: self.resolve_ty(&param.ty),
                        })
                        .collect(),
                    Self::finalized_closure_captures(&typed_body, &outer_ids),
                    Box::new(typed_body),
                ),
            })
        })();

        self.env.pop_var_scope();
        self.function_return_ty = saved_function_return_ty;
        self.function_return_origin = saved_function_return_origin;
        self.current_function_symbol = saved_current_function_symbol;
        self.current_impl_struct_target = saved_current_impl_struct_target;
        self.current_private_field_owner = saved_current_private_field_owner;
        self.callable_context = saved_callable_context;
        self.closure_depth = saved_closure_depth;
        self.facet_bindings = saved_facet_bindings;
        result
    }

    fn check_capture_closure(
        &mut self,
        span: &Span,
        params: &[ResolvedClosureParam],
        captures: &[ResolvedId],
        body: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let saved_capture = self.active_lazy_capture.take();
        self.active_lazy_capture =
            ActiveLazyCapture::new(params, expected, self.resolved_span(body).clone());
        let saved_capture_kind = self.is_capture_closure;
        self.is_capture_closure = true;
        let result = self
            .check_closure_with_kind(
                span,
                params,
                captures,
                body,
                expected,
                None,
                CallableContext::Closure,
            )
            .map_err(|error| self.lazy_capture_annotation_error(error));
        self.is_capture_closure = saved_capture_kind;
        self.active_lazy_capture = saved_capture;
        let mut typed = result?;
        let TypedInner::Closure(params, captures, typed_body) = typed.node else {
            return Err(TypeError {
                structured: None,
                message: "Capture closure did not produce a closure node".into(),
                span: span.clone(),
                hint: None,
            });
        };
        let constructor_id = match body {
            Resolved::ConstructorCall(_, id, _) | Resolved::EnumConstructorCall(_, id, _, _)
                if id
                    .symbol_info
                    .as_ref()
                    .and_then(|info| info.capabilities.constructor_capture)
                    == Some(ConstructorCapturePolicy::Ordinary) =>
            {
                Some(id.clone())
            }
            _ => None,
        };
        typed.node = match constructor_id {
            Some(id) => TypedInner::CaptureConstructorClosure(id, params, captures, typed_body),
            None => TypedInner::CaptureClosure(params, captures, typed_body),
        };
        Ok(typed)
    }

    fn check_constructor_capture(
        &mut self,
        span: &Span,
        target: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<Option<TypedNode>, TypeError> {
        let policy = match target {
            Resolved::Var(_, id) | Resolved::EnumConstructorCall(_, id, _, _) => id
                .symbol_info
                .as_ref()
                .and_then(|info| info.capabilities.constructor_capture),
            _ => None,
        };
        let Some(policy) = policy else {
            return Ok(None);
        };
        match policy {
            ConstructorCapturePolicy::CompilerManaged => return Ok(None),
            ConstructorCapturePolicy::Forbidden => {
                let name = match target {
                    Resolved::Var(_, id) | Resolved::EnumConstructorCall(_, id, _, _) => {
                        id.name.clone()
                    }
                    _ => unreachable!("constructor policy was read from a constructor target"),
                };
                return Err(TypeError {
                    structured: None,
                    message: format!("constructor capture is forbidden for `{name}`"),
                    span: span.clone(),
                    hint: None,
                });
            }
            ConstructorCapturePolicy::Ordinary => {}
        }

        let (body, arity) = match target {
            Resolved::EnumConstructorCall(_, id, type_args, _) => {
                let variant = self
                    .lookup_enum_variant_by_constructor_id(id.unique_id)
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: format!("Unknown enum constructor: {}", id.name),
                        span: span.clone(),
                        hint: None,
                    })?;
                (
                    Resolved::EnumConstructorCall(
                        span.clone(),
                        id.clone(),
                        type_args.clone(),
                        Vec::new(),
                    ),
                    variant.payload.len(),
                )
            }
            Resolved::Var(_, id) => {
                if let Some(variant) = self.lookup_enum_variant_by_constructor_id(id.unique_id) {
                    (
                        Resolved::ConstructorCall(span.clone(), id.clone(), Vec::new()),
                        variant.payload.len(),
                    )
                } else {
                    let def = self
                        .env
                        .lookup_type_def(&id.name)
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Unknown constructor type: {}", id.name),
                            span: span.clone(),
                            hint: None,
                        })?;
                    let arity = match def.kind {
                        crate::env::TypeKind::Record => def.fields.len(),
                        crate::env::TypeKind::Struct => {
                            let owner_name =
                                id.qualified_name.as_deref().unwrap_or(id.name.as_str());
                            let new_name = format!("{}::new", owner_name);
                            let new_uid = self.impl_method_uids.get(&new_name).copied().ok_or_else(|| {
                                TypeError {
                                    structured: None,
                                    message: format!(
                                        "Struct `{}` constructor capture requires `{}` but no such method was found",
                                        id.name, new_name
                                    ),
                                    span: span.clone(),
                                    hint: None,
                                }
                            })?;
                            self.callable_signatures
                                .get(&new_uid)
                                .map(|signature| signature.value_arity())
                                .ok_or_else(|| TypeError {
                                    structured: None,
                                    message: format!(
                                        "Struct `{}` constructor capture has no callable signature for `{}`",
                                        id.name, new_name
                                    ),
                                    span: span.clone(),
                                    hint: None,
                                })?
                        }
                        crate::env::TypeKind::Enum => {
                            return Err(TypeError {
                                structured: None,
                                message: format!(
                                    "Enum type `{}` is not a constructor capture target; capture a variant such as `&{}::Variant`",
                                    id.name, id.name
                                ),
                                span: span.clone(),
                                hint: None,
                            });
                        }
                        crate::env::TypeKind::ConcreteError => self
                            .env
                            .error_constructor_inputs
                            .get(&id.unique_id)
                            .ok_or_else(|| {
                                TypeError::new(
                                    "Error constructor input signature is missing",
                                    span.clone(),
                                )
                            })?
                            .len(),
                    };
                    (
                        Resolved::ConstructorCall(span.clone(), id.clone(), Vec::new()),
                        arity,
                    )
                }
            }
            _ => return Ok(None),
        };

        let mut params = Vec::with_capacity(arity);
        let mut body_args = Vec::with_capacity(arity);
        for index in 0..arity {
            let id = ResolvedId {
                name: format!("__constructor_capture_arg_{index}"),
                qualified_name: None,
                symbol_info: None,
                unique_id: Self::next_synthetic_range_uid(),
                compiler_generated: true,
                span: span.clone(),
            };
            body_args.push(ResolvedRecordLitArg::Positional(Resolved::Var(
                span.clone(),
                id.clone(),
            )));
            params.push(ResolvedClosureParam {
                lazy_capture: None,
                id,
                ty: None,
            });
        }

        let body = match body {
            Resolved::ConstructorCall(body_span, id, _) => {
                Resolved::ConstructorCall(body_span, id, body_args)
            }
            Resolved::EnumConstructorCall(body_span, id, type_args, _) => {
                Resolved::EnumConstructorCall(body_span, id, type_args, body_args)
            }
            _ => unreachable!("constructor capture body must be a constructor call"),
        };
        Ok(Some(self.check_capture_closure(
            span,
            &params,
            &[],
            &body,
            expected,
        )?))
    }

    pub(super) fn check_capture(
        &mut self,
        span: &Span,
        target: &Resolved,
        args: &[Resolved],
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        if !args.is_empty() {
            return Err(TypeError {
                structured: None,
                message: "capture calls with arguments must be lowered before type checking".into(),
                span: span.clone(),
                hint: None,
            });
        }

        if self.is_function_curry_callee(target) {
            return Err(TypeError::new(
                "Function::curry cannot be captured as a function value; call it with a callable argument",
                span.clone(),
            ));
        }

        if let Some(mut typed) = self.check_constructor_capture(span, target, expected)? {
            let constructor_id = match target {
                Resolved::Var(_, id) | Resolved::EnumConstructorCall(_, id, _, _) => id.clone(),
                _ => unreachable!("constructor capture target has no constructor identity"),
            };
            match typed.node {
                TypedInner::CaptureConstructorClosure(..) => return Ok(typed),
                TypedInner::CaptureClosure(params, captures, body) => {
                    typed.node = TypedInner::CaptureConstructorClosure(
                        constructor_id,
                        params,
                        captures,
                        body,
                    );
                    return Ok(typed);
                }
                _ => {
                    return Err(TypeError::new(
                        "constructor capture did not produce a capture closure",
                        span.clone(),
                    ));
                }
            }
        }

        if let Some((_, trait_name, method_name)) = self.trait_method_ref(target) {
            let declaration = &self.traits[&trait_name];
            if declaration.standard_lazy_contract
                && declaration.methods[&method_name]
                    .value_parameters
                    .iter()
                    .any(|parameter| Self::lazy_parameter_inner(parameter.ty.syntax()).is_some())
            {
                return Err(TypeError::new(
                    format!("{trait_name}::{method_name} has Lazy arguments and cannot be captured without explicit arguments"),
                    span.clone(),
                ));
            }
            let Some(expected_ty) = expected else {
                if let Resolved::Var(_, id) = target {
                    return Err(self.policy_error(
                        TypeDiagnosticReason::TraitHelperCaptureNeedsExpectedType,
                        diagnostics::TypePolicy::TraitHelperCaptureInference,
                        Some(id.name.clone()),
                        None,
                        None,
                        None,
                        None,
                        span,
                        Some(
                            "Add a callable annotation such as `cmp: (Int, Int -> Ordering) = &compare`, or use the capture inside an expression like `&compare `Function::on` _.field`."
                                .into(),
                        ),
                    ));
                }
                return Err(self.policy_error(
                    TypeDiagnosticReason::TraitHelperCaptureNeedsExpectedType,
                    diagnostics::TypePolicy::TraitHelperCaptureInference,
                    None,
                    None,
                    None,
                    None,
                    None,
                    span,
                    Some(
                        "Add a callable annotation or use the capture where the receiver type can be inferred."
                            .into(),
                    ),
                ));
            };
            let Ty::Func(params, _) = self.resolve_ty(expected_ty) else {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Expected function type, got {}",
                        self.diagnostic_ty_name(&self.resolve_ty(expected_ty))
                    ),
                    span: span.clone(),
                    hint: None,
                });
            };
            let mut closure_params = Vec::with_capacity(params.len());
            let mut body_args = Vec::with_capacity(params.len());
            for index in 0..params.len() {
                let param_id = ResolvedId {
                    name: format!("__trait_helper_arg_{}", index),
                    qualified_name: None,
                    symbol_info: None,
                    unique_id: Self::next_synthetic_range_uid(),
                    compiler_generated: true,
                    span: span.clone(),
                };
                body_args.push(ResolvedRecordLitArg::Positional(Resolved::Var(
                    span.clone(),
                    param_id.clone(),
                )));
                closure_params.push(ResolvedClosureParam {
                    lazy_capture: None,
                    id: param_id,
                    ty: None,
                });
            }
            let synthetic = Resolved::CaptureClosure(
                span.clone(),
                closure_params,
                Vec::new(),
                Box::new(Resolved::App(
                    span.clone(),
                    Box::new(target.clone()),
                    body_args,
                )),
            );
            return self.check_node_with_expected(&synthetic, Some(expected_ty));
        }

        if Self::capture_target_is_facet_path(target) {
            if self.has_concrete_error_facet_root(target) {
                return Err(TypeError::new(
                    "Concrete Error Facet paths cannot be captured",
                    span.clone(),
                ));
            }
            if let Some(expected_ty) = expected {
                let expected_ty_resolved = self.resolve_ty(expected_ty);
                if let Ty::Func(params, _) = &expected_ty_resolved {
                    if params.len() == 1 {
                        let view_id = self.runtime_helper_id("Facet::view", span)?;
                        let param_uid = Self::next_synthetic_range_uid();
                        let param_id = ResolvedId {
                            name: "__facet_capture_arg".to_string(),
                            qualified_name: None,
                            symbol_info: None,
                            unique_id: param_uid,
                            compiler_generated: true,
                            span: span.clone(),
                        };
                        let synthetic = Resolved::CaptureClosure(
                            span.clone(),
                            vec![ResolvedClosureParam {
                                lazy_capture: None,
                                id: param_id.clone(),
                                ty: None,
                            }],
                            Vec::new(),
                            Box::new(Resolved::App(
                                span.clone(),
                                Box::new(Resolved::Var(span.clone(), view_id)),
                                vec![
                                    ResolvedRecordLitArg::Positional(target.clone()),
                                    ResolvedRecordLitArg::Positional(Resolved::Var(
                                        span.clone(),
                                        param_id,
                                    )),
                                ],
                            )),
                        );
                        return self.check_node_with_expected(&synthetic, Some(expected_ty));
                    }
                }
            }
        }

        let explicit_return_type_arguments = Self::explicit_type_args(target);
        let named_target = match target {
            Resolved::ReturnTypeArgumentApply(_, inner, _) => inner.as_ref(),
            other => other,
        };
        let has_callable_signature = match named_target {
            Resolved::Var(_, id) => self.callable_signatures.contains_key(&id.unique_id),
            _ => false,
        };
        let (typed_target, capture_signature) = if has_callable_signature {
            let (mut typed, signature, return_type_arguments) = self
                .instantiate_named_callable_signature(
                    span,
                    named_target,
                    explicit_return_type_arguments.as_deref(),
                )?;
            let expected_return = explicit_return_type_arguments
                .as_ref()
                .and_then(|_| expected)
                .and_then(|expected| match self.resolve_ty(expected) {
                    Ty::Func(_, ret) | Ty::BuiltinFunc { ret, .. } | Ty::UserFunc { ret, .. } => {
                        Some(*ret)
                    }
                    _ => None,
                });
            let constraints = self.call_constraint_set(
                signature,
                return_type_arguments,
                expected_return.as_ref(),
                span,
                &typed.ty,
            );
            self.apply_return_type_argument_constraints(&constraints)?;
            self.apply_expected_call_constraint(
                &constraints,
                span,
                explicit_return_type_arguments.as_deref(),
            )?;
            typed.ty = self.callable_ty_from_signature(&typed.ty, &constraints.signature);
            (typed, Some(constraints.signature))
        } else {
            (self.check_node(target)?, None)
        };
        self.ensure_no_match_result_value(&typed_target.ty, span)?;
        let mut target_ty = self.resolve_ty(&typed_target.ty);
        if let Some(expected_ty) = expected {
            let checkpoint = self.candidate_probe_checkpoint();
            let callable_shape = match &target_ty {
                Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                    Some(Ty::Func(params.clone(), ret.clone()))
                }
                Ty::Func(..) => Some(target_ty.clone()),
                _ => None,
            };
            let compatible = callable_shape
                .as_ref()
                .map(|shape| self.types_compatible(shape, expected_ty))
                .transpose();
            if matches!(compatible, Ok(Some(true))) {
                target_ty = self.resolve_ty(&target_ty);
            } else {
                // Operator checking supplies a provisional callable shape so
                // it can report the mismatch with both operands. A rejected
                // capture probe must not replace that operator diagnostic or
                // leak partial type bindings.
                self.rollback_candidate_probe(checkpoint);
            }
            compatible?;
        }
        if let Ty::Facet(_, source_ty, focus_ty, ..) = &target_ty {
            let view_id = self.runtime_helper_id("Facet::view", span)?;
            let param_uid = Self::next_synthetic_range_uid();
            let param_name = "__facet_capture_arg".to_string();
            let param_id = ResolvedId {
                name: param_name.clone(),
                qualified_name: None,
                symbol_info: None,
                unique_id: param_uid,
                compiler_generated: true,
                span: span.clone(),
            };
            let captures = match target {
                Resolved::Var(_, id) => vec![id.clone()],
                _ => Vec::new(),
            };
            let body = Resolved::App(
                span.clone(),
                Box::new(Resolved::Var(span.clone(), view_id)),
                vec![
                    ResolvedRecordLitArg::Positional(target.clone()),
                    ResolvedRecordLitArg::Positional(Resolved::Var(span.clone(), param_id.clone())),
                ],
            );
            let ret_ty = match &typed_target.node {
                TypedInner::FacetPath(path) if path.may_fail => Ty::Result(
                    Box::new(self.resolve_ty(focus_ty.as_ref())),
                    Box::new(Ty::Error),
                ),
                _ => self.resolve_ty(focus_ty.as_ref()),
            };
            let synthetic = Resolved::CaptureClosure(
                span.clone(),
                vec![ResolvedClosureParam {
                    lazy_capture: None,
                    id: param_id,
                    ty: None,
                }],
                captures,
                Box::new(body),
            );
            let expected = Ty::Func(vec![self.resolve_ty(source_ty.as_ref())], Box::new(ret_ty));
            return self.check_node_with_expected(&synthetic, Some(&expected));
        }
        let (params, ret) = match &target_ty {
            Ty::BuiltinFunc { params, ret, .. } => (params.clone(), ret.as_ref().clone()),
            Ty::UserFunc { params, ret, .. } => (params.clone(), ret.as_ref().clone()),
            Ty::Func(params, ret) => (params.clone(), ret.as_ref().clone()),
            other => {
                return Err(self.callable_shape_error(other, "capture", &typed_target.span, None));
            }
        };
        if let Some(signature) = &capture_signature {
            if let Some(slot) = signature.return_type_arguments.iter().find(|slot| {
                let mut variables = Vec::new();
                match &slot.ty {
                    Ty::SelfApp(items) => {
                        let Some((witness, _)) = Self::constructor_application_parts(items) else {
                            Self::collect_ty_vars(&self.resolve_ty(&slot.ty), &mut variables);
                            return variables.iter().any(|var| !self.rigid_tyvars.contains(var));
                        };
                        let resolved_witness = self.resolve_ty(witness);
                        let carrier = match witness {
                            Ty::Var(var) => {
                                self.constructor_witness_traits.get(var).map(|trait_key| {
                                    self.canonical_constructor_carrier(trait_key, &resolved_witness)
                                })
                            }
                            _ => None,
                        };
                        match carrier {
                            Some(ConstructorCarrierOutcome::Projected(carrier)) => {
                                for captured in carrier.captured_arguments {
                                    self.canonical_waiting_variables(&captured.ty, &mut variables);
                                }
                            }
                            Some(ConstructorCarrierOutcome::Deferred { waiting_on }) => {
                                variables.extend(waiting_on);
                            }
                            Some(ConstructorCarrierOutcome::Rejected { failures }) => {
                                debug_assert!(!failures.is_empty());
                                Self::collect_ty_vars(&resolved_witness, &mut variables);
                            }
                            None => {
                                Self::collect_ty_vars(&resolved_witness, &mut variables);
                            }
                        }
                    }
                    _ => Self::collect_ty_vars(&self.resolve_ty(&slot.ty), &mut variables),
                }
                // The enclosing signature witnesses its own generic inputs;
                // only fresh carrier or captured variables remain ambiguous.
                // Mapped payload variables are ordinary invocation inputs and
                // do not make an otherwise concrete constructor head pending.
                variables.iter().any(|var| !self.rigid_tyvars.contains(var))
            }) {
                let unresolved_ty = self.diagnostic_ty_name(&self.resolve_ty(&slot.ty));
                return Err(TypeError {
                    message: format!(
                        "return type arguments for `{}` cannot be inferred",
                        signature.identity.name
                    ),
                    span: span.clone(),
                    hint: Some(
                        "Provide concrete return type arguments or an expected callable type."
                            .into(),
                    ),
                    structured: Some(StructuredDiagnostic {
                        reason: TypeDiagnosticReason::AmbiguousReturnTypeArgument.into(),
                        origin: DiagnosticOrigin::ReturnTypeArgument {
                            ordinal: slot.ordinal,
                        },
                        data: DiagnosticData::ReturnTypeArgument(
                            diagnostics::ReturnTypeArgumentData {
                                declared_origin: None,
                                value_parameter_origin: None,
                                return_origin: None,
                                left_origin: None,
                                right_origin: Some(SourceFact::typed(
                                    SourceRole::ReturnTypeArgument,
                                    SourceId(0),
                                    span.clone(),
                                    unresolved_ty.clone(),
                                )),
                                required_trait: None,
                                expected_count: None,
                                actual_count: None,
                                callable: signature.identity.name.clone(),
                                ordinal: Some(slot.ordinal),
                                expected_type: Some("concrete return type argument".into()),
                                actual_type: Some(unresolved_ty.clone()),
                            },
                        ),
                        primary: SourceFact::typed(
                            SourceRole::ReturnTypeArgument,
                            SourceId(0),
                            span.clone(),
                            unresolved_ty,
                        ),
                        related: Vec::new(),
                        remediation: None,
                    }),
                });
            }
        }
        Ok(TypedNode {
            ty: Ty::Func(
                params.into_iter().map(|ty| self.resolve_ty(&ty)).collect(),
                Box::new(self.resolve_ty(&ret)),
            ),
            span: span.clone(),
            node: TypedInner::Capture(Box::new(typed_target), Vec::new()),
        })
    }

    pub(super) fn maybe_call_zero_arg_function(
        &self,
        node: TypedNode,
        _call_span: Span,
    ) -> TypedNode {
        match &node.ty {
            Ty::BuiltinFunc { params, ret, .. }
            | Ty::UserFunc { params, ret, .. }
            | Ty::Func(params, ret)
                if params.is_empty() =>
            {
                TypedNode {
                    ty: ret.as_ref().clone(),
                    span: node.span.clone(),
                    node: TypedInner::App(Box::new(node), Vec::new()),
                }
            }
            _ => node,
        }
    }

    fn capture_target_is_facet_path(target: &Resolved) -> bool {
        matches!(
            target,
            Resolved::FieldAccess(_, _, _) | Resolved::FacetSegmentAccess(_, _, _)
        )
    }

    fn unsupported_binop_type_error(op: &BinOp, span: &Span) -> TypeError {
        TypeError {
            structured: None,
            message: format!("Unsupported binary operator in trait lowering: {op:?}"),
            span: span.clone(),
            hint: None,
        }
    }

    pub(super) fn check_binop(
        &mut self,
        span: &Span,
        op: &BinOp,
        left: &Resolved,
        right: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        self.check_binop_with_expected(span, op, left, right, None)
    }

    fn check_binop_with_expected(
        &mut self,
        span: &Span,
        op: &BinOp,
        left: &Resolved,
        right: &Resolved,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        if matches!(op, BinOp::FacetChain) {
            return self.check_arrow_chain(span, left, right, expected);
        }

        let (trait_short, method, token) = match op {
            BinOp::Add => ("Add", "add", "+"),
            BinOp::Sub => ("Sub", "sub", "-"),
            BinOp::Mul => ("Mul", "mul", "*"),
            BinOp::Div(_) => ("Div", "safe_div", "/"),
            BinOp::Mod(_) => ("Mod", "safe_mod", "%"),
            BinOp::Eq => ("Eq", "eq", "=="),
            BinOp::Neq => ("Eq", "neq", "!="),
            BinOp::Lt => ("Compare", "lt", "<"),
            BinOp::Lte => ("Compare", "lte", "<="),
            BinOp::Gt => ("Compare", "gt", ">"),
            BinOp::Gte => ("Compare", "gte", ">="),
            BinOp::Concat => ("Concat", "concat", "++"),
            BinOp::Choice => ("Alternative", "choose", "<|>"),
            BinOp::FacetChain => return Err(Self::unsupported_binop_type_error(op, span)),
        };
        let trait_name = self
            .trait_key_by_short_name(trait_short)
            .ok_or_else(|| TypeError::new(format!("Unknown trait: {trait_short}"), span.clone()))?;
        self.check_trait_invocation_with_result_context(
            span,
            &trait_name,
            method,
            &[
                ResolvedRecordLitArg::Positional(left.clone()),
                ResolvedRecordLitArg::Positional(right.clone()),
            ],
            None,
            // A plain outside expectation cannot determine the Self payload of
            // a Result-producing operator. Preserve compatible Result context
            // for generic payload inference; outer assertions report plain mismatch.
            if matches!(op, BinOp::Div(_) | BinOp::Mod(_)) {
                expected.filter(|ty| matches!(self.resolve_ty(ty), Ty::Result(..)))
            } else {
                expected
            },
            None,
            None,
            None,
            None,
            None,
            None,
            matches!(op, BinOp::Div(_) | BinOp::Mod(_)),
        )
        .and_then(|mut typed| {
            if let TypedInner::TraitCall { origin, args, .. } = &mut typed.node {
                let comparison = match op {
                    BinOp::Lt => Some(ComparisonOperator::Lt),
                    BinOp::Lte => Some(ComparisonOperator::Lte),
                    BinOp::Gt => Some(ComparisonOperator::Gt),
                    BinOp::Gte => Some(ComparisonOperator::Gte),
                    _ => None,
                };
                if let Some(op) = comparison {
                    *origin = TraitCallOrigin::Comparison {
                        op,
                        lhs_ty: args[0].ty.clone(),
                        rhs_ty: args[1].ty.clone(),
                    };
                }
            }
            self.record_safe_operator_signature(op, &typed)?;
            Ok(typed)
        })
        .map_err(|mut error| {
            if let Some(diagnostic) = &mut error.structured {
                if diagnostic.origin == DiagnosticOrigin::TraitCall
                    && (diagnostic.primary.span == *self.resolved_span(left)
                        || diagnostic.primary.span == *self.resolved_span(right))
                {
                    diagnostic.origin = DiagnosticOrigin::Operator {
                        operator: token.into(),
                    };
                    diagnostic.map_source_facts(|fact| {
                        if fact.span == *self.resolved_span(left) {
                            fact.role = SourceRole::LeftValue;
                        } else if fact.span == *self.resolved_span(right) {
                            fact.role = SourceRole::RightValue;
                        }
                    });
                }
            }
            error
        })
    }

    /// Attach provenance only after a concrete implementation was selected.
    /// Declaration syntax preserves an authored error contract; value types
    /// deliberately keep their normal Result<T> display.
    fn record_safe_operator_signature(
        &mut self,
        op: &BinOp,
        typed: &TypedNode,
    ) -> Result<(), TypeError> {
        let (symbol, operator_span) = match op {
            BinOp::Div(span) => ("/", span),
            BinOp::Mod(span) => ("%", span),
            _ => return Ok(()),
        };
        let TypedInner::TraitCall {
            dispatch,
            args,
            method_name,
            obligation,
            ..
        } = &typed.node
        else {
            return Err(self.typecheck_invariant_error("safe operator trait call", operator_span));
        };
        let instantiation = match dispatch {
            TraitDispatch::Selected(instantiation) => instantiation,
            // Bounded generics are checked before a concrete implementation is known.
            TraitDispatch::Pending => return Ok(()),
            TraitDispatch::Static(_) => {
                return Err(self.typecheck_invariant_error(
                    "safe operator selected declaration",
                    operator_span,
                ));
            }
        };
        let mut variables = Vec::new();
        Self::collect_ty_vars(&self.resolve_ty(&typed.ty), &mut variables);
        for argument in args {
            Self::collect_ty_vars(&self.resolve_ty(&argument.ty), &mut variables);
        }
        if !variables.is_empty() {
            // A selected generic implementation can still contain unresolved caller
            // inputs; its signature is not a concrete diagnostic fact yet.
            return Ok(());
        }
        let TraitImplementationId::Declared { declaration, .. } = &instantiation.implementation
        else {
            return Err(self.typecheck_invariant_error(
                "safe operator implementation declaration",
                operator_span,
            ));
        };
        let implementation = self
            .trait_impls
            .values()
            .find(|info| info.declaration_key == *declaration)
            .ok_or_else(|| {
                self.typecheck_invariant_error(
                    "safe operator implementation metadata",
                    operator_span,
                )
            })?;
        let method = implementation.methods.get(method_name).ok_or_else(|| {
            self.typecheck_invariant_error("safe operator method metadata", operator_span)
        })?;
        let mut result = self.diagnostic_ty_name(&self.resolve_ty(&typed.ty));
        if let Some(return_syntax) = method.ret_ty.as_ref() {
            if let AstTy::Generic(_, name, arguments) = return_syntax.syntax() {
                if Self::surface_name(name) == "Result" && arguments.len() == 2 {
                    self.resolve_error_marker_type(&arguments[1])?;
                    let AstTy::Named(_, authored_error) = &arguments[1] else {
                        return Err(self.typecheck_invariant_error(
                            "safe operator authored error marker",
                            operator_span,
                        ));
                    };
                    let Ty::Result(ok, _) = self.resolve_ty(&typed.ty) else {
                        return Err(self.typecheck_invariant_error(
                            "safe operator Result signature",
                            operator_span,
                        ));
                    };
                    result = format!(
                        "Result<{}, {}>",
                        self.diagnostic_ty_name(&ok),
                        Self::surface_name(authored_error)
                    );
                }
            }
        }
        let params = args
            .iter()
            .map(|argument| self.diagnostic_ty_name(&self.resolve_ty(&argument.ty)))
            .collect::<Vec<_>>()
            .join(", ");
        let mut fact = SourceFact::typed(
            SourceRole::OperatorSignature,
            diagnostics::SourceId(0),
            operator_span.clone(),
            format!("({params}) -> {result}"),
        );
        fact.declaration_identity = Some(diagnostics::DeclarationIdentity {
            owner: obligation.trait_id.clone(),
            name: symbol.into(),
        });
        self.safe_operator_results
            .insert((typed.span.start, typed.span.end), fact);
        Ok(())
    }

    /// Grouping and the final expression of a block preserve the produced value.
    fn propagate_safe_operator_result(&mut self, from: &Span, to: &Span) {
        if let Some(fact) = self
            .safe_operator_results
            .get(&(from.start, from.end))
            .cloned()
        {
            self.safe_operator_results.insert((to.start, to.end), fact);
        }
    }

    fn check_arrow_chain(
        &mut self,
        span: &Span,
        left: &Resolved,
        right: &Resolved,
        _expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        self.check_facet_compose_intrinsic(
            span,
            &[
                ResolvedRecordLitArg::Positional(left.clone()),
                ResolvedRecordLitArg::Positional(right.clone()),
            ],
        )
    }

    pub(super) fn check_list_nil(&mut self, span: &Span) -> Result<TypedNode, TypeError> {
        let tv = self.env.fresh_tyvar();
        Ok(TypedNode {
            ty: Ty::List(Box::new(tv)),
            span: span.clone(),
            node: TypedInner::ListNil,
        })
    }

    pub(super) fn check_list_cons(
        &mut self,
        span: &Span,
        head: &Resolved,
        tail: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let typed_head = self.check_node(head)?;
        let typed_tail = self.check_node(tail)?;
        self.ensure_no_runtime_facet_value(&typed_head, "List construction")?;
        self.ensure_no_runtime_facet_value(&typed_tail, "List construction")?;
        let tail_elem_ty = match &typed_tail.ty {
            Ty::List(inner) => inner.as_ref().clone(),
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!("list tail must be List<...>, got {}", self.ty_name(other)),
                    span: typed_tail.span.clone(),
                    hint: Some("Use `[head, ..tail]` with a list tail value".into()),
                });
            }
        };

        if !self.types_compatible(&typed_head.ty, &tail_elem_ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "expected {}, got {}",
                    self.ty_name(&tail_elem_ty),
                    self.ty_name(&typed_head.ty)
                ),
                span: typed_head.span.clone(),
                hint: Some("List head and tail element types must match".into()),
            });
        }

        let elem_ty = self.resolve_ty(&tail_elem_ty);
        Ok(TypedNode {
            ty: Ty::List(Box::new(elem_ty.clone())),
            span: span.clone(),
            node: TypedInner::ListCons(Box::new(typed_head), Box::new(typed_tail)),
        })
    }

    pub(super) fn check_list_literal(
        &mut self,
        span: &Span,
        elems: &[Resolved],
    ) -> Result<TypedNode, TypeError> {
        if elems.is_empty() {
            return self.check_list_nil(span);
        }

        let typed_elems: Vec<TypedNode> = elems
            .iter()
            .map(|e| self.check_node(e))
            .collect::<Result<Vec<_>, _>>()?;
        for typed in &typed_elems {
            self.ensure_no_runtime_facet_value(typed, "List literal")?;
        }

        let elem_ty = typed_elems[0].ty.clone();
        for te in typed_elems.iter().skip(1) {
            if !self.types_compatible(&elem_ty, &te.ty)? {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "expected {}, got {}",
                        self.ty_name(&elem_ty),
                        self.ty_name(&te.ty)
                    ),
                    span: te.span.clone(),
                    hint: Some("All list elements must have the same type".into()),
                });
            }
        }

        Ok(TypedNode {
            ty: Ty::List(Box::new(elem_ty)),
            span: span.clone(),
            node: TypedInner::ListLiteral(typed_elems),
        })
    }

    pub(super) fn check_hash_map_literal(
        &mut self,
        span: &Span,
        entries: &[sigil::resolved::ResolvedHashMapLiteralEntry],
    ) -> Result<TypedNode, TypeError> {
        if entries.is_empty() {
            return Ok(TypedNode {
                ty: Ty::Enum("HashMap".into(), vec![self.env.fresh_tyvar()]),
                span: span.clone(),
                node: TypedInner::HashMapLiteral(Vec::new()),
            });
        }

        let mut typed_entries = Vec::new();
        for entry in entries {
            let typed_key = self.check_node(&entry.key)?;
            self.ensure_no_runtime_facet_value(&typed_key, "HashMap literal key")?;
            if !self.types_compatible(&Ty::Str, &typed_key.ty)? {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "HashMap literal key must be String, got {}",
                        self.ty_name(&typed_key.ty)
                    ),
                    span: typed_key.span.clone(),
                    hint: Some(
                        "Use `hash![key_expr => value]` with a key expression that returns String."
                            .into(),
                    ),
                });
            }

            let typed_value = self.check_node(&entry.value)?;
            self.ensure_no_runtime_facet_value(&typed_value, "HashMap literal value")?;
            typed_entries.push((typed_key, typed_value));
        }

        let value_ty = typed_entries[0].1.ty.clone();
        for (_, value) in typed_entries.iter().skip(1) {
            if !self.types_compatible(&value_ty, &value.ty)? {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "expected {}, got {}",
                        self.ty_name(&value_ty),
                        self.ty_name(&value.ty)
                    ),
                    span: value.span.clone(),
                    hint: Some("All HashMap literal values must have the same type".into()),
                });
            }
        }

        Ok(TypedNode {
            ty: Ty::Enum("HashMap".into(), vec![value_ty]),
            span: span.clone(),
            node: TypedInner::HashMapLiteral(typed_entries),
        })
    }

    pub(super) fn check_range_literal(
        &mut self,
        span: &Span,
        start: &Resolved,
        stop: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let typed_start = self.check_node(start)?;
        let typed_stop = self.check_node(stop)?;
        self.ensure_no_runtime_facet_value(&typed_start, "Range literal")?;
        self.ensure_no_runtime_facet_value(&typed_stop, "Range literal")?;

        let start_ty = self.resolve_ty(&typed_start.ty);
        let stop_ty = self.resolve_ty(&typed_stop.ty);
        match (&start_ty, &stop_ty) {
            (Ty::Int, Ty::Int) => {
                if let (Some(start_int), Some(stop_int)) = (
                    Self::typed_int_literal_value(&typed_start),
                    Self::typed_int_literal_value(&typed_stop),
                ) {
                    return Ok(self.fold_int_range_literal(span, start_int, stop_int));
                }
                self.lower_int_range_runtime(span, start.clone(), stop.clone())
            }
            (Ty::Str, Ty::Str) => {
                if let (Some(start_str), Some(stop_str)) = (
                    Self::typed_string_literal_value(&typed_start),
                    Self::typed_string_literal_value(&typed_stop),
                ) {
                    if let Some((start_cp, stop_cp)) =
                        Self::foldable_string_range_endpoints(&start_str, &stop_str)
                    {
                        return Ok(self.fold_string_range_literal(span, start_cp, stop_cp));
                    }
                }
                self.lower_string_range_runtime(span, start.clone(), stop.clone())
            }
            _ => Err(TypeError {
                structured: None,
                message: "range literal endpoints must both be Int or both be String".into(),
                span: span.clone(),
                hint: Some("Use `[start..stop]` with matching Int endpoints or matching single-char String endpoints.".into()),
            }),
        }
    }

    fn typed_int_literal_value(node: &TypedNode) -> Option<sindr::primitives::SurtrInt> {
        match &node.node {
            TypedInner::Lit(Lit::Int(value)) => Some(value.clone()),
            _ => None,
        }
    }

    fn typed_string_literal_value(node: &TypedNode) -> Option<String> {
        match &node.node {
            TypedInner::Lit(Lit::Str(value)) => Some(value.clone()),
            _ => None,
        }
    }

    fn fold_int_range_literal(
        &mut self,
        span: &Span,
        start: sindr::primitives::SurtrInt,
        stop: sindr::primitives::SurtrInt,
    ) -> TypedNode {
        let mut current = start;
        let mut elems = Vec::new();
        while current <= stop {
            elems.push(TypedNode {
                ty: Ty::Int,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Int(current.clone())),
            });
            current += int(1);
        }

        TypedNode {
            ty: Ty::List(Box::new(Ty::Int)),
            span: span.clone(),
            node: TypedInner::ListLiteral(elems),
        }
    }

    fn fold_string_range_literal(&mut self, span: &Span, start_cp: u8, stop_cp: u8) -> TypedNode {
        let mut elems = Vec::new();
        let mut current = start_cp;
        while current <= stop_cp {
            elems.push(TypedNode {
                ty: Ty::Str,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Str((current as char).to_string())),
            });
            current += 1;
        }

        let list_node = TypedNode {
            ty: Ty::List(Box::new(Ty::Str)),
            span: span.clone(),
            node: TypedInner::ListLiteral(elems),
        };
        TypedNode {
            ty: Ty::Result(Box::new(Ty::List(Box::new(Ty::Str))), Box::new(Ty::Error)),
            span: span.clone(),
            node: TypedInner::ConstructorCall(0, vec![list_node]),
        }
    }

    fn foldable_string_range_endpoints(start: &str, stop: &str) -> Option<(u8, u8)> {
        Some((
            Self::single_ascii_range_endpoint_value(start)?,
            Self::single_ascii_range_endpoint_value(stop)?,
        ))
    }

    fn single_ascii_range_endpoint_value(value: &str) -> Option<u8> {
        let mut chars = value.chars();
        let ch = chars.next()?;
        if chars.next().is_some() {
            return None;
        }
        if !ch.is_ascii() {
            return None;
        }
        Some(ch as u8)
    }

    fn canonical_enum_constructor_id(
        &self,
        name: &str,
        span: &Span,
    ) -> Result<ResolvedId, TypeError> {
        let meta = sindr::names::special_enum_variant_meta(name)
            .ok_or_else(|| TypeError::new("invalid canonical variant", span.clone()))?;
        let (unique_id, variant) = self
            .env
            .enum_constructor_ids
            .iter()
            .find(|(_, variant)| variant.special_variant == Some(meta.lowering))
            .ok_or_else(|| {
                TypeError::new(format!("missing canonical variant `{name}`"), span.clone())
            })?;
        Ok(ResolvedId {
            name: variant.constructor_name.clone(),
            qualified_name: Some(variant.constructor_name.clone()),
            symbol_info: None,
            unique_id: *unique_id,
            compiler_generated: true,
            span: span.clone(),
        })
    }

    fn runtime_helper_id(
        &self,
        qualified_name: &str,
        span: &Span,
    ) -> Result<ResolvedId, TypeError> {
        if let Some(id) = self.function_ids_by_name.get(qualified_name) {
            return Ok(id.clone());
        }
        if let Some(uid) = self.impl_method_uids.get(qualified_name) {
            if let Some(id) = self
                .function_ids_by_name
                .values()
                .find(|id| id.unique_id == *uid)
            {
                return Ok(id.clone());
            }
            let local_name = qualified_name
                .rsplit("::")
                .next()
                .unwrap_or(qualified_name)
                .to_string();
            return Ok(ResolvedId {
                name: local_name,
                qualified_name: Some(qualified_name.to_string()),
                symbol_info: None,
                unique_id: *uid,
                compiler_generated: true,
                span: span.clone(),
            });
        }
        Err(TypeError {
            structured: None,
            message: format!("internal error: missing std helper `{qualified_name}`"),
            span: span.clone(),
            hint: None,
        })
    }

    pub(super) fn next_synthetic_range_uid() -> u32 {
        SYNTHETIC_RANGE_UID.fetch_add(1, Ordering::Relaxed)
    }

    fn lower_int_range_runtime(
        &mut self,
        span: &Span,
        start: Resolved,
        stop: Resolved,
    ) -> Result<TypedNode, TypeError> {
        let range_id = self.runtime_helper_id("Generator::range", span)?;
        let to_list_id = self.runtime_helper_id("Generator::to_list", span)?;
        let lowered = Resolved::App(
            span.clone(),
            Box::new(Resolved::Var(span.clone(), to_list_id)),
            vec![ResolvedRecordLitArg::Positional(Resolved::App(
                span.clone(),
                Box::new(Resolved::Var(span.clone(), range_id)),
                vec![
                    ResolvedRecordLitArg::Positional(start),
                    ResolvedRecordLitArg::Positional(stop),
                ],
            ))],
        );
        self.check_node(&lowered)
    }

    fn lower_string_range_runtime(
        &mut self,
        span: &Span,
        start: Resolved,
        stop: Resolved,
    ) -> Result<TypedNode, TypeError> {
        let range_char_id = self.runtime_helper_id("Generator::range_char", span)?;
        let to_list_id = self.runtime_helper_id("Generator::to_list", span)?;
        let gen_uid = Self::next_synthetic_range_uid();
        let gen_id = ResolvedId {
            name: "__range_gen".into(),
            qualified_name: None,
            symbol_info: None,
            unique_id: gen_uid,
            compiler_generated: true,
            span: span.clone(),
        };
        let lowered = Resolved::Block(
            span.clone(),
            vec![
                Resolved::SafeBind(
                    span.clone(),
                    ResolvedPattern::Var(gen_id.clone()),
                    Box::new(Resolved::App(
                        span.clone(),
                        Box::new(Resolved::Var(span.clone(), range_char_id)),
                        vec![
                            ResolvedRecordLitArg::Positional(start),
                            ResolvedRecordLitArg::Positional(stop),
                        ],
                    )),
                    span.clone(),
                ),
                Resolved::ConstructorCall(
                    span.clone(),
                    self.canonical_enum_constructor_id("Result::Ok", span)?,
                    vec![ResolvedRecordLitArg::Positional(Resolved::App(
                        span.clone(),
                        Box::new(Resolved::Var(span.clone(), to_list_id)),
                        vec![ResolvedRecordLitArg::Positional(Resolved::Var(
                            span.clone(),
                            gen_id,
                        ))],
                    ))],
                ),
            ],
        );
        self.check_node(&lowered)
    }

    pub(super) fn check_tuple_literal(
        &mut self,
        span: &Span,
        elems: &[Resolved],
    ) -> Result<TypedNode, TypeError> {
        if elems.len() < 2 {
            return Err(TypeError {
                structured: None,
                message: "Tuple literals require at least 2 values".into(),
                span: span.clone(),
                hint: None,
            });
        }

        let typed_elems = elems
            .iter()
            .map(|elem| self.check_node(elem))
            .collect::<Result<Vec<_>, _>>()?;
        for typed in &typed_elems {
            self.ensure_no_runtime_facet_value(typed, "Tuple literal")?;
        }
        let item_tys = typed_elems.iter().map(|elem| elem.ty.clone()).collect();

        Ok(TypedNode {
            ty: Ty::Tuple(item_tys),
            span: span.clone(),
            node: TypedInner::TupleLiteral(typed_elems),
        })
    }

    pub(super) fn check_interpolated_str(
        &mut self,
        span: &Span,
        parts: &[ResolvedInterpolatedPart],
    ) -> Result<TypedNode, TypeError> {
        let mut typed_parts = Vec::new();
        for part in parts {
            match part {
                ResolvedInterpolatedPart::Text(s) => {
                    typed_parts.push(TypedInterpolatedPart::Text(s.clone()));
                }
                ResolvedInterpolatedPart::Expr(expr) => {
                    let show = self.trait_key_by_short_name("Show").ok_or_else(|| {
                        TypeError::new("Missing canonical Show trait", span.clone())
                    })?;
                    let args = [ResolvedRecordLitArg::Positional(expr.as_ref().clone())];
                    let call = TraitInvocationContext {
                        span: self.resolved_span(expr),
                        trait_name: &show,
                        method_name: "to_string",
                        args: &args,
                        receiver_owner_hint: None,
                        expected_ret_ty: Some(&Ty::Str),
                        expected_ret_relation: None,
                        argument_expected_relation: None,
                        constructor_failure_reason: None,
                        explicit_type_args: None,
                        operator: None,
                        receiver_hint: None,
                        defer_incompatible_result_context: false,
                    };
                    let mut prepared = match self.prepare_trait_invocation(&call)? {
                        TraitInvocationPreparation::Arguments(prepared) => prepared,
                        TraitInvocationPreparation::Complete(_) => {
                            return Err(TypeError::new(
                                "Show interpolation unexpectedly completed without checking its argument",
                                self.resolved_span(expr).clone(),
                            ));
                        }
                    };
                    let typed_args = self.check_prepared_trait_arguments(&call, &mut prepared)?;
                    let typed_expr = &typed_args[0];
                    self.ensure_no_runtime_facet_value(typed_expr, "String interpolation")?;
                    if matches!(self.resolve_ty(&typed_expr.ty), Ty::Result(_, _)) {
                        return Err(TypeError {
                            structured: None,
                            message: "Interpolation does not allow Result type".into(),
                            span: typed_expr.span.clone(),
                            hint: Some(
                                "Unwrap/match the Result first, or convert it to a printable value"
                                    .into(),
                            ),
                        });
                    }
                    let conversion = self.finish_trait_invocation(&call, prepared, typed_args)?;
                    typed_parts.push(TypedInterpolatedPart::Expr(Box::new(conversion)));
                }
            }
        }

        Ok(TypedNode {
            ty: Ty::Str,
            span: span.clone(),
            node: TypedInner::InterpolatedStr(typed_parts),
        })
    }

    pub(super) fn is_lazy_placeholder(arg: &Resolved) -> bool {
        match arg {
            Resolved::Grouped(_, inner) => Self::is_lazy_placeholder(inner),
            Resolved::Var(_, id) => id.compiler_generated && id.name.starts_with("__cap_"),
            _ => false,
        }
    }

    pub(super) fn check_lazy_input(
        &mut self,
        arg: &Resolved,
        expected: Option<&Ty>,
        call_span: &Span,
    ) -> Result<LazyInput, TypeError> {
        if let Resolved::Var(span, id) = arg {
            if id.name.starts_with("__pipe_slot_") {
                return Err(TypeError {
                    structured: None,
                    message: "pipe injection into a Lazy parameter is not allowed".into(),
                    span: span.clone(),
                    hint: Some("Lazy parameters are evaluated under the callee's control. Bind the value first, then pass that binding explicitly, or use a closure to make the evaluation order explicit.".into()),
                });
            }
        }
        let placeholder = Self::is_lazy_placeholder(arg);
        if let Resolved::Grouped(span, inner) = arg {
            let mut input = self.check_lazy_input(inner, expected, call_span)?;
            // Parentheses around a normalized capture parameter only group it.
            if placeholder {
                input.placeholder = true;
                return Ok(input);
            }
            input.call_shell = false;
            input.node = TypedNode {
                ty: input.node.ty.clone(),
                span: span.clone(),
                node: TypedInner::EagerBoundary(Box::new(input.node)),
            };
            return Ok(input);
        }
        let node = if self.branch_tail_is_return_type_argument_call(arg) && expected.is_some() {
            let checkpoint = self.candidate_probe_checkpoint();
            match self.check_node(arg) {
                Ok(node) => node,
                Err(error)
                    if error.reason()
                        == Some(TypeDiagnosticReason::AmbiguousReturnTypeArgument) =>
                {
                    self.rollback_candidate_probe(checkpoint);
                    let expected = expected.expect("checked expected branch result");
                    match arg {
                        Resolved::Closure(span, params, captures, body)
                        | Resolved::ExtractorClosure(span, params, captures, body)
                        | Resolved::CaptureClosure(span, params, captures, body)
                            if params.is_empty() =>
                        {
                            self.check_closure(
                                span,
                                params,
                                captures,
                                body,
                                Some(&Ty::Func(vec![], Box::new(expected.clone()))),
                                None,
                            )?
                        }
                        _ => self.check_node_with_expected(arg, Some(expected))?,
                    }
                }
                Err(error) => {
                    self.rollback_candidate_probe(checkpoint);
                    return Err(error);
                }
            }
        } else {
            self.check_node(arg)?
        };
        Ok(LazyInput {
            node,
            placeholder,
            call_shell: matches!(
                arg,
                Resolved::App(..)
                    | Resolved::LazyApp(..)
                    | Resolved::ConstructorCall(..)
                    | Resolved::EnumConstructorCall(..)
                    | Resolved::If(..)
                    | Resolved::IfLet(..)
                    | Resolved::Cause(..)
                    | Resolved::ApplyPattern(..)
                    | Resolved::IsMatch(..)
                    | Resolved::Dbg(..)
            ),
        })
    }

    fn lazy_depth(&self, ty: &Ty) -> usize {
        match self.resolve_ty(ty) {
            Ty::Func(params, ret)
            | Ty::UserFunc { params, ret, .. }
            | Ty::BuiltinFunc { params, ret, .. }
                if params.is_empty() =>
            {
                1 + self.lazy_depth(&ret)
            }
            _ => 0,
        }
    }

    fn lazy_shell_type(&self, input: &LazyInput) -> Ty {
        let ty = self.resolve_ty(&input.node.ty);
        if input.call_shell {
            Ty::Func(vec![], Box::new(ty))
        } else {
            ty
        }
    }

    /// Consume exactly one normalized shell, preserving any function in its result.
    fn consume_lazy_input(&self, mut input: LazyInput, wrap: bool, span: &Span) -> TypedNode {
        input.node.ty = self.resolve_ty(&input.node.ty);
        if wrap && input.call_shell {
            // Consuming the extra adjustment shell leaves the original shell
            // around a bare call. That remaining shell must be represented as
            // a real thunk rather than evaluating the call now.
            let outer_ids = self
                .env
                .vars
                .iter()
                .filter_map(|(id, ty)| {
                    (!matches!(ty, Ty::UserFunc { .. } | Ty::BuiltinFunc { .. })
                        && !self.env.type_constructor_ids.contains(id))
                    .then_some(*id)
                })
                .collect::<HashSet<_>>();
            let captures = Self::finalized_closure_captures(&input.node, &outer_ids);
            TypedNode {
                ty: Ty::Func(vec![], Box::new(input.node.ty.clone())),
                span: input.node.span.clone(),
                node: TypedInner::Closure(vec![], captures, Box::new(input.node)),
            }
        } else if wrap || input.call_shell {
            input.node
        } else {
            self.maybe_call_zero_arg_function(input.node, span.clone())
        }
    }

    /// Known inputs decide the shell depth; an expected type only determines unknown parameters.
    /// Each shallower input receives at most one shell before the ordinary branch relation.
    pub(super) fn normalize_lazy_pair(
        &mut self,
        left: LazyInput,
        right: LazyInput,
        expected: Option<&Ty>,
        span: &Span,
    ) -> Result<(TypedNode, TypedNode), TypeError> {
        let mut left_type = self.lazy_shell_type(&left);
        let mut right_type = self.lazy_shell_type(&right);
        let mut wrap_left = false;
        let mut wrap_right = false;
        match (left.placeholder, right.placeholder) {
            (true, true) => {
                let result = expected.cloned().unwrap_or_else(|| self.env.fresh_tyvar());
                let required = Ty::Func(vec![], Box::new(result));
                self.assert_lazy_placeholder(
                    &required,
                    &left.node,
                    span,
                    &[(&left.node, &required), (&right.node, &required)],
                )?;
                self.assert_lazy_placeholder(
                    &required,
                    &right.node,
                    span,
                    &[(&left.node, &required), (&right.node, &required)],
                )?;
            }
            (true, false) => {
                if self.lazy_depth(&right_type) == 0 {
                    wrap_right = true;
                    right_type = Ty::Func(vec![], Box::new(right_type));
                }
                self.assert_lazy_placeholder(
                    &right_type,
                    &left.node,
                    span,
                    &[(&left.node, &right_type)],
                )?;
            }
            (false, true) => {
                if self.lazy_depth(&left_type) == 0 {
                    wrap_left = true;
                    left_type = Ty::Func(vec![], Box::new(left_type));
                }
                self.assert_lazy_placeholder(
                    &left_type,
                    &right.node,
                    span,
                    &[(&right.node, &left_type)],
                )?;
            }
            (false, false) => {
                let left_depth = self.lazy_depth(&left_type);
                let right_depth = self.lazy_depth(&right_type);
                wrap_left = left_depth == 0 && right_depth == 0 || left_depth < right_depth;
                wrap_right = left_depth == 0 && right_depth == 0 || right_depth < left_depth;
            }
        }
        // The ordinary branch relation below checks the resulting values;
        // at most one shell is added, so deeper mismatches remain errors.
        Ok((
            self.consume_lazy_input(left, wrap_left, span),
            self.consume_lazy_input(right, wrap_right, span),
        ))
    }

    /// Keep all requirements known at this normalization step available to diagnostics,
    /// even when the first placeholder relation fails.
    fn assert_lazy_placeholder(
        &mut self,
        required: &Ty,
        node: &TypedNode,
        span: &Span,
        requirements: &[(&TypedNode, &Ty)],
    ) -> Result<(), TypeError> {
        let result = self.assert_type_relation(
            required,
            &node.ty,
            self.type_fact(SourceRole::Expected, span, required),
            self.type_fact(SourceRole::Value, &node.span, &node.ty),
            TypeDiagnosticReason::ArgumentTypeMismatch,
            DiagnosticOrigin::Call,
            "Lazy",
            0,
        );
        result.map_err(|error| self.lazy_placeholder_error(error, required, node, requirements))
    }

    pub(super) fn check_lazy_argument(
        &mut self,
        arg: &Resolved,
        call_span: &Span,
    ) -> Result<TypedNode, TypeError> {
        let input = self.check_lazy_input(arg, None, call_span)?;
        if input.placeholder {
            return Err(TypeError::new(
                "Lazy capture parameter requires a known branch or expected type",
                input.node.span.clone(),
            ));
        }
        let wrap = self.lazy_depth(&self.lazy_shell_type(&input)) == 0;
        Ok(self.consume_lazy_input(input, wrap, call_span))
    }

    pub(super) fn normalize_lazy_single(
        &mut self,
        input: LazyInput,
        expected: &Ty,
        span: &Span,
    ) -> Result<TypedNode, TypeError> {
        if input.placeholder {
            let required = Ty::Func(vec![], Box::new(expected.clone()));
            self.assert_lazy_placeholder(
                &required,
                &input.node,
                span,
                &[(&input.node, &required)],
            )?;
        }
        let wrap = !input.placeholder && self.lazy_depth(&self.lazy_shell_type(&input)) == 0;
        Ok(self.consume_lazy_input(input, wrap, span))
    }

    pub(super) fn check_lazy_argument_with_expected(
        &mut self,
        arg: &Resolved,
        expected: &Ty,
        call_span: &Span,
    ) -> Result<TypedNode, TypeError> {
        let input = self.check_lazy_input(arg, Some(expected), call_span)?;
        self.normalize_lazy_single(input, expected, call_span)
    }

    pub(super) fn check_branch_node_with_expected(
        &mut self,
        node: &Resolved,
        expected: &Ty,
    ) -> Result<TypedNode, TypeError> {
        if self.branch_tail_is_return_type_argument_call(node) {
            let checkpoint = self.candidate_probe_checkpoint();
            match self.check_node(node) {
                Ok(typed) => return Ok(typed),
                Err(error)
                    if error.reason()
                        == Some(TypeDiagnosticReason::AmbiguousReturnTypeArgument) =>
                {
                    self.rollback_candidate_probe(checkpoint);
                }
                Err(error) => {
                    self.rollback_candidate_probe(checkpoint);
                    return Err(error);
                }
            }
        }
        self.check_node_with_expected(node, Some(expected))
    }

    fn branch_tail_is_return_type_argument_call(&self, node: &Resolved) -> bool {
        match node {
            Resolved::Closure(_, _, _, body)
            | Resolved::ExtractorClosure(_, _, _, body)
            | Resolved::CaptureClosure(_, _, _, body) => {
                self.body_tail_is_return_type_argument_call(body)
            }
            _ => self.body_tail_is_return_type_argument_call(node),
        }
    }

    fn check_if_with_expected(
        &mut self,
        span: &Span,
        cond: &Resolved,
        then: &Resolved,
        else_opt: &Option<Box<Resolved>>,
        expected: &Ty,
    ) -> Result<TypedNode, TypeError> {
        self.check_if_branches(span, cond, then, else_opt, Some(expected))
    }

    pub(super) fn check_if(
        &mut self,
        span: &Span,
        cond: &Resolved,
        then: &Resolved,
        else_opt: &Option<Box<Resolved>>,
    ) -> Result<TypedNode, TypeError> {
        self.check_if_branches(span, cond, then, else_opt, None)
    }

    fn check_if_branches(
        &mut self,
        span: &Span,
        cond: &Resolved,
        then: &Resolved,
        else_opt: &Option<Box<Resolved>>,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let callable_expected = self.contextual_callable_expected(expected);
        let typed_cond = self.check_node(cond)?;
        self.assert_type_relation(
            &Ty::Bool,
            &typed_cond.ty,
            self.type_fact(SourceRole::Expected, span, &Ty::Bool),
            self.type_fact(SourceRole::Value, &typed_cond.span, &typed_cond.ty),
            TypeDiagnosticReason::ArgumentTypeMismatch,
            DiagnosticOrigin::Branch {
                form: diagnostics::BranchForm::If,
                ordinal: 0,
            },
            "if",
            0,
        )?;
        let (typed_then, typed_else) = if let Some(branch) = else_opt {
            let then_input = self.check_lazy_input(then, expected, span)?;
            let else_input = self.check_lazy_input(branch, expected, span)?;
            let (then, other) = self.normalize_lazy_pair(then_input, else_input, expected, span)?;
            (then, Some(other))
        } else {
            (
                self.check_lazy_argument_with_expected(then, &Ty::Unit, span)?,
                None,
            )
        };
        if let Some(other) = &typed_else {
            if let Some(expected) = &callable_expected {
                for (ordinal, branch) in [&typed_then, other].into_iter().enumerate() {
                    self.assert_type_relation(
                        expected,
                        &branch.ty,
                        self.type_fact(SourceRole::Expected, span, expected),
                        self.branch_fact(SourceRole::Branch, branch, ordinal),
                        TypeDiagnosticReason::IfBranchTypeMismatch,
                        DiagnosticOrigin::Branch {
                            form: diagnostics::BranchForm::If,
                            ordinal: ordinal as u32,
                        },
                        "if",
                        ordinal as u32,
                    )
                    .map_err(|error| {
                        self.complete_branch_error(
                            error,
                            &[&typed_then, other],
                            &[Some(&typed_cond), None],
                        )
                    })?;
                }
            } else {
                self.assert_type_relation(
                    &typed_then.ty,
                    &other.ty,
                    self.branch_fact(SourceRole::Branch, &typed_then, 0),
                    self.branch_fact(SourceRole::Branch, other, 1),
                    TypeDiagnosticReason::IfBranchTypeMismatch,
                    DiagnosticOrigin::Branch {
                        form: diagnostics::BranchForm::If,
                        ordinal: 1,
                    },
                    "if",
                    1,
                )
                .map_err(|error| {
                    self.complete_branch_error(
                        error,
                        &[&typed_then, other],
                        &[Some(&typed_cond), None],
                    )
                })?;
            }
        }
        if typed_else.is_none() {
            self.assert_type_relation(
                &Ty::Unit,
                &typed_then.ty,
                self.type_fact(SourceRole::Expected, span, &Ty::Unit),
                self.type_fact(SourceRole::Value, &typed_then.span, &typed_then.ty),
                TypeDiagnosticReason::IfBranchTypeMismatch,
                DiagnosticOrigin::Branch {
                    form: diagnostics::BranchForm::If,
                    ordinal: 0,
                },
                "if_then",
                0,
            )?;
        }
        let ty = if typed_else.is_some() {
            callable_expected.unwrap_or_else(|| typed_then.ty.clone())
        } else {
            Ty::Unit
        };
        self.record_lazy_capture_signature(span, &ty);
        if let Some(expected) = expected {
            self.assert_type_relation(
                expected,
                &ty,
                self.type_fact(SourceRole::Expected, span, expected),
                self.type_fact(SourceRole::Value, span, &ty),
                TypeDiagnosticReason::IfBranchTypeMismatch,
                DiagnosticOrigin::Branch {
                    form: diagnostics::BranchForm::If,
                    ordinal: 0,
                },
                "if",
                0,
            )
            .map_err(|error| {
                let mut bodies = vec![&typed_then];
                if let Some(other) = &typed_else {
                    bodies.push(other);
                }
                self.complete_branch_error(error, &bodies, &[Some(&typed_cond)])
            })?;
        }
        Ok(TypedNode {
            ty: self.resolve_ty(&ty),
            span: span.clone(),
            node: TypedInner::If(
                Box::new(typed_cond),
                Box::new(typed_then),
                typed_else.map(Box::new),
            ),
        })
    }

    pub(super) fn check_dbg(
        &mut self,
        span: &Span,
        args: &[Resolved],
    ) -> Result<TypedNode, TypeError> {
        let typed_args = args
            .iter()
            .map(|arg| {
                let expr = self.check_node(arg)?;
                Ok(TypedDbgArg {
                    span: expr.span.clone(),
                    ty_name: self.ty_name(&expr.ty),
                    expr,
                })
            })
            .collect::<Result<Vec<_>, TypeError>>()?;

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Dbg(typed_args),
        })
    }

    pub(super) fn check_cause(
        &mut self,
        span: &Span,
        value: &Resolved,
        err: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let typed_value = self.check_result_value(value, "cause", None)?;
        let typed_err = self.check_lazy_argument_with_expected(err, &Ty::Error, span)?;
        self.ensure_result_error_arg(&typed_err, "cause")?;

        Ok(TypedNode {
            ty: typed_value.ty.clone(),
            span: span.clone(),
            node: TypedInner::Cause(Box::new(typed_value), Box::new(typed_err)),
        })
    }

    fn check_result_value(
        &mut self,
        value: &Resolved,
        form_name: &str,
        expected_ok_ty: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let expected_result_ty = Ty::Result(
            Box::new(
                expected_ok_ty
                    .cloned()
                    .unwrap_or_else(|| self.env.fresh_tyvar()),
            ),
            Box::new(Ty::Error),
        );
        let typed_value = self.check_node_with_expected(value, Some(&expected_result_ty))?;
        let value_ty = self.resolve_ty(&typed_value.ty);
        if !self.types_compatible(&expected_result_ty, &value_ty)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} value must be Result<...>, got {}",
                    form_name,
                    self.ty_name(&value_ty)
                ),
                span: typed_value.span.clone(),
                hint: None,
            });
        }
        Ok(typed_value)
    }

    fn resolve_facet_segment_for_source_ty(
        &mut self,
        source_ty: &Ty,
        segment: &PendingFacetSegment,
        span: &Span,
        _for_capability: bool,
    ) -> Result<(TypedFacetSegment, Ty, bool), TypeError> {
        if let PendingFacetSegment::Bracket { expr, display } = segment {
            let typed_expr = match expr {
                PendingFacetExpr::Resolved(expr) => self.check_node(expr)?,
                PendingFacetExpr::Typed(expr) => *self.resolve_typed_node((**expr).clone()),
            };
            return match self.resolve_ty(source_ty) {
                Ty::List(inner) => {
                    let expr_ty = self.resolve_ty(&typed_expr.ty);
                    if let Ty::Result(ok, _) = &expr_ty {
                        if self.types_compatible(ok.as_ref(), &Ty::Int)? {
                            return Err(TypeError {
                                structured: None,
                                message: "Facet bracket expression must be plain Int; unwrap Result<Int> before using it".into(),
                                span: typed_expr.span.clone(),
                                hint: None,
                            });
                        }
                    }
                    if !self.types_compatible(&Ty::Int, &expr_ty)? {
                        return Err(TypeError {
                            structured: None,
                            message: "List Facet index expression must be Int".into(),
                            span: typed_expr.span.clone(),
                            hint: None,
                        });
                    }

                    let literal_index = match &typed_expr.node {
                        TypedInner::Lit(Lit::Int(index)) => Some(index.clone()),
                        _ => None,
                    };
                    let focus_ty = inner.as_ref().clone();
                    Ok((
                        TypedFacetSegment::ListIndex {
                            index: Box::new(typed_expr),
                            display: display.clone(),
                            literal_index,
                        },
                        focus_ty,
                        true,
                    ))
                }
                Ty::Enum(name, args)
                    if Self::surface_name(&name) == "HashMap" && args.len() == 1 =>
                {
                    let expr_ty = self.resolve_ty(&typed_expr.ty);
                    if let Ty::Result(ok, _) = &expr_ty {
                        if self.types_compatible(ok.as_ref(), &Ty::Str)? {
                            return Err(TypeError {
                                structured: None,
                                message: "Facet bracket expression must be plain String; unwrap Result<String> before using it".into(),
                                span: typed_expr.span.clone(),
                                hint: None,
                            });
                        }
                    }
                    if !self.types_compatible(&Ty::Str, &expr_ty)? {
                        return Err(TypeError {
                            structured: None,
                            message: "HashMap Facet key expression must be String".into(),
                            span: typed_expr.span.clone(),
                            hint: None,
                        });
                    }

                    let literal_key = match &typed_expr.node {
                        TypedInner::Lit(Lit::Str(key)) => Some(key.clone()),
                        _ => None,
                    };
                    let value_ty = args[0].clone();
                    Ok((
                        TypedFacetSegment::MapKey {
                            key: Box::new(typed_expr),
                            display: display.clone(),
                            literal_key,
                        },
                        value_ty,
                        true,
                    ))
                }
                other => Err(TypeError {
                    structured: None,
                    message: format!(
                        "Facet segment {} is not supported for {} yet",
                        Self::pending_segment_display(segment),
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: None,
                }),
            };
        }
        if let PendingFacetSegment::RangeBracket {
            start,
            end,
            display,
        } = segment
        {
            let typed_start = match start {
                PendingFacetExpr::Resolved(expr) => self.check_node(expr)?,
                PendingFacetExpr::Typed(expr) => *self.resolve_typed_node((**expr).clone()),
            };
            let typed_end = match end {
                PendingFacetExpr::Resolved(expr) => self.check_node(expr)?,
                PendingFacetExpr::Typed(expr) => *self.resolve_typed_node((**expr).clone()),
            };
            return match self.resolve_ty(source_ty) {
                Ty::List(inner) => {
                    for typed_expr in [&typed_start, &typed_end] {
                        let expr_ty = self.resolve_ty(&typed_expr.ty);
                        if let Ty::Result(ok, _) = &expr_ty {
                            if self.types_compatible(ok.as_ref(), &Ty::Int)? {
                                return Err(TypeError {
                                    structured: None,
                                    message: "Facet bracket expression must be plain Int; unwrap Result<Int> before using it".into(),
                                    span: typed_expr.span.clone(),
                                    hint: None,
                                });
                            }
                        }
                        if !self.types_compatible(&Ty::Int, &expr_ty)? {
                            return Err(TypeError {
                                structured: None,
                                message: "List Facet index expression must be Int".into(),
                                span: typed_expr.span.clone(),
                                hint: None,
                            });
                        }
                    }

                    let literal_start = match &typed_start.node {
                        TypedInner::Lit(Lit::Int(index)) => Some(index.clone()),
                        _ => None,
                    };
                    let literal_end = match &typed_end.node {
                        TypedInner::Lit(Lit::Int(index)) => Some(index.clone()),
                        _ => None,
                    };
                    let focus_ty = Ty::List(Box::new(inner.as_ref().clone()));
                    Ok((
                        TypedFacetSegment::ListRange {
                            start: Box::new(typed_start),
                            end: Box::new(typed_end),
                            display: display.clone(),
                            literal_start,
                            literal_end,
                        },
                        focus_ty,
                        true,
                    ))
                }
                other => Err(TypeError {
                    structured: None,
                    message: format!(
                        "Facet segment {} is not supported for {} yet",
                        Self::pending_segment_display(segment),
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: None,
                }),
            };
        }
        let PendingFacetSegment::Field {
            name: field,
            optional,
        } = segment
        else {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Facet segment {} is not supported for {} yet",
                    Self::pending_segment_display(segment),
                    self.ty_name(source_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        };
        if *optional {
            return Err(TypeError {
                structured: None,
                message: "optional Facet selectors are no longer supported".into(),
                span: span.clone(),
                hint: Some(
                    "Facet variant selectors are required because an optional mismatch cannot preserve a type-changing rebuild."
                        .into(),
                ),
            });
        }
        match self.resolve_ty(source_ty) {
            Ty::Error if matches!(field.as_str(), "kind" | "message") => {
                let builtin_id =
                    sindr::builtin::builtin_meta_for_decl(field, Some(&format!("Error::{field}")))
                        .map(|meta| meta.runtime_id())
                        .ok_or_else(|| {
                            TypeError::new("Missing Error observation builtin", span.clone())
                        })?;
                Ok((
                    TypedFacetSegment::ReadonlyBuiltin {
                        field_name: field.clone(),
                        builtin_id,
                    },
                    Ty::Str,
                    false,
                ))
            }
            Ty::Tuple(items) => {
                let index = field
                    .strip_prefix('_')
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: "Tuple elements are accessed with ._0, ._1, ...".into(),
                        span: span.clone(),
                        hint: None,
                    })?
                    .parse::<usize>()
                    .map_err(|_| TypeError {
                        structured: None,
                        message: "Tuple elements are accessed with ._0, ._1, ...".into(),
                        span: span.clone(),
                        hint: None,
                    })?;
                let field_ty = items.get(index).cloned().ok_or_else(|| TypeError {
                    structured: None,
                    message: format!(
                        "Tuple index ._{} is out of bounds for {}",
                        index,
                        self.ty_name(source_ty)
                    ),
                    span: span.clone(),
                    hint: Some(Self::tuple_index_hint(items.len())),
                })?;
                Ok((
                    TypedFacetSegment::Tuple {
                        field_index: index as u32,
                        tuple_len: items.len() as u32,
                    },
                    field_ty,
                    false,
                ))
            }
            Ty::Struct(name, fields) | Ty::Record(name, fields) => {
                let origin_index = if matches!(self.resolve_ty(source_ty), Ty::Record(..)) {
                    let numbered = field.strip_prefix('_').is_some_and(|digits| {
                        !digits.is_empty() && digits.bytes().all(|ch| ch.is_ascii_digit())
                    });
                    let parsed = Self::parse_tuple_index_name(field);
                    if numbered && parsed.is_none() {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Record index .{field} is out of bounds for {}",
                                self.ty_name(source_ty)
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                    parsed
                } else {
                    None
                };
                let resolved_field = if let Some(index) = origin_index {
                    fields
                        .get(index)
                        .map(|(name, _)| name.as_str())
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!(
                                "Record index ._{index} is out of bounds for {}",
                                self.ty_name(source_ty)
                            ),
                            span: span.clone(),
                            hint: None,
                        })?
                } else {
                    field.as_str()
                };
                let field_policy = self.env.field_policy(&name, resolved_field);
                if field_policy.is_some_and(|policy| policy.private) {
                    let display_name = Self::surface_name(&name);
                    let outside_impl =
                        self.current_private_field_owner.as_deref() != Some(display_name);
                    if outside_impl && !self.allow_private_facet_inspection {
                        return Err(TypeError {
                            structured: None,
                            message: format!("Field '{}.{}' is private", display_name, field),
                            span: span.clone(),
                            hint: Some(format!(
                                "Expose the value through a public method on {} instead.",
                                display_name
                            )),
                        });
                    }
                }
                let (field_index, field_ty) = fields
                    .iter()
                    .enumerate()
                    .find(|(_, (field_name, _))| field_name == resolved_field)
                    .map(|(i, (_, ty))| (i as u32, ty.clone()))
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: format!("No field '{}' on {}", field, self.ty_name(source_ty)),
                        span: span.clone(),
                        hint: None,
                    })?;
                Ok((
                    TypedFacetSegment::Field {
                        field_name: resolved_field.to_string(),
                        origin_index: origin_index.map(|index| index as u32),
                        field_index,
                        container_field_count: fields.len() as u32,
                        container_type_name: Self::surface_name(&name).to_string(),
                        readonly: field_policy.is_some_and(|policy| policy.readonly),
                        private: field_policy.is_some_and(|policy| policy.private),
                    },
                    field_ty,
                    false,
                ))
            }
            source if Self::facet_enum_source_name(&source).is_some() => {
                let enum_name =
                    Self::facet_enum_source_name(&source).expect("checked enum-like Facet source");
                if self.lookup_enum_variants_of(&enum_name).is_none() {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "No variants found for enum {}",
                            Self::surface_name(&enum_name)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                let Some(variant) = self.lookup_enum_variant_by_short_name(&enum_name, field)
                else {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "No variant selector '{}' on {} (use PascalCase constructor names)",
                            field,
                            Self::surface_name(&enum_name)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                };
                let variant = self.instantiate_enum_variant(&variant);
                if !self.types_compatible(&variant.enum_ty, source_ty)? {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Variant selector {}.{} does not match {}",
                            enum_name,
                            field,
                            self.ty_name(source_ty)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                let payload_arity = variant.payload.len() as u32;
                let focus_ty = match variant.payload.len() {
                    0 => Ty::Unit,
                    1 => variant.payload[0].clone(),
                    _ => Ty::Tuple(variant.payload.clone()),
                };
                Ok((
                    TypedFacetSegment::Variant {
                        enum_name,
                        variant_name: variant.short_name,
                        variant_tag: variant.tag,
                        discriminant: variant.discriminant,
                        payload_arity,
                        optional: *optional,
                    },
                    focus_ty,
                    true,
                ))
            }
            other => {
                let message = if field.starts_with('_')
                    && field
                        .strip_prefix('_')
                        .is_some_and(|suffix| suffix.chars().all(|ch| ch.is_ascii_digit()))
                {
                    format!(
                        "Tuple-style access .{} is only available on tuples, got {}",
                        field,
                        self.ty_name(&other)
                    )
                } else {
                    format!("Cannot access field on {}", self.ty_name(&other))
                };
                Err(TypeError {
                    structured: None,
                    message,
                    span: span.clone(),
                    hint: None,
                })
            }
        }
    }

    fn facet_enum_source_name(source_ty: &Ty) -> Option<Symbol> {
        match source_ty {
            Ty::Enum(enum_name, _) => Some(enum_name.clone()),
            Ty::Bool => Some("Boolean".into()),
            _ => None,
        }
    }

    fn try_check_tuple_type_root_facet_path(
        &mut self,
        span: &Span,
        field: &str,
        expected: Option<&Ty>,
    ) -> Result<Option<TypedNode>, TypeError> {
        let Some(index) = Self::parse_tuple_index_name(field) else {
            return Ok(None);
        };

        let Some(expected_ty) = expected else {
            return Ok(Some(self.pending_facet_node(
                span,
                PendingFacetPath {
                    root_path_name: Some("Tuple".into()),
                    source_ty_hint: None,
                    segments: vec![Self::pending_field_segment(field)],
                },
            )));
        };
        let expected_ty = self.resolve_ty(expected_ty);
        let (expected_source, expected_focus) = match expected_ty {
            Ty::Facet(_, source, focus, ..) => (source.as_ref().clone(), focus.as_ref().clone()),
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Tuple.{} requires expected Facet<..., ...> context, got {}",
                        field,
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: Some(
                        "Use Tuple._N as a Facet path argument in Facet::view/set/over.".into(),
                    ),
                });
            }
        };

        let tuple_items = match self.resolve_ty(&expected_source) {
            Ty::Tuple(items) => items,
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Tuple.{} requires tuple source context, got {}",
                        field,
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: Some("Expected source type like (A, B, ...) for Tuple._N.".into()),
                });
            }
        };

        let focus_ty = tuple_items.get(index).cloned().ok_or_else(|| TypeError {
            structured: None,
            message: format!(
                "Tuple index ._{} is out of bounds for ({})",
                index,
                tuple_items
                    .iter()
                    .map(|item| self.ty_name(item))
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            span: span.clone(),
            hint: Some(Self::tuple_index_hint(tuple_items.len())),
        })?;

        if !self.types_compatible(&focus_ty, &expected_focus)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Tuple.{} focus type mismatch: expected {}, got {}",
                    field,
                    self.ty_name(&expected_focus),
                    self.ty_name(&focus_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let source_ty = Ty::Tuple(tuple_items);
        let path = TypedFacetPath {
            source_ty: source_ty.clone(),
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: TypedFacetPathKind::InfallibleStructural,
            may_fail: false,
            segments: vec![TypedFacetSegment::Tuple {
                field_index: index as u32,
                tuple_len: match &source_ty {
                    Ty::Tuple(items) => items.len() as u32,
                    _ => unreachable!("source_ty is always Tuple here"),
                },
            }],
        };

        Ok(Some(TypedNode {
            ty: Self::deferred_facet_ty(path.path_kind, source_ty, focus_ty),
            span: span.clone(),
            node: TypedInner::FacetPath(path),
        }))
    }

    fn try_check_container_type_root_facet_path(
        &mut self,
        span: &Span,
        root_kind: FacetRootKind,
        segment: &PendingFacetSegment,
        expected: Option<&Ty>,
    ) -> Result<Option<TypedNode>, TypeError> {
        let root_path_name = match (root_kind, segment) {
            (
                FacetRootKind::List,
                PendingFacetSegment::Bracket { .. } | PendingFacetSegment::RangeBracket { .. },
            ) => "List",
            (FacetRootKind::HashMap, PendingFacetSegment::Bracket { .. }) => "HashMap",
            _ => return Ok(None),
        };

        let Some(expected_ty) = expected else {
            return Ok(Some(self.pending_facet_node(
                span,
                PendingFacetPath {
                    root_path_name: Some(root_path_name.into()),
                    source_ty_hint: None,
                    segments: vec![segment.clone()],
                },
            )));
        };
        let expected_ty = self.resolve_ty(expected_ty);
        let (expected_source, expected_focus) = match expected_ty {
            Ty::Facet(_, source, focus, ..) => (source.as_ref().clone(), focus.as_ref().clone()),
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "{root_path_name} root Facet path requires expected Facet<..., ...> context, got {}",
                        self.ty_name(&other)
                    ),
                    span: span.clone(),
                    hint: Some(format!(
                        "Use {root_path_name} root paths as Facet path arguments in Facet::view/set/over."
                    )),
                });
            }
        };

        self.validate_pending_root_source(root_path_name, &expected_source, span)?;
        let (typed_segment, focus_ty, may_fail) =
            self.resolve_facet_segment_for_source_ty(&expected_source, segment, span, true)?;
        let focus_ty = self.resolve_ty(&focus_ty);
        if !self.types_compatible(&focus_ty, &expected_focus)? {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{root_path_name} root Facet path focus type mismatch: expected {}, got {}",
                    self.ty_name(&expected_focus),
                    self.ty_name(&focus_ty)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let source_ty = self.resolve_ty(&expected_source);
        let path = TypedFacetPath {
            source_ty: source_ty.clone(),
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: Self::facet_path_kind_for_segments(std::slice::from_ref(&typed_segment)),
            may_fail,
            segments: vec![typed_segment],
        };

        Ok(Some(TypedNode {
            ty: Self::deferred_facet_ty(path.path_kind, source_ty, focus_ty),
            span: span.clone(),
            node: TypedInner::FacetPath(path),
        }))
    }

    fn facet_type_root_matches_source(root: &Resolved, source: &Ty) -> bool {
        let Resolved::Var(_, id) = root else {
            return false;
        };
        let authored_owner = id.qualified_name.as_deref().unwrap_or(&id.name);
        let expected_owner = match source {
            Ty::Struct(name, _) | Ty::Record(name, _) | Ty::Enum(name, _) => name.as_str(),
            Ty::Bool => "Boolean",
            Ty::Result(_, _) => "Result",
            Ty::Error => "Error",
            _ => return false,
        };
        Self::canonical_user_type_name(authored_owner)
            == Self::canonical_user_type_name(expected_owner)
    }

    fn check_type_root_facet_path_with_expected(
        &mut self,
        span: &Span,
        expr: &Resolved,
        segment: &PendingFacetSegment,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let (source_ty, expected_focus_ty) = match expected.map(|ty| self.resolve_ty(ty)) {
            Some(Ty::Facet(_, source, focus, ..)) => {
                let expected_source_ty = source.as_ref().clone();
                let authored_owner = match expr {
                    Resolved::Var(_, id) => id.qualified_name.as_deref().unwrap_or(&id.name),
                    _ => unreachable!("type-root Facet paths are resolved variables"),
                };
                let same_owner = Self::facet_type_root_matches_source(
                    expr,
                    &self.resolve_ty(&expected_source_ty),
                );
                if !same_owner {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Facet path source owner mismatch: path root is {}, source is {}",
                            Self::surface_name(authored_owner),
                            self.ty_name(&expected_source_ty)
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                (expected_source_ty, Some(focus.as_ref().clone()))
            }
            _ => {
                if let Resolved::Var(_, id) = expr {
                    if sindr::names::builtin_type_name(Self::surface_name(
                        id.qualified_name.as_deref().unwrap_or(&id.name),
                    )) == Some(sindr::names::TypeName::Error)
                    {
                        (Ty::Error, None)
                    } else {
                        let typed_root = self.check_node(expr)?;
                        (self.resolve_ty(&typed_root.ty), None)
                    }
                } else {
                    unreachable!("type-root Facet paths are resolved variables")
                }
            }
        };
        let (segment, focus_ty, may_fail) =
            self.resolve_facet_segment_for_source_ty(&source_ty, segment, span, true)?;
        let focus_ty = self.resolve_ty(&focus_ty);
        if let Some(expected_focus_ty) = expected_focus_ty {
            if !self.types_compatible(&focus_ty, &expected_focus_ty)? {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Facet path focus type mismatch: expected {}, got {}",
                        self.ty_name(&expected_focus_ty),
                        self.ty_name(&focus_ty)
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }
        }
        let path = TypedFacetPath {
            source_ty: source_ty.clone(),
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: Self::facet_path_kind_for_segments(std::slice::from_ref(&segment)),
            may_fail,
            segments: vec![segment],
        };
        Ok(TypedNode {
            ty: Self::deferred_facet_ty(path.path_kind, source_ty, focus_ty),
            span: span.clone(),
            node: TypedInner::FacetPath(path),
        })
    }

    fn facet_root_kind(expr: &Resolved) -> Option<FacetRootKind> {
        let Resolved::Var(_, id) = expr else {
            return None;
        };
        id.symbol_info
            .as_ref()
            .and_then(|info| info.capabilities.facet_root_path.clone())
    }

    fn known_non_facet_root_name(expr: &Resolved) -> Option<&str> {
        let Resolved::Var(_, id) = expr else {
            return None;
        };
        id.symbol_info
            .as_ref()
            .filter(|info| info.capabilities.facet_root_path.is_none())
            .map(|_| id.name.as_str())
    }

    fn known_non_facet_root_error(root: &str, span: &Span) -> TypeError {
        TypeError {
            structured: None,
            message: format!(
                "{root} is not a Facet path root; primitive types are not path-constructable"
            ),
            span: span.clone(),
            hint: Some(
                "Use a defstruct/defrecord/defenum root, Tuple._N, List.[N], HashMap.[\"key\"], or a visible Facet binding."
                    .into(),
            ),
        }
    }

    fn bind_local_error_identity(&mut self, pattern: &TypedPattern, kind: &str) {
        match pattern {
            TypedPattern::Var(_, binding) => {
                self.env
                    .concrete_error_bindings
                    .insert(binding.unique_id, kind.to_string());
            }
            TypedPattern::Located(_, inner) => self.bind_local_error_identity(inner, kind),
            _ => {}
        }
    }

    fn resolved_concrete_error_identity<'a>(&'a self, expression: &Resolved) -> Option<&'a str> {
        match expression {
            Resolved::Var(_, id) => self
                .canonical_pattern_id(id)
                .ok()
                .and_then(|id| self.env.concrete_error_bindings.get(&id.unique_id))
                .map(String::as_str),
            Resolved::Grouped(_, inner) => self.resolved_concrete_error_identity(inner),
            _ => None,
        }
    }

    pub(super) fn concrete_error_annotation_identity(&self, annotation: &AstTy) -> Option<String> {
        let AstTy::Named(_, name) = annotation else {
            return None;
        };
        self.env
            .lookup_type_def(name)
            .filter(|def| def.kind == crate::env::TypeKind::ConcreteError)
            .map(|def| def.name.clone())
    }

    fn error_payload_facet_path(
        &self,
        kind: &str,
        field: &str,
        span: &Span,
    ) -> Result<TypedFacetPath, TypeError> {
        let schema = self.env.lookup_type_def(kind).ok_or_else(|| {
            TypeError::new("Concrete Error Payload schema is missing", span.clone())
        })?;
        let (field_index, (_, focus_ty)) = schema
            .fields
            .iter()
            .enumerate()
            .find(|(_, (name, _))| name == field)
            .ok_or_else(|| {
                TypeError::new(
                    format!("Unknown Error Payload field: {}", field),
                    span.clone(),
                )
            })?;
        Ok(TypedFacetPath {
            source_ty: Ty::Error,
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: TypedFacetPathKind::InfallibleStructural,
            may_fail: false,
            segments: vec![TypedFacetSegment::ErrorPayload {
                kind: kind.to_string(),
                field_name: field.to_string(),
                field_index: field_index as u32,
                payload_len: schema.fields.len() as u32,
            }],
        })
    }

    fn check_field_access_with_expected(
        &mut self,
        span: &Span,
        expr: &Resolved,
        field: &str,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let segment = ResolvedFacetPathSegment::Field {
            name: field.to_string(),
            optional: false,
        };
        self.check_facet_segment_access_with_expected(span, expr, &segment, expected)
    }

    fn check_facet_segment_access_with_expected(
        &mut self,
        span: &Span,
        expr: &Resolved,
        syntax_segment: &ResolvedFacetPathSegment,
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let pending_segment = Self::pending_segment_from_syntax(syntax_segment);
        let field = match syntax_segment {
            ResolvedFacetPathSegment::Field {
                name,
                optional: false,
            } => Some(name.as_str()),
            _ => None,
        };

        if let (Resolved::Var(_, id), Some(field)) = (expr, field) {
            if self.env.is_error_constructor(id.unique_id) {
                let kind = id.qualified_name.as_deref().ok_or_else(|| {
                    TypeError::new(
                        "Error Facet root is missing declaration identity",
                        span.clone(),
                    )
                })?;
                if matches!(field, "kind" | "message") {
                    let segment = Self::pending_field_segment(field.to_string());
                    let (segment, focus_ty, may_fail) =
                        self.resolve_facet_segment_for_source_ty(&Ty::Error, &segment, span, true)?;
                    let path = TypedFacetPath {
                        source_ty: Ty::Error,
                        focus_ty: focus_ty.clone(),
                        update_source_ty: Ty::Hole,
                        update_focus_ty: Ty::Hole,
                        path_kind: TypedFacetPathKind::InfallibleStructural,
                        may_fail,
                        segments: vec![segment],
                    };
                    return Ok(TypedNode {
                        ty: Self::deferred_facet_ty(path.path_kind, Ty::Error, focus_ty),
                        span: span.clone(),
                        node: TypedInner::FacetPath(path),
                    });
                }
                let path = self.error_payload_facet_path(kind, field, span)?;
                return Ok(TypedNode {
                    ty: Self::deferred_facet_ty(path.path_kind, Ty::Error, path.focus_ty.clone()),
                    span: span.clone(),
                    node: TypedInner::FacetPath(path),
                });
            }
            if let Some(kind) = self.env.concrete_error_bindings.get(&id.unique_id).cloned() {
                if !matches!(field, "kind" | "message") {
                    let path = self.error_payload_facet_path(&kind, field, span)?;
                    let source = self.check_node(expr)?;
                    return Ok(TypedNode {
                        ty: path.focus_ty.clone(),
                        span: span.clone(),
                        node: TypedInner::FacetView {
                            api: TypedFacetApi::View,
                            source: Box::new(source),
                            path,
                            source_is_result: false,
                        },
                    });
                }
            }
        }
        if let Some(root_kind) = Self::facet_root_kind(expr) {
            match root_kind {
                FacetRootKind::TypeRoot => {
                    return self.check_type_root_facet_path_with_expected(
                        span,
                        expr,
                        &pending_segment,
                        expected,
                    );
                }
                FacetRootKind::Tuple => {
                    if let Some(field) = field {
                        if let Some(tuple_root_path) =
                            self.try_check_tuple_type_root_facet_path(span, field, expected)?
                        {
                            return Ok(tuple_root_path);
                        }
                    }
                }
                FacetRootKind::List => {
                    if let Some(container_root_path) = self
                        .try_check_container_type_root_facet_path(
                            span,
                            FacetRootKind::List,
                            &pending_segment,
                            expected,
                        )?
                    {
                        return Ok(container_root_path);
                    }
                }
                FacetRootKind::HashMap => {
                    if let Some(container_root_path) = self
                        .try_check_container_type_root_facet_path(
                            span,
                            FacetRootKind::HashMap,
                            &pending_segment,
                            expected,
                        )?
                    {
                        return Ok(container_root_path);
                    }
                }
            }
        }
        if let Some(root) = Self::known_non_facet_root_name(expr) {
            return Err(Self::known_non_facet_root_error(root, span));
        }
        let typed_expr = self.check_node(expr)?;

        if matches!(typed_expr.ty, Ty::Facet(..)) {
            let path = self.resolve_facet_path_from_node(typed_expr, span, None)?;
            let (segment_source_ty, result_transparent) = match self.resolve_ty(&path.focus_ty) {
                Ty::Result(ok, _) => (ok.as_ref().clone(), true),
                other => (other, false),
            };
            let (segment, focus_ty, may_fail) = self.resolve_facet_segment_for_source_ty(
                &segment_source_ty,
                &pending_segment,
                span,
                true,
            )?;
            let source_ty = self.resolve_ty(&path.source_ty);
            let focus_ty = self.resolve_ty(&focus_ty);
            let mut segments = path.segments;
            segments.push(segment);
            let combined = TypedFacetPath {
                source_ty: source_ty.clone(),
                focus_ty: focus_ty.clone(),
                update_source_ty: Ty::Hole,
                update_focus_ty: Ty::Hole,
                path_kind: Self::facet_path_kind_for_segments(&segments),
                may_fail: path.may_fail || may_fail || result_transparent,
                segments,
            };
            return Ok(TypedNode {
                ty: Self::deferred_facet_ty(combined.path_kind, source_ty, focus_ty),
                span: span.clone(),
                node: TypedInner::FacetPath(combined),
            });
        }

        let (source_is_result, source_focus_ty) = match self.resolve_ty(&typed_expr.ty) {
            Ty::Result(ok, _) => (true, ok.as_ref().clone()),
            other => (false, other),
        };
        let (segment, focus_ty, may_fail) = self.resolve_facet_segment_for_source_ty(
            &source_focus_ty,
            &pending_segment,
            span,
            false,
        )?;
        let focus_ty = self.resolve_ty(&focus_ty);
        let path = TypedFacetPath {
            source_ty: source_focus_ty,
            focus_ty: focus_ty.clone(),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: Self::facet_path_kind_for_segments(std::slice::from_ref(&segment)),
            may_fail,
            segments: vec![segment],
        };
        let out_ty = if source_is_result || path.may_fail {
            Ty::Result(Box::new(focus_ty), Box::new(Ty::Error))
        } else {
            focus_ty
        };

        Ok(TypedNode {
            ty: out_ty,
            span: span.clone(),
            node: TypedInner::FacetView {
                api: TypedFacetApi::View,
                source: Box::new(typed_expr),
                path,
                source_is_result,
            },
        })
    }

    pub(super) fn check_field_access(
        &mut self,
        span: &Span,
        expr: &Resolved,
        field: &str,
    ) -> Result<TypedNode, TypeError> {
        self.check_field_access_with_expected(span, expr, field, None)
    }
}

fn trait_impl_signature_display(
    qualified_name: &str,
    param_list: &str,
    ret: &str,
) -> Option<String> {
    let (_, rest) = qualified_name.split_once("::__traitimpl__::")?;
    let mut parts = rest.rsplitn(4, "::").collect::<Vec<_>>();
    if parts.len() != 4 {
        return None;
    }
    parts.reverse();
    let trait_name = parts[0];
    let target = parts[1];
    let method = parts[2];
    Some(format!(
        "impl {} for {} {{ def {}({}) -> {} }}",
        trait_name, target, method, param_list, ret
    ))
}

pub(super) fn callable_definition_display_name(qualified_name: &str, local_name: &str) -> String {
    let local_tail = local_name.rsplit("::").next().unwrap_or(local_name);
    if let Some((_prefix, rest)) = qualified_name.split_once("::__traitimpl__::") {
        let mut parts = rest.rsplitn(4, "::").collect::<Vec<_>>();
        if parts.len() == 4 {
            parts.reverse();
            if parts[2] == local_tail {
                let display_name = local_name
                    .strip_prefix("Global::")
                    .unwrap_or(local_name)
                    .replace("::Global::", "::");
                return trim_script_qualified_display_name(&display_name);
            }
        }
        return Checker::surface_name(local_name).to_string();
    }

    let display_name = if qualified_name
        .rsplit("::")
        .next()
        .is_some_and(|tail| tail == local_tail)
    {
        Checker::surface_name(qualified_name).to_string()
    } else {
        Checker::surface_name(local_name).to_string()
    };
    trim_script_qualified_display_name(&display_name)
}

fn trim_script_qualified_display_name(qualified_name: &str) -> String {
    let Some(rest) = qualified_name.strip_prefix("__Script::") else {
        return qualified_name.to_string();
    };
    let segments = rest.split("::").collect::<Vec<_>>();
    if segments.len() < 2 {
        return qualified_name.to_string();
    }

    let name = segments[segments.len() - 1];
    let parent = segments[segments.len() - 2];
    if parent
        .chars()
        .next()
        .is_some_and(|ch| ch.is_ascii_uppercase())
    {
        format!("{}::{}", parent, name)
    } else {
        name.to_string()
    }
}

#[cfg(test)]
mod tests {
    use std::collections::HashSet;

    use diagnostics::TypeDiagnosticReason;

    use super::*;
    use crate::env::TypeKind;
    use crate::typed::{TypedFacetPath, TypedFacetPathKind, TypedFacetSegment};

    fn test_span() -> Span {
        Span { start: 0, end: 0 }
    }

    fn registered_callable_id(name: &str, unique_id: u32) -> ResolvedId {
        ResolvedId {
            name: name.into(),
            qualified_name: Some(format!("Global::{name}")),
            unique_id,
            compiler_generated: false,
            symbol_info: None,
            span: test_span(),
        }
    }

    fn pending_trait_call(trait_id: &str, receiver: Ty) -> TypedNode {
        TypedNode {
            ty: receiver.clone(),
            span: test_span(),
            node: TypedInner::TraitCall {
                trait_name: trait_id.rsplit("::").next().unwrap_or(trait_id).into(),
                method_name: "method".into(),
                receiver_ty: receiver.clone(),
                obligation: TraitObligation {
                    trait_id: trait_id.into(),
                    trait_args: Vec::new(),
                    receiver,
                },
                dispatch: TraitDispatch::Pending,
                origin: TraitCallOrigin::Explicit,
                args: Vec::new(),
            },
        }
    }

    #[test]
    fn full_trait_obligations_enters_do_safebind_control() {
        let node = TypedNode {
            ty: Ty::Int,
            span: test_span(),
            node: TypedInner::DoSafeBind(Box::new(TypedDoSafeBind {
                pattern: TypedPattern::Wildcard(Ty::Int),
                rhs: Box::new(pending_trait_call("Global::RhsTrait", Ty::Int)),
                projection: SafeBindRhsProjection::PatternInput {
                    pattern_input_ty: Ty::Int,
                },
                failure_target: SafeBindFailureTarget::DoAlternative {
                    empty: Box::new(pending_trait_call("Global::EmptyTrait", Ty::Int)),
                },
                continuation: Box::new(pending_trait_call("Global::NextTrait", Ty::Int)),
                origins: DoSafeBindOrigins {
                    do_span: test_span(),
                    operator_span: test_span(),
                    pattern_span: test_span(),
                    rhs_span: test_span(),
                    result_span: test_span(),
                },
            })),
        };

        let obligations = Checker::full_trait_obligations(&node);
        assert_eq!(
            obligations
                .iter()
                .map(|obligation| obligation.trait_id.as_str())
                .collect::<Vec<_>>(),
            vec![
                "Global::RhsTrait",
                "Global::EmptyTrait",
                "Global::NextTrait"
            ]
        );
    }

    #[test]
    fn registered_user_callable_without_canonical_signature_fails_closed() {
        let mut checker = Checker::new(TypecheckContext::default());
        let id = registered_callable_id("target", 91_001);
        checker.register_function_id(&id);
        checker.env.bind_var(
            id.unique_id,
            Ty::UserFunc {
                fun_idx: 0,
                type_params: Vec::new(),
                call_substitution: Vec::new(),
                params: vec![Ty::Int],
                ret: Box::new(Ty::Int),
            },
        );

        let error = checker
            .check_app(
                &test_span(),
                &Resolved::Var(test_span(), id),
                &[ResolvedRecordLitArg::Positional(Resolved::Lit(
                    test_span(),
                    Lit::Int(int(1)),
                ))],
            )
            .expect_err("a registered declaration must not use the legacy positional checker");
        assert_eq!(
            error.reason(),
            Some(TypeDiagnosticReason::CallableSignatureMetadataMismatch)
        );
    }

    #[test]
    fn resolved_do_requires_canonical_intrinsic_contract_inputs() {
        let mut checker = Checker::new(TypecheckContext::default());
        let node = Resolved::Do(
            test_span(),
            sindr::intrinsic::IntrinsicId::Do,
            sigil::resolved::ResolvedDoContract {
                keyword_span: test_span(),
                monad_fail_trait: None,
                monad_trait: None,
                alternative_trait: None,
            },
            Vec::new(),
            vec![sigil::resolved::ResolvedDoStatement::Statement(
                Resolved::Lit(test_span(), Lit::Int(int(1))),
            )],
        );
        let error = checker
            .check_node(&node)
            .expect_err("do lowering must fail closed without canonical trait metadata");
        assert_eq!(
            error.reason(),
            Some(TypeDiagnosticReason::TypecheckInvariantViolation)
        );
        assert!(matches!(
            error.structured.as_ref().map(|diagnostic| &diagnostic.data),
            Some(DiagnosticData::Policy(diagnostics::PolicyData {
                subject: Some(subject),
                ..
            })) if subject == "canonical intrinsic Trait Monad"
        ));
    }

    #[test]
    fn executable_constructor_audit_enters_generic_declaration_bodies() {
        let checker = Checker::new(TypecheckContext::default());
        let witness_variable = 91_050;
        let constructor_application =
            Ty::SelfApp(vec![Ty::Hole, Ty::Var(witness_variable), Ty::Int]);
        let definition = TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Def(
                0,
                registered_callable_id("generic", 91_051),
                Vec::new(),
                Vec::new(),
                constructor_application.clone(),
                None,
                Box::new(TypedNode {
                    ty: constructor_application,
                    span: test_span(),
                    node: TypedInner::Lit(Lit::Unit),
                }),
                spire::ast::Visibility::Private,
            ),
        };

        assert!(matches!(
            checker.unresolved_executable_constructor_application(&definition),
            Some((ConstructorApplicationOutcome::Deferred { waiting_on }, _))
                if waiting_on == vec![witness_variable]
        ));
    }

    #[test]
    fn executable_constructor_audit_rejects_malformed_self_application() {
        let checker = Checker::new(TypecheckContext::default());
        let node = TypedNode {
            ty: Ty::SelfApp(vec![Ty::Int]),
            span: test_span(),
            node: TypedInner::Lit(Lit::Unit),
        };

        let Some((ConstructorApplicationOutcome::Rejected { failures }, span)) =
            checker.unresolved_executable_constructor_application(&node)
        else {
            panic!("malformed executable SelfApp must be rejected")
        };
        assert_eq!(
            failures,
            vec![ConstructorProjectionFailure::UnsupportedConstructor]
        );
        let error = signatures::constructor_signature_metadata_error(
            "constructor application",
            &span,
            Checker::constructor_projection_failure_detail(&failures),
        );
        assert_eq!(
            error.reason(),
            Some(TypeDiagnosticReason::CallableSignatureMetadataMismatch)
        );
        assert!(!error.message.contains("UnsupportedConstructor"));
    }

    #[test]
    fn registered_builtin_without_canonical_signature_fails_closed() {
        let mut checker = Checker::new(TypecheckContext::default());
        let id = registered_callable_id("runtime_target", 91_002);
        checker.register_function_id(&id);
        checker.env.bind_var(
            id.unique_id,
            Ty::BuiltinFunc {
                name: "runtime_target".into(),
                params: vec![Ty::Int],
                ret: Box::new(Ty::Int),
            },
        );

        let error = checker
            .check_app(
                &test_span(),
                &Resolved::Var(test_span(), id),
                &[ResolvedRecordLitArg::Positional(Resolved::Lit(
                    test_span(),
                    Lit::Int(int(1)),
                ))],
            )
            .expect_err("a registered builtin must not use the legacy positional checker");
        assert_eq!(
            error.reason(),
            Some(TypeDiagnosticReason::CallableSignatureMetadataMismatch)
        );
    }

    #[test]
    fn ordinary_successful_applications_do_not_create_candidate_probe_checkpoints() {
        let mut checker = Checker::new(TypecheckContext::default());
        let plain = registered_callable_id("plain", 91_101);
        let builtin = registered_callable_id("builtin", 91_102);
        let user = registered_callable_id("user", 91_103);
        checker
            .env
            .bind_var(plain.unique_id, Ty::Func(vec![Ty::Int], Box::new(Ty::Int)));
        checker.env.bind_var(
            builtin.unique_id,
            Ty::BuiltinFunc {
                name: "builtin".into(),
                params: vec![Ty::Int],
                ret: Box::new(Ty::Int),
            },
        );
        checker.env.bind_var(
            user.unique_id,
            Ty::UserFunc {
                fun_idx: 0,
                type_params: Vec::new(),
                call_substitution: Vec::new(),
                params: vec![Ty::Int],
                ret: Box::new(Ty::Int),
            },
        );

        for callee in [plain, builtin, user] {
            checker
                .check_app(
                    &test_span(),
                    &Resolved::Var(test_span(), callee),
                    &[ResolvedRecordLitArg::Positional(Resolved::Lit(
                        test_span(),
                        Lit::Int(int(1)),
                    ))],
                )
                .expect("ordinary function application should succeed");
        }

        assert_eq!(checker.candidate_probe_checkpoint_count.get(), 0);
    }

    fn setup_type(
        checker: &mut Checker,
        name: &str,
        fields: Vec<(&str, Ty)>,
        readonly_fields: &[&str],
    ) {
        checker
            .env
            .predeclare_type_def(name.into(), TypeKind::Struct, Vec::new(), Vec::new());
        checker.env.resolve_type_def_signature(
            name,
            fields
                .into_iter()
                .map(|(field, ty)| (field.into(), ty))
                .collect(),
            Vec::new(),
            HashSet::new(),
            readonly_fields
                .iter()
                .map(|field| (*field).into())
                .collect(),
        );
    }

    fn field_segment(
        container_type_name: &str,
        field_name: &str,
        field_index: u32,
        readonly: bool,
    ) -> TypedFacetSegment {
        TypedFacetSegment::Field {
            field_name: field_name.into(),
            origin_index: None,
            field_index,
            container_field_count: 1,
            container_type_name: container_type_name.into(),
            private: false,
            readonly,
        }
    }

    #[test]
    fn error_observation_facet_has_no_owner_update_exception() {
        let mut checker = Checker::new(TypecheckContext::default());
        checker.current_impl_struct_target = Some("Error".into());
        let path = TypedFacetPath {
            source_ty: Ty::Error,
            focus_ty: Ty::Str,
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: TypedFacetPathKind::InfallibleStructural,
            may_fail: false,
            segments: vec![TypedFacetSegment::ReadonlyBuiltin {
                field_name: "message".into(),
                builtin_id: sindr::builtin::builtin_id_by_name("message").unwrap(),
            }],
        };
        let error = checker
            .check_mutating_facet_path_permissions("Facet::set", &path, &test_span())
            .expect_err("Error observations remain readonly in the owner scope");
        assert!(error.message.contains("readonly Error.message"));
    }

    #[test]
    fn mutating_facet_rejects_deep_traversal_through_readonly_field_even_for_owner() {
        let mut checker = Checker::new(TypecheckContext::default());
        setup_type(&mut checker, "Profile", vec![("name", Ty::Str)], &[]);
        setup_type(
            &mut checker,
            "User",
            vec![(
                "profile",
                Ty::Struct(
                    "Profile".into(),
                    NominalType::monomorphic(vec![("name".into(), Ty::Str)]),
                ),
            )],
            &["profile"],
        );
        checker.current_impl_struct_target = Some("User".into());

        let path = TypedFacetPath {
            source_ty: Ty::Struct(
                "User".into(),
                NominalType::monomorphic(vec![(
                    "profile".into(),
                    Ty::Struct(
                        "Profile".into(),
                        NominalType::monomorphic(vec![("name".into(), Ty::Str)]),
                    ),
                )]),
            ),
            focus_ty: Ty::Str,
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: TypedFacetPathKind::InfallibleStructural,
            may_fail: false,
            segments: vec![
                field_segment("User", "profile", 0, true),
                field_segment("Profile", "name", 0, false),
            ],
        };

        let err = checker
            .check_mutating_facet_path_permissions("Facet::set", &path, &test_span())
            .expect_err("deep traversal through readonly field should fail");
        assert!(err.message.contains("readonly field User.profile"));
        assert!(err.message.contains("replace the property itself"));
    }

    #[test]
    fn mutating_facet_allows_owner_to_replace_readonly_field_itself() {
        let mut checker = Checker::new(TypecheckContext::default());
        setup_type(&mut checker, "Profile", vec![("name", Ty::Str)], &[]);
        setup_type(
            &mut checker,
            "User",
            vec![(
                "profile",
                Ty::Struct(
                    "Profile".into(),
                    NominalType::monomorphic(vec![("name".into(), Ty::Str)]),
                ),
            )],
            &["profile"],
        );
        checker.current_impl_struct_target = Some("User".into());

        let path = TypedFacetPath {
            source_ty: Ty::Struct(
                "User".into(),
                NominalType::monomorphic(vec![(
                    "profile".into(),
                    Ty::Struct(
                        "Profile".into(),
                        NominalType::monomorphic(vec![("name".into(), Ty::Str)]),
                    ),
                )]),
            ),
            focus_ty: Ty::Struct(
                "Profile".into(),
                NominalType::monomorphic(vec![("name".into(), Ty::Str)]),
            ),
            update_source_ty: Ty::Hole,
            update_focus_ty: Ty::Hole,
            path_kind: TypedFacetPathKind::InfallibleStructural,
            may_fail: false,
            segments: vec![field_segment("User", "profile", 0, true)],
        };

        checker
            .check_mutating_facet_path_permissions("Facet::set", &path, &test_span())
            .expect("owner replacement of readonly field should succeed");
    }
}

#[cfg(test)]
mod safe_operator_provenance_tests {
    use super::*;

    #[test]
    fn candidate_rollback_restores_only_committed_operator_provenance() {
        let mut checker = Checker::new(TypecheckContext::default());
        let fact = SourceFact::typed(
            SourceRole::OperatorSignature,
            diagnostics::SourceId(0),
            Span { start: 2, end: 3 },
            "(Int, Int) -> Result<Int>",
        );
        checker.safe_operator_results.insert((0, 5), fact.clone());
        let checkpoint = checker.candidate_probe_checkpoint();
        checker.safe_operator_results.clear();
        checker.safe_operator_results.insert((8, 13), fact.clone());
        checker.rollback_candidate_probe(checkpoint);
        assert_eq!(checker.safe_operator_results.len(), 1);
        assert_eq!(checker.safe_operator_results.get(&(0, 5)), Some(&fact));
    }
}
