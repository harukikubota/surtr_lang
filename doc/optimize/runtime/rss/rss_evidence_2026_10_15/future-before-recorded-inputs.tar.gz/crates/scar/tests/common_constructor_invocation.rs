#![deny(dead_code)]

#[allow(dead_code)]
mod support;
use scar::typed::TypedInner;
use std::collections::HashSet;

macro_rules! constructor_case {
    ($case:ident) => {
        (stringify!($case), $case as fn())
    };
}

const CONSTRUCTOR_CASES: &[(&str, fn())] = &[
    constructor_case!(record_keyword_shorthand_checks_field_contract),
    constructor_case!(constructor_invocations_propagate_expected_return),
    constructor_case!(callable_result_context_is_shared_by_helpers_and_operators),
    constructor_case!(arrow_uses_fixed_facet_path_contract),
    constructor_case!(trait_result_conflict_preserves_expected_and_actual_direction),
    constructor_case!(registered_carriers_do_not_supply_constructor_inference_evidence),
    constructor_case!(generic_receiverless_family_helpers_use_expected_return),
    constructor_case!(generic_constructor_trait_wrappers_specialize_all_method_roles),
    constructor_case!(monadt_lift_uses_trait_target_and_value_arguments_together),
];

#[test]
fn constructor_case_inventory_has_unique_names_and_functions() {
    let direct_tests = include_str!("common_constructor_invocation.rs")
        .lines()
        .filter(|line| *line == "#[test]")
        .count();
    assert_eq!(
        direct_tests, 2,
        "constructor cases must be registered instead of using standalone #[test]"
    );

    let mut names = HashSet::new();
    let mut functions = HashSet::new();
    for &(name, case) in CONSTRUCTOR_CASES {
        assert!(
            names.insert(name),
            "duplicate constructor case name: {name}"
        );
        assert!(
            functions.insert(case as usize),
            "duplicate constructor case function: {name}"
        );
    }
}

#[test]
fn common_constructor_invocation_suite() {
    for &(name, case) in CONSTRUCTOR_CASES {
        eprintln!("common constructor invocation case: {name}");
        case();
    }
}

fn constructor_invocations_propagate_expected_return() {
    for expression in [
        "Functor::fmap([1], {|x: Int| []})",
        "[1] |*> {|x: Int| []}",
        "Monad::bind([1], {|x: Int| []})",
        "[1] |>= {|x: Int| []}",
    ] {
        let source = format!("value: List<List<String>> = {expression}");
        support::typecheck(support::resolve_with_builtin_prelude(&source))
            .unwrap_or_else(|error| panic!("{source}: {error:?}"));
    }
}

fn callable_result_context_is_shared_by_helpers_and_operators() {
    for (expected, expression) in [
        (
            "List<List<String>>",
            "Applicative::ap([{|x: Int| []}], [1])",
        ),
        ("List<List<String>>", "[{|x: Int| []}] |*| [1]"),
        ("(Int -> List<String>)", "{|x: Int| x} >> {|x: Int| []}"),
        (
            "(Int -> List<List<String>>)",
            "{|x: Int| [x]} >* {|x: Int| []}",
        ),
        ("(Int -> List<String>)", "{|x: Int| [x]} >=> {|x: Int| []}"),
    ] {
        let source = format!("value: {expected} = {expression}");
        support::typecheck(support::resolve_with_builtin_prelude(&source))
            .unwrap_or_else(|error| panic!("{source}: {error:?}"));
    }
}

fn arrow_uses_fixed_facet_path_contract() {
    support::typecheck(support::resolve_with_builtin_prelude(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
user = User(Profile("alice"))
Facet::view(User.profile -> Profile.name, user)"#,
    ))
    .expect("Facet arrow composition should follow Facet::compose");

    let source = "value = 1 -> 2";
    let err = support::typecheck(support::resolve_with_builtin_prelude(source))
        .expect_err("non-Facet arrow must fail");
    assert!(err.message.contains("Expected Facet<...> value"), "{err:?}");
}

fn trait_result_conflict_preserves_expected_and_actual_direction() {
    let error = support::typecheck(support::resolve_with_builtin_prelude(
        "value: Int = Show::to_string(1)",
    ))
    .expect_err("the declared result is String, while the context requires Int");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeMismatch)
    );
    let data = error.structured.unwrap().data.to_json_value();
    assert_eq!(data["expected_type"], "Int");
    assert_eq!(data["actual_type"], "String");
}

fn registered_carriers_do_not_supply_constructor_inference_evidence() {
    let definitions = r#"
defenum Boxed<$T> { Box($T) }
impl Functor for Boxed<$T> {
    def fmap(self: Boxed<$A>, mapper: ($A -> $B)) -> Boxed<$B> {
        match self { Boxed::Box(value) => Boxed::Box(mapper(value)) }
    }
}
impl Applicative for Boxed<$T> {
    def pure::<Boxed<$T>>(value: $A) -> Boxed<$A> { Boxed::Box(value) }
    def ap(mapper: Boxed<($A -> $B)>, value: Boxed<$A>) -> Boxed<$B> {
        match mapper {
            Boxed::Box(f) => match value { Boxed::Box(item) => Boxed::Box(f(item)) }
        }
    }
}
impl Monad for Boxed<$T> {
    def return::<Boxed<$T>>(value: $A) -> Boxed<$A> { Boxed::Box(value) }
    def bind(self: Boxed<$A>, mapper: ($A -> Boxed<$B>)) -> Boxed<$B> {
        match self { Boxed::Box(value) => mapper(value) }
    }
}
"#;
    let check = |tail| {
        let source = format!("{definitions}\n{tail}");
        let ast = spire::parse_with_context(&source, spire::ParserContext::project(0)).unwrap();
        support::typecheck(support::resolve_ast_with_builtin_prelude(ast).unwrap())
    };
    let error = check("value = Monad::return(1) |>= {|x| Monad::return(x)}")
        .expect_err("registration count supplies no source-level carrier evidence");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::AmbiguousReturnTypeArgument),
        "{error:?}"
    );
    check("value = Monad::return(1) |>= {|x| Boxed::Box(x)}")
        .expect("a concrete callback result supplies the carrier");
    check("value: Boxed<Int> = Monad::return(1) |>= {|x| Monad::return(x)}")
        .expect("an expected concrete carrier supplies the missing evidence");
    let error = check("value = Functor::fmap(Monad::return(1), {|x: Int| x})")
        .expect_err("a plain mapped payload never provides the outer carrier");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::AmbiguousReturnTypeArgument)
    );
    check("value: Boxed<Int> = Functor::fmap(Monad::return(1), {|x: Int| x})")
        .expect("the expected carrier determines both helper calls");
    check("value = Functor::fmap(Monad::return::<Boxed>(1), {|x: Int| x})")
        .expect("an explicit inner constructor head supplies source evidence");

    for prefix in ["", definitions] {
        for annotation in ["NotAType", "List<Int, String>", "DoBlock<Int>"] {
            for callback in [
                format!("{{|x: {annotation}| Ok(x)}}"),
                format!("{{|x| annotated: {annotation} = x\n Ok(annotated)}}"),
                format!("({{|x: {annotation}| Ok(x)}})"),
                format!("{{|x| Monad::return(x) |>= {{|y: {annotation}| Ok(y)}}}}"),
            ] {
                // Keep both annotation offsets identical so the complete source facts
                // can be compared, including nested structured annotation errors.
                let direct = format!("{prefix}\nvalue = {:16} |>= {callback}", "Ok(1)");
                let probed = format!("{prefix}\nvalue = Monad::return(1) |>= {callback}");
                let direct_error =
                    support::typecheck(support::resolve_with_builtin_prelude(&direct))
                        .expect_err("invalid annotations must fail for a known carrier");
                let probed_error =
                    support::typecheck(support::resolve_with_builtin_prelude(&probed))
                        .expect_err("invalid annotations must fail before carrier selection");
                assert_eq!(probed_error, direct_error, "{probed}");
            }
        }
        let source = format!("{prefix}\nvalue = Monad::return(1) |>= {{|x: String| Ok(x)}}");
        let error = support::typecheck(support::resolve_with_builtin_prelude(&source))
            .expect_err("valid annotations with incompatible input types still reject candidates");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation)
        );
        let diagnostics::DiagnosticData::CandidateSelection(data) = error.structured.unwrap().data
        else {
            panic!("expected candidate failures for a type relation error");
        };
        assert!(!data.failures.is_empty());
        assert!(data
            .failures
            .iter()
            .all(|failure| !failure.detail.is_empty()));
        support::typecheck(support::resolve_with_builtin_prelude(&format!(
            "{prefix}\nvalue = Monad::return(1) |>= {{|x: Int| Ok(x)}}"
        )))
        .expect("a valid callback annotation and concrete result still supply carrier evidence");
    }
}

fn generic_receiverless_family_helpers_use_expected_return() {
    let definitions = r#"
deftrait Family where Self: Type<$A> {
    def make::<Self>(value: $A) -> Self<$A>
    def map(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

defenum Boxed<$T> { Box($T) }
impl Family for Boxed<$T> {
    def make::<Boxed<$T>>(value: $A) -> Boxed<$A> { Boxed::Box(value) }
    def map(self: Boxed<$A>, mapper: ($A -> $B)) -> Boxed<$B> {
        match self { Boxed::Box(value) => Boxed::Box(mapper(value)) }
    }
}
"#;
    for expression in [
        "Family::make(1)",
        "Family::map(Family::make(1), {|x: Int| x})",
    ] {
        let source = format!("{definitions}\nvalue: Boxed<Int> = {expression}");
        let ast = spire::parse_with_context(&source, spire::ParserContext::project(0)).unwrap();
        support::typecheck(support::resolve_ast_with_builtin_prelude(ast).unwrap())
            .expect("receiverless helpers are signature-driven");
    }
}

fn monadt_lift_uses_trait_target_and_value_arguments_together() {
    let identity_impl = r#"
impl MonadT<Identity> for Option<$T> {
    def lift::<Option<$T>>(value: Identity<$A>) -> Option<$A> {
        Option::Some(Identity::run(value))
    }
}
"#;
    for expression in ["Monad::return(1)", "Applicative::pure(1)"] {
        let underconstrained =
            format!("{identity_impl}\nresult: Option<Int> = MonadT::lift({expression})");
        let error = support::typecheck(support::resolve_with_builtin_prelude(&underconstrained))
            .expect_err("a fixed MonadT argument must not guess a nested constructor witness");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::AmbiguousReturnTypeArgument),
            "{expression}: {error:?}"
        );
    }

    let disjoint_impl = r#"
impl MonadT<Option> for Option<$T> {
    def lift::<Option<$T>>(value: Option<$A>) -> Option<$A> { value }
}
"#;
    let source_selects_identity = format!(
        "{identity_impl}\n{disjoint_impl}\nresult: Option<Int> = MonadT::lift(Identity::new(1))"
    );
    support::typecheck(support::resolve_with_builtin_prelude(
        &source_selects_identity,
    ))
    .unwrap_or_else(|error| {
        panic!("the Identity input selects its matching MonadT argument: {error:?}")
    });

    let incompatible_result =
        format!("{identity_impl}\nresult: Option<String> = MonadT::lift(Identity::new(1))");
    support::typecheck(support::resolve_with_builtin_prelude(&incompatible_result))
        .expect_err("the selected Identity payload must remain Int through the expected result");
}

fn generic_constructor_trait_wrappers_specialize_all_method_roles() {
    for (map_applicative, keep_applicative) in [
        (
            r#"def map_applicative(value: $F<$A>, mapper: ($A -> $B)) -> $F<$B>
where $F: Applicative {
    Functor::fmap(value, mapper)
}"#,
            r#"
def keep_applicative(value: $F<$A>) -> $F<$A> where $F: Applicative { value }"#,
        ),
        (
            r#"def map_applicative(value: Applicative<$A>, mapper: ($A -> $B)) -> Applicative<$B> {
    Functor::fmap(value, mapper)
}"#,
            r#"
def keep_applicative(value: Applicative<$A>) -> Applicative<$A> { value }"#,
        ),
    ] {
        let source = [
            r#"
def map_functor(value: $F<$A>, mapper: ($A -> $B)) -> $F<$B> where $F: Functor {
    Functor::fmap(value, mapper)
}
"#,
            map_applicative,
            keep_applicative,
            r#"
strings: List<String> = map_functor([1], {|value: Int| "mapped"})
booleans: List<Boolean> = map_functor([2], {|value: Int| True})
inherited: List<String> = map_applicative([3], {|value: Int| "mapped"})
kept: List<Int> = keep_applicative([4])
"#,
        ]
        .concat();

        let nodes = support::typecheck(support::resolve_with_builtin_prelude(&source))
            .expect("both constructor constraint spellings share the call-site specialization");
        let map_functor_specializations = nodes
            .iter()
            .filter_map(|node| {
                let TypedInner::Bind(_, rhs) = &node.node else {
                    return None;
                };
                let TypedInner::App(func, _) = &rhs.node else {
                    return None;
                };
                let TypedInner::Var(id) = &func.node else {
                    return None;
                };
                let scar::types::Ty::UserFunc { fun_idx, .. } = &func.ty else {
                    return None;
                };
                (id.name == "map_functor").then_some(*fun_idx)
            })
            .collect::<Vec<_>>();
        assert_eq!(map_functor_specializations.len(), 2);
        assert_ne!(
            map_functor_specializations[0], map_functor_specializations[1],
            "mapped output type must participate in the specialization key"
        );
    }
}

fn record_keyword_shorthand_checks_field_contract() {
    let prefix = "defrecord User(name: String, age: Int)\nname = \"Ada\"\nage = 37\nyears = 38\n";
    for expression in [
        "User(name: name, age)",
        "User(age: age, name)",
        "User(name, age)",
    ] {
        let source = format!("{prefix}value = {expression}");
        support::typecheck_with_rules(&source, sindr::policy::RuntimeSourcePolicy::script())
            .unwrap_or_else(|error| panic!("{expression}: {error:?}"));
    }
    use diagnostics::TypeDiagnosticReason as Reason;
    for (expression, reason) in [
        ("User(name: name, 37)", Some(Reason::ArgumentModeMismatch)),
        (
            "User(name: name, age + 1)",
            Some(Reason::ArgumentModeMismatch),
        ),
        (
            "User(name: name, name.length)",
            Some(Reason::ArgumentModeMismatch),
        ),
        (
            "User(name: name, years)",
            Some(Reason::UnknownNamedArgument),
        ),
        (
            "User(name: name, age, age: 37)",
            Some(Reason::DuplicateArgument),
        ),
        ("User(name: name)", Some(Reason::MissingArgument)),
        (
            "User(name: name, age: \"37\")",
            Some(Reason::ArgumentTypeMismatch),
        ),
    ] {
        let source = format!("{prefix}value = {expression}");
        let error =
            support::typecheck_with_rules(&source, sindr::policy::RuntimeSourcePolicy::script())
                .expect_err(expression);
        assert_eq!(error.reason(), reason, "{expression}: {error:?}");
        if reason == Some(Reason::ArgumentModeMismatch) {
            assert!(
                error
                    .hint
                    .as_deref()
                    .unwrap_or("")
                    .contains("explicit field name or a bare variable shorthand"),
                "{expression}: {error:?}"
            );
        }
    }
}
