#![deny(dead_code)]

#[path = "support/case_registry.rs"]
mod case_registry;

case_registry::register_case_suite!(
    "return_type_arguments.rs",
    [
        accepts_declared_return_only_input,
        recursively_finds_missing_return_only_input,
        rejects_input_introduced_by_value_and_return_type_argument,
        rejects_unused_return_type_argument,
        rejects_constructor_variable_without_constructor_trait_constraint,
        accepts_constructor_variable_with_constructor_trait_constraint,
        rejects_trait_name_as_where_constraint_subject,
        recursive_value_occurrences_do_not_require_return_type_arguments,
        direct_type_constructor_trait_return_type_argument_is_accepted,
        direct_type_constructor_trait_uses_one_typed_witness,
        rejects_omitted_return_only_input_without_a_witness,
        accepts_return_only_input_inferred_from_expected_result,
        rejects_ambiguous_return_only_input_inside_an_unannotated_binding,
        accepts_return_only_input_forwarded_by_an_outer_generic_result,
        forwards_return_only_where_obligation_through_outer_generic_bound,
        callable_result_binding_requires_a_concrete_return_type_argument,
        accepts_explicit_return_type_argument_on_ordinary_callable,
        ordinary_return_type_argument_requires_a_complete_type,
        trait_method_return_type_argument_accepts_a_structural_bare_target_head,
        trait_method_bare_target_head_rejects_an_unshared_argument,
        trait_method_top_level_underscore_uses_expected_return_inference,
        constructor_return_type_argument_accepts_bare_full_and_partial_carriers,
        applied_constructor_return_type_argument_accepts_enclosing_fixed_type_variable,
        constructor_return_type_argument_rejects_an_outer_constructor_variable,
        constructor_return_type_argument_defers_nominal_constraints_on_underscores,
        rejects_constructor_head_with_an_unresolved_fixed_argument,
        alternative_empty_allows_a_user_defined_captured_carrier_representation,
        alternative_empty_rejects_an_unresolved_mapped_slot_inside_a_carrier_rta,
        rejects_captured_constructor_head_with_an_unresolved_fixed_argument,
        expected_constructor_selection_is_independent_of_impl_order,
        omitted_and_underscore_return_type_arguments_share_inference,
        rejects_return_type_argument_arity_underflow_without_partial_zip,
        rejects_return_type_argument_arity_overflow_without_partial_zip,
        rejects_explicit_return_type_argument_conflicting_with_expected_return,
        mismatch_reports_the_conflicting_return_type_argument_ordinal,
        ambiguity_reports_the_unresolved_return_type_argument_ordinal,
        accepts_explicit_return_type_argument_capture_with_expected_shape,
        rejects_explicit_capture_conflicting_with_expected_return,
        rejects_ambiguous_return_type_argument_capture,
        omitted_and_underscore_captures_share_ambiguity_check,
        expected_generic_result_allows_err_only_self_match_arm,
    ]
);

#[allow(dead_code)]
mod support;

use diagnostics::TypeDiagnosticReason;
use scar::typed::TypedInner;
use sigil::resolved::Resolved;

fn resolve_with_standard_environment(source: &str) -> Vec<Resolved> {
    let ast = spire::parse_with_context(source, spire::ParserContext::project(0))
        .expect("source should parse with the standard environment");
    support::resolve_ast_with_builtin_prelude(ast)
        .expect("source should resolve with the standard environment")
}

fn typecheck_with_standard_environment(
    source: &str,
) -> Result<Vec<scar::typed::TypedNode>, scar::error::TypeError> {
    support::typecheck(resolve_with_standard_environment(source))
}

fn assert_reason(source: &str, expected: TypeDiagnosticReason) -> scar::error::TypeError {
    let error = typecheck_with_standard_environment(source).expect_err("source must be rejected");
    assert_eq!(error.reason(), Some(expected), "unexpected error: {error}");
    error
}

fn accepts_declared_return_only_input() {
    typecheck_with_standard_environment(
        r#"deftrait Factory {
  def make::<$A>() -> $A
}"#,
    )
    .expect("a declared return-only input should be accepted");
}

fn recursively_finds_missing_return_only_input() {
    let error = assert_reason(
        r#"def missing(mapper: ($A -> Int)) -> Option<$B> { 0 }"#,
        TypeDiagnosticReason::MissingReturnTypeArgument,
    );
    assert_eq!(error.message, "return-only type input `$B` is not declared");
}

fn rejects_input_introduced_by_value_and_return_type_argument() {
    for source in [
        r#"deftrait FixtureFunctor
where
  Self: Type<$A>
{}

def duplicate::<$F>(value: $F<$A>) -> $F<$A>
where
  $F: FixtureFunctor
{ value }"#,
        r#"deftrait FixtureFunctor
where
  Self: Type<$A>
{}

def duplicate::<FixtureFunctor>(value: FixtureFunctor<$A>) -> FixtureFunctor<$A> { value }"#,
    ] {
        let error = assert_reason(
            source,
            TypeDiagnosticReason::DuplicateReturnTypeArgumentInput,
        );
        assert!(error.message.contains("is introduced more than once"));
        let structured = error
            .structured
            .expect("diagnostic should retain both origins");
        assert_eq!(structured.related.len(), 1);
    }
}

fn rejects_unused_return_type_argument() {
    let error = assert_reason(
        r#"def unused::<$A>() -> Int { 0 }"#,
        TypeDiagnosticReason::UnusedReturnTypeArgument,
    );
    assert_eq!(
        error.message,
        "return type argument `$A` does not appear in the return type"
    );
}

fn rejects_constructor_variable_without_constructor_trait_constraint() {
    let error = assert_reason(
        r#"def invalid(value: $F<$A>) -> $F<$A> { value }"#,
        TypeDiagnosticReason::MissingTypeConstructorConstraint,
    );
    assert_eq!(
        error.message,
        "type constructor variable `$F` requires a TypeCtorTrait constraint"
    );
}

fn accepts_constructor_variable_with_constructor_trait_constraint() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureFunctor
where
  Self: Type<$A>
{}

deftrait Keeper {
  def keep(value: $F<$A>) -> $F<$A>
  where
    $F: FixtureFunctor
}"#,
    )
    .expect("a constrained constructor variable application should be accepted");
}

fn rejects_trait_name_as_where_constraint_subject() {
    let error = assert_reason(
        r#"deftrait FixtureAdd {}

deftrait FixtureApplicative
where
  Self: Type<$A>
{}

def invalid_subject::<$F>() -> $F<Unit>
where
  FixtureApplicative: FixtureAdd
{ 0 }"#,
        TypeDiagnosticReason::InvalidTraitConstraintSubject,
    );
    assert_eq!(
        error.message,
        "trait `FixtureApplicative` cannot be used as a constraint subject"
    );
}

fn recursive_value_occurrences_do_not_require_return_type_arguments() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureMapper {
  def map(mapper: ($A -> $B)) -> ($A -> $B)
}"#,
    )
    .expect("nested function-type inputs should be classified as value inputs");
}

fn direct_type_constructor_trait_return_type_argument_is_accepted() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

deftrait GuardFactory {
  def guard::<FixtureAlternative>(condition: Boolean) -> FixtureAlternative<Unit>
}"#,
    )
    .expect("direct TypeCtorTrait syntax should normalize as one constructor input");
}

fn direct_type_constructor_trait_uses_one_typed_witness() {
    let typed = typecheck_with_standard_environment(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

impl FixtureAlternative for List<$T>
where
  $T: FixtureAlternative.$A
{}

def guard::<FixtureAlternative>(condition: Boolean) -> FixtureAlternative<Unit> {
  []
}"#,
    )
    .expect("a concrete constructor body should satisfy the direct constructor signature");
    let (_, return_type_arguments, return_type) = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Def(_, id, arguments, _, return_type, _, _, _) if id.name == "guard" => {
                Some((id, arguments, return_type))
            }
            _ => None,
        })
        .expect("guard should be present in the typed program");
    let rta_witness = match &return_type_arguments[0].ty {
        scar::types::Ty::SelfApp(items) => &items[1],
        other => panic!("expected constructor RTA, got {other:?}"),
    };
    assert_eq!(rta_witness, return_type);
}

fn rejects_omitted_return_only_input_without_a_witness() {
    let error = assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
make()"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
    assert_eq!(
        error.message,
        "return type arguments for `make` cannot be inferred"
    );
}

fn accepts_return_only_input_inferred_from_expected_result() {
    typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
value: List<Int> = make()"#,
    )
    .expect("the expected result type should determine the return-only input");
}

fn rejects_ambiguous_return_only_input_inside_an_unannotated_binding() {
    assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
value = make()"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn accepts_return_only_input_forwarded_by_an_outer_generic_result() {
    typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
def forward::<$A>() -> List<$A> { make() }"#,
    )
    .expect("an outer declared input should witness the nested return-only input");
}

fn forwards_return_only_where_obligation_through_outer_generic_bound() {
    for tail in [
        "inner()",
        "if(True, inner(), inner())",
        "match 0 { 0 => inner(), _ => inner() }",
    ] {
        let source = r#"deftrait FixtureDefault {
  def default::<Self>() -> Self
}

impl FixtureDefault for Int {
  def default::<Int>() -> Int { 0 }
}

def inner::<$A>() -> $A
where
  $A: FixtureDefault
{
  FixtureDefault::default()
}

def outer::<$A>() -> $A
where
  $A: FixtureDefault
{
  BODY
}

value: Int = outer()"#
            .replace("BODY", tail);
        typecheck_with_standard_environment(&source)
            .unwrap_or_else(|error| panic!("generic proof forwarding failed for {tail}: {error}"));
    }
}

fn callable_result_binding_requires_a_concrete_return_type_argument() {
    let error = typecheck_with_standard_environment(
        r#"def identity::<$A>() -> ($A -> $A) { {|value| value} }
callable = identity()
result: Int = callable(42)"#,
    )
    .expect_err("a later call must not choose an unresolved callable binding's witness");
    assert!(
        error
            .message
            .contains("Callable binding requires a concrete signature"),
        "{error:?}"
    );

    typecheck_with_standard_environment(
        r#"def identity::<$A>() -> ($A -> $A) { {|value| value} }
callable: (Int -> Int) = identity()
result: Int = callable(42)"#,
    )
    .expect("a concrete callable annotation may choose the return type argument");
}

fn accepts_explicit_return_type_argument_on_ordinary_callable() {
    typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
value: List<Int> = make::<Int>()"#,
    )
    .expect("an ordinary callable should accept its declared ReturnTypeArgument");
}

fn ordinary_return_type_argument_requires_a_complete_type() {
    let error = typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
value = make::<List>()"#,
    )
    .expect_err("a bare constructor head is not a complete ordinary type argument");
    assert!(
        error.message.contains("Unknown type: List"),
        "unexpected error: {error}"
    );
}

fn trait_method_return_type_argument_accepts_a_structural_bare_target_head() {
    typecheck_with_standard_environment(
        r#"defenum Source<$A> { Source($A), }
defenum Target<$A> { Target($A), }

deftrait FixtureConvert<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl FixtureConvert<Target<$A>> for Source<$A> {
  def convert::<Target<$A>>(self: Self) -> Target<$A> {
    match self {
      Source::Source(value) => Target::Target(value),
    }
  }
}

source: Source<Int> = Source::Source(1)
bare: Target<Int> = FixtureConvert::convert::<Target>(source)
full: Target<Int> = FixtureConvert::convert::<Target<Int>>(source)"#,
    )
    .expect("the matching impl must share its payload variable from source to target");
}

fn trait_method_bare_target_head_rejects_an_unshared_argument() {
    let error = typecheck_with_standard_environment(
        r#"defenum Source<$A> { Source($A), }
defenum Target<$L, $A> { Target($A), }

deftrait FixtureConvert<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl FixtureConvert<Target<$L, $A>> for Source<$A> {
  def convert::<Target<$L, $A>>(self: Self) -> Target<$L, $A> {
    match self {
      Source::Source(value) => Target::Target(value),
    }
  }
}

source: Source<Int> = Source::Source(1)
value = FixtureConvert::convert::<Target>(source)"#,
    )
    .expect_err("a bare head must not infer a captured argument from impl count or order");
    assert!(
        matches!(
            error.reason(),
            Some(
                TypeDiagnosticReason::AmbiguousReturnTypeArgument
                    | TypeDiagnosticReason::UnresolvedTraitMethodInstantiation
            )
        ),
        "unexpected error: {error}"
    );
}

fn trait_method_top_level_underscore_uses_expected_return_inference() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureDefault {
  def default::<Self>() -> Self
}

impl FixtureDefault for Int {
  def default::<Int>() -> Int { 0 }
}

value: Int = FixtureDefault::default::<_>()"#,
    )
    .expect("a zero-argument Trait method's `_` RTA should defer to the expected result");

    typecheck_with_standard_environment(
        r#"deftrait Maker {
  def make::<$A>(self: Self) -> List<$A>
}

impl Maker for Unit {
  def make::<$A>(self: Self) -> List<$A> { [] }
}

value: List<Int> = Maker::make::<_>(())"#,
    )
    .expect("the regular Trait-call path should use the same `_` inference rule");
}

fn constructor_return_type_argument_accepts_bare_full_and_partial_carriers() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

impl FixtureAlternative for List<$T>
where
  $T: FixtureAlternative.$A
{}

def guard::<FixtureAlternative>(condition: Boolean) -> FixtureAlternative<Unit> { [] }
value: List<Unit> = guard::<List>(True)"#,
    )
    .expect("a direct constructor input should accept its bare constructor head");

    typecheck_with_standard_environment(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

impl FixtureAlternative for List<$T>
where
  $T: FixtureAlternative.$A
{}

def guard::<FixtureAlternative>(condition: Boolean) -> FixtureAlternative<Unit> { [] }
value: List<Unit> = guard::<List<Unit>>(True)"#,
    )
    .expect("a constructor input should accept a fully applied carrier");

    typecheck_with_standard_environment(
        r#"deftrait FixtureApplicative
where
  Self: Type<$A>
{}

defenum FixtureEither<$L, $R> {
  Left($L),
  Right($R),
}

impl FixtureApplicative for FixtureEither<$L, $R>
where
  $R: FixtureApplicative.$A
{}

def pure::<FixtureApplicative>(value: $A) -> FixtureApplicative<$A> { FixtureEither::Right(value) }
value: FixtureEither<String, Int> = pure::<FixtureEither<String, _>>(10)"#,
    )
    .expect("a constructor input should infer only the underscore position");
}

fn applied_constructor_return_type_argument_accepts_enclosing_fixed_type_variable() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureApplicative
where
  Self: Type<$A>
{
  def pure::<Self>(value: $A) -> Self<$A>
}

defenum FixtureEither<$L, $R> {
  Left($L),
  Right($R),
}

impl FixtureApplicative for FixtureEither<$L, $R>
where
  $R: FixtureApplicative.$A
{
  def pure::<FixtureEither<$L, $R>>(value: $A) -> FixtureEither<$L, $A> {
    FixtureEither::Right(value)
  }
}

def wrap(value: $L) -> FixtureEither<$L, Int> {
  FixtureApplicative::pure::<FixtureEither<$L, _>>(1)
}

value: FixtureEither<String, Int> = wrap("tag")"#,
    )
    .expect("an applied carrier may use an enclosing ordinary type variable as a fixed argument");
}

fn constructor_return_type_argument_rejects_an_outer_constructor_variable() {
    let error = typecheck_with_standard_environment(
        r#"deftrait FixtureApplicative
where
  Self: Type<$A>
{
  def pure::<Self>(value: $A) -> Self<$A>
}

def invalid(value: $F<Int>) -> $F<Int>
where
  $F: FixtureApplicative
{
  FixtureApplicative::pure::<$F>(1)
}"#,
    )
    .expect_err("the carrier identity cannot be supplied by an outer constructor variable");
    assert!(
        error
            .message
            .contains("cannot use constructor variable `$F` as its carrier"),
        "unexpected error: {error}"
    );
}

fn constructor_return_type_argument_defers_nominal_constraints_on_underscores() {
    let source = r#"deftrait Marker {}
impl Marker for Int {}

deftrait Maker
where
  Self: Type<$A>
{
  def make::<Self>() -> Self
}

defenum Bounded<$M, $A>
where
  $M: Marker
  $A: Marker
{
  Value,
}

impl Maker for Bounded<Int, $T>
where
  $T: Maker.$A
  $T: Marker
{
  def make::<Bounded<Int, $T>>() -> Bounded<Int, $T> {
    Bounded<Int, $T>::Value
  }
}

value: Bounded<Int, EXPECTED> = Maker::make::<Bounded<Int, _>>()"#;
    typecheck_with_standard_environment(&source.replace("EXPECTED", "Int"))
        .expect("an RTA-local `_` should be checked after expected-result inference");

    let error = typecheck_with_standard_environment(&source.replace("EXPECTED", "String"))
        .expect_err("the deferred declaration constraint must reject an invalid inferred type");
    assert!(
        error
            .message
            .contains("does not satisfy declaration constraint Marker"),
        "unexpected error: {error}"
    );
}

fn rejects_constructor_head_with_an_unresolved_fixed_argument() {
    assert_reason(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

defenum FixtureEither<$L, $R> {
  Left($L),
  Right($R),
}

impl FixtureAlternative for FixtureEither<$L, $R>
where
  $R: FixtureAlternative.$A
{}

def choose::<FixtureAlternative>() -> FixtureAlternative<Unit> { FixtureEither::Right(()) }
value = choose::<FixtureEither>()"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn alternative_empty_allows_a_user_defined_captured_carrier_representation() {
    typecheck_with_standard_environment(
        r#"deftrait FixtureApplicative
where
  Self: Type<$A>
{}

deftrait FixtureAlternative
where
  Self: FixtureApplicative
{
  def empty::<Self>() -> Self
  def choose(left: Self<$A>, right: Self<$A>) -> Self<$A>
}

defenum Choice<$L, $A> {
  Empty($L),
  Value($A),
}

impl FixtureApplicative for Choice<$L, $T>
where
  $T: FixtureApplicative.$A
{}

impl FixtureAlternative for Choice<String, $T> {
  def empty::<Choice<String, $T>>() -> Choice<String, $T> {
    Choice::Empty("missing")
  }

  def choose(left: Choice<String, $A>, right: Choice<String, $A>) -> Choice<String, $A> {
    left
  }
}

empty: Choice<String, Int> = FixtureAlternative::empty::<Choice<String, Int>>()
first: Choice<String, Int> = Choice::Value(1)
value: Choice<String, Int> = FixtureAlternative::choose(empty, first)"#,
    )
    .expect(
        "FixtureAlternative::empty must use the user impl rather than a representation allowlist",
    );
}

fn alternative_empty_rejects_an_unresolved_mapped_slot_inside_a_carrier_rta() {
    assert_reason(
        r#"deftrait FixtureApplicative
where
  Self: Type<$A>
{}

deftrait FixtureAlternative
where
  Self: FixtureApplicative
{
  def empty::<Self>() -> Self
}

defenum Choice<$L, $A> {
  Empty($L),
  Value($A),
}

impl FixtureApplicative for Choice<$L, $T>
where
  $T: FixtureApplicative.$A
{}

impl FixtureAlternative for Choice<String, $T> {
  def empty::<Choice<String, $T>>() -> Choice<String, $T> {
    Choice::Empty("missing")
  }
}

value = FixtureAlternative::empty::<Choice<String, _>>()"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn rejects_captured_constructor_head_with_an_unresolved_fixed_argument() {
    assert_reason(
        r#"deftrait FixtureAlternative
where
  Self: Type<$A>
{}

defenum FixtureEither<$L, $R> {
  Left($L),
  Right($R),
}

impl FixtureAlternative for FixtureEither<$L, $R>
where
  $R: FixtureAlternative.$A
{}

def choose::<FixtureAlternative>() -> FixtureAlternative<Unit> { FixtureEither::Right(()) }
factory = &choose::<FixtureEither>"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn expected_constructor_selection_is_independent_of_impl_order() {
    for impls in [
        r#"impl Factory for First<$T> {
  def make::<First<$T>>() -> First<Unit> { First::First(()) }
}

impl Factory for Second<$T> {
  def make::<Second<$T>>() -> Second<Unit> { Second::Second(()) }
}"#,
        r#"impl Factory for Second<$T> {
  def make::<Second<$T>>() -> Second<Unit> { Second::Second(()) }
}

impl Factory for First<$T> {
  def make::<First<$T>>() -> First<Unit> { First::First(()) }
}"#,
    ] {
        let source = format!(
            r#"defenum First<$A> {{ First($A) }}
defenum Second<$A> {{ Second($A) }}

deftrait Factory
where
  Self: Type<$A>
{{
  def make::<Self>() -> Self<Unit>
}}

{impls}

def choose::<Factory>() -> Factory<Unit> {{ Factory::make() }}
value: Second<Unit> = choose()"#
        );
        typecheck_with_standard_environment(&source)
            .expect("expected return type must select Second regardless of impl order");
    }
}

fn omitted_and_underscore_return_type_arguments_share_inference() {
    typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
omitted: List<Int> = make()
underscore: List<Int> = make::<_>()"#,
    )
    .expect("omitted and underscore ReturnTypeArguments should use the same inference route");
}

fn rejects_return_type_argument_arity_underflow_without_partial_zip() {
    assert_reason(
        r#"def choose::<$A, $B>() -> ($A, $B) { choose() }
choose::<Int>()"#,
        TypeDiagnosticReason::ReturnTypeArgumentArityMismatch,
    );
}

fn rejects_return_type_argument_arity_overflow_without_partial_zip() {
    assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
make::<Int, String>()"#,
        TypeDiagnosticReason::ReturnTypeArgumentArityMismatch,
    );
}

fn rejects_explicit_return_type_argument_conflicting_with_expected_return() {
    let error = assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
value: List<String> = make::<Int>()"#,
        TypeDiagnosticReason::ReturnTypeArgumentMismatch,
    );
    let structured = error
        .structured
        .expect("mismatch should retain both origins");
    assert_eq!(
        structured.primary.role,
        diagnostics::SourceRole::ReturnTypeArgument
    );
    assert_eq!(
        structured.related[0].role,
        diagnostics::SourceRole::Expected
    );
}

fn mismatch_reports_the_conflicting_return_type_argument_ordinal() {
    let error = assert_reason(
        r#"def choose::<$A, $B>() -> ($A, $B) { choose() }
value: (Int, String) = choose::<Int, Boolean>()"#,
        TypeDiagnosticReason::ReturnTypeArgumentMismatch,
    );
    let structured = error.structured.expect("mismatch should be structured");
    assert_eq!(
        structured.origin,
        diagnostics::DiagnosticOrigin::ReturnTypeArgument { ordinal: 1 }
    );
}

fn ambiguity_reports_the_unresolved_return_type_argument_ordinal() {
    let error = assert_reason(
        r#"def choose::<$A, $B>() -> ($A, $B) { choose() }
value = choose::<Int, _>()"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
    let structured = error.structured.expect("ambiguity should be structured");
    assert_eq!(
        structured.origin,
        diagnostics::DiagnosticOrigin::ReturnTypeArgument { ordinal: 1 }
    );
}

fn accepts_explicit_return_type_argument_capture_with_expected_shape() {
    typecheck_with_standard_environment(
        r#"def make::<$A>() -> List<$A> { [] }
factory: (-> List<Int>) = &make::<Int>"#,
    )
    .expect("a capture should preserve an explicitly solved ReturnTypeArgument");
}

fn rejects_explicit_capture_conflicting_with_expected_return() {
    let error = assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
factory: (-> List<String>) = &make::<Int>"#,
        TypeDiagnosticReason::ReturnTypeArgumentMismatch,
    );
    let structured = error.structured.expect("mismatch should be structured");
    assert_eq!(
        structured.origin,
        diagnostics::DiagnosticOrigin::ReturnTypeArgument { ordinal: 0 }
    );
    assert_eq!(
        structured.related[0].role,
        diagnostics::SourceRole::Expected
    );
}

fn rejects_ambiguous_return_type_argument_capture() {
    assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
factory = &make::<_>"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn omitted_and_underscore_captures_share_ambiguity_check() {
    assert_reason(
        r#"def make::<$A>() -> List<$A> { [] }
factory = &make"#,
        TypeDiagnosticReason::AmbiguousReturnTypeArgument,
    );
}

fn expected_generic_result_allows_err_only_self_match_arm() {
    typecheck_with_standard_environment(
        r#"def map_result(value: Result<$A>, mapper: ($A -> $B)) -> Result<$B> {
  match value {
    Ok(inner) => Ok(mapper(inner)),
    _ => value,
  }
}"#,
    )
    .expect("an error-only fallback preserves Result's error channel under an expected result");
}
