use super::*;
use diagnostics::{DiagnosticOrigin, SourceRole, TypeDiagnosticReason};

struct SpecialFormContract {
    expected_qname: &'static str,
    expected_signature: &'static str,
    shape_ok: fn(&[ResolvedValueParameter], &Option<AstTy>) -> bool,
}

#[cfg(test)]
mod contextual_capability_tests {
    use super::*;

    #[test]
    fn declared_method_generic_absent_from_signature_still_tracks_unused_capability() {
        let span = Span { start: 10, end: 16 };
        let mut checker = Checker::new(TypecheckContext::default());
        let declared = vec![ResolvedTypeParam {
            name: "$T".into(),
            bound: None,
            span: span.clone(),
        }];
        let mut method_tyvars = HashMap::new();
        checker.seed_missing_method_type_params(&declared, &mut method_tyvars);
        let marker_id = ResolvedId {
            name: "Marker".into(),
            qualified_name: Some("Marker".into()),
            unique_id: 1,
            compiler_generated: false,
            symbol_info: None,
            span: span.clone(),
        };
        let where_clause = ResolvedWhereClause {
            constraints: vec![ResolvedWhereConstraint {
                subject: AstTy::Named(span.clone(), "$T".into()),
                bounds: vec![ResolvedWhereConstraintRhs::Trait {
                    trait_id: marker_id,
                }],
                span: span.clone(),
            }],
            span: span.clone(),
        };
        let capabilities = checker
            .resolved_capability_uses(Some(&where_clause), &method_tyvars)
            .expect("declared method capability should resolve");

        let err = checker
            .check_body_in_isolated_scope(
                &[],
                &[],
                &capabilities,
                &mut [],
                method_tyvars.clone(),
                Checker::signature_tyvar_ids(&method_tyvars),
                Ty::Unit,
                &span,
                None,
                "unused".into(),
                None,
                None,
                false,
                &Resolved::Lit(span.clone(), Lit::Unit),
            )
            .expect_err("a where-only declared method generic must remain an unused capability");

        assert!(err.message.contains("UnusedTraitConstraint"), "{err:?}");
        assert_eq!(err.span, span);
    }
}

fn special_form_shape_if(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 3
        && Checker::is_named_type(&params[0].ty, "Boolean")
        && Checker::is_lazy_of_named(&params[1].ty, "$A")
        && Checker::is_lazy_of_named(&params[2].ty, "$A")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_named_type(ty, "$A"))
}

fn special_form_shape_if_then(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "Boolean")
        && Checker::is_lazy_of_unit(&params[1].ty)
        && ret_ty.as_ref().is_some_and(Checker::is_unit_type)
}

fn special_form_shape_if_let(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 4
        && Checker::is_named_type(&params[0].ty, "$A")
        && Checker::is_named_type(&params[1].ty, "$Pattern")
        && Checker::is_lazy_of_named(&params[2].ty, "$B")
        && Checker::is_lazy_of_named(&params[3].ty, "$B")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_named_type(ty, "$B"))
}

fn special_form_shape_if_let_then(
    params: &[ResolvedValueParameter],
    ret_ty: &Option<AstTy>,
) -> bool {
    params.len() == 3
        && Checker::is_named_type(&params[0].ty, "$A")
        && Checker::is_named_type(&params[1].ty, "$Pattern")
        && Checker::is_lazy_of_unit(&params[2].ty)
        && ret_ty.as_ref().is_some_and(Checker::is_unit_type)
}

fn special_form_shape_is_match(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "$A")
        && Checker::is_named_type(&params[1].ty, "$Pattern")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_named_type(ty, "Boolean"))
}

pub(super) fn special_form_shape_apply_pattern(
    params: &[ResolvedValueParameter],
    ret_ty: &Option<AstTy>,
) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "$Value")
        && Checker::is_named_type(&params[1].ty, "$Pattern")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_result_of_named(ty, "$Return"))
}

fn special_form_shape_require(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "Boolean")
        && Checker::is_lazy_of_named(&params[1].ty, "Error")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_result_of_named(ty, "Unit"))
}

fn special_form_shape_ensure(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 3
        && Checker::is_named_type(&params[0].ty, "$A")
        && Checker::is_unary_func_from_named_to_named(&params[1].ty, "$A", "Boolean")
        && Checker::is_lazy_of_named(&params[2].ty, "Error")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_result_of_named(ty, "$A"))
}

fn special_form_shape_map_err_or_cause(
    params: &[ResolvedValueParameter],
    ret_ty: &Option<AstTy>,
) -> bool {
    params.len() == 2
        && Checker::is_result_of_named(&params[0].ty, "$T")
        && Checker::is_lazy_of_named(&params[1].ty, "Error")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_result_of_named(ty, "$T"))
}

fn special_form_shape_or_else(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 2
        && Checker::is_result_of_named(&params[0].ty, "$T")
        && matches!(params[1].ty.syntax(), AstTy::Generic(_, name, args)
            if name == "Lazy" && args.len() == 1
                && Checker::is_result_of_named(&args[0], "$T"))
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_result_of_named(ty, "$T"))
}

fn special_form_shape_and_or(params: &[ResolvedValueParameter], ret_ty: &Option<AstTy>) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "Boolean")
        && Checker::is_lazy_of_named(&params[1].ty, "Boolean")
        && ret_ty
            .as_ref()
            .is_some_and(|ty| Checker::is_named_type(ty, "Boolean"))
}

fn special_form_shape_pair_constructor(
    params: &[ResolvedValueParameter],
    ret_ty: &Option<AstTy>,
) -> bool {
    params.len() == 2
        && Checker::is_named_type(&params[0].ty, "$A")
        && Checker::is_named_type(&params[1].ty, "$B")
        && matches!(
            ret_ty,
            Some(AstTy::Tuple(_, items))
                if matches!(items.as_slice(), [first, second]
                    if Checker::is_named_type(first, "$A") && Checker::is_named_type(second, "$B"))
        )
}

impl Checker {
    fn bare_return_typevar_result_mismatch(
        &self,
        expected_ret: &Ty,
        actual_ret: &Ty,
        span: &Span,
    ) -> Option<TypeError> {
        match (self.resolve_ty(expected_ret), self.resolve_ty(actual_ret)) {
            (Ty::Var(_), Ty::Result(_, _)) => Some(self.type_relation_error(expected_ret, actual_ret,
                self.type_fact(SourceRole::Expected, span, expected_ret), self.type_fact(SourceRole::Value, span, actual_ret),
                TypeDiagnosticReason::ReturnTypeMismatch, DiagnosticOrigin::Return, "function", 0)
                .with_hint("A plain return type variable cannot be satisfied by Err(...). Declare Result<$T> when the function propagates failures.")),
            _ => None,
        }
    }

    pub(super) fn check_builtin_decl(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        return_type_arguments: &[ResolvedReturnTypeArgument],
        params: &[ResolvedValueParameter],
        ret_ty: &Option<sigil::resolved::ResolvedSignatureTy>,
        where_clause: Option<&ResolvedWhereClause>,
    ) -> Result<TypedNode, TypeError> {
        if Self::is_compiler_flow_operator_decl(id) {
            if !super::signatures::builtin_surface_matches(
                id,
                return_type_arguments,
                params,
                ret_ty.as_ref(),
                where_clause,
            ) {
                return Err(TypeError::new(
                    format!(
                        "Builtin {} does not match its canonical surface signature",
                        id.name
                    ),
                    span.clone(),
                ));
            }
            return Ok(TypedNode {
                ty: Ty::Unit,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Unit),
            });
        }
        let declared_name = id.name.rsplit("::").next().unwrap_or(&id.name);
        let is_special_form = Self::is_special_form_builtin_decl_name(declared_name);
        if is_special_form {
            let syntax_ret_ty = ret_ty.as_ref().map(|ty| ty.syntax.clone());
            return self.check_special_form_builtin_decl(span, id, params, &syntax_ret_ty);
        }

        let builtin_name =
            sindr::builtin::builtin_runtime_name(declared_name, id.qualified_name.as_deref());
        let meta = sindr::builtin::builtin_meta_by_name(builtin_name).ok_or_else(|| TypeError {
            structured: None,
            message: format!("Unknown builtin declaration: {}", id.name),
            span: span.clone(),
            hint: None,
        })?;
        if params.len() != usize::from(meta.runtime_arity()) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Builtin {} arity mismatch: expected {}, got {}",
                    id.name,
                    meta.runtime_arity(),
                    params.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }

        if !super::signatures::builtin_surface_matches(
            id,
            return_type_arguments,
            params,
            ret_ty.as_ref(),
            where_clause,
        ) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Builtin {} does not match its canonical surface signature",
                    id.name
                ),
                span: span.clone(),
                hint: Some(
                    "Update the @builtin declaration to match BUILTIN_METAS, including its owner and type shape."
                        .into(),
                ),
            });
        }

        let mut tyvars = HashMap::new();
        let return_type_argument_tys = return_type_arguments
            .iter()
            .map(|argument| {
                self.resolve_builtin_signature_ty_in_context(
                    &argument.ty,
                    TypeSyntaxContext::General,
                    &mut tyvars,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let param_tys = params
            .iter()
            .map(|param| {
                self.resolve_builtin_signature_ty_in_context(
                    &param.ty,
                    TypeSyntaxContext::StdBuiltinParameter,
                    &mut tyvars,
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let ret = match ret_ty {
            Some(ty) => self.resolve_builtin_signature_ty_in_context(
                ty,
                TypeSyntaxContext::FunctionReturn,
                &mut tyvars,
            )?,
            None => Ty::Unit,
        };

        let canonical_where_constraints =
            super::signatures::canonical_where_constraints(self, where_clause, &mut tyvars)?;
        self.callable_signatures.insert(
            id.unique_id,
            Arc::new(super::signatures::canonical_callable_signature(
                self,
                id,
                return_type_arguments,
                params,
                return_type_argument_tys.as_slice(),
                param_tys.as_slice(),
                ret.clone(),
                canonical_where_constraints,
                sindr::signature::RuntimeTarget::Builtin(meta.builtin_id()),
                sindr::signature::CallableDeclarationKind::Builtin,
            )?),
        );

        self.env.bind_var(
            id.unique_id,
            Ty::BuiltinFunc {
                name: meta.name.into(),
                params: param_tys,
                ret: Box::new(ret),
            },
        );

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Lit(Lit::Unit),
        })
    }

    pub(super) fn check_special_form_builtin_decl(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        params: &[ResolvedValueParameter],
        ret_ty: &Option<AstTy>,
    ) -> Result<TypedNode, TypeError> {
        let contract = Self::special_form_contract(id.name.as_str());

        if Self::surface_qualified_name(id.qualified_name.as_deref())
            != Some(contract.expected_qname)
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Special-form declaration `{}` is only allowed at `{}`.",
                    id.name, contract.expected_qname
                ),
                span: span.clone(),
                hint: None,
            });
        }

        if !(contract.shape_ok)(params, ret_ty) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Special-form declaration must match the canonical contract: {}",
                    contract.expected_signature
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let mut tyvars = HashMap::new();
        let param_tys = params
            .iter()
            .enumerate()
            .map(|(_index, param)| self.resolve_builtin_ast_ty(&param.ty, &mut tyvars))
            .collect::<Result<Vec<_>, _>>()?;
        let ret = match ret_ty {
            Some(ty) => self.resolve_builtin_ast_ty_in_context(
                ty,
                TypeSyntaxContext::FunctionReturn,
                &mut tyvars,
            )?,
            None => Ty::Unit,
        };

        self.env.bind_var(
            id.unique_id,
            Ty::BuiltinFunc {
                name: id.name.clone(),
                params: param_tys,
                ret: Box::new(ret),
            },
        );

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Lit(Lit::Unit),
        })
    }

    pub(super) fn check_builtin_type_decl(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        params: &[String],
        attrs: &ResolvedDeclAttrs,
    ) -> Result<TypedNode, TypeError> {
        if let Some(members) = &attrs.facet_path_kind {
            if attrs.builtin {
                return Err(TypeError {
                    structured: None,
                    message: "@FacetPathKind Type declarations are only allowed in canonical lib/facet.srt".into(),
                    span: span.clone(),
                    hint: None,
                });
            }
            if !params.is_empty() {
                return Err(TypeError {
                    structured: None,
                    message: "Facet path kind types cannot have generic parameters".into(),
                    span: span.clone(),
                    hint: None,
                });
            }
            let atomic = matches!(
                id.name.as_str(),
                "InfallibleStructural" | "FallibleStructural" | "VariantPath"
            );
            if members.is_empty() {
                if !atomic {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Facet path kind `{}` must be an alias or one of the compiler-derived atomic kinds",
                            id.name
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
            } else {
                if atomic {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Atomic Facet path kind `{}` cannot declare an alias RHS",
                            id.name
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                for member in members {
                    if !self.facet_path_kind_decls.contains_key(member) {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Facet path kind alias `{}` must reference a previously declared kind; `{member}` is not available",
                                id.name
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                }
            }
            if self
                .facet_path_kind_decls
                .insert(id.name.clone(), members.clone())
                .is_some()
            {
                return Err(TypeError {
                    structured: None,
                    message: format!("Duplicate Facet path kind declaration: {}", id.name),
                    span: span.clone(),
                    hint: None,
                });
            }
            return Ok(TypedNode {
                ty: Ty::Unit,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Unit),
            });
        }
        let Some(meta) = builtin_type_meta_by_name(Self::surface_name(&id.name)) else {
            return Err(TypeError {
                structured: None,
                message: format!("Unknown builtin type declaration: {}", id.name),
                span: span.clone(),
                hint: None,
            });
        };

        let exact_params_match = params.len() == meta.params.len()
            && params
                .iter()
                .zip(meta.params.iter())
                .all(|(actual, expected)| actual == expected);
        if !exact_params_match {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Builtin type {} must be declared as {}{}",
                    id.name,
                    id.name,
                    format_builtin_type_param_suffix(meta.params)
                ),
                span: span.clone(),
                hint: None,
            });
        }

        if self.enforce_builtin_type_contracts {
            if let Some((_, first_span)) = self.seen_builtin_type_decls.get(&id.name) {
                return Err(TypeError {
                    structured: None,
                    message: format!("Duplicate builtin type declaration: {}", id.name),
                    span: span.clone(),
                    hint: Some(format!(
                        "Already declared at {}..{}",
                        first_span.start, first_span.end
                    )),
                });
            }
            self.seen_builtin_type_decls
                .insert(id.name.clone(), (params.to_vec(), span.clone()));
        }

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Lit(Lit::Unit),
        })
    }

    pub(super) fn require_concrete_extractor_target_head(
        &self,
        target_ty: &Ty,
        span: &Span,
        extractor_name: &str,
    ) -> Result<(), TypeError> {
        match self.resolve_ty(target_ty) {
            Ty::Var(_) | Ty::SelfApp(_) | Ty::Hole => Err(TypeError {
                structured: None,
                message: format!(
                    "Extractor target type must have a concrete head: {extractor_name}"
                ),
                span: span.clone(),
                hint: Some(
                    "Use a concrete target such as Int, String, List<$T>, or Result<$T>. Put type-wide or Trait-constrained computation in a normal function."
                        .into(),
                ),
            }),
            _ => Ok(()),
        }
    }

    pub(super) fn check_builtin_extractor_decl(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        params: &[ResolvedExtractorParam],
        ret_ty: &AstTy,
    ) -> Result<TypedNode, TypeError> {
        let mut tyvars = HashMap::new();
        let param_tys = params
            .iter()
            .map(|param| match &param.ty {
                Some(ty) => self.resolve_builtin_ast_ty_in_context(
                    ty,
                    TypeSyntaxContext::General,
                    &mut tyvars,
                ),
                None => Ok(self.env.fresh_tyvar()),
            })
            .collect::<Result<Vec<_>, _>>()?;
        if param_tys.is_empty() {
            return Err(TypeError::new(
                "Extractor requires at least one input",
                span.clone(),
            ));
        }
        let target_param = params.last().expect("non-empty Extractor parameters");
        let target_span = target_param
            .ty
            .as_ref()
            .map(Self::ast_ty_span)
            .unwrap_or(&target_param.id.span);
        self.require_concrete_extractor_target_head(
            param_tys
                .last()
                .expect("non-empty Extractor parameter types"),
            target_span,
            &id.name,
        )?;
        let ret = self.resolve_builtin_ast_ty_in_context(
            ret_ty,
            TypeSyntaxContext::ExtractorReturn,
            &mut tyvars,
        )?;
        self.require_extractor_match_result_payload_ty(
            &ret,
            span,
            &format!("Extractor {}", id.name),
        )?;

        self.env.bind_var(
            id.unique_id,
            Ty::BuiltinFunc {
                name: id.name.clone(),
                params: param_tys.clone(),
                ret: Box::new(ret.clone()),
            },
        );

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::BuiltinExtractorDecl(id.clone(), param_tys, ret),
        })
    }

    pub(super) fn is_named_type(ast_ty: &AstTy, expected_name: &str) -> bool {
        matches!(ast_ty, AstTy::Named(_, name) if name == expected_name)
    }

    pub(super) fn is_unit_type(ast_ty: &AstTy) -> bool {
        Self::is_named_type(ast_ty, "Unit")
    }

    pub(super) fn is_lazy_of_named(ast_ty: &AstTy, expected_name: &str) -> bool {
        matches!(
            ast_ty,
            AstTy::Generic(_, name, args)
                if name == "Lazy"
                    && args.len() == 1
                    && matches!(&args[0], AstTy::Named(_, param_name) if param_name == expected_name)
        )
    }

    pub(super) fn is_lazy_of_unit(ast_ty: &AstTy) -> bool {
        Self::is_lazy_of_named(ast_ty, "Unit")
    }

    pub(super) fn is_unary_func_from_named_to_named(
        ast_ty: &AstTy,
        expected_param_name: &str,
        expected_ret_name: &str,
    ) -> bool {
        matches!(
            ast_ty,
            AstTy::Func(_, params, ret)
                if params.len() == 1
                    && matches!(&params[0], AstTy::Named(_, name) if name == expected_param_name)
                    && matches!(ret.as_ref(), AstTy::Named(_, name) if name == expected_ret_name)
        )
    }

    pub(super) fn is_special_form_builtin_decl_name(name: &str) -> bool {
        matches!(
            name,
            "if_let"
                | "if_let_then"
                | "is_match"
                | "apply_pattern"
                | "cause"
                | "and"
                | "or"
                | "eq"
                | "neq"
                | "concat"
                | "(,)"
        )
    }

    pub(super) fn validate_standard_lazy_function_decl(
        &self,
        span: &Span,
        id: &ResolvedId,
        params: &[ResolvedValueParameter],
        ret_ty: &Option<sigil::resolved::ResolvedSignatureTy>,
    ) -> Result<(), TypeError> {
        if !self.enforce_builtin_type_contracts {
            return Ok(());
        }
        let qname = Self::surface_qualified_name(id.qualified_name.as_deref());
        let name = match qname {
            Some("Kernel::if") => "if",
            Some("Kernel::if_then") => "if_then",
            Some("Kernel::require") => "require",
            Some("Kernel::ensure") => "ensure",
            Some("Result::map_err") => "map_err",
            Some("Result::or_else") => "or_else",
            _ => return Ok(()),
        };
        let contract = Self::special_form_contract(name);
        let annotation = ret_ty.as_ref().map(|ty| ty.syntax().clone());
        if !(contract.shape_ok)(params, &annotation) {
            return Err(TypeError::new(
                format!(
                    "Standard Lazy declaration must match the canonical contract: {}",
                    contract.expected_signature
                ),
                span.clone(),
            ));
        }
        Ok(())
    }

    pub(super) fn is_compiler_flow_operator_decl(id: &ResolvedId) -> bool {
        matches!(id.name.as_str(), "|>" | ">>" | ">*" | ">=>")
            && Self::surface_qualified_name(id.qualified_name.as_deref())
                == Some(format!("Bootstrap::{}", id.name).as_str())
    }

    fn special_form_contract(name: &str) -> SpecialFormContract {
        match name {
            "if" => SpecialFormContract {
                expected_qname: "Kernel::if",
                expected_signature: "def if(flag: Boolean, then_branch: Lazy<$A>, else_branch: Lazy<$A>) -> $A",
                shape_ok: special_form_shape_if,
            },
            "if_then" => SpecialFormContract {
                expected_qname: "Kernel::if_then",
                expected_signature: "def if_then(flag: Boolean, then_branch: Lazy<Unit>) -> Unit",
                shape_ok: special_form_shape_if_then,
            },
            "if_let" => SpecialFormContract {
                expected_qname: "Kernel::if_let",
                expected_signature: "@builtin def if_let(value: $A, pattern: $Pattern, then_branch: Lazy<$B>, else_branch: Lazy<$B>) -> $B",
                shape_ok: special_form_shape_if_let,
            },
            "if_let_then" => SpecialFormContract {
                expected_qname: "Kernel::if_let_then",
                expected_signature: "@builtin def if_let_then(value: $A, pattern: $Pattern, then_branch: Lazy<Unit>) -> Unit",
                shape_ok: special_form_shape_if_let_then,
            },
            "apply_pattern" => SpecialFormContract {
                expected_qname: "Kernel::apply_pattern",
                expected_signature: "@builtin def apply_pattern(value: $Value, pattern: $Pattern) -> Result<$Return>",
                shape_ok: special_form_shape_apply_pattern,
            },
            "is_match" => SpecialFormContract {
                expected_qname: "Kernel::is_match",
                expected_signature: "@builtin def is_match(value: $A, pattern: $Pattern) -> Boolean",
                shape_ok: special_form_shape_is_match,
            },
            "require" => SpecialFormContract {
                expected_qname: "Kernel::require",
                expected_signature: "def require(flag: Boolean, err: Lazy<Error>) -> Result<Unit>",
                shape_ok: special_form_shape_require,
            },
            "ensure" => SpecialFormContract {
                expected_qname: "Kernel::ensure",
                expected_signature: "def ensure(value: $A, pred: ($A -> Boolean), err: Lazy<Error>) -> Result<$A>",
                shape_ok: special_form_shape_ensure,
            },
            "map_err" => SpecialFormContract {
                expected_qname: "Result::map_err",
                expected_signature: "def map_err(result: Result<$T>, err: Lazy<Error>) -> Result<$T>",
                shape_ok: special_form_shape_map_err_or_cause,
            },
            "cause" => SpecialFormContract {
                expected_qname: "Result::cause",
                expected_signature: "@builtin def cause(result: Result<$T>, err: Lazy<Error>) -> Result<$T>",
                shape_ok: special_form_shape_map_err_or_cause,
            },
            "or_else" => SpecialFormContract {
                expected_qname: "Result::or_else",
                expected_signature: "def or_else(value: Result<$T>, next: Lazy<Result<$T>>) -> Result<$T>",
                shape_ok: special_form_shape_or_else,
            },
            "and" => SpecialFormContract {
                expected_qname: "Kernel::and",
                expected_signature: "@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean",
                shape_ok: special_form_shape_and_or,
            },
            "or" => SpecialFormContract {
                expected_qname: "Kernel::or",
                expected_signature: "@builtin def or(left: Boolean, right: Lazy<Boolean>) -> Boolean",
                shape_ok: special_form_shape_and_or,
            },
            "(,)" => SpecialFormContract {
                expected_qname: "Bootstrap::(,)",
                expected_signature: "@builtin def (,)(lhs: $A, rhs: $B) -> ($A, $B)",
                shape_ok: special_form_shape_pair_constructor,
            },
            _ => unreachable!(),
        }
    }

    pub(super) fn is_result_of_named(ast_ty: &AstTy, expected_name: &str) -> bool {
        matches!(
            ast_ty,
            AstTy::Generic(_, name, args)
                if name == "Result"
                    && args.len() == 1
                    && matches!(&args[0], AstTy::Named(_, param_name) if param_name == expected_name)
        )
    }

    pub(super) fn ensure_builtin_type_contracts(&self) -> Result<(), TypeError> {
        if !self.enforce_builtin_type_contracts {
            return Ok(());
        }

        for meta in builtin_type_head_metas() {
            if !self.seen_builtin_type_decls.contains_key(meta.name) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Missing builtin type declaration: {}{}",
                        meta.name,
                        format_builtin_type_param_suffix(meta.params)
                    ),
                    span: Span { start: 0, end: 0 },
                    hint: None,
                });
            }
        }

        Ok(())
    }

    pub(super) fn resolved_capability_uses(
        &mut self,
        where_clause: Option<&ResolvedWhereClause>,
        tyvars: &HashMap<String, Ty>,
    ) -> Result<Vec<CapabilityUse>, TypeError> {
        let Some(where_clause) = where_clause else {
            return Ok(Vec::new());
        };
        let mut uses = Vec::new();
        for constraint in &where_clause.constraints {
            let subject = match &constraint.subject {
                AstTy::Named(_, name) | AstTy::Generic(_, name, _) if tyvars.contains_key(name) => {
                    tyvars.get(name).cloned().expect("checked above")
                }
                _ => continue,
            };
            let subject_ty = self.resolve_ty(&subject);
            let subject_name = Self::surface_ast_ty(&constraint.subject);
            for bound in &constraint.bounds {
                if let ResolvedWhereConstraintRhs::Trait { trait_id } = bound {
                    uses.push(CapabilityUse {
                        subject_ty: subject_ty.clone(),
                        subject_name: subject_name.clone(),
                        trait_id: self.trait_key(trait_id),
                        span: trait_id.span.clone(),
                        consumed: false,
                    });
                }
            }
        }
        Ok(uses)
    }

    fn generated_derive_capability_uses(
        &mut self,
        where_clause: Option<&ResolvedWhereClause>,
        tyvars: &HashMap<String, Ty>,
        self_ty: &Ty,
    ) -> Result<Vec<CapabilityUse>, TypeError> {
        let Some(where_clause) = where_clause else {
            return Ok(Vec::new());
        };
        let mut uses = Vec::new();
        for constraint in &where_clause.constraints {
            let subject_ty = self.where_constraint_subject_ty(
                &constraint.subject,
                tyvars,
                Some(self_ty),
                &constraint.span,
                true,
            )?;
            let subject_name = Self::surface_ast_ty(&constraint.subject);
            for bound in &constraint.bounds {
                if let ResolvedWhereConstraintRhs::Trait { trait_id } = bound {
                    uses.push(CapabilityUse {
                        subject_ty: self.resolve_ty(&subject_ty),
                        subject_name: subject_name.clone(),
                        trait_id: self.trait_key(trait_id),
                        span: trait_id.span.clone(),
                        consumed: false,
                    });
                }
            }
        }
        Ok(uses)
    }

    fn collect_constructor_application_names(ty: &AstTy, names: &mut HashSet<String>) {
        match ty {
            AstTy::Generic(_, name, arguments) => {
                names.insert(name.clone());
                for argument in arguments {
                    Self::collect_constructor_application_names(argument, names);
                }
            }
            AstTy::Tuple(_, items) => {
                for item in items {
                    Self::collect_constructor_application_names(item, names);
                }
            }
            AstTy::Func(_, parameters, return_type) => {
                for parameter in parameters {
                    Self::collect_constructor_application_names(parameter, names);
                }
                Self::collect_constructor_application_names(return_type, names);
            }
            AstTy::Named(_, _) | AstTy::ImplTrait(_, _) => {}
        }
    }

    fn consume_signature_constructor_capabilities(
        &self,
        capabilities: &mut [CapabilityUse],
        return_type_arguments: &[ResolvedReturnTypeArgument],
        value_parameters: &[ResolvedValueParameter],
        return_type: Option<&sigil::resolved::ResolvedSignatureTy>,
    ) {
        let mut constructor_names = HashSet::new();
        for argument in return_type_arguments {
            Self::collect_constructor_application_names(
                argument.ty.syntax(),
                &mut constructor_names,
            );
        }
        for parameter in value_parameters {
            Self::collect_constructor_application_names(
                parameter.ty.syntax(),
                &mut constructor_names,
            );
        }
        if let Some(return_type) = return_type {
            Self::collect_constructor_application_names(
                return_type.syntax(),
                &mut constructor_names,
            );
        }

        for capability in capabilities {
            if constructor_names.contains(&capability.subject_name)
                && self
                    .traits
                    .get(&capability.trait_id)
                    .is_some_and(|info| !info.constructor_slots.is_empty())
            {
                capability.consumed = true;
            }
        }
    }

    fn typed_capability_uses(
        &mut self,
        where_clause: Option<&TypedWhereClause>,
        tyvars: &HashMap<String, Ty>,
    ) -> Vec<CapabilityUse> {
        let Some(where_clause) = where_clause else {
            return Vec::new();
        };
        let mut uses = Vec::new();
        for constraint in &where_clause.constraints {
            let subject = match &constraint.subject {
                AstTy::Named(_, name) | AstTy::Generic(_, name, _) if tyvars.contains_key(name) => {
                    tyvars.get(name).cloned().expect("checked above")
                }
                _ => continue,
            };
            let subject_ty = self.resolve_ty(&subject);
            let subject_name = Self::surface_ast_ty(&constraint.subject);
            for bound in &constraint.bounds {
                if let TypedWhereConstraintRhs::Trait { trait_id } = bound {
                    uses.push(CapabilityUse {
                        subject_ty: subject_ty.clone(),
                        subject_name: subject_name.clone(),
                        trait_id: self.trait_key(trait_id),
                        span: trait_id.span.clone(),
                        consumed: false,
                    });
                }
            }
        }
        uses
    }

    pub(super) fn seed_missing_method_type_params(
        &mut self,
        type_params: &[ResolvedTypeParam],
        tyvars: &mut HashMap<String, Ty>,
    ) {
        let missing = type_params
            .iter()
            .filter(|param| !tyvars.contains_key(&param.name))
            .cloned()
            .collect::<Vec<_>>();
        self.seed_signature_type_params(&missing, tyvars);
    }

    pub(super) fn resolved_named_type_args(
        &self,
        type_name: &str,
        resolved_ty: &Ty,
    ) -> Option<Vec<Ty>> {
        let def = self.env.lookup_type_def(type_name)?;
        let nominal = match resolved_ty {
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => nominal,
            _ => return None,
        };
        (nominal.arguments.len() == def.type_params.len()).then(|| nominal.arguments.clone())
    }

    pub(super) fn collect_signature_ty_bindings(
        &self,
        ast_ty: &AstTy,
        resolved_ty: &Ty,
        bindings: &mut HashMap<String, Ty>,
    ) {
        match (ast_ty, resolved_ty) {
            (AstTy::Named(_, name), ty) if name.starts_with('$') => {
                bindings.insert(name.clone(), ty.clone());
            }
            (AstTy::Generic(_, name, args), Ty::SelfApp(items))
                if name != "Self" && Self::constructor_application_parts(items).is_some() =>
            {
                let (_, slots) = Self::constructor_application_parts(items).expect("checked above");
                for (arg, slot) in args.iter().zip(slots.iter()) {
                    self.collect_signature_ty_bindings(arg, slot, bindings);
                }
            }
            (AstTy::Generic(_, name, args), Ty::Struct(_, _) | Ty::Record(_, _)) => {
                if let Some(resolved_args) = self.resolved_named_type_args(name, resolved_ty) {
                    for (arg, resolved) in args.iter().zip(resolved_args.iter()) {
                        self.collect_signature_ty_bindings(arg, resolved, bindings);
                    }
                }
            }
            (AstTy::Generic(_, _, args), Ty::Pid(marker)) if args.len() == 1 => {
                self.collect_signature_ty_bindings(&args[0], marker, bindings);
            }
            (AstTy::Generic(_, name, args), Ty::Enum(_, resolved_args))
                if matches!(Self::surface_name(name), "Workers" | "WorkerLease")
                    && args.len() == 1 =>
            {
                if let [Ty::Pid(marker)] = resolved_args.as_slice() {
                    self.collect_signature_ty_bindings(&args[0], marker, bindings);
                }
            }
            (AstTy::Generic(_, _, args), Ty::List(inner)) if args.len() == 1 => {
                self.collect_signature_ty_bindings(&args[0], inner, bindings);
            }
            (AstTy::Generic(_, _, args), Ty::Result(ok, err)) => {
                if let Some(arg) = args.first() {
                    self.collect_signature_ty_bindings(arg, ok, bindings);
                }
                if let Some(arg) = args.get(1) {
                    self.collect_signature_ty_bindings(arg, err, bindings);
                }
            }
            (AstTy::Generic(_, _, args), Ty::Enum(_, resolved_args)) => {
                for (arg, resolved) in args.iter().zip(resolved_args.iter()) {
                    self.collect_signature_ty_bindings(arg, resolved, bindings);
                }
            }
            (AstTy::Tuple(_, items), Ty::Tuple(resolved_items)) => {
                for (item, resolved) in items.iter().zip(resolved_items.iter()) {
                    self.collect_signature_ty_bindings(item, resolved, bindings);
                }
            }
            (AstTy::Func(_, params, ret), Ty::Func(resolved_params, resolved_ret)) => {
                for (param, resolved) in params.iter().zip(resolved_params.iter()) {
                    self.collect_signature_ty_bindings(param, resolved, bindings);
                }
                self.collect_signature_ty_bindings(ret, resolved_ret, bindings);
            }
            _ => {}
        }
    }

    pub(super) fn resolve_contextual_return_body(
        &mut self,
        return_ast: &sigil::resolved::ResolvedSignatureTy,
        expected_ret: &Ty,
        typed_body: &TypedNode,
        rigid_tyvars: &HashSet<u32>,
    ) -> Result<Option<Ty>, TypeError> {
        let Some(trait_key) = self.constructor_trait_key_for_signature_ty(return_ast) else {
            return Ok(None);
        };
        let actual = self.resolve_ty(&typed_body.ty);
        let has_concrete_constructor_shape = Self::is_concrete_constructor_shape(&actual);
        let expected_parts = match expected_ret {
            Ty::SelfApp(items) => Self::constructor_application_parts(items),
            _ => None,
        };
        let Some((witness, expected_slots)) = expected_parts else {
            unreachable!("constructor result annotation must lower to a contextual application")
        };
        if let Ty::SelfApp(actual_items) = &actual {
            if let Some((actual_witness, _)) = Self::constructor_application_parts(actual_items) {
                let same_witness = self.resolve_ty(witness) == self.resolve_ty(actual_witness);
                if same_witness
                    && self.types_compatible_with_rigid(expected_ret, &actual, rigid_tyvars)?
                {
                    // A definition generic over a direct constructor input
                    // keeps its body abstract. Pending trait calls are
                    // concretized when the ordinary function is specialized.
                    return Ok(None);
                }
            }
        }
        if matches!(actual, Ty::Var(_) | Ty::SelfApp(_)) {
            return Err(self.ambiguous_constructor_result(
                Self::surface_name(&trait_key),
                "return",
                &self.return_mismatch_span(typed_body),
            ));
        }
        if !has_concrete_constructor_shape {
            return Err(self.trait_failure(
                TypeDiagnosticReason::NoApplicableTraitImplementation,
                &trait_key,
                &actual,
                &self.return_mismatch_span(typed_body),
                DiagnosticOrigin::Return,
            ));
        }
        let concrete_slots = match self
            .constructor_application_slots_for_trait(&trait_key, &actual)
            .into_checked()
            .map_err(|error| error.at_span(&self.return_mismatch_span(typed_body)))?
        {
            ConstructorSlotsOutcome::Projected(slots) => slots,
            ConstructorSlotsOutcome::Deferred { waiting_on } => {
                let mut error = self.ambiguous_constructor_result(
                    Self::surface_name(&trait_key),
                    "return",
                    &self.return_mismatch_span(typed_body),
                );
                error.hint = Some(format!(
                    "Resolve all {} constructor input(s) before returning this value.",
                    waiting_on.len()
                ));
                return Err(error);
            }
            ConstructorSlotsOutcome::Rejected { failures } => {
                let span = self.return_mismatch_span(typed_body);
                return if Self::constructor_projection_failures_are_metadata(&failures) {
                    Err(signatures::constructor_signature_metadata_error(
                        &Self::surface_ast_ty(return_ast),
                        &span,
                        Self::constructor_projection_failure_detail(&failures),
                    ))
                } else {
                    Err(self.trait_failure(
                        TypeDiagnosticReason::NoApplicableTraitImplementation,
                        &trait_key,
                        &actual,
                        &span,
                        DiagnosticOrigin::Return,
                    ))
                };
            }
        };
        if expected_slots.len() != concrete_slots.len()
            || !try_all(
                expected_slots.iter().zip(concrete_slots.iter()),
                |(expected, actual)| {
                    self.types_compatible_with_rigid(expected, actual, rigid_tyvars)
                },
            )?
            || !self.bind_tyvar(
                match witness {
                    Ty::Var(var) => *var,
                    _ => unreachable!("fresh constructor witness must be a type variable"),
                },
                &actual,
            )?
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "expected {}, got {}",
                    self.ty_name(expected_ret),
                    self.ty_name(&actual)
                ),
                span: self.return_mismatch_span(typed_body),
                hint: None,
            });
        }
        if self
            .trait_dispatch_target_for_args(&trait_key, "", &self.resolve_ty(&actual), &[])?
            .is_none()
        {
            return Err(TypeError::new(
                format!(
                    "{} does not implement constructor trait {}",
                    self.ty_name(&actual),
                    self.trait_display_name(&trait_key)
                ),
                self.return_mismatch_span(typed_body),
            ));
        }
        Ok(Some(actual))
    }

    pub(super) fn check_body_in_isolated_scope(
        &mut self,
        local_bindings: &[(u32, Ty)],
        local_capabilities: &[(u32, String)],
        declaration_capabilities: &[CapabilityUse],
        deferred_capabilities: &mut [CapabilityUse],
        local_annotation_tyvars: HashMap<String, Ty>,
        rigid_tyvars: HashSet<u32>,
        function_return_ty: Ty,
        function_return_span: &Span,
        function_return_origin: Option<&Span>,
        function_symbol: String,
        impl_target: Option<String>,
        private_field_owner: Option<String>,
        in_extractor_body: bool,
        body: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let saved_function_return_ty = self.function_return_ty.clone();
        let saved_function_return_origin = self.function_return_origin.clone();
        let saved_local_annotation_tyvars = self.local_annotation_tyvars.clone();
        let saved_rigid_tyvars = self.rigid_tyvars.clone();
        let saved_current_function_symbol = self.current_function_symbol.clone();
        let saved_current_impl_struct_target = self.current_impl_struct_target.clone();
        let saved_current_private_field_owner = self.current_private_field_owner.clone();
        let saved_callable_context = self.callable_context;
        let saved_closure_depth = self.closure_depth;
        let saved_facet_bindings = self.facet_bindings.clone();
        let saved_constructor_capabilities = self.constructor_capabilities.clone();
        let saved_active_capabilities = self.active_capabilities.clone();

        self.env.push_var_scope();
        self.function_return_ty = Some(function_return_ty.clone());
        self.function_return_origin = function_return_origin.cloned();
        self.local_annotation_tyvars = local_annotation_tyvars;
        self.rigid_tyvars = rigid_tyvars;
        // Direct constructor inputs introduce witnesses outside the named
        // type-variable map. They are caller-owned just like named generics.
        for (_, ty) in local_bindings {
            let mut variables = Vec::new();
            Self::collect_ty_vars(ty, &mut variables);
            for variable in variables {
                if self.constructor_witness_traits.contains_key(&variable) {
                    self.rigid_tyvars.insert(variable);
                }
            }
        }
        self.current_function_symbol = Some(function_symbol);
        self.current_impl_struct_target = impl_target;
        self.current_private_field_owner = private_field_owner;
        self.callable_context = if in_extractor_body {
            CallableContext::Extractor
        } else {
            CallableContext::Function
        };
        self.active_capabilities = declaration_capabilities
            .iter()
            .chain(deferred_capabilities.iter())
            .cloned()
            .collect();
        for (unique_id, ty) in local_bindings {
            self.env.bind_var(*unique_id, ty.clone());
        }
        for (unique_id, capability) in local_capabilities {
            self.constructor_capabilities.insert(
                *unique_id,
                ConstructorCapabilityProvenance::constrained(capability.clone()),
            );
        }

        // Function and trait method bodies are embedded in a top-level typed
        // definition. Check the body now, but defer subtree normalization to the
        // single resolve_typed_node pass in check_program.
        let profile = self.profiler.start();
        let result =
            self.check_node_with_return_expected(body, &function_return_ty, function_return_span);
        for (deferred, checked) in deferred_capabilities.iter_mut().zip(
            self.active_capabilities
                .iter()
                .skip(declaration_capabilities.len()),
        ) {
            deferred.consumed |= checked.consumed;
        }
        let unused_capability = result.as_ref().ok().and_then(|_| {
            self.active_capabilities
                .iter()
                .take(declaration_capabilities.len())
                .find(|capability| !capability.consumed)
                .cloned()
        });
        self.profiler
            .finish(ProfileEvent::CheckBodyIsolated, profile);

        self.env.pop_var_scope();
        self.function_return_ty = saved_function_return_ty;
        self.function_return_origin = saved_function_return_origin;
        self.local_annotation_tyvars = saved_local_annotation_tyvars;
        self.rigid_tyvars = saved_rigid_tyvars;
        self.current_function_symbol = saved_current_function_symbol;
        self.current_impl_struct_target = saved_current_impl_struct_target;
        self.current_private_field_owner = saved_current_private_field_owner;
        self.callable_context = saved_callable_context;
        self.closure_depth = saved_closure_depth;
        self.facet_bindings = saved_facet_bindings;
        self.constructor_capabilities = saved_constructor_capabilities;
        self.active_capabilities = saved_active_capabilities;

        if let Some(unused) = unused_capability {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "UnusedTraitConstraint: {}: {} is never consumed",
                    unused.subject_name,
                    Self::surface_name(&unused.trait_id)
                ),
                span: unused.span,
                hint: Some(
                    "Remove this bound, or use it in a trait call or generic proof forwarding expression."
                        .into(),
                ),
            });
        }
        result
    }

    pub(super) fn body_tail_is_return_type_argument_call(&self, body: &Resolved) -> bool {
        match body {
            Resolved::Do(..) => true,
            Resolved::Block(_, statements) => statements
                .last()
                .is_some_and(|tail| self.body_tail_is_return_type_argument_call(tail)),
            Resolved::Grouped(_, inner) => self.body_tail_is_return_type_argument_call(inner),
            Resolved::Cond(_, clauses) => clauses
                .iter()
                .any(|(_, body)| self.body_tail_is_return_type_argument_call(body)),
            Resolved::LazyApp(_, LazyCaptureKind::If, _, args) => {
                self.body_tail_is_return_type_argument_call(&args[1])
                    || self.body_tail_is_return_type_argument_call(&args[2])
            }
            Resolved::LazyApp(_, LazyCaptureKind::IfThen, _, args) => {
                self.body_tail_is_return_type_argument_call(&args[1])
            }
            Resolved::If(_, _, then_branch, else_branch) => {
                self.body_tail_is_return_type_argument_call(then_branch)
                    || else_branch
                        .as_ref()
                        .is_some_and(|branch| self.body_tail_is_return_type_argument_call(branch))
            }
            Resolved::Match(_, _, arms)
            | Resolved::IsMatch(_, _, arms)
            | Resolved::IfLet(_, _, arms, _) => arms
                .iter()
                .any(|arm| self.body_tail_is_return_type_argument_call(&arm.body)),
            Resolved::App(_, function, _) | Resolved::Capture(_, function, _) => {
                let target = match function.as_ref() {
                    Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
                    target => target,
                };
                matches!(target, Resolved::Var(_, id)
                    if self.callable_signatures
                        .get(&id.unique_id)
                        .is_some_and(|signature| !signature.return_type_arguments.is_empty()))
            }
            _ => false,
        }
    }

    pub(super) fn check_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        return_type_arguments: &[ResolvedReturnTypeArgument],
        params: &[ResolvedValueParameter],
        ret_ty: &Option<sigil::resolved::ResolvedSignatureTy>,
        where_clause: Option<&ResolvedWhereClause>,
        body: &Resolved,
        attrs: &ResolvedDeclAttrs,
    ) -> Result<TypedNode, TypeError> {
        let mut typed_params = Vec::new();
        let mut local_bindings = Vec::new();
        let mut local_capabilities = Vec::new();
        let mut tyvars = HashMap::new();
        // Where-clause variables are part of the signature namespace. Seed
        // them before resolving `$M<$A>` applications so a constructor bound
        // can register `$M` as the application witness rather than creating a
        // disconnected fresh witness for each occurrence.
        if let Some(clause) = where_clause {
            for constraint in &clause.constraints {
                if let AstTy::Named(_, name) = &constraint.subject {
                    if name.starts_with('$') {
                        tyvars
                            .entry(name.clone())
                            .or_insert_with(|| self.env.fresh_tyvar());
                    }
                }
            }
            self.apply_resolved_where_trait_bounds(Some(clause), &tyvars, None)?;
        }
        let mut direct_constructor_inputs = super::signatures::DirectConstructorInputs::default();
        let mut typed_return_type_arguments = Vec::new();
        for argument in return_type_arguments {
            let ty = self.resolve_def_signature_ast_ty_in_context(
                id,
                &argument.ty,
                TypeSyntaxContext::General,
                &mut tyvars,
            )?;
            super::signatures::remember_direct_constructor_input(
                self,
                &argument.ty,
                &ty,
                &mut direct_constructor_inputs,
            );
            typed_return_type_arguments.push(TypedReturnTypeArgument {
                ordinal: argument.ordinal,
                ty,
                span: argument.span.clone(),
            });
        }

        for param in params {
            let param_ty = self.resolve_def_parameter_contract(id, &param.ty, &mut tyvars)?;
            super::signatures::remember_direct_constructor_input(
                self,
                &param.ty,
                &param_ty,
                &mut direct_constructor_inputs,
            );
            let param_ty = super::signatures::coalesce_direct_constructor_inputs(
                self,
                param_ty,
                &direct_constructor_inputs,
            );
            if self.ty_contains_process_init(&param_ty) {
                return Err(TypeError {
                    structured: None,
                    message: "StandbyInit<T> is only allowed as Standby @init return type".into(),
                    span: param.id.span.clone(),
                    hint: None,
                });
            }
            if self.ty_contains_facet(&param_ty) {
                return Err(TypeError {
                    structured: None,
                    message:
                        "Facet is compile-time only in Stage1 and cannot appear in function parameter types"
                            .into(),
                    span: param.id.span.clone(),
                    hint: None,
                });
            }
            local_bindings.push((param.id.unique_id, param_ty.clone()));
            if let Some(capability) = self.constructor_trait_key_for_signature_ty(&param.ty) {
                local_capabilities.push((param.id.unique_id, capability));
            }
            typed_params.push(TypedValueParameter {
                id: param.id.clone(),
                mode: param.mode,
                ty: param_ty.clone(),
                span: param.span.clone(),
            });
        }

        let mut expected_ret = match ret_ty {
            Some(ty) => self.resolve_def_signature_ast_ty_in_context(
                id,
                ty,
                TypeSyntaxContext::FunctionReturn,
                &mut tyvars,
            )?,
            None => Ty::Unit,
        };
        if let Some(ret_ty) = ret_ty {
            super::signatures::remember_direct_constructor_input(
                self,
                ret_ty,
                &expected_ret,
                &mut direct_constructor_inputs,
            );
        }
        expected_ret = super::signatures::coalesce_direct_constructor_inputs(
            self,
            expected_ret,
            &direct_constructor_inputs,
        );
        // Reuse the predeclared input identities before checking the body.
        // Recursive and forward calls already carry substitutions keyed by
        // these identities; checking a definition must not replace them.
        if let Some(predeclared) = self.callable_signatures.get(&id.unique_id) {
            let checked_types = typed_return_type_arguments
                .iter()
                .map(|slot| slot.ty.clone())
                .chain(typed_params.iter().map(|param| param.ty.clone()))
                .chain(std::iter::once(expected_ret.clone()))
                .collect::<Vec<_>>();
            let declared_types = predeclared
                .return_type_arguments
                .iter()
                .map(|slot| slot.ty.clone())
                .chain(
                    predeclared
                        .value_parameters
                        .iter()
                        .map(|param| param.ty.clone()),
                )
                .chain(std::iter::once(predeclared.return_type.ty.clone()))
                .collect::<Vec<_>>();
            let mut checked_vars = Vec::new();
            let mut declared_vars = Vec::new();
            Self::collect_ty_vars(&Ty::Tuple(checked_types.clone()), &mut checked_vars);
            Self::collect_ty_vars(&Ty::Tuple(declared_types.clone()), &mut declared_vars);
            if checked_vars.len() != declared_vars.len() {
                return Err(super::signatures::missing_canonical_callable_signature(
                    id, span,
                ));
            }
            let mapping = checked_vars
                .into_iter()
                .zip(declared_vars.into_iter().map(Ty::Var))
                .collect::<HashMap<_, _>>();
            if checked_types
                .iter()
                .map(|ty| self.substitute_ty_with_mapping(ty, &mapping))
                .ne(declared_types.iter().cloned())
            {
                return Err(super::signatures::missing_canonical_callable_signature(
                    id, span,
                ));
            }
            for ty in tyvars.values_mut() {
                *ty = self.substitute_ty_with_mapping(ty, &mapping);
            }
            for (_, ty) in &mut local_bindings {
                *ty = self.substitute_ty_with_mapping(ty, &mapping);
            }
            for parameter in &mut typed_params {
                parameter.ty = self.substitute_ty_with_mapping(&parameter.ty, &mapping);
            }
            for argument in &mut typed_return_type_arguments {
                argument.ty = self.substitute_ty_with_mapping(&argument.ty, &mapping);
            }
            expected_ret = self.substitute_ty_with_mapping(&expected_ret, &mapping);
        }
        self.apply_resolved_where_trait_bounds(where_clause, &tyvars, None)?;
        let mut declaration_capabilities = self.resolved_capability_uses(where_clause, &tyvars)?;
        self.consume_signature_constructor_capabilities(
            &mut declaration_capabilities,
            return_type_arguments,
            params,
            ret_ty.as_ref(),
        );
        let signature_types = typed_return_type_arguments
            .iter()
            .map(|argument| &argument.ty)
            .chain(typed_params.iter().map(|parameter| &parameter.ty))
            .chain(std::iter::once(&expected_ret))
            .collect::<Vec<_>>();
        for capability in &mut declaration_capabilities {
            if signature_types.iter().any(|ty| {
                self.nominal_type_uses_capability(ty, &capability.subject_ty, &capability.trait_id)
            }) {
                capability.consumed = true;
            }
        }
        if self.ty_contains_facet(&expected_ret) {
            return Err(TypeError {
                structured: None,
                message:
                    "Facet is compile-time only in Stage1 and cannot appear in function return types"
                        .into(),
                span: span.clone(),
                hint: None,
            });
        }

        let current_symbol = id.qualified_name.clone().unwrap_or_else(|| id.name.clone());
        if self.process_handler_return_exposes_context_pid(&current_symbol, &expected_ret) {
            return Err(TypeError {
                structured: None,
                message: "handler dependency cannot be returned from process handlers".into(),
                span: span.clone(),
                hint: Some("Keep ctx.<slot> usage inside the process handler body.".into()),
            });
        }
        let is_entrypoint = self
            .runtime_policy
            .normalized_entrypoint
            .as_deref()
            .is_some_and(|entry| entry == current_symbol);
        if is_entrypoint {
            if !params.is_empty() {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "entrypoint `{}` must have signature () -> Result<()>",
                        current_symbol
                    ),
                    span: span.clone(),
                    hint: Some("Remove entrypoint parameters and return Result<()>.".into()),
                });
            }
            if !Self::is_main_result_unit_ty(&expected_ret) {
                let legacy_main = current_symbol == "main"
                    && self
                        .runtime_policy
                        .normalized_entrypoint
                        .as_deref()
                        .is_some_and(|entry| entry == "main");
                return Err(TypeError {
                    structured: None,
                    message: if legacy_main {
                        "main must declare return type Result<()>".into()
                    } else {
                        format!(
                            "entrypoint `{}` must declare return type Result<()>",
                            current_symbol
                        )
                    },
                    span: span.clone(),
                    hint: Some(
                        "Define entrypoint as `def <name>() -> Result<()> { ... }` and return Ok(()) or Err(error)."
                            .into(),
                    ),
                });
            }
        }

        let impl_target = Self::split_impl_method_id(id).and_then(|(impl_target, _method)| {
            self.env
                .lookup_type_def(&impl_target)
                .is_some_and(|def| def.kind == crate::env::TypeKind::Struct)
                .then_some(Self::surface_name(&impl_target).to_string())
        });
        let typed_body = self.check_body_in_isolated_scope(
            &local_bindings,
            &local_capabilities,
            &declaration_capabilities,
            &mut [],
            tyvars.clone(),
            Self::signature_tyvar_ids(&tyvars),
            expected_ret.clone(),
            ret_ty
                .as_ref()
                .map(|ty| Self::ast_ty_span(ty.syntax()))
                .unwrap_or(span),
            ret_ty.as_ref().map(|ty| Self::ast_ty_span(ty.syntax())),
            current_symbol,
            impl_target.clone(),
            impl_target,
            false,
            body,
        )?;

        if let Some(return_ast) = ret_ty.as_ref() {
            if let Some(concrete) = self.resolve_contextual_return_body(
                return_ast,
                &expected_ret,
                &typed_body,
                &Self::signature_tyvar_ids(&tyvars),
            )? {
                expected_ret = concrete;
            }
        }
        for parameter in &mut typed_params {
            parameter.ty = self.resolve_ty(&parameter.ty);
        }
        for argument in &mut typed_return_type_arguments {
            argument.ty = self.resolve_ty(&argument.ty);
        }

        let actual_ret = self.resolve_ty(&typed_body.ty);
        if let Some(err) = self.bare_return_typevar_result_mismatch(
            &expected_ret,
            &actual_ret,
            &self.return_mismatch_span(&typed_body),
        ) {
            return Err(err);
        }
        let rigid_tyvars = Self::signature_tyvar_ids(&tyvars);
        let return_constructor_coercion = ret_ty
            .as_ref()
            .and_then(|ty| self.constructor_trait_key_for_signature_ty(ty))
            .map(|trait_key| {
                self.constructor_annotation_compatible(&trait_key, &expected_ret, &typed_body.ty)
                    .map_err(|error| error.at_span(&typed_body.span))
            })
            .transpose()?
            .unwrap_or(false);
        let saved_rigid = std::mem::replace(&mut self.rigid_tyvars, rigid_tyvars.clone());
        let relation = self.assert_type_relation(
            &expected_ret,
            &typed_body.ty,
            self.type_fact(
                SourceRole::Expected,
                ret_ty
                    .as_ref()
                    .map(|ty| Self::ast_ty_span(ty.syntax()))
                    .unwrap_or(span),
                &expected_ret,
            ),
            self.type_fact(
                SourceRole::Value,
                &self.return_mismatch_span(&typed_body),
                &actual_ret,
            ),
            TypeDiagnosticReason::ReturnTypeMismatch,
            DiagnosticOrigin::Return,
            &id.name,
            0,
        );
        self.rigid_tyvars = saved_rigid;
        if let Err(mut error) = relation {
            if !return_constructor_coercion {
                if matches!(actual_ret, Ty::Unit) {
                    if let Some(hint) = self.describe_unit_return_hint(&typed_body) {
                        error = error.with_hint(hint);
                    }
                }
                return Err(error);
            }
        }

        let typed_body = *self
            .concretize_pending_trait_calls(typed_body)
            .map_err(|error| *error)?;
        let signature_inputs = local_bindings
            .iter()
            .map(|(_, ty)| ty.clone())
            .chain(std::iter::once(expected_ret.clone()))
            .collect::<Vec<_>>();
        self.validate_pending_body_dependencies(&typed_body, &signature_inputs)?;

        let fun_idx = match self.env.lookup_var(id.unique_id) {
            Some(Ty::UserFunc { fun_idx, .. }) => *fun_idx,
            _ => {
                return Err(TypeError {
                    structured: None,
                    message: format!("Undefined function: {}", id.name),
                    span: span.clone(),
                    hint: None,
                });
            }
        };
        let checked_params = typed_params
            .iter()
            .map(|param| self.resolve_ty(&param.ty))
            .collect::<Vec<_>>();
        let mut checked_type_params = Vec::new();
        for argument in &typed_return_type_arguments {
            Self::collect_ty_vars(&argument.ty, &mut checked_type_params);
        }
        for param in &checked_params {
            Self::collect_ty_vars(param, &mut checked_type_params);
        }
        Self::collect_ty_vars(&expected_ret, &mut checked_type_params);
        self.env.bind_var(
            id.unique_id,
            Ty::UserFunc {
                fun_idx,
                type_params: checked_type_params,
                call_substitution: Vec::new(),
                params: checked_params.clone(),
                ret: Box::new(expected_ret.clone()),
            },
        );
        let canonical_where_constraints =
            super::signatures::canonical_where_constraints(self, where_clause, &mut tyvars)?;
        self.callable_signatures.insert(
            id.unique_id,
            Arc::new(super::signatures::canonical_callable_signature(
                self,
                id,
                return_type_arguments,
                params,
                typed_return_type_arguments
                    .iter()
                    .map(|argument| argument.ty.clone())
                    .collect::<Vec<_>>()
                    .as_slice(),
                checked_params.as_slice(),
                expected_ret.clone(),
                canonical_where_constraints,
                sindr::signature::RuntimeTarget::UserFunction(fun_idx),
                sindr::signature::CallableDeclarationKind::Function,
            )?),
        );
        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::Def(
                fun_idx,
                id.clone(),
                typed_return_type_arguments,
                typed_params,
                expected_ret,
                where_clause.map(TypedWhereClause::from),
                Box::new(typed_body),
                attrs.visibility,
            ),
        })
    }

    pub(super) fn check_extractor_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        type_params: &[ResolvedTypeParam],
        params: &[ResolvedExtractorParam],
        ret_ty: &AstTy,
        body: &Resolved,
        attrs: &ResolvedDeclAttrs,
    ) -> Result<TypedNode, TypeError> {
        let mut tyvars = HashMap::new();
        self.seed_signature_type_params(type_params, &mut tyvars);

        if params.is_empty() {
            return Err(TypeError::new(
                "Extractor requires at least one input",
                span.clone(),
            ));
        }
        let mut typed_params = Vec::with_capacity(params.len());
        for param in params {
            let param_ty = match &param.ty {
                Some(ty) => self.resolve_signature_ast_ty_in_context(
                    ty,
                    TypeSyntaxContext::General,
                    &mut tyvars,
                )?,
                None => self.env.fresh_tyvar(),
            };
            if self.ty_contains_facet(&param_ty) {
                return Err(TypeError::new(
                    "Facet is compile-time only and cannot appear in extractor parameters",
                    param.id.span.clone(),
                ));
            }
            typed_params.push(TypedValueParameter {
                id: param.id.clone(),
                mode: spire::ast::ValueParameterMode::PositionalOrNamed,
                ty: param_ty,
                span: param.id.span.clone(),
            });
        }
        let target_param = params.last().expect("non-empty Extractor parameters");
        let target_span = target_param
            .ty
            .as_ref()
            .map(Self::ast_ty_span)
            .unwrap_or(&target_param.id.span);
        self.require_concrete_extractor_target_head(
            &typed_params
                .last()
                .expect("non-empty Extractor parameter types")
                .ty,
            target_span,
            &id.name,
        )?;
        let mut expected_ret = self.resolve_signature_ast_ty_in_context(
            ret_ty,
            TypeSyntaxContext::ExtractorReturn,
            &mut tyvars,
        )?;
        // Pattern heads may already refer to the predeclared signature. Keep
        // those declaration identities when checking the Extractor body.
        let Some(Ty::UserFunc {
            type_params: declared_vars,
            params: declared_params,
            ret: declared_ret,
            ..
        }) = self.env.lookup_var(id.unique_id).cloned()
        else {
            return Err(self.typecheck_invariant_error(
                "Extractor definition must have a predeclared callable signature",
                span,
            ));
        };
        let checked_types = typed_params
            .iter()
            .map(|parameter| parameter.ty.clone())
            .chain(std::iter::once(expected_ret.clone()))
            .collect::<Vec<_>>();
        let declared_types = declared_params
            .into_iter()
            .chain(std::iter::once(*declared_ret))
            .collect::<Vec<_>>();
        let mut checked_vars = Vec::new();
        for parameter in type_params {
            if let Some(ty) = tyvars.get(&parameter.name) {
                Self::collect_ty_vars(ty, &mut checked_vars);
            }
        }
        Self::collect_ty_vars(&Ty::Tuple(checked_types.clone()), &mut checked_vars);
        if checked_vars.len() != declared_vars.len() {
            return Err(self.typecheck_invariant_error(
                "Extractor signature must retain its predeclared type slots",
                span,
            ));
        }
        let mapping = checked_vars
            .into_iter()
            .zip(declared_vars.into_iter().map(Ty::Var))
            .collect::<HashMap<_, _>>();
        if checked_types
            .iter()
            .map(|ty| self.substitute_ty_with_mapping(ty, &mapping))
            .ne(declared_types)
        {
            return Err(self.typecheck_invariant_error(
                "Extractor signature must match its predeclared callable contract",
                span,
            ));
        }
        for ty in tyvars.values_mut() {
            *ty = self.substitute_ty_with_mapping(ty, &mapping);
        }
        for parameter in &mut typed_params {
            parameter.ty = self.substitute_ty_with_mapping(&parameter.ty, &mapping);
        }
        expected_ret = self.substitute_ty_with_mapping(&expected_ret, &mapping);
        let local_bindings = typed_params
            .iter()
            .map(|param| (param.id.unique_id, param.ty.clone()))
            .collect::<Vec<_>>();
        if self.ty_contains_facet(&expected_ret) {
            return Err(TypeError {
                structured: None,
                message:
                    "Facet is compile-time only in Stage1 and cannot appear in extractor return types"
                        .into(),
                span: span.clone(),
                hint: None,
            });
        }
        self.require_extractor_match_result_payload_ty(
            &expected_ret,
            span,
            &format!("Extractor {}", id.name),
        )?;

        let current_symbol = id.qualified_name.clone().unwrap_or_else(|| id.name.clone());
        let impl_target = Self::split_impl_method_id(id).and_then(|(impl_target, _method)| {
            self.env
                .lookup_type_def(&impl_target)
                .is_some_and(|def| def.kind == crate::env::TypeKind::Struct)
                .then_some(Self::surface_name(&impl_target).to_string())
        });
        let typed_body = self.check_body_in_isolated_scope(
            &local_bindings,
            &[],
            &[],
            &mut [],
            tyvars.clone(),
            Self::signature_tyvar_ids(&tyvars),
            expected_ret.clone(),
            Self::ast_ty_span(ret_ty),
            Some(Self::ast_ty_span(ret_ty)),
            current_symbol,
            impl_target.clone(),
            impl_target,
            true,
            body,
        )?;

        let rigid_tyvars = Self::signature_tyvar_ids(&tyvars);
        if !self.types_compatible_with_rigid(&expected_ret, &typed_body.ty, &rigid_tyvars)? {
            let actual_ret = self.resolve_ty(&typed_body.ty);
            let hint = if matches!(actual_ret, Ty::Unit) {
                self.describe_unit_return_hint(&typed_body)
            } else {
                None
            };
            return Err(TypeError {
                structured: None,
                message: format!(
                    "expected {}, got {}",
                    self.ty_name(&expected_ret),
                    self.ty_name(&actual_ret)
                ),
                span: self.return_mismatch_span(&typed_body),
                hint,
            });
        }

        let typed_body = *self
            .concretize_pending_trait_calls(typed_body)
            .map_err(|error| *error)?;
        let signature_inputs = local_bindings
            .iter()
            .map(|(_, ty)| ty.clone())
            .chain(std::iter::once(expected_ret.clone()))
            .collect::<Vec<_>>();
        self.validate_pending_body_dependencies(&typed_body, &signature_inputs)?;

        let fun_idx = match self.env.lookup_var(id.unique_id) {
            Some(Ty::UserFunc { fun_idx, .. }) => *fun_idx,
            _ => {
                return Err(TypeError {
                    structured: None,
                    message: format!("Undefined extractor: {}", id.name),
                    span: span.clone(),
                    hint: None,
                });
            }
        };

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::ExtractorDef(
                fun_idx,
                id.clone(),
                type_params
                    .iter()
                    .filter_map(|param| match tyvars.get(&param.name) {
                        Some(Ty::Var(var)) => Some(TypedTypeParam {
                            name: param.name.clone(),
                            ty_var: *var,
                            bound: param.bound.clone(),
                        }),
                        _ => None,
                    })
                    .collect(),
                typed_params
                    .into_iter()
                    .map(|param| TypedValueParameter {
                        ty: self.resolve_ty(&param.ty),
                        ..param
                    })
                    .collect(),
                self.resolve_ty(&expected_ret),
                Box::new(typed_body),
                attrs.visibility,
            ),
        })
    }

    fn derive_dependency_for_subject(
        &mut self,
        target_ty: &Ty,
        subject_span: &Span,
        trait_key: &str,
    ) -> Option<diagnostics::TraitDependencyData> {
        use diagnostics::{TraitDependencyStep, TraitDependencyStepKind};

        let root = self.resolve_ty(target_ty);
        let root_type = self.diagnostic_ty_name(&root);
        let (first_step, mut leaf) = match &root {
            Ty::Struct(name, nominal) | Ty::Record(name, nominal) => self
                .env
                .lookup_type_def(name)?
                .field_type_spans
                .iter()
                .position(|span| span == subject_span)
                .and_then(|index| nominal.fields.get(index))
                .map(|(name, ty)| {
                    let leaf = self.resolve_ty(ty);
                    (
                        TraitDependencyStep {
                            kind: TraitDependencyStepKind::Field,
                            name: Some(name.clone()),
                            ordinal: None,
                            ty: self.diagnostic_ty_name(&leaf),
                        },
                        leaf,
                    )
                })?,
            Ty::Enum(name, _) => {
                self.lookup_enum_variants_of(name)?
                    .iter()
                    .find_map(|variant| {
                        variant.payload.iter().enumerate().find_map(|(index, ty)| {
                            (variant.payload_type_spans.get(index) == Some(subject_span)).then(
                                || {
                                    let leaf = self.resolve_ty(ty);
                                    (
                                        TraitDependencyStep {
                                            kind: TraitDependencyStepKind::VariantPayload,
                                            name: Some(variant.short_name.clone()),
                                            ordinal: Some(index as u32),
                                            ty: self.diagnostic_ty_name(&leaf),
                                        },
                                        leaf,
                                    )
                                },
                            )
                        })
                    })?
            }
            _ => return None,
        };
        let mut steps = vec![first_step];
        let mut visited = Vec::new();
        loop {
            if visited.contains(&leaf) {
                break;
            }
            visited.push(leaf.clone());
            let next = match &leaf {
                Ty::List(item)
                    if self.trait_impl_requires_children(trait_key, &leaf, &[*item.clone()]) =>
                {
                    Some((
                        TraitDependencyStepKind::ListElement,
                        None,
                        None,
                        *item.clone(),
                    ))
                }
                Ty::Enum(name, args)
                    if sindr::names::builtin_type_name(sindr::names::surface_path_name(name))
                        == Some(sindr::names::TypeName::HashMap)
                        && args.len() == 1
                        && self.trait_impl_requires_children(
                            trait_key,
                            &leaf,
                            &[args[0].clone()],
                        ) =>
                {
                    Some((
                        TraitDependencyStepKind::HashMapValue,
                        None,
                        None,
                        args[0].clone(),
                    ))
                }
                Ty::Tuple(items) if self.trait_impl_requires_children(trait_key, &leaf, items) => {
                    items
                        .iter()
                        .enumerate()
                        .find(|(_, item)| !self.trait_impl_exists_for_args(trait_key, &[], item))
                        .map(|(index, item)| {
                            (
                                TraitDependencyStepKind::TupleElement,
                                None,
                                Some(index as u32),
                                item.clone(),
                            )
                        })
                }
                Ty::Result(ok, _)
                    if self.trait_impl_requires_children(trait_key, &leaf, &[*ok.clone()]) =>
                {
                    Some((
                        TraitDependencyStepKind::ResultSuccess,
                        None,
                        None,
                        *ok.clone(),
                    ))
                }
                _ => None,
            };
            let Some((kind, name, ordinal, next_ty)) = next else {
                break;
            };
            leaf = self.resolve_ty(&next_ty);
            steps.push(TraitDependencyStep {
                kind,
                name,
                ordinal,
                ty: self.diagnostic_ty_name(&leaf),
            });
        }
        let leaf_policy =
            if self.trait_impl_policy_for_ty(&leaf) == sindr::names::TraitImplPolicy::Open {
                diagnostics::TraitDependencyLeafPolicy::TraitImplementationMissing
            } else {
                diagnostics::TraitDependencyLeafPolicy::TraitImplementationForbidden
            };
        Some(diagnostics::TraitDependencyData {
            context: diagnostics::TraitDependencyContext::Derive,
            root_type,
            steps,
            leaf_type: self.diagnostic_ty_name(&leaf),
            leaf_policy,
        })
    }

    pub(super) fn trait_dependency_for_requirement(
        &self,
        trait_key: &str,
        subject: &Ty,
    ) -> Option<diagnostics::TraitDependencyData> {
        use diagnostics::{TraitDependencyStep, TraitDependencyStepKind};

        let root = self.resolve_ty(subject);
        let root_type = self.diagnostic_ty_name(&root);
        let mut probe = self.spawn_child_checker(self.env.clone());
        let mut leaf = root;
        let mut steps = Vec::new();
        let mut visited = Vec::new();
        loop {
            if visited.contains(&leaf) {
                break;
            }
            visited.push(leaf.clone());
            let next = match &leaf {
                Ty::List(item)
                    if self.trait_impl_requires_children(trait_key, &leaf, &[*item.clone()]) =>
                {
                    Some((TraitDependencyStepKind::ListElement, None, *item.clone()))
                }
                Ty::Enum(name, args)
                    if sindr::names::builtin_type_name(sindr::names::surface_path_name(name))
                        == Some(sindr::names::TypeName::HashMap)
                        && args.len() == 1
                        && self.trait_impl_requires_children(
                            trait_key,
                            &leaf,
                            &[args[0].clone()],
                        ) =>
                {
                    Some((TraitDependencyStepKind::HashMapValue, None, args[0].clone()))
                }
                Ty::Tuple(items) if self.trait_impl_requires_children(trait_key, &leaf, items) => {
                    items
                        .iter()
                        .enumerate()
                        .find(|(_, item)| !probe.trait_impl_exists_for_args(trait_key, &[], item))
                        .map(|(index, item)| {
                            (
                                TraitDependencyStepKind::TupleElement,
                                Some(index as u32),
                                item.clone(),
                            )
                        })
                }
                Ty::Result(ok, _)
                    if self.trait_impl_requires_children(trait_key, &leaf, &[*ok.clone()]) =>
                {
                    Some((TraitDependencyStepKind::ResultSuccess, None, *ok.clone()))
                }
                _ => None,
            };
            let Some((kind, ordinal, next_ty)) = next else {
                break;
            };
            leaf = self.resolve_ty(&next_ty);
            steps.push(TraitDependencyStep {
                kind,
                name: None,
                ordinal,
                ty: self.diagnostic_ty_name(&leaf),
            });
        }
        let leaf_policy =
            if self.trait_impl_policy_for_ty(&leaf) == sindr::names::TraitImplPolicy::Open {
                diagnostics::TraitDependencyLeafPolicy::TraitImplementationMissing
            } else {
                diagnostics::TraitDependencyLeafPolicy::TraitImplementationForbidden
            };
        if steps.is_empty()
            && leaf_policy == diagnostics::TraitDependencyLeafPolicy::TraitImplementationMissing
        {
            return None;
        }
        Some(diagnostics::TraitDependencyData {
            context: diagnostics::TraitDependencyContext::Requirement,
            root_type,
            steps,
            leaf_type: self.diagnostic_ty_name(&leaf),
            leaf_policy,
        })
    }

    fn enrich_generated_derive_failure(
        &mut self,
        mut error: TypeError,
        generated: bool,
        target_ty: &Ty,
        trait_key: &str,
        declaration_span: &Span,
    ) -> TypeError {
        if !generated {
            return error;
        }
        let Some(structured) = error.structured.as_mut() else {
            return error;
        };
        let diagnostics::DiagnosticData::TraitDispatch(dispatch) = &mut structured.data else {
            return error;
        };
        if dispatch.trait_name != trait_key {
            return error;
        }
        let Some(dependency) =
            self.derive_dependency_for_subject(target_ty, &error.span, trait_key)
        else {
            return error;
        };
        if dependency.leaf_policy
            == diagnostics::TraitDependencyLeafPolicy::TraitImplementationForbidden
        {
            structured.remediation = Some(diagnostics::Remediation::Help {
                text: if trait_key.ends_with("Show") {
                    "Remove this derive or write Show explicitly, using inspect for the forbidden field when needed."
                        .into()
                } else {
                    "Remove this derive or compare a supported value extracted from the type."
                        .into()
                },
            });
        }
        dispatch.dependency = Some(dependency);
        structured.related.push(self.type_fact(
            SourceRole::Declaration,
            declaration_span,
            target_ty,
        ));
        TypeError::from_structured(structured.clone())
    }

    pub(super) fn check_trait_impl_items(
        &mut self,
        span: &Span,
        declaration_id: u32,
        trait_id: &ResolvedId,
        trait_args: &[AstTy],
        target_ast_ty: &AstTy,
        where_clause: Option<&ResolvedWhereClause>,
        resolved_methods: &[ResolvedTraitImplMethod],
    ) -> Result<Vec<TypedNode>, TypeError> {
        let trait_key = self.trait_key(trait_id);
        let trait_info = self
            .traits
            .get(&trait_key)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait: {}", trait_id.name),
                span: span.clone(),
                hint: None,
            })?;
        let (_, target_ty, _, _) =
            self.resolve_trait_impl_head_tys(&trait_info, trait_args, target_ast_ty)?;
        let target_name = self
            .trait_target_name(&target_ty)
            .ok_or_else(|| TypeError {
                structured: None,
                message:
                    "trait impl target must be a concrete named type, tuple type, or function type"
                        .into(),
                span: Self::ast_ty_span(target_ast_ty).clone(),
                hint: None,
            })?;
        let impl_info = self
            .trait_impl_for_declaration(declaration_id)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait impl {} for {}", trait_id.name, target_name),
                span: span.clone(),
                hint: None,
            })?;
        let target_ty = impl_info.target_ty.clone();
        let mut impl_tyvars = impl_info
            .type_param_vars_by_name
            .iter()
            .map(|(name, var)| (name.clone(), Ty::Var(*var)))
            .collect::<HashMap<_, _>>();
        impl_tyvars.insert("Self".into(), target_ty.clone());
        let mut block_capabilities = if impl_info.generated_derive {
            self.generated_derive_capability_uses(where_clause, &impl_tyvars, &target_ty)?
        } else {
            self.resolved_capability_uses(where_clause, &impl_tyvars)?
        };
        for capability in &mut block_capabilities {
            if self.nominal_type_uses_capability(
                &target_ty,
                &capability.subject_ty,
                &capability.trait_id,
            ) {
                capability.consumed = true;
            }
        }
        let mut typed_nodes = vec![TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::TraitImplDef(
                self.trait_instance_key(trait_id, trait_args),
                target_name.clone(),
                where_clause.map(TypedWhereClause::from),
            ),
        }];

        let mut methods = impl_info.methods.values().collect::<Vec<_>>();
        methods.sort_by_key(|method| method.function_id.unique_id);

        for method in methods {
            let resolved_method = resolved_methods
                .iter()
                .find(|candidate| candidate.function_id.unique_id == method.function_id.unique_id);
            if resolved_method.is_none() && !method.function_id.compiler_generated {
                return Err(TypeError {
                    structured: None,
                    message: format!("Unknown resolved impl method {}", method.method_name),
                    span: method.span.clone(),
                    hint: None,
                });
            }
            let trait_method =
                trait_info
                    .methods
                    .get(&method.method_name)
                    .ok_or_else(|| TypeError {
                        structured: None,
                        message: format!(
                            "Trait impl {} for {} defines unknown method `{}`",
                            trait_id.name, target_name, method.method_name
                        ),
                        span: method.span.clone(),
                        hint: None,
                    })?;
            let ResolvedImplMethodSignature {
                params: param_tys,
                result: mut expected_ret,
                type_params,
                return_type_arguments: return_type_argument_tys,
                environment: raw_environment,
            } = method.resolved_signature.clone().ok_or_else(|| {
                TypeError::new(
                    "Validated impl method is missing its declaration signature",
                    method.span.clone(),
                )
            })?;

            let mut typed_params = Vec::new();
            let mut local_bindings = Vec::new();
            let mut method_tyvars = raw_environment.head_bindings.clone();
            method_tyvars.extend(raw_environment.bindings.clone());
            method_tyvars.insert("Self".into(), raw_environment.self_ty.clone());
            for (param, param_ty) in method.value_parameters.iter().zip(param_tys.iter()) {
                local_bindings.push((param.id.unique_id, param_ty.clone()));
                let binding_source = match &*param.ty {
                    AstTy::Named(_, name) if name == "Self" => target_ast_ty,
                    _ => &param.ty,
                };
                self.collect_signature_ty_bindings(binding_source, param_ty, &mut method_tyvars);
                typed_params.push(TypedValueParameter {
                    id: param.id.clone(),
                    mode: param.mode,
                    ty: param_ty.clone(),
                    span: param.span.clone(),
                });
            }

            if method.is_builtin {
                continue;
            }
            self.collect_signature_ty_bindings(
                method.ret_ty.as_ref().unwrap_or(&trait_method.ret_ty),
                &expected_ret,
                &mut method_tyvars,
            );
            self.seed_missing_method_type_params(&method.type_params, &mut method_tyvars);
            let mut method_capabilities = match resolved_method {
                Some(resolved_method) => self.resolved_capability_uses(
                    resolved_method.where_clause.as_ref(),
                    &method_tyvars,
                )?,
                None => self.typed_capability_uses(method.where_clause.as_ref(), &method_tyvars),
            };
            self.consume_signature_constructor_capabilities(
                &mut method_capabilities,
                &method.return_type_arguments,
                &method.value_parameters,
                Some(method.ret_ty.as_ref().unwrap_or(&trait_method.ret_ty)),
            );
            let mut method_block_capabilities = if impl_info.generated_derive {
                self.generated_derive_capability_uses(where_clause, &method_tyvars, &target_ty)?
            } else {
                self.resolved_capability_uses(where_clause, &method_tyvars)?
            };
            self.consume_signature_constructor_capabilities(
                &mut method_block_capabilities,
                &method.return_type_arguments,
                &method.value_parameters,
                Some(method.ret_ty.as_ref().unwrap_or(&trait_method.ret_ty)),
            );
            let signature_types = return_type_argument_tys
                .iter()
                .chain(param_tys.iter())
                .chain(std::iter::once(&expected_ret))
                .collect::<Vec<_>>();
            for capability in &mut method_block_capabilities {
                if signature_types.iter().any(|ty| {
                    self.nominal_type_uses_capability(
                        ty,
                        &capability.subject_ty,
                        &capability.trait_id,
                    )
                }) {
                    capability.consumed = true;
                }
            }
            for capability in &mut method_block_capabilities {
                capability.consumed = block_capabilities.iter().any(|existing| {
                    existing.consumed
                        && existing.subject_name == capability.subject_name
                        && &existing.trait_id == &capability.trait_id
                });
            }

            let impl_target = self
                .env
                .lookup_type_def(&target_name)
                .is_some_and(|def| def.kind == crate::env::TypeKind::Struct)
                .then_some(Self::surface_name(&target_name).to_string());
            // Derive bodies originate in the owning type declaration. A
            // handwritten trait implementation does not have owner authority.
            let private_field_owner = impl_info
                .generated_derive
                .then(|| impl_target.clone())
                .flatten();
            let typed_body = self
                .check_body_in_isolated_scope(
                    &local_bindings,
                    &[],
                    &method_capabilities,
                    &mut method_block_capabilities,
                    method_tyvars.clone(),
                    type_params.iter().copied().collect(),
                    expected_ret.clone(),
                    method
                        .ret_ty
                        .as_ref()
                        .map(|ty| Self::ast_ty_span(ty.syntax()))
                        .unwrap_or_else(|| Self::ast_ty_span(trait_method.ret_ty.syntax())),
                    method
                        .ret_ty
                        .as_ref()
                        .map(|ty| Self::ast_ty_span(ty.syntax())),
                    method.function_id.name.clone(),
                    impl_target,
                    private_field_owner,
                    false,
                    &method.body,
                )
                .map_err(|error| {
                    self.enrich_generated_derive_failure(
                        error,
                        method.function_id.compiler_generated,
                        &target_ty,
                        &trait_key,
                        span,
                    )
                })?;
            for checked in method_block_capabilities {
                if checked.consumed {
                    if let Some(existing) = block_capabilities.iter_mut().find(|existing| {
                        existing.subject_name == checked.subject_name
                            && &existing.trait_id == &checked.trait_id
                    }) {
                        existing.consumed = true;
                    }
                }
            }

            let rigid_tyvars = type_params.iter().copied().collect::<HashSet<_>>();
            let return_ast = method.ret_ty.as_ref().unwrap_or(&trait_method.ret_ty);
            if let Some(concrete) = self.resolve_contextual_return_body(
                return_ast,
                &expected_ret,
                &typed_body,
                &rigid_tyvars,
            )? {
                expected_ret = concrete;
            }

            let actual_ret = self.resolve_ty(&typed_body.ty);
            if let Some(err) = self.bare_return_typevar_result_mismatch(
                &expected_ret,
                &actual_ret,
                &self.return_mismatch_span(&typed_body),
            ) {
                return Err(err);
            }
            let saved_rigid = std::mem::replace(&mut self.rigid_tyvars, rigid_tyvars.clone());
            let relation = self.assert_type_relation(
                &expected_ret,
                &typed_body.ty,
                self.type_fact(
                    SourceRole::Expected,
                    Self::ast_ty_span(return_ast),
                    &expected_ret,
                ),
                self.type_fact(
                    SourceRole::Value,
                    &self.return_mismatch_span(&typed_body),
                    &actual_ret,
                ),
                TypeDiagnosticReason::ReturnTypeMismatch,
                DiagnosticOrigin::Return,
                &method.method_name,
                0,
            );
            self.rigid_tyvars = saved_rigid;
            relation?;

            let typed_body = *self
                .concretize_pending_trait_calls(typed_body)
                .map_err(|error| *error)?;
            let signature_inputs = local_bindings
                .iter()
                .map(|(_, ty)| ty.clone())
                .chain(std::iter::once(expected_ret.clone()))
                .collect::<Vec<_>>();
            self.validate_pending_body_dependencies(&typed_body, &signature_inputs)?;

            let body_obligations = Self::full_trait_obligations(&typed_body)
                .into_iter()
                .map(|obligation| TraitObligation {
                    trait_id: obligation.trait_id,
                    trait_args: obligation
                        .trait_args
                        .iter()
                        .map(|ty| self.resolve_ty(ty))
                        .collect(),
                    receiver: self.resolve_ty(&obligation.receiver),
                })
                .collect::<Vec<_>>();
            let registered_impl_key = self.trait_impls.iter().find_map(|(key, implementation)| {
                implementation
                    .methods
                    .get(&method.method_name)
                    .filter(|registered| {
                        registered.function_id.unique_id == method.function_id.unique_id
                    })
                    .map(|_| key.clone())
            });
            if let Some(key) = registered_impl_key {
                let implementation = Arc::make_mut(
                    self.trait_impls
                        .get_mut(&key)
                        .expect("matched implementation remains registered"),
                );
                implementation
                    .methods
                    .get_mut(&method.method_name)
                    .expect("matched implementation method remains registered")
                    .body_obligations = body_obligations;
            }
            let fun_idx = match self.env.lookup_var(method.function_id.unique_id) {
                Some(Ty::UserFunc { fun_idx, .. }) => *fun_idx,
                _ => {
                    return Err(TypeError {
                        structured: None,
                        message: format!("Undefined function: {}", method.function_id.name),
                        span: method.span.clone(),
                        hint: None,
                    });
                }
            };
            let typed_return_type_arguments = method
                .return_type_arguments
                .iter()
                .zip(return_type_argument_tys.iter())
                .map(|(argument, ty)| TypedReturnTypeArgument {
                    ordinal: argument.ordinal,
                    ty: ty.clone(),
                    span: argument.span.clone(),
                })
                .collect::<Vec<_>>();
            typed_nodes.push(TypedNode {
                ty: Ty::Unit,
                span: method.span.clone(),
                node: TypedInner::Def(
                    fun_idx,
                    method.function_id.clone(),
                    typed_return_type_arguments,
                    typed_params,
                    expected_ret,
                    method.where_clause.clone(),
                    Box::new(typed_body),
                    method.attrs.visibility,
                ),
            });
        }

        if let Some(unused) = block_capabilities
            .into_iter()
            .find(|capability| !capability.consumed)
        {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "UnusedTraitConstraint: {}: {} is never consumed by this impl block",
                    unused.subject_name,
                    Self::surface_name(&unused.trait_id)
                ),
                span: unused.span,
                hint: Some(
                    "Remove this impl bound, or consume it from at least one implementation method."
                        .into(),
                ),
            });
        }

        Ok(typed_nodes)
    }

    pub(super) fn check_trait_impl_def(
        &mut self,
        span: &Span,
        trait_id: &ResolvedId,
        trait_args: &[AstTy],
        target_ast_ty: &AstTy,
        where_clause: Option<&ResolvedWhereClause>,
        _methods: &[ResolvedTraitImplMethod],
    ) -> Result<TypedNode, TypeError> {
        let trait_key = self.trait_key(trait_id);
        let trait_info = self
            .traits
            .get(&trait_key)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait: {}", trait_id.name),
                span: span.clone(),
                hint: None,
            })?;
        let (_, target_ty, _, _) =
            self.resolve_trait_impl_head_tys(&trait_info, trait_args, target_ast_ty)?;
        let target_name = self
            .trait_target_name(&target_ty)
            .ok_or_else(|| TypeError {
                structured: None,
                message:
                    "trait impl target must be a concrete named type, tuple type, or function type"
                        .into(),
                span: Self::ast_ty_span(target_ast_ty).clone(),
                hint: None,
            })?;
        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::TraitImplDef(
                self.trait_instance_key(trait_id, trait_args),
                target_name,
                where_clause.map(TypedWhereClause::from),
            ),
        })
    }

    pub(super) fn is_main_result_unit_ty(ty: &Ty) -> bool {
        matches!(
            ty,
            Ty::Result(ok, err)
                if matches!(ok.as_ref(), Ty::Unit) && matches!(err.as_ref(), Ty::Error)
        )
    }

    pub(super) fn check_struct_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        type_params: &[ResolvedTypeParam],
        fields: &[ResolvedField],
    ) -> Result<TypedNode, TypeError> {
        let mut tyvars = HashMap::new();
        self.seed_signature_type_params(type_params, &mut tyvars);
        let ty_fields: Vec<(String, Ty)> = fields
            .iter()
            .map(|f| {
                Ok((
                    f.name.clone(),
                    self.resolve_signature_ast_ty_in_context(
                        &f.ty,
                        TypeSyntaxContext::General,
                        &mut tyvars,
                    )?,
                ))
            })
            .collect::<Result<Vec<_>, TypeError>>()?;
        let private_fields = fields
            .iter()
            .filter(|field| field.visibility == spire::ast::Visibility::Private)
            .map(|field| field.name.clone())
            .collect::<HashSet<_>>();

        let readonly_fields = fields
            .iter()
            .filter(|field| field.readonly)
            .map(|field| field.name.clone())
            .collect::<HashSet<_>>();
        let type_param_vars = type_params
            .iter()
            .filter_map(|param| match tyvars.get(&param.name) {
                Some(Ty::Var(var)) => Some(*var),
                _ => None,
            })
            .collect::<Vec<_>>();

        let tag = self
            .env
            .resolve_type_def_signature(
                &id.name,
                ty_fields.clone(),
                type_param_vars.clone(),
                private_fields,
                readonly_fields,
            )
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown struct type declaration: {}", id.name),
                span: span.clone(),
                hint: None,
            })?;

        self.env.bind_var(
            id.unique_id,
            Ty::Struct(
                id.name.clone(),
                NominalType::new(
                    type_param_vars.iter().copied().map(Ty::Var).collect(),
                    ty_fields.clone(),
                ),
            ),
        );

        let field_names: Vec<String> = ty_fields.iter().map(|(n, _)| n.clone()).collect();
        let field_policies = fields
            .iter()
            .map(|field| crate::typed::TypedFieldPolicy {
                private: field.visibility == spire::ast::Visibility::Private,
                readonly: field.readonly,
            })
            .collect();

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::StructDef(tag, id.name.clone(), field_names, field_policies),
        })
    }

    pub(super) fn validate_builtin_enum_shape(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        type_params: &[ResolvedTypeParam],
        variants: &[ResolvedEnumVariant],
        attrs: &ResolvedDeclAttrs,
    ) -> Result<(), TypeError> {
        if attrs.builtin {
            match Self::surface_name(&id.name) {
                "Result" => {
                    if type_params.len() != 1
                        || variants.len() != 2
                        || variants[0].id.name.rsplit("::").next() != Some("Ok")
                        || variants[1].id.name.rsplit("::").next() != Some("Err")
                        || variants[0].payload.len() != 1
                        || variants[1].payload.len() != 1
                        || !matches!(&variants[0].payload[0], AstTy::Named(_, name) if name == "$T")
                        || !matches!(&variants[1].payload[0], AstTy::Named(_, name) if name == "Error")
                    {
                        return Err(TypeError {
                            structured: None,
                            message: "Builtin Result enum must match `defenum Result<$T> { Ok($T), Err(Error) }`.".into(),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                    self.seen_builtin_type_decls
                        .insert("Result".into(), (vec!["$T".into()], span.clone()));
                }
                "MatchResult" => {
                    if type_params.len() != 1
                        || variants.len() != 2
                        || variants[0].id.name.rsplit("::").next() != Some("Ok")
                        || variants[1].id.name.rsplit("::").next() != Some("Err")
                        || variants[0].payload.len() != 1
                        || variants[1].payload.len() != 1
                        || !matches!(&variants[0].payload[0], AstTy::Named(_, name) if name == &type_params[0].name)
                        || !matches!(&variants[1].payload[0], AstTy::Named(_, name) if name == "Error")
                    {
                        return Err(TypeError::new(
                            "Builtin MatchResult must define Ok($Value) and Err(Error)",
                            span.clone(),
                        ));
                    }
                    self.seen_builtin_type_decls.insert(
                        "MatchResult".into(),
                        (vec![type_params[0].name.clone()], span.clone()),
                    );
                }
                "Boolean" => {
                    if !type_params.is_empty()
                        || variants.len() != 2
                        || variants[0].id.name.rsplit("::").next() != Some("True")
                        || variants[1].id.name.rsplit("::").next() != Some("False")
                        || !variants.iter().all(|variant| variant.payload.is_empty())
                    {
                        return Err(TypeError {
                            structured: None,
                            message:
                                "Builtin Boolean enum must match `defenum Boolean { True, False }`."
                                    .into(),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                    self.seen_builtin_type_decls
                        .insert("Boolean".into(), (Vec::new(), span.clone()));
                }
                _ => {}
            }
        }

        Ok(())
    }

    pub(super) fn check_enum_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        type_params: &[ResolvedTypeParam],
        variants: &[ResolvedEnumVariant],
        attrs: &ResolvedDeclAttrs,
    ) -> Result<TypedNode, TypeError> {
        self.validate_builtin_enum_shape(span, id, type_params, variants, attrs)?;

        let enum_variants = self
            .lookup_enum_variants_of(&id.name)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown enum type declaration: {}", id.name),
                span: span.clone(),
                hint: None,
            })?;

        if enum_variants.len() != variants.len() {
            return Err(TypeError {
                structured: None,
                message: format!("Enum variant metadata mismatch: {}", id.name),
                span: span.clone(),
                hint: None,
            });
        }

        let typed_variants = enum_variants.iter().map(Into::into).collect::<Vec<_>>();

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::EnumDef(id.name.clone(), typed_variants),
        })
    }

    pub(super) fn check_record_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        fields: &[ResolvedField],
    ) -> Result<TypedNode, TypeError> {
        if let Some(field) = fields
            .iter()
            .find(|field| field.visibility != spire::ast::Visibility::Public || field.readonly)
        {
            return Err(TypeError {
                structured: None,
                message: "record fields do not support visibility or readonly modifiers".into(),
                span: field.span.clone(),
                hint: None,
            });
        }
        let ty_fields: Vec<(String, Ty)> = fields
            .iter()
            .map(|f| {
                Ok((
                    f.name.clone(),
                    self.resolve_ast_ty_in_context(&f.ty, TypeSyntaxContext::General)?,
                ))
            })
            .collect::<Result<Vec<_>, TypeError>>()?;

        let tag = self
            .env
            .resolve_type_def_signature(
                &id.name,
                ty_fields.clone(),
                Vec::new(),
                HashSet::new(),
                HashSet::new(),
            )
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown record type declaration: {}", id.name),
                span: span.clone(),
                hint: None,
            })?;

        self.env.bind_var(
            id.unique_id,
            Ty::Record(id.name.clone(), NominalType::monomorphic(ty_fields.clone())),
        );

        let field_names: Vec<String> = ty_fields.iter().map(|(n, _)| n.clone()).collect();
        let field_policies = fields
            .iter()
            .map(|_| crate::typed::TypedFieldPolicy {
                private: false,
                readonly: false,
            })
            .collect();

        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::RecordDef(tag, id.name.clone(), field_names, field_policies),
        })
    }

    pub(super) fn check_struct_lit(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        field_vals: &[ResolvedStructLitField],
    ) -> Result<TypedNode, TypeError> {
        let def = self
            .env
            .lookup_type_def(&id.name)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown struct type: {}", id.name),
                span: span.clone(),
                hint: None,
            })?
            .clone();

        if !id.compiler_generated {
            let owner_name = Self::surface_name(&def.name);
            if self.current_impl_struct_target.as_deref() != Some(owner_name) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Struct literal `{}` is only allowed inside `impl {} {{ ... }}` method bodies",
                        id.name, id.name
                    ),
                    span: span.clone(),
                    hint: Some(format!(
                        "Construct `{}` values via `{}(...)` / `{}::new(...)` outside the impl body.",
                        id.name, id.name, id.name
                    )),
                });
            }
        }

        let tag = def.tag;

        let mut seen = HashSet::new();
        for field in field_vals {
            let name = match field {
                ResolvedStructLitField::Explicit(name, _)
                | ResolvedStructLitField::Shorthand(name, _) => name,
            };
            if !def.fields.iter().any(|(field_name, _)| field_name == name) {
                return Err(TypeError {
                    structured: None,
                    message: format!("Unknown field '{}' in {}", name, id.name),
                    span: span.clone(),
                    hint: None,
                });
            }
            if !seen.insert(name.clone()) {
                return Err(TypeError {
                    structured: None,
                    message: format!("Duplicate field '{}' in {}", name, id.name),
                    span: span.clone(),
                    hint: None,
                });
            }
        }

        let mut fresh = HashMap::new();
        for variable in &def.type_param_vars {
            self.instantiate_ty_with_fresh(&Ty::Var(*variable), &mut fresh);
        }
        let fields = def
            .fields
            .iter()
            .map(|(name, ty)| (name.clone(), self.instantiate_ty_with_fresh(ty, &mut fresh)))
            .collect::<Vec<_>>();
        let mut typed_fields = Vec::new();
        for (def_name, def_ty) in &fields {
            let resolved_val = field_vals
                .iter()
                .find_map(|field| match field {
                    ResolvedStructLitField::Explicit(name, resolved_val)
                    | ResolvedStructLitField::Shorthand(name, resolved_val)
                        if name == def_name =>
                    {
                        Some(resolved_val)
                    }
                    _ => None,
                })
                .ok_or_else(|| TypeError {
                    structured: None,
                    message: format!("Missing field '{}' in {}", def_name, id.name),
                    span: span.clone(),
                    hint: None,
                })?;
            let typed_val = self.check_node(resolved_val)?;
            if self.ty_contains_facet(&typed_val.ty) {
                return Err(TypeError {
                    structured: None,
                    message:
                        "Struct literal fields cannot contain Facet values in Stage1 (Facet is compile-time only)"
                            .into(),
                    span: typed_val.span.clone(),
                    hint: Some("Apply Facet::view/set/over before constructing runtime values.".into()),
                });
            }
            if !self.types_compatible(def_ty, &typed_val.ty)? {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Field '{}': expected {}, got {}",
                        def_name,
                        self.ty_name(def_ty),
                        self.ty_name(&typed_val.ty)
                    ),
                    span: typed_val.span.clone(),
                    hint: None,
                });
            }
            typed_fields.push(typed_val);
        }

        let arguments: Vec<Ty> = def
            .type_param_vars
            .iter()
            .map(|variable| {
                self.resolve_ty(
                    fresh
                        .get(variable)
                        .expect("every nominal type parameter is instantiated"),
                )
            })
            .collect();
        let result_fields = self.instantiate_type_def_fields(&def, &arguments);
        let result_ty = Ty::Struct(id.name.clone(), NominalType::new(arguments, result_fields));
        Ok(TypedNode {
            ty: result_ty,
            span: span.clone(),
            node: TypedInner::StructLit(tag, typed_fields),
        })
    }

    pub(super) fn check_constructor_call(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        args: &[ResolvedRecordLitArg],
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        // Closure bodies are checked through `check_node`, but an expected
        // closure return type is kept separately while that body is checked.
        // Use it for Result constructors so `Err(error)` can inhabit a nested
        // Result without constructing `Err(Err(error))`.
        // An absent call-site expectation means the constructor is
        // polymorphic, not that it should inherit the enclosing function's
        // return type.  In particular, `Err(...)` inside a list/tuple or a
        // nested call must not become `Result<Unit>` merely because the
        // surrounding function returns `Result<Unit>`.  The fresh Result
        // success slot below is unified later by the surrounding expression
        // or by the function body's final return check.
        let expected = expected.cloned();
        if let Some(variant) = self.lookup_enum_variant_by_constructor_id(id.unique_id) {
            let variant = self.instantiate_enum_variant(&variant);
            let enum_surface_name = Self::surface_name(&variant.enum_name);
            if let Some(sindr::names::SpecialEnumVariantLowering::Boolean(value)) =
                variant.special_variant
            {
                if !args.is_empty() {
                    return Err(TypeError::from_structured(
                        self.argument_contract_diagnostic(
                            TypeDiagnosticReason::ArityMismatch,
                            &id.name,
                            None,
                            0,
                            args.len(),
                            span,
                            DiagnosticOrigin::Call,
                        ),
                    ));
                }
                return Ok(TypedNode {
                    ty: Ty::Bool,
                    span: span.clone(),
                    node: TypedInner::Lit(Lit::Bool(value)),
                });
            }
            if enum_surface_name == "MatchResult" {
                if !matches!(
                    self.callable_context,
                    CallableContext::Extractor | CallableContext::ExtractorClosure
                ) {
                    return Err(TypeError::new(
                        "MatchResult constructors are only allowed in an Extractor body",
                        span.clone(),
                    ));
                }
                if args.len() != 1 {
                    return Err(TypeError::new(
                        "MatchResult constructors require exactly one value",
                        span.clone(),
                    ));
                }
                let ResolvedRecordLitArg::Positional(expr) = &args[0] else {
                    return Err(TypeError::new(
                        "MatchResult constructors require a positional value",
                        span.clone(),
                    ));
                };
                let expected_payload = expected.as_ref().and_then(|ty| match self.resolve_ty(ty) {
                    Ty::MatchResult(payload) => Some(*payload),
                    _ => None,
                });
                let inner = self.check_node_with_expected(
                    expr,
                    if variant.short_name == "Ok" {
                        expected_payload.as_ref()
                    } else {
                        None
                    },
                )?;
                let inner = self.maybe_call_zero_arg_function(inner, span.clone());
                self.ensure_no_runtime_facet_args(
                    std::slice::from_ref(&inner),
                    span,
                    "MatchResult constructor",
                )?;
                let payload = match variant.short_name.as_str() {
                    "Ok" => inner.ty.clone(),
                    "Err" => {
                        if !self.types_compatible(&inner.ty, &Ty::Error)? {
                            let mut error = TypeError::new(
                                "MatchResult::Err requires an Error value",
                                inner.span.clone(),
                            );
                            if let Some(hint) = self.error_kind_error_hint(&inner) {
                                error = error.with_hint(hint);
                            }
                            return Err(error);
                        }
                        expected_payload.unwrap_or_else(|| self.env.fresh_tyvar())
                    }
                    _ => {
                        return Err(TypeError::new(
                            "Invalid canonical MatchResult variant",
                            span.clone(),
                        ))
                    }
                };
                return Ok(TypedNode {
                    ty: Ty::MatchResult(Box::new(payload)),
                    span: span.clone(),
                    node: TypedInner::ConstructorCall(
                        variant.tag,
                        vec![
                            TypedNode {
                                ty: Ty::Int,
                                span: span.clone(),
                                node: TypedInner::Lit(Lit::Int(variant.discriminant)),
                            },
                            inner,
                        ],
                    ),
                });
            }
            if matches!(
                variant.special_variant,
                Some(
                    sindr::names::SpecialEnumVariantLowering::ResultOk
                        | sindr::names::SpecialEnumVariantLowering::ResultErr
                )
            ) {
                if args.len() != 1 {
                    return Err(TypeError::from_structured(
                        self.argument_contract_diagnostic(
                            TypeDiagnosticReason::ArityMismatch,
                            &id.name,
                            None,
                            1,
                            args.len(),
                            span,
                            DiagnosticOrigin::Call,
                        ),
                    ));
                }
                let inner = match &args[0] {
                    ResolvedRecordLitArg::Positional(expr) => {
                        // Only the success payload receives the owner's success
                        // type. Err stores a concrete Error at the current layer.
                        let inner_expected = (variant.special_variant
                            == Some(sindr::names::SpecialEnumVariantLowering::ResultOk))
                        .then(|| {
                            expected
                                .as_ref()
                                .and_then(|expected| match self.resolve_ty(expected) {
                                    Ty::Result(ok, _) => Some(ok.as_ref().clone()),
                                    _ => None,
                                })
                        })
                        .flatten();
                        let typed = self.check_node_with_expected(expr, inner_expected.as_ref())?;
                        self.ensure_no_match_result_value(&typed.ty, &typed.span)?;
                        if self.ty_contains_facet(&typed.ty) {
                            return Err(TypeError {
                                structured: None,
                                message:
                                    "Result constructors cannot contain Facet values in Stage1 (Facet is compile-time only)"
                                        .into(),
                                span: typed.span.clone(),
                                hint: Some(
                                    "Apply Facet::view/set/over before wrapping with Ok(...) or Err(...)."
                                        .into(),
                                ),
                            });
                        }
                        self.maybe_call_zero_arg_function(typed, span.clone())
                    }
                    ResolvedRecordLitArg::Named(_, _) => {
                        return Err(TypeError::from_structured(
                            self.argument_contract_diagnostic(
                                TypeDiagnosticReason::ArgumentModeMismatch,
                                &id.name,
                                None,
                                1,
                                args.len(),
                                span,
                                DiagnosticOrigin::Call,
                            ),
                        ));
                    }
                };
                if variant.special_variant
                    == Some(sindr::names::SpecialEnumVariantLowering::ResultErr)
                {
                    if matches!(self.resolve_ty(&inner.ty), Ty::Result(_, _)) {
                        return Err(TypeError {
                            structured: None,
                            message: "Nested Result errors are not allowed: use Err(error) for the outer failure, or Ok(Err(error)) for an inner failure.".into(),
                            span: inner.span.clone(),
                            hint: Some(
                                "Err(...) is lifted to the expected Result nesting; do not write Err(Err(...)).".into(),
                            ),
                        });
                    }
                    if !matches!(inner.ty, Ty::Error) {
                        return Err(TypeError {
                            structured: None,
                            message: "Err(...) requires an Error value.".into(),
                            span: inner.span.clone(),
                            hint: self.error_kind_error_hint(&inner).or_else(|| Some(
                                "Use an existing Error or an explicit deferror constructor call in Err(...).".into(),
                            )),
                        });
                    }
                    if self.is_abstract_error_marker_value(&inner) {
                        return Err(TypeError {
                            structured: None,
                            message: "Error is abstract and cannot be constructed directly.".into(),
                            span: inner.span.clone(),
                            hint: Some("Use a concrete deferror value in Err(...).".into()),
                        });
                    }
                }
                let result_ty = if variant.special_variant
                    == Some(sindr::names::SpecialEnumVariantLowering::ResultOk)
                {
                    Ty::Result(Box::new(inner.ty.clone()), Box::new(Ty::Error))
                } else {
                    expected
                        .as_ref()
                        .filter(|ty| matches!(self.resolve_ty(ty), Ty::Result(_, _)))
                        .map(|ty| self.resolve_ty(ty))
                        .unwrap_or_else(|| {
                            let ok_var = self.env.fresh_tyvar();
                            Ty::Result(Box::new(ok_var), Box::new(Ty::Error))
                        })
                };
                return Ok(TypedNode {
                    ty: result_ty,
                    span: span.clone(),
                    node: TypedInner::ConstructorCall(variant.tag, vec![inner]),
                });
            }
            if matches!(
                Self::surface_name(&variant.enum_name),
                "StopReply" | "StopReason"
            ) && !self.stop_constructor_allowed()
            {
                return Err(self.stop_constructor_error(span, &variant.enum_name));
            }
            let payload_values = self.typecheck_positional_call_args(
                span,
                &id.name,
                &variant.payload,
                args,
                None,
                "Enum constructors do not accept named arguments".into(),
            )?;
            self.ensure_no_runtime_facet_args(&payload_values, span, "Enum constructor arguments")?;

            let mut fields = Vec::with_capacity(payload_values.len() + 1);
            fields.push(TypedNode {
                ty: Ty::Int,
                span: span.clone(),
                node: TypedInner::Lit(Lit::Int(variant.discriminant)),
            });
            fields.extend(payload_values);

            return Ok(TypedNode {
                ty: self.resolve_ty(&variant.enum_ty),
                span: span.clone(),
                node: TypedInner::ConstructorCall(variant.tag, fields),
            });
        }

        if self.error_definition_uid == Some(id.unique_id) {
            return Err(TypeError::new("Error internal construction is only allowed as the direct terminal expression of its declaration", span.clone()));
        }
        if self.env.is_error_constructor(id.unique_id) {
            let schema = self
                .env
                .error_constructor_inputs
                .get(&id.unique_id)
                .cloned()
                .ok_or_else(|| {
                    TypeError::new("Error constructor input signature is missing", span.clone())
                })?;
            let typed_args = self.check_error_arguments(span, &id.name, &schema, args)?;
            let ty = self.env.lookup_var(id.unique_id).cloned().ok_or_else(|| {
                TypeError::new("Error constructor function is missing", span.clone())
            })?;
            return Ok(TypedNode {
                ty: Ty::Error,
                span: span.clone(),
                node: TypedInner::App(
                    Box::new(TypedNode {
                        ty,
                        span: id.span.clone(),
                        node: TypedInner::Var(id.clone()),
                    }),
                    typed_args,
                ),
            });
        }
        if let Some(ty) = self.env.lookup_var(id.unique_id).cloned() {
            match &ty {
                Ty::BuiltinFunc { params, ret, .. } => {
                    let callable_hint =
                        Some(self.call_target_signature_hint_for_id(id, params, ret.as_ref()));
                    let typed_args = self.typecheck_positional_call_args(
                        span,
                        &id.name,
                        params,
                        args,
                        callable_hint,
                        "Constructor calls do not accept named arguments".into(),
                    )?;
                    self.ensure_no_runtime_facet_args(&typed_args, span, "Constructor arguments")?;

                    return Ok(TypedNode {
                        ty: ret.as_ref().clone(),
                        span: span.clone(),
                        node: TypedInner::App(
                            Box::new(TypedNode {
                                ty: ty.clone(),
                                span: id.span.clone(),
                                node: TypedInner::Var(id.clone()),
                            }),
                            typed_args,
                        ),
                    });
                }
                Ty::UserFunc { params, ret, .. }
                    if self.callable_signatures.contains_key(&id.unique_id) =>
                {
                    return self.check_registered_callable_application(span, id, args, None);
                }
                Ty::UserFunc { params, ret, .. } => {
                    let callable_hint = self.call_target_signature_hint_for_id(id, params, ret);
                    let typed_args = self.typecheck_user_function_args(
                        span,
                        id.unique_id,
                        "function",
                        params,
                        args,
                        Some(callable_hint.as_str()),
                        false,
                    )?;
                    return Ok(TypedNode {
                        ty: ret.as_ref().clone(),
                        span: span.clone(),
                        node: TypedInner::App(
                            Box::new(TypedNode {
                                ty: ty.clone(),
                                span: id.span.clone(),
                                node: TypedInner::Var(id.clone()),
                            }),
                            typed_args,
                        ),
                    });
                }
                Ty::Func(params, ret) => {
                    let callable_hint =
                        self.callable_signature_hint(&Ty::Func(params.clone(), ret.clone()));
                    let typed_args = self.typecheck_positional_call_args(
                        span,
                        &id.name,
                        params,
                        args,
                        callable_hint,
                        "Constructor calls do not accept named arguments".into(),
                    )?;
                    self.ensure_no_runtime_facet_args(&typed_args, span, "Constructor arguments")?;

                    return Ok(TypedNode {
                        ty: ret.as_ref().clone(),
                        span: span.clone(),
                        node: TypedInner::App(
                            Box::new(TypedNode {
                                ty: ty.clone(),
                                span: id.span.clone(),
                                node: TypedInner::Var(id.clone()),
                            }),
                            typed_args,
                        ),
                    });
                }
                _ => {}
            }
        }

        let def = self
            .env
            .lookup_type_def(&id.name)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown constructor type: {}", id.name),
                span: span.clone(),
                hint: None,
            })?
            .clone();

        if matches!(def.kind, crate::env::TypeKind::Struct) {
            let owner_name = id.qualified_name.as_deref().unwrap_or(id.name.as_str());
            let new_name = format!("{}::new", owner_name);
            let Some(new_uid) = self.impl_method_uids.get(&new_name).copied() else {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Struct `{}` constructor call requires `{}` but no such method was found",
                        id.name, new_name
                    ),
                    span: span.clone(),
                    hint: Some(format!(
                        "Define `impl {} {{ def new(...) -> Self {{ ... }} }}` or `impl {} {{ def new(...) -> Result<Self, Error> {{ ... }} }}`.",
                        id.name, id.name
                    )),
                });
            };
            let new_id = ResolvedId {
                name: new_name.clone(),
                qualified_name: None,
                symbol_info: None,
                unique_id: new_uid,
                compiler_generated: false,
                span: id.span.clone(),
            };
            let typed_call =
                self.check_registered_callable_application(span, &new_id, args, None)?;
            let ret_ty = typed_call.ty.clone();
            let expected_self_ty = Ty::Struct(
                id.name.clone(),
                NominalType::new(
                    def.type_param_vars.iter().copied().map(Ty::Var).collect(),
                    def.fields.clone(),
                ),
            );
            let returns_self = self.types_compatible(&expected_self_ty, &ret_ty)?;
            let returns_result_self = match self.resolve_ty(&ret_ty) {
                Ty::Result(ok, _) => self.types_compatible(&expected_self_ty, ok.as_ref())?,
                _ => false,
            };
            if !(returns_self || returns_result_self) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "`{}` must return Self ({}) or Result<Self, E>, got {}",
                        new_name,
                        self.ty_name(&expected_self_ty),
                        self.ty_name(&ret_ty)
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }

            return Ok(typed_call);
        }

        if !matches!(def.kind, crate::env::TypeKind::Record) {
            return Err(TypeError {
                structured: None,
                message: format!("{} is not a constructor-call type", id.name),
                span: span.clone(),
                hint: None,
            });
        }

        let tag = def.tag;
        let mut typed_fields = vec![None; def.fields.len()];

        let named = args
            .iter()
            .any(|a| matches!(a, ResolvedRecordLitArg::Named(_, _)));

        if !named {
            if args.len() != def.fields.len() {
                return Err(TypeError::from_structured(
                    self.argument_contract_diagnostic(
                        TypeDiagnosticReason::ArityMismatch,
                        &id.name,
                        None,
                        def.fields.len(),
                        args.len(),
                        span,
                        DiagnosticOrigin::Call,
                    ),
                ));
            }
            for (i, arg) in args.iter().enumerate() {
                if let ResolvedRecordLitArg::Positional(expr) = arg {
                    let typed_val = self.check_node(expr)?;
                    if self.ty_contains_facet(&typed_val.ty) {
                        return Err(TypeError {
                            structured: None,
                            message:
                                "Record constructors cannot contain Facet values in Stage1 (Facet is compile-time only)"
                                    .into(),
                            span: typed_val.span.clone(),
                            hint: Some("Apply Facet::view/set/over before constructing runtime values.".into()),
                        });
                    }
                    let (_, def_ty) = &def.fields[i];
                    self.assert_type_relation(
                        def_ty,
                        &typed_val.ty,
                        self.type_fact(SourceRole::Expected, &id.span, def_ty),
                        self.type_fact(SourceRole::Value, &typed_val.span, &typed_val.ty),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::Call,
                        &id.name,
                        i as u32,
                    )?;
                    typed_fields[i] = Some(typed_val);
                }
            }
        } else {
            let mut seen = HashSet::new();
            for arg in args {
                if let ResolvedRecordLitArg::Positional(expr) = arg {
                    let mut diagnostic = self.argument_contract_diagnostic(
                        TypeDiagnosticReason::ArgumentModeMismatch,
                        &id.name,
                        None,
                        def.fields.len(),
                        args.len(),
                        self.resolved_span(expr),
                        DiagnosticOrigin::Call,
                    );
                    diagnostic.remediation = Some(diagnostics::Remediation::Help {
                        text: "Named Record arguments require an explicit field name or a bare variable shorthand".into(),
                    });
                    return Err(TypeError::from_structured(diagnostic));
                }
                if let ResolvedRecordLitArg::Named(name, expr) = arg {
                    if !seen.insert(name.clone()) {
                        return Err(TypeError::from_structured(
                            self.argument_contract_diagnostic(
                                TypeDiagnosticReason::DuplicateArgument,
                                &id.name,
                                Some(name),
                                def.fields.len(),
                                args.len(),
                                span,
                                DiagnosticOrigin::Call,
                            ),
                        ));
                    }
                    let idx = def
                        .fields
                        .iter()
                        .position(|(n, _)| n == name)
                        .ok_or_else(|| {
                            TypeError::from_structured(self.argument_contract_diagnostic(
                                TypeDiagnosticReason::UnknownNamedArgument,
                                &id.name,
                                Some(name),
                                def.fields.len(),
                                args.len(),
                                span,
                                DiagnosticOrigin::Call,
                            ))
                        })?;
                    let typed_val = self.check_node(expr)?;
                    if self.ty_contains_facet(&typed_val.ty) {
                        return Err(TypeError {
                            structured: None,
                            message:
                                "Record constructors cannot contain Facet values in Stage1 (Facet is compile-time only)"
                                    .into(),
                            span: typed_val.span.clone(),
                            hint: Some("Apply Facet::view/set/over before constructing runtime values.".into()),
                        });
                    }
                    let (_, def_ty) = &def.fields[idx];
                    self.assert_type_relation(
                        def_ty,
                        &typed_val.ty,
                        self.type_fact(SourceRole::Expected, &id.span, def_ty),
                        self.type_fact(SourceRole::Value, &typed_val.span, &typed_val.ty),
                        TypeDiagnosticReason::ArgumentTypeMismatch,
                        DiagnosticOrigin::Call,
                        &id.name,
                        idx as u32,
                    )?;
                    typed_fields[idx] = Some(typed_val);
                }
            }
        }

        let final_fields: Vec<TypedNode> = typed_fields
            .into_iter()
            .enumerate()
            .map(|(i, f)| {
                f.ok_or_else(|| {
                    TypeError::from_structured(self.argument_contract_diagnostic(
                        TypeDiagnosticReason::MissingArgument,
                        &id.name,
                        Some(&def.fields[i].0),
                        def.fields.len(),
                        args.len(),
                        span,
                        DiagnosticOrigin::Call,
                    ))
                })
            })
            .collect::<Result<Vec<_>, _>>()?;

        let result_ty = match def.kind {
            crate::env::TypeKind::Record => Ty::Record(
                id.name.clone(),
                NominalType::monomorphic(def.fields.clone()),
            ),
            crate::env::TypeKind::Struct
            | crate::env::TypeKind::Enum
            | crate::env::TypeKind::ConcreteError => {
                unreachable!("validated above")
            }
        };
        Ok(TypedNode {
            ty: result_ty,
            span: span.clone(),
            node: TypedInner::ConstructorCall(tag, final_fields),
        })
    }

    pub(super) fn check_explicit_enum_constructor_call(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        type_args: &[AstTy],
        args: &[ResolvedRecordLitArg],
        expected: Option<&Ty>,
    ) -> Result<TypedNode, TypeError> {
        let variant = self
            .lookup_enum_variant_by_constructor_id(id.unique_id)
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown enum constructor: {}", id.name),
                span: span.clone(),
                hint: None,
            })?;
        let def = self
            .env
            .lookup_type_def(&variant.enum_name)
            .cloned()
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown enum type: {}", variant.enum_name),
                span: span.clone(),
                hint: None,
            })?;
        if !matches!(def.kind, crate::env::TypeKind::Enum) {
            return Err(TypeError {
                structured: None,
                message: format!("{} is not an enum type", variant.enum_name),
                span: span.clone(),
                hint: None,
            });
        }
        if type_args.len() != def.type_params.len() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Enum constructor {} expects {} type argument(s), got {}",
                    variant.enum_name,
                    def.type_params.len(),
                    type_args.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }

        let supplied = type_args
            .iter()
            .map(|ast_ty| {
                if matches!(ast_ty, AstTy::Named(_, name) if Self::surface_name(name) == "_") {
                    Ok(self.env.fresh_tyvar())
                } else {
                    let ty = self.resolve_ast_ty_in_context(ast_ty, TypeSyntaxContext::General)?;
                    Ok(ty)
                }
            })
            .collect::<Result<Vec<_>, TypeError>>()?;
        let declared_arguments = match &variant.enum_ty {
            Ty::Enum(_, arguments) => arguments.clone(),
            Ty::Result(ok, _) => vec![ok.as_ref().clone()],
            Ty::Bool => Vec::new(),
            Ty::MatchResult(payload) => vec![payload.as_ref().clone()],
            other => {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Enum constructor metadata for {} has invalid result type {}",
                        variant.enum_name,
                        self.ty_name(other)
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }
        };
        if declared_arguments.len() != supplied.len() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Enum constructor metadata for {} has {} type slot(s), expected {}",
                    variant.enum_name,
                    declared_arguments.len(),
                    supplied.len()
                ),
                span: span.clone(),
                hint: None,
            });
        }
        let mut bindings = HashMap::new();
        for (declared, supplied) in declared_arguments.into_iter().zip(supplied) {
            let Ty::Var(variable) = declared else {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Enum constructor metadata for {} contains a non-variable type slot",
                        variant.enum_name
                    ),
                    span: span.clone(),
                    hint: None,
                });
            };
            bindings.insert(variable, supplied);
        }
        let enum_ty = self.substitute_type_def_ty(&variant.enum_ty, &bindings);
        let payload = variant
            .payload
            .iter()
            .map(|ty| self.substitute_type_def_ty(ty, &bindings))
            .collect::<Vec<_>>();

        if let Some(expected) = expected {
            self.assert_type_relation(
                expected,
                &enum_ty,
                self.type_fact(SourceRole::Expected, span, expected),
                self.type_fact(SourceRole::Value, span, &enum_ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                "enum constructor",
                0,
            )?;
        }

        if variant.special_variant.is_some() || matches!(variant.enum_ty, Ty::MatchResult(_)) {
            let typed = self.check_constructor_call(span, id, args, Some(&enum_ty))?;
            self.assert_type_relation(
                &enum_ty,
                &typed.ty,
                self.type_fact(SourceRole::Expected, span, &enum_ty),
                self.type_fact(SourceRole::Value, &typed.span, &typed.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                &id.name,
                0,
            )?;
            return Ok(typed);
        }

        let payload_values = self.typecheck_positional_call_args(
            span,
            &id.name,
            &payload,
            args,
            None,
            "Enum constructors do not accept named arguments".into(),
        )?;
        self.ensure_no_runtime_facet_args(&payload_values, span, "Enum constructor arguments")?;

        let mut fields = Vec::with_capacity(payload_values.len() + 1);
        fields.push(TypedNode {
            ty: Ty::Int,
            span: span.clone(),
            node: TypedInner::Lit(Lit::Int(variant.discriminant)),
        });
        fields.extend(payload_values);
        Ok(TypedNode {
            ty: self.resolve_ty(&enum_ty),
            span: span.clone(),
            node: TypedInner::ConstructorCall(variant.tag, fields),
        })
    }

    pub(super) fn check_deferror_def(
        &mut self,
        span: &Span,
        id: &ResolvedId,
        fields: &[ResolvedField],
        show_expr: &Resolved,
    ) -> Result<TypedNode, TypeError> {
        let kind = id.qualified_name.clone().ok_or_else(|| {
            TypeError::new(
                "Error declaration is missing canonical identity",
                span.clone(),
            )
        })?;
        let mut seen = HashSet::new();
        let payload_fields = fields
            .iter()
            .map(|field| {
                if matches!(field.name.as_str(), "kind" | "message")
                    || !seen.insert(field.name.clone())
                {
                    return Err(TypeError::new(
                        format!("Invalid or duplicate Error Payload field: {}", field.name),
                        field.span.clone(),
                    ));
                }
                let ty = self.resolve_ast_ty_in_context(&field.ty, TypeSyntaxContext::General)?;
                self.ensure_no_match_result_value(&ty, &field.span)?;
                if self.ty_contains_facet(&ty) {
                    return Err(TypeError::new(
                    "Facet is compile-time only in Stage1 and cannot appear in Error Payload types",
                    field.span.clone(),
                ));
                }
                Ok((field.name.clone(), ty))
            })
            .collect::<Result<Vec<_>, TypeError>>()?;
        let tag = self
            .env
            .lookup_type_def(&id.name)
            .ok_or_else(|| {
                TypeError::new(
                    format!("Unknown Error declaration: {}", id.name),
                    span.clone(),
                )
            })?
            .tag;
        let Resolved::Closure(_, params, _, body) = show_expr else {
            return Err(TypeError::new(
                "deferror body must be a constructor block",
                span.clone(),
            ));
        };
        let mut body_env = self.env.clone();
        let typed_params = params.iter().map(|param| {
            let ast_ty = param.ty.as_ref().ok_or_else(|| TypeError::new(
                "deferror constructor inputs require type annotations", param.id.span.clone()))?;
            let ty = self.resolve_ast_ty_in_context(ast_ty, TypeSyntaxContext::General)?;
            self.ensure_no_match_result_value(&ty, &param.id.span)?;
            if self.ty_contains_facet(&ty) {
                return Err(TypeError::new(
                    "Facet is compile-time only in Stage1 and cannot appear in Error constructor input types",
                    param.id.span.clone(),
                ));
            }
            body_env.bind_var(param.id.unique_id, ty.clone());
            Ok(TypedValueParameter { id: param.id.clone(), mode: spire::ast::ValueParameterMode::PositionalOrNamed,
                ty, span: param.id.span.clone() })
        }).collect::<Result<Vec<_>, TypeError>>()?;
        let fun_idx = match self.env.lookup_var(id.unique_id) {
            Some(Ty::UserFunc { fun_idx, .. }) => *fun_idx,
            _ => {
                return Err(TypeError::new(
                    format!("Undefined Error constructor: {}", id.name),
                    span.clone(),
                ))
            }
        };
        let mut child = self.spawn_child_checker(body_env);
        child.error_definition_uid = Some(id.unique_id);
        child.function_return_ty = Some(Ty::Error);
        let statements: Vec<&Resolved> = match body.as_ref() {
            Resolved::Block(_, items) => items.iter().collect(),
            other => vec![other],
        };
        let Some((last, initial)) = statements.split_last() else {
            return Err(TypeError::new(
                "deferror constructor body cannot be empty",
                span.clone(),
            ));
        };
        let mut typed_body = Vec::new();
        for statement in initial {
            typed_body.push(child.check_node(statement)?);
        }
        let final_node = match last {
            Resolved::ConstructorCall(call_span, target, args)
                if target.unique_id == id.unique_id =>
            {
                let mut schema = vec![("message".to_string(), Ty::Str)];
                schema.extend(payload_fields.clone());
                let mut values = child.check_error_arguments(call_span, &id.name, &schema, args)?;
                let message = Box::new(values.remove(0));
                TypedNode {
                    ty: Ty::Error,
                    span: call_span.clone(),
                    node: TypedInner::ErrorConstruct {
                        kind,
                        message,
                        payload: values,
                        payload_fields,
                    },
                }
            }
            other => {
                if !payload_fields.is_empty() {
                    return Err(TypeError::new(
                        "deferror with Payload requires a direct terminal internal construction",
                        span.clone(),
                    ));
                }
                let message = child.check_node(other)?;
                if !child.types_compatible(&Ty::Str, &message.ty)? {
                    return Err(TypeError::new("empty Payload deferror body must return String or a direct internal construction", message.span.clone()));
                }
                TypedNode {
                    ty: Ty::Error,
                    span: message.span.clone(),
                    node: TypedInner::ErrorConstruct {
                        kind,
                        message: Box::new(message),
                        payload: Vec::new(),
                        payload_fields,
                    },
                }
            }
        };
        typed_body.push(final_node);
        self.absorb_child_progress(&child);
        let body_node = TypedNode {
            ty: Ty::Error,
            span: span.clone(),
            node: TypedInner::Block(typed_body),
        };
        Ok(TypedNode {
            ty: Ty::Unit,
            span: span.clone(),
            node: TypedInner::DeferrorDef(
                tag,
                fun_idx,
                id.clone(),
                typed_params,
                Box::new(body_node),
            ),
        })
    }

    pub(super) fn check_error_arguments(
        &mut self,
        span: &Span,
        name: &str,
        schema: &[(String, Ty)],
        args: &[ResolvedRecordLitArg],
    ) -> Result<Vec<TypedNode>, TypeError> {
        let named = args
            .iter()
            .any(|arg| matches!(arg, ResolvedRecordLitArg::Named(..)));
        let mut values = vec![None; schema.len()];
        if args.len() != schema.len() {
            return Err(TypeError::new(
                format!(
                    "{} expects {} arguments, got {}",
                    name,
                    schema.len(),
                    args.len()
                ),
                span.clone(),
            ));
        }
        for (position, argument) in args.iter().enumerate() {
            let (index, expression) = if named {
                let (field, expression) = match argument {
                    ResolvedRecordLitArg::Named(field, expression) => (field.as_str(), expression),
                    ResolvedRecordLitArg::Positional(expression) => {
                        match expression {
                            Resolved::Var(_, variable) => (variable.name.as_str(), expression),
                            _ => return Err(TypeError::new(
                                "Error named arguments require an explicit name or a bare variable",
                                span.clone(),
                            )),
                        }
                    }
                };
                let index = schema
                    .iter()
                    .position(|(name, _)| name == field)
                    .ok_or_else(|| {
                        TypeError::new(
                            format!("Unknown Error field or input: {}", field),
                            span.clone(),
                        )
                    })?;
                (index, expression)
            } else {
                let ResolvedRecordLitArg::Positional(expression) = argument else {
                    unreachable!()
                };
                (position, expression)
            };
            if values[index].is_some() {
                return Err(TypeError::new(
                    format!("Duplicate Error field or input: {}", schema[index].0),
                    span.clone(),
                ));
            }
            let value = self.check_node_with_expected(expression, Some(&schema[index].1))?;
            self.assert_type_relation(
                &schema[index].1,
                &value.ty,
                self.type_fact(SourceRole::Expected, span, &schema[index].1),
                self.type_fact(SourceRole::Value, &value.span, &value.ty),
                TypeDiagnosticReason::ArgumentTypeMismatch,
                DiagnosticOrigin::Call,
                name,
                index as u32,
            )?;
            values[index] = Some(value);
        }
        let values = values
            .into_iter()
            .enumerate()
            .map(|(index, value)| {
                value.ok_or_else(|| {
                    TypeError::new(
                        format!("Missing Error field or input: {}", schema[index].0),
                        span.clone(),
                    )
                })
            })
            .collect::<Result<Vec<_>, _>>()?;
        self.ensure_no_runtime_facet_args(&values, span, "Error constructor arguments")?;
        Ok(values)
    }

    pub(super) fn error_kind_error_hint(&self, node: &TypedNode) -> Option<String> {
        if !matches!(self.resolve_ty(&node.ty), Ty::Enum(name, args) if name == "ErrorKind" && args.is_empty())
        {
            return None;
        }
        if let TypedInner::ErrorKind(kind) = &node.node {
            let id = self.function_ids_by_name.get(kind)?;
            let inputs = self.env.error_constructor_inputs.get(&id.unique_id)?;
            let name = kind.strip_prefix("Global::").unwrap_or(kind);
            return Some(if inputs.is_empty() {
                format!("Call `{name}()` to construct an Error; the bare name is an ErrorKind.")
            } else {
                format!("Call `{name}(...)` with the declared constructor inputs to construct an Error; the bare name is an ErrorKind.")
            });
        }
        Some("ErrorKind identifies a deferror declaration. Pass an Error value or call a concrete deferror constructor explicitly.".into())
    }

    pub(super) fn is_abstract_error_marker_value(&self, node: &TypedNode) -> bool {
        matches!(&node.node, TypedInner::Var(id) if id.name == "Error" && !self.env.is_error_constructor(id.unique_id))
    }

    pub(super) fn ensure_guard_error_value(
        &self,
        node: &TypedNode,
        form_name: &str,
    ) -> Result<(), TypeError> {
        if !matches!(node.ty, Ty::Error) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} error branch must evaluate to Error, got {}",
                    form_name,
                    self.ty_name(&node.ty)
                ),
                span: node.span.clone(),
                hint: self.error_kind_error_hint(node),
            });
        }
        Ok(())
    }

    pub(super) fn ensure_result_error_arg(
        &self,
        node: &TypedNode,
        form_name: &str,
    ) -> Result<(), TypeError> {
        if !matches!(node.ty, Ty::Error) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} error argument must evaluate to Error, got {}",
                    form_name,
                    self.ty_name(&node.ty)
                ),
                span: node.span.clone(),
                hint: self.error_kind_error_hint(node),
            });
        }
        Ok(())
    }
}
