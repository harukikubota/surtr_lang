use super::*;
use sindr::builtin::{builtin_type_meta_by_name, builtin_type_supports_inherent_impl};
use sindr::names::{builtin_type_name, surface_path_name, TraitImplPolicy};

const SYNTHETIC_DEFAULT_METHOD_UID_BASE: u32 = 0x6000_0000;

pub(super) fn is_generated_derive_impl(methods: &[ResolvedTraitImplMethod]) -> bool {
    !methods.is_empty()
        && methods
            .iter()
            .all(|method| method.function_id.compiler_generated)
}

enum ParentImplCoverage {
    HeadMismatch,
    ConstraintMismatch,
    Covers,
}

impl Checker {
    fn validate_type_shape_clause(
        clause: Option<&ResolvedWhereClause>,
        trait_definition: bool,
        enclosing_impl_trait: Option<&ResolvedId>,
        constructor_trait_ids: &HashSet<u32>,
        trait_names: &HashSet<String>,
    ) -> Result<(), TypeError> {
        let Some(clause) = clause else {
            return Ok(());
        };
        let mut shape_seen = false;
        for constraint in &clause.constraints {
            if let AstTy::Named(span, subject) = &constraint.subject {
                if trait_names.contains(Self::surface_name(subject))
                    && constraint
                        .bounds
                        .iter()
                        .any(|bound| matches!(bound, ResolvedWhereConstraintRhs::Trait { .. }))
                {
                    return Err(super::signatures::invalid_trait_constraint_subject_error(
                        Self::surface_name(subject),
                        span.clone(),
                    ));
                }
            }
            for bound in &constraint.bounds {
                if let ResolvedWhereConstraintRhs::TraitSlot { trait_id, span, .. } = bound {
                    let Some(enclosing_trait) = enclosing_impl_trait else {
                        return Err(TypeError {
                            structured: None,
                            message: "`Trait.$Slot` mappings are only allowed in a trait implementation where clause".into(),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    if !constructor_trait_ids.contains(&enclosing_trait.unique_id) {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Trait {} is not a TypeConstructor trait and cannot own a slot mapping",
                                enclosing_trait.name
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                    if trait_id.unique_id != enclosing_trait.unique_id {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "`Trait.$Slot` mapping owner {} must be the same trait as enclosing impl {}",
                                trait_id.name, enclosing_trait.name
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                    continue;
                }
                let ResolvedWhereConstraintRhs::TypeConstructor { span, .. } = bound else {
                    continue;
                };
                if !trait_definition
                    || !matches!(&constraint.subject, AstTy::Named(_, name) if name == "Self")
                {
                    return Err(TypeError {
                        structured: None,
                        message:
                            "`Type<...>` is only allowed as `Self: Type<...>` in a trait definition where clause"
                                .into(),
                        span: span.clone(),
                        hint: None,
                    });
                }
                if shape_seen {
                    return Err(TypeError {
                        structured: None,
                        message: "A trait definition cannot declare more than one Self type-constructor constraint"
                            .into(),
                        span: span.clone(),
                        hint: None,
                    });
                }
                shape_seen = true;
            }
        }
        Ok(())
    }

    pub(super) fn validate_declaration_where_well_formedness(
        &self,
        stmts: &[Resolved],
    ) -> Result<(), TypeError> {
        let mut constructor_trait_ids = self
            .traits
            .values()
            .filter(|info| !info.constructor_slots.is_empty())
            .map(|info| info.id.unique_id)
            .collect::<HashSet<_>>();
        constructor_trait_ids.extend(stmts.iter().filter_map(|stmt| {
            let Resolved::TraitDef(_, id, _, Some(clause), _, _) = stmt else {
                return None;
            };
            clause
                .constraints
                .iter()
                .any(|constraint| {
                    matches!(&constraint.subject, AstTy::Named(_, name) if name == "Self")
                        && constraint.bounds.iter().any(|bound| {
                            matches!(bound, ResolvedWhereConstraintRhs::TypeConstructor { .. })
                        })
                })
                .then_some(id.unique_id)
        }));
        // A trait may inherit its contextual shape through a parent (for
        // example `Applicative: Functor`).  This validation runs before the
        // trait table has been predeclared, so reproduce the same closure
        // over the resolved declarations here rather than mistaking those
        // inherited constructor traits for ordinary traits.
        loop {
            let mut changed = false;
            for stmt in stmts {
                let Resolved::TraitDef(_, id, _, Some(clause), _, _) = stmt else {
                    continue;
                };
                if constructor_trait_ids.contains(&id.unique_id) {
                    continue;
                }
                let inherits_constructor_shape = clause.constraints.iter().any(|constraint| {
                    matches!(&constraint.subject, AstTy::Named(_, name) if name == "Self")
                        && constraint.bounds.iter().any(|bound| {
                            matches!(bound, ResolvedWhereConstraintRhs::Trait { trait_id }
                                if constructor_trait_ids.contains(&trait_id.unique_id))
                        })
                });
                if inherits_constructor_shape {
                    constructor_trait_ids.insert(id.unique_id);
                    changed = true;
                }
            }
            if !changed {
                break;
            }
        }
        let mut trait_names = self
            .traits
            .values()
            .flat_map(|info| {
                [
                    Self::surface_name(&info.id.name).to_string(),
                    self.trait_key(&info.id),
                ]
            })
            .collect::<HashSet<_>>();
        trait_names.extend(stmts.iter().filter_map(|stmt| {
            let Resolved::TraitDef(_, id, ..) = stmt else {
                return None;
            };
            Some(Self::surface_name(&id.name).to_string())
        }));
        for stmt in stmts {
            match stmt {
                Resolved::Def(
                    _,
                    id,
                    return_type_arguments,
                    value_parameters,
                    return_type,
                    clause,
                    _,
                    _,
                )
                | Resolved::BuiltinDecl(
                    _,
                    id,
                    return_type_arguments,
                    value_parameters,
                    return_type,
                    clause,
                    _,
                ) => {
                    Self::validate_type_shape_clause(
                        clause.as_ref(),
                        false,
                        None,
                        &constructor_trait_ids,
                        &trait_names,
                    )?;
                    let rewritten_return_type_arguments = return_type_arguments
                        .iter()
                        .map(|argument| sigil::resolved::ResolvedReturnTypeArgument {
                            ordinal: argument.ordinal,
                            ty: sigil::resolved::ResolvedSignatureTy {
                                syntax: self
                                    .rewrite_inherent_signature_ast_ty(id, argument.ty.syntax()),
                                direct_constructor_trait: argument
                                    .ty
                                    .direct_constructor_trait
                                    .clone(),
                            },
                            span: argument.span.clone(),
                        })
                        .collect::<Vec<_>>();
                    let rewritten_value_parameters = value_parameters
                        .iter()
                        .map(|parameter| sigil::resolved::ResolvedValueParameter {
                            id: parameter.id.clone(),
                            mode: parameter.mode,
                            ty: sigil::resolved::ResolvedSignatureTy {
                                syntax: self
                                    .rewrite_inherent_signature_ast_ty(id, parameter.ty.syntax()),
                                direct_constructor_trait: parameter
                                    .ty
                                    .direct_constructor_trait
                                    .clone(),
                            },
                            span: parameter.span.clone(),
                        })
                        .collect::<Vec<_>>();
                    let rewritten_return_type =
                        return_type
                            .as_ref()
                            .map(|ty| sigil::resolved::ResolvedSignatureTy {
                                syntax: self.rewrite_inherent_signature_ast_ty(id, ty.syntax()),
                                direct_constructor_trait: ty.direct_constructor_trait.clone(),
                            });
                    // The canonical Pattern consumer derives its result from selected
                    // projection slots; $Return is not a caller-supplied type argument.
                    let pattern_result_slot = matches!(stmt, Resolved::BuiltinDecl(..))
                        && Self::surface_qualified_name(id.qualified_name.as_deref())
                            == Some("Kernel::apply_pattern")
                        && return_type_arguments.is_empty()
                        && clause.is_none()
                        && super::definitions::special_form_shape_apply_pattern(
                            value_parameters,
                            &return_type.as_ref().map(|ty| ty.syntax.clone()),
                        );
                    if !pattern_result_slot {
                        super::signatures::validate_return_type_argument_definition(
                            id.qualified_name.as_deref().unwrap_or(&id.name),
                            &rewritten_return_type_arguments,
                            &rewritten_value_parameters,
                            rewritten_return_type.as_ref(),
                        )?;
                    }
                    super::signatures::validate_constructor_variable_constraints(
                        &id.name,
                        &rewritten_return_type_arguments,
                        &rewritten_value_parameters,
                        rewritten_return_type.as_ref().map(|ty| ty.syntax()),
                        clause.as_ref(),
                        None,
                        &constructor_trait_ids,
                    )?;
                }
                Resolved::TraitDef(_, _, _, clause, methods, _) => {
                    Self::validate_type_shape_clause(
                        clause.as_ref(),
                        true,
                        None,
                        &constructor_trait_ids,
                        &trait_names,
                    )?;
                    for method in methods {
                        Self::validate_type_shape_clause(
                            method.where_clause.as_ref(),
                            false,
                            None,
                            &constructor_trait_ids,
                            &trait_names,
                        )?;
                        super::signatures::validate_return_type_argument_definition(
                            method
                                .id
                                .qualified_name
                                .as_deref()
                                .unwrap_or(&method.id.name),
                            &method.return_type_arguments,
                            &method.value_parameters,
                            Some(&method.ret_ty),
                        )?;
                        super::signatures::validate_constructor_variable_constraints(
                            &method.id.name,
                            &method.return_type_arguments,
                            &method.value_parameters,
                            Some(method.ret_ty.syntax()),
                            method.where_clause.as_ref(),
                            clause.as_ref(),
                            &constructor_trait_ids,
                        )?;
                    }
                }
                Resolved::TraitImplDef(_, _, trait_id, _, _, clause, methods) => {
                    Self::validate_type_shape_clause(
                        clause.as_ref(),
                        false,
                        Some(trait_id),
                        &constructor_trait_ids,
                        &trait_names,
                    )?;
                    for method in methods {
                        Self::validate_type_shape_clause(
                            method.where_clause.as_ref(),
                            false,
                            None,
                            &constructor_trait_ids,
                            &trait_names,
                        )?;
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    pub(super) fn predeclare_signature_aliases(
        &mut self,
        stmts: &[Resolved],
    ) -> Result<(), TypeError> {
        for stmt in stmts {
            let Resolved::TypeAlias(span, name, params, rhs, _) = stmt else {
                continue;
            };
            if self.signature_aliases.contains_key(name) || self.env.lookup_type_def(name).is_some()
            {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Internal consistency error: duplicate type owner `{}` reached Scar after resolution",
                        name
                    ),
                    span: span.clone(),
                    hint: Some(
                        "Sigil must reject duplicate owners before type checking.".into(),
                    ),
                });
            }
            let mut used = HashSet::new();
            Self::collect_ast_ty_type_params(rhs, &mut used);
            if let Some(param) = params.iter().find(|param| !used.contains(&param.name)) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Type alias {} has an unused type parameter {}",
                        name, param.name
                    ),
                    span: param.span.clone(),
                    hint: Some(
                        "Every alias type parameter must appear in its function signature.".into(),
                    ),
                });
            }
            self.signature_aliases.insert(
                name.clone(),
                SignatureAliasInfo {
                    params: params.clone(),
                    rhs: rhs.clone(),
                    span: span.clone(),
                },
            );
        }
        Ok(())
    }

    pub(super) fn where_constraint_subject_ty(
        &mut self,
        subject: &AstTy,
        tyvars: &HashMap<String, Ty>,
        self_ty: Option<&Ty>,
        span: &Span,
        generated_derive: bool,
    ) -> Result<Ty, TypeError> {
        if generated_derive && !matches!(subject, AstTy::Named(_, _)) {
            let self_ty = self_ty.ok_or_else(|| {
                TypeError::new("Generated derive requires an impl target", span.clone())
            })?;
            let mut bindings = tyvars.clone();
            let resolved = self.resolve_trait_signature_ast_ty_in_context(
                subject,
                TypeSyntaxContext::General,
                self_ty,
                &mut bindings,
            )?;
            if bindings.keys().any(|name| !tyvars.contains_key(name)) {
                return Err(TypeError::new(
                    "Generated derive constraint references a type variable outside its impl target",
                    span.clone(),
                ));
            }
            return Ok(resolved);
        }
        let AstTy::Named(_, name) = subject else {
            return Err(TypeError {
                structured: None,
                message: "where constraint subjects must be `Self` or a signature type variable"
                    .into(),
                span: span.clone(),
                hint: None,
            });
        };
        if name == "Self" {
            return self_ty.cloned().ok_or_else(|| TypeError {
                structured: None,
                message: "`Self` is only available in trait and trait impl where clauses".into(),
                span: span.clone(),
                hint: None,
            });
        }
        if !name.starts_with('$') {
            return Err(TypeError {
                structured: None,
                message: "where constraint subjects must be `Self` or a signature type variable"
                    .into(),
                span: span.clone(),
                hint: None,
            });
        }
        tyvars.get(name).cloned().ok_or_else(|| TypeError {
            structured: None,
            message: format!(
                "where clause constraint `{name}` does not appear in the declaration signature"
            ),
            span: span.clone(),
            hint: Some("where clauses add constraints; they do not declare type variables".into()),
        })
    }

    fn apply_where_trait_bound(
        &mut self,
        subject: &Ty,
        trait_id: &ResolvedId,
    ) -> Result<(), TypeError> {
        let trait_key = self.trait_key(trait_id);
        let constructor_trait = self
            .traits
            .get(&trait_key)
            .map(|info| !info.constructor_slots.is_empty())
            .ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown trait: {}", trait_id.name),
                span: trait_id.span.clone(),
                hint: None,
            })?;
        match self.resolve_ty(subject) {
            Ty::Var(var) => {
                self.register_tyvar_bound(var, &trait_key);
                if constructor_trait {
                    self.constructor_witness_traits.insert(var, trait_key);
                }
                Ok(())
            }
            // A concrete `Self` is already guarded by trait dispatch/impl
            // validation. Signature where clauses primarily add bounds to
            // variables that must survive instantiation at call sites.
            _ => Ok(()),
        }
    }

    pub(super) fn apply_resolved_where_trait_bounds(
        &mut self,
        where_clause: Option<&ResolvedWhereClause>,
        tyvars: &HashMap<String, Ty>,
        self_ty: Option<&Ty>,
    ) -> Result<(), TypeError> {
        let Some(where_clause) = where_clause else {
            return Ok(());
        };
        for constraint in &where_clause.constraints {
            let subject = self.where_constraint_subject_ty(
                &constraint.subject,
                tyvars,
                self_ty,
                &constraint.span,
                false,
            )?;
            for bound in &constraint.bounds {
                if let ResolvedWhereConstraintRhs::Trait { trait_id } = bound {
                    self.apply_where_trait_bound(&subject, trait_id)?;
                }
            }
        }
        Ok(())
    }

    fn apply_typed_where_trait_bounds(
        &mut self,
        where_clause: Option<&TypedWhereClause>,
        tyvars: &HashMap<String, Ty>,
        self_ty: Option<&Ty>,
        generated_derive: bool,
    ) -> Result<(), TypeError> {
        let Some(where_clause) = where_clause else {
            return Ok(());
        };
        for constraint in &where_clause.constraints {
            let subject = self.where_constraint_subject_ty(
                &constraint.subject,
                tyvars,
                self_ty,
                &constraint.span,
                generated_derive,
            )?;
            for bound in &constraint.bounds {
                if let TypedWhereConstraintRhs::Trait { trait_id } = bound {
                    self.apply_where_trait_bound(&subject, trait_id)?;
                }
            }
        }
        Ok(())
    }

    fn apply_trait_head_where_bounds(
        &mut self,
        where_clause: Option<&TypedWhereClause>,
        trait_head_bindings: &HashMap<String, Ty>,
    ) -> Result<(), TypeError> {
        let Some(where_clause) = where_clause else {
            return Ok(());
        };
        for constraint in &where_clause.constraints {
            let AstTy::Named(_, subject) = &constraint.subject else {
                continue;
            };
            let Some(subject_ty) = trait_head_bindings.get(subject) else {
                continue;
            };
            for bound in &constraint.bounds {
                if let TypedWhereConstraintRhs::Trait { trait_id } = bound {
                    self.apply_where_trait_bound(subject_ty, trait_id)?;
                }
            }
        }
        Ok(())
    }

    fn synthetic_default_method_symbol(impl_declaration_id: u32, trait_method_uid: u32) -> String {
        format!("__default_impl_{impl_declaration_id}_trait_method_{trait_method_uid}")
    }

    fn synthetic_default_method_uid(
        &self,
        qualified_name: &str,
        locally_reserved: &HashSet<u32>,
    ) -> u32 {
        if let Some(existing) = self.function_ids_by_name.get(qualified_name) {
            return existing.unique_id;
        }
        let mut occupied = self
            .function_ids_by_name
            .values()
            .map(|id| id.unique_id)
            .chain(self.trait_impls.values().flat_map(|implementation| {
                implementation
                    .methods
                    .values()
                    .map(|method| method.function_id.unique_id)
            }))
            .chain(locally_reserved.iter().copied())
            .collect::<HashSet<_>>();
        let mut candidate = SYNTHETIC_DEFAULT_METHOD_UID_BASE;
        while !occupied.insert(candidate) {
            candidate = candidate
                .checked_add(1)
                .expect("synthetic default method UID namespace exhausted");
        }
        candidate
    }

    fn trait_method_display_name(trait_id: &ResolvedId, method_name: &str) -> String {
        format!("{}::{}", Self::surface_name(&trait_id.name), method_name)
    }

    fn synthesized_default_method_id(
        &self,
        impl_declaration_id: u32,
        trait_method: &ResolvedId,
        span: &Span,
        locally_reserved: &HashSet<u32>,
    ) -> ResolvedId {
        let qualified_name =
            Self::synthetic_default_method_symbol(impl_declaration_id, trait_method.unique_id);
        let unique_id = self.synthetic_default_method_uid(&qualified_name, locally_reserved);
        ResolvedId {
            name: trait_method.name.clone(),
            qualified_name: Some(qualified_name),
            symbol_info: None,
            unique_id,
            compiler_generated: true,
            span: span.clone(),
        }
    }

    fn struct_new_contract_error(
        &self,
        struct_name: &str,
        span: &Span,
        actual: Option<&Ty>,
    ) -> TypeError {
        let actual_suffix = actual
            .map(|ty| format!("; got {}", self.ty_name(ty)))
            .unwrap_or_default();
        TypeError {
            structured: None,
            message: format!(
                "Struct `{}::{}` `new` must return Self or Result<Self, E>{}",
                struct_name, "new", actual_suffix
            ),
            span: span.clone(),
            hint: Some(format!(
                "Define `impl {} {{ def new(...) -> Self {{ ... }} }}` or `impl {} {{ def new(...) -> Result<Self, Error> {{ ... }} }}`.",
                struct_name, struct_name
            )),
        }
    }

    fn struct_new_return_allowed(
        &mut self,
        expected_self_ty: &Ty,
        ret_ty: &Ty,
    ) -> Result<bool, TypeError> {
        let resolved_ret = self.resolve_ty(ret_ty);
        if self.types_compatible(expected_self_ty, &resolved_ret)? {
            return Ok(true);
        }
        Ok(match resolved_ret {
            Ty::Result(ok, _) => self.types_compatible(expected_self_ty, ok.as_ref())?,
            _ => false,
        })
    }

    pub(super) fn predeclare_error_types(&mut self, stmts: &[Resolved]) {
        for stmt in stmts {
            if let Resolved::DeferrorDef(_, id, _, _) = stmt {
                self.env.declare_error_type_name(id.name.clone());
            }
        }
    }

    fn const_facet_segment_is_allowed(&self, segment: &ResolvedFacetPathSegment) -> bool {
        match segment {
            ResolvedFacetPathSegment::Field { .. } => true,
            ResolvedFacetPathSegment::Bracket(expr) => match expr.expr.as_ref() {
                Resolved::Lit(_, Lit::Int(_) | Lit::Str(_)) => true,
                Resolved::RangeLiteral(_, start, end) => matches!(
                    (start.as_ref(), end.as_ref()),
                    (Resolved::Lit(_, Lit::Int(_)), Resolved::Lit(_, Lit::Int(_)))
                ),
                _ => false,
            },
        }
    }

    fn const_has_dynamic_bracket_segment(&self, value: &Resolved) -> bool {
        match value {
            Resolved::FieldAccess(_, inner, _) => self.const_has_dynamic_bracket_segment(inner),
            Resolved::FacetSegmentAccess(_, inner, segment) => {
                self.const_has_dynamic_bracket_segment(inner)
                    || !self.const_facet_segment_is_allowed(segment)
            }
            Resolved::BinOp(_, BinOp::FacetChain, left, right) => {
                self.const_has_dynamic_bracket_segment(left)
                    || self.const_has_dynamic_bracket_segment(right)
            }
            _ => false,
        }
    }

    fn const_surface_is_allowed(&self, value: &Resolved) -> bool {
        match value {
            Resolved::Lit(_, _) => true,
            Resolved::Var(_, id) => self
                .consts
                .get(&id.unique_id)
                .is_none_or(|meta| matches!(meta.kind, ConstKind::FacetPath)),
            Resolved::FieldAccess(_, inner, _) => self.const_surface_is_allowed(inner),
            Resolved::FacetSegmentAccess(_, inner, segment) => {
                self.const_surface_is_allowed(inner) && self.const_facet_segment_is_allowed(segment)
            }
            Resolved::InferredFacetCapture(_, _) => false,
            Resolved::BinOp(_, BinOp::FacetChain, left, right) => {
                self.const_surface_is_allowed(left) && self.const_surface_is_allowed(right)
            }
            _ => false,
        }
    }

    pub(super) fn predeclare_consts(&mut self, stmts: &[Resolved]) -> Result<(), TypeError> {
        for stmt in stmts {
            let Resolved::ConstDef(span, id, ast_ty, value, attrs) = stmt else {
                continue;
            };

            if !self.const_surface_is_allowed(value) {
                if self.const_has_dynamic_bracket_segment(value) {
                    return Err(TypeError {
                        structured: None,
                        message:
                            "const Facet path bracket segments must use literal Int or String values"
                                .into(),
                        span: span.clone(),
                        hint: Some(
                            "Use literal container keys in const Facet paths and keep dynamic bracket expressions in local bindings or Facet API calls.".into(),
                        ),
                    });
                }
                return Err(TypeError {
                    structured: None,
                    message: "const value must be a primitive literal or a facet path".into(),
                    span: span.clone(),
                    hint: Some(
                        "V1 const supports literal values, facet paths, Facet const refs, and `->` composition of those facet values only.".into(),
                    ),
                });
            }

            let expected_ty = ast_ty
                .as_ref()
                .map(|ty| self.resolve_ast_ty_in_context(ty, TypeSyntaxContext::BindingAnnotation))
                .transpose()?;
            let checked = self.check_node_with_expected(value, expected_ty.as_ref())?;
            let typed = *self.resolve_typed_node(checked);

            let (kind, stored) = match &typed.node {
                TypedInner::Lit(lit) => (
                    ConstKind::PrimitiveLiteral,
                    StoredConstValue::Literal(lit.clone()),
                ),
                TypedInner::FacetPath(path) => (
                    ConstKind::FacetPath,
                    StoredConstValue::FacetPath(path.clone()),
                ),
                _ => {
                    return Err(TypeError {
                        structured: None,
                        message: "const value must be a primitive literal or a facet path".into(),
                        span: span.clone(),
                        hint: Some(
                            "Use `const NAME = 1`, `const NAME = User.profile`, or compose Facet consts with `->`.".into(),
                        ),
                    })
                }
            };

            self.env.bind_var(id.unique_id, typed.ty.clone());
            self.consts.insert(
                id.unique_id,
                ConstMeta {
                    name: id.name.clone(),
                    visibility: attrs.visibility,
                    ty: typed.ty.clone(),
                    kind,
                    value: stored,
                    span: span.clone(),
                },
            );
        }
        Ok(())
    }

    pub(super) fn predeclare_type_signatures(
        &mut self,
        stmts: &[Resolved],
    ) -> Result<(), TypeError> {
        let mut seen_type_spans: HashMap<String, Span> = HashMap::new();
        // Pass 1: reserve deterministic tags for all user-defined types.
        for stmt in stmts {
            let maybe_decl = match stmt {
                Resolved::StructDef(_, id, type_params, _, _) => Some((
                    &id.name,
                    &id.span,
                    TypeKind::Struct,
                    type_params
                        .iter()
                        .map(|param| param.name.clone())
                        .collect::<Vec<_>>(),
                    type_params
                        .iter()
                        .map(|param| param.bound.clone())
                        .collect::<Vec<_>>(),
                    false,
                )),
                Resolved::RecordDef(_, id, _, _) => Some((
                    &id.name,
                    &id.span,
                    TypeKind::Record,
                    Vec::new(),
                    Vec::new(),
                    false,
                )),
                Resolved::DeferrorDef(_, id, _, _) => Some((
                    &id.name,
                    &id.span,
                    TypeKind::ConcreteError,
                    Vec::new(),
                    Vec::new(),
                    false,
                )),
                Resolved::EnumDef(_, id, type_params, _, attrs) => Some((
                    &id.name,
                    &id.span,
                    TypeKind::Enum,
                    type_params
                        .iter()
                        .map(|param| param.name.clone())
                        .collect::<Vec<_>>(),
                    type_params
                        .iter()
                        .map(|param| param.bound.clone())
                        .collect::<Vec<_>>(),
                    attrs.builtin,
                )),
                _ => None,
            };

            let Some((
                name,
                span,
                kind,
                type_params,
                type_param_bounds,
                allow_builtin_reserved_name,
            )) = maybe_decl
            else {
                continue;
            };

            if !allow_builtin_reserved_name
                && builtin_type_meta_by_name(Self::surface_name(name)).is_some()
            {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Type name `{}` is reserved by a canonical builtin type declaration",
                        Self::surface_name(name)
                    ),
                    span: span.clone(),
                    hint: Some("Builtin and canonical type names cannot be redefined.".into()),
                });
            }

            if let Some(first_span) = seen_type_spans.get(name) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Internal consistency error: duplicate type owner `{}` reached Scar after resolution",
                        name
                    ),
                    span: span.clone(),
                    hint: Some(format!(
                        "Sigil must reject duplicate owners before type checking; the first malformed resolved declaration was at {}..{}.",
                        first_span.start, first_span.end
                    )),
                });
            }
            seen_type_spans.insert(name.clone(), span.clone());

            self.env
                .predeclare_type_def(name.clone(), kind, type_params, type_param_bounds);
        }

        self.ensure_no_type_cycles(stmts)?;

        // Pass 2: finalize field signatures and constructor-like bindings.
        for stmt in stmts {
            match stmt {
                Resolved::StructDef(_, id, type_params, fields, _) => {
                    let mut tyvars = HashMap::new();
                    self.seed_signature_type_params(type_params, &mut tyvars);
                    let ty_fields = fields
                        .iter()
                        .map(|f| {
                            let field_ty = self.resolve_signature_ast_ty_in_context(
                                &f.ty,
                                TypeSyntaxContext::General,
                                &mut tyvars,
                            )?;
                            if self.ty_contains_process_init(&field_ty) {
                                return Err(TypeError {
                                    structured: None,
                                    message:
                                        "StandbyInit<T> is only allowed as Standby @init return type"
                                            .into(),
                                    span: f.span.clone(),
                                    hint: None,
                                });
                            }
                            Ok((f.name.clone(), field_ty))
                        })
                        .collect::<Result<Vec<_>, TypeError>>()?;
                    let private_fields = fields
                        .iter()
                        .filter(|field| field.visibility == spire::ast::Visibility::Private)
                        .map(|field| field.name.clone())
                        .collect::<HashSet<_>>();
                    let readonly_fields = fields
                        .iter()
                        .filter(|field| field.readonly)
                        .map(|field| field.name.clone())
                        .collect::<HashSet<_>>();
                    let type_param_vars = type_params
                        .iter()
                        .filter_map(|param| match tyvars.get(&param.name) {
                            Some(Ty::Var(var)) => Some(*var),
                            _ => None,
                        })
                        .collect::<Vec<_>>();
                    self.env
                        .resolve_type_def_signature(
                            &id.name,
                            ty_fields.clone(),
                            type_param_vars.clone(),
                            private_fields,
                            readonly_fields,
                        )
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Unknown type declaration: {}", id.name),
                            span: id.span.clone(),
                            hint: None,
                        })?;
                    self.env
                        .lookup_type_def_mut(&id.name)
                        .expect("resolved struct remains registered")
                        .field_type_spans = fields
                        .iter()
                        .map(|field| Self::ast_ty_span(&field.ty).clone())
                        .collect();
                    self.env.register_type_constructor_id(id.unique_id);
                    self.env.bind_var(
                        id.unique_id,
                        Ty::Struct(
                            id.name.clone(),
                            NominalType::new(
                                type_param_vars.iter().copied().map(Ty::Var).collect(),
                                ty_fields,
                            ),
                        ),
                    );
                }
                Resolved::RecordDef(_, id, fields, _) => {
                    if let Some(field) = fields.iter().find(|field| {
                        field.visibility != spire::ast::Visibility::Public || field.readonly
                    }) {
                        return Err(TypeError {
                            structured: None,
                            message:
                                "record fields do not support visibility or readonly modifiers"
                                    .into(),
                            span: field.span.clone(),
                            hint: None,
                        });
                    }
                    let ty_fields = fields
                        .iter()
                        .map(|f| {
                            let field_ty =
                                self.resolve_ast_ty_in_context(&f.ty, TypeSyntaxContext::General)?;
                            if self.ty_contains_process_init(&field_ty) {
                                return Err(TypeError {
                                    structured: None,
                                    message:
                                        "StandbyInit<T> is only allowed as Standby @init return type"
                                            .into(),
                                    span: f.span.clone(),
                                    hint: None,
                                });
                            }
                            Ok((f.name.clone(), field_ty))
                        })
                        .collect::<Result<Vec<_>, TypeError>>()?;
                    self.env
                        .resolve_type_def_signature(
                            &id.name,
                            ty_fields.clone(),
                            Vec::new(),
                            HashSet::new(),
                            HashSet::new(),
                        )
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Unknown type declaration: {}", id.name),
                            span: id.span.clone(),
                            hint: None,
                        })?;
                    self.env
                        .lookup_type_def_mut(&id.name)
                        .expect("resolved record remains registered")
                        .field_type_spans = fields
                        .iter()
                        .map(|field| Self::ast_ty_span(&field.ty).clone())
                        .collect();
                    self.env.register_type_constructor_id(id.unique_id);
                    self.env.bind_var(
                        id.unique_id,
                        Ty::Record(id.name.clone(), NominalType::monomorphic(ty_fields)),
                    );
                }
                Resolved::DeferrorDef(_, id, fields, _) => {
                    let ty_fields = fields
                        .iter()
                        .map(|f| {
                            Ok((
                                f.name.clone(),
                                self.resolve_ast_ty_in_context(&f.ty, TypeSyntaxContext::General)?,
                            ))
                        })
                        .collect::<Result<Vec<_>, TypeError>>()?;
                    let private_fields = fields
                        .iter()
                        .filter(|field| field.visibility == spire::ast::Visibility::Private)
                        .map(|field| field.name.clone())
                        .collect::<HashSet<_>>();
                    self.env
                        .resolve_type_def_signature(
                            &id.name,
                            ty_fields,
                            Vec::new(),
                            private_fields,
                            HashSet::new(),
                        )
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Unknown type declaration: {}", id.name),
                            span: id.span.clone(),
                            hint: None,
                        })?;
                    self.env
                        .lookup_type_def_mut(&id.name)
                        .expect("resolved data type remains registered")
                        .field_type_spans = fields
                        .iter()
                        .map(|field| Self::ast_ty_span(&field.ty).clone())
                        .collect();
                }
                Resolved::EnumDef(span, id, type_params, variants, attrs) => {
                    self.validate_builtin_enum_shape(span, id, type_params, variants, attrs)?;
                    let mut sig_tyvars = HashMap::new();
                    self.seed_signature_type_params(type_params, &mut sig_tyvars);
                    let enum_ty_args = type_params
                        .iter()
                        .map(|param| {
                            sig_tyvars
                                .get(&param.name)
                                .cloned()
                                .expect("every enum type parameter must be seeded")
                        })
                        .collect::<Vec<_>>();
                    let type_param_vars = enum_ty_args
                        .iter()
                        .map(|ty| match ty {
                            Ty::Var(variable) => *variable,
                            _ => unreachable!("seeded enum type parameter must be a variable"),
                        })
                        .collect::<Vec<_>>();
                    let _ = self
                        .env
                        .resolve_type_def_signature(
                            &id.name,
                            Vec::new(),
                            type_param_vars,
                            HashSet::new(),
                            HashSet::new(),
                        )
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!("Unknown type declaration: {}", id.name),
                            span: id.span.clone(),
                            hint: None,
                        })?;

                    let enum_surface_name = Self::surface_name(&id.name);
                    let builtin_result_enum = attrs.builtin && enum_surface_name == "Result";
                    let builtin_match_result_enum =
                        attrs.builtin && enum_surface_name == "MatchResult";
                    let builtin_boolean_enum = attrs.builtin && enum_surface_name == "Boolean";
                    let enum_ty = if builtin_result_enum {
                        let ok_ty = enum_ty_args
                            .first()
                            .expect("validated canonical Result has exactly one success slot")
                            .clone();
                        Ty::Result(Box::new(ok_ty), Box::new(Ty::Error))
                    } else if builtin_match_result_enum {
                        Ty::MatchResult(Box::new(enum_ty_args[0].clone()))
                    } else if builtin_boolean_enum {
                        Ty::Bool
                    } else {
                        Ty::Enum(id.name.clone(), enum_ty_args.clone())
                    };

                    self.env.bind_var(id.unique_id, enum_ty.clone());
                    self.env.register_type_constructor_id(id.unique_id);

                    let mut next_discriminant = sindr::primitives::int(0);
                    let mut seen_discriminants: HashSet<sindr::primitives::SurtrInt> =
                        HashSet::new();
                    let mut enum_variants = Vec::new();

                    for variant in variants {
                        let discriminant = if let Some(explicit) = &variant.discriminant {
                            explicit.clone()
                        } else {
                            next_discriminant.clone()
                        };
                        if seen_discriminants.contains(&discriminant) {
                            return Err(TypeError {
                                structured: None,
                                message: format!(
                                    "Duplicate enum discriminant {} in {}",
                                    discriminant, id.name
                                ),
                                span: variant.span.clone(),
                                hint: None,
                            });
                        }
                        seen_discriminants.insert(discriminant.clone());
                        next_discriminant = discriminant.clone() + sindr::primitives::int(1);

                        let payload = variant
                            .payload
                            .iter()
                            .map(|ty| {
                                let payload_ty = self.resolve_signature_ast_ty_in_context(
                                    ty,
                                    TypeSyntaxContext::General,
                                    &mut sig_tyvars,
                                )?;
                                if self.ty_contains_process_init(&payload_ty) {
                                    return Err(TypeError {
                                        structured: None,
                                        message:
                                            "StandbyInit<T> is only allowed as Standby @init return type"
                                                .into(),
                                        span: Self::ast_ty_span(ty).clone(),
                                        hint: None,
                                    });
                                }
                                Ok(payload_ty)
                            })
                            .collect::<Result<Vec<_>, _>>()?;

                        let short_name = variant
                            .id
                            .name
                            .rsplit("::")
                            .next()
                            .unwrap_or(variant.id.name.as_str())
                            .to_string();
                        let special_variant = if attrs.builtin {
                            sindr::names::special_enum_variant_meta(&variant.id.name)
                                .filter(|meta| meta.owner == enum_surface_name)
                                .map(|meta| meta.lowering)
                        } else {
                            None
                        };
                        let tag = match special_variant {
                            Some(sindr::names::SpecialEnumVariantLowering::ResultOk) => 0,
                            Some(sindr::names::SpecialEnumVariantLowering::ResultErr) => 1,
                            _ => self.env.reserve_tag(),
                        };
                        let info = crate::env::EnumVariantInfo {
                            special_variant,
                            constructor_name: variant.id.name.clone(),
                            short_name,
                            enum_name: id.name.clone(),
                            enum_ty: enum_ty.clone(),
                            tag,
                            payload: payload.clone(),
                            payload_type_spans: variant
                                .payload
                                .iter()
                                .map(|ty| Self::ast_ty_span(ty).clone())
                                .collect(),
                            discriminant: discriminant.clone(),
                        };
                        self.env
                            .register_enum_variant(variant.id.unique_id, info.clone())
                            .map_err(|message| TypeError {
                                structured: None,
                                message,
                                span: variant.span.clone(),
                                hint: None,
                            })?;
                        enum_variants.push(info);
                    }

                    self.env
                        .enum_variants_by_enum
                        .insert(id.name.clone(), Arc::new(enum_variants));
                }
                _ => {}
            }
        }

        Ok(())
    }

    pub(super) fn ensure_no_type_cycles(&self, stmts: &[Resolved]) -> Result<(), TypeError> {
        let mut decl_spans: HashMap<String, Span> = HashMap::new();
        let mut edges: HashMap<String, HashSet<String>> = HashMap::new();

        for stmt in stmts {
            match stmt {
                Resolved::StructDef(_, id, _, fields, _)
                | Resolved::RecordDef(_, id, fields, _)
                | Resolved::DeferrorDef(_, id, fields, _) => {
                    decl_spans.insert(id.name.clone(), id.span.clone());
                    edges.entry(id.name.clone()).or_default();
                    for field in fields {
                        let mut refs = Vec::new();
                        Self::collect_type_dependency_names(&field.ty, &mut refs);
                        for ref_name in refs {
                            edges.entry(id.name.clone()).or_default().insert(ref_name);
                        }
                    }
                }
                Resolved::EnumDef(_, id, _, variants, _) => {
                    decl_spans.insert(id.name.clone(), id.span.clone());
                    edges.entry(id.name.clone()).or_default();
                    let mut common_refs: Option<HashSet<String>> = None;
                    for variant in variants {
                        let mut variant_refs = HashSet::new();
                        for payload_ty in &variant.payload {
                            let mut refs = Vec::new();
                            Self::collect_type_dependency_names(payload_ty, &mut refs);
                            for ref_name in refs {
                                variant_refs.insert(ref_name);
                            }
                        }
                        common_refs = Some(match common_refs {
                            Some(existing) => existing
                                .intersection(&variant_refs)
                                .cloned()
                                .collect::<HashSet<_>>(),
                            None => variant_refs,
                        });
                    }
                    for ref_name in common_refs.unwrap_or_default() {
                        edges.entry(id.name.clone()).or_default().insert(ref_name);
                    }
                }
                _ => {}
            }
        }

        for refs in edges.values_mut() {
            refs.retain(|name| decl_spans.contains_key(name));
        }

        #[derive(Clone, Copy, PartialEq, Eq)]
        enum Visit {
            Visiting,
            Done,
        }

        fn find_cycle<'a>(
            node: &'a str,
            edges: &'a HashMap<String, HashSet<String>>,
            states: &mut HashMap<String, Visit>,
        ) -> Option<Vec<String>> {
            if states.get(node) == Some(&Visit::Done) {
                return None;
            }
            states.insert(node.to_string(), Visit::Visiting);
            let mut stack = vec![(node, edges[node].iter())];
            // Each frame retains its iterator so returning from a child resumes
            // the same dependency order as the recursive traversal.
            while let Some((_, nexts)) = stack.last_mut() {
                if let Some(next) = nexts.next() {
                    match states.get(next) {
                        Some(Visit::Done) => {}
                        Some(Visit::Visiting) => {
                            let start = stack
                                .iter()
                                .position(|(name, _)| *name == next)
                                .expect("visiting dependency remains on the traversal stack");
                            let mut cycle = stack[start..]
                                .iter()
                                .map(|(name, _)| (*name).to_string())
                                .collect::<Vec<_>>();
                            cycle.push(next.clone());
                            return Some(cycle);
                        }
                        None => {
                            states.insert(next.clone(), Visit::Visiting);
                            stack.push((next.as_str(), edges[next].iter()));
                        }
                    }
                } else {
                    let (finished, _) = stack.pop().expect("traversal has an active frame");
                    states.insert(finished.to_string(), Visit::Done);
                }
            }
            None
        }

        let mut states: HashMap<String, Visit> = HashMap::new();
        for name in decl_spans.keys() {
            if let Some(cycle) = find_cycle(name, &edges, &mut states) {
                return Err(TypeError {
                    structured: None,
                    message: format!("Cyclic type definition detected: {}", cycle.join(" -> ")),
                    span: decl_spans[&cycle[0]].clone(),
                    hint: None,
                });
            }
        }

        Ok(())
    }

    pub(super) fn split_impl_method_name(name: &str) -> Option<(String, String)> {
        let (target, method) = name.rsplit_once("::")?;
        if target.is_empty() || method.is_empty() {
            None
        } else {
            Some((target.to_string(), method.to_string()))
        }
    }

    pub(super) fn split_impl_method_id(id: &ResolvedId) -> Option<(String, String)> {
        if let Some(qualified) = id.qualified_name.as_deref() {
            if let Some(split) = Self::split_impl_method_name(qualified) {
                return Some(split);
            }
        }

        if let Some(split) = Self::split_impl_method_name(&id.name) {
            return Some(split);
        }

        let qualified = id.qualified_name.as_deref()?;
        let mut parts = qualified.rsplitn(3, "::");
        let method = parts.next()?;
        let target = parts.next()?;
        if target.is_empty() || method.is_empty() {
            None
        } else {
            Some((target.to_string(), method.to_string()))
        }
    }

    fn rewrite_inherent_self_apps(ast_ty: &AstTy, target: &str) -> AstTy {
        match ast_ty {
            AstTy::Named(span, name) => AstTy::Named(span.clone(), name.clone()),
            AstTy::ImplTrait(span, name) => AstTy::ImplTrait(span.clone(), name.clone()),
            AstTy::Generic(span, name, args) => AstTy::Generic(
                span.clone(),
                if name == "Self" {
                    target.to_string()
                } else {
                    name.clone()
                },
                args.iter()
                    .map(|arg| Self::rewrite_inherent_self_apps(arg, target))
                    .collect(),
            ),
            AstTy::Tuple(span, items) => AstTy::Tuple(
                span.clone(),
                items
                    .iter()
                    .map(|item| Self::rewrite_inherent_self_apps(item, target))
                    .collect(),
            ),
            AstTy::Func(span, params, ret) => AstTy::Func(
                span.clone(),
                params
                    .iter()
                    .map(|param| Self::rewrite_inherent_self_apps(param, target))
                    .collect(),
                Box::new(Self::rewrite_inherent_self_apps(ret, target)),
            ),
        }
    }

    fn rewrite_inherent_signature_ast_ty(&self, id: &ResolvedId, ast_ty: &AstTy) -> AstTy {
        let Some((target, _)) = Self::split_impl_method_id(id) else {
            return ast_ty.clone();
        };
        let target_surface = Self::surface_name(&target).to_string();
        if !target.starts_with("Global::")
            && self.env.lookup_type_def(&target).is_none()
            && self.env.lookup_type_def(&target_surface).is_none()
            && !builtin_type_supports_inherent_impl(&target_surface)
        {
            return ast_ty.clone();
        }
        Self::rewrite_inherent_self_apps(ast_ty, &target_surface)
    }

    pub(super) fn resolve_def_parameter_contract(
        &mut self,
        id: &ResolvedId,
        signature: &sigil::resolved::ResolvedSignatureTy,
        tyvars: &mut HashMap<String, Ty>,
    ) -> Result<Ty, TypeError> {
        if let Some(inner) = Self::lazy_parameter_inner(signature.syntax()) {
            if !self.enforce_builtin_type_contracts
                && !self.lazy_function_parameters.contains_key(&id.unique_id)
            {
                return Err(self.lazy_type_not_allowed_error(Self::ast_ty_span(signature.syntax())));
            }
            let inner_signature = sigil::resolved::ResolvedSignatureTy {
                syntax: inner.clone(),
                direct_constructor_trait: None,
            };
            let result = self.resolve_def_signature_ast_ty_in_context(
                id,
                &inner_signature,
                TypeSyntaxContext::General,
                tyvars,
            )?;
            return Ok(Ty::Func(vec![], Box::new(result)));
        }
        self.resolve_def_signature_ast_ty_in_context(
            id,
            signature,
            TypeSyntaxContext::General,
            tyvars,
        )
    }

    pub(super) fn resolve_def_signature_ast_ty_in_context(
        &mut self,
        id: &ResolvedId,
        signature_ty: &sigil::resolved::ResolvedSignatureTy,
        context: TypeSyntaxContext,
        tyvars: &mut HashMap<String, Ty>,
    ) -> Result<Ty, TypeError> {
        let Some((target, _)) = Self::split_impl_method_id(id) else {
            return self.resolve_resolved_signature_ty_in_context(signature_ty, context, tyvars);
        };
        let target_surface = Self::surface_name(&target).to_string();
        if !target.starts_with("Global::")
            && self.env.lookup_type_def(&target).is_none()
            && self.env.lookup_type_def(&target_surface).is_none()
            && !builtin_type_supports_inherent_impl(&target_surface)
        {
            return self.resolve_resolved_signature_ty_in_context(signature_ty, context, tyvars);
        }
        let rewritten = sigil::resolved::ResolvedSignatureTy {
            syntax: Self::rewrite_inherent_self_apps(signature_ty.syntax(), &target_surface),
            direct_constructor_trait: signature_ty.direct_constructor_trait.clone(),
        };
        self.resolve_resolved_signature_ty_in_context(&rewritten, context, tyvars)
    }

    pub(super) fn current_impl_self_ty(&self) -> Option<Ty> {
        let symbol = self.current_function_symbol.as_deref()?;
        let mut parts = symbol.split("::").collect::<Vec<_>>();
        if parts.len() < 2 {
            return None;
        }
        let target = parts.pop()?;
        let _method = target;
        let type_name = parts.pop()?;
        let def = self.env.lookup_type_def(type_name)?;
        match def.kind {
            TypeKind::Struct => Some(Ty::Struct(
                def.name.clone(),
                NominalType::new(
                    def.type_param_vars.iter().copied().map(Ty::Var).collect(),
                    def.fields.clone(),
                ),
            )),
            TypeKind::Enum => Some(Ty::Enum(def.name.clone(), Vec::new())),
            TypeKind::Record | TypeKind::ConcreteError => None,
        }
    }

    pub(super) fn ensure_self_rebinding_types(
        &mut self,
        pattern: &TypedPattern,
        span: &Span,
    ) -> Result<(), TypeError> {
        let expected_self = self.current_impl_self_ty();
        self.ensure_self_rebinding_types_inner(pattern, span, expected_self.as_ref())
    }

    pub(super) fn ensure_self_rebinding_types_inner(
        &mut self,
        pattern: &TypedPattern,
        span: &Span,
        expected_self: Option<&Ty>,
    ) -> Result<(), TypeError> {
        match pattern {
            TypedPattern::Located(_, inner) => {
                self.ensure_self_rebinding_types_inner(inner, span, expected_self)
            }
            TypedPattern::HashMap(_, entries) => {
                for entry in entries {
                    self.ensure_self_rebinding_types_inner(&entry.pattern, span, expected_self)?;
                }
                Ok(())
            }
            TypedPattern::Var(bind_ty, id) => {
                if id.name == "self" {
                    let Some(expected) = expected_self else {
                        return Err(TypeError {
                            structured: None,
                            message: "`self` can only be rebound inside impl methods".to_string(),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    if !self.types_compatible(expected, bind_ty)? {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "`self` rebinding requires Self type ({}), got {}",
                                self.ty_name(expected),
                                self.ty_name(bind_ty)
                            ),
                            span: id.span.clone(),
                            hint: None,
                        });
                    }
                }
                Ok(())
            }
            TypedPattern::As(alias_ty, inner, id) => {
                if id.name == "self" {
                    let Some(expected) = expected_self else {
                        return Err(TypeError {
                            structured: None,
                            message: "`self` can only be rebound inside impl methods".to_string(),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    if !self.types_compatible(expected, alias_ty)? {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "`self` rebinding requires Self type ({}), got {}",
                                self.ty_name(expected),
                                self.ty_name(alias_ty)
                            ),
                            span: id.span.clone(),
                            hint: None,
                        });
                    }
                }
                self.ensure_self_rebinding_types_inner(inner, span, expected_self)
            }
            TypedPattern::ListCons(_, head, tail) => {
                self.ensure_self_rebinding_types_inner(head, span, expected_self)?;
                self.ensure_self_rebinding_types_inner(tail, span, expected_self)
            }
            TypedPattern::Tuple(_, items) => {
                for item in items {
                    self.ensure_self_rebinding_types_inner(item, span, expected_self)?;
                }
                Ok(())
            }
            TypedPattern::Constructor { fields, .. } => {
                for field in fields {
                    self.ensure_self_rebinding_types_inner(field, span, expected_self)?;
                }
                Ok(())
            }
            TypedPattern::Extractor { items, .. } => {
                for item in items {
                    self.ensure_self_rebinding_types_inner(item, span, expected_self)?;
                }
                Ok(())
            }
            TypedPattern::Wildcard(_)
            | TypedPattern::Pin(_, _, _)
            | TypedPattern::ListNil(_)
            | TypedPattern::IntLit(_, _)
            | TypedPattern::StrLit(_, _)
            | TypedPattern::BoolLit(_, _)
            | TypedPattern::DurationLit(_, _) => Ok(()),
        }
    }

    pub(super) fn ensure_struct_impl_new_contract(
        &mut self,
        stmts: &[Resolved],
    ) -> Result<(), TypeError> {
        let mut struct_defs: HashMap<String, (Span, Ty)> = HashMap::new();
        let mut structs_with_new: HashSet<String> = HashSet::new();

        for stmt in stmts {
            if let Resolved::StructDef(_, id, type_params, fields, _attrs) = stmt {
                let mut tyvars = HashMap::new();
                self.seed_signature_type_params(type_params, &mut tyvars);
                let expected_self_ty = Ty::Struct(
                    id.name.clone(),
                    NominalType::new(
                        type_params
                            .iter()
                            .map(|param| {
                                tyvars
                                    .get(&param.name)
                                    .cloned()
                                    .expect("seeded struct type parameter")
                            })
                            .collect(),
                        fields
                            .iter()
                            .map(|field| {
                                Ok((
                                    field.name.clone(),
                                    self.resolve_signature_ast_ty_in_context(
                                        &field.ty,
                                        TypeSyntaxContext::General,
                                        &mut tyvars,
                                    )?,
                                ))
                            })
                            .collect::<Result<Vec<_>, TypeError>>()?,
                    ),
                );
                struct_defs.insert(id.name.clone(), (id.span.clone(), expected_self_ty.clone()));
                if let Some(surface_name) = id.name.strip_prefix("Global::") {
                    struct_defs.insert(
                        surface_name.to_string(),
                        (id.span.clone(), expected_self_ty),
                    );
                }
            }
        }

        for stmt in stmts {
            let Resolved::Def(_, id, _, _, _, _, _, _) = stmt else {
                continue;
            };
            if let Some((target, method)) = Self::split_impl_method_id(id) {
                if method == "new" {
                    structs_with_new.insert(target.clone());
                    if !target.contains("::") {
                        structs_with_new.insert(format!("Global::{}", target));
                    }
                    if let Some(surface_name) = target.strip_prefix("Global::") {
                        structs_with_new.insert(surface_name.to_string());
                    }
                    let Some((span, expected_self_ty)) = struct_defs.get(&target) else {
                        continue;
                    };
                    let Some(method_ty) = self.env.lookup_var(id.unique_id) else {
                        continue;
                    };
                    let ret_ty = match self.resolve_ty(method_ty) {
                        Ty::UserFunc { ret, .. }
                        | Ty::BuiltinFunc { ret, .. }
                        | Ty::Func(_, ret) => *ret,
                        other => {
                            return Err(self.struct_new_contract_error(&target, span, Some(&other)))
                        }
                    };
                    if !self.struct_new_return_allowed(expected_self_ty, &ret_ty)? {
                        return Err(self.struct_new_contract_error(&target, span, Some(&ret_ty)));
                    }
                }
            }
        }

        for (struct_name, (span, _)) in struct_defs {
            if !structs_with_new.contains(&struct_name) {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Struct `{}` must define `new` in its impl block (e.g. `impl {} {{ def new(...) -> Self {{ ... }} }}` or `impl {} {{ def new(...) -> Result<Self, Error> {{ ... }} }}`)",
                        struct_name, struct_name
                        , struct_name
                    ),
                    span,
                    hint: None,
                });
            }
        }

        Ok(())
    }

    pub(super) fn register_function_id(&mut self, id: &ResolvedId) {
        let key = id.qualified_name.clone().unwrap_or_else(|| id.name.clone());
        self.function_ids_by_name.insert(key.clone(), id.clone());
        if let Some(surface_key) = key.strip_prefix("Global::") {
            self.function_ids_by_name
                .insert(surface_key.to_string(), id.clone());
        }
    }

    pub(super) fn trait_key(&self, id: &ResolvedId) -> String {
        id.qualified_name.clone().unwrap_or_else(|| id.name.clone())
    }

    pub(super) fn ast_ty_key(ast_ty: &AstTy) -> String {
        match ast_ty {
            AstTy::Named(_, name) | AstTy::ImplTrait(_, name) => name.clone(),
            AstTy::Generic(_, name, args) => format!(
                "{}<{}>",
                name,
                args.iter()
                    .map(Self::ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Tuple(_, items) => format!(
                "({})",
                items
                    .iter()
                    .map(Self::ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Func(_, params, ret) => format!(
                "({} -> {})",
                params
                    .iter()
                    .map(Self::ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", "),
                Self::ast_ty_key(ret)
            ),
        }
    }

    pub(super) fn trait_instance_key(&self, trait_id: &ResolvedId, trait_args: &[AstTy]) -> String {
        let base = self.trait_key(trait_id);
        if trait_args.is_empty() {
            base
        } else {
            format!(
                "{}<{}>",
                base,
                trait_args
                    .iter()
                    .map(Self::ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", ")
            )
        }
    }

    pub(super) fn trait_impl_for_declaration(
        &self,
        declaration_id: u32,
    ) -> Option<Arc<TraitImplInfo>> {
        self.trait_impls
            .values()
            .find(|info| info.declaration_key.declaration_id == declaration_id)
            .cloned()
    }

    pub(super) fn trait_display_name(&self, trait_name: &str) -> String {
        let (base, suffix) = trait_name
            .split_once('<')
            .map(|(base, suffix)| (base, Some(suffix)))
            .unwrap_or((trait_name, None));
        let display = self
            .traits
            .get(base)
            .map(|info| info.id.name.clone())
            .unwrap_or_else(|| base.rsplit("::").next().unwrap_or(base).to_string());
        match suffix {
            Some(suffix) => format!("{}<{}", display, suffix),
            None => display,
        }
    }

    pub(super) fn trait_key_by_short_name(&self, short_name: &str) -> Option<String> {
        let mut candidates = self
            .traits
            .values()
            .filter(|info| info.id.name == short_name)
            .map(|info| self.trait_key(&info.id))
            .collect::<Vec<_>>();
        candidates.sort();
        candidates.dedup();
        (candidates.len() == 1).then(|| candidates.remove(0))
    }

    pub(super) fn trait_matches_short_name(&self, trait_name: &str, short_name: &str) -> bool {
        self.trait_key_by_short_name(short_name)
            .as_deref()
            .is_some_and(|key| key == trait_name)
    }

    pub(super) fn trait_instance_key_from_tys(
        &self,
        trait_name: &str,
        trait_args: &[Ty],
    ) -> String {
        if trait_args.is_empty() {
            trait_name.to_string()
        } else {
            format!(
                "{}<{}>",
                trait_name,
                trait_args
                    .iter()
                    .map(|ty| self.ty_name(&self.resolve_ty(ty)))
                    .collect::<Vec<_>>()
                    .join(", ")
            )
        }
    }

    pub(super) fn collect_ty_vars(ty: &Ty, out: &mut Vec<u32>) {
        match ty {
            Ty::Var(var) => {
                if !out.contains(var) {
                    out.push(*var);
                }
            }
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => Self::collect_ty_vars(inner, out),
            Ty::Result(source, focus) => {
                Self::collect_ty_vars(source, out);
                Self::collect_ty_vars(focus, out);
            }
            Ty::Facet(_, source, focus, update_source, update_focus) => {
                Self::collect_ty_vars(source, out);
                Self::collect_ty_vars(focus, out);
                Self::collect_ty_vars(update_source, out);
                Self::collect_ty_vars(update_focus, out);
            }
            Ty::Tuple(items) | Ty::SelfApp(items) | Ty::Enum(_, items) => {
                for item in items {
                    Self::collect_ty_vars(item, out);
                }
            }
            Ty::Func(params, ret) => {
                for param in params {
                    Self::collect_ty_vars(param, out);
                }
                Self::collect_ty_vars(ret, out);
            }
            Ty::BuiltinFunc { params, ret, .. } | Ty::UserFunc { params, ret, .. } => {
                for param in params {
                    Self::collect_ty_vars(param, out);
                }
                Self::collect_ty_vars(ret, out);
            }
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                for argument in &nominal.arguments {
                    Self::collect_ty_vars(argument, out);
                }
                for (_, field_ty) in nominal {
                    Self::collect_ty_vars(field_ty, out);
                }
            }
            Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::Hole
            | Ty::ProcessMarker(_) => {}
        }
    }

    fn signature_type_param_vars(
        declared: &[ResolvedTypeParam],
        tyvars: &HashMap<String, Ty>,
        params: &[Ty],
        ret: &Ty,
    ) -> Vec<u32> {
        let mut vars = Vec::new();
        for param in declared {
            if let Some(ty) = tyvars.get(&param.name) {
                Self::collect_ty_vars(ty, &mut vars);
            }
        }
        for param in params {
            Self::collect_ty_vars(param, &mut vars);
        }
        Self::collect_ty_vars(ret, &mut vars);
        vars
    }

    fn trait_constructor_slots(
        &self,
        trait_id: &ResolvedId,
        where_clause: Option<&ResolvedWhereClause>,
    ) -> Result<Vec<String>, TypeError> {
        let mut slots = None;
        let Some(clause) = where_clause else {
            return Ok(Vec::new());
        };
        for constraint in &clause.constraints {
            if !matches!(&constraint.subject, AstTy::Named(_, name) if name == "Self") {
                continue;
            }
            for bound in &constraint.bounds {
                let ResolvedWhereConstraintRhs::TypeConstructor {
                    span,
                    slots: declared_slots,
                } = bound
                else {
                    continue;
                };
                if slots.is_some() {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait {} declares more than one Self type-constructor constraint",
                            trait_id.name
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
                if declared_slots.is_empty() {
                    return Err(TypeError {
                        structured: None,
                        message: "Type constructor constraints require at least one slot".into(),
                        span: span.clone(),
                        hint: None,
                    });
                }
                let mut names = Vec::with_capacity(declared_slots.len());
                let mut seen = HashSet::new();
                for slot in declared_slots {
                    let AstTy::Named(slot_span, name) = slot else {
                        return Err(TypeError {
                            structured: None,
                            message: "Type constructor slots must be type variables such as `$A`"
                                .into(),
                            span: Self::ast_ty_span(slot).clone(),
                            hint: None,
                        });
                    };
                    if !name.starts_with('$') {
                        return Err(TypeError {
                            structured: None,
                            message: "Type constructor slots must be type variables such as `$A`"
                                .into(),
                            span: slot_span.clone(),
                            hint: None,
                        });
                    }
                    if !seen.insert(name.clone()) {
                        return Err(TypeError {
                            structured: None,
                            message: format!("Duplicate type constructor slot: {}", name),
                            span: slot_span.clone(),
                            hint: None,
                        });
                    }
                    names.push(name.clone());
                }
                slots = Some(names);
            }
        }
        Ok(slots.unwrap_or_default())
    }

    fn trait_parents(where_clause: Option<&ResolvedWhereClause>) -> Vec<TraitParent> {
        let Some(clause) = where_clause else {
            return Vec::new();
        };
        clause
            .constraints
            .iter()
            .filter(|constraint| {
                matches!(&constraint.subject, AstTy::Named(_, subject) if subject == "Self")
            })
            .flat_map(|constraint| constraint.bounds.iter())
            .filter_map(|bound| match bound {
                ResolvedWhereConstraintRhs::Trait { trait_id } => Some(TraitParent {
                    trait_id: trait_id.clone(),
                }),
                _ => None,
            })
            .collect()
    }

    fn resolve_trait_constraint_closure(&mut self) -> Result<(), TypeError> {
        fn visit(
            key: &str,
            traits: &TraitDefinitions,
            visiting: &mut Vec<String>,
            resolved: &mut HashMap<String, Vec<String>>,
        ) -> Result<Vec<String>, TypeError> {
            if let Some(result) = resolved.get(key) {
                return Ok(result.clone());
            }
            if let Some(start) = visiting.iter().position(|item| item == key) {
                let mut cycle = visiting[start..].to_vec();
                cycle.push(key.to_string());
                let info = traits.get(key).expect("visited trait must exist");
                return Err(TypeError {
                    structured: None,
                    message: format!("Parent trait constraint cycle: {}", cycle.join(" -> ")),
                    span: info.id.span.clone(),
                    hint: None,
                });
            }
            let info = traits.get(key).ok_or_else(|| TypeError {
                structured: None,
                message: format!("Unknown parent trait: {key}"),
                span: Span { start: 0, end: 0 },
                hint: None,
            })?;
            visiting.push(key.to_string());
            let mut slots = info.constructor_slots.clone();
            for parent in &info.parents {
                let parent_key = parent
                    .trait_id
                    .qualified_name
                    .clone()
                    .unwrap_or_else(|| parent.trait_id.name.clone());
                let parent_slots = visit(&parent_key, traits, visiting, resolved)?;
                if slots.is_empty() {
                    slots = parent_slots;
                } else if !parent_slots.is_empty() && slots.len() != parent_slots.len() {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait {} exposes {} constructor slot(s), but parent {} exposes {}",
                            info.id.name,
                            slots.len(),
                            parent.trait_id.name,
                            parent_slots.len()
                        ),
                        span: info.id.span.clone(),
                        hint: None,
                    });
                }
            }
            visiting.pop();
            let result = slots;
            resolved.insert(key.to_string(), result.clone());
            Ok(result)
        }

        let keys = self.traits.keys().cloned().collect::<Vec<_>>();
        let mut resolved = HashMap::new();
        for key in &keys {
            visit(key, &self.traits, &mut Vec::new(), &mut resolved)?;
        }
        for (key, slots) in resolved {
            if let Some(info) = self.traits.get_mut(&key) {
                if info.constructor_slots != slots {
                    Arc::make_mut(info).constructor_slots = slots;
                }
            }
        }
        Ok(())
    }

    fn target_top_level_type_params(target_ast_ty: &AstTy) -> Vec<String> {
        let AstTy::Generic(_, _, args) = target_ast_ty else {
            return Vec::new();
        };
        args.iter()
            .filter_map(|arg| match arg {
                AstTy::Named(_, name) if name.starts_with('$') => Some(name.clone()),
                _ => None,
            })
            .collect()
    }

    fn explicit_constructor_slot_vars_for_impl(
        &self,
        trait_info: &TraitInfo,
        target_ast_ty: &AstTy,
        where_clause: Option<&TypedWhereClause>,
        target_param_vars: &HashMap<String, u32>,
        span: &Span,
        root: bool,
    ) -> Result<(Vec<Option<u32>>, Vec<Option<usize>>), TypeError> {
        let target_params = Self::target_top_level_type_params(target_ast_ty);
        let mut mapped_slots = vec![None; trait_info.constructor_slots.len()];
        let mut mapped_params = HashSet::new();
        if let Some(clause) = where_clause {
            for constraint in &clause.constraints {
                let AstTy::Named(subject_span, subject) = &constraint.subject else {
                    continue;
                };
                for bound in &constraint.bounds {
                    let TypedWhereConstraintRhs::TraitSlot {
                        trait_id,
                        slot_name,
                        slot_ordinal,
                        span: bound_span,
                    } = bound
                    else {
                        continue;
                    };
                    if trait_id.unique_id != trait_info.id.unique_id {
                        continue;
                    }
                    if !target_params.contains(subject) {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "{} is not a top-level type parameter of the impl target",
                                subject
                            ),
                            span: subject_span.clone(),
                            hint: None,
                        });
                    }
                    let slot_ordinal = *slot_ordinal as usize;
                    if slot_ordinal >= trait_info.constructor_slots.len() {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Trait {} has no constructor slot {}",
                                trait_info.id.name, slot_name
                            ),
                            span: bound_span.clone(),
                            hint: None,
                        });
                    }
                    if mapped_slots[slot_ordinal].is_some() {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Trait constructor slot {} is mapped more than once",
                                slot_name
                            ),
                            span: bound_span.clone(),
                            hint: None,
                        });
                    }
                    if !mapped_params.insert(subject.clone()) {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Impl target parameter {} is mapped to more than one constructor slot",
                                subject
                            ),
                            span: bound_span.clone(),
                            hint: None,
                        });
                    }
                    mapped_slots[slot_ordinal] = target_param_vars.get(subject).copied();
                }
            }
        }

        if root
            && mapped_slots.iter().all(Option::is_none)
            && trait_info.constructor_slots.len() == 1
            && target_params.len() == 1
        {
            mapped_slots[0] = target_param_vars.get(&target_params[0]).copied();
        }

        if root && mapped_slots.iter().any(Option::is_none) {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "{} does not satisfy Type<{}>: map every constructor slot in the impl where clause",
                    Self::surface_ast_ty_key(target_ast_ty),
                    trait_info.constructor_slots.join(", ")
                ),
                span: span.clone(),
                hint: Some(format!(
                    "Use `where $T: {}.{}` for each public constructor slot.",
                    trait_info.id.name,
                    trait_info.constructor_slots[0]
                )),
            });
        }

        let positions = mapped_slots.iter().map(|var| var.map(|var| {
            let AstTy::Generic(_, _, arguments) = target_ast_ty else {
                unreachable!("mapped constructor target is an application")
            };
            arguments.iter().position(|argument| matches!(argument, AstTy::Named(_, name) if target_param_vars.get(name) == Some(&var)))
                .expect("mapped constructor variable belongs to target parameters")
        })).collect();
        Ok((mapped_slots, positions))
    }

    fn root_constructor_slot_vars_for_impl(
        &self,
        trait_info: &TraitInfo,
        target_ast_ty: &AstTy,
        where_clause: Option<&TypedWhereClause>,
        target_param_vars: &HashMap<String, u32>,
        span: &Span,
    ) -> Result<(Vec<u32>, Vec<usize>), TypeError> {
        let (vars, positions) = self.explicit_constructor_slot_vars_for_impl(
            trait_info,
            target_ast_ty,
            where_clause,
            target_param_vars,
            span,
            true,
        )?;
        Ok((
            vars.into_iter().map(Option::unwrap).collect(),
            positions.into_iter().map(Option::unwrap).collect(),
        ))
    }

    pub(super) fn trait_head_parameter_constructor_bound(
        &self,
        trait_info: &TraitInfo,
        parameter_name: &str,
    ) -> Option<String> {
        trait_info
            .where_clause
            .as_ref()?
            .constraints
            .iter()
            .find_map(|constraint| {
                matches!(&constraint.subject, AstTy::Named(_, name) if name == parameter_name)
                    .then(|| {
                        constraint.bounds.iter().find_map(|bound| match bound {
                            TypedWhereConstraintRhs::Trait { trait_id }
                                if self.traits.get(&self.trait_key(trait_id)).is_some_and(
                                    |bound_info| !bound_info.constructor_slots.is_empty(),
                                ) =>
                            {
                                Some(self.trait_key(trait_id))
                            }
                            _ => None,
                        })
                    })
                    .flatten()
            })
    }

    pub(super) fn resolve_trait_impl_head_tys(
        &mut self,
        trait_info: &TraitInfo,
        trait_args: &[AstTy],
        target_ast_ty: &AstTy,
    ) -> Result<(Vec<Ty>, Ty, Vec<u32>, HashMap<String, u32>), TypeError> {
        let mut tyvars = HashMap::new();
        let target_ty = self.resolve_signature_like_ast_ty_in_context(
            target_ast_ty,
            TypeSyntaxContext::General,
            &mut tyvars,
            super::types::SignatureTyMode::ImplHead { self_ty: None },
        )?;
        let trait_arg_tys = trait_info
            .type_params
            .iter()
            .zip(trait_args)
            .map(|(parameter, arg)| {
                if self
                    .trait_head_parameter_constructor_bound(trait_info, &parameter.name)
                    .is_some()
                    && !matches!(arg, AstTy::Named(_, name) if name.starts_with('$'))
                {
                    self.resolve_type_constructor_head(arg)
                } else {
                    self.resolve_signature_like_ast_ty_in_context(
                        arg,
                        TypeSyntaxContext::General,
                        &mut tyvars,
                        super::types::SignatureTyMode::ImplHead {
                            self_ty: Some(&target_ty),
                        },
                    )
                }
            })
            .collect::<Result<Vec<_>, _>>()?;
        let mut type_param_vars = Vec::new();
        for ty in &trait_arg_tys {
            Self::collect_ty_vars(ty, &mut type_param_vars);
        }
        Self::collect_ty_vars(&target_ty, &mut type_param_vars);
        let target_param_vars = tyvars
            .into_iter()
            .filter_map(|(name, ty)| match ty {
                Ty::Var(var) if name.starts_with('$') => Some((name, var)),
                _ => None,
            })
            .collect();
        Ok((trait_arg_tys, target_ty, type_param_vars, target_param_vars))
    }

    fn surface_ast_ty_key(ty: &AstTy) -> String {
        match ty {
            AstTy::Named(_, name) | AstTy::ImplTrait(_, name) => Self::surface_name(name).into(),
            AstTy::Generic(_, name, args) => format!(
                "{}<{}>",
                Self::surface_name(name),
                args.iter()
                    .map(Self::surface_ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Tuple(_, items) => format!(
                "({})",
                items
                    .iter()
                    .map(Self::surface_ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
            AstTy::Func(_, params, ret) => format!(
                "({} -> {})",
                params
                    .iter()
                    .map(Self::surface_ast_ty_key)
                    .collect::<Vec<_>>()
                    .join(", "),
                Self::surface_ast_ty_key(ret)
            ),
        }
    }

    pub(super) fn tyvar_satisfies_compiler_trait(&self, _var: u32, _trait_name: &str) -> bool {
        false
    }

    pub(super) fn trait_target_name(&self, ty: &Ty) -> Option<String> {
        match self.resolve_ty(ty) {
            Ty::Int => Some("Int".into()),
            Ty::Float => Some("Float".into()),
            Ty::Str => Some("String".into()),
            Ty::Bool => Some("Boolean".into()),
            Ty::Unit => Some("Unit".into()),
            Ty::Error => Some("Error".into()),
            Ty::Pid(marker) => Some(format!("PID<{}>", self.ty_name(&marker))),
            Ty::Result(_, _) => Some("Result".into()),
            Ty::List(_) => Some("List".into()),
            Ty::Facet(..) => Some("Facet".into()),
            Ty::Tuple(items) if items.len() >= 2 => Some(format!("Tuple{}", items.len())),
            Ty::Func(_, _) => Some("Function".into()),
            Ty::Struct(name, _) | Ty::Record(name, _) => Some(name),
            Ty::Enum(name, _) => Some(name),
            _ => None,
        }
    }

    pub(super) fn trait_impl_policy_for_ty(&self, ty: &Ty) -> TraitImplPolicy {
        match self.resolve_ty(ty) {
            Ty::Func(..)
            | Ty::ExtractorClosure(..)
            | Ty::Error
            | Ty::Facet(..)
            | Ty::Lazy(..)
            | Ty::MatchResult(..)
            | Ty::Hole => TraitImplPolicy::Forbidden,
            Ty::Pid(..) => TraitImplPolicy::CompilerOwned,
            Ty::Struct(name, _) | Ty::Record(name, _) | Ty::Enum(name, _) => {
                builtin_type_name(surface_path_name(&name))
                    .map(|builtin| builtin.trait_impl_policy())
                    .unwrap_or(TraitImplPolicy::Open)
            }
            _ => TraitImplPolicy::Open,
        }
    }

    fn pid_eq_process_spec_exists(&self, marker: &Ty) -> bool {
        let Ty::ProcessMarker(name) = marker else {
            return false;
        };
        let mut matches = self
            .process_specs
            .iter()
            .filter(|spec| spec.process_name == *name);
        let Some(spec) = matches.next() else {
            return false;
        };
        matches.next().is_none()
            && matches!(
                spec.spec.instance,
                spire::ast::ProcessInstance::Singleton | spire::ast::ProcessInstance::Worker
            )
    }

    pub(super) fn trait_impl_exists_for_args(
        &mut self,
        trait_name: &str,
        trait_args: &[Ty],
        ty: &Ty,
    ) -> bool {
        self.trait_obligation_satisfied_with_args(trait_name, trait_args, ty, &mut HashSet::new())
    }

    fn trait_obligation_satisfied_with_args(
        &mut self,
        trait_name: &str,
        trait_args: &[Ty],
        ty: &Ty,
        _visiting: &mut HashSet<ObligationKey>,
    ) -> bool {
        matches!(
            self.probe_trait_head(trait_name, trait_args, ty),
            Ok(ApplicabilityProof::Satisfied(_))
        )
    }

    /// Check declared bounds (including trait inheritance) without adding a
    /// constraint to the signature variable. This is also used by parent
    /// coverage, where the child impl's where clause is temporarily supplied
    /// as a proof environment.
    pub(super) fn rigid_tyvar_entails_trait(
        &self,
        var: u32,
        requested: &str,
        visiting: &mut HashSet<String>,
    ) -> bool {
        self.tyvar_bound_names(var)
            .iter()
            .any(|bound| self.trait_bound_entails(bound, requested, visiting))
    }

    pub(super) fn trait_bound_entails(
        &self,
        bound: &str,
        requested: &str,
        visiting: &mut HashSet<String>,
    ) -> bool {
        if bound == requested {
            return true;
        }
        if !visiting.insert(bound.to_string()) {
            return false;
        }
        let entails = self.traits.get(bound).is_some_and(|trait_info| {
            trait_info.parents.iter().any(|parent| {
                self.trait_bound_entails(&self.trait_key(&parent.trait_id), requested, visiting)
            })
        });
        visiting.remove(bound);
        entails
    }

    pub(super) fn trait_dispatch_override(
        &self,
        trait_id: &ResolvedId,
        method_name: &str,
        target: &Ty,
        value_parameters: &[ResolvedValueParameter],
        params: &[Ty],
        ret_ty: &Ty,
        span: &Span,
    ) -> Result<TraitDispatchTarget, TypeError> {
        let canonical_target = self.canonical_request(target)?;
        let metadata = builtin_function_metas()
            .iter()
            .filter_map(BuiltinMeta::trait_method)
            .find(|meta| {
                self.trait_key_by_short_name(meta.trait_name)
                    .and_then(|key| self.traits.get(&key))
                    .is_some_and(|info| info.id.unique_id == trait_id.unique_id)
                    && meta.method_name == method_name
                    && (matches!(canonical_target.head, CanonicalTypeHead::Builtin(name) if meta.targets.contains(&name))
                        || matches!(canonical_target.head, CanonicalTypeHead::Facet(_))
                            && meta.targets.contains(&sindr::names::TypeName::Facet))
            })
            .ok_or_else(|| {
                TypeError::new(
                    format!(
                        "MissingCanonicalBuiltinTraitImplementation: {}::{} for {:?}",
                        self.trait_key(trait_id),
                        method_name,
                        canonical_target
                    ),
                    span.clone(),
                )
        })?;
        if !super::signatures::builtin_trait_surface_matches(
            self,
            &metadata,
            target,
            value_parameters,
            params,
            ret_ty,
        ) {
            return Err(TypeError::new(
                format!(
                    "Builtin Trait method {}::{} does not match its canonical runtime signature",
                    self.trait_key(trait_id),
                    method_name
                ),
                span.clone(),
            ));
        }
        Ok(TraitDispatchTarget::Builtin(metadata.builtin_id))
    }

    fn is_standard_eq_trait(&self, trait_name: &str) -> bool {
        self.traits.get(trait_name).is_some_and(|info| {
            info.compiler_owned_equality && self.trait_key(&info.id) == trait_name
        })
    }

    pub(super) fn compiler_trait_impl_exists(&self, trait_name: &str, ty: &Ty) -> bool {
        let ty = self.resolve_ty(ty);
        if self.is_standard_eq_trait(trait_name) {
            return match &ty {
                Ty::Pid(name) => self.pid_eq_process_spec_exists(name),
                _ => false,
            };
        }
        false
    }

    pub(super) fn compiler_trait_dispatch_target(
        &self,
        trait_name: &str,
        method_name: &str,
        target_ty: &Ty,
    ) -> Option<TraitDispatchTarget> {
        let target_ty = self.resolve_ty(target_ty);
        if self.is_standard_eq_trait(trait_name) {
            return match (method_name, &target_ty) {
                ("eq", Ty::Pid(name)) if self.pid_eq_process_spec_exists(name) => {
                    Some(TraitDispatchTarget::BinOp(BinOp::Eq))
                }
                ("neq", Ty::Pid(name)) if self.pid_eq_process_spec_exists(name) => {
                    Some(TraitDispatchTarget::BinOp(BinOp::Neq))
                }
                _ => None,
            };
        }
        None
    }

    pub(super) fn resolve_trait_method_signature(
        &mut self,
        trait_info: &TraitInfo,
        method: &TraitMethodInfo,
        self_ty: &Ty,
    ) -> Result<(Vec<Ty>, Ty, Vec<Ty>, Vec<Ty>, MethodTypeEnvironment), TypeError> {
        let mut trait_head_bindings = HashMap::new();
        for param in &trait_info.type_params {
            let fresh = self.env.fresh_tyvar();
            if let Ty::Var(var) = fresh {
                if let Some(bound) = &param.bound {
                    self.register_tyvar_bound(var, bound);
                }
            }
            trait_head_bindings.insert(param.name.clone(), fresh);
        }
        self.apply_trait_head_where_bounds(trait_info.where_clause.as_ref(), &trait_head_bindings)?;
        let mut tyvars = trait_head_bindings.clone();
        self.seed_signature_type_params(&method.type_params, &mut tyvars);
        let mut direct_constructor_inputs = super::signatures::DirectConstructorInputs::default();
        let mut return_type_arguments = Vec::new();
        for argument in &method.return_type_arguments {
            let ty = self.resolve_trait_signature_ty_in_context(
                &argument.ty,
                TypeSyntaxContext::General,
                self_ty,
                &mut tyvars,
            )?;
            super::signatures::remember_direct_constructor_input(
                self,
                &argument.ty,
                &ty,
                &mut direct_constructor_inputs,
            );
            return_type_arguments.push(ty);
        }
        let params = method
            .value_parameters
            .iter()
            .map(|param| {
                let ty = self.resolve_trait_parameter_contract(
                    &param.ty,
                    self_ty,
                    &mut tyvars,
                    trait_info.standard_lazy_contract,
                )?;
                super::signatures::remember_direct_constructor_input(
                    self,
                    &param.ty,
                    &ty,
                    &mut direct_constructor_inputs,
                );
                Ok(super::signatures::coalesce_direct_constructor_inputs(
                    self,
                    ty,
                    &direct_constructor_inputs,
                ))
            })
            .collect::<Result<Vec<_>, TypeError>>()?;
        let ret = self.resolve_trait_signature_ty_in_context(
            &method.ret_ty,
            TypeSyntaxContext::FunctionReturn,
            self_ty,
            &mut tyvars,
        )?;
        super::signatures::remember_direct_constructor_input(
            self,
            &method.ret_ty,
            &ret,
            &mut direct_constructor_inputs,
        );
        let ret = super::signatures::coalesce_direct_constructor_inputs(
            self,
            ret,
            &direct_constructor_inputs,
        );
        self.apply_typed_where_trait_bounds(
            method.where_clause.as_ref(),
            &tyvars,
            Some(self_ty),
            false,
        )?;
        for ty in &params {
            self.validate_nominal_type_well_formed(ty, &method.span, false)?;
        }
        self.validate_nominal_type_well_formed(&ret, &method.span, false)?;
        for ty in &return_type_arguments {
            self.validate_nominal_type_well_formed(ty, &method.span, false)?;
        }
        let trait_args = trait_info
            .type_params
            .iter()
            .filter_map(|param| trait_head_bindings.get(&param.name).cloned())
            .collect::<Vec<_>>();
        Ok((
            params,
            ret,
            trait_args.clone(),
            return_type_arguments,
            MethodTypeEnvironment {
                head_bindings: trait_head_bindings,
                bindings: tyvars,
                trait_arguments: trait_args,
                self_ty: self_ty.clone(),
                direct_inputs: direct_constructor_inputs,
            },
        ))
    }

    pub(super) fn expand_trait_self_apps(
        &self,
        ty: Ty,
        target_ty: &Ty,
        constructor_slot_vars: &[u32],
    ) -> Result<Ty, TypeError> {
        Ok(match ty {
            Ty::SelfApp(args) if Self::constructor_application_parts(&args).is_some() => {
                Ty::SelfApp(
                    args.into_iter()
                        .map(|arg| {
                            self.expand_trait_self_apps(arg, target_ty, constructor_slot_vars)
                        })
                        .collect::<Result<_, _>>()?,
                )
            }
            Ty::SelfApp(args) => {
                if args.len() != constructor_slot_vars.len() {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Self requires {} constructor argument(s), got {}",
                            constructor_slot_vars.len(),
                            args.len()
                        ),
                        span: Span { start: 0, end: 0 },
                        hint: None,
                    });
                }
                let mapping = constructor_slot_vars
                    .iter()
                    .copied()
                    .zip(args)
                    .collect::<HashMap<_, _>>();
                self.substitute_ty_with_mapping(target_ty, &mapping)
            }
            Ty::ExtractorClosure(inner) => Ty::ExtractorClosure(Box::new(
                self.expand_trait_self_apps(*inner, target_ty, constructor_slot_vars)?,
            )),
            Ty::MatchResult(inner) => Ty::MatchResult(Box::new(self.expand_trait_self_apps(
                *inner,
                target_ty,
                constructor_slot_vars,
            )?)),
            Ty::List(inner) => Ty::List(Box::new(self.expand_trait_self_apps(
                *inner,
                target_ty,
                constructor_slot_vars,
            )?)),
            Ty::Tuple(items) => Ty::Tuple(
                items
                    .into_iter()
                    .map(|item| self.expand_trait_self_apps(item, target_ty, constructor_slot_vars))
                    .collect::<Result<_, _>>()?,
            ),
            Ty::Func(params, ret) => Ty::Func(
                params
                    .into_iter()
                    .map(|param| {
                        self.expand_trait_self_apps(param, target_ty, constructor_slot_vars)
                    })
                    .collect::<Result<_, _>>()?,
                Box::new(self.expand_trait_self_apps(*ret, target_ty, constructor_slot_vars)?),
            ),
            Ty::Pid(inner) => Ty::Pid(Box::new(self.expand_trait_self_apps(
                *inner,
                target_ty,
                constructor_slot_vars,
            )?)),
            Ty::Lazy(inner) => Ty::Lazy(Box::new(self.expand_trait_self_apps(
                *inner,
                target_ty,
                constructor_slot_vars,
            )?)),
            Ty::Facet(kind, source, focus, update_source, update_focus) => Ty::Facet(
                kind,
                Box::new(self.expand_trait_self_apps(*source, target_ty, constructor_slot_vars)?),
                Box::new(self.expand_trait_self_apps(*focus, target_ty, constructor_slot_vars)?),
                Box::new(self.expand_trait_self_apps(
                    *update_source,
                    target_ty,
                    constructor_slot_vars,
                )?),
                Box::new(self.expand_trait_self_apps(
                    *update_focus,
                    target_ty,
                    constructor_slot_vars,
                )?),
            ),
            Ty::BuiltinFunc { name, params, ret } => Ty::BuiltinFunc {
                name,
                params: params
                    .into_iter()
                    .map(|param| {
                        self.expand_trait_self_apps(param, target_ty, constructor_slot_vars)
                    })
                    .collect::<Result<_, _>>()?,
                ret: Box::new(self.expand_trait_self_apps(
                    *ret,
                    target_ty,
                    constructor_slot_vars,
                )?),
            },
            Ty::UserFunc {
                fun_idx,
                type_params,
                call_substitution,
                params,
                ret,
            } => Ty::UserFunc {
                fun_idx,
                type_params,
                call_substitution,
                params: params
                    .into_iter()
                    .map(|param| {
                        self.expand_trait_self_apps(param, target_ty, constructor_slot_vars)
                    })
                    .collect::<Result<_, _>>()?,
                ret: Box::new(self.expand_trait_self_apps(
                    *ret,
                    target_ty,
                    constructor_slot_vars,
                )?),
            },
            Ty::Struct(name, fields) => Ty::Struct(
                name,
                NominalType::new(
                    fields
                        .arguments
                        .into_iter()
                        .map(|argument| {
                            self.expand_trait_self_apps(argument, target_ty, constructor_slot_vars)
                        })
                        .collect::<Result<_, TypeError>>()?,
                    fields
                        .fields
                        .into_iter()
                        .map(|(name, field)| {
                            Ok((
                                name,
                                self.expand_trait_self_apps(
                                    field,
                                    target_ty,
                                    constructor_slot_vars,
                                )?,
                            ))
                        })
                        .collect::<Result<_, TypeError>>()?,
                ),
            ),
            Ty::Record(name, fields) => Ty::Record(
                name,
                NominalType::new(
                    fields
                        .arguments
                        .into_iter()
                        .map(|argument| {
                            self.expand_trait_self_apps(argument, target_ty, constructor_slot_vars)
                        })
                        .collect::<Result<_, TypeError>>()?,
                    fields
                        .fields
                        .into_iter()
                        .map(|(name, field)| {
                            Ok((
                                name,
                                self.expand_trait_self_apps(
                                    field,
                                    target_ty,
                                    constructor_slot_vars,
                                )?,
                            ))
                        })
                        .collect::<Result<_, TypeError>>()?,
                ),
            ),
            Ty::Enum(name, args) => Ty::Enum(
                name,
                args.into_iter()
                    .map(|arg| self.expand_trait_self_apps(arg, target_ty, constructor_slot_vars))
                    .collect::<Result<_, _>>()?,
            ),
            Ty::Result(ok, err) => Ty::Result(
                Box::new(self.expand_trait_self_apps(*ok, target_ty, constructor_slot_vars)?),
                Box::new(self.expand_trait_self_apps(*err, target_ty, constructor_slot_vars)?),
            ),
            other => other,
        })
    }

    pub(super) fn resolve_trait_impl_method_signature(
        &mut self,
        trait_info: &TraitInfo,
        trait_args: &[AstTy],
        method: &TraitImplMethodInfo,
        target_ast_ty: &AstTy,
        fallback_ret_ty: &sigil::resolved::ResolvedSignatureTy,
        impl_where_clause: Option<&TypedWhereClause>,
        generated_derive: bool,
        constructor_slot_positions: &[usize],
    ) -> Result<(Vec<Ty>, Ty, Vec<u32>, Vec<Ty>, MethodTypeEnvironment), TypeError> {
        if trait_info.type_params.len() != trait_args.len() {
            return Err(TypeError {
                structured: None,
                message: format!(
                    "Trait {} requires {} type argument(s), got {}",
                    trait_info.id.name,
                    trait_info.type_params.len(),
                    trait_args.len()
                ),
                span: method.span.clone(),
                hint: None,
            });
        }

        let mut trait_head_bindings = HashMap::new();
        let mut tyvars = HashMap::new();
        let placeholder_self = self.env.fresh_tyvar();
        let self_ty = self.resolve_trait_signature_ast_ty_in_context(
            target_ast_ty,
            TypeSyntaxContext::General,
            &placeholder_self,
            &mut tyvars,
        )?;
        for (param, arg) in trait_info.type_params.iter().zip(trait_args.iter()) {
            let resolved = if self
                .trait_head_parameter_constructor_bound(trait_info, &param.name)
                .is_some()
                && !matches!(arg, AstTy::Named(_, name) if name.starts_with('$'))
            {
                self.resolve_type_constructor_head(arg)?
            } else {
                self.resolve_trait_signature_ast_ty_in_context(
                    arg,
                    TypeSyntaxContext::General,
                    &self_ty,
                    &mut tyvars,
                )?
            };
            trait_head_bindings.insert(param.name.clone(), resolved);
        }
        self.apply_trait_head_where_bounds(trait_info.where_clause.as_ref(), &trait_head_bindings)?;
        self.apply_typed_where_trait_bounds(
            impl_where_clause,
            &tyvars,
            Some(&self_ty),
            generated_derive,
        )?;

        let head_bindings = tyvars.clone();
        // User impl source has its own namespace. Only synthesized default
        // bodies still originate in the contract's source namespace.
        if method.display_name_override.is_some() {
            tyvars.extend(trait_head_bindings.clone());
        }
        self.seed_signature_type_params(&method.type_params, &mut tyvars);
        let mut direct_constructor_inputs = super::signatures::DirectConstructorInputs::default();
        let mut return_type_arguments = Vec::new();
        for argument in &method.return_type_arguments {
            let ty = self.resolve_trait_signature_ty_in_context(
                &argument.ty,
                TypeSyntaxContext::General,
                &self_ty,
                &mut tyvars,
            )?;
            super::signatures::remember_direct_constructor_input(
                self,
                &argument.ty,
                &ty,
                &mut direct_constructor_inputs,
            );
            return_type_arguments.push(ty);
        }
        let params = method
            .value_parameters
            .iter()
            .enumerate()
            .map(|(index, param)| {
                let allows_lazy = trait_info.standard_lazy_contract
                    && trait_info
                        .methods
                        .get(&method.method_name)
                        .and_then(|declaration| declaration.value_parameters.get(index))
                        .is_some_and(|parameter| {
                            Self::lazy_parameter_inner(parameter.ty.syntax()).is_some()
                        });
                let ty = self.resolve_trait_parameter_contract(
                    &param.ty,
                    &self_ty,
                    &mut tyvars,
                    allows_lazy,
                )?;
                super::signatures::remember_direct_constructor_input(
                    self,
                    &param.ty,
                    &ty,
                    &mut direct_constructor_inputs,
                );
                Ok(super::signatures::coalesce_direct_constructor_inputs(
                    self,
                    ty,
                    &direct_constructor_inputs,
                ))
            })
            .collect::<Result<Vec<_>, _>>()?;
        let ret_signature_source = method.ret_ty.as_ref().unwrap_or(fallback_ret_ty);
        let mut return_bindings = tyvars.clone();
        if method.ret_ty.is_none() {
            return_bindings.extend(trait_head_bindings.clone());
        }
        let ret = self.resolve_trait_signature_ty_in_context(
            ret_signature_source,
            TypeSyntaxContext::FunctionReturn,
            &self_ty,
            &mut return_bindings,
        )?;
        super::signatures::remember_direct_constructor_input(
            self,
            ret_signature_source,
            &ret,
            &mut direct_constructor_inputs,
        );
        let ret = super::signatures::coalesce_direct_constructor_inputs(
            self,
            ret,
            &direct_constructor_inputs,
        );
        self.apply_typed_where_trait_bounds(
            method.where_clause.as_ref(),
            &tyvars,
            Some(&self_ty),
            false,
        )?;
        self.apply_typed_where_trait_bounds(
            impl_where_clause,
            &tyvars,
            Some(&self_ty),
            generated_derive,
        )?;
        let slots = self.slot_vars_at_positions(
            target_ast_ty,
            &head_bindings,
            constructor_slot_positions,
            &method.span,
        )?;
        let params = params
            .into_iter()
            .map(|ty| self.expand_trait_self_apps(ty, &self_ty, &slots))
            .collect::<Result<Vec<_>, _>>()?;
        let ret = self.expand_trait_self_apps(ret, &self_ty, &slots)?;
        let return_type_arguments = return_type_arguments
            .into_iter()
            .map(|ty| self.expand_trait_self_apps(ty, &self_ty, &slots))
            .collect::<Result<Vec<_>, _>>()?;
        self.validate_nominal_type_well_formed(&self_ty, &method.span, false)?;
        for ty in &params {
            self.validate_nominal_type_well_formed(ty, &method.span, false)?;
        }
        self.validate_nominal_type_well_formed(&ret, &method.span, false)?;
        for ty in &return_type_arguments {
            self.validate_nominal_type_well_formed(ty, &method.span, false)?;
        }
        let mut type_params = Vec::new();
        for ty in tyvars.values() {
            Self::collect_ty_vars(ty, &mut type_params);
        }
        for var in method
            .type_params
            .iter()
            .filter_map(|param| match tyvars.get(&param.name) {
                Some(Ty::Var(var)) => Some(*var),
                _ => None,
            })
        {
            if !type_params.contains(&var) {
                type_params.push(var);
            }
        }
        Ok((
            params,
            ret,
            type_params,
            return_type_arguments,
            MethodTypeEnvironment {
                bindings: tyvars,
                head_bindings,
                trait_arguments: trait_info
                    .type_params
                    .iter()
                    .filter_map(|param| trait_head_bindings.get(&param.name).cloned())
                    .collect(),
                self_ty,
                direct_inputs: direct_constructor_inputs,
            },
        ))
    }

    fn validate_nominal_declaration_constructor_applications(
        &self,
        ty: &Ty,
        parameters: &HashMap<u32, (String, String)>,
        owner: &str,
        span: &Span,
    ) -> Result<(), TypeError> {
        match ty {
            Ty::SelfApp(items) => {
                if let Some((witness, slots)) = Self::constructor_application_parts(items) {
                    let Ty::Var(variable) = self.resolve_ty(witness) else {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Type constructor application in {} has no declaration parameter witness",
                                Self::surface_name(owner)
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    let Some((parameter, bound)) = parameters.get(&variable) else {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Type constructor application in {} does not refer to one of its declaration parameters",
                                Self::surface_name(owner)
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    let Some(trait_key) = self.constructor_witness_traits.get(&variable) else {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Type constructor parameter {} on {} requires a TypeCtorTrait declaration constraint; {} is not a constructor trait",
                                parameter,
                                Self::surface_name(owner),
                                self.trait_display_name(bound)
                            ),
                            span: span.clone(),
                            hint: Some(
                                "Use a declaration constraint whose Trait defines `Self: Type<...>`."
                                    .into(),
                            ),
                        });
                    };
                    let Some(trait_info) = self.traits.get(trait_key) else {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Unknown constructor Trait {} for {}",
                                self.trait_display_name(trait_key),
                                parameter
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    };
                    let expected = trait_info.constructor_slots.len();
                    if slots.len() != expected {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Type constructor parameter {} requires {} slot argument(s), got {}",
                                parameter,
                                expected,
                                slots.len()
                            ),
                            span: span.clone(),
                            hint: None,
                        });
                    }
                }
                for item in items {
                    self.validate_nominal_declaration_constructor_applications(
                        item, parameters, owner, span,
                    )?;
                }
            }
            Ty::List(inner)
            | Ty::MatchResult(inner)
            | Ty::ExtractorClosure(inner)
            | Ty::Lazy(inner)
            | Ty::Pid(inner) => self.validate_nominal_declaration_constructor_applications(
                inner, parameters, owner, span,
            )?,
            Ty::Tuple(items) => {
                for item in items {
                    self.validate_nominal_declaration_constructor_applications(
                        item, parameters, owner, span,
                    )?;
                }
            }
            Ty::Func(params, ret)
            | Ty::BuiltinFunc { params, ret, .. }
            | Ty::UserFunc { params, ret, .. } => {
                for param in params {
                    self.validate_nominal_declaration_constructor_applications(
                        param, parameters, owner, span,
                    )?;
                }
                self.validate_nominal_declaration_constructor_applications(
                    ret, parameters, owner, span,
                )?;
            }
            Ty::Facet(_, source, focus, update_source, update_focus) => {
                for item in [source, focus, update_source, update_focus] {
                    self.validate_nominal_declaration_constructor_applications(
                        item, parameters, owner, span,
                    )?;
                }
            }
            Ty::Result(ok, err) => {
                self.validate_nominal_declaration_constructor_applications(
                    ok, parameters, owner, span,
                )?;
                self.validate_nominal_declaration_constructor_applications(
                    err, parameters, owner, span,
                )?;
            }
            Ty::Enum(_, arguments) => {
                for argument in arguments {
                    self.validate_nominal_declaration_constructor_applications(
                        argument, parameters, owner, span,
                    )?;
                }
            }
            Ty::Struct(_, nominal) | Ty::Record(_, nominal) => {
                for argument in &nominal.arguments {
                    self.validate_nominal_declaration_constructor_applications(
                        argument, parameters, owner, span,
                    )?;
                }
            }
            Ty::Int
            | Ty::Float
            | Ty::Str
            | Ty::Bool
            | Ty::Unit
            | Ty::Error
            | Ty::Hole
            | Ty::Var(_)
            | Ty::ProcessMarker(_) => {}
        }
        Ok(())
    }

    pub(super) fn activate_nominal_declaration_bounds(
        &mut self,
        stmts: &[Resolved],
    ) -> Result<(), TypeError> {
        let declarations = stmts
            .iter()
            .filter_map(|stmt| match stmt {
                Resolved::StructDef(span, id, _, _, _) | Resolved::EnumDef(span, id, _, _, _) => {
                    Some((id.name.clone(), span.clone()))
                }
                _ => None,
            })
            .collect::<Vec<_>>();

        for (name, span) in declarations {
            let Some(def) = self.env.lookup_type_def(&name).cloned() else {
                continue;
            };
            let parameters = def
                .type_param_vars
                .iter()
                .copied()
                .zip(def.type_params.iter())
                .zip(def.type_param_bounds.iter())
                .filter_map(|((variable, parameter), bound)| {
                    bound
                        .as_ref()
                        .map(|bound| (variable, (parameter.clone(), bound.clone())))
                })
                .collect::<HashMap<_, _>>();
            for (variable, (_, bound)) in &parameters {
                if let Some(trait_key) = self.declaration_constructor_trait_key(bound) {
                    self.constructor_witness_traits.insert(*variable, trait_key);
                }
            }
            for (_, field) in &def.fields {
                self.validate_nominal_declaration_constructor_applications(
                    field,
                    &parameters,
                    &name,
                    &span,
                )?;
                self.validate_nominal_type_well_formed(field, &span, false)?;
            }
            if matches!(def.kind, TypeKind::Enum) {
                if let Some(variants) = self.lookup_enum_variants_of(&name).cloned() {
                    for variant in variants {
                        for payload in &variant.payload {
                            self.validate_nominal_declaration_constructor_applications(
                                payload,
                                &parameters,
                                &name,
                                &span,
                            )?;
                            self.validate_nominal_type_well_formed(payload, &span, false)?;
                        }
                    }
                }
            }
        }
        Ok(())
    }

    pub(super) fn predeclare_traits(&mut self, stmts: &[Resolved]) -> Result<(), TypeError> {
        let mut declared_trait = false;
        let mut declared_trait_impl = false;
        for stmt in stmts {
            let Resolved::TraitDef(span, id, type_params, where_clause, methods, _) = stmt else {
                continue;
            };
            declared_trait = true;
            let trait_key = self.trait_key(id);
            let constructor_slots = self.trait_constructor_slots(id, where_clause.as_ref())?;
            let parents = Self::trait_parents(where_clause.as_ref());
            let mut direct_parents = HashSet::new();
            for parent in &parents {
                let key = parent
                    .trait_id
                    .qualified_name
                    .as_deref()
                    .unwrap_or(parent.trait_id.name.as_str());
                if !direct_parents.insert(key.to_string()) {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait {} declares parent {} more than once",
                            id.name, parent.trait_id.name
                        ),
                        span: parent.trait_id.span.clone(),
                        hint: None,
                    });
                }
            }
            if !constructor_slots.is_empty() {
                for method in methods {
                    let mut return_type_argument_slots = HashSet::new();
                    for return_type_argument in &method.return_type_arguments {
                        Self::collect_constructor_signature_slots(
                            &return_type_argument.ty,
                            &mut return_type_argument_slots,
                        );
                    }
                    let mut value_param_slots = HashSet::new();
                    for param in &method.value_parameters {
                        Self::collect_constructor_signature_slots(
                            &param.ty,
                            &mut value_param_slots,
                        );
                    }
                    if let Some(slot) = return_type_argument_slots
                        .intersection(&value_param_slots)
                        .next()
                    {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Constructor trait method {} introduces {} through both ReturnTypeArguments and value arguments",
                                method.id.name, slot
                            ),
                            span: method.span.clone(),
                            hint: Some(
                                "Introduce each type variable through exactly one input channel."
                                    .into(),
                            ),
                        });
                    }
                    let mut input_slots = return_type_argument_slots;
                    input_slots.extend(value_param_slots);
                    let mut return_slots = HashSet::new();
                    Self::collect_constructor_signature_slots(&method.ret_ty, &mut return_slots);
                    if let Some(slot) = return_slots.difference(&input_slots).next() {
                        return Err(TypeError {
                            structured: None,
                            message: format!(
                                "Constructor trait method {} has {} only in its return type",
                                method.id.name, slot
                            ),
                            span: method.span.clone(),
                            hint: Some(
                                "Introduce the type variable through ReturnTypeArguments or a value argument."
                                    .into(),
                            ),
                        });
                    }
                }
            }
            let mut method_map = HashMap::new();
            for method in methods {
                if let Some(qualified_name) = &method.id.qualified_name {
                    self.trait_methods_by_qualified_name.insert(
                        qualified_name.clone(),
                        (trait_key.clone(), method.id.name.clone()),
                    );
                }
                method_map.insert(
                    method.id.name.clone(),
                    TraitMethodInfo {
                        id: method.id.clone(),
                        return_type_arguments: method.return_type_arguments.clone(),
                        type_params: method.type_params.clone(),
                        value_parameters: method.value_parameters.clone(),
                        ret_ty: method.ret_ty.clone(),
                        where_clause: method.where_clause.as_ref().map(TypedWhereClause::from),
                        attrs: method.attrs.clone(),
                        body: method.body.clone(),
                        span: method.span.clone(),
                    },
                );
            }
            let trait_info = TraitInfo {
                id: id.clone(),
                compiler_owned_failure: self.enforce_builtin_type_contracts
                    && trait_key == "MonadFail",
                compiler_owned_equality: self.enforce_builtin_type_contracts
                    && id.name == "Eq"
                    && trait_key == "Eq",
                standard_lazy_contract: self.enforce_builtin_type_contracts,
                type_params: type_params.clone(),
                where_clause: where_clause.as_ref().map(TypedWhereClause::from),
                constructor_slots,
                parents,
                methods: method_map,
            };
            self.traits.insert(trait_key, Arc::new(trait_info));

            let _ = span;
        }

        if declared_trait {
            self.resolve_trait_constraint_closure()?;

            // Trait helpers participate in the same canonical callable
            // registry as user functions and non-intrinsic builtins. Resolve
            // their signatures only after inherited constructor slots are
            // closed so parameter bounds such as `$M: Monad` retain their
            // constructor witness metadata.
            for stmt in stmts {
                let Resolved::TraitDef(_, id, ..) = stmt else {
                    continue;
                };
                let trait_key = self.trait_key(id);
                let trait_info = self
                    .traits
                    .get(&trait_key)
                    .cloned()
                    .expect("predeclared Trait must remain registered");
                for method in trait_info.methods.values() {
                    let self_ty = self.env.fresh_tyvar();
                    let (param_tys, ret, _, return_type_argument_tys, _) =
                        self.resolve_trait_method_signature(&trait_info, method, &self_ty)?;
                    self.callable_signatures.insert(
                        method.id.unique_id,
                        Arc::new(super::signatures::canonical_callable_signature(
                            self,
                            &method.id,
                            &method.return_type_arguments,
                            &method.value_parameters,
                            return_type_argument_tys.as_slice(),
                            param_tys.as_slice(),
                            ret,
                            sindr::signature::CanonicalConstraintSet::default(),
                            sindr::signature::RuntimeTarget::TraitDispatch(method.id.unique_id),
                            sindr::signature::CallableDeclarationKind::TraitMethod,
                        )?),
                    );
                }
            }
        }

        for stmt in stmts {
            let Resolved::TraitImplDef(
                span,
                declaration_id,
                trait_id,
                trait_args,
                target_ast_ty,
                where_clause,
                methods,
            ) = stmt
            else {
                continue;
            };
            declared_trait_impl = true;
            let generated_derive = is_generated_derive_impl(methods);

            let trait_key = self.trait_key(trait_id);
            let trait_info = self
                .traits
                .get(&trait_key)
                .cloned()
                .ok_or_else(|| TypeError {
                    structured: None,
                    message: format!("Unknown trait: {}", trait_id.name),
                    span: span.clone(),
                    hint: None,
                })?;
            if trait_info.type_params.len() != trait_args.len() {
                return Err(TypeError {
                    structured: None,
                    message: format!(
                        "Trait {} requires {} type argument(s), got {}",
                        trait_id.name,
                        trait_info.type_params.len(),
                        trait_args.len()
                    ),
                    span: span.clone(),
                    hint: None,
                });
            }
            let (trait_arg_tys, target_ty, type_param_vars, target_param_vars) =
                self.resolve_trait_impl_head_tys(&trait_info, trait_args, target_ast_ty)?;
            let policy = self.trait_impl_policy_for_ty(&target_ty);
            if policy != TraitImplPolicy::Open {
                let target = self.ty_name(&target_ty);
                let reason = match policy {
                    TraitImplPolicy::CompilerOwned => "reserved for compiler-owned capabilities",
                    TraitImplPolicy::Forbidden => "forbidden by the type's trait policy",
                    TraitImplPolicy::Open => unreachable!(),
                };
                return Err(TypeError::from_structured(diagnostics::StructuredDiagnostic {
                    reason: diagnostics::TypeDiagnosticReason::TraitImplementationForbidden.into(),
                    origin: diagnostics::DiagnosticOrigin::Declaration,
                    data: diagnostics::DiagnosticData::Policy(diagnostics::PolicyData {
                        policy: diagnostics::TypePolicy::TraitImplementation,
                        subject: Some(target),
                        expected_type: Some(trait_id.name.clone()),
                        actual_type: Some(reason.into()),
                        stage: Some("declaration".into()),
                        entrypoint: None,
                    }),
                    primary: diagnostics::SourceFact::untyped(
                        diagnostics::SourceRole::Impl,
                        diagnostics::SourceId(0),
                        Self::ast_ty_span(target_ast_ty).clone(),
                    ),
                    related: vec![diagnostics::SourceFact::untyped(
                        diagnostics::SourceRole::Trait,
                        diagnostics::SourceId(0),
                        trait_id.span.clone(),
                    )],
                    remediation: Some(diagnostics::Remediation::Help {
                        text: "Use a user-defined outer type for this trait implementation when appropriate.".into(),
                    }),
                }));
            }
            let typed_impl_clause = where_clause.as_ref().map(TypedWhereClause::from);
            let impl_head_bindings = target_param_vars
                .iter()
                .map(|(name, var)| (name.clone(), Ty::Var(*var)))
                .collect::<HashMap<_, _>>();
            self.apply_typed_where_trait_bounds(
                typed_impl_clause.as_ref(),
                &impl_head_bindings,
                Some(&target_ty),
                generated_derive,
            )?;
            let target_name = self.trait_target_name(&target_ty).ok_or_else(|| TypeError {
                structured: None,
                message: "trait impl target must be a concrete named type, tuple type, or function type".into(),
                span: Self::ast_ty_span(target_ast_ty).clone(),
                hint: Some("Use `impl Trait for Int` / `impl Trait for UserType` / `impl Trait for (Int, String)` / `impl Trait for ($A -> $B)`.".into()),
            })?;
            let has_constructor_parent = trait_info.parents.iter().any(|parent| {
                !self.traits[&self.trait_key(&parent.trait_id)]
                    .constructor_slots
                    .is_empty()
            });
            let (constructor_slot_vars, constructor_slot_positions) = if has_constructor_parent {
                (Vec::new(), Vec::new())
            } else {
                self.root_constructor_slot_vars_for_impl(
                    &trait_info,
                    target_ast_ty,
                    typed_impl_clause.as_ref(),
                    &target_param_vars,
                    span,
                )?
            };

            let head_environment = MethodTypeEnvironment {
                head_bindings: target_param_vars
                    .iter()
                    .map(|(name, var)| (name.clone(), Ty::Var(*var)))
                    .collect(),
                bindings: target_param_vars
                    .iter()
                    .map(|(name, var)| (name.clone(), Ty::Var(*var)))
                    .collect(),
                trait_arguments: trait_arg_tys.clone(),
                self_ty: target_ty.clone(),
                direct_inputs: super::signatures::DirectConstructorInputs::default(),
            };
            let (head_type_list, canonical_environment) =
                self.canonical_impl_head(trait_args, target_ast_ty, &head_environment, span)?;
            let impl_constraints = self
                .canonical_method_list(
                    &[],
                    &[],
                    &Ty::Unit,
                    &[],
                    &[],
                    &AstTy::Named(span.clone(), "Unit".into()),
                    typed_impl_clause.as_ref(),
                    &head_environment,
                    &canonical_environment,
                    None,
                    false,
                )?
                .where_constraints;
            let impl_key =
                CanonicalTraitImplPatternKey::from_head(trait_id.unique_id, &head_type_list);
            let existing_impls = self.trait_impls.values().cloned().collect::<Vec<_>>();
            for existing in existing_impls {
                if self.trait_key(&existing.trait_id) != trait_key {
                    continue;
                }
                if Self::canonical_patterns_overlap(&impl_key, &existing.declaration_key.pattern) {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Overlapping trait impls for {}: {} and {}",
                            trait_id.name,
                            Self::surface_ast_ty_key(target_ast_ty),
                            Self::surface_ast_ty_key(&existing.target_ast_ty)
                        ),
                        span: span.clone(),
                        hint: Some("Trait impl patterns must be structurally disjoint; Surtr does not use specialization or declaration-order dispatch.".into()),
                    });
                }
            }

            let exclusive_peer = if self.trait_matches_short_name(&trait_key, "Convert") {
                self.trait_key_by_short_name("TryConvert")
            } else if self.trait_matches_short_name(&trait_key, "TryConvert") {
                self.trait_key_by_short_name("Convert")
            } else {
                None
            };
            if let Some(peer_trait_key) = exclusive_peer {
                let peers = self
                    .trait_impls
                    .values()
                    .filter(|existing| self.trait_key(&existing.trait_id) == peer_trait_key)
                    .cloned()
                    .collect::<Vec<_>>();
                let peer = peers.into_iter().find(|existing| {
                    Self::canonical_patterns_overlap(&impl_key, &existing.declaration_key.pattern)
                });
                if let Some(existing) = peer {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "{} and {} cannot both be implemented for {} -> {}",
                            trait_id.name,
                            existing
                                .trait_id
                                .name
                                .rsplit("::")
                                .next()
                                .unwrap_or(&existing.trait_id.name),
                            Self::surface_ast_ty_key(target_ast_ty),
                            trait_args
                                .iter()
                                .map(Self::ast_ty_key)
                                .collect::<Vec<_>>()
                                .join(", ")
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
            }

            self.trait_impls.insert(
                impl_key.clone(),
                Arc::new(TraitImplInfo {
                    declaration_key: TraitImplDeclarationKey {
                        pattern: impl_key.clone(),
                        declaration_id: *declaration_id,
                    },
                    head_type_list,
                    impl_constraints,
                    method_signature_lists: HashMap::new(),
                    trait_id: trait_id.clone(),
                    trait_args: trait_args.clone(),
                    trait_arg_tys,
                    target_name,
                    target_ast_ty: target_ast_ty.clone(),
                    target_ty,
                    where_clause: where_clause.as_ref().map(TypedWhereClause::from),
                    generated_derive,
                    type_param_vars,
                    type_param_vars_by_name: target_param_vars,
                    constructor_slot_vars,
                    constructor_slot_positions,
                    methods: HashMap::new(),
                }),
            );
            self.constructor_mapping_resolution
                .pending
                .insert(impl_key.clone());
            self.index_trait_impl(impl_key);
        }

        if declared_trait_impl {
            self.resolve_impl_constructor_mappings()?;
        }

        // Methods consume the declaration's resolved mapping, never re-infer it.
        for stmt in stmts {
            let Resolved::TraitImplDef(
                span,
                declaration_id,
                trait_id,
                trait_args,
                target_ast_ty,
                where_clause,
                methods,
            ) = stmt
            else {
                continue;
            };
            let trait_key = self.trait_key(trait_id);
            let trait_info = self.traits[&trait_key].clone();
            let impl_info = self
                .trait_impls
                .values()
                .find(|info| info.declaration_key.declaration_id == *declaration_id)
                .expect("collected impl head")
                .clone();
            let generated_derive = impl_info.generated_derive;
            let target_ty = impl_info.target_ty.clone();
            let target_name = impl_info.target_name.clone();
            let trait_arg_tys = impl_info.trait_arg_tys.clone();
            let constructor_slot_vars = impl_info.constructor_slot_vars.clone();
            let constructor_slot_positions = impl_info.constructor_slot_positions.clone();
            let typed_impl_clause = impl_info.where_clause.clone();
            let head_type_list = impl_info.head_type_list.clone();
            self.validate_nominal_type_well_formed(&target_ty, span, false)?;
            for argument in &trait_arg_tys {
                self.validate_nominal_type_well_formed(argument, span, false)?;
            }
            let mut method_map = HashMap::new();
            for method in methods {
                method_map.insert(
                    method.method_name.clone(),
                    TraitImplMethodInfo {
                        method_name: method.method_name.clone(),
                        function_id: method.function_id.clone(),
                        return_type_arguments: method.return_type_arguments.clone(),
                        type_params: method.type_params.clone(),
                        value_parameters: method.value_parameters.clone(),
                        ret_ty: method.ret_ty.clone(),
                        where_clause: method.where_clause.as_ref().map(TypedWhereClause::from),
                        body: method.body.clone(),
                        attrs: method.attrs.clone(),
                        span: method.span.clone(),
                        display_name_override: None,
                        dispatch_override: None,
                        is_builtin: method.is_builtin,
                        body_obligations: Vec::new(),
                        instantiation_contract: None,
                        resolved_signature: None,
                    },
                );
            }

            let mut required_methods = trait_info.methods.iter().collect::<Vec<_>>();
            required_methods.sort_by_key(|(_, method)| method.id.unique_id);
            let mut locally_reserved_default_uids = HashSet::new();
            for (required_method, trait_method) in required_methods {
                if method_map.contains_key(required_method) {
                    continue;
                }
                let Some(default_body) = trait_method.body.clone() else {
                    if trait_method.attrs.visibility == spire::ast::Visibility::Private {
                        continue;
                    }
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait impl {} for {} is missing method `{}`",
                            trait_id.name, target_name, required_method
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                };
                method_map.insert(
                    required_method.clone(),
                    TraitImplMethodInfo {
                        method_name: required_method.clone(),
                        function_id: self.synthesized_default_method_id(
                            *declaration_id,
                            &trait_method.id,
                            &trait_method.span,
                            &locally_reserved_default_uids,
                        ),
                        return_type_arguments: trait_method.return_type_arguments.clone(),
                        type_params: trait_method.type_params.clone(),
                        value_parameters: trait_method.value_parameters.clone(),
                        ret_ty: None,
                        where_clause: trait_method.where_clause.clone(),
                        body: default_body,
                        attrs: trait_method.attrs.clone(),
                        span: trait_method.span.clone(),
                        display_name_override: Some(Self::trait_method_display_name(
                            &trait_info.id,
                            required_method,
                        )),
                        dispatch_override: None,
                        is_builtin: false,
                        body_obligations: Vec::new(),
                        instantiation_contract: None,
                        resolved_signature: None,
                    },
                );
                locally_reserved_default_uids
                    .insert(method_map[required_method].function_id.unique_id);
            }

            for method_name in method_map.keys() {
                if !trait_info.methods.contains_key(method_name) {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait impl {} for {} defines unknown method `{}`",
                            trait_id.name, target_name, method_name
                        ),
                        span: span.clone(),
                        hint: None,
                    });
                }
            }

            let mut method_signature_lists = HashMap::new();
            let mut instantiation_contracts = HashMap::new();
            let mut resolved_signatures = HashMap::new();
            let mut dispatch_overrides = HashMap::new();
            for (method_name, impl_method) in &method_map {
                let trait_method =
                    trait_info
                        .methods
                        .get(method_name)
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!(
                                "Trait impl {} for {} defines unknown method `{}`",
                                trait_id.name, target_name, method_name
                            ),
                            span: impl_method.span.clone(),
                            hint: None,
                        })?;
                if trait_method.attrs.visibility != impl_method.attrs.visibility {
                    return Err(TypeError {
                        structured: None,
                        message: format!(
                            "Trait impl method {}::{} has incompatible visibility",
                            trait_id.name, method_name
                        ),
                        span: impl_method.span.clone(),
                        hint: Some("A trait private helper must be implemented with `defp`, and a public trait method with `def`".into()),
                    });
                }

                let (
                    trait_params,
                    trait_ret,
                    trait_head_vars,
                    trait_return_type_arguments,
                    mut contract_env,
                ) = self.resolve_trait_method_signature(&trait_info, trait_method, &target_ty)?;
                let trait_head_mapping = trait_head_vars
                    .into_iter()
                    .zip(trait_arg_tys.iter().cloned())
                    .filter_map(|(from, to)| match from {
                        Ty::Var(var) => Some((var, to)),
                        _ => None,
                    })
                    .collect::<HashMap<_, _>>();
                let trait_params = trait_params
                    .into_iter()
                    .map(|param| {
                        let param = self.substitute_ty_with_mapping(&param, &trait_head_mapping);
                        self.expand_trait_self_apps(param, &target_ty, &constructor_slot_vars)
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                let trait_ret = self.substitute_ty_with_mapping(&trait_ret, &trait_head_mapping);
                let trait_ret =
                    self.expand_trait_self_apps(trait_ret, &target_ty, &constructor_slot_vars)?;
                let trait_return_type_arguments = trait_return_type_arguments
                    .into_iter()
                    .map(|param| {
                        let param = self.substitute_ty_with_mapping(&param, &trait_head_mapping);
                        self.expand_trait_self_apps(param, &target_ty, &constructor_slot_vars)
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                let (impl_params, impl_ret, impl_type_params, impl_return_type_arguments, impl_env) =
                    self.resolve_trait_impl_method_signature(
                        &trait_info,
                        trait_args,
                        impl_method,
                        target_ast_ty,
                        &trait_method.ret_ty,
                        where_clause.as_ref().map(TypedWhereClause::from).as_ref(),
                        generated_derive,
                        &constructor_slot_positions,
                    )?;
                let generated_boolean_equality = generated_derive
                    && trait_info.compiler_owned_equality
                    && matches!(
                        self.canonical_request(&target_ty)?.head,
                        CanonicalTypeHead::Builtin(sindr::names::TypeName::Boolean)
                    );
                if impl_method.is_builtin || generated_boolean_equality {
                    dispatch_overrides.insert(
                        method_name.clone(),
                        self.trait_dispatch_override(
                            &trait_info.id,
                            method_name,
                            &target_ty,
                            &impl_method.value_parameters,
                            &impl_params,
                            &impl_ret,
                            &impl_method.span,
                        )?,
                    );
                }

                for ty in contract_env.bindings.values_mut() {
                    *ty = self.substitute_ty_with_mapping(ty, &trait_head_mapping);
                    *ty = self.expand_trait_self_apps(
                        ty.clone(),
                        &target_ty,
                        &constructor_slot_vars,
                    )?;
                }
                let expected_env = self.canonical_contract_environment(
                    &contract_env,
                    &trait_info,
                    &head_type_list,
                    &constructor_slot_positions,
                )?;
                let expected = self.canonical_method_list(
                    &trait_return_type_arguments,
                    &trait_params,
                    &trait_ret,
                    &trait_method.return_type_arguments,
                    &trait_method.value_parameters,
                    &trait_method.ret_ty,
                    trait_method.where_clause.as_ref(),
                    &contract_env,
                    &expected_env,
                    None,
                    true,
                )?;
                let (actual_head, mut actual_env) =
                    self.canonical_impl_head(trait_args, target_ast_ty, &impl_env, span)?;
                actual_env.slot_positions = constructor_slot_positions.clone();
                if impl_method.display_name_override.is_some() {
                    actual_env = self.canonical_contract_environment(
                        &impl_env,
                        &trait_info,
                        &actual_head,
                        &constructor_slot_positions,
                    )?;
                }
                let return_env = if impl_method.ret_ty.is_none() {
                    Some(self.canonical_contract_environment(
                        &impl_env,
                        &trait_info,
                        &actual_head,
                        &constructor_slot_positions,
                    )?)
                } else {
                    None
                };
                let mut actual = self.canonical_method_list(
                    &impl_return_type_arguments,
                    &impl_params,
                    &impl_ret,
                    &impl_method.return_type_arguments,
                    &impl_method.value_parameters,
                    impl_method.ret_ty.as_ref().unwrap_or(&trait_method.ret_ty),
                    impl_method.where_clause.as_ref(),
                    &impl_env,
                    &actual_env,
                    return_env.as_ref(),
                    true,
                )?;
                let instantiated_impl_constraints = self
                    .canonical_method_list(
                        &[],
                        &[],
                        &Ty::Unit,
                        &[],
                        &[],
                        &AstTy::Named(span.clone(), "Unit".into()),
                        typed_impl_clause.as_ref(),
                        &impl_env,
                        &actual_env,
                        None,
                        false,
                    )?
                    .where_constraints;
                instantiation_contracts.insert(
                    method_name.clone(),
                    ImplMethodInstantiationContract {
                        head: actual_head.clone(),
                        signature: actual.clone(),
                        impl_constraints: instantiated_impl_constraints,
                    },
                );
                resolved_signatures.insert(
                    method_name.clone(),
                    ResolvedImplMethodSignature {
                        params: impl_params,
                        result: impl_ret,
                        type_params: impl_type_params,
                        return_type_arguments: impl_return_type_arguments,
                        environment: impl_env,
                    },
                );
                let mapping = self
                    .validate_trait_method_contract(
                        &head_type_list,
                        &actual_head,
                        &expected,
                        &actual,
                        method_name,
                        &trait_method.span,
                        &impl_method.span,
                        trait_method.where_clause.as_ref(),
                        impl_method.where_clause.as_ref(),
                    )
                    .map_err(|mut error| {
                        let names = self.diagnostic_ty_names(
                            &std::iter::once(&target_ty)
                                .chain(trait_arg_tys.iter())
                                .collect::<Vec<_>>(),
                        );
                        let identity = diagnostics::TraitDiagnosticIdentity {
                            trait_id: trait_key.clone(),
                            trait_arguments: names[1..].to_vec(),
                            subject_type: names[0].clone(),
                        };
                        let diagnostic = error
                            .structured
                            .as_mut()
                            .expect("contract failures are structured");
                        match &mut diagnostic.data {
                            diagnostics::DiagnosticData::TraitMethodTypeList(data) => {
                                data.identity = Some(identity)
                            }
                            diagnostics::DiagnosticData::TraitMethodConstraint(data) => {
                                data.identity = Some(identity)
                            }
                            _ => unreachable!("contract validation returns a contract diagnostic"),
                        }
                        let declaration_identity = diagnostics::DeclarationIdentity {
                            owner: trait_key.clone(),
                            name: method_name.clone(),
                        };
                        let impl_declaration = match &mut diagnostic.data {
                            diagnostics::DiagnosticData::TraitMethodTypeList(data) => {
                                &mut data.impl_declaration
                            }
                            diagnostics::DiagnosticData::TraitMethodConstraint(data) => {
                                &mut data.impl_declaration
                            }
                            _ => unreachable!("contract diagnostic"),
                        };
                        impl_declaration
                            .as_mut()
                            .expect("contract impl origin")
                            .declaration_identity = Some(declaration_identity.clone());
                        diagnostic.primary.declaration_identity = Some(declaration_identity);
                        error
                    })?;
                // Store method variables in the same namespace as the impl
                // head; do not rebuild a receiver-only mapping at a later use.
                for entry in &mut actual.entries {
                    entry.ty = entry.ty.substitute(&mapping);
                }
                for constraint in &mut actual.where_constraints.constraints {
                    constraint.subject = constraint.subject.substitute(&mapping);
                    if let CanonicalMethodBound::TypeConstructor(slots) = &mut constraint.bound {
                        for slot in slots {
                            *slot = slot.substitute(&mapping);
                        }
                    }
                }
                method_signature_lists.insert(method_name.clone(), actual);
            }

            for (name, signature) in resolved_signatures {
                method_map
                    .get_mut(&name)
                    .expect("declared method")
                    .resolved_signature = Some(signature);
            }
            for (name, contract) in instantiation_contracts {
                method_map
                    .get_mut(&name)
                    .expect("declared method")
                    .instantiation_contract = Some(contract);
            }
            for (name, dispatch) in dispatch_overrides {
                method_map
                    .get_mut(&name)
                    .expect("declared method")
                    .dispatch_override = Some(dispatch);
            }
            let impl_info = Arc::make_mut(
                self.trait_impls
                    .get_mut(&impl_info.declaration_key.pattern)
                    .expect("registered impl head"),
            );
            impl_info.methods = method_map;
            impl_info.method_signature_lists = method_signature_lists;
        }

        Ok(())
    }

    fn slot_vars_at_positions(
        &self,
        target: &AstTy,
        bindings: &HashMap<String, Ty>,
        positions: &[usize],
        span: &Span,
    ) -> Result<Vec<u32>, TypeError> {
        let mut vars = Vec::new();
        for position in positions {
            let argument = match target {
                AstTy::Generic(_, _, args) => args.get(*position),
                _ => None,
            };
            let Some(AstTy::Named(_, name)) = argument else {
                return Err(TypeError::new(
                    "Inherited constructor slot must remain a top-level type parameter of the impl target",
                    span.clone(),
                ));
            };
            let Some(Ty::Var(var)) = bindings.get(name) else {
                return Err(TypeError::new(
                    "Inherited constructor slot must remain a top-level type parameter of the impl target",
                    span.clone(),
                ));
            };
            if vars.contains(var) {
                return Err(TypeError::new(
                    format!(
                        "Impl target parameter {name} is mapped to more than one constructor slot"
                    ),
                    span.clone(),
                ));
            }
            vars.push(*var);
        }
        Ok(vars)
    }

    fn resolve_impl_constructor_mappings(&mut self) -> Result<(), TypeError> {
        let mut keys = self
            .constructor_mapping_resolution
            .pending
            .iter()
            .cloned()
            .collect::<Vec<_>>();
        keys.sort_by_key(|key| self.trait_impls[key].declaration_key.declaration_id);
        let result = (|| {
            for key in keys {
                self.resolve_impl_constructor_mapping(&key)?;
            }
            if !self.constructor_mapping_resolution.pending.is_empty()
                || self
                    .constructor_mapping_resolution
                    .requests
                    .borrow()
                    .is_some()
            {
                return Err(TypeError::new(
                    "Internal error: unfinished impl mapping resolution",
                    Span { start: 0, end: 0 },
                ));
            }
            Ok(())
        })();
        // Declaration dependency state never escapes into body checking or a checkpoint.
        self.constructor_mapping_resolution = ConstructorMappingResolution::default();
        result
    }

    fn parent_coverage_with_resolved_mappings(
        &mut self,
        parent: &TraitImplInfo,
        child: &TraitImplInfo,
    ) -> Result<ParentImplCoverage, TypeError> {
        loop {
            assert!(self
                .constructor_mapping_resolution
                .requests
                .borrow()
                .is_none());
            *self.constructor_mapping_resolution.requests.borrow_mut() = Some(HashSet::new());
            let result = self.parent_impl_covers_child(parent, child);
            let requests = self
                .constructor_mapping_resolution
                .requests
                .borrow_mut()
                .take()
                .expect("declaration proof frame");
            if requests.is_empty() {
                return result;
            }
            // Even a successful trial may have used a pending projection during
            // canonicalization. Discard every trial result which requested metadata.
            let mut requests = requests.into_iter().collect::<Vec<_>>();
            requests.sort_by_key(|key| self.trait_impls[key].declaration_key.declaration_id);
            for key in requests {
                self.resolve_impl_constructor_mapping(&key)?;
            }
        }
    }

    fn resolve_impl_constructor_mapping(&mut self, key: &TraitImplKey) -> Result<(), TypeError> {
        if !self.constructor_mapping_resolution.pending.contains(key) {
            return Ok(());
        }
        let child = self.trait_impls[key].clone();
        if !self
            .constructor_mapping_resolution
            .resolving
            .insert(key.clone())
        {
            return Err(TypeError::new(
                format!(
                    "Constructor slot mapping dependency cycle for {}",
                    child.trait_id.name
                ),
                child.trait_id.span.clone(),
            ));
        }
        let trait_info = self.traits[&self.trait_key(&child.trait_id)].clone();
        let mut inherited: Option<Vec<usize>> = None;
        for parent in &trait_info.parents {
            let parent_key = self.trait_key(&parent.trait_id);
            let parent_info = self
                .traits
                .get(&parent_key)
                .ok_or_else(|| {
                    TypeError::new(
                        format!("Unknown parent trait: {}", parent.trait_id.name),
                        parent.trait_id.span.clone(),
                    )
                })?
                .clone();
            let mut candidates = self.trait_impl_candidate_keys(&parent_key);
            candidates.sort_by_key(|key| self.trait_impls[key].declaration_key.declaration_id);
            let mut covered = false;
            let mut head_covered = false;
            for candidate_key in candidates {
                let candidate = self.trait_impls[&candidate_key].clone();
                match self.parent_coverage_with_resolved_mappings(&candidate, &child)? {
                    ParentImplCoverage::HeadMismatch => continue,
                    ParentImplCoverage::ConstraintMismatch => {
                        head_covered = true;
                        continue;
                    }
                    ParentImplCoverage::Covers => {}
                }
                covered = true;
                self.resolve_impl_constructor_mapping(&candidate_key)?;
                if parent_info.constructor_slots.is_empty() {
                    continue;
                }
                let positions = self.trait_impls[&candidate_key]
                    .constructor_slot_positions
                    .clone();
                if let Some(previous) = &inherited {
                    if previous != &positions {
                        return Err(TypeError::new(
                            format!("Trait impl {} for {} has conflicting inherited constructor slot mappings from parent {}",
                                child.trait_id.name, child.target_name, parent.trait_id.name),
                            child.trait_id.span.clone(),
                        ));
                    }
                } else {
                    inherited = Some(positions);
                }
            }
            if !covered {
                let message = if head_covered {
                    format!(
                        "Trait impl {} for {} cannot prove parent constraint(s) of {}",
                        child.trait_id.name, child.target_name, parent.trait_id.name
                    )
                } else {
                    format!(
                        "Trait impl {} for {} requires parent impl {} for the same target",
                        child.trait_id.name, child.target_name, parent.trait_id.name
                    )
                };
                return Err(TypeError::new(message, child.trait_id.span.clone()));
            }
        }
        if let Some(positions) = inherited {
            let bindings = child
                .type_param_vars_by_name
                .iter()
                .map(|(name, var)| (name.clone(), Ty::Var(*var)))
                .collect();
            let vars = self.slot_vars_at_positions(
                &child.target_ast_ty,
                &bindings,
                &positions,
                &child.trait_id.span,
            )?;
            let (_, confirmations) = self.explicit_constructor_slot_vars_for_impl(
                &trait_info,
                &child.target_ast_ty,
                child.where_clause.as_ref(),
                &child.type_param_vars_by_name,
                &child.trait_id.span,
                false,
            )?;
            if confirmations
                .iter()
                .zip(&positions)
                .any(|(explicit, inherited)| {
                    explicit.is_some_and(|explicit| explicit != *inherited)
                })
            {
                return Err(TypeError::new(
                    format!("Trait impl {} for {} must use the same constructor slot mapping as its parent",
                        child.trait_id.name, child.target_name),
                    child.trait_id.span.clone(),
                ));
            }
            let info = Arc::make_mut(self.trait_impls.get_mut(key).expect("collected impl"));
            info.constructor_slot_vars = vars;
            info.constructor_slot_positions = positions;
        }
        self.constructor_mapping_resolution.resolving.remove(key);
        self.constructor_mapping_resolution.pending.remove(key);
        Ok(())
    }

    /// Parent-trait validation is universal: every instance described by the
    /// child head (under the child's declared bounds) must be described by a
    /// single parent impl.  It is not the existential overlap test used for
    /// coherence.
    fn parent_impl_covers_child(
        &mut self,
        parent_impl: &TraitImplInfo,
        child_impl: &TraitImplInfo,
    ) -> Result<ParentImplCoverage, TypeError> {
        let before_substitutions = self.substitutions.clone();
        let before_rigid = self.rigid_tyvars.clone();
        let before_bounds = self.tyvar_bounds.clone();
        let before_witnesses = self.constructor_witness_traits.clone();
        let mut child_vars = Vec::new();
        Self::collect_ty_vars(&child_impl.target_ty, &mut child_vars);
        for arg in &child_impl.trait_arg_tys {
            Self::collect_ty_vars(arg, &mut child_vars);
        }
        self.rigid_tyvars.extend(child_vars);
        // Coverage is quantified over the child impl's instances. Its where
        // clause is therefore an assumption available while proving the
        // parent's requirements, but must not escape into the checker-wide
        // declaration environment.
        let mut fresh = HashMap::new();
        let parent_target = self.instantiate_ty_with_fresh(&parent_impl.target_ty, &mut fresh);
        // A declaration constraint `Self: Parent` names the Parent capability
        // family, not a zero-argument Parent instance. Instantiate the full
        // parent head so its variables remain available to its where clause,
        // but coverage is determined by the target and declared obligations.
        for arg in &parent_impl.trait_arg_tys {
            self.instantiate_ty_with_fresh(arg, &mut fresh);
        }
        let obligations_hold = (|| {
            // Head coverage is structural. Bounds are proved separately below,
            // rather than making a missing bound look like a head mismatch.
            let Some(mapping) =
                self.parent_head_substitution(&parent_target, &child_impl.target_ty, &fresh)?
            else {
                return Ok(ParentImplCoverage::HeadMismatch);
            };
            self.substitutions.extend(mapping);
            if self.parent_where_is_entailed_by_child(parent_impl, child_impl, &fresh)? {
                Ok(ParentImplCoverage::Covers)
            } else {
                Ok(ParentImplCoverage::ConstraintMismatch)
            }
        })();

        self.substitutions = before_substitutions;
        self.rigid_tyvars = before_rigid;
        self.tyvar_bounds = before_bounds;
        self.constructor_witness_traits = before_witnesses;
        obligations_hold
    }

    /// Prove a parent's `where` requirements from the child's declared
    /// assumptions.  This is deliberately a local proof environment: unlike
    /// the old implementation it never writes assumptions into
    /// `tyvar_bounds`, where they could accidentally affect another impl.
    fn parent_where_is_entailed_by_child(
        &mut self,
        parent_impl: &TraitImplInfo,
        child_impl: &TraitImplInfo,
        fresh: &HashMap<u32, Ty>,
    ) -> Result<bool, TypeError> {
        let Some(parent_where) = &parent_impl.where_clause else {
            return Ok(true);
        };

        for constraint in &parent_where.constraints {
            let parent_subject =
                match &constraint.subject {
                    AstTy::Named(_, subject) if subject == "Self" => Some(self.resolve_ty(
                        &self.substitute_ty_with_mapping(&parent_impl.target_ty, fresh),
                    )),
                    AstTy::Named(_, subject) => parent_impl
                        .type_param_vars_by_name
                        .get(subject)
                        .and_then(|var| fresh.get(var))
                        .map(|ty| self.resolve_ty(ty)),
                    _ => None,
                };
            let Some(parent_subject) = parent_subject else {
                return Ok(false);
            };

            for bound in &constraint.bounds {
                let TypedWhereConstraintRhs::Trait { trait_id } = bound else {
                    continue;
                };
                let required = self.trait_key(trait_id);
                if !self.child_where_entails(child_impl, &parent_subject, &required)
                    && !matches!(
                        self.probe_trait_head(&required, &[], &parent_subject)?,
                        ApplicabilityProof::Satisfied(_)
                    )
                {
                    return Ok(false);
                }
            }
        }
        Ok(true)
    }

    fn child_where_entails(
        &mut self,
        child_impl: &TraitImplInfo,
        subject: &Ty,
        required: &str,
    ) -> bool {
        let Some(child_where) = &child_impl.where_clause else {
            return false;
        };
        child_where.constraints.iter().any(|constraint| {
            let child_subject = match &constraint.subject {
                AstTy::Named(_, name) if name == "Self" => child_impl.target_ty.clone(),
                AstTy::Named(_, name) => match child_impl.type_param_vars_by_name.get(name) {
                    Some(var) => Ty::Var(*var),
                    None => return false,
                },
                _ => return false,
            };
            self.resolve_ty(&child_subject) == self.resolve_ty(subject)
                && constraint.bounds.iter().any(|bound| match bound {
                    TypedWhereConstraintRhs::Trait { trait_id } => {
                        self.trait_key(trait_id) == required
                    }
                    _ => false,
                })
        })
    }

    pub(super) fn predeclare_functions(&mut self, stmts: &[Resolved]) -> Result<(), TypeError> {
        let mut fun_idx = self.env.next_fun_idx;
        let mut trait_impl_keys_in_stmts = HashSet::new();

        for stmt in stmts {
            let Resolved::TraitImplDef(
                span,
                declaration_id,
                trait_id,
                trait_args,
                target_ast_ty,
                _,
                _,
            ) = stmt
            else {
                continue;
            };
            let trait_key = self.trait_key(trait_id);
            let trait_info = self
                .traits
                .get(&trait_key)
                .cloned()
                .ok_or_else(|| TypeError {
                    structured: None,
                    message: format!("Unknown trait: {}", trait_id.name),
                    span: span.clone(),
                    hint: None,
                })?;
            let (_, target_ty, _, _) =
                self.resolve_trait_impl_head_tys(&trait_info, trait_args, target_ast_ty)?;
            self.trait_target_name(&target_ty)
                .ok_or_else(|| {
                    TypeError {
                structured: None,
                message:
                    "trait impl target must be a concrete named type, tuple type, or function type"
                        .into(),
                span: Self::ast_ty_span(target_ast_ty).clone(),
                hint: None,
            }
                })?;
            trait_impl_keys_in_stmts.insert(*declaration_id);
        }

        for stmt in stmts {
            match stmt {
                Resolved::BuiltinDecl(
                    _,
                    id,
                    return_type_arguments,
                    params,
                    ret_ty,
                    where_clause,
                    _,
                ) => {
                    if Self::is_compiler_flow_operator_decl(id) {
                        if !super::signatures::builtin_surface_matches(
                            id,
                            return_type_arguments,
                            params,
                            ret_ty.as_ref(),
                            where_clause.as_ref(),
                        ) {
                            return Err(TypeError::new(
                                format!(
                                    "Builtin {} does not match its canonical surface signature",
                                    id.name
                                ),
                                id.span.clone(),
                            ));
                        }
                        continue;
                    }
                    let declared_name = id.name.rsplit("::").next().unwrap_or(&id.name);
                    let runtime_name = sindr::builtin::builtin_runtime_name(
                        declared_name,
                        id.qualified_name.as_deref(),
                    );
                    let meta = sindr::builtin::builtin_meta_by_runtime_name(runtime_name);
                    let is_special_form = Self::is_special_form_builtin_decl_name(declared_name);
                    if !is_special_form
                        && (meta.is_none()
                            || super::signatures::builtin_surface_signature(id).is_none())
                    {
                        return Err(TypeError {
                            structured: None,
                            message: format!("Unknown builtin declaration: {}", id.name),
                            span: id.span.clone(),
                            hint: Some(
                                "Declare the builtin owner and runtime mapping in BUILTIN_METAS before using @builtin."
                                    .into(),
                            ),
                        });
                    }
                    self.register_function_id(id);
                    let mut tyvars = HashMap::new();
                    let return_type_argument_tys = return_type_arguments
                        .iter()
                        .map(|argument| {
                            self.resolve_builtin_signature_ty_in_context(
                                &argument.ty,
                                TypeSyntaxContext::General,
                                &mut tyvars,
                            )
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let param_tys = params
                        .iter()
                        .enumerate()
                        .map(|(_index, param)| {
                            self.resolve_builtin_signature_ty_in_context(
                                &param.ty,
                                TypeSyntaxContext::StdBuiltinParameter,
                                &mut tyvars,
                            )
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let ret = match ret_ty {
                        Some(ty) => self.resolve_builtin_signature_ty_in_context(
                            ty,
                            TypeSyntaxContext::FunctionReturn,
                            &mut tyvars,
                        )?,
                        None => Ty::Unit,
                    };
                    let canonical_where_constraints =
                        super::signatures::canonical_where_constraints(
                            self,
                            where_clause.as_ref(),
                            &mut tyvars,
                        )?;
                    super::signatures::validate_boolean_function_suffix(self, id, &ret)?;
                    if let Some(meta) = meta {
                        self.callable_signatures.insert(
                            id.unique_id,
                            Arc::new(super::signatures::canonical_callable_signature(
                                self,
                                id,
                                return_type_arguments,
                                params,
                                return_type_argument_tys.as_slice(),
                                param_tys.as_slice(),
                                ret.clone(),
                                canonical_where_constraints,
                                sindr::signature::RuntimeTarget::Builtin(meta.builtin_id()),
                                sindr::signature::CallableDeclarationKind::Builtin,
                            )?),
                        );
                    }
                    self.env.bind_var(
                        id.unique_id,
                        Ty::BuiltinFunc {
                            name: sindr::builtin::builtin_runtime_name(
                                declared_name,
                                id.qualified_name.as_deref(),
                            )
                            .into(),
                            params: param_tys,
                            ret: Box::new(ret),
                        },
                    );
                }
                Resolved::BuiltinExtractorDecl(_, id, param, ret_ty, _) => {
                    self.register_function_id(id);
                    let mut tyvars = HashMap::new();
                    let param_tys = param
                        .iter()
                        .map(|param| match &param.ty {
                            Some(ty) => self.resolve_builtin_ast_ty_in_context(
                                ty,
                                TypeSyntaxContext::General,
                                &mut tyvars,
                            ),
                            None => Ok(self.env.fresh_tyvar()),
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let target_param = param.last().ok_or_else(|| {
                        TypeError::new("Extractor requires at least one input", id.span.clone())
                    })?;
                    let target_span = target_param
                        .ty
                        .as_ref()
                        .map(Self::ast_ty_span)
                        .unwrap_or(&target_param.id.span);
                    self.require_concrete_extractor_target_head(
                        param_tys
                            .last()
                            .expect("non-empty Extractor parameter types"),
                        target_span,
                        &id.name,
                    )?;
                    let ret = self.resolve_builtin_ast_ty_in_context(
                        ret_ty,
                        TypeSyntaxContext::ExtractorReturn,
                        &mut tyvars,
                    )?;
                    self.env.bind_var(
                        id.unique_id,
                        Ty::BuiltinFunc {
                            name: id.name.clone(),
                            params: param_tys,
                            ret: Box::new(ret),
                        },
                    );
                }
                Resolved::Def(
                    _,
                    id,
                    return_type_arguments,
                    params,
                    ret_ty,
                    where_clause,
                    _,
                    _attrs,
                ) => {
                    self.validate_standard_lazy_function_decl(&id.span, id, params, ret_ty)?;
                    self.register_function_id(id);
                    let lazy_parameters = params
                        .iter()
                        .enumerate()
                        .filter_map(|(ordinal, parameter)| {
                            Self::lazy_parameter_inner(parameter.ty.syntax())
                                .is_some()
                                .then_some(ordinal)
                        })
                        .collect::<Vec<_>>();
                    if self.enforce_builtin_type_contracts && !lazy_parameters.is_empty() {
                        self.lazy_function_parameters
                            .insert(id.unique_id, lazy_parameters);
                    }
                    let mut tyvars = HashMap::new();
                    let mut direct_constructor_inputs =
                        super::signatures::DirectConstructorInputs::default();
                    let mut return_type_argument_tys = Vec::new();
                    for argument in return_type_arguments {
                        let ty = self.resolve_def_signature_ast_ty_in_context(
                            id,
                            &argument.ty,
                            TypeSyntaxContext::General,
                            &mut tyvars,
                        )?;
                        super::signatures::remember_direct_constructor_input(
                            self,
                            &argument.ty,
                            &ty,
                            &mut direct_constructor_inputs,
                        );
                        return_type_argument_tys.push(ty);
                    }
                    let param_tys = params
                        .iter()
                        .map(|param| {
                            let param_ty =
                                self.resolve_def_parameter_contract(id, &param.ty, &mut tyvars)?;
                            super::signatures::remember_direct_constructor_input(
                                self,
                                &param.ty,
                                &param_ty,
                                &mut direct_constructor_inputs,
                            );
                            let param_ty = super::signatures::coalesce_direct_constructor_inputs(
                                self,
                                param_ty,
                                &direct_constructor_inputs,
                            );
                            Ok(param_ty)
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let param_names = params
                        .iter()
                        .map(|param| param.id.name.clone())
                        .collect::<Vec<_>>();
                    let ret = match ret_ty {
                        Some(ty) => self.resolve_def_signature_ast_ty_in_context(
                            id,
                            ty,
                            TypeSyntaxContext::FunctionReturn,
                            &mut tyvars,
                        )?,
                        None => Ty::Unit,
                    };
                    if let Some(ret_ty) = ret_ty {
                        super::signatures::remember_direct_constructor_input(
                            self,
                            ret_ty,
                            &ret,
                            &mut direct_constructor_inputs,
                        );
                    }
                    let ret = super::signatures::coalesce_direct_constructor_inputs(
                        self,
                        ret,
                        &direct_constructor_inputs,
                    );
                    self.apply_resolved_where_trait_bounds(where_clause.as_ref(), &tyvars, None)?;
                    for (argument, ty) in
                        return_type_arguments.iter().zip(&return_type_argument_tys)
                    {
                        self.validate_nominal_type_well_formed(
                            ty,
                            Self::ast_ty_span(argument.ty.syntax()),
                            false,
                        )?;
                    }
                    for (parameter, ty) in params.iter().zip(&param_tys) {
                        self.validate_nominal_type_well_formed(
                            ty,
                            Self::ast_ty_span(parameter.ty.syntax()),
                            false,
                        )?;
                    }
                    if let Some(return_annotation) = ret_ty {
                        self.validate_nominal_type_well_formed(
                            &ret,
                            Self::ast_ty_span(return_annotation.syntax()),
                            false,
                        )?;
                    }
                    let canonical_where_constraints =
                        super::signatures::canonical_where_constraints(
                            self,
                            where_clause.as_ref(),
                            &mut tyvars,
                        )?;
                    let function_symbol = id.qualified_name.as_deref().unwrap_or(&id.name);
                    if self.ty_contains_process_init(&ret)
                        && !self.is_lazy_init_function_symbol(function_symbol)
                    {
                        return Err(TypeError {
                            structured: None,
                            message: "StandbyInit<T> is only allowed as Standby @init return type"
                                .into(),
                            span: ret_ty
                                .as_ref()
                                .map(|ty| Self::ast_ty_span(ty.syntax()))
                                .cloned()
                                .unwrap_or_else(|| id.span.clone()),
                            hint: None,
                        });
                    }
                    let type_params =
                        Self::signature_type_param_vars(&[], &tyvars, &param_tys, &ret);
                    self.env.bind_var(
                        id.unique_id,
                        Ty::UserFunc {
                            fun_idx,
                            type_params,
                            call_substitution: Vec::new(),
                            params: param_tys.clone(),
                            ret: Box::new(ret.clone()),
                        },
                    );
                    self.callable_signatures.insert(
                        id.unique_id,
                        Arc::new(super::signatures::canonical_callable_signature(
                            self,
                            id,
                            return_type_arguments,
                            params,
                            return_type_argument_tys.as_slice(),
                            param_tys.as_slice(),
                            ret,
                            canonical_where_constraints,
                            sindr::signature::RuntimeTarget::UserFunction(fun_idx),
                            sindr::signature::CallableDeclarationKind::Function,
                        )?),
                    );
                    self.user_func_params.insert(id.unique_id, param_names);
                    if let Some(qualified_name) = id.qualified_name.as_ref() {
                        if Self::split_impl_method_name(qualified_name).is_some() {
                            self.impl_method_uids
                                .insert(qualified_name.clone(), id.unique_id);
                        }
                    }
                    fun_idx += 1;
                }
                Resolved::ExtractorDef(span, id, type_params, param, ret_ty, _, _) => {
                    self.register_function_id(id);
                    let mut tyvars = HashMap::new();
                    self.seed_signature_type_params(type_params, &mut tyvars);
                    let param_tys = param
                        .iter()
                        .map(|param| match &param.ty {
                            Some(ty) => self.resolve_signature_ast_ty_in_context(
                                ty,
                                TypeSyntaxContext::General,
                                &mut tyvars,
                            ),
                            None => Ok(self.env.fresh_tyvar()),
                        })
                        .collect::<Result<Vec<_>, _>>()?;
                    let target_param = param.last().ok_or_else(|| {
                        TypeError::new("Extractor requires at least one input", span.clone())
                    })?;
                    let target_span = target_param
                        .ty
                        .as_ref()
                        .map(Self::ast_ty_span)
                        .unwrap_or(&target_param.id.span);
                    self.require_concrete_extractor_target_head(
                        param_tys
                            .last()
                            .expect("non-empty Extractor parameter types"),
                        target_span,
                        &id.name,
                    )?;
                    let ret = self.resolve_signature_ast_ty_in_context(
                        ret_ty,
                        TypeSyntaxContext::ExtractorReturn,
                        &mut tyvars,
                    )?;
                    for param_ty in &param_tys {
                        self.validate_nominal_type_well_formed(param_ty, span, false)?;
                    }
                    self.validate_nominal_type_well_formed(&ret, span, false)?;
                    let type_params =
                        Self::signature_type_param_vars(type_params, &tyvars, &param_tys, &ret);
                    self.env.bind_var(
                        id.unique_id,
                        Ty::UserFunc {
                            fun_idx,
                            type_params,
                            call_substitution: Vec::new(),
                            params: param_tys,
                            ret: Box::new(ret),
                        },
                    );
                    fun_idx += 1;
                }
                Resolved::DeferrorDef(span, id, _, body) => {
                    self.register_function_id(id);
                    let Resolved::Closure(_, params, _, _) = body.as_ref() else {
                        return Err(TypeError::new(
                            "deferror body must be a constructor block",
                            span.clone(),
                        ));
                    };
                    let inputs = params
                        .iter()
                        .map(|param| {
                            let ty = param.ty.as_ref().ok_or_else(|| {
                                TypeError::new(
                                    "deferror constructor inputs require type annotations",
                                    param.id.span.clone(),
                                )
                            })?;
                            Ok((
                                param.id.name.clone(),
                                self.resolve_ast_ty_in_context(ty, TypeSyntaxContext::General)?,
                            ))
                        })
                        .collect::<Result<Vec<_>, TypeError>>()?;
                    let param_tys = inputs.iter().map(|(_, ty)| ty.clone()).collect();
                    self.env
                        .error_constructor_inputs
                        .insert(id.unique_id, inputs);

                    self.env.bind_var(
                        id.unique_id,
                        Ty::UserFunc {
                            fun_idx,
                            type_params: Vec::new(),
                            call_substitution: Vec::new(),
                            params: param_tys,
                            ret: Box::new(Ty::Error),
                        },
                    );
                    self.env.register_error_constructor(id.unique_id);
                    fun_idx += 1;
                }
                Resolved::BuiltinTypeDecl(_, _, _, _) => {}
                _ => {}
            }
        }

        if trait_impl_keys_in_stmts.is_empty() {
            self.env.next_fun_idx = fun_idx;
            return Ok(());
        }
        let mut trait_impls = self.trait_impls.values().cloned().collect::<Vec<_>>();
        trait_impls.sort_by_key(|info| info.declaration_key.declaration_id);

        for trait_impl in trait_impls {
            if !trait_impl_keys_in_stmts.contains(&trait_impl.declaration_key.declaration_id) {
                continue;
            }
            let trait_key = self.trait_key(&trait_impl.trait_id);
            let trait_info = self
                .traits
                .get(&trait_key)
                .cloned()
                .ok_or_else(|| TypeError {
                    structured: None,
                    message: format!("Unknown trait: {}", trait_impl.trait_id.name),
                    span: trait_impl.trait_id.span.clone(),
                    hint: None,
                })?;
            let mut methods = trait_impl.methods.iter().collect::<Vec<_>>();
            methods.sort_by_key(|(_, method)| method.function_id.unique_id);

            for (method_name, method) in methods {
                if method.is_builtin {
                    continue;
                }
                self.register_function_id(&method.function_id);
                let trait_method =
                    trait_info
                        .methods
                        .get(method_name)
                        .ok_or_else(|| TypeError {
                            structured: None,
                            message: format!(
                                "Unknown trait method: {}::{}",
                                trait_impl.trait_id.name, method_name
                            ),
                            span: method.span.clone(),
                            hint: None,
                        })?;
                let (param_tys, ret, type_params, return_type_argument_tys, _) = self
                    .resolve_trait_impl_method_signature(
                        &trait_info,
                        &trait_impl.trait_args,
                        method,
                        &trait_impl.target_ast_ty,
                        &trait_method.ret_ty,
                        trait_impl.where_clause.as_ref(),
                        trait_impl.generated_derive,
                        &trait_impl.constructor_slot_positions,
                    )?;
                let param_names = method
                    .value_parameters
                    .iter()
                    .map(|param| param.id.name.clone())
                    .collect::<Vec<_>>();
                self.env.bind_var(
                    method.function_id.unique_id,
                    Ty::UserFunc {
                        fun_idx,
                        type_params,
                        call_substitution: Vec::new(),
                        params: param_tys.clone(),
                        ret: Box::new(ret.clone()),
                    },
                );
                self.user_func_params
                    .insert(method.function_id.unique_id, param_names);
                self.callable_signatures.insert(
                    method.function_id.unique_id,
                    Arc::new(super::signatures::canonical_callable_signature(
                        self,
                        &method.function_id,
                        &method.return_type_arguments,
                        &method.value_parameters,
                        return_type_argument_tys.as_slice(),
                        param_tys.as_slice(),
                        ret.clone(),
                        sindr::signature::CanonicalConstraintSet::default(),
                        sindr::signature::RuntimeTarget::TraitDispatch(
                            method.function_id.unique_id,
                        ),
                        sindr::signature::CallableDeclarationKind::TraitMethod,
                    )?),
                );
                if let Some(qualified_name) = method.function_id.qualified_name.as_ref() {
                    if Self::split_impl_method_name(qualified_name).is_some() {
                        self.impl_method_uids
                            .insert(qualified_name.clone(), method.function_id.unique_id);
                    }
                }
                fun_idx += 1;
            }
        }

        self.env.next_fun_idx = fun_idx;
        Ok(())
    }
}

#[cfg(test)]
mod shared_registry_tests {
    use super::*;

    fn resolve(source: &str) -> Vec<Resolved> {
        let ast = spire::parse_with_context(source, spire::ParserContext::project(0)).unwrap();
        crate::test_support::resolve_ast_with_builtin_prelude(ast).unwrap()
    }

    #[test]
    fn inherited_slots_detach_only_changed_traits_from_saved_branches() {
        let source = "deftrait CowRoot where Self: Type<$A> {}\ndeftrait CowChild where Self: CowRoot {}\ndeftrait CowPlain {}";
        let mut parent = Checker::with_persistent_state(
            crate::test_support::session_from_cached_std_prelude().state,
            TypecheckContext::default(),
        );
        parent.check_program(resolve(source)).unwrap();
        let child_key = parent.trait_key_by_short_name("CowChild").unwrap();
        let root_key = parent.trait_key_by_short_name("CowRoot").unwrap();
        let plain_key = parent.trait_key_by_short_name("CowPlain").unwrap();
        assert_eq!(parent.traits[&child_key].constructor_slots, vec!["$A"]);
        assert_eq!(
            bincode::serialize(&parent.traits[&child_key]).unwrap(),
            bincode::serialize(parent.traits[&child_key].as_ref()).unwrap(),
        );
        // Model the declaration state before inherited slots are resolved.
        Arc::make_mut(parent.traits.get_mut(&child_key).unwrap())
            .constructor_slots
            .clear();
        let checkpoint = parent
            .persistent_state_with_env(parent.env.clone())
            .checkpoint(Vec::new());
        let sibling = parent.spawn_child_checker(parent.env.clone());
        let mut child = parent.spawn_child_checker(parent.env.clone());
        assert!(Arc::ptr_eq(
            &parent.traits[&child_key],
            &child.traits[&child_key]
        ));

        child.resolve_trait_constraint_closure().unwrap();
        assert_eq!(child.traits[&child_key].constructor_slots, vec!["$A"]);
        assert!(parent.traits[&child_key].constructor_slots.is_empty());
        assert!(sibling.traits[&child_key].constructor_slots.is_empty());
        assert!(checkpoint.traits[&child_key].constructor_slots.is_empty());
        assert!(!Arc::ptr_eq(
            &parent.traits[&child_key],
            &child.traits[&child_key]
        ));
        for unchanged in [&root_key, &plain_key] {
            assert!(Arc::ptr_eq(
                &parent.traits[unchanged],
                &child.traits[unchanged]
            ));
        }
        let resolved_child = child.traits[&child_key].clone();
        child.resolve_trait_constraint_closure().unwrap();
        assert!(Arc::ptr_eq(&resolved_child, &child.traits[&child_key]));

        let bytes = bincode::serialize(&checkpoint).unwrap();
        let restored: ScarCheckpoint = bincode::deserialize(&bytes).unwrap();
        let mut restored =
            Checker::with_persistent_state(restored.into(), TypecheckContext::default());
        restored.resolve_trait_constraint_closure().unwrap();
        assert_eq!(restored.traits[&child_key].constructor_slots, vec!["$A"]);
        assert!(checkpoint.traits[&child_key].constructor_slots.is_empty());
    }

    #[test]
    fn shared_callable_signatures_keep_instantiations_and_failed_sessions_independent() {
        const DEFINITION: &str = "def cow_identity(value: $A) -> $A { value }";
        let mut original = crate::test_support::session_from_cached_std_prelude();
        let definition = resolve(DEFINITION);
        let Resolved::Def(_, id, ..) = &definition[0] else {
            panic!("expected the identity definition");
        };
        let uid = id.unique_id;
        original.typecheck(definition).unwrap();
        let declaration = original.state.callable_signatures[&uid].clone();
        assert!(matches!(declaration.value_parameters[0].ty, Ty::Var(_)));
        assert_eq!(
            bincode::serialize(&declaration).unwrap(),
            bincode::serialize(declaration.as_ref()).unwrap(),
        );
        let checkpoint = original.checkpoint();
        let mut successful = original.clone();
        let mut rejected = original.clone();
        let calls = |suffix: &str| {
            let resolved = resolve(&format!("{DEFINITION}\n{suffix}"));
            let Resolved::Def(_, id, ..) = &resolved[0] else {
                panic!("expected the identity definition before calls");
            };
            assert_eq!(id.unique_id, uid);
            resolved.into_iter().skip(1).collect()
        };
        let typed = successful
            .typecheck(calls("cow_identity(1)\ncow_identity(\"ok\")"))
            .unwrap();
        assert_eq!(typed[0].ty, Ty::Int);
        assert_eq!(typed[1].ty, Ty::Str);
        assert!(Arc::ptr_eq(
            &declaration,
            &successful.state.callable_signatures[&uid]
        ));
        let error = rejected
            .typecheck(calls("wrong: Boolean = cow_identity(1)"))
            .expect_err("Boolean annotation cannot accept an Int result");
        assert!(
            error.message.contains("Boolean") && error.message.contains("Int"),
            "expected the annotation type mismatch: {error:?}"
        );
        assert!(Arc::ptr_eq(
            &declaration,
            &rejected.state.callable_signatures[&uid]
        ));
        let mut sibling = original.clone();
        assert_eq!(
            sibling
                .typecheck(calls("cow_identity(\"after failure\")"))
                .unwrap()[0]
                .ty,
            Ty::Str
        );
        assert!(Arc::ptr_eq(
            &declaration,
            &checkpoint.callable_signatures[&uid]
        ));
        assert!(matches!(declaration.value_parameters[0].ty, Ty::Var(_)));

        let bytes = bincode::serialize(&checkpoint).unwrap();
        let decoded: ScarCheckpoint = bincode::deserialize(&bytes).unwrap();
        let mut restored = ScarSession::new();
        restored.rollback(decoded);
        assert_eq!(
            restored.typecheck(calls("cow_identity(2)")).unwrap()[0].ty,
            Ty::Int
        );
    }
}

#[cfg(test)]
mod constructor_mapping_tests {
    use super::*;

    #[test]
    fn declaration_parent_proof_resolves_mapping_through_an_ordinary_trait() {
        // This test targets declaration coverage. Body checking separately
        // rejects the deliberately unconsumed capabilities of these empty impls.
        let ast = spire::parse_with_context(
            r#"
deftrait DepRoot where Self: Type<$A> {}
deftrait DepChild where Self: DepRoot {}
deftrait Marker {}
defenum Leaf<$A> { Leaf($A), }
defenum Bridge<$M> { Bridge($M), }
defenum DepShell<$L, $A> { Shell($L, $A), }
impl DepChild for DepShell<Bridge<Leaf<Int>>, $T> {}
impl DepRoot for DepShell<$L, $A>
where
  $L: Marker
  $A: DepRoot.$A
{}
impl Marker for Bridge<$M> where $M: DepChild {}
impl DepChild for Leaf<$T> {}
impl DepRoot for Leaf<$T> {}
"#,
            spire::ParserContext::project(0),
        )
        .unwrap();
        let resolved = crate::test_support::resolve_ast_with_builtin_prelude(ast).unwrap();
        let mut checker = Checker::with_persistent_state(
            crate::test_support::session_from_cached_std_prelude().state,
            TypecheckContext::default(),
        );
        checker.predeclare_type_signatures(&resolved).unwrap();
        checker.predeclare_traits(&resolved).unwrap();
        let trait_key = checker.trait_key_by_short_name("DepChild").unwrap();
        let implementation = checker
            .trait_impl_candidate_keys(&trait_key)
            .into_iter()
            .map(|key| &checker.trait_impls[&key])
            .find(|info| info.target_name.ends_with("DepShell"))
            .unwrap();
        assert_eq!(implementation.constructor_slot_positions, vec![1]);
        assert!(checker.constructor_mapping_resolution.pending.is_empty());
        assert!(checker.constructor_mapping_resolution.resolving.is_empty());
        assert!(checker
            .constructor_mapping_resolution
            .requests
            .borrow()
            .is_none());
    }

    #[test]
    fn declaration_mapping_cycle_rejects_reentry_and_clears_transient_state() {
        let ast = spire::parse_with_context(
            "deftrait MappingRoot where Self: Type<$A> {}\n\
             deftrait MappingChild where Self: MappingRoot {}\n\
             defenum MappingBox<$A> { Box($A), }\n\
             impl MappingRoot for MappingBox<$A> {}\n\
             impl MappingChild for MappingBox<$A> {}",
            spire::ParserContext::project(0),
        )
        .unwrap();
        let resolved = crate::test_support::resolve_ast_with_builtin_prelude(ast).unwrap();
        let mut checker = Checker::with_persistent_state(
            crate::test_support::session_from_cached_std_prelude().state,
            TypecheckContext::default(),
        );
        checker.check_program(resolved).unwrap();
        let trait_key = checker.trait_key_by_short_name("MappingChild").unwrap();
        let key = checker.trait_impl_candidate_keys(&trait_key)[0].clone();
        // Simulate a declaration dependency requesting its own unfinished impl.
        // Source-level trait inheritance cycles are rejected earlier by closure.
        checker
            .constructor_mapping_resolution
            .pending
            .insert(key.clone());
        checker.constructor_mapping_resolution.resolving.insert(key);
        let substitutions = checker.substitutions.clone();
        let bounds = checker.tyvar_bounds.clone();
        let witnesses = checker.constructor_witness_traits.clone();
        let rigid = checker.rigid_tyvars.clone();
        let error = checker.resolve_impl_constructor_mappings().unwrap_err();
        assert!(
            error.message.contains("mapping dependency cycle"),
            "{error}"
        );
        assert!(checker.constructor_mapping_resolution.pending.is_empty());
        assert!(checker.constructor_mapping_resolution.resolving.is_empty());
        assert!(checker
            .constructor_mapping_resolution
            .requests
            .borrow()
            .is_none());
        assert_eq!(checker.substitutions, substitutions);
        assert_eq!(checker.tyvar_bounds, bounds);
        assert_eq!(checker.constructor_witness_traits, witnesses);
        assert_eq!(checker.rigid_tyvars, rigid);
    }
}
