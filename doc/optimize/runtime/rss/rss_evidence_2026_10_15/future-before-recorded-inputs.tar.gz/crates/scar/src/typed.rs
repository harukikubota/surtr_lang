use serde::{Deserialize, Serialize};
use sigil::resolved::{
    Resolved, ResolvedId, ResolvedProcessHandlerUid, ResolvedProcessSpec, ResolvedWhereClause,
    ResolvedWhereConstraintRhs,
};
use sindr::primitives::SurtrInt;
use spire::ast::{
    AstTy, BinOp, Lit, ProcessSpec, Span, SupervisorInitSpec, ValueParameterMode, Visibility,
};

use crate::types::Ty;

/// A fully typed AST node.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedNode {
    pub ty: Ty,
    pub span: Span,
    pub node: TypedInner,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedProgram {
    pub nodes: Vec<TypedNode>,
    /// Checked enum templates visible in this program, including an incremental prefix.
    pub enum_definitions: std::collections::HashMap<String, Vec<TypedEnumVariantDef>>,
    /// Checked struct and record templates, preserving formal and phantom type parameters.
    pub nominal_definitions: std::collections::HashMap<String, TypedNominalDefinition>,
    pub process_specs: Vec<TypedProcessSpec>,
    pub boot_plan: SupervisorInitSpec,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedNominalDefinition {
    pub type_param_vars: Vec<u32>,
    pub fields: Vec<(String, Ty)>,
}

/// A declaration-level constraint clause preserved by Scar. Constructor
/// arity, slot mappings, parent-trait closure, and signature trait bounds are
/// validated while declarations are predeclared and checked.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedWhereClause {
    pub constraints: Vec<TypedWhereConstraint>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedWhereConstraint {
    pub subject: AstTy,
    pub bounds: Vec<TypedWhereConstraintRhs>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedWhereConstraintRhs {
    Trait {
        trait_id: ResolvedId,
    },
    TypeConstructor {
        span: Span,
        slots: Vec<AstTy>,
    },
    TraitSlot {
        trait_id: ResolvedId,
        slot_name: String,
        slot_ordinal: u32,
        span: Span,
    },
}

impl From<&ResolvedWhereClause> for TypedWhereClause {
    fn from(clause: &ResolvedWhereClause) -> Self {
        Self {
            constraints: clause
                .constraints
                .iter()
                .map(|constraint| TypedWhereConstraint {
                    subject: constraint.subject.clone(),
                    bounds: constraint
                        .bounds
                        .iter()
                        .map(|bound| match bound {
                            ResolvedWhereConstraintRhs::Trait { trait_id } => {
                                TypedWhereConstraintRhs::Trait {
                                    trait_id: trait_id.clone(),
                                }
                            }
                            ResolvedWhereConstraintRhs::TypeConstructor { span, slots } => {
                                TypedWhereConstraintRhs::TypeConstructor {
                                    span: span.clone(),
                                    slots: slots.clone(),
                                }
                            }
                            ResolvedWhereConstraintRhs::TraitSlot {
                                trait_id,
                                slot_name,
                                slot_ordinal,
                                span,
                            } => TypedWhereConstraintRhs::TraitSlot {
                                trait_id: trait_id.clone(),
                                slot_name: slot_name.clone(),
                                slot_ordinal: *slot_ordinal,
                                span: span.clone(),
                            },
                        })
                        .collect(),
                    span: constraint.span.clone(),
                })
                .collect(),
            span: clause.span.clone(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedTraitMethodInfo {
    pub name: String,
    pub params: Vec<Ty>,
    pub ret_ty: Ty,
    pub where_clause: Option<TypedWhereClause>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedProcessSpec {
    pub module_path: String,
    pub process_name: String,
    pub spec: ProcessSpec,
    pub init_uid: u32,
    pub get_uid: u32,
    pub set_uid: Option<u32>,
    pub handler_uids: Vec<TypedProcessHandlerUid>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TypedProcessHandlerUid {
    pub internal_name: String,
    pub uid: u32,
}

impl From<ResolvedProcessHandlerUid> for TypedProcessHandlerUid {
    fn from(value: ResolvedProcessHandlerUid) -> Self {
        Self {
            internal_name: value.internal_name,
            uid: value.uid,
        }
    }
}

impl From<ResolvedProcessSpec> for TypedProcessSpec {
    fn from(value: ResolvedProcessSpec) -> Self {
        Self {
            module_path: value.module_path,
            process_name: value.process_name,
            spec: value.spec,
            init_uid: value.init_uid,
            get_uid: value.get_uid,
            set_uid: value.set_uid,
            handler_uids: value.handler_uids.into_iter().map(Into::into).collect(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedDbgArg {
    pub span: Span,
    pub ty_name: String,
    pub expr: TypedNode,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ComposeFlavor {
    Plain,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedTypeParam {
    pub name: String,
    pub ty_var: u32,
    pub bound: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TraitDispatch {
    Pending,
    /// The selected implementation and its one complete solver substitution.
    /// Scar materializes this value before the Forge boundary.
    Selected(Box<TraitMethodInstantiation>),
    Static(TraitDispatchTarget),
}

/// The complete trait proof requested by an expression.  Keep this structural
/// while dispatch is pending so specialization never has to recover type
/// arguments from a rendered trait name.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TraitObligation {
    pub trait_id: String,
    pub trait_args: Vec<Ty>,
    pub receiver: Ty,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TraitDispatchTarget {
    BinOp(BinOp),
    Builtin(sindr::signature::BuiltinId),
    UserFunction { name: String, fun_idx: u32 },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TraitCallOrigin {
    Explicit,
    Operator {
        op: OperatorTraitOp,
        lhs_ty: Ty,
        rhs_ty: Ty,
    },
    Comparison {
        op: ComparisonOperator,
        lhs_ty: Ty,
        rhs_ty: Ty,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum OperatorTraitOp {
    PipeMap,
    ContextApply,
    PipeBind,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ComparisonOperator {
    Lt,
    Lte,
    Gt,
    Gte,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedFacetSegment {
    /// A public observation API, never a runtime representation field.
    ReadonlyBuiltin {
        field_name: String,
        builtin_id: u16,
    },
    ErrorPayload {
        kind: String,
        field_name: String,
        field_index: u32,
        payload_len: u32,
    },
    Field {
        field_name: String,
        /// Authored positional Record selector. Access still uses field_index.
        origin_index: Option<u32>,
        field_index: u32,
        container_field_count: u32,
        container_type_name: String,
        readonly: bool,
        private: bool,
    },
    Tuple {
        field_index: u32,
        tuple_len: u32,
    },
    Variant {
        enum_name: String,
        variant_name: String,
        variant_tag: u32,
        discriminant: SurtrInt,
        payload_arity: u32,
        optional: bool,
    },
    ListIndex {
        index: Box<TypedNode>,
        display: String,
        literal_index: Option<SurtrInt>,
    },
    ListRange {
        start: Box<TypedNode>,
        end: Box<TypedNode>,
        display: String,
        literal_start: Option<SurtrInt>,
        literal_end: Option<SurtrInt>,
    },
    MapKey {
        key: Box<TypedNode>,
        display: String,
        literal_key: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TypedFieldPolicy {
    pub private: bool,
    pub readonly: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TypedFacetPathKind {
    InfallibleStructural,
    FallibleStructural,
    VariantPath,
}

impl TypedFacetPathKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::InfallibleStructural => "InfallibleStructural",
            Self::FallibleStructural => "FallibleStructural",
            Self::VariantPath => "VariantPath",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedFacetPath {
    pub source_ty: Ty,
    pub focus_ty: Ty,
    /// Update-side slots carried by a concrete Facet annotation.  Both are
    /// `Hole` for a deferred path, so consuming the same binding can derive a
    /// fresh replacement type each time.
    pub update_source_ty: Ty,
    pub update_focus_ty: Ty,
    pub path_kind: TypedFacetPathKind,
    pub may_fail: bool,
    pub segments: Vec<TypedFacetSegment>,
}

impl TypedFacetPath {
    pub fn has_variant_segment(&self) -> bool {
        self.segments
            .iter()
            .any(|segment| matches!(segment, TypedFacetSegment::Variant { .. }))
    }

    pub fn final_segment_is_variant(&self) -> bool {
        self.segments
            .last()
            .is_some_and(|segment| matches!(segment, TypedFacetSegment::Variant { .. }))
    }

    pub fn is_infallible_structural(&self) -> bool {
        !self.may_fail && !self.has_variant_segment()
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PendingFacetPath {
    pub root_path_name: Option<String>,
    pub source_ty_hint: Option<Ty>,
    pub segments: Vec<PendingFacetSegment>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum PendingFacetExpr {
    Resolved(Box<Resolved>),
    Typed(Box<TypedNode>),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum PendingFacetSegment {
    Field {
        name: String,
        optional: bool,
    },
    Bracket {
        expr: PendingFacetExpr,
        display: String,
    },
    RangeBracket {
        start: PendingFacetExpr,
        end: PendingFacetExpr,
        display: String,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TypedFacetSetMode {
    Exact,
    CaseSet,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TypedFacetOverMode {
    FocusValue,
    FocusResult,
    CaseFocusValue,
    CaseFocusResult,
}

/// Resolved Facet API identity survives intrinsic lowering for callable metadata.
/// Path sugar uses View; closure literals retain their own callable identity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TypedFacetApi {
    View,
    Preview,
    Put,
    Set,
    Over,
    OverResult,
    CaseSet,
    CaseOver,
}

impl TypedFacetApi {
    pub fn name(self) -> &'static str {
        match self {
            Self::View => "view",
            Self::Preview => "preview",
            Self::Put => "put",
            Self::Set => "set",
            Self::Over => "over",
            Self::OverResult => "over_result",
            Self::CaseSet => "case_set",
            Self::CaseOver => "case_over",
        }
    }
}

/// Inner structure of a typed node.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedInner {
    Lit(Lit),
    Var(ResolvedId),
    App(Box<TypedNode>, Vec<TypedNode>),
    TraitCall {
        trait_name: String,
        method_name: String,
        receiver_ty: Ty,
        obligation: TraitObligation,
        dispatch: TraitDispatch,
        origin: TraitCallOrigin,
        args: Vec<TypedNode>,
    },
    /// Unary callable synthesized from `f(...)` for apply-style operators.
    InjectCall(Box<TypedNode>, Vec<TypedNode>),
    Block(Vec<TypedNode>),
    Bind(TypedPattern, Box<TypedNode>),
    SafeBind(
        TypedPattern,
        Box<TypedNode>,
        SafeBindRhsProjection,
        SafeBindFailureTarget,
    ),
    /// SafeBind normalized as expression-local control flow inside a `do` block.
    /// Both failure routes produce the do carrier value without escaping the
    /// enclosing callable or relying on codegen context.
    DoSafeBind(Box<TypedDoSafeBind>),
    BinOp(BinOp, Box<TypedNode>, Box<TypedNode>),
    Pipe(Box<TypedNode>, Box<TypedNode>),
    Compose(ComposeFlavor, Box<TypedNode>, Box<TypedNode>),
    ListNil,
    ListCons(Box<TypedNode>, Box<TypedNode>),
    ListLiteral(Vec<TypedNode>),
    TupleLiteral(Vec<TypedNode>),
    InterpolatedStr(Vec<TypedInterpolatedPart>),
    Dbg(Vec<TypedDbgArg>),
    /// An explicit parenthesized eager boundary at a `Lazy<T>` argument site.
    EagerBoundary(Box<TypedNode>),
    If(Box<TypedNode>, Box<TypedNode>, Option<Box<TypedNode>>),
    Cause(Box<TypedNode>, Box<TypedNode>),
    ErrorKind(String),
    Match(Box<TypedNode>, Vec<TypedMatchArm>),
    /// Expression-local Pattern execution with projection results in slot order.
    ApplyPattern {
        value: Box<TypedNode>,
        pattern: TypedPattern,
        projections: Vec<(ResolvedId, Ty)>,
    },

    /// Field access — field name resolved to index by Scar
    FieldAccess(Box<TypedNode>, u32),

    /// Process-local handler dependency access lowered from `ctx.<slot>`.
    ProcessContextHandler {
        process_name: String,
        slot: String,
    },

    /// Supervisor-driven worker spawn lowered from `DynSup::spawn(...)` or
    /// `MySup::spawn(...)`.
    SupervisorSpawn {
        supervisor_process: String,
        worker_process: String,
        init: Box<TypedNode>,
    },

    SupervisorAdopt {
        supervisor_process: String,
        worker_process: String,
        pid: Box<TypedNode>,
    },

    SupervisorStatus {
        supervisor_process: String,
    },

    SupervisorWorkers {
        supervisor_process: String,
        worker_process: String,
        init: Box<TypedNode>,
        strategy: Box<TypedNode>,
    },

    /// Compile-time facet constant path value. Stage 1 does not allow
    /// first-class runtime transport of facet values.
    FacetPath(TypedFacetPath),

    /// Deferred compile-time facet path value. Used for path bindings that need
    /// later source/focus context before they can be fully specialized.
    PendingFacetPath(PendingFacetPath),

    /// Facet view application with compile-time path metadata.
    FacetView {
        api: TypedFacetApi,
        source: Box<TypedNode>,
        path: TypedFacetPath,
        source_is_result: bool,
    },

    /// Facet set application with compile-time path metadata.
    FacetSet {
        api: TypedFacetApi,
        source: Box<TypedNode>,
        path: TypedFacetPath,
        value: Box<TypedNode>,
        source_is_result: bool,
        mode: TypedFacetSetMode,
    },

    /// Facet over application with compile-time path metadata.
    FacetOver {
        api: TypedFacetApi,
        source: Box<TypedNode>,
        path: TypedFacetPath,
        update_fun: Box<TypedNode>,
        source_is_result: bool,
        mode: TypedFacetOverMode,
    },

    /// Struct literal — tag + field values (in definition order)
    StructLit(u32, Vec<TypedNode>),

    /// Constructor call — tag + field values (in definition order)
    ConstructorCall(u32, Vec<TypedNode>),

    ErrorConstruct {
        kind: String,
        message: Box<TypedNode>,
        payload: Vec<TypedNode>,
        payload_fields: Vec<(String, Ty)>,
    },
    /// Error type definition — tag + binding id + constructor inputs + body
    DeferrorDef(
        u32,
        u32,
        ResolvedId,
        Vec<TypedValueParameter>,
        Box<TypedNode>,
    ),

    /// Enum definition — enum type name + variants
    EnumDef(String, Vec<TypedEnumVariantDef>),

    /// Function definition — tag + name + params + return type + body
    Def(
        u32,
        ResolvedId,
        Vec<TypedReturnTypeArgument>,
        Vec<TypedValueParameter>,
        Ty,
        Option<TypedWhereClause>,
        Box<TypedNode>,
        Visibility,
    ),

    /// Extractor definition — function-shaped runtime entry with MatchResult return type.
    ExtractorDef(
        u32,
        ResolvedId,
        Vec<TypedTypeParam>,
        Vec<TypedValueParameter>,
        Ty,
        Box<TypedNode>,
        Visibility,
    ),

    /// Trait definition metadata.
    TraitDef(String, Option<TypedWhereClause>, Vec<TypedTraitMethodInfo>),

    /// Trait impl metadata.
    TraitImplDef(String, String, Option<TypedWhereClause>),

    /// Builtin extractor declaration.
    BuiltinExtractorDecl(ResolvedId, Vec<Ty>, Ty),

    /// Closure literal — params + captures + body
    Closure(Vec<TypedClosureParam>, Vec<ResolvedId>, Box<TypedNode>),

    /// Lexically captured extractor whose body returns MatchResult.
    ExtractorClosure(Vec<TypedClosureParam>, Vec<ResolvedId>, Box<TypedNode>),

    /// Callable synthesized from a named capture expression. The runtime body
    /// is closure-shaped, but display metadata must preserve its Capture origin.
    CaptureClosure(Vec<TypedClosureParam>, Vec<ResolvedId>, Box<TypedNode>),

    /// Callable synthesized from a nominal constructor capture. Keep the
    /// resolved constructor identity alongside the closure body so Forge and
    /// Eldr do not have to recover it from the lowered constructor tag.
    CaptureConstructorClosure(
        ResolvedId,
        Vec<TypedClosureParam>,
        Vec<ResolvedId>,
        Box<TypedNode>,
    ),

    /// Captured function value
    Capture(Box<TypedNode>, Vec<TypedNode>),

    /// Struct definition — tag + name + field names + field policies
    StructDef(u32, String, Vec<String>, Vec<TypedFieldPolicy>),

    /// Record definition — tag + name + field names + field policies
    RecordDef(u32, String, Vec<String>, Vec<TypedFieldPolicy>),

    /// Semicolon — explicit Unit coercion
    Semi(Box<TypedNode>),

    HashMapLiteral(Vec<(TypedNode, TypedNode)>),
}

/// Interpolated string fragment (typed).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedInterpolatedPart {
    Text(String),
    /// A Show::to_string invocation whose result type is String.
    Expr(Box<TypedNode>),
}

/// Pattern in a binding (typed).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedPattern {
    /// Exact source position of this Pattern node, preserved through specialization.
    Located(Span, Box<TypedPattern>),
    Var(Ty, ResolvedId),
    Pin(Ty, ResolvedId, TraitDispatch),
    As(Ty, Box<TypedPattern>, ResolvedId),
    Wildcard(Ty),
    ListNil(Ty),
    ListCons(Ty, Box<TypedPattern>, Box<TypedPattern>),
    IntLit(Ty, SurtrInt),
    StrLit(Ty, String),
    BoolLit(Ty, bool),
    DurationLit(Ty, SurtrInt),
    Tuple(Ty, Vec<TypedPattern>),
    /// Ordered String keys and child patterns; only an empty entry list is total.
    HashMap(Ty, Vec<TypedHashMapPatternEntry>),
    /// Enum/Result constructor pattern checked through the common MatchBlock rules.
    Constructor {
        ty: Ty,
        tag: u32,
        field_tys: Vec<Ty>,
        fields: Vec<TypedPattern>,
        field_offset: u32,
    },
    Extractor {
        input_ty: Ty,
        extractor: ResolvedId,
        extractor_ty: Ty,
        pre_args: Vec<TypedNode>,
        success_tag: u32,
        err_tag: u32,
        seq_tys: Vec<Ty>,
        items: Vec<TypedPattern>,
    },
}

/// Key source positions survive specialization for missing-key Error origins.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedHashMapPatternEntry {
    pub key: TypedNode,
    pub pattern: TypedPattern,
    pub key_span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedHashMapMatchPatternEntry {
    pub key: TypedNode,
    pub pattern: TypedMatchPattern,
    pub key_span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum SafeBindRhsProjection {
    CanonicalResultOnce {
        payload_ty: Ty,
        error_ty: Ty,
    },
    /// Match the checked Pattern input directly. It may itself be Result when
    /// supplied as a Monad payload by `<-`; this projection never unwraps it.
    PatternInput {
        pattern_input_ty: Ty,
    },
}

/// Resolved ordinary Trait call; the generated argument binding receives the
/// original Pattern/Result Error without reconstructing its metadata.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MonadFailTarget {
    pub carrier_ty: Ty,
    pub error_id: ResolvedId,
    pub call: Box<TypedNode>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DeferredDoFailureTarget {
    pub do_keyword_span: Span,
    pub carrier_ty: Ty,
    pub alternative_trait_key: String,
    pub alternative_method_name: String,
    pub propagated_error_tys: Vec<Ty>,
    pub failure_span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum SafeBindFailureTarget {
    EnclosingMonadFail(Box<MonadFailTarget>),
    EnclosingMatchResultContext { err_tag: u32 },
    TopLevel,
    DoMonadFail(Box<MonadFailTarget>),
    DoAlternative { empty: Box<TypedNode> },
    Deferred(Box<DeferredDoFailureTarget>),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedDoSafeBind {
    pub pattern: TypedPattern,
    pub rhs: Box<TypedNode>,
    pub projection: SafeBindRhsProjection,
    pub failure_target: SafeBindFailureTarget,
    pub continuation: Box<TypedNode>,
    pub origins: DoSafeBindOrigins,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DoSafeBindOrigins {
    pub do_span: Span,
    pub operator_span: Span,
    pub pattern_span: Span,
    pub rhs_span: Span,
    pub result_span: Span,
}

/// Match pattern (typed).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypedMatchPattern {
    Binding(ResolvedId),
    Pin {
        id: ResolvedId,
        ty: Ty,
        dispatch: TraitDispatch,
    },
    /// `inner @ alias`
    As(Box<TypedMatchPattern>, ResolvedId),
    /// `_`
    Wildcard,
    /// `True` / `False`
    BoolLit(bool),
    /// Integer literal
    IntLit(SurtrInt),
    /// String literal
    StrLit(String),
    /// Duration literal, e.g. `20ms`.
    DurationLit(SurtrInt),
    /// Concrete `deferror` kind pattern for abstract Error values.
    ErrorKind(String),
    ErrorPayload {
        kind: String,
        fields: Vec<TypedMatchPattern>,
    },
    /// Pattern alternative. Alternatives are tests only and do not bind names.
    Or(Vec<TypedMatchPattern>),
    Tuple(Vec<TypedMatchPattern>),
    /// Total structural Record head; children may still be partial.
    Record(Vec<TypedMatchPattern>),
    HashMap(Vec<TypedHashMapMatchPatternEntry>),
    /// Constructor tag + field patterns + payload field offset.
    Constructor {
        tag: u32,
        fields: Vec<TypedMatchPattern>,
        field_offset: u32,
    },
    /// `[]`
    ListNil,
    /// `[head, ..tail]`
    ListCons(Box<TypedMatchPattern>, Box<TypedMatchPattern>),
    Extractor {
        input_ty: Ty,
        extractor: ResolvedId,
        extractor_ty: Ty,
        pre_args: Vec<TypedNode>,
        success_tag: u32,
        err_tag: u32,
        seq_tys: Vec<Ty>,
        items: Vec<TypedMatchPattern>,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedMatchArm {
    /// An if_let success expression whose Pattern introduces bindings, even if unused.
    /// Preserved and revalidated through inference and specialization: an external thunk
    /// cannot replace it, while a Pattern-bound function or a closure created here can.
    pub direct_expression: bool,
    pub pattern: TypedMatchPattern,
    pub guard: Option<TypedNode>,
    pub body: TypedNode,
}

/// A checked declaration or call-site return type argument.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedReturnTypeArgument {
    pub ordinal: u32,
    pub ty: Ty,
    pub span: Span,
}

/// A checked declaration-side value parameter.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedValueParameter {
    pub id: ResolvedId,
    pub mode: ValueParameterMode,
    pub ty: Ty,
    pub span: Span,
}

/// Typed closure parameter.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedClosureParam {
    pub id: ResolvedId,
    pub ty: Ty,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypedEnumVariantDef {
    pub enum_ty: Ty,
    pub payload_types: Vec<Ty>,
    pub discriminant: SurtrInt,
    pub lowering: Option<sindr::names::SpecialEnumVariantLowering>,
    pub tag: u32,
    pub constructor_name: String,
    pub field_names: Vec<String>,
}

impl From<&crate::env::EnumVariantInfo> for TypedEnumVariantDef {
    fn from(variant: &crate::env::EnumVariantInfo) -> Self {
        Self {
            enum_ty: variant.enum_ty.clone(),
            payload_types: variant.payload.clone(),
            discriminant: variant.discriminant.clone(),
            lowering: variant.special_variant,
            tag: variant.tag,
            constructor_name: variant.constructor_name.clone(),
            field_names: (0..variant.payload.len())
                .map(|idx| format!("_{idx}"))
                .collect(),
        }
    }
}

pub use diagnostics::TypeListRole;

/// A structural declaration type. Nominal applications retain all type
/// arguments, including phantom parameters absent from runtime field storage.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CanonicalTypeHead {
    Builtin(sindr::names::TypeName),
    Nominal(u32),
    Variable(u32),
    Tuple,
    Function,
    SelfApplication,
    Facet(crate::types::FacetKind),
    Pid,
    ProcessMarker(String),
    Hole,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalTy {
    pub head: CanonicalTypeHead,
    pub arguments: Vec<CanonicalTy>,
}

impl CanonicalTy {
    pub fn has_pending_instantiation(&self) -> bool {
        matches!(
            self.head,
            CanonicalTypeHead::Variable(_) | CanonicalTypeHead::SelfApplication
        ) || self.arguments.iter().any(Self::has_pending_instantiation)
    }
}

/// The sorted canonical Trait identities of one inheritance component.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct TypeCtorTraitFamilyId(pub Vec<u32>);

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ConstructorHead {
    Concrete(CanonicalTypeHead),
    DeclarationVariable(u32),
    InferenceVariable(u32),
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ConstructorSlotId {
    pub family_id: TypeCtorTraitFamilyId,
    pub ordinal: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalMappedSlot {
    pub slot_id: ConstructorSlotId,
    pub position: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalCapturedArgument {
    pub position: u32,
    pub ty: CanonicalTy,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalConstructorCarrier {
    pub family_id: TypeCtorTraitFamilyId,
    pub constructor: ConstructorHead,
    pub arity: u32,
    pub mapped_slots: Vec<CanonicalMappedSlot>,
    pub captured_arguments: Vec<CanonicalCapturedArgument>,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalTraitRef {
    pub trait_id: u32,
    pub arguments: Vec<CanonicalTy>,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CanonicalTraitImplPatternKey {
    pub trait_ref: CanonicalTraitRef,
    pub target: CanonicalTy,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct TraitImplDeclarationKey {
    pub pattern: CanonicalTraitImplPatternKey,
    pub declaration_id: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct MethodDeclarationId(pub u32);

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SyntheticMethodId {
    pub site_start: usize,
    pub site_end: usize,
    pub target: CanonicalTy,
    pub contract: MethodDeclarationId,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum TraitMethodOrigin {
    Explicit(MethodDeclarationId),
    Default(MethodDeclarationId),
    Derived(SyntheticMethodId),
    Builtin(sindr::signature::BuiltinId),
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum TraitImplementationId {
    Declared {
        declaration: TraitImplDeclarationKey,
        origin: TraitMethodOrigin,
    },
    Compiler {
        contract: MethodDeclarationId,
        subject: CanonicalTy,
    },
}

/// Canonical declaration variables mapped by the single applicability probe.
pub type CanonicalSubstitution = std::collections::HashMap<u32, Ty>;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TraitMethodInstantiation {
    pub implementation: TraitImplementationId,
    pub method: MethodDeclarationId,
    pub substitution: CanonicalSubstitution,
    pub callable_signature: sindr::signature::CallableSignature<CanonicalTy>,
    pub dispatch_target: TraitDispatchTarget,
    pub(crate) caller_substitution: std::collections::HashMap<u32, Ty>,
    pub(crate) proof_evidence: Vec<usize>,
}

/// Source location of one complete type entry; nested types remain recursive.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypeOrigin {
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypeListEntry {
    pub role: TypeListRole,
    pub ordinal: u32,
    /// Canonical identity and recursive arguments in declaration order.
    pub ty: CanonicalTy,
    pub origin: TypeOrigin,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImplHeadTypeList {
    pub entries: Vec<TypeListEntry>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RequestedHeadTypeList {
    pub entries: Vec<TypeListEntry>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum CanonicalMethodBound {
    Trait(u32),
    TypeConstructor(Vec<CanonicalTy>),
    TraitSlot { trait_id: u32, ordinal: u32 },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CanonicalMethodConstraint {
    pub subject: CanonicalTy,
    pub bound: CanonicalMethodBound,
    pub origin: TypeOrigin,
}

#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
pub struct CanonicalConstraintSet {
    pub constraints: Vec<CanonicalMethodConstraint>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MethodSignatureTypeList {
    pub entries: Vec<TypeListEntry>,
    pub where_constraints: CanonicalConstraintSet,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StructuralTypePath {
    pub role: TypeListRole,
    pub ordinal: u32,
    pub nested_arguments: Vec<u32>,
}

impl TypedPattern {
    pub fn unlocated(&self) -> &Self {
        match self {
            Self::Located(_, inner) => inner.unlocated(),
            other => other,
        }
    }
}

impl TypedNode {
    /// The embedded ordinary call is a child for specialization and validation.
    pub fn monad_fail_call(&self) -> Option<&TypedNode> {
        match &self.node {
            TypedInner::SafeBind(_, _, _, target) => target.monad_fail_call(),
            TypedInner::DoSafeBind(control) => control.failure_target.monad_fail_call(),
            _ => None,
        }
    }
}
impl SafeBindFailureTarget {
    pub fn monad_fail_call(&self) -> Option<&TypedNode> {
        match self {
            Self::EnclosingMonadFail(target) | Self::DoMonadFail(target) => Some(&target.call),
            _ => None,
        }
    }
}
