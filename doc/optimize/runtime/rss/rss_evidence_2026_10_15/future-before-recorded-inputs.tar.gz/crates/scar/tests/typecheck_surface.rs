#![deny(dead_code)]

use scar::env::TypeKind;
use scar::typed::{
    OperatorTraitOp, SafeBindFailureTarget, SafeBindRhsProjection, TraitCallOrigin,
    TypedDoSafeBind, TypedFacetPathKind, TypedFacetSegment, TypedInner, TypedNode, TypedPattern,
    TypedProgram, TypedWhereConstraintRhs,
};
use scar::types::Ty;
use sigil::resolved::{
    Resolved, ResolvedFacetBracketExpr, ResolvedFacetPathSegment, ResolvedHashMapLiteralEntry,
    ResolvedId, ResolvedPattern, ResolvedWhereConstraintRhs,
};
use sindr::names::TypeIdentity;
use sindr::policy::{EntryPoint, ExitCodePolicy, RuntimeSourcePolicy};
use sindr::primitives::int;
use spire::ast::{AstTy, Lit, Span};
use std::collections::HashSet;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Mutex;

mod support;

use support::*;

const PROCESS_MODULE_SOURCE: &str = include_str!("../../../lib/process.srt");

const SURFACE_WORKER_COUNT: usize = 1;

fn resolve_with_standard_environment(source: &str) -> Vec<Resolved> {
    let ast = spire::parse_with_context(source, spire::ParserContext::project(0))
        .expect("source should parse with the standard environment");
    support::resolve_ast_with_builtin_prelude(ast)
        .expect("source should resolve with the standard environment")
}

fn typecheck_with_standard_environment(
    source: &str,
) -> Result<Vec<TypedNode>, scar::error::TypeError> {
    support::typecheck(resolve_with_standard_environment(source))
}

macro_rules! surface_case {
    ($case:ident) => {
        (stringify!($case), $case as fn())
    };
}

const SURFACE_CASES: &[(&str, fn())] = &[
    surface_case!(hash_map_pattern_type_boundaries),
    surface_case!(pattern_failure_diagnostics_show_target_origins),
    surface_case!(facet_view_capture_infers_source_from_path),
    surface_case!(facet_view_capture_preserves_constraints),
    surface_case!(facet_capture_compile_time_scope_boundaries),
    surface_case!(trait_result_error_omission_allows_impl_contract),
    surface_case!(trait_result_explicit_error_contract_is_declaration_metadata),
    (
        "process_stdlib_no_longer_declares_task_hidden_lower_helpers",
        process_stdlib_no_longer_declares_task_hidden_lower_helpers as fn(),
    ),
    (
        "process_stdlib_declares_common_process_family_modules",
        process_stdlib_declares_common_process_family_modules as fn(),
    ),
    (
        "process_module_only_declares_public_runtime_helpers",
        process_module_only_declares_public_runtime_helpers as fn(),
    ),
    (
        "process_stdlib_declares_agent_lower_surface_with_regular_surface_docs",
        process_stdlib_declares_agent_lower_surface_with_regular_surface_docs as fn(),
    ),
    (
        "field_access_is_resolved_to_numeric_index",
        field_access_is_resolved_to_numeric_index as fn(),
    ),
    (
        "match_bool_requires_exhaustive_arms",
        match_bool_requires_exhaustive_arms as fn(),
    ),
    (
        "match_bool_accepts_qualified_boolean_constructor_patterns",
        match_bool_accepts_qualified_boolean_constructor_patterns as fn(),
    ),
    (
        "match_bool_qualified_constructor_patterns_require_exhaustive_arms",
        match_bool_qualified_constructor_patterns_require_exhaustive_arms as fn(),
    ),
    surface_case!(facet_capture_call_inference_preserves_argument_diagnostics),
    surface_case!(error_kind_accepts_user_type_positions),
    surface_case!(recover_kind_rejects_invalid_handlers),
    surface_case!(facet_capture_call_inference_resolves_later_arguments),
    surface_case!(facet_capture_call_inference_resolves_dependencies_and_return),
    surface_case!(facet_capture_call_inference_rejects_invalid_paths_and_unresolved_source),
    surface_case!(match_root_or_contributes_to_exhaustiveness),
    surface_case!(match_root_or_as_alias_contributes_to_exhaustiveness),
    surface_case!(if_let_or_shares_binding_type),
    surface_case!(if_let_or_rejects_different_binding_types),
    (
        "safebind_total_pattern_rejects_plain_non_monad_rhs",
        safebind_total_pattern_rejects_plain_non_monad_rhs as fn(),
    ),
    (
        "dbg_special_form_typechecks_to_unit",
        dbg_special_form_typechecks_to_unit as fn(),
    ),
    (
        "safebind_function_requires_result_return_type",
        safebind_function_requires_result_return_type as fn(),
    ),
    (
        "safebind_result_closure_uses_nearest_callable_return_type",
        safebind_result_closure_uses_nearest_callable_return_type as fn(),
    ),
    (
        "safebind_non_result_closure_is_rejected",
        safebind_non_result_closure_is_rejected as fn(),
    ),
    (
        "safebind_result_returning_annotated_closure_allows_safebind",
        safebind_result_returning_annotated_closure_allows_safebind as fn(),
    ),
    (
        "safebind_non_result_closure_rejects_safebind",
        safebind_non_result_closure_rejects_safebind as fn(),
    ),
    (
        "safebind_top_ok_pattern_requires_nested_result_rhs",
        safebind_top_ok_pattern_requires_nested_result_rhs as fn(),
    ),
    (
        "safebind_top_ok_pattern_accepts_nested_result_rhs",
        safebind_top_ok_pattern_accepts_nested_result_rhs as fn(),
    ),
    surface_case!(safebind_partial_option_constructor_checks_the_whole_rhs),
    surface_case!(safebind_total_option_rhs_uses_non_result_monad_reason),
    surface_case!(safebind_annotation_mismatch_precedes_total_rhs_classification),
    surface_case!(safebind_unbound_generic_rhs_keeps_capability_failure),
    (
        "safebind_list_pattern_accepts_plain_list_rhs",
        safebind_list_pattern_accepts_plain_list_rhs as fn(),
    ),
    (
        "safebind_string_pattern_accepts_plain_string_rhs",
        safebind_string_pattern_accepts_plain_string_rhs as fn(),
    ),
    (
        "int_range_literal_typechecks_to_list_int",
        int_range_literal_typechecks_to_list_int as fn(),
    ),
    (
        "string_range_literal_typechecks_to_result_list_string",
        string_range_literal_typechecks_to_result_list_string as fn(),
    ),
    (
        "hash_map_literal_typechecks_string_key_expressions",
        hash_map_literal_typechecks_string_key_expressions as fn(),
    ),
    (
        "hash_map_literal_rejects_non_string_keys",
        hash_map_literal_rejects_non_string_keys as fn(),
    ),
    (
        "hash_map_literal_rejects_mixed_value_types",
        hash_map_literal_rejects_mixed_value_types as fn(),
    ),
    (
        "match_string_requires_empty_and_uncons_arms_for_exhaustiveness",
        match_string_requires_empty_and_uncons_arms_for_exhaustiveness as fn(),
    ),
    (
        "match_string_accepts_empty_and_uncons_arms",
        match_string_accepts_empty_and_uncons_arms as fn(),
    ),
    (
        "safebind_list_pattern_accepts_nested_constructor_literals",
        safebind_list_pattern_accepts_nested_constructor_literals as fn(),
    ),
    (
        "tuple_literal_and_field_access_typecheck",
        tuple_literal_and_field_access_typecheck as fn(),
    ),
    (
        "pair_constructor_lowered_tuple_values_typecheck_without_operator_traits",
        pair_constructor_lowered_tuple_values_typecheck_without_operator_traits as fn(),
    ),
    (
        "tuple_bind_pattern_typechecks",
        tuple_bind_pattern_typechecks as fn(),
    ),
    (
        "facet_view_on_plain_value_returns_plain_focus",
        facet_view_on_plain_value_returns_plain_focus as fn(),
    ),
    (
        "facet_view_on_result_value_returns_result_focus",
        facet_view_on_result_value_returns_result_focus as fn(),
    ),
    (
        "facet_variant_selector_returns_result_and_requires_pascal_case",
        facet_variant_selector_returns_result_and_requires_pascal_case as fn(),
    ),
    (
        "facet_preview_requires_variant_path_and_records_path_kind",
        facet_preview_requires_variant_path_and_records_path_kind as fn(),
    ),
    (
        "facet_preview_accepts_option_variant",
        facet_preview_accepts_option_variant as fn(),
    ),
    (
        "facet_boolean_selector_uses_regular_enum_diagnostic",
        facet_boolean_selector_uses_regular_enum_diagnostic as fn(),
    ),
    (
        "facet_list_and_map_segments_are_fallible_structural_paths",
        facet_list_and_map_segments_are_fallible_structural_paths as fn(),
    ),
    (
        "facet_explicit_container_root_captures_use_expected_function_context",
        facet_explicit_container_root_captures_use_expected_function_context as fn(),
    ),
    (
        "facet_dynamic_container_segments_accept_runtime_expressions",
        facet_dynamic_container_segments_accept_runtime_expressions as fn(),
    ),
    (
        "facet_dynamic_container_segments_reject_result_and_wrong_key_types",
        facet_dynamic_container_segments_reject_result_and_wrong_key_types as fn(),
    ),
    (
        "facet_negative_list_index_and_range_segments_typecheck",
        facet_negative_list_index_and_range_segments_typecheck as fn(),
    ),
    (
        "facet_range_segments_require_plain_int_endpoints_and_list_values",
        facet_range_segments_require_plain_int_endpoints_and_list_values as fn(),
    ),
    (
        "facet_const_dynamic_container_segments_require_literals",
        facet_const_dynamic_container_segments_require_literals as fn(),
    ),
    (
        "facet_case_api_requires_enum_path_and_records_modes",
        facet_case_api_requires_enum_path_and_records_modes as fn(),
    ),
    (
        "facet_surface_resolves_after_facet_rename",
        facet_surface_resolves_after_facet_rename as fn(),
    ),
    (
        "facet_compose_typecheck_success_and_mismatch",
        facet_compose_typecheck_success_and_mismatch as fn(),
    ),
    surface_case!(result_chain_field_access_is_not_facet_compose),
    surface_case!(facet_compose_and_result_chain_have_separate_identities),
    (
        "facet_arrow_compose_typecheck_success_and_mismatch",
        facet_arrow_compose_typecheck_success_and_mismatch as fn(),
    ),
    (
        "facet_set_returns_result_source",
        facet_set_returns_result_source as fn(),
    ),
    (
        "facet_put_returns_plain_source",
        facet_put_returns_plain_source as fn(),
    ),
    (
        "facet_put_rejects_result_source_and_variant_path",
        facet_put_rejects_result_source_and_variant_path as fn(),
    ),
    (
        "facet_put_supports_same_type_tuple_update_inside_annotated_closure",
        facet_put_supports_same_type_tuple_update_inside_annotated_closure as fn(),
    ),
    (
        "facet_put_unannotated_closure_uses_declared_return_tuple_context",
        facet_put_unannotated_closure_uses_declared_return_tuple_context as fn(),
    ),
    (
        "facet_put_supports_type_changing_tuple_update",
        facet_put_supports_type_changing_tuple_update as fn(),
    ),
    (
        "facet_put_rebuilds_unique_generic_named_type",
        facet_put_rebuilds_unique_generic_named_type as fn(),
    ),
    (
        "facet_put_rejects_repeated_generic_named_type",
        facet_put_rejects_repeated_generic_named_type as fn(),
    ),
    (
        "facet_case_set_rebuilds_unique_generic_enum",
        facet_case_set_rebuilds_unique_generic_enum as fn(),
    ),
    (
        "facet_put_rejects_result_annotation_context",
        facet_put_rejects_result_annotation_context as fn(),
    ),
    (
        "facet_put_rejects_result_return_context",
        facet_put_rejects_result_return_context as fn(),
    ),
    (
        "facet_over_requires_unary_result_callable",
        facet_over_requires_unary_result_callable as fn(),
    ),
    (
        "optional_type_annotation_matches_option",
        optional_type_annotation_matches_option as fn(),
    ),
    (
        "optional_type_annotation_rejects_result_value",
        optional_type_annotation_rejects_result_value as fn(),
    ),
    (
        "facet_set_rejects_plain_value_for_result_focus",
        facet_set_rejects_plain_value_for_result_focus as fn(),
    ),
    (
        "facet_shorthand_view_and_mutation_forms_typecheck",
        facet_shorthand_view_and_mutation_forms_typecheck as fn(),
    ),
    (
        "facet_shorthand_reuses_existing_facet_api_errors",
        facet_shorthand_reuses_existing_facet_api_errors as fn(),
    ),
    (
        "facet_shorthand_misuse_is_rejected_outside_facet_api",
        facet_shorthand_misuse_is_rejected_outside_facet_api as fn(),
    ),
    (
        "facet_over_accepts_success_updater_for_result_focus",
        facet_over_accepts_success_updater_for_result_focus as fn(),
    ),
    (
        "facet_over_allows_result_typed_payload_replacement",
        facet_over_allows_result_typed_payload_replacement as fn(),
    ),
    (
        "facet_over_result_requires_result_container_updater",
        facet_over_result_requires_result_container_updater as fn(),
    ),
    (
        "nested_result_err_expression_has_dedicated_diagnostic",
        nested_result_err_expression_has_dedicated_diagnostic as fn(),
    ),
    (
        "nested_result_err_pattern_has_dedicated_diagnostic",
        nested_result_err_pattern_has_dedicated_diagnostic as fn(),
    ),
    (
        "readonly_facet_view_succeeds_and_preserves_path_metadata",
        readonly_facet_view_succeeds_and_preserves_path_metadata as fn(),
    ),
    (
        "readonly_field_blocks_deep_mutation_but_owner_can_replace_property",
        readonly_field_blocks_deep_mutation_but_owner_can_replace_property as fn(),
    ),
    (
        "readonly_struct_fields_allow_owner_replacement",
        readonly_struct_fields_allow_owner_replacement as fn(),
    ),
    (
        "facet_standalone_tuple_root_is_rejected",
        facet_standalone_tuple_root_is_rejected as fn(),
    ),
    (
        "facet_bindings_can_be_reused_by_facet_intrinsics",
        facet_bindings_can_be_reused_by_facet_intrinsics as fn(),
    ),
    (
        "facet_tuple_type_root_view_works_with_expected_context",
        facet_tuple_type_root_view_works_with_expected_context as fn(),
    ),
    surface_case!(record_positional_facet_resolves_to_named_field),
    surface_case!(record_positional_facet_rejects_out_of_bounds_and_tuple_root),
    (
        "deferred_tuple_facet_binding_can_be_reused_by_facet_intrinsics",
        deferred_tuple_facet_binding_can_be_reused_by_facet_intrinsics as fn(),
    ),
    (
        "deferred_tuple_facet_binding_can_compose_before_consumption",
        deferred_tuple_facet_binding_can_compose_before_consumption as fn(),
    ),
    (
        "facet_tuple_type_root_compose_works_as_inner_path",
        facet_tuple_type_root_compose_works_as_inner_path as fn(),
    ),
    (
        "facet_tuple_type_root_arrow_compose_works_as_inner_path",
        facet_tuple_type_root_arrow_compose_works_as_inner_path as fn(),
    ),
    (
        "facet_const_arrow_compose_allows_facet_consts",
        facet_const_arrow_compose_allows_facet_consts as fn(),
    ),
    (
        "facet_const_arrow_compose_rejects_non_facet_const_refs",
        facet_const_arrow_compose_rejects_non_facet_const_refs as fn(),
    ),
    (
        "slash_operator_has_no_facet_fallback",
        slash_operator_has_no_facet_fallback as fn(),
    ),
    (
        "facet_tuple_type_root_without_context_can_bind_as_deferred_path",
        facet_tuple_type_root_without_context_can_bind_as_deferred_path as fn(),
    ),
    (
        "facet_view_inside_closure_is_allowed_for_same_scope_consumption",
        facet_view_inside_closure_is_allowed_for_same_scope_consumption as fn(),
    ),
    (
        "facet_capture_shorthand_builds_read_closure",
        facet_capture_shorthand_builds_read_closure as fn(),
    ),
    (
        "facet_values_cannot_be_embedded_in_runtime_containers",
        facet_values_cannot_be_embedded_in_runtime_containers as fn(),
    ),
    (
        "nested_facet_types_are_rejected_in_function_signatures",
        nested_facet_types_are_rejected_in_function_signatures as fn(),
    ),
    (
        "private_field_access_is_allowed_inside_owner_impl_only",
        private_field_access_is_allowed_inside_owner_impl_only as fn(),
    ),
    (
        "private_field_access_outside_owner_impl_is_rejected_for_value_and_capability_roots",
        private_field_access_outside_owner_impl_is_rejected_for_value_and_capability_roots
            as fn(),
    ),
    (
        "private_field_access_inside_closure_is_rejected_outside_owner_impl",
        private_field_access_inside_closure_is_rejected_outside_owner_impl as fn(),
    ),
    (
        "private_field_access_inside_param_closure_is_rejected_outside_owner_impl",
        private_field_access_inside_param_closure_is_rejected_outside_owner_impl as fn(),
    ),
    (
        "private_capability_root_is_rejected_in_facet_view_call",
        private_capability_root_is_rejected_in_facet_view_call as fn(),
    ),
    (
        "facet_scope_local_value_can_flow_to_closure_after_view",
        facet_scope_local_value_can_flow_to_closure_after_view as fn(),
    ),
    (
        "facet_runtime_transport_restrictions_remain",
        facet_runtime_transport_restrictions_remain as fn(),
    ),
    (
        "extractor_single_value_match_result_contract_typechecks",
        extractor_single_value_match_result_contract_typechecks as fn(),
    ),
    (
        "struct_matchblock_head_uses_attached_deconstruct_method",
        struct_matchblock_head_uses_attached_deconstruct_method as fn(),
    ),
    (
        "struct_matchblock_head_requires_attached_deconstruct_method",
        struct_matchblock_head_requires_attached_deconstruct_method as fn(),
    ),
    (
        "enum_impl_extractor_can_be_used_in_matchblock",
        enum_impl_extractor_can_be_used_in_matchblock as fn(),
    ),
    (
        "forward_struct_type_annotation_and_literal_are_allowed",
        forward_struct_type_annotation_and_literal_are_allowed as fn(),
    ),
    (
        "generic_struct_single_type_param_typechecks",
        generic_struct_single_type_param_typechecks as fn(),
    ),
    (
        "generic_struct_two_type_params_typecheck",
        generic_struct_two_type_params_typecheck as fn(),
    ),
    (
        "forward_deferror_value_can_flow_into_err",
        forward_deferror_value_can_flow_into_err as fn(),
    ),
    (
        "zero_arg_deferror_value_can_flow_into_error_parameter",
        zero_arg_deferror_value_can_flow_into_error_parameter as fn(),
    ),
    (
        "recover_kind_payload_type_name_typechecks",
        recover_kind_payload_type_name_typechecks as fn(),
    ),
    (
        "forward_reference_type_tags_are_deterministic_across_runs",
        forward_reference_type_tags_are_deterministic_across_runs as fn(),
    ),
    (
        "user_function_calls_typecheck_inside_script_module_scope",
        user_function_calls_typecheck_inside_script_module_scope as fn(),
    ),
    (
        "namespaced_type_and_trait_impl_typecheck_inside_script_module_scope",
        namespaced_type_and_trait_impl_typecheck_inside_script_module_scope as fn(),
    ),
    (
        "tuple_trait_impl_typechecks_inside_script_module_scope",
        tuple_trait_impl_typechecks_inside_script_module_scope as fn(),
    ),
    (
        "concrete_tuple_trait_impl_typechecks_inside_script_module_scope",
        concrete_tuple_trait_impl_typechecks_inside_script_module_scope as fn(),
    ),
    (
        "generic_user_function_calls_typecheck_inside_script_module_scope",
        generic_user_function_calls_typecheck_inside_script_module_scope as fn(),
    ),
    (
        "where_constraint_kinds_survive_in_typed_metadata",
        where_constraint_kinds_survive_in_typed_metadata as fn(),
    ),
    (
        "return_only_signature_slots_are_rejected",
        return_only_signature_slots_are_rejected as fn(),
    ),
    (
        "signature_slots_are_checked_before_definition_bodies",
        signature_slots_are_checked_before_definition_bodies as fn(),
    ),
    (
        "named_args_user_function_calls_typecheck_inside_script_module_scope",
        named_args_user_function_calls_typecheck_inside_script_module_scope as fn(),
    ),
    (
        "canonical_builtin_type_name_hole_is_reserved_for_structs",
        canonical_builtin_type_name_hole_is_reserved_for_structs as fn(),
    ),
    (
        "canonical_builtin_type_name_hole_is_reserved_for_enums",
        canonical_builtin_type_name_hole_is_reserved_for_enums as fn(),
    ),
    (
        "canonical_builtin_type_name_hole_is_reserved_for_errors",
        canonical_builtin_type_name_hole_is_reserved_for_errors as fn(),
    ),
    (
        "canonical_builtin_type_name_closure_is_reserved_for_structs",
        canonical_builtin_type_name_closure_is_reserved_for_structs as fn(),
    ),
    (
        "canonical_builtin_type_name_match_arms_is_reserved_for_structs",
        canonical_builtin_type_name_match_arms_is_reserved_for_structs as fn(),
    ),
    (
        "canonical_builtin_type_name_cond_clauses_is_reserved_for_enums",
        canonical_builtin_type_name_cond_clauses_is_reserved_for_enums as fn(),
    ),
    (
        "match_arms_type_is_forbidden_in_ordinary_user_signatures",
        match_arms_type_is_forbidden_in_ordinary_user_signatures as fn(),
    ),
    (
        "match_arms_type_is_forbidden_in_return_types",
        match_arms_type_is_forbidden_in_return_types as fn(),
    ),
    (
        "cond_clauses_type_is_forbidden_in_ordinary_user_signatures",
        cond_clauses_type_is_forbidden_in_ordinary_user_signatures as fn(),
    ),
    (
        "cond_clauses_type_is_forbidden_in_return_types",
        cond_clauses_type_is_forbidden_in_return_types as fn(),
    ),
    surface_case!(do_block_type_is_reserved_in_ordinary_type_positions),
    surface_case!(do_explicit_and_expected_carriers_typecheck),
    surface_case!(do_resolved_contract_preserves_canonical_trait_ids),
    surface_case!(do_infers_carrier_from_each_monadic_origin),
    surface_case!(do_rejects_ambiguous_and_conflicting_carriers),
    surface_case!(do_mismatch_reasons_follow_relation_owner),
    surface_case!(do_generated_bind_closure_preserves_expected_relation_owner),
    surface_case!(do_expected_relation_does_not_override_user_branch_mismatch),
    surface_case!(do_uses_generic_monad_capability_without_binding_rigid_carrier),
    surface_case!(do_extract_lowers_to_concrete_monad_dispatch),
    surface_case!(do_total_extract_allows_mapped_payload_changes),
    surface_case!(do_sequences_unit_payloads),
    surface_case!(do_partial_extract_requires_alternative),
    surface_case!(do_rigid_monad_requires_explicit_alternative_bound),
    surface_case!(do_ordinary_binding_is_not_a_monadic_origin),
    surface_case!(do_final_expression_still_requires_monad),
    surface_case!(do_concrete_non_monad_reason_is_independent_of_origin),
    surface_case!(do_safebind_selects_typed_failure_targets),
    surface_case!(do_safebind_preserves_n06_and_carrier_boundaries),
    surface_case!(do_safebind_return_mismatch_points_to_the_final_expression),
    surface_case!(do_partial_extract_rejects_carriers_without_alternative),
    surface_case!(do_generated_bind_closure_keeps_facet_source_scope),
    surface_case!(do_extract_accepts_fallible_facet_nominal_payload),
    surface_case!(do_extract_accepts_structural_facet_on_result_source),
    surface_case!(do_extract_accepts_variant_facet_payload_shapes),
    surface_case!(do_facet_extract_preserves_caller_payload_capability),
    surface_case!(facet_result_preserves_payload_carrier_capability),
    surface_case!(do_implicit_bind_inputs_preserve_payload_views),
    surface_case!(generic_callbacks_preserve_input_views_in_either_argument_order),
    surface_case!(contextual_callbacks_preserve_implicit_payload_views),
    surface_case!(captured_contextual_callbacks_preserve_payload_views),
    surface_case!(fixed_nominal_callback_parameters_keep_independent_views),
    surface_case!(rigid_callback_payloads_keep_declared_constructor_capability),
    (
        "trailing_block_calls_typecheck_inside_script_module_scope",
        trailing_block_calls_typecheck_inside_script_module_scope as fn(),
    ),
    (
        "set_exit_code_is_allowed_in_script_rules",
        set_exit_code_is_allowed_in_script_rules as fn(),
    ),
    (
        "set_exit_code_is_forbidden_in_repl_chunk_rules",
        set_exit_code_is_forbidden_in_repl_chunk_rules as fn(),
    ),
    (
        "set_exit_code_entry_only_policy_allows_only_entrypoint_function",
        set_exit_code_entry_only_policy_allows_only_entrypoint_function as fn(),
    ),
    (
        "require_standard_call_typechecks_to_result_unit",
        require_standard_call_typechecks_to_result_unit as fn(),
    ),
    (
        "bitwidth_zero_arg_variant_reference_reuses_std_enum_constructor_uid",
        bitwidth_zero_arg_variant_reference_reuses_std_enum_constructor_uid as fn(),
    ),
    (
        "bitwidth_zero_arg_variant_typechecks_with_builtin_prelude",
        bitwidth_zero_arg_variant_typechecks_with_builtin_prelude as fn(),
    ),
    (
        "ensure_standard_call_typechecks_to_result_value",
        ensure_standard_call_typechecks_to_result_value as fn(),
    ),
    (
        "and_special_form_typechecks_to_boolean_if",
        and_special_form_typechecks_to_boolean_if as fn(),
    ),
    (
        "eq_helper_typechecks_as_trait_call",
        eq_helper_typechecks_as_trait_call as fn(),
    ),
    (
        "eq_helper_mismatch_uses_shared_reason",
        eq_helper_mismatch_uses_shared_reason as fn(),
    ),
    (
        "shadowed_compare_keeps_generic_call_mismatch_message",
        shadowed_compare_keeps_generic_call_mismatch_message as fn(),
    ),
    (
        "concat_helper_typechecks_as_trait_call",
        concat_helper_typechecks_as_trait_call as fn(),
    ),
    (
        "to_string_helper_typechecks_as_trait_call",
        to_string_helper_typechecks_as_trait_call as fn(),
    ),
    (
        "ensure_rejects_call_expression_predicate",
        ensure_rejects_call_expression_predicate as fn(),
    ),
    (
        "require_rejects_non_concrete_error_expression",
        require_rejects_non_concrete_error_expression as fn(),
    ),
    (
        "kernel_and_contract_rejects_eager_signature",
        kernel_and_contract_rejects_eager_signature as fn(),
    ),
    (
        "removed_if_builtin_declaration_is_rejected",
        removed_if_builtin_declaration_is_rejected as fn(),
    ),
    (
        "kernel_does_not_allow_removed_concat_builtin",
        kernel_does_not_allow_removed_concat_builtin as fn(),
    ),
    (
        "if_auto_forces_zero_arg_closure_once_for_branch_type",
        if_auto_forces_zero_arg_closure_once_for_branch_type as fn(),
    ),
    (
        "if_nested_closure_is_not_deep_forced",
        if_nested_closure_is_not_deep_forced as fn(),
    ),
    (
        "user_lazy_annotation_is_rejected",
        user_lazy_annotation_is_rejected as fn(),
    ),
    (
        "require_accepts_lazy_error_branch",
        require_accepts_lazy_error_branch as fn(),
    ),
    (
        "ensure_accepts_lazy_error_branch",
        ensure_accepts_lazy_error_branch as fn(),
    ),
    (
        "require_accepts_existing_error_value",
        require_accepts_existing_error_value as fn(),
    ),
    (
        "ensure_accepts_existing_error_value",
        ensure_accepts_existing_error_value as fn(),
    ),
    (
        "generic_annotation_list_int_is_accepted",
        generic_annotation_list_int_is_accepted as fn(),
    ),
    (
        "generic_def_signature_instantiates_per_call_site",
        generic_def_signature_instantiates_per_call_site as fn(),
    ),
    (
        "generic_defenum_constructor_and_match_typecheck",
        generic_defenum_constructor_and_match_typecheck as fn(),
    ),
    (
        "closure_param_annotation_without_expected_type_constrains_calls",
        closure_param_annotation_without_expected_type_constrains_calls as fn(),
    ),
    (
        "closure_application_mismatch_reports_callable_type_signature",
        closure_application_mismatch_reports_callable_type_signature as fn(),
    ),
    (
        "builtin_function_arity_reports_call_target_signature",
        builtin_function_arity_reports_call_target_signature as fn(),
    ),
    (
        "builtin_function_mismatch_reports_call_target_signature",
        builtin_function_mismatch_reports_call_target_signature as fn(),
    ),
    (
        "capture_application_mismatch_reports_callable_type_signature",
        capture_application_mismatch_reports_callable_type_signature as fn(),
    ),
    (
        "script_callable_signature_omits_file_path_segments",
        script_callable_signature_omits_file_path_segments as fn(),
    ),
    (
        "compose_mismatch_reports_left_and_right_callable_types",
        compose_mismatch_reports_left_and_right_callable_types as fn(),
    ),
    (
        "compose_accepts_calls_returning_function_values",
        compose_accepts_calls_returning_function_values as fn(),
    ),
    (
        "compose_rejects_non_function_call_results_after_typechecking_call",
        compose_rejects_non_function_call_results_after_typechecking_call as fn(),
    ),
    (
        "closure_trait_helper_binding_requires_concrete_callable_boundary",
        closure_trait_helper_binding_requires_concrete_callable_boundary as fn(),
    ),
    (
        "closure_trait_helper_binding_accepts_binding_annotation",
        closure_trait_helper_binding_accepts_binding_annotation as fn(),
    ),
    (
        "closure_trait_helper_binding_accepts_parameter_annotations",
        closure_trait_helper_binding_accepts_parameter_annotations as fn(),
    ),
    (
        "on_call_concretizes_closure_trait_helper_from_key_function",
        on_call_concretizes_closure_trait_helper_from_key_function as fn(),
    ),
    (
        "on_call_concretizes_trait_helper_capture_from_key_function",
        on_call_concretizes_trait_helper_capture_from_key_function as fn(),
    ),
    (
        "pipe_plain_apply_over_result_reports_whole_lhs_mismatch",
        pipe_plain_apply_over_result_reports_whole_lhs_mismatch as fn(),
    ),
    (
        "context_bind_rejects_plain_rhs_return",
        context_bind_rejects_plain_rhs_return as fn(),
    ),
    (
        "constructor_context_bind_preserves_candidate_failures",
        constructor_context_bind_preserves_candidate_failures as fn(),
    ),
    (
        "constructor_context_bind_rolls_back_rejected_candidates",
        constructor_context_bind_rolls_back_rejected_candidates as fn(),
    ),
    (
        "context_bind_rhs_closure_receives_result_return_expectation",
        context_bind_rhs_closure_receives_result_return_expectation as fn(),
    ),
    (
        "safebind_pipe_bind_closure_receives_expected_result_return",
        safebind_pipe_bind_closure_receives_expected_result_return as fn(),
    ),
    (
        "apply_and_map_rhs_closures_receive_whole_expression_return_expectation",
        apply_and_map_rhs_closures_receive_whole_expression_return_expectation as fn(),
    ),
    (
        "safebind_pipe_apply_annotated_closure_receives_expected_result_return",
        safebind_pipe_apply_annotated_closure_receives_expected_result_return as fn(),
    ),
    (
        "safebind_pipe_map_annotated_closure_receives_expected_result_return",
        safebind_pipe_map_annotated_closure_receives_expected_result_return as fn(),
    ),
    (
        "kleisli_compose_closures_receive_result_return_expectation",
        kleisli_compose_closures_receive_result_return_expectation as fn(),
    ),
    (
        "safebind_kleisli_annotated_closure_receives_expected_result_return",
        safebind_kleisli_annotated_closure_receives_expected_result_return as fn(),
    ),
    (
        "lifted_compose_rhs_closure_allows_explicit_nested_result_expectation",
        lifted_compose_rhs_closure_allows_explicit_nested_result_expectation as fn(),
    ),
    (
        "context_map_keeps_result_for_later_bind",
        context_map_keeps_result_for_later_bind as fn(),
    ),
    (
        "context_map_and_bind_lower_to_operator_trait_calls",
        context_map_and_bind_lower_to_operator_trait_calls as fn(),
    ),
    (
        "explicit_functor_call_has_explicit_origin",
        explicit_functor_call_has_explicit_origin as fn(),
    ),
    (
        "flow_apply_and_compose_operators_lower_to_trait_calls",
        flow_apply_and_compose_operators_lower_to_trait_calls as fn(),
    ),
    (
        "plain_flow_operators_use_compiler_rules",
        plain_flow_operators_use_compiler_rules as fn(),
    ),
    (
        "user_defined_container_can_use_context_operators_via_traits",
        user_defined_container_can_use_context_operators_via_traits as fn(),
    ),
    (
        "result_match_wildcard_self_after_ok_can_change_ok_payload_type",
        result_match_wildcard_self_after_ok_can_change_ok_payload_type as fn(),
    ),
    surface_case!(result_match_wildcard_self_after_ok_or_can_change_ok_payload_type),
    (
        "result_match_wildcard_self_after_ok_can_keep_err_for_bind_shape",
        result_match_wildcard_self_after_ok_can_keep_err_for_bind_shape as fn(),
    ),
    (
        "result_match_wildcard_self_requires_err_proven_branch",
        result_match_wildcard_self_requires_err_proven_branch as fn(),
    ),
    (
        "closure_param_annotation_must_match_expected_signature",
        closure_param_annotation_must_match_expected_signature as fn(),
    ),
    (
        "local_binding_annotation_can_reference_outer_generic_type_param",
        local_binding_annotation_can_reference_outer_generic_type_param as fn(),
    ),
    (
        "closure_param_annotation_can_reference_outer_generic_type_param",
        closure_param_annotation_can_reference_outer_generic_type_param as fn(),
    ),
    (
        "generic_first_can_inline_tuple_rebuild_with_closure_param_annotation",
        generic_first_can_inline_tuple_rebuild_with_closure_param_annotation as fn(),
    ),
    (
        "sibling_closures_keep_substitution_state_local",
        sibling_closures_keep_substitution_state_local as fn(),
    ),
    (
        "cyclic_type_definition_is_rejected",
        cyclic_type_definition_is_rejected as fn(),
    ),
    (
        "enum_cycle_is_allowed_when_not_shared_by_all_variants",
        enum_cycle_is_allowed_when_not_shared_by_all_variants as fn(),
    ),
    (
        "enum_cycle_is_rejected_when_shared_by_all_variants",
        enum_cycle_is_rejected_when_shared_by_all_variants as fn(),
    ),
    (
        "enum_field_access_is_rejected",
        enum_field_access_is_rejected as fn(),
    ),
    (
        "match_binding_pattern_is_treated_as_exhaustive",
        match_binding_pattern_is_treated_as_exhaustive as fn(),
    ),
    (
        "match_tuple_binding_pattern_is_treated_as_exhaustive",
        match_tuple_binding_pattern_is_treated_as_exhaustive as fn(),
    ),
    (
        "match_guard_must_be_boolean",
        match_guard_must_be_boolean as fn(),
    ),
    (
        "guarded_match_arm_does_not_satisfy_exhaustiveness",
        guarded_match_arm_does_not_satisfy_exhaustiveness as fn(),
    ),
    (
        "struct_literal_rejects_extra_fields",
        struct_literal_rejects_extra_fields as fn(),
    ),
    (
        "constructor_named_args_reject_duplicate_fields",
        constructor_named_args_reject_duplicate_fields as fn(),
    ),
    (
        "struct_literal_field_shorthand_typechecks",
        struct_literal_field_shorthand_typechecks as fn(),
    ),
    (
        "struct_literal_field_shorthand_mixed_with_explicit_typechecks",
        struct_literal_field_shorthand_mixed_with_explicit_typechecks as fn(),
    ),
    (
        "struct_literal_field_shorthand_rejects_duplicate_fields",
        struct_literal_field_shorthand_rejects_duplicate_fields as fn(),
    ),
    ("struct_requires_impl_new", struct_requires_impl_new as fn()),
    (
        "generic_struct_bare_annotation_requires_type_args",
        generic_struct_bare_annotation_requires_type_args as fn(),
    ),
    (
        "generic_struct_arity_mismatch_is_rejected",
        generic_struct_arity_mismatch_is_rejected as fn(),
    ),
    (
        "struct_new_accepts_result_self_return_type",
        struct_new_accepts_result_self_return_type as fn(),
    ),
    (
        "struct_new_rejects_non_self_return_type",
        struct_new_rejects_non_self_return_type as fn(),
    ),
    (
        "struct_new_rejects_result_non_self_payload",
        struct_new_rejects_result_non_self_payload as fn(),
    ),
    (
        "struct_constructor_call_accepts_result_return_type",
        struct_constructor_call_accepts_result_return_type as fn(),
    ),
    (
        "struct_literal_is_rejected_outside_impl_body",
        struct_literal_is_rejected_outside_impl_body as fn(),
    ),
    (
        "user_function_call_rejects_mixed_named_and_positional_args",
        user_function_call_rejects_mixed_named_and_positional_args as fn(),
    ),
    (
        "user_function_call_rejects_duplicate_named_arg",
        user_function_call_rejects_duplicate_named_arg as fn(),
    ),
    (
        "impl_self_rebinding_allows_self_type",
        impl_self_rebinding_allows_self_type as fn(),
    ),
    (
        "impl_self_rebinding_rejects_non_self_type",
        impl_self_rebinding_rejects_non_self_type as fn(),
    ),
    (
        "deferror_show_type_mismatch_points_to_show_expression_span",
        deferror_show_type_mismatch_points_to_show_expression_span as fn(),
    ),
    (
        "operator_traits_and_concrete_numeric_helpers_typecheck",
        operator_traits_and_concrete_numeric_helpers_typecheck as fn(),
    ),
    (
        "duration_operator_traits_dispatch_to_surtr_impls",
        duration_operator_traits_dispatch_to_surtr_impls as fn(),
    ),
    (
        "bounded_add_generics_specialize_without_pending_trait_calls",
        bounded_add_generics_specialize_without_pending_trait_calls as fn(),
    ),
    (
        "range_duration_comparisons_specialize_without_pending_trait_calls",
        range_duration_comparisons_specialize_without_pending_trait_calls as fn(),
    ),
    (
        "generic_struct_constructor_calls_remain_polymorphic_within_closure_body",
        generic_struct_constructor_calls_remain_polymorphic_within_closure_body as fn(),
    ),
    (
        "generic_struct_constructor_calls_remain_polymorphic_within_one_source",
        generic_struct_constructor_calls_remain_polymorphic_within_one_source as fn(),
    ),
    (
        "scar_session_preserves_trait_registry_across_chunks",
        scar_session_preserves_trait_registry_across_chunks as fn(),
    ),
    (
        "add_trait_mismatch_retains_typed_signature_relation",
        add_trait_mismatch_retains_typed_signature_relation as fn(),
    ),
    (
        "trait_method_call_rejects_named_arguments_without_panic",
        trait_method_call_rejects_named_arguments_without_panic as fn(),
    ),
    (
        "add_trait_missing_receiver_retains_obligation",
        add_trait_missing_receiver_retains_obligation as fn(),
    ),
    (
        "add_operator_missing_impl_retains_obligation",
        add_operator_missing_impl_retains_obligation as fn(),
    ),
    (
        "bind_operator_missing_impl_retains_obligation",
        bind_operator_missing_impl_retains_obligation as fn(),
    ),
    (
        "to_helper_typechecks_as_generic_trait_call",
        to_helper_typechecks_as_generic_trait_call as fn(),
    ),
    (
        "try_to_helper_typechecks_as_generic_trait_call",
        try_to_helper_typechecks_as_generic_trait_call as fn(),
    ),
    (
        "conversion_helpers_support_qualified_calls_and_captures",
        conversion_helpers_support_qualified_calls_and_captures as fn(),
    ),
    (
        "encode_helper_typechecks_as_generic_trait_call",
        encode_helper_typechecks_as_generic_trait_call as fn(),
    ),
    (
        "json_value_encode_source_alias_typechecks",
        json_value_encode_source_alias_typechecks as fn(),
    ),
    (
        "decode_helper_typechecks_explicit_target",
        decode_helper_typechecks_explicit_target as fn(),
    ),
    (
        "decode_helper_inside_decode_impl_dispatches_by_receiver_and_target",
        decode_helper_inside_decode_impl_dispatches_by_receiver_and_target as fn(),
    ),
    (
        "decode_helper_allows_same_pattern_recursive_dispatch",
        decode_helper_allows_same_pattern_recursive_dispatch as fn(),
    ),
    (
        "encode_helper_dispatches_to_receiver_impl_with_json_value_target",
        encode_helper_dispatches_to_receiver_impl_with_json_value_target as fn(),
    ),
    (
        "encode_helper_allows_same_pattern_recursive_dispatch",
        encode_helper_allows_same_pattern_recursive_dispatch as fn(),
    ),
    (
        "to_helper_suggests_try_to_when_only_fallible_impl_exists",
        to_helper_suggests_try_to_when_only_fallible_impl_exists as fn(),
    ),
    (
        "try_to_helper_suggests_to_when_only_infallible_impl_exists",
        try_to_helper_suggests_to_when_only_infallible_impl_exists as fn(),
    ),
    (
        "to_and_try_to_impls_are_mutually_exclusive",
        to_and_try_to_impls_are_mutually_exclusive as fn(),
    ),
    (
        "process_sleep_accepts_duration_literal",
        process_sleep_accepts_duration_literal as fn(),
    ),
    (
        "process_self_is_rejected_outside_process_context",
        process_self_is_rejected_outside_process_context as fn(),
    ),
    (
        "process_self_typechecks_inside_process_handler",
        process_self_typechecks_inside_process_handler as fn(),
    ),
    (
        "singleton_agent_pid_surface_returns_concrete_pid",
        singleton_agent_pid_surface_returns_concrete_pid as fn(),
    ),
    (
        "singleton_genserver_pid_surface_returns_concrete_pid",
        singleton_genserver_pid_surface_returns_concrete_pid as fn(),
    ),
    (
        "singleton_agent_explicit_pid_call_typechecks",
        singleton_agent_explicit_pid_call_typechecks as fn(),
    ),
    (
        "genserver_additional_call_handler_typechecks_as_process_context",
        genserver_additional_call_handler_typechecks_as_process_context as fn(),
    ),
    (
        "genserver_call_handler_accepts_call_result_contract",
        genserver_call_handler_accepts_call_result_contract as fn(),
    ),
    (
        "process_meta_state_mismatch_is_rejected",
        process_meta_state_mismatch_is_rejected as fn(),
    ),
    (
        "user_defined_process_state_can_appear_in_public_signatures",
        user_defined_process_state_can_appear_in_public_signatures as fn(),
    ),
    (
        "typecheck_staged_program_keeps_process_specs",
        typecheck_staged_program_keeps_process_specs as fn(),
    ),
    (
        "dynsup_spawn_accepts_worker_init_route_reference",
        dynsup_spawn_accepts_worker_init_route_reference as fn(),
    ),
    (
        "custom_supervisor_spawn_accepts_worker_init_route_reference",
        custom_supervisor_spawn_accepts_worker_init_route_reference as fn(),
    ),
    (
        "supervisor_spawn_rejects_plain_closure_argument",
        supervisor_spawn_rejects_plain_closure_argument as fn(),
    ),
    (
        "supervisor_spawn_rejects_non_worker_callable",
        supervisor_spawn_rejects_non_worker_callable as fn(),
    ),
    (
        "supervisor_adopt_accepts_worker_pid",
        supervisor_adopt_accepts_worker_pid as fn(),
    ),
    (
        "supervisor_adopt_rejects_non_pid_argument",
        supervisor_adopt_rejects_non_pid_argument as fn(),
    ),
    (
        "supervisor_adopt_rejects_when_policy_disallows_it",
        supervisor_adopt_rejects_when_policy_disallows_it as fn(),
    ),
    (
        "supervisor_status_returns_supervisor_status",
        supervisor_status_returns_supervisor_status as fn(),
    ),
    (
        "supervisor_workers_returns_workers_handle",
        supervisor_workers_returns_workers_handle as fn(),
    ),
    (
        "workers_submit_accepts_worker_message_template",
        workers_submit_accepts_worker_message_template as fn(),
    ),
    (
        "workers_broadcast_accepts_worker_message_template",
        workers_broadcast_accepts_worker_message_template as fn(),
    ),
    (
        "task_await_accepts_task_handle",
        task_await_accepts_task_handle as fn(),
    ),
    (
        "workers_reserve_can_flow_into_worker_call",
        workers_reserve_can_flow_into_worker_call as fn(),
    ),
    (
        "tap_err_accepts_local_error_observer_binding",
        tap_err_accepts_local_error_observer_binding as fn(),
    ),
    (
        "tap_err_accepts_error_observer_captures_and_composition",
        tap_err_accepts_error_observer_captures_and_composition as fn(),
    ),
    (
        "error_observer_binding_can_escape_as_plain_value",
        error_observer_binding_can_escape_as_plain_value as fn(),
    ),
    (
        "error_observer_binding_can_be_called_directly",
        error_observer_binding_can_be_called_directly as fn(),
    ),
    (
        "error_observer_binding_can_use_error_annotation",
        error_observer_binding_can_use_error_annotation as fn(),
    ),
    (
        "error_observer_closure_param_can_use_error_annotation",
        error_observer_closure_param_can_use_error_annotation as fn(),
    ),
    (
        "error_observer_binding_can_flow_through_generic_identity",
        error_observer_binding_can_flow_through_generic_identity as fn(),
    ),
    (
        "type_kinds_map_to_compile_space_identities",
        type_kinds_map_to_compile_space_identities as fn(),
    ),
    surface_case!(facet_preview_accepts_boolean_variant_root),
    surface_case!(facet_root_dispatch_requires_symbol_capability_metadata_not_matching_names),
    surface_case!(facet_root_capability_dispatch_preserves_standard_roots_and_string_diagnostic),
    surface_case!(deferred_list_and_hashmap_facet_bindings_can_be_reused_by_facet_intrinsics),
    surface_case!(overlapping_trait_impl_patterns_are_rejected_before_codegen),
    surface_case!(disjoint_specializations_with_the_same_nominal_target_typecheck),
    surface_case!(conversion_impl_exclusivity_ignores_generic_parameter_names),
    surface_case!(conversion_impl_exclusivity_rejects_generic_concrete_overlap),
    surface_case!(conversion_impl_exclusivity_rejects_nested_overlap),
    surface_case!(conversion_impl_exclusivity_is_declaration_order_independent),
    surface_case!(conversion_impl_exclusivity_allows_disjoint_pairs),
    surface_case!(local_callable_binding_requires_concrete_signature),
    surface_case!(local_callable_binding_accepts_outer_rigid_generic),
    surface_case!(annotated_local_callable_remains_monomorphic),
    surface_case!(unbound_generic_argument_synthesizes_closure_shape),
    surface_case!(direct_generic_capture_uses_higher_order_expected_type),
    surface_case!(generic_capture_binding_requires_concrete_signature),
    surface_case!(expected_type_flows_to_if_and_match_branches),
    surface_case!(trait_dispatch_rejects_impl_with_unsatisfied_where_obligation),
    surface_case!(direct_trait_call_on_rigid_generic_requires_declared_bound),
    surface_case!(deferred_trait_obligation_is_checked_when_closure_argument_is_bound),
    surface_case!(child_impl_where_assumptions_cover_parent_impl_requirements),
    surface_case!(child_impl_self_where_assumption_covers_parent_requirement),
    surface_case!(parameterized_parent_trait_bounds_cover_the_parent_family),
    surface_case!(function_where_bounds_propagate_to_generic_call_sites),
    surface_case!(where_clause_does_not_declare_a_new_type_variable),
    surface_case!(functor_shaped_self_applications_survive_in_typed_metadata),
    surface_case!(unary_type_constructor_slot_is_inferred_for_trait_impl),
    surface_case!(multi_parameter_type_constructor_requires_explicit_slot_mapping),
    surface_case!(type_constructor_constraint_rejects_concrete_and_duplicate_slot_targets),
    surface_case!(malformed_resolved_type_shape_requires_self_lhs),
    surface_case!(malformed_resolved_type_shape_is_rejected_outside_trait_definition_where),
    surface_case!(type_constructor_shape_must_be_unique_in_a_trait_definition),
    surface_case!(inherited_constructor_trait_accepts_captured_head_parameters),
    surface_case!(constructor_slot_maps_require_top_level_target_parameters_and_completeness),
    surface_case!(plain_inherent_owner_expands_self_applications_to_its_target),
    surface_case!(canonical_builtin_inherent_owners_expand_self_applications_to_their_targets),
    surface_case!(trait_contract_self_substitution_preserves_captured_target_parameters),
    surface_case!(same_trait_constructor_parameters_share_one_witness),
    surface_case!(constructor_application_result_shares_the_input_witness),
    surface_case!(constructor_application_result_accepts_the_shared_abstract_input_witness),
    surface_case!(constructor_application_result_rejects_mixed_concrete_constructors),
    surface_case!(
        identity_dependent_constructor_applications_are_rejected_outside_direct_signatures
    ),
    surface_case!(extractor_signatures_reject_identity_dependent_constructor_applications),
    surface_case!(trait_default_contextual_result_requires_constructor_trait_membership),
    surface_case!(trait_impl_contextual_result_requires_constructor_trait_membership),
    surface_case!(trait_impl_contextual_result_accepts_an_implementing_constructor),
    surface_case!(bare_capability_is_consumed_by_a_full_parameterized_trait_obligation),
    surface_case!(unused_function_capability_is_rejected_at_its_bound),
    surface_case!(unused_trait_method_capability_is_rejected_at_its_bound),
    surface_case!(unused_trait_impl_method_capability_is_rejected_at_its_bound),
    surface_case!(unused_trait_impl_block_capability_is_rejected_after_all_methods),
    surface_case!(operator_obligation_consumes_a_bare_capability),
    surface_case!(generic_call_forwards_and_consumes_a_bare_capability),
    surface_case!(different_constructor_roots_keep_independent_parameter_witnesses),
    surface_case!(parent_trait_constraints_require_matching_impls_and_inherit_slots),
    surface_case!(concrete_constructor_implementation_can_be_passed_to_parent_or_child_trait),
    surface_case!(abstract_applicative_cannot_use_monad_helper_but_concrete_option_can),
    surface_case!(trait_default_methods_and_private_helpers_are_accepted),
    surface_case!(parent_trait_cycles_and_slot_mapping_mismatches_are_rejected),
    surface_case!(trait_impl_signature_validation_preserves_generic_relationships),
    surface_case!(trait_impl_method_generics_are_rigid_while_checking_the_body),
    surface_case!(empty_struct_default_derives_without_relaxing_new_contract),
    surface_case!(empty_struct_without_new_is_rejected),
    surface_case!(empty_struct_eq_and_neq_are_constant),
    surface_case!(empty_struct_compare_is_equal),
    surface_case!(compare_default_methods_dispatch_to_trait_source_when_impl_omits_override),
    surface_case!(compare_trait_impl_still_requires_compare_method),
    surface_case!(explicit_type_arguments_specialize_functions_trait_calls_and_captures),
    surface_case!(enum_constructor_partial_type_arguments_constrain_only_their_own_slots),
    surface_case!(regular_callable_rejects_undeclared_return_type_arguments),
    surface_case!(bare_trait_capability_controls_full_parameterized_dispatch),
    surface_case!(trait_heads_and_expression_obligations_retain_nested_arguments),
    surface_case!(impl_bare_capabilities_emit_full_parameterized_obligations),
    surface_case!(explicit_type_arguments_exclude_self_and_enforce_generic_arity),
    surface_case!(
        trait_method_type_slots_have_one_input_channel_and_return_type_arguments_flow_to_return
    ),
    surface_case!(trait_impl_return_type_arguments_must_match_the_trait_slots),
    surface_case!(explicit_function_type_arguments_follow_signature_order),
    surface_case!(match_result_extractor_contract_boundaries),
    surface_case!(match_result_extractor_rejects_ordinary_value_uses),
    surface_case!(match_result_extractor_uses_own_safebind_target),
    surface_case!(match_result_unitonly_rejects_wrong_child_shapes),
    surface_case!(match_result_payload_shape_must_be_resolved_before_execution),
    surface_case!(extractor_prearguments_follow_signature_and_infer_payload_shape),
    surface_case!(extractor_target_requires_concrete_type_head),
    surface_case!(extractor_target_accepts_generic_arguments_under_concrete_head),
    surface_case!(extractor_closure_inference_and_callable_boundaries),
    surface_case!(extractor_closure_direct_argument_uses_expected_type),
    surface_case!(apply_pattern_projection_types_and_boundaries),
    surface_case!(error_contract_surface_is_restricted_to_direct_definition_returns),
    surface_case!(facet_pending_dispatch_collects_path_type_inputs),
    surface_case!(nested_ordinary_match_blocks_typecheck),
    surface_case!(nested_user_closures_typecheck_do_binds_and_captures),
    surface_case!(nested_do_closure_mismatch_keeps_original_source_facts),
];

#[test]
fn surface_case_inventory_has_unique_names_and_functions() {
    let direct_tests = include_str!("typecheck_surface.rs")
        .lines()
        .filter(|line| *line == "#[test]")
        .count();
    assert_eq!(
        direct_tests, 1,
        "Scar surface cases must be registered instead of using standalone #[test]"
    );

    let mut names = HashSet::new();
    let mut functions = HashSet::new();

    for &(name, residue, modulus) in SURFACE_PARTITIONS {
        assert!(modulus > 0, "invalid surface partition modulus: {name}");
        assert!(
            residue < modulus,
            "invalid surface partition residue: {name}"
        );
        assert!(
            (0..SURFACE_CASES.len()).any(|index| index % modulus == residue),
            "empty Scar surface partition: {name}"
        );
    }

    for (index, &(name, case)) in SURFACE_CASES.iter().enumerate() {
        assert!(
            names.insert(name),
            "duplicate Scar surface case name: {name}"
        );
        assert!(
            functions.insert(case as usize),
            "duplicate Scar surface case function: {name}"
        );
        assert_eq!(
            SURFACE_PARTITIONS
                .iter()
                .filter(|&&(_, residue, modulus)| index % modulus == residue)
                .count(),
            1,
            "Scar surface case must belong to exactly one partition: {name}"
        );
    }
}

macro_rules! surface_bucket_tests {
    ($(($name:ident, $residue:expr, $modulus:expr)),+ $(,)?) => {
        const SURFACE_PARTITIONS: &[(&str, usize, usize)] = &[
            $((stringify!($name), $residue, $modulus)),+
        ];

        $(
            #[test]
            fn $name() {
                run_surface_case_bucket($residue, $modulus);
            }
        )+
    };
}

// Split only the slower original buckets; retain every case in its original order.
surface_bucket_tests!(
    (typecheck_surface_bucket_0_a, 0, 16),
    (typecheck_surface_bucket_0_b, 8, 16),
    (typecheck_surface_bucket_1, 1, 8),
    (typecheck_surface_bucket_2, 2, 8),
    (typecheck_surface_bucket_3_a, 3, 16),
    (typecheck_surface_bucket_3_b, 11, 16),
    (typecheck_surface_bucket_4, 4, 8),
    (typecheck_surface_bucket_5, 5, 8),
    (typecheck_surface_bucket_6_a, 6, 16),
    (typecheck_surface_bucket_6_b, 14, 16),
    (typecheck_surface_bucket_7_a, 7, 16),
    (typecheck_surface_bucket_7_b, 15, 16),
);

fn run_surface_case_bucket(bucket: usize, bucket_count: usize) {
    assert!(bucket_count > 0, "bucket_count must be positive");
    assert!(
        bucket < bucket_count,
        "bucket {bucket} out of range {bucket_count}"
    );

    let case_indices = SURFACE_CASES
        .iter()
        .enumerate()
        .filter_map(|(idx, _)| (idx % bucket_count == bucket).then_some(idx))
        .collect::<Vec<_>>();
    assert!(
        !case_indices.is_empty(),
        "no scar surface cases assigned to bucket {bucket} of {bucket_count}"
    );

    let previous_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(|_| {}));

    let next_case = AtomicUsize::new(0);
    let failed = AtomicBool::new(false);
    let failures = Mutex::new(Vec::new());

    std::thread::scope(|scope| {
        for _ in 0..SURFACE_WORKER_COUNT {
            scope.spawn(|| loop {
                if failed.load(Ordering::Relaxed) {
                    break;
                }
                let position = next_case.fetch_add(1, Ordering::Relaxed);
                let Some(idx) = case_indices.get(position).copied() else {
                    break;
                };
                let Some((name, case)) = SURFACE_CASES.get(idx) else {
                    break;
                };
                if let Err(payload) = std::panic::catch_unwind(*case) {
                    failed.store(true, Ordering::Relaxed);
                    failures.lock().expect("failure lock").push(format!(
                        "{name}: {}",
                        panic_payload_message(payload.as_ref())
                    ));
                    break;
                }
            });
        }
    });

    std::panic::set_hook(previous_hook);

    let failures = failures.into_inner().expect("failure lock");
    if !failures.is_empty() {
        panic!(
            "{} scar surface case(s) failed in bucket {}/{}:\n{}",
            failures.len(),
            bucket,
            bucket_count,
            failures.join("\n")
        );
    }
}

fn panic_payload_message(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        (*message).to_owned()
    } else if let Some(message) = payload.downcast_ref::<String>() {
        message.clone()
    } else {
        "non-string panic payload".to_owned()
    }
}

fn typed_bind_rhs<'a>(typed: &'a [TypedNode], name: &str) -> &'a TypedNode {
    typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs)
            | TypedInner::SafeBind(pattern, rhs, _, _)
                if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == name) =>
            {
                Some(rhs.as_ref())
            }
            _ => None,
        })
        .unwrap_or_else(|| panic!("expected binding `{name}`"))
}

fn resolved_test_id(name: &str, unique_id: u32, span: &Span) -> ResolvedId {
    ResolvedId {
        name: name.into(),
        qualified_name: None,
        symbol_info: None,
        unique_id,
        compiler_generated: false,
        span: span.clone(),
    }
}

fn resolved_bracket_segment(expr: Resolved, display: &str) -> ResolvedFacetPathSegment {
    ResolvedFacetPathSegment::Bracket(ResolvedFacetBracketExpr {
        expr: Box::new(expr),
        display: display.into(),
    })
}

fn type_kinds_map_to_compile_space_identities() {
    for (kind, expected) in [
        (TypeKind::Struct, TypeIdentity::Struct),
        (TypeKind::Record, TypeIdentity::Record),
        (TypeKind::Enum, TypeIdentity::Enum),
        (TypeKind::ConcreteError, TypeIdentity::Error),
    ] {
        assert_eq!(kind.identity(), expected);
    }
}

fn process_stdlib_no_longer_declares_task_hidden_lower_helpers() {
    for hidden_name in [
        "__task_call",
        "__task_async",
        "__task_launch",
        "__task_cast",
        "__task_call_timeout",
        "__task_async_timeout",
        "__task_launch_timeout",
        "__task_cast_timeout",
        "__workers_submit",
        "__workers_broadcast",
        "__workers_reserve",
        "__workers_size",
    ] {
        assert!(
            !PROCESS_MODULE_SOURCE.contains(hidden_name),
            "process stdlib should not declare {hidden_name}"
        );
    }
}

fn process_stdlib_declares_common_process_family_modules() {
    for module_name in ["defmod Supervisor", "defmod GenServer", "defmod Agent"] {
        assert!(
            PROCESS_MODULE_SOURCE.contains(module_name),
            "process stdlib should declare {module_name}"
        );
    }
}

fn process_module_source(name: &str) -> String {
    let ast = spire::parse_with_context(
        PROCESS_MODULE_SOURCE,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    )
    .expect("process standard source should parse");
    let span = ast
        .into_iter()
        .find_map(|node| match node {
            spire::ast::Ast::Defmod(span, module_name, _, _)
                if module_name == format!("Global::{name}") =>
            {
                Some(span)
            }
            _ => None,
        })
        .unwrap_or_else(|| panic!("{name} module should exist"));
    PROCESS_MODULE_SOURCE
        .chars()
        .skip(span.start)
        .take(span.end - span.start)
        .collect()
}

fn process_module_only_declares_public_runtime_helpers() {
    let process_module = process_module_source("Process");

    assert!(
        !process_module.contains("@hidden"),
        "Process module should contain only directly callable public helpers"
    );
    for internal_name in [
        "__process_pid",
        "__process_spawn",
        "__process_state",
        "__process_store",
        "__process_self",
        "__process_context_handler",
        "__process_sleep",
    ] {
        assert!(
            !process_module.contains(internal_name),
            "Process module should not declare {internal_name}"
        );
    }
}

fn process_stdlib_declares_agent_lower_surface_with_regular_surface_docs() {
    let agent_module = process_module_source("Agent");

    for surface in [
        "def pid::<",
        "def spawn::<",
        "def state::<",
        "def store(",
        "def self::<",
        "def context_handler::<",
    ] {
        assert!(
            agent_module.contains(surface),
            "Agent module should declare hidden lower surface {surface}"
        );
    }
    assert!(
        agent_module.contains("Ordinary code cannot call this function directly."),
        "Agent lower docs should tell users they cannot call hidden functions directly"
    );
    assert!(
        agent_module.contains("## Regular Surface"),
        "Agent lower docs should show the regular surface"
    );
}

fn field_access_is_resolved_to_numeric_index() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
User { name: name, age: age }
  }
}

user: User = User("alice", 30)
age = user.age"#,
    );

    let typed = typecheck(resolved).expect("typecheck should succeed");
    let facet_view = typed.iter().find_map(|node| {
        if let TypedInner::Bind(_, rhs) = &node.node {
            if let TypedInner::FacetView {
                path,
                source_is_result,
                ..
            } = &rhs.node
            {
                return Some((path.clone(), *source_is_result));
            }
        }
        None
    });

    let (path, source_is_result) = facet_view.expect("expected bind rhs to be FacetView");
    assert!(!source_is_result);
    assert!(!path.may_fail);
    assert_eq!(path.segments.len(), 1);
    match &path.segments[0] {
        TypedFacetSegment::Field { field_index, .. } => assert_eq!(*field_index, 1),
        other => panic!("expected field segment, got {other:?}"),
    }
}

fn match_bool_requires_exhaustive_arms() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
print(match flag {
  True => "yes",
})"#,
    );

    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err.message.contains("Non-exhaustive match. Missing: False"));
}

fn match_bool_accepts_qualified_boolean_constructor_patterns() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
print(match flag {
  Boolean::True => "yes",
  Boolean::False => "no",
})"#,
    );

    typecheck(resolved).expect("Boolean constructor patterns should typecheck like enum variants");
}

fn match_bool_qualified_constructor_patterns_require_exhaustive_arms() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
print(match flag {
  Boolean::True => "yes",
})"#,
    );
    let err = typecheck(resolved)
        .expect_err("qualified Boolean constructor patterns should use enum exhaustiveness");
    assert!(err.message.contains("Non-exhaustive match. Missing: False"));
}

fn match_root_or_contributes_to_exhaustiveness() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
result = match flag { True | False => 1 }"#,
    );
    typecheck(resolved).expect("both Boolean alternatives cover the match");
}

fn match_root_or_as_alias_contributes_to_exhaustiveness() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
result = match flag { (True | False) @ whole => whole }"#,
    );
    typecheck(resolved).expect("OR alternatives remain exhaustive under an outer as-pattern");
}

fn if_let_or_shares_binding_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"pair = (1, 42)
result = if_let(pair, (1, x) | (2, x), x, 0)
if_let_then(pair, (1, x) | (2, x), print(to_string(x)))"#,
    );
    typecheck(resolved).expect("matching OR alternatives share one binding type");
}

fn if_let_or_rejects_different_binding_types() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum Mixed { IntCase(Int), TextCase(String) }
value: Mixed = Mixed::IntCase(1)
result = if_let(value, Mixed::IntCase(x) | Mixed::TextCase(x), 1, 0)"#,
    );
    let error = typecheck(resolved).expect_err("OR binding types must match");
    let diagnostic = error
        .structured
        .expect("OR type mismatch has structured data");
    assert_eq!(
        diagnostic.reason,
        diagnostics::DiagnosticReason::Type(diagnostics::TypeDiagnosticReason::PatternTypeMismatch)
    );
    assert!(
        matches!(&diagnostic.data, diagnostics::DiagnosticData::Pattern(data)
            if data.name.as_deref() == Some("OR pattern binding `x`")
                && data.expected_type.as_deref() == Some("Int")
                && data.actual_type.as_deref() == Some("String")),
        "{diagnostic:?}"
    );
}

fn safebind_total_pattern_rejects_plain_non_monad_rhs() {
    let resolved = resolve_with_builtin_prelude("num =? 10");
    let err = typecheck(resolved).expect_err("total non-Result scalar should be rejected");
    assert_eq!(
        err.message,
        "Int is not a SafeBind target; it is not a Monad, and only a Result RHS can be decomposed by `=?`."
    );
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonMonadRhs)
    );
    assert!(err.hint.is_none());
}

fn dbg_special_form_typechecks_to_unit() {
    let resolved = resolve_with_builtin_prelude("x = dbg!(1, \"ok\")");
    let typed = typecheck(resolved).expect("typecheck should succeed");
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected binding");

    assert_eq!(rhs.ty, Ty::Unit);
    assert!(matches!(rhs.node, TypedInner::Dbg(_)));
}

fn safebind_function_requires_result_return_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"def bad() -> Int {
  num =? Ok(1)
  num
}"#,
    );

    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err.message.contains("MonadFail is not implemented."));
}

fn safebind_result_closure_uses_nearest_callable_return_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler: (Int -> Result<Int>) = {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    typecheck(resolved).expect("Result-returning closure should allow SafeBind");
}

fn safebind_non_result_closure_is_rejected() {
    let resolved = resolve_with_builtin_prelude(
        r#"bad: (Int -> Int) = {|x|
  value =? Ok(x)
  value
}"#,
    );
    let err = typecheck(resolved).expect_err("non-Result closure should reject SafeBind");
    assert!(err.message.contains("MonadFail is not implemented."));
}

fn safebind_result_returning_annotated_closure_allows_safebind() {
    let typed = typecheck_with_builtin_prelude(
        r#"handler: (Int -> Result<Int>) = {|x|
  value =? Ok(x + 1)
  Ok(value)
}

result: Result<Int> = handler(1)"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn safebind_non_result_closure_rejects_safebind() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler: (Int -> Int) = {|x|
  value =? Ok(x + 1)
  value
}"#,
    );

    let err = typecheck(resolved).expect_err("non-Result closure should fail");
    assert!(err.message.contains("MonadFail is not implemented."));
}

fn safebind_top_ok_pattern_requires_nested_result_rhs() {
    let resolved = resolve_with_builtin_prelude(
        r#"value: Result<Int> = Ok(1)
Ok(num) =? value"#,
    );
    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err
        .message
        .contains("Constructor pattern requires an enum or Result RHS"));
}

fn safebind_top_ok_pattern_accepts_nested_result_rhs() {
    let resolved = resolve_with_builtin_prelude(
        r#"value: Result<Result<Int>> = Ok(Ok(1))
Ok(num) =? value"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::SafeBind(
            _,
            _,
            SafeBindRhsProjection::CanonicalResultOnce { .. },
            SafeBindFailureTarget::TopLevel,
        ))
    ));
}

fn safebind_partial_option_constructor_checks_the_whole_rhs() {
    let resolved = resolve_with_builtin_prelude(
        r#"value: Option<Int> = Option::Some(1)
Option::Some(num) =? value"#,
    );
    let typed = typecheck(resolved).expect("partial Option pattern should inspect the whole RHS");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::SafeBind(
            _,
            _,
            SafeBindRhsProjection::PatternInput { .. },
            SafeBindFailureTarget::TopLevel,
        ))
    ));
}

fn safebind_total_option_rhs_uses_non_result_monad_reason() {
    let resolved = resolve_with_builtin_prelude(
        r#"value: Option<Int> = Option::Some(1)
saved =? value"#,
    );
    let err = typecheck(resolved).expect_err("total Option SafeBind should be rejected");
    assert_eq!(
        err.message,
        "Option<Int> is not a SafeBind target; `=?` propagates Result-style failures, not values from another Monad. Only a Result RHS can be decomposed by `=?`."
    );
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonResultMonadRhs)
    );
    let diagnostic = err
        .structured
        .expect("SafeBind rejection should be structured");
    let diagnostics::DiagnosticData::SafeBindRelation(data) = diagnostic.data else {
        panic!("expected SafeBindRelation data");
    };
    assert!(data.lhs_is_total);
    assert!(!data.rhs_is_canonical_result);
    assert_eq!(data.monad_capability, "satisfied");
    assert!(err.hint.is_none());
}

fn safebind_annotation_mismatch_precedes_total_rhs_classification() {
    let resolved = resolve_with_builtin_prelude("num: Int =? Option::Some(10)");
    let err = typecheck(resolved).expect_err("the ordinary pattern relation should fail first");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch)
    );
    assert!(!err.message.contains("SafeBind target"));
    assert!(!err.message.contains("Result RHS"));
}

fn safebind_unbound_generic_rhs_keeps_capability_failure() {
    let resolved = resolve_with_builtin_prelude(
        r#"def reject(value: $A) -> Result<$A> {
  saved =? value
  Ok(saved)
}"#,
    );
    let err =
        typecheck(resolved).expect_err("an unbound rigid RHS must not be classified by impl count");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingGenericBound)
    );
    assert!(!matches!(
        err.reason(),
        Some(
            diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonMonadRhs
                | diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonResultMonadRhs
        )
    ));
}

fn safebind_list_pattern_accepts_plain_list_rhs() {
    let resolved = resolve_with_builtin_prelude(
        r#"value = [1, 2, 3]
[head, ..tail] =? value"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::SafeBind(_, _, _, _))
    ));
}

fn safebind_string_pattern_accepts_plain_string_rhs() {
    let resolved = resolve_with_builtin_prelude(
        r#"value = "source"
[head, ..tail] =? value"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::SafeBind(_, _, _, _))
    ));
}

fn int_range_literal_typechecks_to_list_int() {
    let resolved = resolve_with_builtin_prelude("nums = [1..3]");
    let typed = typecheck(resolved).expect("typecheck should succeed");
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected binding");
    assert_eq!(rhs.ty, Ty::List(Box::new(Ty::Int)));
}

fn string_range_literal_typechecks_to_result_list_string() {
    let resolved = resolve_with_builtin_prelude(r#"chars = ["a".."c"]"#);
    let typed = typecheck(resolved).expect("typecheck should succeed");
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected binding");
    assert_eq!(
        rhs.ty,
        Ty::Result(Box::new(Ty::List(Box::new(Ty::Str))), Box::new(Ty::Error))
    );
}

fn hash_map_literal_typechecks_string_key_expressions() {
    let resolved = resolve_with_builtin_prelude(
        r#"raw = " talk "
scores = hash!["talk" => 80, String::trim(raw) => 90]"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    let rhs = typed_bind_rhs(&typed, "scores");
    assert_eq!(rhs.ty, Ty::Enum("HashMap".into(), vec![Ty::Int]));
    assert!(matches!(rhs.node, TypedInner::HashMapLiteral(_)));
}

fn hash_map_literal_rejects_non_string_keys() {
    let resolved = resolve_with_builtin_prelude(r#"scores = hash![1 => "bad"]"#);
    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err.message.contains("HashMap literal key must be String"));
}

fn hash_map_literal_rejects_mixed_value_types() {
    let resolved = resolve_with_builtin_prelude(r#"scores = hash!["ok" => 1, "bad" => "two"]"#);
    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err.message.contains("expected Int, got String"));
}

fn match_string_requires_empty_and_uncons_arms_for_exhaustiveness() {
    let resolved = resolve_with_builtin_prelude(
        r#"value = "x"
print(match value {
  [head, ..tail] => head,
})"#,
    );

    let err = typecheck(resolved).expect_err("typecheck should fail");
    assert!(err.message.contains("Non-exhaustive match. Missing: []"));
}

fn match_string_accepts_empty_and_uncons_arms() {
    let resolved = resolve_with_builtin_prelude(
        r#"value = "x"
print(match value {
  [] => "empty",
  [head, ..tail] => tail,
})"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(!typed.is_empty());
}

fn safebind_list_pattern_accepts_nested_constructor_literals() {
    let resolved = resolve_with_builtin_prelude(
        r#"lr = [Ok(1), Ok(2), Ok(3)]
[Ok(1), Ok(2), _] =? lr"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::SafeBind(_, _, _, _))
    ));
}

fn tuple_literal_and_field_access_typecheck() {
    let resolved = resolve_with_builtin_prelude(
        r#"pair = (1, "two")
first = pair._0
second = pair._1"#,
    );
    let typed = typecheck(resolved).expect("tuple access should typecheck");
    assert!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::Bind(_, _)))
            .count()
            >= 3
    );
}

fn pair_constructor_lowered_tuple_values_typecheck_without_operator_traits() {
    let resolved = resolve_with_builtin_prelude(
        "pair: (Int, String) = 1 (,) \"two\"\nnested: (Int, (Int, Int)) = 1 (,) 2 (,) 3\npair_fn: (Int, String -> (Int, String)) = &`(,)`\nfrom_capture: (Int, String) = pair_fn(1, \"two\")\nfrom_pipeline: (Int, String) = 1 |> `(,)`(\"two\")",
    );
    let typed = typecheck(resolved).expect("pair constructor forms should typecheck as tuples");

    for name in ["pair", "nested", "from_capture", "from_pipeline"] {
        assert!(
            matches!(typed_bind_rhs(&typed, name).ty, Ty::Tuple(_)),
            "{name} must typecheck as a tuple"
        );
    }
}

fn tuple_bind_pattern_typechecks() {
    let resolved = resolve_with_builtin_prelude(
        r#"pair = (1, "two")
(left, right) = pair"#,
    );
    let typed = typecheck(resolved).expect("tuple bind should typecheck");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Bind(_, _))
    ));
}

fn facet_view_on_plain_value_returns_plain_focus() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
user.name"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn facet_view_on_result_value_returns_result_focus() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
result_user: Result<User> = Ok(User("alice"))
result_user.name"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Str)
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn facet_variant_selector_returns_result_and_requires_pascal_case() {
    let typed = typecheck_with_builtin_prelude(
        r#"defenum Expr {
  Add(Int, Int),
  Halt,
}
expr = Expr::Add(1, 2)
expr.Add"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Tuple(items) if items.len() == 2)
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));

    let err = typecheck_with_rules(
        r#"defenum Expr {
  Add(Int, Int),
  Halt,
}
expr = Expr::Add(1, 2)
expr.add"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("lowercase variant selector should fail");
    assert!(err.message.contains("No variant selector 'add'"));
}

fn facet_preview_requires_variant_path_and_records_path_kind() {
    let typed = typecheck_with_builtin_prelude(
        r#"defenum Expr {
  Add(Int, Int),
  Halt,
}
expr = Expr::Add(1, 2)
Facet::preview(Expr.Add -> Tuple._0, expr)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    let TypedInner::FacetView { path, .. } = &last.node else {
        panic!("expected Facet::preview to lower as a view");
    };
    assert_eq!(path.path_kind, TypedFacetPathKind::VariantPath);
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Int)
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));

    let err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
Facet::preview(User.name, user)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("preview should reject structural paths");
    assert!(err
        .message
        .contains("Facet::preview requires a variant Facet"));
}

fn facet_preview_accepts_option_variant() {
    let typed = typecheck_with_builtin_prelude(
        r#"value: Option<Int> = Option::Some(1)
Facet::preview(Option.Some, value)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    let TypedInner::FacetView { path, .. } = &last.node else {
        panic!("expected Facet::preview to lower as a view");
    };
    assert_eq!(path.path_kind, TypedFacetPathKind::VariantPath);
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Int)
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));
}

fn facet_preview_accepts_boolean_variant_root() {
    let typed = typecheck_with_builtin_prelude(
        r#"flag = True
Facet::preview(Boolean.True, flag)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    let TypedInner::FacetView { path, .. } = &last.node else {
        panic!("expected Boolean.True to lower as a variant Facet view");
    };
    assert_eq!(path.path_kind, TypedFacetPathKind::VariantPath);
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Unit)
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));
}

fn facet_boolean_selector_uses_regular_enum_diagnostic() {
    let err = typecheck_with_rules(
        r#"flag = True
Facet::preview(Boolean.Maybe, flag)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("unknown Boolean selector should fail through regular enum selector handling");
    assert!(err
        .message
        .contains("No variant selector 'Maybe' on Boolean (use PascalCase constructor names)"));
}

fn facet_list_and_map_segments_are_fallible_structural_paths() {
    let typed = typecheck_with_builtin_prelude(
        r#"scores = [10, 20, 30]
score_map = HashMap::map_from_entries([("talk", 80)])
list_root = Facet::view(List.[1], scores)
map_root = Facet::view(HashMap.["talk"], score_map)
list_value = scores.[1]
map_value = score_map.["talk"]"#,
    );

    for name in ["list_root", "map_root", "list_value", "map_value"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<Int>, got {:?}",
            rhs.ty
        );
        let TypedInner::FacetView { path, .. } = &rhs.node else {
            panic!("{name} should lower to FacetView, got {:?}", rhs.node);
        };
        assert_eq!(path.path_kind, TypedFacetPathKind::FallibleStructural);
        assert!(path.may_fail, "{name} should be fallible");
    }

    assert!(matches!(
        &typed_bind_rhs(&typed, "list_root").node,
        TypedInner::FacetView { path, .. }
            if matches!(path.segments.as_slice(), [TypedFacetSegment::ListIndex { .. }])
    ));
    assert!(matches!(
        &typed_bind_rhs(&typed, "map_root").node,
        TypedInner::FacetView { path, .. }
            if matches!(path.segments.as_slice(), [TypedFacetSegment::MapKey { literal_key, .. }] if literal_key.as_deref() == Some("talk"))
    ));
}

fn facet_explicit_container_root_captures_use_expected_function_context() {
    let typed = typecheck_with_builtin_prelude(
        r#"scores = [10, 20]
score_map = HashMap::map_from_entries([("talk", 80)])
get_first: (List<Int> -> Result<Int>) = &List.[0]
get_talk: (HashMap<Int> -> Result<Int>) = &HashMap.["talk"]
first = get_first(scores)
talk = get_talk(score_map)"#,
    );

    for name in ["first", "talk"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<Int>, got {:?}",
            rhs.ty
        );
    }
}

fn facet_root_dispatch_requires_symbol_capability_metadata_not_matching_names() {
    let span = Span { start: 0, end: 0 };
    let tuple_id = resolved_test_id("Tuple", 900_001, &span);
    let tuple_value_id = resolved_test_id("tuple_value", 900_002, &span);
    let list_id = resolved_test_id("List", 900_003, &span);
    let list_value_id = resolved_test_id("list_value", 900_004, &span);
    let map_id = resolved_test_id("HashMap", 900_005, &span);
    let map_value_id = resolved_test_id("map_value", 900_006, &span);

    let typed = typecheck(vec![
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(tuple_id.clone()),
            Box::new(Resolved::TupleLiteral(
                span.clone(),
                vec![
                    Resolved::Lit(span.clone(), Lit::Str("alice".into())),
                    Resolved::Lit(span.clone(), Lit::Int(int(42))),
                ],
            )),
        ),
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(tuple_value_id),
            Box::new(Resolved::FieldAccess(
                span.clone(),
                Box::new(Resolved::Var(span.clone(), tuple_id)),
                "_0".into(),
            )),
        ),
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(list_id.clone()),
            Box::new(Resolved::ListLiteral(
                span.clone(),
                vec![
                    Resolved::Lit(span.clone(), Lit::Int(int(10))),
                    Resolved::Lit(span.clone(), Lit::Int(int(20))),
                ],
            )),
        ),
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(list_value_id),
            Box::new(Resolved::FacetSegmentAccess(
                span.clone(),
                Box::new(Resolved::Var(span.clone(), list_id)),
                resolved_bracket_segment(Resolved::Lit(span.clone(), Lit::Int(int(0))), "0"),
            )),
        ),
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(map_id.clone()),
            Box::new(Resolved::HashMapLiteral(
                span.clone(),
                vec![ResolvedHashMapLiteralEntry {
                    key: Resolved::Lit(span.clone(), Lit::Str("talk".into())),
                    value: Resolved::Lit(span.clone(), Lit::Int(int(80))),
                }],
            )),
        ),
        Resolved::Bind(
            span.clone(),
            ResolvedPattern::Var(map_value_id),
            Box::new(Resolved::FacetSegmentAccess(
                span.clone(),
                Box::new(Resolved::Var(span.clone(), map_id)),
                resolved_bracket_segment(
                    Resolved::Lit(span.clone(), Lit::Str("talk".into())),
                    "\"talk\"",
                ),
            )),
        ),
    ])
    .expect("value bindings with root-like names should typecheck as ordinary values");

    let tuple_rhs = typed_bind_rhs(&typed, "tuple_value");
    assert!(matches!(tuple_rhs.ty, Ty::Str));

    for name in ["list_value", "map_value"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<Int>, got {:?}",
            rhs.ty
        );
        assert!(matches!(rhs.node, TypedInner::FacetView { .. }));
    }
}

fn facet_root_capability_dispatch_preserves_standard_roots_and_string_diagnostic() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
pair = ("bob", 7)
scores = [10, 20]
score_map = HashMap::map_from_entries([("talk", 80)])
user_name = Facet::view(User.name, user)
tuple_name = Facet::view(Tuple._0, pair)
list_score = Facet::view(List.[0], scores)
map_score = Facet::view(HashMap.["talk"], score_map)"#,
    );

    for name in ["user_name", "tuple_name"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(matches!(rhs.ty, Ty::Str), "{name} should be String");
        assert!(matches!(rhs.node, TypedInner::FacetView { .. }));
    }
    for name in ["list_score", "map_score"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<Int>, got {:?}",
            rhs.ty
        );
        assert!(matches!(rhs.node, TypedInner::FacetView { .. }));
    }

    let err = typecheck_with_rules("bad = String.len", RuntimeSourcePolicy::script())
        .expect_err("String.len should stay a known-symbol non-Facet-root diagnostic");
    assert!(err.message.contains("String is not a Facet path root"));
}

fn deferred_list_and_hashmap_facet_bindings_can_be_reused_by_facet_intrinsics() {
    let typed = typecheck_with_builtin_prelude(
        r#"scores = [10, 20]
score_map = HashMap::map_from_entries([("talk", 80)])
list_path = List.[0]
map_path = HashMap.["talk"]
list_score = Facet::view(list_path, scores)
map_score = Facet::view(map_path, score_map)"#,
    );

    for name in ["list_score", "map_score"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<Int>, got {:?}",
            rhs.ty
        );
        assert!(matches!(rhs.node, TypedInner::FacetView { .. }));
    }
}

fn facet_dynamic_container_segments_accept_runtime_expressions() {
    let captured = typecheck_with_builtin_prelude(
        r#"index = 0
view = {|values: List<Int>| Facet::view(List.[index + 1], values)}"#,
    );
    let TypedInner::Closure(_, captures, _) = &typed_bind_rhs(&captured, "view").node else {
        panic!("closure");
    };
    assert!(
        captures.iter().any(|id| id.name == "index"),
        "dynamic Facet segment must retain its lexical capture"
    );
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord ScoreBook(scores: List<Int>, by_kind: HashMap<Int>)
def find_index(values: List<Int>) -> Int { 1 }
def normalize_key(raw: String) -> String { String::trim(raw) }
scores = [10, 20, 30]
score_map = HashMap::map_from_entries([("talk", 80)])
book = ScoreBook(scores, score_map)
index = 0
raw_name = " talk "
list_root = Facet::view(List.[index + 1], scores)
map_root = Facet::view(HashMap.[normalize_key(raw_name)], score_map)
list_value = scores.[find_index(scores)]
map_value = score_map.[String::trim(raw_name)]
path = ScoreBook.scores.[index + 1]
bulk = Facet::bulk_update(book) {
  scores.[index + 1] <- set(99)
  by_kind.[String::trim(raw_name)] <- over({|value| Ok(value + 1)})
}"#,
    );

    for name in ["list_root", "map_root", "list_value", "map_value", "bulk"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(&rhs.ty, Ty::Result(_, err) if matches!(err.as_ref(), Ty::Error)),
            "{name} should be Result<...>, got {:?}",
            rhs.ty
        );
    }

    let path_rhs = typed_bind_rhs(&typed, "path");
    assert!(matches!(
        path_rhs.node,
        TypedInner::FacetPath(_) | TypedInner::PendingFacetPath(_)
    ));
}

fn facet_dynamic_container_segments_reject_result_and_wrong_key_types() {
    let list_err = typecheck_with_rules(
        r#"def find_index(values: List<Int>) -> Result<Int> { Ok(0) }
values = [1, 2, 3]
bad = Facet::view(List.[find_index(values)], values)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Result<Int> bracket expression should fail");
    assert!(list_err.message.contains(
        "Facet bracket expression must be plain Int; unwrap Result<Int> before using it"
    ));

    let map_err = typecheck_with_rules(
        r#"map: HashMap<Int> = HashMap::map_from_entries([("taro", 18)])
bad = Facet::view(HashMap.[1], map)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("non-String HashMap key should fail");
    assert!(map_err
        .message
        .contains("HashMap Facet key expression must be String"));
}

fn facet_negative_list_index_and_range_segments_typecheck() {
    let typed = typecheck_with_builtin_prelude(
        r#"scores = [10, 20, 30, 40]
last = Facet::view(List.[-1], scores)
window = Facet::view(List.[1..-2], scores)
updated = Facet::set(List.[1..2], scores, [99, 100, 101])
bumped = Facet::over(List.[0..1], scores, {|slice| Ok(List::append(slice, [77]))})"#,
    );

    let last_rhs = typed_bind_rhs(&typed, "last");
    assert!(matches!(
        &last_rhs.ty,
        Ty::Result(ok, err)
            if matches!(ok.as_ref(), Ty::Int) && matches!(err.as_ref(), Ty::Error)
    ));

    for name in ["window", "updated", "bumped"] {
        let rhs = typed_bind_rhs(&typed, name);
        assert!(
            matches!(
                &rhs.ty,
                Ty::Result(ok, err)
                    if matches!(ok.as_ref(), Ty::List(_)) && matches!(err.as_ref(), Ty::Error)
            ),
            "{name} should be Result<List<_>>, got {:?}",
            rhs.ty
        );
    }
}

fn facet_range_segments_require_plain_int_endpoints_and_list_values() {
    let endpoint_err = typecheck_with_rules(
        r#"def find_index(values: List<Int>) -> Result<Int> { Ok(0) }
values = [1, 2, 3]
bad = Facet::view(List.[find_index(values)..1], values)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Result<Int> range endpoint should fail");
    assert!(endpoint_err.message.contains(
        "Facet bracket expression must be plain Int; unwrap Result<Int> before using it"
    ));

    let set_err = typecheck_with_rules(
        r#"values = [1, 2, 3]
bad = Facet::set(List.[0..1], values, 9)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("slice set should require List<A>");
    assert!(
        set_err.message.contains("Facet::set value type mismatch")
            || set_err
                .message
                .contains("Facet updates through List segments cannot change the element type"),
        "{set_err:?}"
    );

    let over_err = typecheck_with_rules(
        r#"values = [1, 2, 3]
bad = Facet::over(List.[0..1], values, {|n| Ok(n + 1)})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("slice over should require List<A> updater");
    assert!(
        over_err.message.contains("Facet::over update function")
            || over_err.message.contains("Argument type mismatch"),
        "{over_err:?}"
    );
}

fn facet_const_dynamic_container_segments_require_literals() {
    let err = typecheck_with_rules(
        r#"index = 0
const PATH: Facet<List<Int>, Int> = List.[index]"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("dynamic container bracket in const facet should fail");
    assert!(err
        .message
        .contains("const Facet path bracket segments must use literal Int or String values"));
}

fn facet_case_api_requires_enum_path_and_records_modes() {
    let typed = typecheck_with_builtin_prelude(
        r#"defenum Slot {
  Some(Result<String>),
  None,
}
slot = Slot::Some(Ok("alice"))
updated =? Facet::case_set(Slot.Some, slot, Ok("bob"))
overed =? Facet::case_over(Slot.Some, updated, {|name| Ok(name ++ "!")})
Facet::case_over(Slot.Some, overed, {|value: Result<String>| Ok(value)})"#,
    );
    let rendered = format!("{typed:?}");
    assert!(rendered.contains("CaseSet"), "{rendered}");
    assert!(rendered.contains("CaseFocusValue"), "{rendered}");
    assert!(rendered.contains("CaseFocusResult"), "{rendered}");

    let err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
Facet::case_over(User.name, user, {|name| Ok(name ++ "!")})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("case_over should reject structural-only paths");
    assert!(err.message.contains("requires an enum Facet path"));
}

fn facet_surface_resolves_after_facet_rename() {
    let resolved = resolve_with_builtin_prelude_result(
        r#"defrecord User(name: String)
user = User("alice")
Facet::view(User.name, user)"#,
    )
    .expect("Facet surface should remain available");
    assert!(!resolved.is_empty());
}

fn facet_compose_typecheck_success_and_mismatch() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
user = User(Profile("alice"))
Facet::view(compose(User.profile, Profile.name), user)"#,
    );
    assert!(matches!(
        typed.last().map(|node| &node.ty),
        Some(scar::types::Ty::Str)
    ));

    let err = typecheck_with_rules(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
compose(Profile.name, User.profile)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("mismatched compose should fail");
    assert!(err.message.contains("mismatch"), "{}", err.message);
}

fn result_chain_field_access_is_not_facet_compose() {
    let typed = typecheck_with_builtin_prelude(
        "pair: (Result<Int>, Int) = (Ok(1), 2)\nResult::chain(pair._0, Ok(()))",
    );
    assert!(matches!(
        typed.last().map(|node| &node.ty),
        Some(Ty::Result(inner, _)) if matches!(inner.as_ref(), Ty::Int)
    ));
}

fn facet_compose_and_result_chain_have_separate_identities() {
    let typed = typecheck_with_builtin_prelude(
        "pair: (Result<Int>, Int) = (Ok(1), 2)\nchain(pair._0, Ok(()))",
    );
    assert!(matches!(
        typed.last().map(|node| &node.ty),
        Some(Ty::Result(inner, _)) if matches!(inner.as_ref(), Ty::Int)
    ));
}

fn facet_arrow_compose_typecheck_success_and_mismatch() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
user = User(Profile("alice"))
Facet::view(User.profile -> Profile.name, user)"#,
    );
    assert!(matches!(
        typed.last().map(|node| &node.ty),
        Some(scar::types::Ty::Str)
    ));

    let err = typecheck_with_rules(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
Profile.name -> User.profile"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("mismatched arrow composition should fail");
    assert!(!err.message.is_empty());

    let old_slash = typecheck_with_rules(
        "defrecord Profile(name: String)\ndefrecord User(profile: Profile)\nUser.profile / Profile.name",
        RuntimeSourcePolicy::script(),
    ).expect_err("Facet slash has no compatibility route");
    assert!(old_slash.message.contains("Facet values"), "{old_slash:?}");

    let declarations =
        "defrecord Profile(name: String)\ndefstruct User { private profile: Profile }\nimpl User { def new(profile: Profile) -> Self { User { profile: profile } } }\n";
    let arrow_error = typecheck_with_rules(
        &format!("{declarations}User.profile -> Profile.name"),
        RuntimeSourcePolicy::script(),
    )
    .expect_err("arrow composition preserves private field rejection");
    let call_error = typecheck_with_rules(
        &format!("{declarations}Facet::compose(User.profile, Profile.name)"),
        RuntimeSourcePolicy::script(),
    )
    .expect_err("explicit compose preserves private field rejection");
    assert!(
        arrow_error
            .message
            .contains("Field 'User.profile' is private"),
        "{arrow_error:?}"
    );
    assert_eq!(arrow_error.message, call_error.message);
}

fn facet_set_returns_result_source() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
Facet::set(User.name, user, "bob")"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Record(name, _) if name == "User")
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));
    assert!(matches!(last.node, TypedInner::FacetSet { .. }));
}

fn facet_put_returns_plain_source() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
put(User.name, user, "bob")"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Record(name, _) if name == "User"
    ));
    assert!(matches!(last.node, TypedInner::FacetSet { .. }));
}

fn facet_put_rejects_result_source_and_variant_path() {
    let result_source_err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = Ok(User("alice"))
put(User.name, user, "bob")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Result source should fail for Facet::put");
    assert!(result_source_err
        .message
        .contains("Facet::put requires a plain source value"));

    let variant_path_err = typecheck_with_rules(
        r#"defenum Expr {
  Add(Int, Int),
  Halt,
}
expr = Expr::Add(1, 2)
put(Expr.Add -> Tuple._0, expr, 7)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("variant path should fail for Facet::put");
    assert!(variant_path_err
        .message
        .contains("Facet::put requires an infallible structural Facet path"));
}

fn facet_put_supports_same_type_tuple_update_inside_annotated_closure() {
    let typed = typecheck_with_builtin_prelude(
        r#"def first(f: (Int -> Int)) -> ((Int, Boolean) -> (Int, Boolean)) {
  {|pair: (Int, Boolean)| Facet::put(Tuple._0, pair, f(pair._0))}
}"#,
    );
    assert!(!typed.is_empty());
}

fn facet_put_unannotated_closure_uses_declared_return_tuple_context() {
    typecheck_with_rules(
        r#"def first(f: (Int -> Int)) -> ((Int, Boolean) -> (Int, Boolean)) {
  {|pair| Facet::put(Tuple._0, pair, f(pair._0))}
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("the declared function return should contextualize the unannotated closure");
}

fn facet_put_supports_type_changing_tuple_update() {
    typecheck_with_rules(
        r#"def first(f: (Int -> String)) -> ((Int, Boolean) -> (String, Boolean)) {
  {|pair: (Int, Boolean)| Facet::put(Tuple._0, pair, f(pair._0))}
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("Facet::put should rebuild a tuple with the replacement type");
}

fn facet_put_rebuilds_unique_generic_named_type() {
    typecheck_with_rules(
        r#"defstruct Box<$A> {
  value: $A,
}
impl Box {
  def new(value: $A) -> Box<$A> { Box { value: value } }
}
updated: Box<String> = Facet::put(Box.value, Box(1), "one")

defstruct TaggedBox<$Tag, $A> {
  value: $A,
}
impl TaggedBox {
  def new::<$Tag>(value: $A) -> TaggedBox<$Tag, $A> {
    TaggedBox { value: value }
  }
}
tagged_source: TaggedBox<Boolean, Int> = TaggedBox::new::<Boolean>(1)
tagged: TaggedBox<Boolean, String> = Facet::put(TaggedBox.value, tagged_source, "one")

defstruct Pairish<$A, $B> {
  selected: ($A, $B),
  other: $B,
}
impl Pairish {
  def new(selected: ($A, $B), other: $B) -> Pairish<$A, $B> {
    Pairish { selected: selected, other: other }
  }
}
pairish_source: Pairish<Int, Boolean> = Pairish((1, True), False)
pairish: Pairish<String, Boolean> = Facet::put(Pairish.selected -> Tuple._0, pairish_source, "one")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("Facet::put should rebuild a uniquely parameterized named type");
}

fn facet_put_rejects_repeated_generic_named_type() {
    let err = typecheck_with_rules(
        r#"defstruct Pair<$A> {
  left: $A,
  right: $A,
}
impl Pair {
  def new(left: $A, right: $A) -> Pair<$A> { Pair { left: left, right: right } }
}
Facet::put(Pair.left, Pair(1, 2), "one")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a repeated generic parameter must not be rebuilt through one field");
    assert!(err
        .message
        .contains("generic parameter occurs outside the updated field"));
}

fn facet_case_set_rebuilds_unique_generic_enum() {
    typecheck_with_rules(
        r#"defenum Slot<$A> {
  Some($A),
  None,
}
updated = Facet::case_set(Slot.Some, Slot::Some(1), "one")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("Facet::case_set should rebuild a uniquely parameterized enum");
}

fn facet_put_rejects_result_annotation_context() {
    let err = typecheck_with_rules(
        r#"defrecord User(name: String)
updated: Result<User> = Facet::put(User.name, User("alice"), "bob")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Facet::put should explain Result annotation mismatch");
    assert!(err.message.contains("expected Result<User>, got User"));
}

fn facet_put_rejects_result_return_context() {
    let err = typecheck_with_rules(
        r#"defrecord User(name: String)
def rename() -> Result<User> {
  Facet::put(User.name, User("alice"), "bob")
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Facet::put should explain Result return mismatch");
    assert!(err.message.contains("expected Result<User>, got User"));
}

fn facet_over_requires_unary_result_callable() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
Facet::over(User.name, user, {|name| Ok(name)})"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(
        &last.ty,
        scar::types::Ty::Result(ok, err)
            if matches!(ok.as_ref(), scar::types::Ty::Record(name, _) if name == "User")
                && matches!(err.as_ref(), scar::types::Ty::Error)
    ));
    assert!(matches!(last.node, TypedInner::FacetOver { .. }));

    let err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
Facet::over(User.name, user, {|name| name})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("non-Result update function should fail");
    assert!(err
        .message
        .contains("Facet::over update function must return Result"));
}

fn optional_type_annotation_matches_option() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord Boxed(
  value: Int?,
)
boxed = Boxed(Option::Some(1))
same: Option<Int> = boxed.value"#,
    );
    assert!(!typed.is_empty());
}

fn optional_type_annotation_rejects_result_value() {
    let resolved = resolve_with_builtin_prelude(
        r#"defrecord Boxed(
  value: Int?,
)
boxed = Boxed(Ok(1))"#,
    );
    let err = typecheck(resolved).expect_err("Result value should not typecheck for Int?");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    assert!(
        err.message
            .contains("expected Option<Int>, got Result<Int>"),
        "{err:?}"
    );
}

fn facet_set_rejects_plain_value_for_result_focus() {
    let resolved = resolve_with_builtin_prelude(
        r#"defrecord User(score: Result<Int>)
user = User(Err(NoneError()))
Facet::set(User.score, user, 3)"#,
    );
    let err = typecheck(resolved).expect_err("set must not implicitly wrap a Result focus");
    assert!(
        err.message.contains("expected Result<Int>, got Int"),
        "{}",
        err.message
    );
}

fn facet_shorthand_view_and_mutation_forms_typecheck() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String, score: Result<Int>)
user = User("alice", Ok(1))
name = Facet::view(~user.name)
updated =? Facet::set(~user.name, "bob")
replaced = put(~updated.name, "carol")
bumped =? Facet::over(~replaced.score, {|score| Ok(score + 1)})
Facet::over_result(~bumped.score, {|score| Ok(score)})"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.node, TypedInner::FacetOver { .. }));
}

fn facet_shorthand_reuses_existing_facet_api_errors() {
    let preview_err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
Facet::preview(~user.name)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("structural shorthand should fail for preview");
    assert!(preview_err
        .message
        .contains("Facet::preview requires a variant Facet"));

    let put_err = typecheck_with_rules(
        r#"defrecord User(name: String)
result_user = Ok(User("alice"))
put(~result_user.name, "bob")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("result source shorthand should fail for put");
    assert!(put_err
        .message
        .contains("Facet::put requires a plain source value"));
}

fn facet_shorthand_misuse_is_rejected_outside_facet_api() {
    let bind_err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
path = ~user.name"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("shorthand binding should fail");
    assert!(bind_err.message.contains(
        "must be consumed as the first argument of Facet::view/preview/put/set/over/over_result"
    ));

    let missing_path_err = typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
Facet::view(~user)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("missing path should fail");
    assert!(missing_path_err
        .message
        .contains("requires a field or tuple path"));
}

fn facet_over_accepts_success_updater_for_result_focus() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(score: Result<Int>)
user = User(Ok(1))
Facet::over(User.score, user, {|score| Ok(score + 1)})"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.node, TypedInner::FacetOver { .. }));
}

fn facet_over_allows_result_typed_payload_replacement() {
    typecheck_with_rules(
        r#"defrecord User(score: Result<Int>)
user = User(Ok(1))
Facet::over(User.score, user, {|score| Ok(Ok(score))})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("Facet::over should permit changing a Result payload to a Result value");
}

fn facet_over_result_requires_result_container_updater() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(score: Result<Int>)
user = User(Ok(1))
Facet::over_result(User.score, user, {|score| Ok(score)})"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.node, TypedInner::FacetOver { .. }));

    let err = typecheck_with_rules(
        r#"defrecord User(score: Result<Int>)
user = User(Ok(1))
Facet::over_result(User.score, user, {|score| Ok(1)})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("plain success updater should fail for Facet::over_result");
    assert!(err
        .message
        .contains("Facet::over_result update function output mismatch"));
}

fn nested_result_err_expression_has_dedicated_diagnostic() {
    let err = typecheck_with_rules(
        r#"deferror Oops { "oops" }
value: Result<Result<Int>> = Err(Err(Oops()))"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("nested Err expressions must be rejected");
    assert!(
        err.message.contains("Nested Result errors are not allowed"),
        "{err:?}"
    );
}

fn nested_result_err_pattern_has_dedicated_diagnostic() {
    let err = typecheck_with_rules(
        r#"deferror Oops { "oops" }
value: Result<Result<Int>> = Err(Oops())
match value {
  Err(Err(error)) => Error::message(error)
  Ok(_) => "ok"
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("nested Err patterns must be rejected");
    assert!(
        err.message
            .contains("Nested Result errors are not allowed in match patterns"),
        "{err:?}"
    );
}

fn readonly_facet_view_succeeds_and_preserves_path_metadata() {
    let typed = typecheck_with_builtin_prelude(
        r#"defstruct Profile {
  name: String,
}

defstruct User {
  readonly profile: Profile,
}

impl Profile {
  def new(name: String) -> Self {
    Profile { name: name }
  }
}

impl User {
  def new(profile: Profile) -> Self {
    User { profile: profile }
  }
}

user = User(Profile("alice"))
Facet::view(User.profile.name, user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    let TypedInner::FacetView { path, .. } = &last.node else {
        panic!("expected FacetView");
    };
    assert!(matches!(last.ty, scar::types::Ty::Str));
    match &path.segments[0] {
        TypedFacetSegment::Field {
            readonly,
            container_type_name,
            ..
        } => {
            assert!(*readonly);
            assert_eq!(container_type_name, "User");
        }
        other => panic!("expected field segment, got {other:?}"),
    }
}

fn readonly_field_blocks_deep_mutation_but_owner_can_replace_property() {
    let err = typecheck_with_rules(
        r#"defstruct Profile {
  name: String,
}

defstruct User {
  readonly profile: Profile,
}

impl Profile {
  def new(name: String) -> Self {
    Profile { name: name }
  }
}

impl User {
  def new(profile: Profile) -> Self {
    User { profile: profile }
  }
}

user = User(Profile("alice"))
Facet::set(User.profile.name, user, "bob")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("deep mutation through readonly field should fail");
    assert!(err.message.contains("readonly field User.profile"));

    let typed = typecheck_with_builtin_prelude(
        r#"defstruct Profile {
  name: String,
}

defstruct User {
  readonly profile: Profile,
}

impl Profile {
  def new(name: String) -> Self {
    Profile { name: name }
  }
}

impl User {
  def new(profile: Profile) -> Self {
    User { profile: profile }
  }

  def replace_profile(self: Self, next_profile: Profile) -> Result<User> {
    Facet::set(User.profile, self, next_profile)
  }
}"#,
    );
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Def(..))
    ));
}

fn readonly_struct_fields_allow_owner_replacement() {
    let err = typecheck_with_rules(
        r#"@readonly
defstruct Profile {
  name: String,
}

impl Profile {
  def new(name: String) -> Self {
    Profile { name: name }
  }
}

profile = Profile("alice")
Facet::over(Profile.name, profile, {|name| Ok(name)})"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("readonly fields should reject external mutation");
    assert!(err.message.contains("readonly field Profile.name"));

    let typed = typecheck_with_rules(
        r#"@readonly
defstruct Profile {
  name: String,
}

impl Profile {
  def new(name: String) -> Self {
    Profile { name: name }
  }

  def rename(self: Self, next_name: String) -> Result<Profile> {
    Facet::set(Profile.name, self, next_name)
  }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("owner may replace an annotation-derived readonly field");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Def(..))
    ));

    let err = typecheck_with_rules(
        r#"@readonly
defstruct Profile { scores: List<Int> }
impl Profile {
  def new(scores: List<Int>) -> Self { Profile { scores: scores } }
  def update_score(self: Self) -> Result<Profile> {
    Facet::set(Profile.scores -> List.[0], self, 9)
  }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("owner cannot traverse annotation-derived readonly fields");
    assert!(err.message.contains("readonly field Profile.scores"));
}

fn facet_standalone_tuple_root_is_rejected() {
    let err = spire::parse_with_context(
        r#"pair = (1, "one")
Facet::view(_0, pair)"#,
        spire::ParserContext::project(0),
    )
    .expect_err("standalone _0 is outside the numbered-placeholder range");
    assert!(err.message().contains("between _1 and _16"));
}

fn facet_bindings_can_be_reused_by_facet_intrinsics() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
facet = User.name
Facet::view(facet, user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn facet_tuple_type_root_view_works_with_expected_context() {
    let typed = typecheck_with_builtin_prelude(
        r#"pair = ("alice", 42)
Facet::view(Tuple._0, pair)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn record_positional_facet_resolves_to_named_field() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String, age: Int)
user = User("alice", 42)
Facet::view(User._1, user)
user._0"#,
    );
    let view = &typed[typed.len() - 2];
    let TypedInner::FacetView { path, .. } = &view.node else {
        panic!("expected positional record Facet view");
    };
    assert!(matches!(view.ty, scar::types::Ty::Int));
    assert!(matches!(&path.segments[0], TypedFacetSegment::Field {
        field_name, field_index: 1, origin_index: Some(1), ..
    } if field_name == "age"));
    assert!(matches!(typed.last().unwrap().ty, scar::types::Ty::Str));
}

fn record_positional_facet_rejects_out_of_bounds_and_tuple_root() {
    let err = typecheck_with_rules(
        "defrecord User(name: String, age: Int)\nUser._2",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("out-of-range Record index must fail");
    assert!(
        err.message.contains("Record index ._2 is out of bounds"),
        "{err:?}"
    );

    let err = typecheck_with_rules(
        "defrecord User(name: String, age: Int)\nUser._999999999999999999999999999999999999",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("overflowing Record index must fail as a position selector");
    assert!(
        err.message
            .contains("Record index ._999999999999999999999999999999999999 is out of bounds"),
        "{err:?}"
    );

    let err = typecheck_with_rules(
        "defrecord User(name: String, age: Int)\nuser = User(\"alice\", 42)\nFacet::view(Tuple._1, user)",
        RuntimeSourcePolicy::script(),
    ).expect_err("Tuple root must require tuple source");
    assert!(
        err.message.contains("requires tuple source context"),
        "{err:?}"
    );
}

fn deferred_tuple_facet_binding_can_be_reused_by_facet_intrinsics() {
    let typed = typecheck_with_builtin_prelude(
        r#"pair = ("alice", 42)
facet = Tuple._1
Facet::view(facet, pair)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Int));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn deferred_tuple_facet_binding_can_compose_before_consumption() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord Profile(name: String)
pair = (Profile("alice"), 42)
outer = Tuple._0
path = outer -> Profile.name
Facet::view(path, pair)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
    assert!(matches!(last.node, TypedInner::FacetView { .. }));
}

fn facet_tuple_type_root_compose_works_as_inner_path() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(pair: (String, Int))
user = User(("alice", 42))
Facet::view(Facet::compose(User.pair, Tuple._0), user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_tuple_type_root_arrow_compose_works_as_inner_path() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(pair: (String, Int))
user = User(("alice", 42))
Facet::view(User.pair -> Tuple._0, user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_const_arrow_compose_allows_facet_consts() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord Profile(name: String)
defrecord User(profile: Profile)
const USER_PROFILE: Facet<InfallibleStructural, User, Profile, _, _> = User.profile
const PROFILE_NAME: Facet<InfallibleStructural, Profile, String, _, _> = Profile.name
const FULL_NAME: Facet<InfallibleStructural, User, String, _, _> = USER_PROFILE -> PROFILE_NAME
user = User(Profile("alice"))
Facet::view(FULL_NAME, user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_const_arrow_compose_rejects_non_facet_const_refs() {
    let err = typecheck_with_rules(
        r#"const VALUE = 1
const BAD = VALUE -> VALUE"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("non-facet const refs should fail");
    assert!(err
        .message
        .contains("const value must be a primitive literal or a facet path"));
}

fn slash_operator_has_no_facet_fallback() {
    let typed = typecheck_with_builtin_prelude("value = 10 / 3");
    assert!(matches!(typed.last().map(|node| &node.ty), Some(Ty::Unit)));
    for (source, trait_name) in [
        ("1 / 2.0", "expected Int"),
        ("1.0 % 2.0", "Mod"),
        ("True / False", "Div"),
        ("True % False", "Mod"),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script()).expect_err(source);
        assert!(error.message.contains(trait_name), "{source}: {error:?}");
    }
    for method in [
        "def safe_div(self: Self, rhs: Int) -> Result<Self> { Ok(self) }",
        "def safe_div(self: Self, rhs: Self) -> Result<Int> { Ok(1) }",
    ] {
        let source = format!("defrecord Metric(value: Int)\nimpl Div for Metric {{ {method} }}");
        typecheck_with_rules(&source, RuntimeSourcePolicy::script()).expect_err(
            "error contract flexibility does not relax argument or success type agreement",
        );
    }
}

fn facet_tuple_type_root_without_context_can_bind_as_deferred_path() {
    let typed = typecheck_with_builtin_prelude("facet = Tuple._0");
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Unit));
}

fn facet_view_inside_closure_is_allowed_for_same_scope_consumption() {
    let typed = typecheck_with_rules(
        r#"defrecord User(name: String)
facet = User.name
getter = {|user| Facet::view(facet, user)}
getter(User("alice"))"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("closure-local Facet::view should typecheck");
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_capture_shorthand_builds_read_closure() {
    let typed = typecheck_with_rules(
        r#"defrecord User(name: String)
facet = User.name
getter = &facet
getter(User("alice"))"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("&facet shorthand should typecheck");
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_values_cannot_be_embedded_in_runtime_containers() {
    let tuple_err = typecheck_with_rules(
        r#"defrecord User(name: String)
(User.name, 1)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("tuple literal should reject facet");
    assert!(tuple_err
        .message
        .contains("Tuple literal cannot contain Facet values"));

    let list_err = typecheck_with_rules(
        r#"defrecord User(name: String)
[User.name, User.name]"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("list literal should reject facet");
    assert!(list_err
        .message
        .contains("List literal cannot contain Facet values"));

    let ok_err = typecheck_with_rules(
        r#"defrecord User(name: String)
Ok(User.name)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("result constructors should reject facet");
    assert!(ok_err
        .message
        .contains("Result constructors cannot contain Facet values"));
}

fn nested_facet_types_are_rejected_in_function_signatures() {
    let param_err = typecheck_with_rules(
        r#"defrecord User(name: String)
def bad(values: List<Facet<InfallibleStructural, User, String, _, _>>) -> Unit { () }"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("nested facet in parameter type should fail");
    assert!(param_err
        .message
        .contains("cannot appear in function parameter types"));

    let ret_err = typecheck_with_rules(
        r#"defrecord User(name: String)
def bad() -> List<Facet<InfallibleStructural, User, String, _, _>> { [] }"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("nested facet in return type should fail");
    assert!(ret_err
        .message
        .contains("cannot appear in function return types"));
}

fn private_field_access_is_allowed_inside_owner_impl_only() {
    let typed = typecheck_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }

  def read_password(self) -> String {
    self.password
  }
}
user = User("alice", "s3cr3t")
User::read_password(user)"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn private_field_access_outside_owner_impl_is_rejected_for_value_and_capability_roots() {
    let value_err = typecheck_with_rules(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }
}
user = User("alice", "s3cr3t")
user.password"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("private value access should fail outside impl");
    assert!(value_err
        .message
        .contains("Field 'User.password' is private"));

    let capability_err = typecheck_with_rules(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }
}
User.password"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("private capability root should fail");
    assert!(capability_err
        .message
        .contains("Field 'User.password' is private"));
}

fn private_field_access_inside_closure_is_rejected_outside_owner_impl() {
    let err = typecheck_with_rules(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }
}
user = User("alice", "s3cr3t")
{|| user.password}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("private value access inside closure should fail outside impl");
    assert!(err.message.contains("Field 'User.password' is private"));
}

fn private_field_access_inside_param_closure_is_rejected_outside_owner_impl() {
    let err = typecheck_with_rules(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }
}
reader = {|user: User| user.password}
user = User("alice", "s3cr3t")
reader(user)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("private value access inside parameter closure should fail outside impl");
    assert!(err.message.contains("Field 'User.password' is private"));
}

fn private_capability_root_is_rejected_in_facet_view_call() {
    let err = typecheck_with_rules(
        r#"defstruct User {
  name: String,
  private password: String,
}
impl User {
  def new(name: String, password: String) -> Self {
User { name: name, password: password }
  }
}
user = User("alice", "s3cr3t")
Facet::view(User.password, user)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("private capability root in Facet::view should fail");
    assert!(err.message.contains("Field 'User.password' is private"));
}

fn facet_scope_local_value_can_flow_to_closure_after_view() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
user = User("alice")
facet = User.name
name = Facet::view(facet, user)
reader = {|| name}
reader()"#,
    );
    let last = typed.last().expect("typed program should not be empty");
    assert!(matches!(last.ty, scar::types::Ty::Str));
}

fn facet_runtime_transport_restrictions_remain() {
    let arg_err = typecheck_with_rules(
        r#"defrecord User(name: String)
print(to_string(User.name))"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("passing Facet value as argument should fail");
    assert!(arg_err.message.contains("cannot accept Facet values"));

    let return_err = typecheck_with_rules(
        r#"defrecord User(name: String)
def bad() -> Facet<InfallibleStructural, User, String, _, _> {
  User.name
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("returning Facet value should fail");
    assert!(return_err
        .message
        .contains("cannot appear in function return types"));

    let arg_var_err = typecheck_with_rules(
        r#"defrecord User(name: String)
def consume(value: String) -> String {
  value
}
facet = User.name
consume(facet)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("passing Facet binding as runtime function argument should fail");
    assert!(
        arg_var_err.message.contains("cannot accept Facet values")
            || arg_var_err.message.contains("Argument type mismatch")
            || arg_var_err.message.contains("compile-time only")
    );
}

fn extractor_single_value_match_result_contract_typechecks() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct Single {
  value: Int,
}
impl Single {
  def new(value: Int) -> Self {
Single { value: value }
  }

  defextractor deconstruct(self: Self) -> MatchResult<Int> {
MatchResult::Ok(self.value)
  }
}

value = Single(1)
print(match value {
  Single(inner) => to_string(inner),
  _ => "bad",
})"#,
    );
    let typed = typecheck(resolved).expect("single-value extractor should typecheck");
    assert!(!typed.is_empty());
}

fn struct_matchblock_head_uses_attached_deconstruct_method() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
User { name: name, age: age }
  }
  defextractor deconstruct(self: Self) -> MatchResult<(String, Int)> {
MatchResult::Err(NoneError())
  }
}
user = User("alice", 30)
print(match user {
  User(name, age) => "bad",
  _ => "fallback",
})"#,
    );
    let typed = typecheck(resolved).expect("typecheck should succeed");
    assert!(!typed.is_empty());
}

fn struct_matchblock_head_requires_attached_deconstruct_method() {
    let err = resolve_with_builtin_prelude_result(
        r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
User { name: name }
  }
}
user = User("alice")
print(match user {
  User(name) => name,
  _ => "fallback",
})"#,
    )
    .expect_err("resolve should fail");
    assert!(err.message.contains(
        "MatchBlock head `User` requires attached extractor `User::deconstruct`, but it is not defined"
    ));
}

fn enum_impl_extractor_can_be_used_in_matchblock() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum Light {
  Red,
  Green,
}
impl Light {
  defextractor stop_code(self: Self) -> MatchResult<Int> {
match self {
  Light::Red => MatchResult::Ok(1),
  _ => MatchResult::Err(NoneError()),
}
  }
}
light = Light::Red
print(match light {
  Light::stop_code(code) => to_string(code),
  _ => "fallback",
})"#,
    );
    let typed = typecheck(resolved).expect("enum impl extractor should typecheck");
    assert!(!typed.is_empty());
}

fn forward_struct_type_annotation_and_literal_are_allowed() {
    let resolved = resolve_with_builtin_prelude(
        r#"user: User = User("alice", 30)
defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
User { name: name, age: age }
  }
}"#,
    );
    let typed = typecheck(resolved).expect("forward struct reference should typecheck");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::StructDef(_, _, _, _))));
}

fn generic_struct_single_type_param_typechecks() {
    let typed = typecheck_with_builtin_prelude(
        r#"defstruct Box<$A> {
  value: $A,
}
impl Box {
  def new(value: $A) -> Box<$A> {
    Box { value: value }
  }
}
boxed: Box<Int> = Box(41)
printable: Int = boxed.value"#,
    );
    let boxed_bind = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "boxed") => {
                let TypedPattern::Var(ty, _) = pattern.unlocated() else { unreachable!("binding guard checked"); };
                Some((ty, rhs.as_ref()))
            }
            _ => None,
        })
        .expect("expected boxed binding");
    assert!(
        matches!(boxed_bind.0, Ty::Struct(name, fields) if name == "Global::Box"
        && matches!(fields.as_slice(), [(field, Ty::Int)] if field == "value"))
    );
    assert!(
        matches!(boxed_bind.1.ty, Ty::Struct(ref name, ref fields) if name == "Global::Box"
        && matches!(fields.as_slice(), [(field, Ty::Int)] if field == "value"))
    );
}

fn generic_struct_two_type_params_typecheck() {
    let typed = typecheck_with_builtin_prelude(
        r#"defstruct Pair<$A, $B> {
  left: $A,
  right: $B,
}
impl Pair {
  def new(left: $A, right: $B) -> Pair<$A, $B> {
    Pair { left: left, right: right }
  }
}
pair: Pair<Int, String> = Pair(1, "two")
text: String = pair.right"#,
    );
    let pair_bind = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "pair") => {
                let TypedPattern::Var(ty, _) = pattern.unlocated() else { unreachable!("binding guard checked"); };
                Some((ty, rhs.as_ref()))
            }
            _ => None,
        })
        .expect("expected pair binding");
    assert!(
        matches!(pair_bind.0, Ty::Struct(name, fields) if name == "Global::Pair"
        && matches!(fields.as_slice(),
            [(left, Ty::Int), (right, Ty::Str)] if left == "left" && right == "right"))
    );
    assert!(
        matches!(pair_bind.1.ty, Ty::Struct(ref name, ref fields) if name == "Global::Pair"
        && matches!(fields.as_slice(),
            [(left, Ty::Int), (right, Ty::Str)] if left == "left" && right == "right"))
    );
}

fn forward_deferror_value_can_flow_into_err() {
    let resolved = resolve_with_builtin_prelude(
        r#"ret: Result<Int> = Err(NotFound())
deferror NotFound {
  "not found"
}"#,
    );
    let typed = typecheck(resolved).expect("forward deferror constructor should typecheck");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::DeferrorDef(_, _, _, _, _))));
}

fn zero_arg_deferror_value_can_flow_into_error_parameter() {
    let resolved = resolve_with_builtin_prelude(
        r#"wrapped = Result::cause(Err(NoneError()), NotFound())
deferror NotFound {
  "not found"
}"#,
    );
    let typed = typecheck(resolved).expect("zero-arg deferror should satisfy Error parameters");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Bind(_, _))));
}

fn recover_kind_payload_type_name_typechecks() {
    let resolved = resolve_with_builtin_prelude(
        r#"value = Result::recover_kind(Err(NotFound("runtime")), NotFound, {|err| Ok(1)})
deferror NotFound(detail: String) { |detail: String| Self(message: detail, detail: detail) }"#,
    );
    let typed = typecheck(resolved).expect("recover_kind payload type name should typecheck");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Bind(_, _))));
}

fn forward_reference_type_tags_are_deterministic_across_runs() {
    let source = r#"user: User = User("alice", 30)
pair = Pair(first: 1, second: "two")
ret: Result<Int> = Err(NotFound("404"))

defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
User { name: name, age: age }
  }
}

defrecord Pair(first: Int, second: String)

deferror NotFound(code: String) { |code: String| Self(message: "missing #{code}", code: code) }"#;

    let first = typecheck_with_builtin_prelude(source);
    let second = typecheck_with_builtin_prelude(source);

    fn collect_type_tags(nodes: &[TypedNode]) -> Vec<(String, u32)> {
        nodes
            .iter()
            .filter_map(|node| match &node.node {
                TypedInner::StructDef(tag, name, _, _) | TypedInner::RecordDef(tag, name, _, _) => {
                    Some((name.clone(), *tag))
                }
                TypedInner::DeferrorDef(tag, _, id, _, _) => Some((id.name.clone(), *tag)),
                _ => None,
            })
            .collect()
    }

    assert_eq!(collect_type_tags(&first), collect_type_tags(&second));
}

fn user_function_calls_typecheck_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        "def add1(x: Int) -> Int { x + 1 }\nprint(to_string(add1(41)))",
    );
    assert!(
        typed
            .iter()
            .any(|node| matches!(node.node, TypedInner::Def(..))),
        "expected user function definition to survive typechecking"
    );
}

fn namespaced_type_and_trait_impl_typecheck_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"namespace Auth {
  defrecord User(name: String)
}

impl Show for Auth::User {
  def to_string(self: Self) -> String { "user" }
}

value: Auth::User = Auth::User("alice")
print(to_string(value))"#,
    );
    assert!(
        typed
            .iter()
            .any(|node| matches!(node.node, TypedInner::RecordDef(_, _, _, _))),
        "expected namespaced record definition to survive typechecking"
    );
    assert!(
        typed
            .iter()
            .any(|node| matches!(node.node, TypedInner::TraitImplDef(..))),
        "expected namespaced trait impl to survive typechecking"
    );
}

fn tuple_trait_impl_typechecks_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"deftrait PairTrait {
  def keep(self: Self) -> Self
}

impl PairTrait for ($A, $B) {
  def keep(self: Self) -> Self {
    self
  }
}"#,
    );
    assert!(
        typed
            .iter()
            .any(|node| matches!(node.node, TypedInner::TraitImplDef(..))),
        "expected tuple trait impl to survive typechecking"
    );
}

fn concrete_tuple_trait_impl_typechecks_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"deftrait PairTrait {
  def keep(self: Self) -> Self
}

impl PairTrait for (Int, String) {
  def keep(self: Self) -> Self {
    self
  }
}"#,
    );
    assert!(
        typed
            .iter()
            .any(|node| matches!(node.node, TypedInner::TraitImplDef(..))),
        "expected concrete tuple trait impl to survive typechecking"
    );
}

fn overlapping_trait_impl_patterns_are_rejected_before_codegen() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait Mark<$T> {
  def mark(self: Self) -> String
}

impl Mark<$A> for String {
  def mark(self: String) -> String { "any" }
}

impl Mark<List<$A>> for String {
  def mark(self: String) -> String { "list" }
}"#,
    );

    let err = typecheck(resolved).expect_err("overlapping impls must be rejected by Scar");
    assert!(
        err.message.contains("Overlapping trait impls for Mark"),
        "{err:?}"
    );
}

fn disjoint_specializations_with_the_same_nominal_target_typecheck() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait Mark<$T> {
  def mark(self: Self) -> String
}

impl Mark<Int> for List<Int> {
  def mark(self: List<Int>) -> String { "int" }
}

impl Mark<Int> for List<String> {
  def mark(self: List<String>) -> String { "string" }
}"#,
    );

    let typed = typecheck(resolved).expect("disjoint impl patterns should coexist");
    assert_eq!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::TraitImplDef(..)))
            .count(),
        2
    );
}

fn conversion_impl_exclusivity_ignores_generic_parameter_names() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct LocalBox<$A> { value: $A }

impl Convert<$A> for LocalBox<$A> {
  def to::<$A>(self: LocalBox<$A>) -> $A { self.value }
}

impl TryConvert<$T> for LocalBox<$T> {
  def try_to::<$T>(self: LocalBox<$T>) -> Result<$T, Error> { Ok(self.value) }
}"#,
    );

    let err = typecheck(resolved).expect_err("Convert and TryConvert patterns must be exclusive");
    assert!(
        err.message.contains("cannot both be implemented"),
        "{err:?}"
    );
}

fn conversion_impl_exclusivity_rejects_generic_concrete_overlap() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum LocalBox<$A> { Value($A) }

impl Convert<Int> for LocalBox<$A> {
  def to::<Int>(self: LocalBox<$A>) -> Int { 0 }
}

impl TryConvert<Int> for LocalBox<String> {
  def try_to::<Int>(self: LocalBox<String>) -> Result<Int, Error> { Ok(0) }
}"#,
    );

    let err = typecheck(resolved)
        .expect_err("generic Convert and concrete TryConvert patterns must be exclusive");
    assert!(
        err.message.contains("cannot both be implemented"),
        "{err:?}"
    );
}

fn conversion_impl_exclusivity_rejects_nested_overlap() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum LocalSource { Value }

impl Convert<List<$A>> for LocalSource {
  def to::<List<$A>>(self: LocalSource) -> List<$A> { [] }
}

impl TryConvert<List<Int>> for LocalSource {
  def try_to::<List<Int>>(self: LocalSource) -> Result<List<Int>, Error> { Ok([]) }
}"#,
    );

    let err =
        typecheck(resolved).expect_err("nested Convert and TryConvert patterns must be exclusive");
    assert!(
        err.message.contains("cannot both be implemented"),
        "{err:?}"
    );
}

fn conversion_impl_exclusivity_is_declaration_order_independent() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum LocalSource { Value }

impl TryConvert<Int> for LocalSource {
  def try_to::<Int>(self: LocalSource) -> Result<Int, Error> { Ok(0) }
}

impl Convert<Int> for LocalSource {
  def to::<Int>(self: LocalSource) -> Int { 0 }
}"#,
    );

    let err = typecheck(resolved)
        .expect_err("TryConvert declared before Convert must still be exclusive");
    assert!(
        err.message.contains("cannot both be implemented"),
        "{err:?}"
    );
}

fn conversion_impl_exclusivity_allows_disjoint_pairs() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum LocalBox<$A> { Value($A) }

impl Convert<Int> for LocalBox<Int> {
  def to::<Int>(self: LocalBox<Int>) -> Int { 0 }
}

impl TryConvert<Int> for LocalBox<String> {
  def try_to::<Int>(self: LocalBox<String>) -> Result<Int, Error> { Ok(0) }
}"#,
    );

    let typed = typecheck(resolved).expect("disjoint Convert and TryConvert pairs should coexist");
    assert_eq!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::TraitImplDef(..)))
            .count(),
        2
    );
}

fn local_callable_binding_requires_concrete_signature() {
    let resolved = resolve_with_builtin_prelude(r#"id = {|x| x}"#);
    let error =
        typecheck(resolved).expect_err("an untyped closure binding must not become polymorphic");
    assert!(
        error
            .message
            .contains("Callable binding requires a concrete signature"),
        "{error:?}"
    );
}

fn local_callable_binding_accepts_outer_rigid_generic() {
    typecheck(resolve_with_builtin_prelude(
        r#"def apply_identity(value: $A) -> $A {
  identity: ($A -> $A) = {|item| item}
  identity(value)
}
int_value: Int = apply_identity(1)
string_value: String = apply_identity("text")"#,
    ))
    .expect("an enclosing declaration's rigid generic may appear in a concrete local signature");
}

fn annotated_local_callable_remains_monomorphic() {
    let resolved = resolve_with_builtin_prelude(
        r#"id: (Int -> Int) = {|x| x}
bad: String = id("not an int")"#,
    );

    assert!(
        typecheck(resolved).is_err(),
        "an explicit callable annotation must prevent generalization"
    );
}

fn unbound_generic_argument_synthesizes_closure_shape() {
    let typed = typecheck_with_builtin_prelude(
        r#"def box(value: $A) -> $A { value }
increment = box({|n: Int| n + 1})
result: Int = increment(1)"#,
    );

    assert!(matches!(typed_bind_rhs(&typed, "result").ty, Ty::Int));
}

fn direct_generic_capture_uses_higher_order_expected_type() {
    let typed = typecheck_with_builtin_prelude(
        r#"def identity(value: $A) -> $A { value }
def apply(value: $A, f: ($A -> $A)) -> $A { f(value) }
result: Int = apply(1, &identity)"#,
    );
    assert!(matches!(typed_bind_rhs(&typed, "result").ty, Ty::Int));
}

fn generic_capture_binding_requires_concrete_signature() {
    let resolved = resolve_with_builtin_prelude(
        r#"def identity(value: $A) -> $A { value }
captured = &identity"#,
    );
    let error = typecheck(resolved)
        .expect_err("a generic capture must be concrete before it is bound to a variable");
    assert!(
        error
            .message
            .contains("Callable binding requires a concrete signature"),
        "{error:?}"
    );
}

fn expected_type_flows_to_if_and_match_branches() {
    let typed = typecheck_with_builtin_prelude(
        r#"chooser: (Int -> Int) = if(True, {|n: Int| n + 1}, {|n: Int| n - 1})
matched: (Int -> Int) = match True {
  True => {|n: Int| n + 1},
  False => {|n: Int| n - 1},
}
result: Int = chooser(1) + matched(1)"#,
    );

    assert!(matches!(typed_bind_rhs(&typed, "result").ty, Ty::Int));
}

fn trait_dispatch_rejects_impl_with_unsatisfied_where_obligation() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait Marker {
  def mark(self: Self) -> String
}

deftrait Use {
  def use(self: Self) -> String
}

impl Use for List<$A>
where
  $A: Marker
{
  def use(self: List<$A>) -> String {
    match self {
      [] => "usable",
      [head, ..tail] => Marker::mark(head),
    }
  }
}

values: List<Int> = [1]
result = Use::use(values)"#,
    );

    let err = typecheck(resolved).expect_err("unsatisfied impl bound must reject dispatch");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{err:?}"
    );
    assert!(err.message.contains("List<Int>"), "{err:?}");
}

fn direct_trait_call_on_rigid_generic_requires_declared_bound() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait Marker {
  def mark(self: Self) -> String
}

def hidden(value: $A) -> String {
  Marker::mark(value)
}"#,
    );

    let err = typecheck(resolved).expect_err("undeclared generic bound must be rejected");
    assert!(err.message.contains("MissingGenericBound"), "{err:?}");
    assert!(err.message.contains("must implement Marker"), "{err:?}");
}

fn deferred_trait_obligation_is_checked_when_closure_argument_is_bound() {
    let source = r#"deftrait Marker {
  def mark(self: Self) -> String
}

deftrait Use {
  def use(self: Self) -> String
}

defstruct ObligationBox<$A> {
  value: $A
}

impl ObligationBox {
  def new(value: $A) -> ObligationBox<$A> {
    ObligationBox { value: value }
  }
}

impl Use for ObligationBox<$A>
where
  $A: Marker
{
  def use(self: ObligationBox<$A>) -> String { Marker::mark(self.value) }
}

def invoke(value: $A, call: ($A -> String)) -> String { call(value) }
result = invoke(1, {|value| Use::use(ObligationBox(value))})"#;
    let resolved = resolve_with_builtin_prelude(source);

    let err = typecheck(resolved)
        .expect_err("the direct higher-order boundary must check Int's Marker obligation");
    assert!(
        err.message.contains("Argument type mismatch")
            || err.message.contains("Marker")
            || err.message.contains("No implementation satisfies Use"),
        "unexpected phase-boundary diagnostic: {err:?}"
    );

    let satisfied = source.replace(
        "def invoke(value: $A",
        "impl Marker for Int { def mark(self: Int) -> String { \"marked\" } }\n\ndef invoke(value: $A",
    );
    typecheck(resolve_with_builtin_prelude(&satisfied))
        .expect("the direct higher-order obligation must succeed when Int implements Marker");
}

fn child_impl_where_assumptions_cover_parent_impl_requirements() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait FixtureEq {
  def same(self: Self, other: Self) -> Boolean
}

deftrait FixtureShow {
  def show(self: Self) -> String
}

deftrait Parent {
  def parent(self: Self) -> String
}

deftrait Child
where
  Self: Parent
{
  def child(self: Self) -> String
}

impl Parent for List<$A>
where
  $A: FixtureEq
{
  def parent(self: List<$A>) -> String {
    match self {
      [] => "parent",
      [head, ..tail] => if(FixtureEq::same(head, head), "parent", "parent"),
    }
  }
}

impl Child for List<$A>
where
  $A: FixtureEq + FixtureShow
{
  def child(self: List<$A>) -> String {
    match self {
      [] => "child",
      [head, ..tail] => if(
        FixtureEq::same(head, head),
        FixtureShow::show(head),
        FixtureShow::show(head)
      ),
    }
  }
}"#,
    );

    typecheck(resolved).expect("a stronger child where clause must cover the parent impl");
}

fn child_impl_self_where_assumption_covers_parent_requirement() {
    let resolved = resolve_with_builtin_prelude(
        r#"deftrait Marker {
  def mark(self: Self) -> String
}

deftrait Parent {
  def parent(self: Self) -> String
}

deftrait Child
where
  Self: Parent
{
  def child(self: Self) -> String
}

impl Parent for List<$A>
where
  Self: Marker
{
  def parent(self: List<$A>) -> String { Marker::mark(self) }
}

impl Child for List<$A>
where
  Self: Marker
{
  def child(self: List<$A>) -> String { Marker::mark(self) }
}"#,
    );

    typecheck(resolved).expect("a child Self assumption must cover the parent requirement");
}

fn parameterized_parent_trait_bounds_cover_the_parent_family() {
    typecheck_with_standard_environment(
        r#"deftrait Parent<$Tag> {
  def parent(self: Self) -> String
}

deftrait Child<$Tag>
where
  Self: Parent
{
  def child(self: Self) -> String
}

defenum Boxed<$A> {
  Boxed($A),
}

impl Parent<Int> for Boxed<$A> {
  def parent(self: Boxed<$A>) -> String { "parent" }
}

impl Child<String> for Boxed<$A> {
  def child(self: Boxed<$A>) -> String { "child" }
}"#,
    )
    .expect("a bare Parent bound should require any Parent family instance for the target");

    let err = typecheck_with_standard_environment(
        r#"deftrait Parent<$Tag> {
  def parent(self: Self) -> String
}

deftrait Child<$Tag>
where
  Self: Parent
{
  def child(self: Self) -> String
}

defenum Boxed<$A> {
  Boxed($A),
}

defenum Other<$A> {
  Other($A),
}

impl Parent<Int> for Other<$A> {
  def parent(self: Other<$A>) -> String { "parent" }
}

impl Child<String> for Boxed<$A> {
  def child(self: Boxed<$A>) -> String { "child" }
}"#,
    )
    .expect_err("the parent family instance must still cover the same target");
    assert!(
        err.message.contains("requires parent impl Parent"),
        "{err:?}"
    );
}

fn generic_user_function_calls_typecheck_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"def id(x: $A) -> $A { x }

left: Int = id(1)
right: String = id("ok")
print(to_string(left))
print(right)"#,
    );
    assert!(matches!(typed_bind_rhs(&typed, "left").ty, Ty::Int));
    assert!(matches!(typed_bind_rhs(&typed, "right").ty, Ty::Str));
    assert!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::App(_, _)))
            .count()
            >= 2,
        "expected both generic function call sites to typecheck"
    );
}

fn where_constraint_kinds_survive_in_typed_metadata() {
    let typed = typecheck_with_standard_environment(
        r#"deftrait Marker
where
  Self: Type<$Slot>
{
  def mark(self: Self) -> Self
  where
    Self: Marker
}

defenum Boxed<$T> {
  Box($T),
}

impl Marker for Boxed<$T>
where
  $T: Marker.$Slot
{
  def mark(self: Self) -> Self
  where
    Self: Marker
  {
    Marker::mark(self)
  }
}"#,
    )
    .expect("constraint kinds should survive after semantic validation");

    let (trait_where, trait_methods) = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::TraitDef(name, where_clause, methods) if name.ends_with("Marker") => {
                Some((where_clause.as_ref(), methods))
            }
            _ => None,
        })
        .expect("typed trait should retain metadata");
    let trait_where = trait_where.expect("typed trait should retain its shape");
    assert!(matches!(
        trait_where.constraints[0].bounds[0],
        TypedWhereConstraintRhs::TypeConstructor { .. }
    ));
    let method_where = trait_methods[0]
        .where_clause
        .as_ref()
        .expect("typed trait method should retain its bare capability");
    assert!(matches!(
        method_where.constraints[0].bounds[0],
        TypedWhereConstraintRhs::Trait { .. }
    ));
    let impl_where = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::TraitImplDef(_, _, Some(clause)) => Some(clause),
            _ => None,
        })
        .expect("typed impl should retain its slot map");
    assert!(matches!(
        impl_where.constraints[0].bounds[0],
        TypedWhereConstraintRhs::TraitSlot { .. }
    ));
}

fn function_where_bounds_propagate_to_generic_call_sites() {
    let source = r#"def make(seed: $A) -> $A
where
  $A: Default
{
  Default::default()
}
"#;

    typecheck_with_rules(
        &format!("{source}\nvalue: String = make(\"seed\")"),
        RuntimeSourcePolicy::script(),
    )
    .expect("a call target with the declared where-bound implementation should typecheck");

    let err = typecheck_with_rules(
        &format!("{source}\nvalue: Boolean = make(True)"),
        RuntimeSourcePolicy::script(),
    )
    .expect_err("the generic call must retain and enforce its where bound");
    assert!(
        err.message.contains("expected Int") || err.message.contains("Default"),
        "unexpected diagnostic: {err:?}"
    );
}

fn where_clause_does_not_declare_a_new_type_variable() {
    let err = typecheck_with_rules(
        r#"def id(value: $A) -> $A
where
  $B: Default
{
  value
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a where-only type variable must not be introduced implicitly");

    assert!(err
        .message
        .contains("does not appear in the declaration signature"));
    assert!(err
        .hint
        .as_deref()
        .is_some_and(|hint| hint.contains("do not declare type variables")));
}

fn functor_shaped_self_applications_survive_in_typed_metadata() {
    let typed = typecheck_with_rules(
        r#"deftrait FunctorShape
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("Step 4 should preserve higher-kinded Self applications");

    let method = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::TraitDef(name, _, methods) if name.ends_with("FunctorShape") => {
                methods.iter().find(|method| method.name == "fmap")
            }
            _ => None,
        })
        .expect("typed trait metadata should retain fmap");
    assert!(matches!(method.params.first(), Some(Ty::SelfApp(args)) if args.len() == 1));
    assert!(matches!(method.ret_ty, Ty::SelfApp(ref args) if args.len() == 1));
}

fn unary_type_constructor_slot_is_inferred_for_trait_impl() {
    typecheck_with_rules(
        r#"deftrait FunctorShape
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

defenum Box<$T> {
  Box($T),
}

impl FunctorShape for Box<$T> {
  def fmap(self: Box<$A>, mapper: ($A -> $B)) -> Box<$B> {
    match self {
      Box::Box(value) => Box::Box(mapper(value)),
    }
  }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("a unary impl target should map its only parameter to the trait slot");
}

fn multi_parameter_type_constructor_requires_explicit_slot_mapping() {
    let source = r#"deftrait FunctorShape
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

defenum Pair<$L, $R> {
  Pair($L, $R),
}

impl FunctorShape for Pair<$L, $R> {
  def fmap(self: Pair<$L, $A>, mapper: ($A -> $B)) -> Pair<$L, $B> {
    match self {
      Pair::Pair(left, right) => Pair::Pair(left, mapper(right)),
    }
  }
}"#;
    let err = typecheck_with_rules(source, RuntimeSourcePolicy::script())
        .expect_err("a multi-parameter target must name the public constructor slot");
    assert!(err.message.contains("does not satisfy Type<$A>"), "{err:?}");

    typecheck_with_rules(
        &source.replace(
            "impl FunctorShape for Pair<$L, $R> {",
            "impl FunctorShape for Pair<$L, $R>\nwhere\n  $R: FunctorShape.$A\n{",
        ),
        RuntimeSourcePolicy::script(),
    )
    .expect("an explicit slot mapping should preserve the left capture parameter");
}

fn type_constructor_constraint_rejects_concrete_and_duplicate_slot_targets() {
    let trait_source = r#"deftrait FunctorShape
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}
"#;
    let concrete = format!(
        "{trait_source}\nimpl FunctorShape for Int {{\n  def fmap(self: Int, mapper: (Int -> Int)) -> Int {{ self }}\n}}"
    );
    let err = typecheck_with_rules(&concrete, RuntimeSourcePolicy::script())
        .expect_err("a concrete type is not a unary type constructor");
    assert!(err.message.contains("does not satisfy Type<$A>"), "{err:?}");

    let duplicate = format!(
        r#"{trait_source}
defenum Pair<$L, $R> {{
  Pair($L, $R),
}}
impl FunctorShape for Pair<$L, $R>
where
  $L: FunctorShape.$A
  $R: FunctorShape.$A
{{
  def fmap(self: Pair<$L, $A>, mapper: ($A -> $B)) -> Pair<$L, $B> {{ self }}
}}"#
    );
    let err = typecheck_with_rules(&duplicate, RuntimeSourcePolicy::script())
        .expect_err("one constructor slot cannot map to two target parameters");
    assert!(err.message.contains("mapped more than once"), "{err:?}");
}

fn malformed_resolved_type_shape_requires_self_lhs() {
    let mut resolved = resolve_with_standard_environment(
        r#"deftrait Shape
where
  Self: Type<$A>
{}"#,
    );
    let constraint = resolved
        .iter_mut()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, Some(clause), _, _) if id.name == "Shape" => {
                clause.constraints.first_mut()
            }
            _ => None,
        })
        .expect("Shape should retain its resolved where constraint");
    constraint.subject = AstTy::Named(constraint.span.clone(), "$A".into());

    let err =
        support::typecheck(resolved).expect_err("Type<...> must require a Self subject in Scar");
    assert!(
        err.message.contains("only allowed") && err.message.contains("Self: Type"),
        "{err:?}"
    );
}

fn malformed_resolved_type_shape_is_rejected_outside_trait_definition_where() {
    let mut function = resolve_with_standard_environment(
        r#"deftrait Marker {}

def keep(value: $A) -> $A
where
  $A: Marker
{
  value
}"#,
    );
    let constraint = function
        .iter_mut()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, Some(clause), _, _) if id.name == "keep" => {
                clause.constraints.first_mut()
            }
            _ => None,
        })
        .expect("keep should retain its resolved where constraint");
    constraint.bounds[0] = ResolvedWhereConstraintRhs::TypeConstructor {
        span: constraint.span.clone(),
        slots: vec![AstTy::Named(constraint.span.clone(), "$A".into())],
    };
    let err =
        support::typecheck(function).expect_err("function where must reject Type<...> in Scar");
    assert!(err.message.contains("trait definition where"), "{err:?}");

    let mut trait_impl = resolve_with_standard_environment(
        r#"deftrait Marker {}

defenum LocalList<$A> {
  Item($A),
}

impl Marker for LocalList<$A>
where
  $A: Marker
{}"#,
    );
    let constraint = trait_impl
        .iter_mut()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, _, Some(clause), _) if id.name == "Marker" => {
                clause.constraints.first_mut()
            }
            _ => None,
        })
        .expect("Marker impl should retain its resolved where constraint");
    constraint.bounds[0] = ResolvedWhereConstraintRhs::TypeConstructor {
        span: constraint.span.clone(),
        slots: vec![AstTy::Named(constraint.span.clone(), "$A".into())],
    };
    let err =
        support::typecheck(trait_impl).expect_err("trait impl where must reject Type<...> in Scar");
    assert!(err.message.contains("trait definition where"), "{err:?}");

    let mut trait_method = resolve_with_standard_environment(
        r#"deftrait Marker {}

deftrait HasMethod {
  def keep(self: Self) -> Self
  where
    Self: Marker
}"#,
    );
    let constraint = trait_method
        .iter_mut()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, methods, _) if id.name == "HasMethod" => methods
                .iter_mut()
                .find(|method| method.id.name == "keep")
                .and_then(|method| method.where_clause.as_mut())
                .and_then(|clause| clause.constraints.first_mut()),
            _ => None,
        })
        .expect("trait method should retain its resolved where constraint");
    constraint.bounds[0] = ResolvedWhereConstraintRhs::TypeConstructor {
        span: constraint.span.clone(),
        slots: vec![AstTy::Named(constraint.span.clone(), "$A".into())],
    };
    let err = support::typecheck(trait_method)
        .expect_err("trait method where must reject Type<...> in Scar");
    assert!(err.message.contains("trait definition where"), "{err:?}");
}

fn type_constructor_shape_must_be_unique_in_a_trait_definition() {
    let err = typecheck_with_standard_environment(
        r#"deftrait InvalidShape
where
  Self: Type<$A> + Type<$B>
{}"#,
    )
    .expect_err("a trait must declare at most one Type<...> shape");
    assert!(err.message.contains("more than one"), "{err:?}");
}

fn inherited_constructor_trait_accepts_captured_head_parameters() {
    typecheck_with_standard_environment(
        r#"deftrait Direct<$Tag>
where
  Self: Type<$A>
{}"#,
    )
    .expect("a direct constructor trait may capture a distinct trait-head parameter");

    typecheck_with_standard_environment(
        r#"deftrait RootShape
where
  Self: Type<$A>
{}

deftrait Child<$Base>
where
  $Base: RootShape
  Self: RootShape
{
  def lift::<Self>(value: $Base<$A>) -> Self<$A>
}"#,
    )
    .expect("an inherited constructor trait should keep captured and mapped inputs separate");
}

fn constructor_slot_maps_require_top_level_target_parameters_and_completeness() {
    let declarations = r#"deftrait PairShape
where
  Self: Type<$Left, $Right>
{}

defenum Pair<$Left, $Right> {
  Pair($Left, $Right),
}

defenum Wrapper<$Item> {
  Wrap($Item),
}"#;

    let nested = format!(
        r#"{declarations}

impl PairShape for Pair<Wrapper<$Item>, $Right>
where
  $Item: PairShape.$Left
  $Right: PairShape.$Right
{{}}"#
    );
    let err = typecheck_with_standard_environment(&nested)
        .expect_err("a nested target variable cannot own a constructor slot");
    assert!(
        err.message.contains("not a top-level type parameter"),
        "{err:?}"
    );

    let incomplete = format!(
        r#"{declarations}

impl PairShape for Pair<$Left, $Right>
where
  $Left: PairShape.$Left
{{}}"#
    );
    let err = typecheck_with_standard_environment(&incomplete)
        .expect_err("every constructor slot must be mapped");
    assert!(
        err.message.contains("map every constructor slot"),
        "{err:?}"
    );
}

fn plain_inherent_owner_expands_self_applications_to_its_target() {
    typecheck_with_standard_environment(
        r#"defstruct Box<$A> {
  value: $A,
}

impl Box {
  def new(value: $A) -> Self<$A> {
    Box { value: value }
  }

  def wrap(value: $A) -> Self<$A> {
    Box { value: value }
  }

  def get(self: Self<$A>) -> $A {
    self.value
  }
}

boxed: Box<Int> = Box::wrap(1)
value: Int = Box::get(boxed)"#,
    )
    .expect("Self<$A> in a plain inherent owner should mean Box<$A>");
}

fn canonical_builtin_inherent_owners_expand_self_applications_to_their_targets() {
    for owner in ["List", "HashMap", "Workers", "TaskHandle"] {
        let source = format!(
            r#"impl {owner} {{
  def keep(value: Self<$A>) -> Self<$A> {{ value }}
}}"#
        );
        typecheck_with_standard_environment(&source).unwrap_or_else(|err| {
            panic!("Self<$A> in canonical builtin owner {owner} should expand: {err:?}")
        });
    }
}

fn trait_contract_self_substitution_preserves_captured_target_parameters() {
    typecheck_with_standard_environment(
        r#"deftrait ReplaceRight
where
  Self: Type<$A>
{
  def replace(self: Self<$A>, value: $B) -> Self<$B>
}

defenum Pair<$Left, $Right> {
  Pair($Left, $Right),
}

impl ReplaceRight for Pair<$Captured, $Slot>
where
  $Slot: ReplaceRight.$A
{
  def replace(self: Pair<$Captured, $A>, value: $B) -> Pair<$Captured, $B> {
    match self {
      Pair::Pair(left, _) => Pair::Pair(left, value),
    }
  }
}"#,
    )
    .expect("trait contract expansion must preserve captured target parameters");
}

fn same_trait_constructor_parameters_share_one_witness() {
    let error = typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Left<$T> {
  Left($T),
}

defenum Right<$T> {
  Right($T),
}

impl Context for Left<$T>
where
  $T: Context.$A
{}

impl Context for Right<$T>
where
  $T: Context.$A
{}

def accept(left: Context<Int>, right: Context<String>) -> Unit { () }

accept(Left::Left(1), Right::Right("ok"))"#,
    )
    .expect_err("the same direct Trait name must share one constructor witness");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::TypeConstructorFamilyMismatch),
        "{error:?}"
    );
}

fn constructor_application_result_shares_the_input_witness() {
    let error = typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Left<$T> {
  Left($T),
}

defenum Right<$T> {
  Right($T),
}

impl Context for Left<$T>
where
  $T: Context.$A
{}

impl Context for Right<$T>
where
  $T: Context.$A
{}

def replace(value: Context<Int>) -> Context<String> {
  Right::Right("ok")
}

result: Right<String> = replace(Left::Left(1))"#,
    )
    .expect_err("a direct result with the same Trait name shares the input witness");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch),
        "{error:?}"
    );
}

fn constructor_application_result_accepts_the_shared_abstract_input_witness() {
    typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

def preserve(value: Context<Int>) -> Context<Int> { value }"#,
    )
    .expect("the direct result reuses the abstract input witness");
}

fn constructor_application_result_rejects_mixed_concrete_constructors() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Left<$T> {
  Left($T),
}

defenum Right<$T> {
  Right($T),
}

impl Context for Left<$T>
where
  $T: Context.$A
{}

impl Context for Right<$T>
where
  $T: Context.$A
{}

def make::<Context>(flag: Boolean) -> Context<Int> {
  if(flag, Left::Left(1), Right::Right(1))
}"#,
    )
    .expect_err("all contextual result paths must resolve to one constructor");

    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::IfBranchTypeMismatch),
        "{err:?}"
    );
}

fn identity_dependent_constructor_applications_are_rejected_outside_direct_signatures() {
    let declarations = r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Boxed<$T> {
  Boxed($T),
}

impl Context for Boxed<$T>
where
  $T: Context.$A
{}"#;
    let cases = [
        ("field", r#"defrecord Holder(value: Context<Int>)"#),
        (
            "local annotation",
            r#"def invalid(value: Boxed<Int>) -> Unit {
  local: Context<Int> = value
  ()
}"#,
        ),
        (
            "closure signature",
            r#"def invalid(value: Boxed<Int>) -> Unit {
  mapper = {|item: Context<Int>| ()}
  ()
}"#,
        ),
        (
            "nested signature",
            r#"def invalid(values: List<Context<Int>>) -> Unit { () }"#,
        ),
    ];

    for (label, case) in cases {
        let err = typecheck_with_standard_environment(&format!("{declarations}\n\n{case}"))
            .expect_err(label);
        assert!(
            err.message.contains("ConstructorTraitApplicationPosition"),
            "{label}: {err:?}"
        );
    }
}

fn extractor_signatures_reject_identity_dependent_constructor_applications() {
    let declarations = r#"deftrait Context
where
  Self: Type<$A>
{}

"#;
    let cases = [
        (
            "builtin extractor parameter",
            r#"@builtin defextractor invalid(term: Context<Int>) -> MatchResult<Int>"#,
        ),
        (
            "ordinary extractor return",
            r#"defstruct Owner {}

impl Owner {
  def new() -> Self { Owner {} }
  defextractor invalid(self: Self) -> MatchResult<Context<Int>> { () }
}"#,
        ),
    ];

    for (label, case) in cases {
        let source = format!("{declarations}\n\n{case}");
        let result = if label == "builtin extractor parameter" {
            let ast = spire::parse_with_context(
                &source,
                spire::ParserContext::project(0).with_rules(spire::ParseRules::std_module()),
            )
            .expect("builtin extractor source should parse under std rules");
            support::typecheck(
                support::resolve_ast_with_builtin_prelude(ast)
                    .expect("builtin extractor source should resolve"),
            )
        } else {
            typecheck_with_standard_environment(&source)
        };
        let err = result.expect_err(label);
        assert!(
            err.message.contains("ConstructorTraitApplicationPosition"),
            "{label}: {err:?}"
        );
    }
}

fn trait_default_contextual_result_requires_constructor_trait_membership() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Other<$T> {
  Other($T),
}

deftrait Maker {
  def make::<Context>(value: Int) -> Context<Int> { Other::Other(value) }
}"#,
    )
    .expect_err("a default body cannot return a constructor outside Context");

    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{err:?}"
    );
}

fn trait_impl_contextual_result_requires_constructor_trait_membership() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Other<$T> {
  Other($T),
}

deftrait Maker {
  def make::<Context>(value: Int) -> Context<Int>
}

impl Maker for Int {
  def make::<Context>(value: Int) { Other::Other(value) }
}"#,
    )
    .expect_err("an impl body cannot return a constructor outside Context");

    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{err:?}"
    );
}

fn trait_impl_contextual_result_accepts_an_implementing_constructor() {
    typecheck_with_standard_environment(
        r#"deftrait Context
where
  Self: Type<$A>
{}

defenum Boxed<$T> {
  Boxed($T),
}

impl Context for Boxed<$T>
where
  $T: Context.$A
{}

deftrait Maker {
  def make::<Context>(value: Int) -> Context<Int>
}

impl Maker for Int {
  def make::<Context>(value: Int) { Boxed::Boxed(value) }
}"#,
    )
    .expect("an impl body may resolve its contextual result to a Context constructor");
}

fn bare_capability_is_consumed_by_a_full_parameterized_trait_obligation() {
    let typed = typecheck_with_standard_environment(
        r#"deftrait FixtureConvert<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl FixtureConvert<String> for Int {
  def convert::<String>(self: Int) -> String { "converted" }
}

def convert_to_string(value: $From) -> String
where
  $From: FixtureConvert
{
  FixtureConvert::convert::<String>(value)
}

result: String = convert_to_string(1)"#,
    )
    .expect(
        "the bare family capability must authorize forwarding a full FixtureConvert<String> obligation",
    );

    let obligation = typed.iter().find_map(|node| match &node.node {
        TypedInner::Def(_, id, _, _, _, _, body, _) if id.name == "convert_to_string" => {
            match &body.node {
                TypedInner::Block(stmts) => stmts.last(),
                _ => Some(body.as_ref()),
            }
            .and_then(|node| match &node.node {
                TypedInner::TraitCall {
                    obligation,
                    dispatch,
                    ..
                } => Some((obligation, dispatch)),
                _ => None,
            })
        }
        _ => None,
    });
    let (obligation, dispatch) =
        obligation.expect("the trait call must retain its structural obligation");
    assert!(obligation.trait_id.ends_with("FixtureConvert"));
    assert_eq!(obligation.trait_args, vec![Ty::Str]);
    assert_eq!(obligation.receiver, Ty::Int);
    assert!(matches!(dispatch, scar::typed::TraitDispatch::Static(_)));
}

fn unused_function_capability_is_rejected_at_its_bound() {
    let source = r#"deftrait Marker {
  def mark(self: Self) -> Unit
}

def ignore(value: $T) -> Unit
where
  $T: Marker
{
  ()
}"#;
    let marker_start = source.find("Marker\n{").expect("bound marker span");
    let err = typecheck_with_standard_environment(source)
        .expect_err("a bare capability that creates no full obligation must be rejected");

    assert!(err.message.contains("UnusedTraitConstraint"), "{err:?}");
    assert_eq!(err.span.start, marker_start);
}

fn unused_trait_method_capability_is_rejected_at_its_bound() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Marker {
  def mark(self: Self) -> Unit
}

deftrait Consumer {
  def consume(value: $T) -> Unit
  where
    $T: Marker
  {
    ()
  }
}"#,
    )
    .expect_err("an unused default-method capability must be rejected");
    assert!(err.message.contains("UnusedTraitConstraint"), "{err:?}");
}

fn unused_trait_impl_method_capability_is_rejected_at_its_bound() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Marker {
  def mark(self: Self) -> Unit
}

deftrait Consumer {
  def consume(value: $T) -> Unit
  where
    $T: Marker
}

impl Consumer for Int {
  def consume(value: $T) -> Unit
  where
    $T: Marker
  {
    ()
  }
}"#,
    )
    .expect_err("an unused impl-method capability must be rejected");
    assert!(err.message.contains("UnusedTraitConstraint"), "{err:?}");
}

fn unused_trait_impl_block_capability_is_rejected_after_all_methods() {
    let err = typecheck_with_standard_environment(
        r#"deftrait Marker {
  def mark(self: Self) -> Unit
}

deftrait Keep {
  def keep(self: Self) -> Self
}

defenum Boxed<$T> {
  Boxed($T),
}

impl Keep for Boxed<$T>
where
  $T: Marker
{
  def keep(self: Boxed<$T>) -> Boxed<$T> { self }
}"#,
    )
    .expect_err("an impl-block capability unused by every method must be rejected");
    assert!(err.message.contains("UnusedTraitConstraint"), "{err:?}");
}

fn operator_obligation_consumes_a_bare_capability() {
    typecheck_with_standard_environment(
        r#"def duplicate(value: $T) -> $T
where
  $T: Add
{
  value + value
}

result: Int = duplicate(1)"#,
    )
    .expect("operator lowering must consume the matching bare capability");
}

fn generic_call_forwards_and_consumes_a_bare_capability() {
    typecheck_with_standard_environment(
        r#"deftrait Marker {
  def mark(self: Self) -> Unit
}

impl Marker for Int {
  def mark(self: Int) -> Unit { () }
}

def consume(value: $T) -> Unit
where
  $T: Marker
{
  Marker::mark(value)
}

def forward(value: $T) -> Unit
where
  $T: Marker
{
  consume(value)
}

forward(1)"#,
    )
    .expect("a generic call must consume the proof it forwards to its callee");
}

fn different_constructor_roots_keep_independent_parameter_witnesses() {
    typecheck_with_standard_environment(
        r#"deftrait LeftContext
where
  Self: Type<$A>
{}

deftrait RightContext
where
  Self: Type<$A>
{}

defenum Boxed<$T> {
  Boxed($T),
}

impl LeftContext for Boxed<$T>
where
  $T: LeftContext.$A
{}

impl RightContext for Boxed<$T>
where
  $T: RightContext.$A
{}

def accept(left: LeftContext<Int>, right: RightContext<String>) -> Unit { () }

accept(Boxed::Boxed(1), Boxed::Boxed("ok"))"#,
    )
    .expect("different constructor roots must never share a parameter witness");
}

fn parent_trait_constraints_require_matching_impls_and_inherit_slots() {
    let declarations = r#"deftrait Parent
where
  Self: Type<$A>
{
  def keep(self: Self<$A>) -> Self<$A>
}

deftrait Child
where
  Self: Parent
{
  def child_keep(self: Self<$A>) -> Self<$A>
}

defenum Box<$T> {
  Box($T),
}
"#;
    let child_impl = r#"impl Child for Box<$T> {
  def child_keep(self: Box<$A>) -> Box<$A> { self }
}"#;
    let err = typecheck_with_rules(
        &format!("{declarations}\n{child_impl}"),
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a child impl cannot omit its parent impl");
    assert!(
        err.message.contains("requires parent impl Parent"),
        "{err:?}"
    );

    typecheck_with_rules(
        &format!(
            r#"{declarations}
impl Parent for Box<$T> {{
  def keep(self: Box<$A>) -> Box<$A> {{ self }}
}}
{child_impl}"#
        ),
        RuntimeSourcePolicy::script(),
    )
    .expect("the child should inherit the parent's unary constructor slot");
}

fn concrete_constructor_implementation_can_be_passed_to_parent_or_child_trait() {
    typecheck_with_rules(
        r#"
def take_applicative(value: Applicative<$A>) -> Unit { () }
def take_functor(value: Functor<$A>) -> Unit { () }

take_applicative(Option::Some(1))
take_functor(Option::Some(1))
"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("a concrete Option value should satisfy either constructor trait");
}

fn abstract_applicative_cannot_use_monad_helper_but_concrete_option_can() {
    let err = typecheck_with_rules(
        r#"
def invalid(value: Applicative<$A>) -> Applicative<$A> {
  Monad::bind(value, {|n| value})
}
"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("an Applicative binding must not expose Monad operations");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
        "{err:?}"
    );
    assert_eq!(
        err.structured.as_ref().unwrap().data_json()["required_capability"],
        "Monad"
    );

    typecheck_with_rules(
        r#"
def valid(value: Option<$A>) -> Option<$A> {
  Monad::bind(value, {|n| value})
}

valid(Option::Some(1))
"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("a concrete Option binding must expose its Monad implementation");

    let err = typecheck_with_rules(
        r#"
def preserve_applicative2(value: Applicative<Int>) -> Applicative<String> {
  ret: Option<Int> = value
  Monad::bind(ret, {|num| Option::Some(to_string(num))})
}

preserve_applicative2(Option::Some(1))
"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("an abstract carrier cannot be narrowed to Option by a body annotation");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch),
        "{err:?}"
    );
}

fn trait_default_methods_and_private_helpers_are_accepted() {
    let source = r#"
deftrait DefaultValue {
  def value(self: Self) -> Int { helper() }
  defp helper() -> Int { 42 }
}

impl DefaultValue for Int {
  defp helper() -> Int { 7 }
}
"#;
    typecheck_with_rules(source, RuntimeSourcePolicy::script())
        .expect("default trait methods and impl-private helpers should typecheck");
}

fn parent_trait_cycles_and_slot_mapping_mismatches_are_rejected() {
    let cycle = r#"deftrait Left
where
  Self: Right
{
  def left(self: Self) -> Self
}

deftrait Right
where
  Self: Left
{
  def right(self: Self) -> Self
}"#;
    let err = typecheck_with_rules(cycle, RuntimeSourcePolicy::script())
        .expect_err("parent trait cycles must be rejected");
    assert!(err.message.contains("constraint cycle"), "{err:?}");

    let mismatch = r#"deftrait Parent
where
  Self: Type<$A>
{
  def keep(self: Self<$A>) -> Self<$A>
}

deftrait Child
where
  Self: Parent
{
  def child_keep(self: Self<$A>) -> Self<$A>
}

defenum Pair<$L, $R> {
  Pair($L, $R),
}

impl Parent for Pair<$L, $R>
where
  $R: Parent.$A
{
  def keep(self: Pair<$L, $A>) -> Pair<$L, $A> { self }
}

impl Child for Pair<$L, $R>
where
  $L: Child.$A
{
  def child_keep(self: Pair<$A, $R>) -> Pair<$A, $R> { self }
}"#;
    let err = typecheck_with_rules(mismatch, RuntimeSourcePolicy::script())
        .expect_err("a child must preserve its parent's slot mapping");
    assert!(
        err.message.contains("same constructor slot mapping"),
        "{err:?}"
    );
}

fn trait_impl_signature_validation_preserves_generic_relationships() {
    let err = typecheck_with_rules(
        r#"deftrait Pick {
  def pick(left: $A, right: $B) -> $A
}

impl Pick for Int {
  def pick(left: $A, right: $B) -> $B { right }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("an impl cannot permute independent method generics");
    assert!(err.message.contains("incompatible signature"), "{err:?}");
}

fn trait_impl_method_generics_are_rigid_while_checking_the_body() {
    let err = typecheck_with_rules(
        r#"deftrait Keep {
  def keep(value: $A) -> $A
}

impl Keep for Int {
  def keep(value: $A) -> $A { "wrong" }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("an impl body cannot specialize its method generic to String");
    assert!(
        err.reason() == Some(diagnostics::TypeDiagnosticReason::ReturnTypeMismatch)
            && err.message.contains("expected $A, got String"),
        "{err:?}"
    );
}

fn return_only_signature_slots_are_rejected() {
    let err = typecheck_with_rules(
        r#"def nil() -> $A {
  ""
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a return-only signature slot must be rejected");
    assert!(err
        .message
        .contains("return-only type input `$A` is not declared"));

    typecheck_with_builtin_prelude(r#"def id(value: $A) -> $A { value }"#);
}

fn signature_slots_are_checked_before_definition_bodies() {
    let err = typecheck_with_rules(
        r#"def wrong(value: $A) -> $B {
  value
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a return-only signature slot must be rejected before body checking");
    assert!(err
        .message
        .contains("return-only type input `$B` is not declared"));

    let err = typecheck_with_rules(
        r#"def identity(value: $A) -> $A { value }

def gen_nil() -> List<$A> { [] }"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a return-only signature slot must be rejected");
    assert!(err
        .message
        .contains("return-only type input `$A` is not declared"));
}

fn named_args_user_function_calls_typecheck_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"def add(x: Int, y: Int) -> Int { x + y }
def add3(x: Int, y: Int, z: Int) -> Int { x + y + z }

print(to_string(add(y: 2, x: 1)))
print(to_string(add3(z: 3, y: 2, x: 1)))"#,
    );
    assert!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::Def(..)))
            .count()
            >= 2,
        "expected named-argument user functions to typecheck"
    );
}

fn canonical_builtin_type_name_hole_is_reserved_for_structs() {
    let err = typecheck_module_source_result(
        r#"defstruct Hole {
  value: Int,
}"#,
    )
    .expect_err("Hole should be reserved");
    assert!(
        err.contains("Owner name `Hole` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn canonical_builtin_type_name_hole_is_reserved_for_enums() {
    let err = typecheck_module_source_result(
        r#"defenum Hole {
  Filled,
}"#,
    )
    .expect_err("Hole should be reserved");
    assert!(
        err.contains("Type name `Hole` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn canonical_builtin_type_name_hole_is_reserved_for_errors() {
    let err = typecheck_module_source_result(
        r#"deferror Hole {
  "reserved"
}"#,
    )
    .expect_err("Hole should be reserved");
    assert!(
        err.contains("Owner name `Hole` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn canonical_builtin_type_name_closure_is_reserved_for_structs() {
    let err = typecheck_module_source_result(
        r#"defstruct Closure {
  value: Int,
}"#,
    )
    .expect_err("Closure should be reserved");
    assert!(
        err.contains("Owner name `Closure` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn canonical_builtin_type_name_match_arms_is_reserved_for_structs() {
    let err = typecheck_module_source_result(
        r#"defstruct MatchArms {
  value: Int,
}"#,
    )
    .expect_err("MatchArms should be reserved");
    assert!(
        err.contains("Owner name `MatchArms` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn canonical_builtin_type_name_cond_clauses_is_reserved_for_enums() {
    let err = typecheck_module_source_result(
        r#"defenum CondClauses {
  Clause,
}"#,
    )
    .expect_err("CondClauses should be reserved");
    assert!(
        err.contains("Type name `CondClauses` is reserved by a canonical builtin type declaration"),
        "unexpected error: {err}"
    );
}

fn match_arms_type_is_forbidden_in_ordinary_user_signatures() {
    let err = typecheck_with_rules(
        r#"def bad(arms: MatchArms<Int, String>) -> String {
  "nope"
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("MatchArms should be restricted to special-form signatures");
    assert!(
        err.message
            .contains("MatchArms<$Scrutinee, $Result> is reserved for the `match` special form"),
        "unexpected error: {err}"
    );
}

fn match_arms_type_is_forbidden_in_return_types() {
    let err = typecheck_with_rules(
        r#"def bad() -> MatchArms<Int, String> {
  "nope"
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("MatchArms should be restricted to special-form return types");
    assert!(
        err.message
            .contains("MatchArms<$Scrutinee, $Result> is reserved for the `match` special form"),
        "unexpected error: {err}"
    );
}

fn cond_clauses_type_is_forbidden_in_ordinary_user_signatures() {
    let err = typecheck_with_rules(
        r#"def bad(clauses: CondClauses<String>) -> String {
  "nope"
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("CondClauses should be restricted to special-form signatures");
    assert!(
        err.message
            .contains("CondClauses<$Result> is reserved for the `cond` special form"),
        "unexpected error: {err}"
    );
}

fn cond_clauses_type_is_forbidden_in_return_types() {
    let err = typecheck_with_rules(
        r#"def bad() -> CondClauses<String> {
  "nope"
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("CondClauses should be restricted to special-form return types");
    assert!(
        err.message
            .contains("CondClauses<$Result> is reserved for the `cond` special form"),
        "unexpected error: {err}"
    );
}

fn do_block_type_is_reserved_in_ordinary_type_positions() {
    for source in [
        r#"def bad(block: DoBlock<Int>) -> Int { 1 }"#,
        r#"def bad() -> DoBlock<Int> { 1 }"#,
        r#"defstruct Bad { block: DoBlock<Int> }"#,
        r#"def bad() -> Int { block: DoBlock<Int> = 1; 1 }"#,
        r#"def bad(blocks: List<DoBlock<Int>>) -> Int { 1 }"#,
    ] {
        let err = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("DoBlock must not be an ordinary first-class type");
        assert_eq!(
            err.reason(),
            Some(diagnostics::TypeDiagnosticReason::ReservedIntrinsicMarkerUsage),
            "unexpected error for {source}: {err}"
        );
        assert!(
            err.message
                .contains("`DoBlock` is reserved for the compiler-owned `do` signature"),
            "unexpected error for {source}: {err}"
        );
        assert_eq!(
            err.span.start,
            source.find("DoBlock").expect("fixture contains DoBlock"),
            "primary span must point to the reserved marker"
        );
    }
}

fn do_explicit_and_expected_carriers_typecheck() {
    for source in [
        "result = do::<Option> { Monad::return(1) }",
        "result: Option<Int> = do { Monad::return(1) }",
        "result: Option<Int> = do::<_> { Monad::return(1) }",
    ] {
        let typed = typecheck_with_builtin_prelude_in_script_module(source);
        let rhs = typed
            .iter()
            .rev()
            .find_map(|node| match &node.node {
                TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "result") => Some(rhs),
                _ => None,
            })
            .unwrap_or_else(|| panic!("expected result binding for {source}"));
        assert_eq!(
            rhs.ty,
            Ty::Enum("Global::Option".into(), vec![Ty::Int]),
            "{source}"
        );
    }
}

fn do_resolved_contract_preserves_canonical_trait_ids() {
    let resolved = resolve_program_with_builtin_prelude(
        "result: Option<Int> = do::<Option> { Option::Some(1) }",
    );
    let canonical_monad = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, ..) if id.name == "Monad" => Some(id),
            _ => None,
        })
        .expect("canonical Monad declaration");
    let canonical_alternative = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, ..) if id.name == "Alternative" => Some(id),
            _ => None,
        })
        .expect("canonical Alternative declaration");
    let contract = resolved
        .iter()
        .rev()
        .find_map(|node| match node {
            Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
                Resolved::Do(_, _, contract, ..) => Some(contract),
                _ => None,
            },
            _ => None,
        })
        .expect("resolved do contract");

    assert_eq!(
        contract.monad_trait.as_ref().map(|id| id.unique_id),
        Some(canonical_monad.unique_id)
    );
    assert_eq!(
        contract.alternative_trait.as_ref().map(|id| id.unique_id),
        Some(canonical_alternative.unique_id)
    );
}

fn do_infers_carrier_from_each_monadic_origin() {
    for source in [
        // The final expression is the only monadic origin.
        "result = do { Option::Some(1) }",
        // The first `<-` RHS fixes the carrier before the final expression.
        r#"result = do {
  value <- Option::Some(1)
  Option::Some(value)
}"#,
        // A bare monadic statement fixes the carrier and is sequenced through bind.
        r#"result = do {
  Option::Some(1)
  Option::Some(2)
}"#,
        // Normal call-site RTA inference fixes the first call before do-local unification.
        r#"result = do {
  value <- Monad::return::<Option>(1)
  Monad::return(value)
}"#,
    ] {
        let typed = typecheck_with_builtin_prelude_in_script_module(source);
        let rhs = typed
            .iter()
            .rev()
            .find_map(|node| match &node.node {
                TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "result") => Some(rhs),
                _ => None,
            })
            .expect("expected result binding");
        assert_eq!(
            rhs.ty,
            Ty::Enum("Global::Option".into(), vec![Ty::Int]),
            "{source}"
        );
    }
}

fn do_rejects_ambiguous_and_conflicting_carriers() {
    let ambiguous = typecheck_with_rules(
        "result = do { Monad::return(1) }",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("an unconstrained constructor-producing call must remain ambiguous");
    assert_eq!(
        ambiguous.reason(),
        Some(diagnostics::TypeDiagnosticReason::AmbiguousReturnTypeArgument),
        "{ambiguous:?}"
    );

    let explicit_expected_mismatch = typecheck_with_rules(
        "result: Identity<Int> = do::<Option> { Option::Some(1) }",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("explicit and expected do carriers must agree");
    assert_eq!(
        explicit_expected_mismatch.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeArgumentMismatch),
        "{explicit_expected_mismatch:?}"
    );
    let explicit_expected_diagnostic = explicit_expected_mismatch
        .structured
        .as_ref()
        .expect("structured explicit/expected carrier mismatch");
    let annotation_start = "result: Identity<Int>".find("Identity<Int>").unwrap();
    assert!(explicit_expected_diagnostic.related.iter().any(|fact| {
        fact.role == diagnostics::SourceRole::Annotation
            && fact.span
                == Span {
                    start: annotation_start,
                    end: annotation_start + "Identity<Int>".len(),
                }
    }));

    let return_source = r#"def invalid() -> Option<Int> {
  do::<Result> { Result::Ok(1) }
}"#;
    let return_mismatch = typecheck_with_rules(return_source, RuntimeSourcePolicy::script())
        .expect_err("explicit do carrier must agree with the function return annotation");
    assert_eq!(
        return_mismatch.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeArgumentMismatch),
        "{return_mismatch:?}"
    );
    let return_annotation_start = return_source.find("Option<Int>").unwrap();
    assert!(return_mismatch
        .structured
        .as_ref()
        .expect("structured return/RTA mismatch")
        .related
        .iter()
        .any(|fact| {
            fact.role == diagnostics::SourceRole::Expected
                && fact.span
                    == Span {
                        start: return_annotation_start,
                        end: return_annotation_start + "Option<Int>".len(),
                    }
        }));

    let captured_source = r#"result: Either<String, Int> = do::<Either<String, _>> {
  value <- Either<Int, Int>::Right(1)
  Either<String, Int>::Right(value)
}"#;
    let captured_mismatch = typecheck(resolve_with_builtin_prelude(captured_source))
        .expect_err("captured carrier arguments must remain fixed inside do");
    assert_eq!(
        captured_mismatch.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeArgumentMismatch),
        "{captured_mismatch:?}"
    );
    let explicit_start = captured_source.find("Either<String, _>").unwrap();
    assert_eq!(
        captured_mismatch.span,
        Span {
            start: explicit_start,
            end: explicit_start + "Either<String, _>".len(),
        }
    );
    let rhs_start = captured_source.find("Either<Int, Int>::Right(1)").unwrap();
    assert!(captured_mismatch
        .structured
        .as_ref()
        .expect("structured RTA mismatch")
        .related
        .iter()
        .any(|fact| fact.span
            == Span {
                start: rhs_start,
                end: rhs_start + "Either<Int, Int>::Right(1)".len(),
            }));

    let order_reasons = [
        r#"result = do {
  left <- Option::Some(1)
  right <- Identity::new(2)
  Option::Some(left + right)
}"#,
        r#"result = do {
  right <- Identity::new(2)
  left <- Option::Some(1)
  Option::Some(left + right)
}"#,
    ]
    .map(|source| {
        typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("mixed carrier families must be rejected independent of source order")
            .reason()
    });
    assert_eq!(order_reasons[0], order_reasons[1]);
}

fn do_mismatch_reasons_follow_relation_owner() {
    for (source, expected_reason) in [
        (
            "result: Result<String> = do::<Result> { Result::Ok(1) }",
            diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch,
        ),
        (
            "result = do::<Option> { Identity::new(1) }",
            diagnostics::TypeDiagnosticReason::ReturnTypeArgumentMismatch,
        ),
        (
            r#"def consume(value: Result<String>) -> Unit { () }
consume(do::<Result> { Result::Ok(1) })"#,
            diagnostics::TypeDiagnosticReason::TypePayloadMismatch,
        ),
        (
            r#"def consume(value: Result<Int>) -> Unit { () }
consume(do { Identity::new(1) })"#,
            diagnostics::TypeDiagnosticReason::TypeConstructorFamilyMismatch,
        ),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("do mismatch must retain the owner of its expected relation");
        assert_eq!(error.reason(), Some(expected_reason), "{source}: {error:?}");
    }
}

fn do_generated_bind_closure_preserves_expected_relation_owner() {
    let annotation_source = r#"result: Result<String> = do::<Result> {
  value <- Result::Ok(1)
  Result::Ok(value)
}"#;
    let annotation_error = typecheck_with_rules(annotation_source, RuntimeSourcePolicy::script())
        .expect_err("generated bind continuation must retain its binding annotation owner");
    assert_eq!(
        annotation_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch),
        "{annotation_error:?}"
    );
    let annotation_start = annotation_source.find("Result<String>").unwrap();
    assert!(annotation_error
        .structured
        .as_ref()
        .expect("structured annotation mismatch")
        .related
        .iter()
        .any(|fact| {
            fact.role == diagnostics::SourceRole::Annotation
                && fact.span
                    == Span {
                        start: annotation_start,
                        end: annotation_start + "Result<String>".len(),
                    }
        }));

    let return_source = r#"def invalid() -> Result<String> {
  do::<Result> {
    value <- Result::Ok(1)
    Result::Ok(value)
  }
}"#;
    let return_error = typecheck_with_rules(return_source, RuntimeSourcePolicy::script())
        .expect_err("generated bind continuation must retain its function return owner");
    assert_eq!(
        return_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeMismatch),
        "{return_error:?}"
    );
    let return_start = return_source.find("Result<String>").unwrap();
    assert!(return_error
        .structured
        .as_ref()
        .expect("structured return mismatch")
        .related
        .iter()
        .any(|fact| {
            fact.role == diagnostics::SourceRole::Expected
                && fact.span
                    == Span {
                        start: return_start,
                        end: return_start + "Result<String>".len(),
                    }
        }));

    let partial_annotation_source = r#"result: Option<String> = do::<Option> {
  Option::Some(value) <- Option::Some(Option::Some(1))
  Option::Some(value)
}"#;
    let partial_annotation_error =
        typecheck_with_rules(partial_annotation_source, RuntimeSourcePolicy::script())
            .expect_err("partial bind continuation must retain its binding annotation owner");
    assert_eq!(
        partial_annotation_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch),
        "{partial_annotation_error:?}"
    );
    let partial_annotation_start = partial_annotation_source.find("Option<String>").unwrap();
    assert!(partial_annotation_error
        .structured
        .as_ref()
        .expect("structured partial annotation mismatch")
        .related
        .iter()
        .any(|fact| {
            fact.role == diagnostics::SourceRole::Annotation
                && fact.span
                    == Span {
                        start: partial_annotation_start,
                        end: partial_annotation_start + "Option<String>".len(),
                    }
        }));

    let partial_return_source = r#"def invalid() -> Option<String> {
  do::<Option> {
    Option::Some(value) <- Option::Some(Option::Some(1))
    Option::Some(value)
  }
}"#;
    let partial_return_error =
        typecheck_with_rules(partial_return_source, RuntimeSourcePolicy::script())
            .expect_err("partial bind continuation must retain its function return owner");
    assert_eq!(
        partial_return_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeMismatch),
        "{partial_return_error:?}"
    );
    let partial_return_start = partial_return_source.find("Option<String>").unwrap();
    assert!(partial_return_error
        .structured
        .as_ref()
        .expect("structured partial return mismatch")
        .related
        .iter()
        .any(|fact| {
            fact.role == diagnostics::SourceRole::Expected
                && fact.span
                    == Span {
                        start: partial_return_start,
                        end: partial_return_start + "Option<String>".len(),
                    }
        }));
}

fn on_cli_compiler_stack(name: &str, case: impl FnOnce() + Send + 'static) {
    // The test configuration raises RUST_MIN_STACK to 32 MiB. Use the CLI's
    // 8 MiB budget so that the inherited worker stack cannot hide regressions.
    std::thread::Builder::new()
        .name(name.into())
        .stack_size(8 * 1024 * 1024)
        .spawn(case)
        .expect("compiler stack regression thread should spawn")
        .join()
        .expect("compiler regression must fit the CLI stack budget");
}

fn nested_ordinary_match_blocks_typecheck() {
    on_cli_compiler_stack("scar-nested-ordinary-blocks", || {
        // Each level uses the match and arm delimiters, reaching the parser's
        // existing 32-delimiter boundary without any Test DSL or do.
        let mut expression = "1".to_owned();
        for _ in 0..16 {
            expression = format!("match 1 {{ _ => {{ {expression} }} }}");
        }
        let source = format!("value = {expression}");
        let typed = typecheck_with_standard_environment(&source)
            .expect("legal nested ordinary blocks must typecheck on the CLI stack budget");
        assert_eq!(typed_bind_rhs(&typed, "value").ty, Ty::Int);

        let mut expression = "1".to_owned();
        for _ in 0..31 {
            expression = format!("layer() {{ marker = 0; {expression} }}");
        }
        let source =
            format!("def layer(body: (-> Int)) -> Int {{ body() }}\nvalue: Int = {expression}");
        let typed = typecheck_with_standard_environment(&source)
            .expect("legal nested closure blocks must fit the CLI compiler stack");
        assert_eq!(typed_bind_rhs(&typed, "value").ty, Ty::Int);
    });
}

fn nested_user_closures_typecheck_do_binds_and_captures() {
    on_cli_compiler_stack("scar-nested-do-closures", || {
        for (carrier, result_ty, first, second, third, output, expected_ty) in [
            (
                "List",
                "List<Int>",
                "[1]",
                "[2]",
                "[3]",
                "[first + second + third + offset]",
                Ty::List(Box::new(Ty::Int)),
            ),
            (
                "Option",
                "Option<Int>",
                "Option::Some(1)",
                "Option::Some(2)",
                "Option::Some(3)",
                "Option::Some(first + second + third + offset)",
                Ty::Enum("Global::Option".into(), vec![Ty::Int]),
            ),
            (
                "Result",
                "Result<Int>",
                "Result::Ok(1)",
                "Result::Ok(2)",
                "Result::Ok(3)",
                "Result::Ok(first + second + third + offset)",
                Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error)),
            ),
        ] {
            let mut expression = format!(
                r#"do::<{carrier}> {{
first <- {first}
second <- {second}
third <- {third}
{output}
}}"#
            );
            for _ in 0..12 {
                expression = format!("layer() {{\n{expression}\n}}");
            }
            let source = format!(
                r#"def layer(body: (-> {result_ty})) -> {result_ty} {{ body() }}
offset = 7
actual: {result_ty} = {expression}"#
            );
            let typed = typecheck_with_builtin_prelude_in_script_module(&source);
            let actual = typed_bind_rhs(&typed, "actual");
            assert_eq!(actual.ty, expected_ty, "{carrier}");
            let TypedInner::App(_, args) = &actual.node else {
                panic!("expected ordinary layer call for {carrier}: {actual:?}");
            };
            let [TypedNode {
                node: TypedInner::Closure(_, captures, _),
                ..
            }] = args.as_slice()
            else {
                panic!("expected one closure argument for {carrier}: {args:?}");
            };
            assert!(
                captures.iter().any(|capture| capture.name == "offset"),
                "the nested continuation must retain its outer capture for {carrier}"
            );
        }

        let mut expression = "do::<List> {\n".to_owned();
        for index in 0..6 {
            expression.push_str(&format!("v{index} <- [{index}]\n"));
        }
        expression.push_str("[v0 + v1 + v2 + v3 + v4 + v5]\n}");
        for _ in 0..12 {
            expression = format!("layer() {{ marker = 0; {expression} }}");
        }
        let source = format!(
            "def layer(body: (-> List<Int>)) -> List<Int> {{ body() }}\nactual: List<Int> = {expression}"
        );
        let typed = typecheck_with_builtin_prelude_in_script_module(&source);
        assert_eq!(
            typed_bind_rhs(&typed, "actual").ty,
            Ty::List(Box::new(Ty::Int))
        );
    });
}

fn nested_do_closure_mismatch_keeps_original_source_facts() {
    on_cli_compiler_stack("scar-nested-do-diagnostic", || {
        let source = r#"def layer(body: (-> List<Int>)) -> List<Int> { body() }
actual: List<Int> = layer() {
  layer() {
    layer() {
      do::<List> {
        first <- [1]
        second <- [2]
        third <- [3]
        bad: String = first
        [third]
      }
    }
  }
}"#;
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("a nested continuation's invalid annotation must remain a type error");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch),
            "{error:?}"
        );
        let value_start = source.find("= first").unwrap() + "= ".len();
        let value_span = Span {
            start: value_start,
            end: value_start + "first".len(),
        };
        let annotation_start = source.find("String").unwrap();
        let annotation_span = Span {
            start: annotation_start,
            end: annotation_start + "String".len(),
        };
        assert_eq!(error.span, value_span, "{error:?}");
        let structured = error
            .structured
            .as_ref()
            .expect("structured annotation error");
        assert_eq!(structured.primary.span, value_span);
        assert!(
            structured.related.iter().any(|fact| {
                fact.role == diagnostics::SourceRole::Annotation && fact.span == annotation_span
            }),
            "{structured:?}"
        );
    });
}

fn do_expected_relation_does_not_override_user_branch_mismatch() {
    for (source, expected_reason) in [
        (
            r#"def invalid() -> Option<String> {
  if(True, do::<Option> { Option::Some(1) }, Option::Some("ok"))
}"#,
            diagnostics::TypeDiagnosticReason::IfBranchTypeMismatch,
        ),
        (
            r#"def invalid() -> Option<String> {
  match True {
    True => do::<Option> { Option::Some(1) },
    False => Option::Some("ok"),
  }
}"#,
            diagnostics::TypeDiagnosticReason::MatchArmTypeMismatch,
        ),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("user branch agreement must precede the outer expected relation");
        assert_eq!(error.reason(), Some(expected_reason), "{source}: {error:?}");
    }
}

fn do_uses_generic_monad_capability_without_binding_rigid_carrier() {
    typecheck_with_builtin_prelude_in_script_module(
        r#"def retain(value: $M<Int>) -> $M<Int> where $M: Monad {
  do {
    item <- value
    Monad::return(item)
  }
}

result = retain(Identity::new(1))"#,
    );

    let error = typecheck_with_rules(
        r#"def retain(value: $M<Int>) -> $M<Int> where $M: Applicative {
  do {
    item <- value
    Applicative::pure(item)
  }
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("do must require Monad rather than accepting only Applicative");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingGenericBound),
        "{error:?}"
    );
}

fn do_extract_lowers_to_concrete_monad_dispatch() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"offset = 1
result: Option<Int> = do::<Option> {
  value <- Option::Some(1)
  Option::Some(value + offset)
}"#,
    );
    let rhs = typed
        .iter()
        .rev()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "result") => Some(rhs),
            _ => None,
        })
        .expect("expected result binding");
    let TypedInner::TraitCall {
        method_name,
        dispatch,
        args,
        ..
    } = &rhs.node
    else {
        panic!("do extract must lower to a TraitCall, got {rhs:?}")
    };
    assert_eq!(method_name, "bind");
    assert!(!matches!(dispatch, scar::typed::TraitDispatch::Pending));
    let [_, mapper] = args.as_slice() else {
        panic!("Monad::bind must receive source and mapper: {args:?}")
    };
    let TypedInner::Closure(_, captures, _) = &mapper.node else {
        panic!("Monad::bind mapper must be a closure: {mapper:?}")
    };
    assert!(captures.iter().any(|capture| capture.name == "offset"));
}

fn do_total_extract_allows_mapped_payload_changes() {
    typecheck_with_builtin_prelude_in_script_module(
        r#"result: Identity<String> = do::<Identity> {
  number <- Identity::new(1)
  flag <- Identity::new(True)
  Identity::new(if(flag, to_string(number), "no"))
}"#,
    );

    typecheck(resolve_with_builtin_prelude(
        r#"result: Either<String, String> = do::<Either<String, _>> {
  number <- Either<String, Int>::Right(1)
  flag <- Either<String, Boolean>::Right(True)
  Either<String, String>::Right(if(flag, to_string(number), "no"))
}"#,
    ))
    .expect("captured Either argument stays fixed while mapped payloads change");
}

fn do_sequences_unit_payloads() {
    for source in [
        "f: (Unit -> List<Int>) = {|_| do::<List> { value <- [1, 2]; Alternative::guard::<List>(value > 1); [value] }}",
        "result: List<Int> = do::<List> { value <- [1, 2]; Alternative::guard::<List>(value > 1); [value] }",
        "result: List<Int> = do::<List> { Alternative::guard::<List>(True); [1] }",
        "source: List<Unit> = [()]; result: List<Int> = do::<List> { _ <- source; [1] }",
        "result: List<Int> = Monad::bind([()], {|_| [1]})",
        "result: Option<Int> = do::<Option> { Alternative::guard::<Option>(True); Option::Some(1) }",
    ] {
        typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .unwrap_or_else(|error| panic!("Unit payload must sequence: {source}: {error:?}"));
        typecheck_module_source_result(&format!("defmod GuardProbe {{ def probe() -> Unit {{ {source}; () }} }}"))
            .unwrap_or_else(|error| panic!("staged Unit payload must sequence: {source}: {error}"));
    }
}

fn do_partial_extract_requires_alternative() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"result: Option<Int> = do::<Option> {
  Option::Some(value) <- Option::Some(Option::Some(1))
  Option::Some(value)
}"#,
    );
    let rhs = typed
        .iter()
        .rev()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "result") => Some(rhs),
            _ => None,
        })
        .expect("expected result binding");
    let TypedInner::TraitCall { args, .. } = &rhs.node else {
        panic!("partial extract must lower through Monad::bind: {rhs:?}")
    };
    let TypedInner::Closure(_, _, body) = &args[1].node else {
        panic!("bind mapper must be a closure: {:?}", args[1])
    };
    let TypedInner::DoSafeBind(control) = &body.node else {
        panic!("partial extract mapper must use common Pattern control: {body:?}")
    };
    let scar::typed::SafeBindFailureTarget::DoAlternative { empty } = &control.failure_target
    else {
        panic!("non-Result partial extract requires Alternative.empty")
    };
    assert!(matches!(
        &empty.node,
        TypedInner::TraitCall { trait_name, method_name, dispatch, .. }
            if trait_name == "Alternative" && method_name == "empty"
                && !matches!(dispatch, scar::typed::TraitDispatch::Pending)
    ));

    let error = typecheck_with_rules(
        r#"result: Identity<Int> = do::<Identity> {
  1 <- Identity::new(1)
  Identity::new(1)
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("partial extract must require Alternative on the same carrier");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{error:?}"
    );
}

fn do_rigid_monad_requires_explicit_alternative_bound() {
    let partial_source = r#"def partial(value: $M<Option<Int>>) -> $M<Int> where $M: Monad {
  do {
    Option::Some(item) <- value
    Monad::return(item)
  }
}"#;
    let partial_error = typecheck_with_rules(partial_source, RuntimeSourcePolicy::script())
        .expect_err("a partial extract on a rigid Monad must require Alternative explicitly");
    assert_eq!(
        partial_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingGenericBound),
        "{partial_error:?}"
    );
    let pattern_start = partial_source.find("Option::Some(item)").unwrap();
    assert_eq!(
        partial_error.span,
        Span {
            start: pattern_start,
            end: pattern_start + "Option::Some(item)".len(),
        }
    );

    let safe_bind_source = r#"def partial(value: $M<Int>) -> $M<Int> where $M: Monad {
  do {
    1 =? 1
    Monad::return(1)
  }
}"#;
    let safe_bind_error = typecheck_with_rules(safe_bind_source, RuntimeSourcePolicy::script())
        .expect_err("SafeBind on a rigid Monad must require Alternative explicitly");
    assert_eq!(
        safe_bind_error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingGenericBound),
        "{safe_bind_error:?}"
    );
    let operator_start = safe_bind_source.find("=?").unwrap();
    assert_eq!(
        safe_bind_error.span,
        Span {
            start: operator_start,
            end: operator_start + "=?".len(),
        }
    );
}

fn do_ordinary_binding_is_not_a_monadic_origin() {
    for source in [
        r#"result: Option<Option<Int>> = do::<Option> {
  saved = Option::Some(1)
  Option::Some(saved)
}"#,
        r#"result: Identity<Option<Int>> = do {
  saved = Option::Some(1)
  Identity::new(saved)
}"#,
        r#"result: Option<Int> = do::<Option> {
  print("ordinary effect")
  Option::Some(1)
}"#,
    ] {
        typecheck_with_builtin_prelude_in_script_module(source);
    }
}

fn do_final_expression_still_requires_monad() {
    let error = typecheck_with_rules("result: Int = do { 1 }", RuntimeSourcePolicy::script())
        .expect_err("a final-expression-only do still requires Monad");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
        "{error:?}"
    );
}

fn do_concrete_non_monad_reason_is_independent_of_origin() {
    for (source, offending_expression) in [
        (
            r#"defenum Box<$A> { Box($A) }
result: Box<Int> = do::<Box> { Box::Box(1) }"#,
            "Box::Box(1)",
        ),
        (
            r#"defenum Box<$A> { Box($A) }
result: Box<Int> = do::<Box> {
  value <- Box::Box(1)
  Box::Box(value)
}"#,
            "Box::Box(1)",
        ),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("a concrete carrier without Monad must be rejected uniformly");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
            "{source}: {error:?}"
        );
        let offending_start = source.find(offending_expression).unwrap();
        assert_eq!(
            error.span,
            Span {
                start: offending_start,
                end: offending_start + offending_expression.len(),
            },
            "{source}: {error:?}"
        );
    }
}

fn do_safebind_selects_typed_failure_targets() {
    let result_source = r#"result: Result<Int> = do::<Result> {
  value =? Result::Ok(1)
  Result::Ok(value)
}"#;
    let typed = typecheck_with_builtin_prelude_in_script_module(result_source);
    let result = typed_bind_rhs(&typed, "result");
    let TypedInner::DoSafeBind(control) = &result.node else {
        panic!("Result do SafeBind must remain explicit typed control: {result:?}")
    };
    let TypedDoSafeBind {
        rhs,
        projection,
        failure_target,
        continuation,
        origins,
        ..
    } = control.as_ref();
    assert!(matches!(rhs.ty, Ty::Result(_, _)));
    assert!(matches!(
        projection,
        SafeBindRhsProjection::CanonicalResultOnce { .. }
    ));
    assert!(matches!(
        failure_target,
        SafeBindFailureTarget::DoMonadFail(target)
            if matches!(target.call.node, TypedInner::TraitCall { .. })
    ));
    assert_eq!(continuation.ty, result.ty);
    assert_eq!(
        origins.do_span.start,
        result_source.find("do::<Result>").unwrap()
    );
    assert_eq!(
        origins.operator_span.start,
        result_source.find("=?").unwrap()
    );
    assert_eq!(
        origins.pattern_span.start,
        result_source.find("value =?").unwrap()
    );
    assert_eq!(
        origins.rhs_span.start,
        result_source.find("Result::Ok(1)").unwrap()
    );
    assert_eq!(
        origins.result_span.start,
        result_source.rfind("Result::Ok(value)").unwrap()
    );

    let option_source = r#"result: Option<Int> = do::<Option> {
  Option::Some(value) =? Option::Some(1)
  Option::Some(value)
}"#;
    let typed = typecheck_with_builtin_prelude_in_script_module(option_source);
    let result = typed_bind_rhs(&typed, "result");
    let TypedInner::DoSafeBind(control) = &result.node else {
        panic!("Option do SafeBind must remain explicit typed control: {result:?}")
    };
    let TypedDoSafeBind {
        projection,
        failure_target,
        continuation,
        origins,
        ..
    } = control.as_ref();
    assert!(matches!(
        projection,
        SafeBindRhsProjection::PatternInput { .. }
    ));
    let SafeBindFailureTarget::DoAlternative { empty } = failure_target else {
        panic!("Option do SafeBind must use Alternative empty: {failure_target:?}")
    };
    assert!(matches!(
        &empty.node,
        TypedInner::TraitCall {
            trait_name,
            method_name,
            dispatch: scar::typed::TraitDispatch::Static(_),
            ..
        } if trait_name == "Alternative" && method_name == "empty"
    ));
    assert_eq!(empty.ty, result.ty);
    assert_eq!(continuation.ty, result.ty);
    assert_eq!(
        origins.do_span.start,
        option_source.find("do::<Option>").unwrap()
    );
    assert_eq!(
        origins.operator_span.start,
        option_source.find("=?").unwrap()
    );
    assert_eq!(
        origins.pattern_span.start,
        option_source.find("Option::Some(value) =?").unwrap()
    );
    assert_eq!(
        origins.rhs_span.start,
        option_source.find("Option::Some(1)").unwrap()
    );
    assert_eq!(
        origins.result_span.start,
        option_source.rfind("Option::Some(value)").unwrap()
    );

    let nested_source = r#"result: Result<Int> = do::<Result> {
  first: Int =? Result::Ok(1)
  [second] =? [first]
  Result::Ok(second)
}"#;
    let typed = typecheck_with_builtin_prelude_in_script_module(nested_source);
    let result = typed_bind_rhs(&typed, "result");
    let final_start = nested_source.rfind("Result::Ok(second)").unwrap();
    let TypedInner::DoSafeBind(first) = &result.node else {
        panic!("first SafeBind must remain explicit typed control: {result:?}")
    };
    assert_eq!(first.origins.result_span.start, final_start);
    let first_pattern_start = nested_source.find("first: Int").unwrap();
    assert_eq!(
        first.origins.pattern_span,
        spire::ast::Span {
            start: first_pattern_start,
            end: first_pattern_start + "first: Int".len(),
        }
    );
    let TypedInner::DoSafeBind(second) = &first.continuation.node else {
        panic!("second SafeBind must remain explicit typed control")
    };
    assert_eq!(second.origins.result_span.start, final_start);
    let second_pattern_start = nested_source.find("[second]").unwrap();
    assert_eq!(
        second.origins.pattern_span,
        spire::ast::Span {
            start: second_pattern_start,
            end: second_pattern_start + "[second]".len(),
        }
    );

    let extract_after_safebind = r#"result: Result<Int> = do::<Result> {
  first =? Result::Ok(1)
  second <- Result::Ok(first + 1)
  Result::Ok(second)
}"#;
    let typed = typecheck_with_builtin_prelude_in_script_module(extract_after_safebind);
    let result = typed_bind_rhs(&typed, "result");
    let TypedInner::DoSafeBind(control) = &result.node else {
        panic!("SafeBind before extract must remain explicit typed control: {result:?}")
    };
    assert_eq!(
        control.origins.result_span.start,
        extract_after_safebind.rfind("Result::Ok(second)").unwrap()
    );
}

fn do_safebind_preserves_n06_and_carrier_boundaries() {
    for (source, expected) in [
        (
            r#"result: Option<Int> = do::<Option> {
  value =? Option::Some(1)
  Option::Some(value)
}"#,
            diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonResultMonadRhs,
        ),
        (
            r#"result: Option<Int> = do::<Option> {
  value =? 1
  Option::Some(value)
}"#,
            diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonMonadRhs,
        ),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
            .expect_err("do must reuse N06 total non-Result rejection");
        assert_eq!(error.reason(), Some(expected), "{error:?}");
    }

    let pattern_error = typecheck_with_rules(
        r#"result: Option<Int> = do::<Option> {
  value: Int =? Option::Some(1)
  Option::Some(value)
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("ordinary pattern checking must precede SafeBind policy");
    assert!(!matches!(
        pattern_error.reason(),
        Some(
            diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonMonadRhs
                | diagnostics::TypeDiagnosticReason::SafeBindTotalPatternNonResultMonadRhs
        )
    ));

    let missing_alternative = typecheck_with_rules(
        r#"result: Identity<Int> = do::<Identity> {
  1 =? 1
  Identity::new(1)
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("non-Result do SafeBind must require Alternative on the same carrier");
    assert_eq!(
        missing_alternative.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{missing_alternative:?}"
    );

    let ambiguous = typecheck_with_rules(
        r#"result = do {
  value =? Result::Ok(1)
  Monad::return(value)
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("SafeBind RHS must not infer the do carrier");
    assert_eq!(
        ambiguous.reason(),
        Some(diagnostics::TypeDiagnosticReason::AmbiguousReturnTypeArgument),
        "{ambiguous:?}"
    );
}

fn do_safebind_return_mismatch_points_to_the_final_expression() {
    let source = r#"def invalid() -> Result<String> {
  do::<Result> {
    value =? Result::Ok(1)
    Result::Ok(value)
  }
}"#;
    let error = typecheck_with_rules(source, RuntimeSourcePolicy::script())
        .expect_err("do's Result value must still be checked against the declared return type");
    let final_start = source.rfind("Result::Ok(value)").unwrap();
    let return_start = source.find("Result<String>").unwrap();
    assert_eq!(error.span.start, final_start, "{error:?}");
    assert_eq!(
        error.span.end,
        final_start + "Result::Ok(value)".len(),
        "{error:?}"
    );
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeMismatch),
        "{error:?}"
    );
    let structured = error.structured.as_ref().expect("structured do diagnostic");
    assert_eq!(structured.primary.span.start, final_start);
    assert_eq!(
        structured.primary.span.end,
        final_start + "Result::Ok(value)".len()
    );
    assert!(
        structured.related.iter().any(|fact| {
            fact.ty.as_deref() == Some("Result<String>")
                && fact.span.start == return_start
                && fact.span.end == return_start + "Result<String>".len()
        }),
        "{structured:?}"
    );
}

fn do_partial_extract_rejects_carriers_without_alternative() {
    for (result_ty, rta, rhs, last) in [
        (
            "Identity<Int>",
            "Identity",
            "Identity::new(Option::Some(1))",
            "Identity::new(value)",
        ),
        (
            "Reader<Int, Int>",
            "Reader",
            "Reader::new({|environment| Option::Some(1)})",
            "Reader::new({|environment| value})",
        ),
        (
            "State<Int, Int>",
            "State",
            "State::new({|state| (Option::Some(1), state)})",
            "State::new({|state| (value, state)})",
        ),
    ] {
        let source = format!(
            "result: {result_ty} = do::<{rta}> {{\n  Option::Some(value) <- {rhs}\n  {last}\n}}"
        );
        let error = typecheck_with_rules(&source, RuntimeSourcePolicy::script())
            .expect_err("partial pattern extraction requires Alternative on the carrier");
        let pattern_start = source.find("Option::Some(value)").unwrap();
        assert_eq!(error.span.start, pattern_start, "{result_ty}: {error:?}");
        assert_eq!(
            error.span.end,
            pattern_start + "Option::Some(value)".len(),
            "{result_ty}: {error:?}"
        );
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
            "{result_ty}: {error:?}"
        );
    }

    for (result_ty, rta, last) in [
        ("Identity<Int>", "Identity", "Identity::new(value)"),
        (
            "Reader<Int, Int>",
            "Reader",
            "Reader::new({|environment| value})",
        ),
        (
            "State<Int, Int>",
            "State",
            "State::new({|state| (value, state)})",
        ),
    ] {
        let source = format!(
            "result: {result_ty} = do::<{rta}> {{\n  Option::Some(value) =? Option::Some(1)\n  {last}\n}}"
        );
        let error = typecheck_with_rules(&source, RuntimeSourcePolicy::script())
            .expect_err("partial SafeBind requires Alternative on the carrier");
        let operator_start = source.find("=?").unwrap();
        assert_eq!(error.span.start, operator_start, "{result_ty}: {error:?}");
        assert_eq!(error.span.end, operator_start + 2, "{result_ty}: {error:?}");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
            "{result_ty}: {error:?}"
        );
    }
}

fn do_generated_bind_closure_keeps_facet_source_scope() {
    typecheck_with_rules(
        r#"defrecord User(name: String)
user = User("alice")
facet = User.name
result: Identity<String> = do::<Identity> {
  scoped_user <- Identity::new(user)
  name = Facet::view(facet, scoped_user)
  length <- Identity::new(String::len(name))
  Identity::new(to_string(length))
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("compiler-generated bind closures must not create a source Facet scope boundary");
}

fn do_extract_accepts_fallible_facet_nominal_payload() {
    for rhs in ["items.[0]", "Facet::view(List.[0], items)"] {
        let source = format!(
            r#"defstruct Item {{ value: Int }}
impl Item {{
  def new(value: Int) -> Self {{ Item {{ value }} }}
}}
items = [Item::new(7)]
result: Result<Int> = do {{
  item <- {rhs}
  Ok(item.value)
}}"#
        );
        let typed =
            typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_or_else(|error| {
                panic!("Facet Result<Item> must bind like an ordinary Result: {rhs}: {error:?}")
            });
        assert_eq!(
            typed_bind_rhs(&typed, "result").ty,
            Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error)),
            "{rhs}"
        );
    }
}

fn do_extract_accepts_structural_facet_on_result_source() {
    for rhs in ["source.item", "Facet::view(Holder.item, source)"] {
        let source = format!(
            r#"defstruct Item {{ value: Int }}
impl Item {{
  def new(value: Int) -> Self {{ Item {{ value }} }}
}}
defstruct Holder {{ item: Item }}
impl Holder {{
  def new(item: Item) -> Self {{ Holder {{ item }} }}
}}
source = Ok(Holder::new(Item::new(7)))
result: Result<Int> = do {{
  item <- {rhs}
  Ok(item.value)
}}"#
        );
        let typed =
            typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_or_else(|error| {
                panic!("structural view on Result must retain its nominal focus: {rhs}: {error:?}")
            });
        assert_eq!(
            typed_bind_rhs(&typed, "result").ty,
            Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error)),
            "{rhs}"
        );
    }
}

fn do_extract_accepts_variant_facet_payload_shapes() {
    for (constructor, path, expected_payload) in [
        ("Packet::Empty", "Packet.Empty", Ty::Unit),
        (
            "Packet::Pair(7, True)",
            "Packet.Pair",
            Ty::Tuple(vec![Ty::Int, Ty::Bool]),
        ),
    ] {
        let source = format!(
            r#"defenum Packet {{ Empty, Pair(Int, Boolean), }}
packet = {constructor}
result = do {{
  payload <- Facet::preview({path}, packet)
  Ok(payload)
}}"#
        );
        let typed =
            typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_or_else(|error| {
                panic!(
                    "variant preview must unwrap its zero or multiple payloads: {path}: {error:?}"
                )
            });
        assert_eq!(
            typed_bind_rhs(&typed, "result").ty,
            Ty::Result(Box::new(expected_payload), Box::new(Ty::Error)),
            "{path}"
        );
    }
}

fn do_facet_extract_preserves_caller_payload_capability() {
    let definition = r#"def double_first(values: List<$A>) -> Result<$A>
where
  $A: Add
{
  do {
    item <- values.[0]
    Ok(item + item)
  }
}
"#;
    typecheck_with_rules(
        &format!("{definition}result: Result<Int> = double_first([7])"),
        RuntimeSourcePolicy::script(),
    )
    .expect("unwrapping Facet Result must preserve the caller-owned Add capability");

    let field_definition = r#"defstruct Boxed<$A> { value: Result<$A> }
impl Boxed {
  def new(value: Result<$A>) -> Boxed<$A> { Boxed { value } }
}
def double_field(boxed: Boxed<$A>) -> Result<$A>
where
  $A: Add
{
  do {
    item <- Facet::view(Boxed.value, boxed)
    Ok(item + item)
  }
}
"#;
    typecheck_with_rules(
        &format!("{field_definition}result: Result<Int> = double_field(Boxed::new(Ok(7)))"),
        RuntimeSourcePolicy::script(),
    )
    .expect("total Facet field view must retain the stored Result payload capability without another wrapper");

    let error = typecheck_with_rules(
        &format!("{definition}double_first([()])"),
        RuntimeSourcePolicy::script(),
    )
    .expect_err("Facet Result unwrapping must not authorize Add for an unsupported payload");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingTraitCapability),
        "{error:?}"
    );
}

fn facet_result_preserves_payload_carrier_capability() {
    let declarations = r#"def retain(value: $F<Int>) -> $F<Int>
where
  $F: Functor
{
  Functor::fmap(value, {|item| item})
}
def stronger(value: Monad<Int>) -> Int { 1 }
"#;
    let computation = r#"values = [source]
projected = values.[0]
result = match projected {
  Ok(item) => stronger(item),
  Err(_) => 0,
}"#;
    typecheck_with_rules(
        &format!("{declarations}source = Identity::new(7)\n{computation}"),
        RuntimeSourcePolicy::script(),
    )
    .expect("fresh concrete payload independently provides its Monad capability");

    let source = format!("{declarations}source = retain(Identity::new(7))\n{computation}");
    let error = typecheck_with_rules(&source, RuntimeSourcePolicy::script())
        .expect_err("Facet Result projection must retain the payload constructor capability");
    assert_eq!(
        error.reason(),
        Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
        "{error:?}"
    );
    assert!(
        error.span.start >= source.find("stronger(item)").unwrap(),
        "the rejection must belong to the projected payload capability: {error:?}"
    );
}

const CALLBACK_PAYLOAD_VIEW_SOURCE: &str = r#"def retain(value: $F<Int>) -> $F<Int>
where
  $F: Functor
{
  Functor::fmap(value, {|item| item})
}
def retain_monad(value: $F<Int>) -> $F<Int>
where
  $F: Monad
{
  Monad::bind(value, {|item| Monad::return(item)})
}
def stronger(value: Monad<Int>) -> Int { 1 }
def consume(value: $A, mapper: ($A -> Int)) -> Int { mapper(value) }
def consume_reversed(mapper: ($A -> Int), value: $A) -> Int { mapper(value) }
def layer(body: (-> Int)) -> Int { body() }
"#;

fn assert_implicit_callback_input_views(computations: &[&str]) {
    // Check every positive input before evaluating the rejection boundary.
    for computation in computations {
        for producer in ["Identity::new(7)", "retain_monad(Identity::new(7))"] {
            let source =
                format!("{CALLBACK_PAYLOAD_VIEW_SOURCE}source = {producer}\n{computation}");
            typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_or_else(|error| {
                panic!("fresh or Monad-constrained inputs must authorize the implicit callback: {computation}: {error:?}")
            });
        }
    }
    for computation in computations {
        let source = format!(
            "{CALLBACK_PAYLOAD_VIEW_SOURCE}source = retain(Identity::new(7))\n{computation}"
        );
        let Err(error) = typecheck_with_rules(&source, RuntimeSourcePolicy::script()) else {
            panic!("implicit callback input lost its source's Functor-only view: {computation}");
        };
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
            "{computation}: {error:?}"
        );
        assert!(
            error.span.start >= source.len() - computation.len(),
            "the callback use must own the payload capability diagnostic: {computation}: {error:?}"
        );
    }
}

fn do_implicit_bind_inputs_preserve_payload_views() {
    assert_implicit_callback_input_views(&[
        "result: Result<Int> = do { item <- Ok(source); Ok(stronger(item)) }",
        "result: Result<Int> = do { item: Identity<Int> <- Ok(source); Ok(stronger(item)) }",
        "result: List<Int> = do { item <- [source]; [stronger(item)] }",
        "result: Identity<Int> = do { item <- Identity::new(source); Identity::new(stronger(item)) }",
        "result: Result<Int> = do { (item, _) <- Ok((source, 1)); Ok(stronger(item)) }",
        "result: Result<Int> = do { Option::Some(item) <- Ok(Option::Some(source)); Ok(stronger(item)) }",
        "result: Result<Int> = do { Option::Some(item) @ whole <- Ok(Option::Some(source)); Ok(stronger(item)) }",
        "result: Result<Int> = do { [item] <- Ok([source]); Ok(stronger(item)) }",
        "result: Result<Int> = do { pair <- Ok((Option::Some(source), Option::Some(source))); Ok(match pair { (Option::Some(item), _) | (_, Option::Some(item)) => stronger(item), _ => 0, }) }",
    ]);
}

fn generic_callbacks_preserve_input_views_in_either_argument_order() {
    assert_implicit_callback_input_views(&[
        "consume(source, {|item| stronger(item)})",
        "consume_reversed({|item| stronger(item)}, source)",
    ]);
}

fn contextual_callbacks_preserve_implicit_payload_views() {
    assert_implicit_callback_input_views(&[
        "Monad::bind(Ok(source), {|item| Ok(stronger(item))})",
        "Functor::fmap(Ok(source), {|item| stronger(item)})",
        "Ok(source) |>= {|item| Ok(stronger(item))}",
        "Ok(source) |*> {|item| stronger(item)}",
    ]);
}

fn captured_contextual_callbacks_preserve_payload_views() {
    assert_implicit_callback_input_views(&[
        "Function::apply(&stronger, source)",
        "Function::apply(&stronger(&1), source)",
        "Functor::fmap(Ok(source), &stronger)",
        "Functor::fmap(Ok(source), &stronger(&1))",
        "Applicative::ap(Ok(&stronger), Ok(source))",
        "Applicative::ap(Ok(&stronger(&1)), Ok(source))",
        "Applicative::ap(Ok({|item| stronger(item)}), Ok(source))",
        "Applicative::ap(Ok({|item| layer() { stronger(item) }}), Ok(source))",
        "mapper: (Identity<Int> -> Identity<Int>) = &Monad::bind(&1, {|item| Identity::new(item)}); mapper(source)",
    ]);
}

fn fixed_nominal_callback_parameters_keep_independent_views() {
    let source = format!(
        r#"{CALLBACK_PAYLOAD_VIEW_SOURCE}
def fixed_mapper(item: Identity<Int>) -> Result<Int> {{ Ok(stronger(item)) }}
source = retain(Identity::new(7))
"#
    );
    for computation in [
        "Monad::bind(Ok(source), &fixed_mapper)",
        "Monad::bind(Ok(source), {|item: Identity<Int>| Ok(stronger(item))})",
        "consume(source, {|item: Identity<Int>| stronger(item)})",
        "consume_reversed({|item: Identity<Int>| stronger(item)}, source)",
        "Applicative::ap(Ok({|item: Identity<Int>| stronger(item)}), Ok(source))",
        "mapper: (Identity<Int> -> Int) = {|item| stronger(item)}; mapper(source)",
    ] {
        typecheck_with_rules(&format!("{source}{computation}"), RuntimeSourcePolicy::script())
            .unwrap_or_else(|error| panic!("a fixed nominal callback input has its own declared capability view: {computation}: {error:?}"));
    }
}

fn rigid_callback_payloads_keep_declared_constructor_capability() {
    for computation in [
        "do { item <- Ok(value); Ok(stronger(item)) }",
        "Monad::bind(Ok(value), {|item| Ok(stronger(item))})",
    ] {
        let definition = format!(
            "{CALLBACK_PAYLOAD_VIEW_SOURCE}def probe(value: $F<Int>) -> Result<Int> where $F: __CAPABILITY__ {{ {computation} }}"
        );
        typecheck_with_rules(
            &definition.replace("__CAPABILITY__", "Monad"),
            RuntimeSourcePolicy::script(),
        )
        .unwrap_or_else(|error| panic!("a rigid Monad payload supports stronger inside the callback: {computation}: {error:?}"));
        let error = typecheck_with_rules(
            &definition.replace("__CAPABILITY__", "Functor"),
            RuntimeSourcePolicy::script(),
        )
        .expect_err("a rigid Functor-only payload must remain insufficient inside the callback");
        assert_eq!(
            error.reason(),
            Some(diagnostics::TypeDiagnosticReason::MissingTypeConstructorCapability),
            "{computation}: {error:?}"
        );
    }
}

fn trailing_block_calls_typecheck_inside_script_module_scope() {
    let typed = typecheck_with_builtin_prelude_in_script_module(
        r#"def take(flag: Boolean, value: (-> Int)) -> Int {
  if(flag, value(), 0)
}

print(to_string(take(True) { num = 10; num }))

v = if_then(True) { print("x") }
print(to_string(v))"#,
    );
    assert!(
        typed
            .iter()
            .filter(|node| matches!(node.node, TypedInner::App(_, _)))
            .count()
            >= 2,
        "expected trailing-block call sites to typecheck"
    );
}

fn set_exit_code_is_allowed_in_script_rules() {
    let typed =
        typecheck_with_rules("set_exit_code(9)", RuntimeSourcePolicy::script()).expect("must pass");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::App(_, _))
    ));
}

fn set_exit_code_is_forbidden_in_repl_chunk_rules() {
    let err = typecheck_with_rules("set_exit_code(9)", RuntimeSourcePolicy::repl_chunk())
        .expect_err("must fail");
    assert!(err.message.contains("forbidden by source policy"));
}

fn set_exit_code_entry_only_policy_allows_only_entrypoint_function() {
    let entrypoint = EntryPoint::qualified("main");
    let rules = RuntimeSourcePolicy::module()
        .with_exit_code_policy(ExitCodePolicy::EntryOnly, Some(&entrypoint));

    let ok = typecheck_with_rules(
        r#"def main() -> Result<()> {
  set_exit_code(7)
  Ok(())
}"#,
        rules.clone(),
    )
    .expect("entrypoint body should allow set_exit_code");
    assert!(ok
        .iter()
        .find(|node| matches!(node.node, TypedInner::Def(..)))
        .is_some());

    let err = typecheck_with_rules(
        r#"def helper() -> Result<()> {
  set_exit_code(7)
  Ok(())
}"#,
        rules,
    )
    .expect_err("non-entrypoint function must fail");
    assert!(err.message.contains("only allowed inside entrypoint"));
}

fn require_standard_call_typechecks_to_result_unit() {
    let typed = typecheck_with_builtin_prelude("guard = require(True, NoneError())");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(rhs.node, TypedInner::Block(_)));
            assert!(matches!(
                rhs.ty,
                scar::types::Ty::Result(ref ok, ref err)
                    if matches!(ok.as_ref(), scar::types::Ty::Unit)
                        && matches!(err.as_ref(), scar::types::Ty::Error)
            ));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn bitwidth_zero_arg_variant_reference_reuses_std_enum_constructor_uid() {
    let resolved = resolve_program_with_builtin_prelude("width = BitWidth::W8");

    let use_uid = match resolved
        .last()
        .expect("user bind should be present after std modules")
    {
        sigil::resolved::Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            sigil::resolved::Resolved::ConstructorCall(_, id, args) => {
                assert!(args.is_empty(), "W8 should be zero-arg");
                id.unique_id
            }
            other => panic!("expected zero-arg constructor call, got {other:?}"),
        },
        other => panic!("expected user bind, got {other:?}"),
    };

    let variant_uid = resolved
        .iter()
        .find_map(|node| match node {
            sigil::resolved::Resolved::EnumDef(_, id, _, variants, _)
                if id.name == "BitWidth" || id.name == "Global::BitWidth" =>
            {
                variants
                    .iter()
                    .find(|variant| {
                        variant.id.name == "BitWidth::W8"
                            || variant.id.name == "Global::BitWidth::W8"
                    })
                    .map(|variant| variant.id.unique_id)
            }
            _ => None,
        })
        .expect("BitWidth::W8 variant should exist");

    assert_eq!(use_uid, variant_uid);

    let colliding_defs = resolved
        .iter()
        .filter_map(|node| match node {
            sigil::resolved::Resolved::BuiltinDecl(_, id, _, _, _, _, _)
                if id.unique_id == use_uid =>
            {
                Some(format!("builtin {}", id.name))
            }
            sigil::resolved::Resolved::Def(_, id, _, _, _, _, _, _) if id.unique_id == use_uid => {
                Some(format!("def {}", id.name))
            }
            sigil::resolved::Resolved::ExtractorDef(_, id, _, _, _, _, _)
                if id.unique_id == use_uid =>
            {
                Some(format!("extractor {}", id.name))
            }
            sigil::resolved::Resolved::StructDef(_, id, ..) if id.unique_id == use_uid => {
                Some(format!("struct {}", id.name))
            }
            sigil::resolved::Resolved::RecordDef(_, id, _, _) if id.unique_id == use_uid => {
                Some(format!("record {}", id.name))
            }
            sigil::resolved::Resolved::DeferrorDef(_, id, _, _) if id.unique_id == use_uid => {
                Some(format!("deferror {}", id.name))
            }
            sigil::resolved::Resolved::EnumDef(_, _, _, variants, _) => variants
                .iter()
                .find(|variant| variant.id.unique_id == use_uid)
                .map(|variant| format!("enum variant {}", variant.id.name)),
            _ => None,
        })
        .collect::<Vec<_>>();

    assert!(
        colliding_defs == vec!["enum variant BitWidth::W8".to_string()]
            || colliding_defs == vec!["enum variant Global::BitWidth::W8".to_string()],
        "unexpected declarations sharing uid {use_uid}: {colliding_defs:?}"
    );
}

fn bitwidth_zero_arg_variant_typechecks_with_builtin_prelude() {
    let typed = typecheck_with_builtin_prelude("width = BitWidth::W8");
    assert!(matches!(
        typed.last().expect("user bind should be present").node,
        TypedInner::Bind(_, _)
    ));
}

fn ensure_standard_call_typechecks_to_result_value() {
    let typed = typecheck_with_builtin_prelude(
        r#"def is_even(n: Int) -> Boolean { Int::is_even(n) }
guard = ensure(4, &is_even, NoneError())"#,
    );
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(rhs.node, TypedInner::Block(_)));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn and_special_form_typechecks_to_boolean_if() {
    let typed = typecheck_with_builtin_prelude("flag = and(True, False)");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(rhs.node, TypedInner::If(_, _, Some(_))));
            assert!(matches!(rhs.ty, scar::types::Ty::Bool));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn eq_helper_typechecks_as_trait_call() {
    let typed = typecheck_with_builtin_prelude("flag = eq(1, 1)");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(
                rhs.node,
                TypedInner::TraitCall { ref method_name, .. } if method_name == "eq"
            ));
            assert!(matches!(rhs.ty, scar::types::Ty::Bool));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn eq_helper_mismatch_uses_shared_reason() {
    let resolved = resolve_with_builtin_prelude("print(to_string(eq(1, True)))");
    let err = typecheck(resolved).expect_err("eq helper mismatch must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    let data = err.structured.as_ref().unwrap().data_json();
    assert_eq!(data["expected_type"], "Int");
    assert_eq!(data["actual_type"], "Boolean");
}

fn shadowed_compare_keeps_generic_call_mismatch_message() {
    let resolved = resolve_with_builtin_prelude(
        r#"def compare(left: String, right: String) -> Boolean {
  True
}

print(to_string(compare(1, True)))"#,
    );
    let err = typecheck(resolved).expect_err("shadowed compare should use generic call checking");
    assert!(err
        .message
        .contains("Argument type mismatch: expected String, got Int"));
    assert!(!err.message.contains("Compare::compare helper"));
}

fn concat_helper_typechecks_as_trait_call() {
    let typed = typecheck_with_builtin_prelude(r#"value = concat("a", "b")"#);
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(
                rhs.node,
                TypedInner::TraitCall { ref method_name, .. } if method_name == "concat"
            ));
            assert!(matches!(rhs.ty, scar::types::Ty::Str));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn to_string_helper_typechecks_as_trait_call() {
    let typed = typecheck_with_builtin_prelude("text = to_string(42)");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => {
            assert!(matches!(
                rhs.node,
                TypedInner::TraitCall { ref method_name, .. } if method_name == "to_string"
            ));
            assert!(matches!(rhs.ty, scar::types::Ty::Str));
        }
        other => panic!("expected bind, got {:?}", other),
    }
}

fn ensure_rejects_call_expression_predicate() {
    let err = typecheck_with_rules(
        r#"def is_even() -> (Int -> Boolean) { {|n| Int::is_even(n) } }
guard = ensure(4, is_even(), NoneError())"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("call expression predicate must fail");
    assert!(err.message.contains("ensure requires a closure or capture"));
}

fn require_rejects_non_concrete_error_expression() {
    let err = typecheck_with_rules(
        r#"def bad_code() -> Int { 1 }
guard = require(False, bad_code())"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("non-Error expression must fail");
    assert!(err
        .message
        .contains("require error branch must evaluate to Error, got Int"));
}

fn kernel_and_contract_rejects_eager_signature() {
    let kernel_source = include_str!("../../../lib/kernel.srt").replace(
        "@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean",
        "@builtin def and(left: Boolean, right: Boolean) -> Boolean",
    );
    let err = typecheck_std_modules_with_overrides(&[("Kernel", &kernel_source)])
        .expect_err("eager signature should violate canonical contract");
    assert!(err
        .message
        .contains("@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean"));
}

fn removed_if_builtin_declaration_is_rejected() {
    let ast = spire::parse_with_context(
        "defmod Kernel { @builtin def if(flag: Boolean, then_branch: Lazy<$A>, else_branch: Lazy<$A>) -> $A }",
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    ).expect("obsolete builtin declaration should parse");
    let stages = vec![sigil::staged_modules_from_source_ast(ast, None)];
    let declarations =
        sigil::precollect_declaration_index(&stages).expect("precollect declarations");
    let error = sigil::resolve_staged_program(&stages, Vec::new(), &declarations, None)
        .expect_err("if must be an ordinary standard function");
    assert!(
        error.message.contains("Unknown builtin declaration: if"),
        "{error:?}"
    );
}

fn kernel_does_not_allow_removed_concat_builtin() {
    let ast = spire::parse_with_context(
        r#"defmod Kernel {
  @builtin def concat(left: $A, right: $A) -> String
}"#,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    )
    .expect("removed builtin fixture should parse");
    let module_stages = vec![sigil::staged_modules_from_source_ast(ast, None)];
    let declaration_index =
        sigil::precollect_declaration_index(&module_stages).expect("std modules should precollect");
    let err = sigil::resolve_staged_program(&module_stages, Vec::new(), &declaration_index, None)
        .expect_err("concat is no longer a declared runtime builtin");
    assert!(
        err.message.contains("Unknown builtin declaration: concat"),
        "{}",
        err.message
    );
}

fn if_auto_forces_zero_arg_closure_once_for_branch_type() {
    let typed = typecheck_with_builtin_prelude("value = if(True, {|| 1}, 2)");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => assert!(matches!(rhs.ty, scar::types::Ty::Int)),
        other => panic!("expected bind, got {:?}", other),
    }
}

fn if_nested_closure_is_not_deep_forced() {
    let err = typecheck_with_rules(
        "value = if(True, {|| {|| 1}}, 2)",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("nested lazy branch should not be deep forced");
    assert!(err
        .message
        .contains("if branches have different types: (-> Int) and Int"));
}

fn user_lazy_annotation_is_rejected() {
    let err = typecheck_with_rules("x: Lazy<Int> = 1", RuntimeSourcePolicy::script())
        .expect_err("user lazy annotations must fail");
    assert!(err
        .message
        .contains("Lazy<T> is reserved for standard callable parameter declarations"));
}

fn require_accepts_lazy_error_branch() {
    let typed = typecheck_with_rules(
        r#"deferror SomeError(detail: String) { |detail: String| Self(message: detail, detail: detail) }
guard = require(False, {|| SomeError("boom") })"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("lazy error branch should typecheck");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => assert!(matches!(rhs.node, TypedInner::Block(_))),
        other => panic!("expected bind, got {:?}", other),
    }
}

fn ensure_accepts_lazy_error_branch() {
    let typed = typecheck_with_rules(
        r#"deferror SomeError(detail: String) { |detail: String| Self(message: detail, detail: detail) }
def is_positive(value: Int) -> Boolean { value > 0 }
guard = ensure(-1, &is_positive, {|| SomeError("boom") })"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("lazy ensure error branch should typecheck");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => assert!(matches!(rhs.node, TypedInner::Block(_))),
        other => panic!("expected bind, got {:?}", other),
    }
}

fn require_accepts_existing_error_value() {
    let typed = typecheck_with_rules(
        r#"guard = match Err(NoneError()) {
  Ok(_) => require(False, NoneError()),
  Err(e) => require(False, e),
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("existing Error value should typecheck");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => assert!(matches!(rhs.node, TypedInner::Match(_, _))),
        other => panic!("expected bind, got {:?}", other),
    }
}

fn ensure_accepts_existing_error_value() {
    let typed = typecheck_with_rules(
        r#"def is_positive(value: Int) -> Boolean { value > 0 }
guard = match Err(NoneError()) {
  Ok(_) => ensure(-1, &is_positive, NoneError()),
  Err(e) => ensure(-1, &is_positive, e),
}"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("existing Error value should typecheck");
    let bind = typed.last().expect("binding should exist");
    match &bind.node {
        TypedInner::Bind(_, rhs) => assert!(matches!(rhs.node, TypedInner::Match(_, _))),
        other => panic!("expected bind, got {:?}", other),
    }
}

fn generic_annotation_list_int_is_accepted() {
    let typed = typecheck_with_builtin_prelude("nums: List<Int> = [1, 2, 3]");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Bind(_, _))
    ));
}

fn generic_def_signature_instantiates_per_call_site() {
    let typed = typecheck_with_builtin_prelude(
        r#"def id(x: $A) -> $A { x }
left: Int = id(1)
right: String = id("ok")"#,
    );
    assert!(typed.len() >= 3);
    assert!(typed
        .iter()
        .rev()
        .take(3)
        .all(|node| matches!(node.node, TypedInner::Bind(_, _) | TypedInner::Def(..))));
}

fn generic_defenum_constructor_and_match_typecheck() {
    let typed = typecheck_with_builtin_prelude(
        r#"defenum StepSignal<$A> {
  Resume($A),
  Stop($A),
}

step: StepSignal<Int> = StepSignal::Resume(1)
value = match step {
  StepSignal::Resume(v) => v,
  StepSignal::Stop(v) => v,
}"#,
    );
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::EnumDef(_, _))));
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Bind(_, _))
    ));
}

fn closure_param_annotation_without_expected_type_constrains_calls() {
    let resolved = resolve_with_builtin_prelude(
        r#"id = {|value: Int| value}
answer = id("oops")"#,
    );
    let err = typecheck(resolved).expect_err("annotation should reject String call");
    assert!(err.message.contains("expected Int, got String"));
}

fn closure_application_mismatch_reports_callable_type_signature() {
    let resolved = resolve_with_builtin_prelude(
        r#"inc = {|n: Int| n + 1}
answer = inc("oops")"#,
    );
    let err = typecheck(resolved).expect_err("closure application should fail");
    assert!(err.message.contains("expected Int, got String"));
    let hint = err.hint.as_deref().expect("callable signature hint");
    assert!(hint.contains("Callable type signature: (Int -> Int)"));
}

fn builtin_function_arity_reports_call_target_signature() {
    let resolved = resolve_with_builtin_prelude("value = print()");
    let err = typecheck(resolved).expect_err("builtin arity mismatch should fail");
    let hint = err.hint.as_deref().expect("builtin signature hint");
    assert_eq!(
        hint,
        "Call target signature: Kernel::print(arg1: String) -> Unit"
    );
}

fn builtin_function_mismatch_reports_call_target_signature() {
    let resolved = resolve_with_builtin_prelude("value = print(1)");
    let err = typecheck(resolved).expect_err("builtin type mismatch should fail");
    let hint = err.hint.as_deref().expect("builtin signature hint");
    assert_eq!(
        hint,
        "Call target signature: Kernel::print(arg1: String) -> Unit"
    );
}

fn capture_application_mismatch_reports_callable_type_signature() {
    let resolved = resolve_with_builtin_prelude_in_script_module(
        r#"def add(x: Int, y: Int) -> Int {
  x + y
}
bad = &add(&1, "oops")"#,
    )
    .expect("source should resolve");
    let err = typecheck(resolved).expect_err("capture application should fail");
    assert!(err.message.contains("expected Int, got String"));
    let hint = err
        .hint
        .as_deref()
        .expect("callable definition signature hint");
    assert!(hint.contains("Callable definition signature: add(x: Int, y: Int) -> Int"));
}

fn script_callable_signature_omits_file_path_segments() {
    let resolved = resolve_with_builtin_prelude_in_module(
        r#"def add_one(x: Int) -> Int {
  x + 1
}
result = add_one("oops")"#,
        "__Script::Users::haruca::work::rust::surtr::surtr_compile_error_cases::type_call_arg_mismatch",
    )
    .expect("source should resolve");
    let err = typecheck(resolved).expect_err("function call should fail");
    let hint = err
        .hint
        .as_deref()
        .expect("callable definition signature hint");
    assert!(hint.contains("Callable definition signature: add_one(x: Int) -> Int"));
    assert!(!hint.contains("__Script::Users::haruca"));
    assert!(hint.contains("Callable definition span: 0.."));
}

fn compose_mismatch_reports_left_and_right_callable_types() {
    let resolved = resolve_with_builtin_prelude(
        r#"def text(x: Int) -> String {
  to_string(x)
}

def inc(x: Int) -> Int {
  x + 1
}

bad = &text >> &inc"#,
    );
    let err = typecheck(resolved).expect_err("compose mismatch should fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    let facts = err.structured.as_ref().unwrap();
    let types = std::iter::once(&facts.primary)
        .chain(facts.related.iter())
        .filter_map(|fact| fact.ty.as_deref())
        .collect::<Vec<_>>();
    assert!(types.contains(&"(Int -> String)"));
    assert!(types.contains(&"(Int -> Int)"));
}

fn compose_accepts_calls_returning_function_values() {
    let resolved = resolve_with_builtin_prelude(
        r#"def make_inc() -> (Int -> Int) {
  {|x| x + 1}
}

def make_double() -> (Int -> Int) {
  {|x| x * 2}
}

plain = make_inc() >> make_double()"#,
    );
    typecheck(resolved).expect("compose should accept function-returning calls");
}

fn compose_rejects_non_function_call_results_after_typechecking_call() {
    let resolved = resolve_with_builtin_prelude(
        r#"def inc(x: Int) -> Int {
  x + 1
}

plain = inc(1) >> inc(1)"#,
    );
    let err = typecheck(resolved).expect_err("compose should reject Int call results");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NotCallable)
    );
    let hint = err.hint.as_deref().expect("compose function-value hint");
    assert!(hint.contains("Call target signature:"));
    assert!(hint.contains("result type Int is not a function value"));
}

fn closure_trait_helper_binding_requires_concrete_callable_boundary() {
    let resolved = resolve_with_builtin_prelude(r#"cmp = {|left, right| compare(left, right)}"#);
    let err = typecheck(resolved).expect_err("unresolved closure helper binding must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::UnresolvedTraitMethodInstantiation),
        "{err:?}"
    );
}

fn closure_trait_helper_binding_accepts_binding_annotation() {
    let resolved = resolve_with_builtin_prelude(
        r#"cmp: (Int, Int -> Ordering) = {|left, right| compare(left, right)}"#,
    );
    typecheck(resolved).expect("binding annotation should concretize compare helper");
}

fn closure_trait_helper_binding_accepts_parameter_annotations() {
    let resolved =
        resolve_with_builtin_prelude(r#"cmp = {|left: Int, right: Int| compare(left, right)}"#);
    typecheck(resolved).expect("parameter annotations should concretize compare helper");
}

fn on_call_concretizes_closure_trait_helper_from_key_function() {
    let resolved = resolve_with_builtin_prelude(
        r#"sorted = List::sort_by(["a", "abcd", "xy"], {|left, right| compare(left, right)} `on` &String::len)"#,
    );
    typecheck(resolved).expect("on should concretize compare helper from the key callable");
}

fn on_call_concretizes_trait_helper_capture_from_key_function() {
    let resolved = resolve_with_builtin_prelude(
        r#"sorted = List::sort_by(["a", "abcd", "xy"], &compare `on` &String::len)"#,
    );
    typecheck(resolved)
        .expect("on should concretize captured compare helper from the key callable");
}

fn pipe_plain_apply_over_result_reports_whole_lhs_mismatch() {
    let resolved = resolve_with_builtin_prelude(
        r#"def parse(x: Int) -> Result<Int> {
  Ok(x)
}

def inc(x: Int) -> Int {
  x + 1
}

bad = parse(1) |> &inc"#,
    );
    let err = typecheck(resolved).expect_err("plain pipe over Result should fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    let diagnostic = err.structured.as_ref().expect("structured pipe relation");
    let diagnostics::DiagnosticData::ArgumentRelation(data) = &diagnostic.data else {
        panic!("{err:?}")
    };
    assert_eq!(data.expected_type.as_deref(), Some("Int"));
    assert!(
        data.actual_type
            .as_deref()
            .is_some_and(|ty| ty.starts_with("Result<Int")),
        "{err:?}"
    );
    assert!(
        matches!(&diagnostic.origin, diagnostics::DiagnosticOrigin::Operator { operator } if operator == "|>")
    );
}

fn context_bind_rejects_plain_rhs_return() {
    let resolved = resolve_with_builtin_prelude(
        r#"def parse(x: Int) -> Result<Int> {
  Ok(x)
}

def inc(x: Int) -> Int {
  x + 1
}

bad = parse(1) |>= &inc"#,
    );
    let err = typecheck(resolved).expect_err("bind with plain RHS should fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::TypeConstructorFamilyMismatch),
        "{err:?}"
    );
}

fn constructor_context_bind_preserves_candidate_failures() {
    let resolved =
        resolve_with_builtin_prelude(r#"bad = Monad::return(1) |>= {|value| value + 1}"#);
    let err =
        typecheck(resolved).expect_err("all rejected constructor candidates must fail closed");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation)
    );
    let structured = err
        .structured
        .expect("candidate failure must be structured");
    let diagnostics::DiagnosticData::CandidateSelection(data) = structured.data else {
        panic!("expected candidate selection data");
    };
    assert_eq!(data.trait_name, "Monad");
    assert_eq!(data.method, "bind");
    assert!(!data.failures.is_empty());
    assert!(data
        .failures
        .iter()
        .all(|failure| !failure.detail.is_empty()));
}

fn constructor_context_bind_rolls_back_rejected_candidates() {
    let typed =
        typecheck_with_builtin_prelude(r#"bound = Monad::return(1) |>= {|value| [value + 1]}"#);
    let bind = typed
        .iter()
        .rev()
        .find(|node| matches!(node.node, TypedInner::Bind(..)))
        .expect("binding should exist");
    let TypedInner::Bind(_, rhs) = &bind.node else {
        panic!("expected binding, got {:?}", bind.node);
    };
    assert_eq!(rhs.ty, Ty::List(Box::new(Ty::Int)));
}

fn context_bind_rhs_closure_receives_result_return_expectation() {
    let resolved = resolve_with_builtin_prelude(
        r#"bound: Result<Int> = Ok(1) |>= {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    typecheck(resolved).expect("bind RHS closure should receive Result return expectation");
}

fn safebind_pipe_bind_closure_receives_expected_result_return() {
    let typed = typecheck_with_builtin_prelude(
        r#"result: Result<Int> = Ok(1) |>= {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn apply_and_map_rhs_closures_receive_whole_expression_return_expectation() {
    let resolved = resolve_with_builtin_prelude(
        r#"applied: Result<Int> = 1 |> {|x|
  value =? Ok(x + 1)
  Ok(value)
}

mapped: Result<Result<Int>> = Ok(1) |*> {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    typecheck(resolved)
        .expect("annotated apply/map operators should pass Result expectation to RHS closures");
}

fn safebind_pipe_apply_annotated_closure_receives_expected_result_return() {
    let typed = typecheck_with_builtin_prelude(
        r#"result: Result<Int> = 1 |> {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn safebind_pipe_map_annotated_closure_receives_expected_result_return() {
    let typed = typecheck_with_builtin_prelude(
        r#"result: Result<Result<Int>> = Ok(1) |*> {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn kleisli_compose_closures_receive_result_return_expectation() {
    let resolved = resolve_with_builtin_prelude(
        r#"pipeline: (Int -> Result<Int>) = {|x|
  value =? Ok(x + 1)
  Ok(value)
} >=> {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    typecheck(resolved).expect("Kleisli operands should receive Result return expectation");
}

fn safebind_kleisli_annotated_closure_receives_expected_result_return() {
    let typed = typecheck_with_builtin_prelude(
        r#"def parse(text: String) -> Result<Int> {
  Ok(String::len(text))
}

pipeline: (String -> Result<Int>) = &parse >=> {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn lifted_compose_rhs_closure_allows_explicit_nested_result_expectation() {
    let resolved = resolve_with_builtin_prelude(
        r#"deferror Oops {
  "oops"
}

def gen(x: Int) -> Result<Int, Oops> {
  if(x > 0, Ok(x), Err(Oops()))
}

pipeline: (Int -> Result<Result<Int>>) = {|x|
  gen(x)
} >* {|x|
  value =? Ok(x + 1)
  Ok(value)
}"#,
    );
    typecheck(resolved)
        .expect("Lifted compose should allow explicit nested Result RHS expectation");
}

fn context_map_keeps_result_for_later_bind() {
    let typed = typecheck_with_builtin_prelude(
        r#"def parse(x: Int) -> Result<Int> {
  Ok(x)
}

def inc(x: Int) -> Int {
  x + 1
}

def stringify(x: Int) -> Result<String> {
  Ok(to_string(x))
}

ok = parse(1) |*> &inc |>= &stringify"#,
    );
    assert_eq!(typed.last().map(|node| &node.ty), Some(&Ty::Unit));
}

fn context_map_and_bind_lower_to_operator_trait_calls() {
    let typed = typecheck_with_builtin_prelude(
        r#"def parse(x: Int) -> Result<Int> {
  Ok(x)
}

def inc(x: Int) -> Int {
  x + 1
}

def stringify(x: Int) -> Result<String> {
  Ok(to_string(x))
}

mapped = parse(1) |*> &inc
bound = parse(1) |>= &stringify"#,
    );
    let trait_calls = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => match &rhs.node {
                TypedInner::TraitCall {
                    trait_name,
                    method_name,
                    dispatch,
                    origin,
                    args,
                    ..
                } => Some((trait_name, method_name, dispatch, origin, args, &rhs.ty)),
                _ => None,
            },
            _ => None,
        })
        .collect::<Vec<_>>();

    assert!(trait_calls.iter().any(
        |(trait_name, method_name, dispatch, origin, args, result_ty)| {
            trait_name.ends_with("Functor")
                && *method_name == "fmap"
                && matches!(
                    dispatch,
                    scar::typed::TraitDispatch::Static(
                        scar::typed::TraitDispatchTarget::UserFunction { name, .. }
                    ) if name.ends_with("::fmap") || name == "fmap"
                )
                && matches!(
                    origin,
                    TraitCallOrigin::Operator {
                        op: OperatorTraitOp::PipeMap,
                        lhs_ty: Ty::Result(_, _),
                        rhs_ty: Ty::Func(_, _) | Ty::UserFunc { .. } | Ty::BuiltinFunc { .. },
                    }
                )
                && args.len() == 2
                && matches!(result_ty, Ty::Result(ok, _) if matches!(ok.as_ref(), Ty::Int))
        }
    ));
    assert!(trait_calls.iter().any(
        |(_trait_name, _method_name, _dispatch, origin, args, result_ty)| {
            matches!(
                origin,
                TraitCallOrigin::Operator {
                    op: OperatorTraitOp::PipeBind,
                    lhs_ty: Ty::Result(_, _),
                    rhs_ty: Ty::Func(_, _) | Ty::UserFunc { .. } | Ty::BuiltinFunc { .. },
                }
            ) && args.len() == 2
                && matches!(result_ty, Ty::Result(ok, _) if matches!(ok.as_ref(), Ty::Str))
        }
    ));
}

fn explicit_functor_call_has_explicit_origin() {
    let typed = typecheck_with_builtin_prelude(
        r#"def inc(x: Int) -> Int {
  x + 1
}

mapped = Functor::fmap(Ok(1), &inc)"#,
    );
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            method_name,
            origin,
            ..
        } => {
            assert_eq!(method_name, "fmap");
            assert_eq!(origin, &TraitCallOrigin::Explicit);
            assert!(matches!(rhs.ty, Ty::Result(_, _)));
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn plain_flow_operators_use_compiler_rules() {
    let typed = typecheck_with_builtin_prelude(
        r#"def inc(x: Int) -> Int { x + 1 }
def twice(x: Int) -> Int { x * 2 }
applied = 1 |> &inc
composed = &inc >> &twice"#,
    );
    let mut bound = typed.iter().filter_map(|node| match &node.node {
        TypedInner::Bind(_, value) => Some(&value.node),
        _ => None,
    });
    assert!(bound
        .clone()
        .any(|node| matches!(node, TypedInner::Pipe(_, _))));
    assert!(bound.any(|node| matches!(
        node,
        TypedInner::Compose(scar::typed::ComposeFlavor::Plain, _, _)
    )));
}

fn flow_apply_and_compose_operators_lower_to_trait_calls() {
    let typed = typecheck_with_builtin_prelude(
        r#"def inc(x: Int) -> Int { x + 1 }
def show_int(x: Int) -> String { to_string(x) }
def parse(x: Int) -> Result<Int> { Ok(x) }
def parse_list(x: Int) -> List<Int> { [x] }
def maybe_parse(x: Int) -> Option<Int> { Option::Some(x) }
def maybe_show(x: Int) -> Option<String> { Option::Some(to_string(x)) }
applied = 1 |> &inc
plain = &inc >> &show_int
lifted = &parse >* &show_int
kleisli = &parse_list >=> {|x| [x, x + 1]}
lifted_option = &maybe_parse >* &show_int
kleisli_option = &maybe_parse >=> &maybe_show"#,
    );
    let values = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert!(values
        .iter()
        .any(|node| matches!(node.node, TypedInner::Pipe(_, _))));
    assert!(values.iter().any(|node| matches!(
        node.node,
        TypedInner::Compose(scar::typed::ComposeFlavor::Plain, _, _)
    )));
    let contextual = values
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Block(items) => match items.last().map(|item| &item.node) {
                Some(TypedInner::Closure(_, _, body)) => match &body.node {
                    TypedInner::TraitCall {
                        trait_name,
                        method_name,
                        ..
                    } => Some((trait_name.as_str(), method_name.as_str())),
                    _ => None,
                },
                _ => None,
            },
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(contextual.len(), 4);
    assert_eq!(
        contextual
            .iter()
            .filter(|(_, method)| *method == "fmap")
            .count(),
        2
    );
    assert_eq!(
        contextual
            .iter()
            .filter(|(_, method)| *method == "bind")
            .count(),
        2
    );
}

fn user_defined_container_can_use_context_operators_via_traits() {
    let typed = typecheck_with_builtin_prelude(
        r#"defenum Boxed<$T> {
  Box($T),
}

impl Functor for Boxed<$T> {
  def fmap(self: Boxed<$A>, mapper: ($A -> $B)) -> Boxed<$B> {
    match self {
      Boxed::Box(value) => Boxed::Box(mapper(value)),
    }
  }
}

impl Applicative for Boxed<$T> {
  def pure::<Boxed<$T>>(value: $A) -> Boxed<$A> { Boxed::Box(value) }

  def ap(mapper: Boxed<($A -> $B)>, value: Boxed<$A>) -> Boxed<$B> {
    match mapper {
      Boxed::Box(f) => match value {
        Boxed::Box(inner) => Boxed::Box(f(inner)),
      },
    }
  }
}

impl Monad for Boxed<$T> {
  def return::<Boxed<$T>>(value: $A) -> Boxed<$A> { Boxed::Box(value) }

  def bind(self: Boxed<$A>, mapper: ($A -> Boxed<$B>)) -> Boxed<$B> {
    match self {
      Boxed::Box(value) => mapper(value),
    }
  }
}

def inc(x: Int) -> Int {
  x + 1
}

def box_inc(x: Int) -> Boxed<Int> {
  Boxed::Box(x + 1)
}

def render(x: Int) -> String {
  to_string(x)
}

def stringify(x: Int) -> Boxed<String> {
  Boxed::Box(to_string(x))
}

mapped = Boxed::Box(1) |*> &inc
bound = Boxed::Box(1) |>= &stringify
lifted = &box_inc >* &render
kleisli = &box_inc >=> &stringify"#,
    );

    let boxed_results = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(&rhs.ty),
            _ => None,
        })
        .filter(|ty| matches!(ty, Ty::Enum(name, _) if name == "Boxed" || name == "Global::Boxed"))
        .count();
    assert_eq!(boxed_results, 2);
    let boxed_function_results = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(&rhs.ty),
            _ => None,
        })
        .filter(|ty| {
            matches!(ty, Ty::Func(_, ret) if matches!(ret.as_ref(), Ty::Enum(name, _) if name == "Boxed" || name == "Global::Boxed"))
        })
        .count();
    assert_eq!(boxed_function_results, 2);
}

fn result_match_wildcard_self_after_ok_can_change_ok_payload_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"def remap(value: Result<Int>) -> Result<String> {
  match value {
    Ok(inner) => Ok(to_string(inner)),
    _ => value,
  }
}"#,
    );

    let typed = typecheck(resolved).expect("Err-proven wildcard arm should typecheck");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Def(..))));
}

fn result_match_wildcard_self_after_ok_or_can_change_ok_payload_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"def remap(value: Result<Int>) -> Result<String> {
  match value {
    Ok(inner) | Ok(inner) => Ok(to_string(inner)),
    _ => value,
  }
}"#,
    );

    typecheck(resolved).expect("OR Ok arm should preserve Err-proven wildcard coercion");
}

fn result_match_wildcard_self_after_ok_can_keep_err_for_bind_shape() {
    let resolved = resolve_with_builtin_prelude(
        r#"def bind_like(value: Result<Int>) -> Result<String> {
  match value {
    Ok(inner) => Ok(to_string(inner)),
    _ => value,
  }
}"#,
    );

    let typed = typecheck(resolved).expect("Err-proven bind-style wildcard arm should typecheck");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Def(..))));
}

fn result_match_wildcard_self_requires_err_proven_branch() {
    let resolved = resolve_with_builtin_prelude(
        r#"def bad(value: Result<Int>) -> Result<String> {
  match value {
    _ => value,
    Ok(inner) => Ok(to_string(inner)),
  }
}"#,
    );

    let err = typecheck(resolved).expect_err("wildcard arm without prior Ok coverage must fail");
    assert!(
        err.message.contains("Match arm type mismatch")
            || err
                .message
                .contains("expected Result<String>, got Result<Int>")
            || err
                .message
                .contains("expected Result<Int>, got Result<String>")
    );
}

fn closure_param_annotation_must_match_expected_signature() {
    let resolved = resolve_with_builtin_prelude(r#"id: (String -> String) = {|value: Int| value}"#);
    let err = typecheck(resolved).expect_err("mismatched expected signature must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::AnnotationTypeMismatch),
        "{err:?}"
    );
}

fn local_binding_annotation_can_reference_outer_generic_type_param() {
    let typed = typecheck_with_builtin_prelude(
        r#"def id(x: $A) -> $A {
  y: $A = x
  y
}"#,
    );
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Def(..))));
}

fn closure_param_annotation_can_reference_outer_generic_type_param() {
    let typed = typecheck_with_builtin_prelude(
        r#"def keep(x: $A) -> $A {
  same: ($A -> $A) = {|value: $A| value}
  same(x)
}"#,
    );
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Def(..))));
}

fn generic_first_can_inline_tuple_rebuild_with_closure_param_annotation() {
    let typed = typecheck_with_builtin_prelude(
        r#"def first(f: ($A -> $C), seed: $B) -> (($A, $B) -> ($C, $B)) {
  {|pair: ($A, $B)|
    (left, right) = pair
    (f(left), right)
  }
}"#,
    );
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::Def(..))));
}

fn sibling_closures_keep_substitution_state_local() {
    let typed = typecheck_with_builtin_prelude(
        r#"int_id: (Int -> Int) = {|value| value}
str_id: (String -> String) = {|value| value}
left: Int = int_id(1)
right: String = str_id("ok")"#,
    );
    assert!(typed.len() >= 4);
    assert!(typed
        .iter()
        .rev()
        .take(4)
        .all(|node| matches!(node.node, TypedInner::Bind(_, _))));
}

fn cyclic_type_definition_is_rejected() {
    for (source, cycle_size) in [
        ("defstruct Node { next: Node, }", 1),
        (
            "defrecord Left(right: Right)\ndefrecord Right(left: Left)",
            2,
        ),
    ] {
        let resolved = resolve_with_builtin_prelude(source);
        let declaration_spans = resolved
            .iter()
            .filter_map(|node| match node {
                Resolved::StructDef(_, id, ..) | Resolved::RecordDef(_, id, ..) => {
                    Some((id.name.clone(), id.span.clone()))
                }
                _ => None,
            })
            .collect::<std::collections::HashMap<_, _>>();
        let err = typecheck(resolved).expect_err("cyclic type must fail");
        let cycle = err
            .message
            .strip_prefix("Cyclic type definition detected: ")
            .expect("cycle diagnostic should keep its reason")
            .split(" -> ")
            .collect::<Vec<_>>();
        assert_eq!(cycle.len(), cycle_size + 1);
        assert_eq!(cycle.first(), cycle.last());
        assert_eq!(err.span, declaration_spans[cycle[0]]);
    }
}

fn enum_cycle_is_allowed_when_not_shared_by_all_variants() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum Loop {
  End,
  Next(Loop),
}
value: Loop = Loop::End"#,
    );
    let typed = typecheck(resolved).expect("enum should allow conditional recursion");
    assert!(typed
        .iter()
        .any(|node| matches!(node.node, TypedInner::EnumDef(_, _))));
}

fn enum_cycle_is_rejected_when_shared_by_all_variants() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum Loop {
  A(Loop),
  B(Loop),
}"#,
    );
    let err = typecheck(resolved).expect_err("enum cycle must fail");
    assert!(err.message.contains("Cyclic type definition detected"));
}

fn enum_field_access_is_rejected() {
    let resolved = resolve_with_builtin_prelude(
        r#"defenum Direction {
  Up,
  Down,
}
up: Direction = Direction::Up
x = up.idx"#,
    );
    let err = typecheck(resolved).expect_err("enum field access must fail");
    assert!(err
        .message
        .contains("No variant selector 'idx' on Direction"));
}

fn match_binding_pattern_is_treated_as_exhaustive() {
    let resolved = resolve_with_builtin_prelude(
        r#"flag = True
answer = match flag {
  value => value,
}"#,
    );
    let typed = typecheck(resolved).expect("binding arm should be exhaustive");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Bind(_, _))
    ));
}

fn match_tuple_binding_pattern_is_treated_as_exhaustive() {
    let resolved = resolve_with_builtin_prelude(
        r#"pair = (1, "two")
answer = match pair {
  (left, right) => right,
}"#,
    );
    let typed = typecheck(resolved).expect("tuple binding arm should be exhaustive");
    assert!(matches!(
        typed.last().map(|node| &node.node),
        Some(TypedInner::Bind(_, _))
    ));
}

fn match_guard_must_be_boolean() {
    let resolved = resolve_with_builtin_prelude(
        r#"answer = match 1 {
  n when 1 => n,
  _ => 0,
}"#,
    );
    let err = typecheck(resolved).expect_err("non-boolean guard must fail");
    assert!(err.message.contains("match guard must be Boolean, got Int"));
}

fn guarded_match_arm_does_not_satisfy_exhaustiveness() {
    let resolved = resolve_with_builtin_prelude(
        r#"answer = match True {
  flag when flag => 1,
}"#,
    );
    let err = typecheck(resolved).expect_err("guarded-only arm must be non-exhaustive");
    assert!(err
        .message
        .contains("Non-exhaustive match. Missing: True, False"));
}

fn struct_literal_rejects_extra_fields() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
User { name: name, age: age, extra: 1 }
  }
}
user = User("alice", 20)"#,
    );
    let err = typecheck(resolved).expect_err("extra fields must fail");
    assert!(err.message.contains("Unknown field 'extra' in User"));
}

fn constructor_named_args_reject_duplicate_fields() {
    let resolved = resolve_with_builtin_prelude(
        r#"defrecord Pair(first: Int, second: String)
pair = Pair(first: 1, first: 2)"#,
    );
    let err = typecheck(resolved).expect_err("duplicate named args must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::DuplicateArgument)
    );
}

fn struct_literal_field_shorthand_typechecks() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
User { name, age }
  }
}
user = User("alice", 20)"#,
    );
    typecheck(resolved).expect("struct shorthand should typecheck");
}

fn struct_literal_field_shorthand_mixed_with_explicit_typechecks() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def rename(self, name: String, next_age: Int) -> Self {
User { name, age: next_age }
  }

  def new(name: String, age: Int) -> Self {
    User::rename(User { name, age }, name, age)
  }
}"#,
    );
    typecheck(resolved).expect("mixed struct shorthand should typecheck");
}

fn struct_literal_field_shorthand_rejects_duplicate_fields() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
User { name, name: name }
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("duplicate shorthand field must fail");
    assert!(err.message.contains("Duplicate field 'name' in User"));
}

fn struct_requires_impl_new() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}
user = User("alice")"#,
    );
    let err = typecheck(resolved).expect_err("struct without new should fail");
    assert!(err.message.contains("must define `new` in its impl block"));
}

fn empty_struct_default_derives_without_relaxing_new_contract() {
    let resolved = resolve_with_builtin_prelude(
        r#"@derive Default
defstruct Empty {}

impl Empty {
  def new() -> Self { Empty {} }
}

value = Default::default::<Empty>()
constructed = Empty()
"#,
    );
    typecheck(resolved).expect("empty struct should derive Default and retain new constructor");
}

fn empty_struct_without_new_is_rejected() {
    let resolved = resolve_with_builtin_prelude(
        r#"@derive Default
defstruct Empty {}

value = Default::default::<Empty>()
"#,
    );
    let err = typecheck(resolved).expect_err("empty struct without new should fail");
    assert!(err.message.contains("must define `new` in its impl block"));
}

fn empty_struct_eq_and_neq_are_constant() {
    let resolved = resolve_with_builtin_prelude(
        r#"@derive Eq
defstruct Empty {}

impl Empty {
  def new() -> Self { Empty {} }
}

same = Empty() == Empty()
different = Empty() != Empty()
"#,
    );
    typecheck(resolved).expect("empty struct Eq derive should provide eq and neq");
}

fn empty_struct_compare_is_equal() {
    let resolved = resolve_with_builtin_prelude(
        r#"@derive Compare
defstruct Empty {}

impl Empty {
  def new() -> Self { Empty {} }
}

ordering = compare(Empty(), Empty())
"#,
    );
    typecheck(resolved).expect("empty struct Compare derive should provide Equal");
}

fn generic_struct_bare_annotation_requires_type_args() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct Box<$A> {
  value: $A,
}
boxed: Box = Box(1)
impl Box {
  def new(value: $A) -> Box<$A> {
    Box { value: value }
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("bare generic struct annotation should fail");
    assert!(err.message.contains("Type Box requires 1 type argument(s)"));
}

fn generic_struct_arity_mismatch_is_rejected() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct Pair<$A, $B> {
  left: $A,
  right: $B,
}
pair: Pair<Int> = Pair(1, 2)
impl Pair {
  def new(left: $A, right: $B) -> Pair<$A, $B> {
    Pair { left: left, right: right }
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("generic struct arity mismatch should fail");
    assert!(err
        .message
        .contains("Type Pair requires 2 type argument(s), got 1"));
}

fn struct_new_accepts_result_self_return_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct Elapsed {
  private millis: Int,
}
impl Elapsed {
  def new(value: Int) -> Result<Self, Error> {
    Ok(Elapsed { millis: value })
  }
}
value: Result<Elapsed> = Elapsed(10)"#,
    );
    let typed = typecheck(resolved).expect("Result<Self, Error> constructor should pass");
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected binding");
    assert!(matches!(
        &rhs.ty,
        Ty::Result(ok, err)
            if matches!(ok.as_ref(), Ty::Struct(name, _) if name == "Global::Elapsed")
                && matches!(err.as_ref(), Ty::Error)
    ));
}

fn struct_new_rejects_non_self_return_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Int {
    1
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("non-Self constructor return must fail");
    assert!(err
        .message
        .contains("`new` must return Self or Result<Self, E>"));
}

fn struct_new_rejects_result_non_self_payload() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Result<List<Self>, Error> {
    Ok([User { name: name }])
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("Result payload must be Self");
    assert!(err
        .message
        .contains("`new` must return Self or Result<Self, E>"));
}

fn struct_constructor_call_accepts_result_return_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct Elapsed {
  private millis: Int,
}
impl Elapsed {
  def new(value: Int) -> Result<Self, Error> {
    Ok(Elapsed { millis: value })
  }
}
dur = Elapsed(10)"#,
    );
    let typed = typecheck(resolved).expect("constructor call should accept Result<Self>");
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected binding");
    assert!(matches!(
        &rhs.ty,
        Ty::Result(ok, err)
            if matches!(ok.as_ref(), Ty::Struct(name, _) if name == "Global::Elapsed")
                && matches!(err.as_ref(), Ty::Error)
    ));
}

fn struct_literal_is_rejected_outside_impl_body() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
User { name: name }
  }
}
user = User { name: "alice" }"#,
    );
    let err = typecheck(resolved).expect_err("struct literal outside impl should fail");
    assert!(err
        .message
        .contains("Struct literal `User` is only allowed inside"));
}

fn user_function_call_rejects_mixed_named_and_positional_args() {
    let resolved = resolve_with_builtin_prelude(
        r#"def add3(x: Int, y: Int, z: Int) -> Int { x + y + z }
value = add3(1, y: 2, z: 3)"#,
    );
    let err = typecheck(resolved).expect_err("mixed args should fail");
    assert!(err
        .message
        .contains("Cannot mix positional and named arguments"));
}

fn user_function_call_rejects_duplicate_named_arg() {
    let resolved = resolve_with_builtin_prelude(
        r#"def add2(x: Int, y: Int) -> Int { x + y }
value = add2(x: 1, x: 2)"#,
    );
    let err = typecheck(resolved).expect_err("duplicate named arg should fail");
    assert!(err.message.contains("Duplicate argument 'x'"));
}

fn impl_self_rebinding_allows_self_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}

impl User {
  def new(name: String) -> Self {
User { name: name }
  }

  def keep(self) -> Self {
self = self
self
  }
}

user = User("alice")
print(to_string(User::keep(user).name))"#,
    );
    let _typed = typecheck(resolved).expect("self rebinding with Self should pass");
}

fn impl_self_rebinding_rejects_non_self_type() {
    let resolved = resolve_with_builtin_prelude(
        r#"defstruct User {
  name: String,
}

impl User {
  def new(name: String) -> Self {
User { name: name }
  }

  def bad(self) -> Self {
self = 1
self
  }
}"#,
    );
    let err = typecheck(resolved).expect_err("self rebinding with non-Self must fail");
    assert!(err.message.contains("`self` rebinding requires Self type"));
}

fn deferror_show_type_mismatch_points_to_show_expression_span() {
    let source =
        r#"deferror NotFound(code: String) { |code: String| Self(message: 123, code: code) }"#;
    let resolved = resolve_with_builtin_prelude(source);
    let err = typecheck(resolved).expect_err("show block must return String");
    let literal_start = source.find("123").expect("literal should exist in source");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    assert_eq!(err.span.start, literal_start);
}

fn operator_traits_and_concrete_numeric_helpers_typecheck() {
    let typed = typecheck_with_builtin_prelude(
        r#"sum = 1 + 2
quot = Div::safe_div(8.0, 2.0)
largest = Float::max(1.5, 2.5)"#,
    );

    let trait_calls = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => match &rhs.node {
                TypedInner::TraitCall {
                    trait_name,
                    method_name,
                    dispatch,
                    ..
                } => Some((trait_name.as_str(), method_name.as_str(), dispatch)),
                _ => None,
            },
            _ => None,
        })
        .collect::<Vec<_>>();

    assert_eq!(trait_calls.len(), 2);
    assert!(trait_calls
        .iter()
        .any(|(trait_name, method_name, dispatch)| {
            *trait_name == "Add"
                && *method_name == "add"
                && matches!(
                    dispatch,
                    scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::Builtin(id))
                        if Some(id.0) == sindr::builtin::builtin_id_by_name("__operator_int_add")
                )
        }));
}

fn duration_operator_traits_dispatch_to_surtr_impls() {
    let typed = typecheck_with_builtin_prelude(
        r#"sum = 10ms + 20ms
same = 10ms == 10ms
less = 10ms < 20ms"#,
    );

    let trait_calls = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => match &rhs.node {
                TypedInner::TraitCall {
                    trait_name,
                    method_name,
                    dispatch,
                    origin,
                    ..
                } => Some((trait_name.as_str(), method_name.as_str(), dispatch, origin)),
                _ => None,
            },
            _ => None,
        })
        .collect::<Vec<_>>();

    for (trait_name, method, expected_name) in [
        ("Add", "add", "Duration::add"),
        ("Eq", "eq", "Duration::eq"),
        ("Compare", "lt", "Compare::lt"),
    ] {
        assert!(
            trait_calls
                .iter()
                .any(|(actual_trait_name, method_name, dispatch, _)| {
                    *actual_trait_name == trait_name
                        && *method_name == method
                        && matches!(
                            dispatch,
                            scar::typed::TraitDispatch::Static(
                                scar::typed::TraitDispatchTarget::UserFunction { name, .. }
                            ) if name == expected_name
                        )
                }),
            "{trait_name}::{method} should dispatch to {expected_name}"
        );
    }

    assert!(
        trait_calls
            .iter()
            .any(|(trait_name, method_name, _, origin)| {
                *trait_name == "Compare"
                    && *method_name == "lt"
                    && matches!(
                        origin,
                        scar::typed::TraitCallOrigin::Comparison {
                            op: scar::typed::ComparisonOperator::Lt,
                            ..
                        }
                    )
            }),
        "< should lower through Compare::lt with a comparison origin"
    );
}

fn compare_default_methods_dispatch_to_trait_source_when_impl_omits_override() {
    let typed = typecheck_with_builtin_prelude(
        r#"
defstruct BoxedInt { value: Int }

impl BoxedInt {
  def new(value: Int) -> Self {
    BoxedInt { value }
  }
}

impl Compare for BoxedInt {
  def compare(self: Self, rhs: Self) -> Ordering {
    Compare::compare(self.value, rhs.value)
  }
}

less = lt(BoxedInt(1), BoxedInt(2))
"#,
    );

    let trait_call = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => match &rhs.node {
                TypedInner::TraitCall {
                    trait_name,
                    method_name,
                    dispatch,
                    ..
                } => Some((trait_name.as_str(), method_name.as_str(), dispatch)),
                _ => None,
            },
            _ => None,
        })
        .expect("lt call should typecheck");

    assert_eq!(trait_call.0, "Compare");
    assert_eq!(trait_call.1, "lt");
    assert!(matches!(
        trait_call.2,
        scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
            name,
            ..
        }) if name == "Compare::lt"
    ));
}

fn compare_trait_impl_still_requires_compare_method() {
    let resolved = resolve_with_builtin_prelude(
        r#"
defstruct BoxedInt { value: Int }

impl BoxedInt {
  def new(value: Int) -> Self {
    BoxedInt { value }
  }
}

impl Compare for BoxedInt {}
"#,
    );
    let err = typecheck(resolved)
        .expect_err("Compare::compare should remain required")
        .message;

    assert!(err.contains("missing method `compare`"), "{err}");
}

fn bounded_add_generics_specialize_without_pending_trait_calls() {
    fn has_pending_trait_call(node: &TypedNode) -> bool {
        match &node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => has_pending_trait_call(message) || payload.iter().any(has_pending_trait_call),
            TypedInner::TraitCall { dispatch, args, .. } => {
                matches!(dispatch, scar::typed::TraitDispatch::Pending)
                    || args.iter().any(has_pending_trait_call)
            }
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                has_pending_trait_call(func) || args.iter().any(has_pending_trait_call)
            }
            TypedInner::Block(stmts) => stmts.iter().any(has_pending_trait_call),
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs)
            | TypedInner::FieldAccess(rhs, _) => has_pending_trait_call(rhs),
            TypedInner::DoSafeBind(control) => {
                has_pending_trait_call(&control.rhs)
                    || matches!(&control.failure_target, SafeBindFailureTarget::DoAlternative { empty }
                        if has_pending_trait_call(empty))
                    || has_pending_trait_call(&control.continuation)
            }
            TypedInner::EagerBoundary(inner) => has_pending_trait_call(inner),
            TypedInner::ProcessContextHandler { .. } => false,
            TypedInner::SupervisorSpawn { init, .. } => has_pending_trait_call(init),
            TypedInner::SupervisorAdopt { pid, .. } => has_pending_trait_call(pid),
            TypedInner::SupervisorStatus { .. } => false,
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                has_pending_trait_call(init) || has_pending_trait_call(strategy)
            }
            TypedInner::FacetPath(_) | TypedInner::PendingFacetPath(_) => false,
            TypedInner::FacetView { source, .. } => has_pending_trait_call(source),
            TypedInner::FacetSet { source, value, .. } => {
                has_pending_trait_call(source) || has_pending_trait_call(value)
            }
            TypedInner::FacetOver {
                source, update_fun, ..
            } => has_pending_trait_call(source) || has_pending_trait_call(update_fun),
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right) => {
                has_pending_trait_call(left) || has_pending_trait_call(right)
            }
            TypedInner::TupleLiteral(items)
            | TypedInner::ListLiteral(items)
            | TypedInner::ConstructorCall(_, items)
            | TypedInner::StructLit(_, items) => items.iter().any(has_pending_trait_call),
            TypedInner::HashMapLiteral(entries) => entries
                .iter()
                .any(|(key, value)| has_pending_trait_call(key) || has_pending_trait_call(value)),
            TypedInner::If(cond, then_branch, else_branch) => {
                has_pending_trait_call(cond)
                    || has_pending_trait_call(then_branch)
                    || else_branch.as_deref().is_some_and(has_pending_trait_call)
            }
            TypedInner::Cause(value, err) => {
                has_pending_trait_call(value) || has_pending_trait_call(err)
            }
            TypedInner::Match(scrutinee, arms) => {
                has_pending_trait_call(scrutinee)
                    || arms.iter().any(|arm| {
                        arm.guard.as_ref().is_some_and(has_pending_trait_call)
                            || has_pending_trait_call(&arm.body)
                    })
            }
            TypedInner::InterpolatedStr(parts) => parts.iter().any(|part| match part {
                scar::typed::TypedInterpolatedPart::Text(_) => false,
                scar::typed::TypedInterpolatedPart::Expr(expr) => has_pending_trait_call(expr),
            }),
            TypedInner::Dbg(args) => args.iter().any(|arg| has_pending_trait_call(&arg.expr)),
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body)
            | TypedInner::CaptureConstructorClosure(_, _, _, body) => has_pending_trait_call(body),
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::DeferrorDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..) => false,
        }
    }

    let typed = typecheck_with_builtin_prelude(
        r#"def double(x: $N) -> $N where $N: Add { x + x }
a = double(21)
b = double(1.5)"#,
    );

    let double_defs = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Def(fun_idx, id, ..) if id.name == "double" => Some(*fun_idx),
            _ => None,
        })
        .collect::<Vec<_>>();

    assert_eq!(double_defs.len(), 2);
    assert_ne!(double_defs[0], double_defs[1]);
    assert!(!typed.iter().any(has_pending_trait_call));
}

fn range_duration_comparisons_specialize_without_pending_trait_calls() {
    fn has_pending_trait_call(node: &TypedNode) -> bool {
        match &node.node {
            TypedInner::ErrorConstruct {
                message, payload, ..
            } => has_pending_trait_call(message) || payload.iter().any(has_pending_trait_call),
            TypedInner::TraitCall { dispatch, args, .. } => {
                matches!(dispatch, scar::typed::TraitDispatch::Pending)
                    || args.iter().any(has_pending_trait_call)
            }
            TypedInner::App(func, args)
            | TypedInner::InjectCall(func, args)
            | TypedInner::Capture(func, args) => {
                has_pending_trait_call(func) || args.iter().any(has_pending_trait_call)
            }
            TypedInner::Block(stmts) => stmts.iter().any(has_pending_trait_call),
            TypedInner::Bind(_, rhs)
            | TypedInner::ApplyPattern { value: rhs, .. }
            | TypedInner::SafeBind(_, rhs, _, _)
            | TypedInner::Semi(rhs)
            | TypedInner::FieldAccess(rhs, _) => has_pending_trait_call(rhs),
            TypedInner::DoSafeBind(control) => {
                has_pending_trait_call(&control.rhs)
                    || matches!(&control.failure_target, SafeBindFailureTarget::DoAlternative { empty }
                        if has_pending_trait_call(empty))
                    || has_pending_trait_call(&control.continuation)
            }
            TypedInner::EagerBoundary(inner) => has_pending_trait_call(inner),
            TypedInner::ProcessContextHandler { .. } => false,
            TypedInner::SupervisorSpawn { init, .. } => has_pending_trait_call(init),
            TypedInner::SupervisorAdopt { pid, .. } => has_pending_trait_call(pid),
            TypedInner::SupervisorStatus { .. } => false,
            TypedInner::SupervisorWorkers { init, strategy, .. } => {
                has_pending_trait_call(init) || has_pending_trait_call(strategy)
            }
            TypedInner::FacetPath(_) | TypedInner::PendingFacetPath(_) => false,
            TypedInner::FacetView { source, .. } => has_pending_trait_call(source),
            TypedInner::FacetSet { source, value, .. } => {
                has_pending_trait_call(source) || has_pending_trait_call(value)
            }
            TypedInner::FacetOver {
                source, update_fun, ..
            } => has_pending_trait_call(source) || has_pending_trait_call(update_fun),
            TypedInner::BinOp(_, left, right)
            | TypedInner::Pipe(left, right)
            | TypedInner::Compose(_, left, right)
            | TypedInner::ListCons(left, right) => {
                has_pending_trait_call(left) || has_pending_trait_call(right)
            }
            TypedInner::TupleLiteral(items)
            | TypedInner::ListLiteral(items)
            | TypedInner::ConstructorCall(_, items)
            | TypedInner::StructLit(_, items) => items.iter().any(has_pending_trait_call),
            TypedInner::HashMapLiteral(entries) => entries
                .iter()
                .any(|(key, value)| has_pending_trait_call(key) || has_pending_trait_call(value)),
            TypedInner::If(cond, then_branch, else_branch) => {
                has_pending_trait_call(cond)
                    || has_pending_trait_call(then_branch)
                    || else_branch.as_deref().is_some_and(has_pending_trait_call)
            }
            TypedInner::Cause(value, err) => {
                has_pending_trait_call(value) || has_pending_trait_call(err)
            }
            TypedInner::Match(scrutinee, arms) => {
                has_pending_trait_call(scrutinee)
                    || arms.iter().any(|arm| {
                        arm.guard.as_ref().is_some_and(has_pending_trait_call)
                            || has_pending_trait_call(&arm.body)
                    })
            }
            TypedInner::InterpolatedStr(parts) => parts.iter().any(|part| match part {
                scar::typed::TypedInterpolatedPart::Text(_) => false,
                scar::typed::TypedInterpolatedPart::Expr(expr) => has_pending_trait_call(expr),
            }),
            TypedInner::Dbg(args) => args.iter().any(|arg| has_pending_trait_call(&arg.expr)),
            TypedInner::Def(_, _, _, _, _, _, body, _)
            | TypedInner::ExtractorDef(_, _, _, _, _, body, _)
            | TypedInner::Closure(_, _, body)
            | TypedInner::ExtractorClosure(_, _, body)
            | TypedInner::CaptureClosure(_, _, body)
            | TypedInner::CaptureConstructorClosure(_, _, _, body) => has_pending_trait_call(body),
            TypedInner::Lit(_)
            | TypedInner::ErrorKind(_)
            | TypedInner::Var(_)
            | TypedInner::ListNil
            | TypedInner::DeferrorDef(..)
            | TypedInner::EnumDef(..)
            | TypedInner::TraitDef(..)
            | TypedInner::TraitImplDef(..)
            | TypedInner::BuiltinExtractorDecl(..)
            | TypedInner::StructDef(..)
            | TypedInner::RecordDef(..) => false,
        }
    }

    let typed = typecheck_with_builtin_prelude(
        r#"left = Range(10ms, 20ms)
right = Range(10ms, 30ms)
same = Range(10ms, 20ms)
ordering = compare(left, right)
equal = left == same
different = left != right"#,
    );

    assert!(!typed.iter().any(has_pending_trait_call));
}

fn generic_struct_constructor_calls_remain_polymorphic_within_one_source() {
    let typed = typecheck_with_builtin_prelude(
        r#"defstruct Box<$A> {
  value: $A,
}
impl Box {
  def new(value: $A) -> Box<$A> {
    Box { value: value }
  }
}
a = Box(1)
b = Box(10ms)"#,
    );

    let mut bindings = typed.iter().filter_map(|node| match &node.node {
        TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "a" || id.name == "b") => {
                let TypedPattern::Var(ty, id) = pattern.unlocated() else { unreachable!("binding guard checked"); };
            Some((id.name.as_str(), ty, rhs.as_ref()))
        }
        _ => None,
    });

    let a = bindings.next().expect("expected a binding");
    let b = bindings.next().expect("expected b binding");

    assert_eq!(a.0, "a");
    assert!(matches!(
        a.1,
        Ty::Struct(name, fields)
            if name == "Global::Box"
                && matches!(fields.as_slice(), [(field, Ty::Int)] if field == "value")
    ));
    assert!(matches!(
        a.2.ty,
        Ty::Struct(ref name, ref fields)
            if name == "Global::Box"
                && matches!(fields.as_slice(), [(field, Ty::Int)] if field == "value")
    ));

    assert_eq!(b.0, "b");
    assert!(matches!(
        b.1,
        Ty::Struct(name, fields)
            if name == "Global::Box"
                && matches!(fields.as_slice(), [(field, Ty::Struct(inner, _inner_fields))]
                    if field == "value"
                        && inner == "Duration")
    ));
    assert!(matches!(
        b.2.ty,
        Ty::Struct(ref name, ref fields)
            if name == "Global::Box"
                && matches!(fields.as_slice(), [(field, Ty::Struct(inner, _inner_fields))]
                    if field == "value"
                        && inner == "Duration")
    ));
}

fn generic_struct_constructor_calls_remain_polymorphic_within_closure_body() {
    let typed = typecheck_with_builtin_prelude(
        r#"factory = {||
  raw = Range(3, 1)
  dur = Range(10ms, 20ms)
  (raw, dur)
}"#,
    );

    let factory = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "factory") => Some(rhs),
            _ => None,
        })
        .expect("expected factory binding");

    let TypedInner::Closure(_, _, body) = &factory.node else {
        panic!("expected closure");
    };
    let TypedInner::Block(stmts) = &body.node else {
        panic!("expected closure body block");
    };

    let mut range_bindings = stmts.iter().filter_map(|node| match &node.node {
        TypedInner::Bind(pattern, rhs) if matches!(pattern.unlocated(), TypedPattern::Var(_, id) if id.name == "raw" || id.name == "dur") => {
                let TypedPattern::Var(ty, id) = pattern.unlocated() else { unreachable!("binding guard checked"); };
            Some((id.name.as_str(), ty, rhs.as_ref()))
        }
        _ => None,
    });

    let raw = range_bindings.next().expect("expected raw binding");
    let dur = range_bindings.next().expect("expected dur binding");

    assert_eq!(raw.0, "raw");
    assert!(matches!(
        raw.1,
        Ty::Struct(name, fields)
            if (name == "Range" || name == "Global::Range")
                && matches!(fields.as_slice(), [(min, Ty::Int), (max, Ty::Int)]
                    if min == "min" && max == "max")
    ));
    assert!(matches!(
        raw.2.ty,
        Ty::Struct(ref name, ref fields)
            if (name == "Range" || name == "Global::Range")
                && matches!(fields.as_slice(), [(min, Ty::Int), (max, Ty::Int)]
                    if min == "min" && max == "max")
    ));

    assert_eq!(dur.0, "dur");
    assert!(matches!(
        dur.1,
        Ty::Struct(name, fields)
            if (name == "Range" || name == "Global::Range")
                && matches!(
                    fields.as_slice(),
                    [(min, Ty::Struct(inner_min, _)), (max, Ty::Struct(inner_max, _))]
                        if min == "min"
                            && max == "max"
                            && inner_min == "Duration"
                            && inner_max == "Duration"
                )
    ));
    assert!(matches!(
        dur.2.ty,
        Ty::Struct(ref name, ref fields)
            if (name == "Range" || name == "Global::Range")
                && matches!(
                    fields.as_slice(),
                    [(min, Ty::Struct(inner_min, _)), (max, Ty::Struct(inner_max, _))]
                        if min == "min"
                            && max == "max"
                            && inner_min == "Duration"
                            && inner_max == "Duration"
                )
    ));
}

fn scar_session_preserves_trait_registry_across_chunks() {
    let mut session = session_from_cached_std_prelude();
    let user_resolved = resolve_with_builtin_prelude("value = 1 + 2");
    let typed = session
        .typecheck(user_resolved)
        .expect("trait registry should survive across chunks");

    assert!(typed.iter().any(|node| {
        matches!(
            &node.node,
            TypedInner::Bind(_, rhs)
                if matches!(
                    &rhs.node,
                    TypedInner::TraitCall {
                        method_name,
                        dispatch: scar::typed::TraitDispatch::Static(
                            scar::typed::TraitDispatchTarget::Builtin(id)
                        ),
                        ..
                    } if method_name == "add" && Some(id.0) == sindr::builtin::builtin_id_by_name("__operator_int_add")
                )
        )
    }));
}

fn add_trait_mismatch_retains_typed_signature_relation() {
    let resolved = resolve_with_builtin_prelude("value = Add::add(1, False)");
    let err = typecheck(resolved).expect_err("mismatched add trait call must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentTypeMismatch)
    );
    let data = err.structured.as_ref().unwrap().data_json();
    assert_eq!(data["expected_type"], "Int");
    assert_eq!(data["actual_type"], "Boolean");
}

fn trait_method_call_rejects_named_arguments_without_panic() {
    let resolved = resolve_with_builtin_prelude("value = Add::add(self: 1, rhs: 2)");
    let err = typecheck(resolved).expect_err("named trait method args should fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ArgumentModeMismatch)
    );
}

fn add_trait_missing_receiver_retains_obligation() {
    let resolved = resolve_with_builtin_prelude("value = Add::add(False, True)");
    let err = typecheck(resolved).expect_err("invalid add receiver must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation)
    );
    let data = err.structured.as_ref().unwrap().data_json();
    assert_eq!(data["trait_id"], "Add");
    assert_eq!(data["subject_type"], "Boolean");
}

fn add_operator_missing_impl_retains_obligation() {
    let resolved = resolve_with_builtin_prelude("value = False + True");
    let err = typecheck(resolved).expect_err("invalid add operator must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation)
    );
    let data = err.structured.as_ref().unwrap().data_json();
    assert_eq!(data["trait_id"], "Add");
    assert_eq!(data["subject_type"], "Boolean");
}

fn bind_operator_missing_impl_retains_obligation() {
    let resolved = resolve_with_builtin_prelude("value = 1 |>= {|x| Ok(x)}");
    let err = typecheck(resolved).expect_err("plain lhs bind must fail");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation)
    );
    let data = err.structured.as_ref().unwrap().data_json();
    assert_eq!(data["trait_id"], "Monad");
    assert_eq!(data["subject_type"], "Int");
}

fn to_helper_typechecks_as_generic_trait_call() {
    let typed = typecheck_with_builtin_prelude(r#"value = to::<String>(42)"#);
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            receiver_ty,
            dispatch:
                scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
                    name,
                    ..
                }),
            args,
            ..
        } => {
            assert_eq!(trait_name, "Convert<String>");
            assert_eq!(method_name, "to");
            assert_eq!(name, "Convert<String>::Int::to");
            assert_eq!(receiver_ty, &scar::types::Ty::Int);
            assert_eq!(args.len(), 1);
            assert_eq!(rhs.ty, scar::types::Ty::Str);
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn try_to_helper_typechecks_as_generic_trait_call() {
    let typed = typecheck_with_builtin_prelude(r#"value = try_to::<Int>("42")"#);
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            receiver_ty,
            dispatch:
                scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
                    name,
                    ..
                }),
            args,
            ..
        } => {
            assert_eq!(trait_name, "TryConvert<Int>");
            assert_eq!(method_name, "try_to");
            assert_eq!(name, "TryConvert<Int>::String::try_to");
            assert_eq!(receiver_ty, &scar::types::Ty::Str);
            assert_eq!(args.len(), 1);
            assert!(matches!(rhs.ty, scar::types::Ty::Result(_, _)));
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn conversion_helpers_support_qualified_calls_and_captures() {
    let typed = typecheck_with_builtin_prelude(
        r#"text: String = Convert::to::<String>(42)
parse: (String -> Result<Int>) = &TryConvert::try_to::<Int>
number: Result<Int> = parse("42")"#,
    );
    assert!(!typed.is_empty());
}

fn encode_helper_typechecks_as_generic_trait_call() {
    let typed = typecheck_with_builtin_prelude(r#"value = Encode::encode::<JsonValue>("hello")"#);
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            receiver_ty,
            dispatch:
                scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
                    name,
                    ..
                }),
            args,
            ..
        } => {
            assert_eq!(trait_name, "Encode<JsonValue>");
            assert_eq!(method_name, "encode");
            assert_eq!(name, "Encode<JsonValue>::String::encode");
            assert_eq!(receiver_ty, &scar::types::Ty::Str);
            assert_eq!(args.len(), 1);
            assert!(matches!(rhs.ty, scar::types::Ty::Result(_, _)));
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn json_value_encode_source_alias_typechecks() {
    let typed = typecheck_with_builtin_prelude(r#"value = JsonValue::encode("hello")"#);
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    assert!(matches!(rhs.ty, scar::types::Ty::Result(_, _)));
}

fn decode_helper_typechecks_explicit_target() {
    let typed = typecheck_with_builtin_prelude(
        r#"value = Decode::decode::<String>(JsonValue::String("ok"))"#,
    );
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            receiver_ty,
            dispatch:
                scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
                    name,
                    ..
                }),
            args,
            ..
        } => {
            assert_eq!(trait_name, "Decode<String>");
            assert_eq!(method_name, "decode");
            assert_eq!(name, "Decode<String>::JsonValue::decode");
            assert!(
                matches!(receiver_ty, scar::types::Ty::Enum(name, _) if name.ends_with("JsonValue"))
            );
            assert_eq!(args.len(), 1);
            assert!(matches!(rhs.ty, scar::types::Ty::Result(_, _)));
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn decode_helper_inside_decode_impl_dispatches_by_receiver_and_target() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord JsonSpecConfig(name: String, entrypoint: String)

impl Decode<JsonSpecConfig> for JsonValue {
  def decode::<JsonSpecConfig>(self: Self) -> Result<JsonSpecConfig, Error> {
    name_json =? Json::get(self, "name")
    name =? Decode::decode::<String>(name_json)
    entry_json =? Json::get(self, "entrypoint")
    entry =? entry_json |> Decode::decode::<String>
    Ok(JsonSpecConfig(name, entry))
  }
}

cfg = Decode::decode::<JsonSpecConfig>(JsonValue::Null)"#,
    );
    let mut calls = Vec::new();
    for node in &typed {
        collect_decode_trait_calls(node, &mut calls);
    }
    let string_decode_calls = calls
        .iter()
        .filter(|(trait_name, dispatch_name)| {
            trait_name.as_str() == "Decode<String>"
                && dispatch_name
                    .as_deref()
                    .is_some_and(|name| name.ends_with("JsonValue::decode"))
        })
        .count();
    assert_eq!(
        string_decode_calls, 2,
        "nested direct and pipeline decode calls should dispatch to String decoder: {calls:?}"
    );
    assert!(
        calls.iter().any(|(trait_name, dispatch_name)| {
            trait_name.as_str() == "Decode<JsonSpecConfig>"
                && dispatch_name
                    .as_deref()
                    .is_some_and(|name| name.ends_with("JsonValue::decode"))
        }),
        "custom Config decoder should still be registered as its own dispatch target: {calls:?}"
    );
}

fn decode_helper_allows_same_pattern_recursive_dispatch() {
    typecheck_with_builtin_prelude(
        r#"defrecord JsonSpecRecursive(value: String)

impl Decode<JsonSpecRecursive> for JsonValue {
  def decode::<JsonSpecRecursive>(self: Self) -> Result<JsonSpecRecursive, Error> {
    Decode::decode::<JsonSpecRecursive>(self)
  }
}"#,
    );
}

fn encode_helper_dispatches_to_receiver_impl_with_json_value_target() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord JsonSpecConfig(name: String, entrypoint: String)

impl Encode<JsonValue> for JsonSpecConfig {
  def encode::<JsonValue>(self: Self) -> Result<JsonValue, Error> {
    Ok(JsonValue::String(self.name))
  }
}

json = Encode::encode::<JsonValue>(JsonSpecConfig("surtr", "boot"))"#,
    );
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    match &rhs.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            dispatch:
                scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
                    name,
                    ..
                }),
            args,
            ..
        } => {
            assert_eq!(trait_name, "Encode<JsonValue>");
            assert_eq!(method_name, "encode");
            assert_eq!(name, "Encode<JsonValue>::Global::JsonSpecConfig::encode");
            assert_eq!(args.len(), 1);
        }
        other => panic!("expected trait call, got {:?}", other),
    }
}

fn encode_helper_allows_same_pattern_recursive_dispatch() {
    typecheck_with_builtin_prelude(
        r#"defrecord JsonSpecRecursive(value: String)

impl Encode<JsonValue> for JsonSpecRecursive {
  def encode::<JsonValue>(self: Self) -> Result<JsonValue, Error> {
    Encode::encode::<JsonValue>(self)
  }
}"#,
    );
}

fn collect_decode_trait_calls(node: &TypedNode, calls: &mut Vec<(String, Option<String>)>) {
    match &node.node {
        TypedInner::TraitCall {
            trait_name,
            method_name,
            dispatch,
            args,
            ..
        } => {
            if method_name == "decode" {
                calls.push((trait_name.clone(), trait_dispatch_name(dispatch)));
            }
            for arg in args {
                collect_decode_trait_calls(arg, calls);
            }
        }
        TypedInner::App(func, args) | TypedInner::InjectCall(func, args) => {
            collect_decode_trait_calls(func, calls);
            for arg in args {
                collect_decode_trait_calls(arg, calls);
            }
        }
        TypedInner::Block(stmts) => {
            for stmt in stmts {
                collect_decode_trait_calls(stmt, calls);
            }
        }
        TypedInner::Bind(_, rhs)
        | TypedInner::ApplyPattern { value: rhs, .. }
        | TypedInner::SafeBind(_, rhs, _, _) => {
            collect_decode_trait_calls(rhs, calls);
        }
        TypedInner::Def(_, _, _, _, _, _, body, _)
        | TypedInner::ExtractorDef(_, _, _, _, _, body, _) => {
            collect_decode_trait_calls(body, calls);
        }
        TypedInner::Closure(_, _, body)
        | TypedInner::Semi(body)
        | TypedInner::FieldAccess(body, _) => {
            collect_decode_trait_calls(body, calls);
        }
        TypedInner::Pipe(left, right)
        | TypedInner::BinOp(_, left, right)
        | TypedInner::Compose(_, left, right)
        | TypedInner::ListCons(left, right) => {
            collect_decode_trait_calls(left, calls);
            collect_decode_trait_calls(right, calls);
        }
        TypedInner::ConstructorCall(_, args)
        | TypedInner::ListLiteral(args)
        | TypedInner::TupleLiteral(args) => {
            for arg in args {
                collect_decode_trait_calls(arg, calls);
            }
        }
        TypedInner::If(cond, then_branch, else_branch) => {
            collect_decode_trait_calls(cond, calls);
            collect_decode_trait_calls(then_branch, calls);
            if let Some(else_branch) = else_branch {
                collect_decode_trait_calls(else_branch, calls);
            }
        }
        _ => {}
    }
}

fn trait_dispatch_name(dispatch: &scar::typed::TraitDispatch) -> Option<String> {
    match dispatch {
        scar::typed::TraitDispatch::Static(scar::typed::TraitDispatchTarget::UserFunction {
            name,
            ..
        }) => Some(name.clone()),
        _ => None,
    }
}

fn to_helper_suggests_try_to_when_only_fallible_impl_exists() {
    let resolved = resolve_with_builtin_prelude(r#"value = to::<Int>("42")"#);
    let err = typecheck(resolved).expect_err("to on fallible conversion must fail");
    assert!(err
        .hint
        .as_ref()
        .expect("conversion remediation")
        .contains("String -> Int implements TryConvert, not Convert"));
    assert!(err
        .hint
        .as_ref()
        .unwrap()
        .contains("Use try_to::<Int>(value)."));
}

fn try_to_helper_suggests_to_when_only_infallible_impl_exists() {
    let resolved = resolve_with_builtin_prelude(r#"value = try_to::<String>(42)"#);
    let err = typecheck(resolved).expect_err("try_to on infallible conversion must fail");
    assert!(err
        .hint
        .as_ref()
        .expect("conversion remediation")
        .contains("Int -> String implements Convert, not TryConvert"));
    assert!(err
        .hint
        .as_ref()
        .unwrap()
        .contains("Use to::<String>(value)."));
}

fn to_and_try_to_impls_are_mutually_exclusive() {
    let string_source = format!(
        "{}\nimpl Convert<Int> for String {{\n  def to::<Int>(self: Self) -> Int {{ 0 }}\n}}",
        include_str!("../../../lib/types/string.srt")
    );
    let overrides = [("String", string_source.as_str())];

    let err = typecheck_std_modules_with_overrides(&overrides)
        .expect_err("conflicting Convert/TryConvert impls must fail");
    assert!(err
        .message
        .contains("Convert and TryConvert cannot both be implemented for String -> Int"));
}

fn process_sleep_accepts_duration_literal() {
    let typed = typecheck_with_builtin_prelude(r#"value = Process::sleep(100ms)"#);
    let rhs = typed
        .iter()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("bind rhs should exist");
    assert!(matches!(rhs.ty, scar::types::Ty::Result(_, _)));
}

fn process_self_is_rejected_outside_process_context() {
    let resolved = resolve_with_builtin_prelude(r#"pid = Process::self()"#);
    let err = typecheck(resolved).expect_err("Process::self outside process must fail");
    assert!(err.message.contains("Process::self"));
}

fn process_self_typechecks_inside_process_handler() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<PID<Counter>> {
    Ok(Process::self())
  }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        Vec::new(),
        &declaration_index,
        None,
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("Process::self should typecheck inside process handler");
}

fn singleton_agent_pid_surface_returns_concrete_pid() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let user_ast =
        spire::parse_with_context("pid = Counter::pid()", spire::ParserContext::project(0))
            .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    let typed = typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("typecheck should succeed");
    let rhs = typed
        .nodes
        .iter()
        .rev()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected pid binding");
    match &rhs.ty {
        Ty::Pid(marker) => assert_eq!(
            marker.as_ref(),
            &Ty::ProcessMarker("Global::Counter".into())
        ),
        other => panic!("expected PID<Counter>, got {other:?}"),
    }
}

fn singleton_genserver_pid_surface_returns_concrete_pid() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defgenserver QueueServer {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def size(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let user_ast =
        spire::parse_with_context("pid = QueueServer::pid()", spire::ParserContext::project(0))
            .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    let typed = typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("typecheck should succeed");
    let rhs = typed
        .nodes
        .iter()
        .rev()
        .find_map(|node| match &node.node {
            TypedInner::Bind(_, rhs) => Some(rhs.as_ref()),
            _ => None,
        })
        .expect("expected pid binding");
    match &rhs.ty {
        Ty::Pid(marker) => assert_eq!(
            marker.as_ref(),
            &Ty::ProcessMarker("Global::QueueServer".into())
        ),
        other => panic!("expected PID<QueueServer>, got {other:?}"),
    }
}

fn singleton_agent_explicit_pid_call_typechecks() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let user_ast = spire::parse_with_context(
        r#"pid = Counter::pid()
value =? Counter::get(pid, "count")
done =? Counter::set(pid, 1)"#,
        spire::ParserContext::project(0),
    )
    .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("singleton explicit pid-first agent surface should typecheck");
}

fn genserver_additional_call_handler_typechecks_as_process_context() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defgenserver Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
    handlers {
      out: OutHandler = StdOut
    }
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def info(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }

  @call
  def log(state: Int, message: String) -> Result<CallResult<Unit, Int>> {
    _handler = ctx.out
    _message = message
    Ok(CallResult::Reply((), state))
  }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let user_ast = spire::parse_with_context(
        r#"supervisor_init {
  Logger {}
}
info = Logger::info()
done = Logger::log("hello")"#,
        spire::ParserContext::project(0),
    )
    .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("additional @call handler should have process context access");
}

fn genserver_call_handler_accepts_call_result_contract() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defgenserver Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def info(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }

  @cast
  def reset(_state: Int, next: Int) -> Result<CastResult<Int>> {
    Ok(CastResult::Next(next))
  }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        Vec::new(),
        &declaration_index,
        None,
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("CallResult/CastResult handlers should typecheck");
}

fn process_meta_state_mismatch_is_rejected() {
    let mut stages = std_module_stages();
    stages.push(vec![staged_process_module(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: String) -> Result<Int> { Ok(0) }
}"#,
    )]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        Vec::new(),
        &declaration_index,
        None,
    )
    .expect("resolve should succeed");
    let err = typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect_err("meta.state mismatch should fail");

    assert!(err.message.contains(
        "@get handler `Counter::get` first parameter must match process state type `Int`"
    ));
}

fn user_defined_process_state_can_appear_in_public_signatures() {
    let user_ast = spire::parse_with_context(
        r#"defstruct CounterState {
  value: Int,
}

impl CounterState {
  def new(value: Int) -> Self {
    CounterState { value: value }
  }
}

defmod Helper {
  def expose(state: CounterState) -> CounterState {
    state
  }
}"#,
        spire::ParserContext::module(0, None),
    )
    .expect("source should parse");
    let mut stages = std_module_stages();
    let mut user_modules = Vec::new();
    let mut global_ast = Vec::new();
    for stmt in user_ast {
        match stmt {
            spire::ast::Ast::Defmod(span, module_path, ast, attrs) => {
                user_modules.push(sigil::StagedModuleAst {
                    source_index: 0,
                    owner: Some(sigil::OwnerDescriptor::new(
                        module_path.clone(),
                        span,
                        sigil::OwnerSourceForm::Defmod,
                    )),
                    module_path,
                    doc_module_path: None,
                    ast,
                    module_doc: attrs.doc,
                    auto_import: attrs.auto_import,
                    process_spec: None,
                });
            }
            other => global_ast.push(other),
        }
    }
    if !global_ast.is_empty() {
        user_modules.push(sigil::StagedModuleAst {
            source_index: 0,
            module_path: String::new(),
            doc_module_path: None,
            ast: global_ast,
            owner: None,
            module_doc: None,
            auto_import: false,
            process_spec: None,
        });
    }
    user_modules.push(staged_process_module(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: CounterState
  }

  @init
  def init() -> Result<CounterState> { Ok(CounterState::new(0)) }

  @get
  def get(state: CounterState) -> Result<CounterState> { Ok(state) }
}"#,
    ));
    stages.push(user_modules);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        Vec::new(),
        &declaration_index,
        None,
    )
    .expect("resolve should succeed");

    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("user-defined process state should be allowed in public signatures");
}

fn typecheck_staged_program_keeps_process_specs() {
    let ast = spire::parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        spire::ParserContext::module(0, Some("Counter".to_string())),
    )
    .expect("defagent source should parse");

    let staged_module = match ast.into_iter().next().expect("lowered module should exist") {
        spire::ast::Ast::Defagent(span, module_path, ast, process_spec, attrs) => {
            sigil::StagedModuleAst {
                source_index: 0,
                owner: Some(sigil::OwnerDescriptor::new(
                    module_path.clone(),
                    span,
                    sigil::OwnerSourceForm::Defagent,
                )),
                module_path,
                doc_module_path: None,
                ast,
                module_doc: attrs.doc,
                auto_import: attrs.auto_import,
                process_spec: Some(process_spec),
            }
        }
        other => panic!("expected defagent, got {other:?}"),
    };

    let mut stages = std_module_stages();
    stages.push(vec![staged_module]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        Vec::new(),
        &declaration_index,
        None,
    )
    .expect("resolve should succeed");
    let typed: TypedProgram = typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
        .expect("typecheck should succeed");

    assert_eq!(typed.process_specs.len(), 2);
    let spec = typed
        .process_specs
        .iter()
        .find(|spec| spec.process_name == "Counter" || spec.process_name == "Global::Counter")
        .expect("Counter process spec should exist");
    assert!(spec.module_path == "Counter" || spec.module_path == "Global::Counter");
    assert!(spec.process_name == "Counter" || spec.process_name == "Global::Counter");
    assert!(!spec.spec.boot);
}

fn staged_process_module(source: &str) -> sigil::StagedModuleAst {
    let ast = spire::parse_with_context(source, spire::ParserContext::module(0, None))
        .expect("process source should parse");
    match ast
        .into_iter()
        .next()
        .expect("lowered process should exist")
    {
        spire::ast::Ast::Defagent(span, module_path, ast, process_spec, attrs)
        | spire::ast::Ast::Defgenserver(span, module_path, ast, process_spec, attrs)
        | spire::ast::Ast::Defsupervisor(span, module_path, ast, process_spec, attrs) => {
            let source_form = match process_spec.kind {
                spire::ast::ProcessKind::Agent => sigil::OwnerSourceForm::Defagent,
                spire::ast::ProcessKind::GenServer => sigil::OwnerSourceForm::Defgenserver,
                spire::ast::ProcessKind::Supervisor
                | spire::ast::ProcessKind::RuntimeSupervisor => {
                    sigil::OwnerSourceForm::Defsupervisor
                }
                spire::ast::ProcessKind::DynamicSupervisor => {
                    sigil::OwnerSourceForm::DefdynamicSupervisor
                }
                spire::ast::ProcessKind::Task => sigil::OwnerSourceForm::Defagent,
            };
            sigil::StagedModuleAst {
                source_index: 0,
                owner: Some(sigil::OwnerDescriptor::new(
                    module_path.clone(),
                    span,
                    source_form,
                )),
                module_path,
                doc_module_path: None,
                ast,
                module_doc: attrs.doc,
                auto_import: attrs.auto_import,
                process_spec: Some(process_spec),
            }
        }
        other => panic!("expected process module, got {other:?}"),
    }
}

fn typecheck_supervisor_spawn_fixture(
    script: &str,
) -> Result<TypedProgram, scar::error::TypeError> {
    let mut stages = std_module_stages();
    stages.push(vec![
        staged_process_module(
            r#"defagent MyWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ),
        staged_process_module(
            r#"defsupervisor MySup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }
}"#,
        ),
        staged_process_module(
            r#"defsupervisor LockedSup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Temporary
    allow_adopt: False
  }
}"#,
        ),
    ]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let project_source = format!(
        r#"supervisor_init {{
  MySup {{}}
  LockedSup {{}}
  DynamicSupervisor {{}}
}}

{script}"#
    );
    let user_ast = spire::parse_with_context(&project_source, spire::ParserContext::project(0))
        .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
}

fn typecheck_supervisor_pool_fixture(
    pool_source: &str,
) -> Result<TypedProgram, scar::error::TypeError> {
    let mut stages = std_module_stages();
    stages.push(vec![
        staged_process_module(
            r#"defagent MyWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        ),
        staged_process_module(
            r#"defsupervisor MySup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }
}"#,
        ),
        staged_process_module(pool_source),
    ]);
    let declaration_index =
        sigil::precollect_declaration_index(&stages).expect("precollect should succeed");
    let user_ast = spire::parse_with_context(
        r#"supervisor_init {
  MySup {}
  MyPool {}
}"#,
        spire::ParserContext::project(0),
    )
    .expect("script should parse");
    let resolved = resolve_staged_program_suffix_with_builtin_prelude(
        &stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect("resolve should succeed");
    typecheck_resolved_program_suffix_with_builtin_prelude(resolved)
}

fn dynsup_spawn_accepts_worker_init_route_reference() {
    let typed =
        typecheck_supervisor_spawn_fixture(r#"pid = DynamicSupervisor::spawn(MyWorker::init(1))"#)
            .expect("DynSup spawn should typecheck");
    assert!(!typed.nodes.is_empty());
}

fn custom_supervisor_spawn_accepts_worker_init_route_reference() {
    let typed = typecheck_supervisor_spawn_fixture(r#"pid = MySup::spawn(MyWorker::init(1))"#)
        .expect("custom supervisor spawn should typecheck");
    assert!(!typed.nodes.is_empty());
}

fn supervisor_spawn_rejects_plain_closure_argument() {
    let err = typecheck_supervisor_spawn_fixture(r#"pid = MySup::spawn({|| Ok(1)})"#)
        .expect_err("plain closure should be rejected");
    assert!(err.message.contains("worker init"));
}

fn supervisor_spawn_rejects_non_worker_callable() {
    let err = typecheck_supervisor_spawn_fixture(r#"pid = MySup::spawn(MySup::status())"#)
        .expect_err("non-worker callable should be rejected");
    assert!(err.message.contains("worker init"));
}

fn supervisor_adopt_accepts_worker_pid() {
    let typed = typecheck_supervisor_spawn_fixture(
        r#"pid =? MySup::spawn(MyWorker::init(1))
_ =? MySup::adopt(pid)"#,
    )
    .expect("adopt should typecheck");
    assert!(!typed.nodes.is_empty());
}

fn supervisor_adopt_rejects_non_pid_argument() {
    let err = typecheck_supervisor_spawn_fixture(r#"_ =? MySup::adopt(1)"#)
        .expect_err("adopt should reject non pid");
    assert!(err.message.contains("PID"));
}

fn supervisor_adopt_rejects_when_policy_disallows_it() {
    let err = typecheck_supervisor_spawn_fixture(
        r#"pid =? MySup::spawn(MyWorker::init(1))
_ =? LockedSup::adopt(pid)"#,
    )
    .expect_err("adopt should respect allow_adopt");
    assert!(err.message.contains("allow_adopt"));
}

fn supervisor_status_returns_supervisor_status() {
    let typed = typecheck_supervisor_spawn_fixture(r#"status =? MySup::status()"#)
        .expect("status should typecheck");
    assert!(!typed.nodes.is_empty());
}

fn supervisor_workers_returns_workers_handle() {
    let typed = typecheck_supervisor_pool_fixture(
        r#"defgenserver MyPool {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Workers<MyWorker>
  }

  @init
  def init() -> Result<Workers<MyWorker>> {
    MySup::workers(MyWorker::init(1), WorkerStrategy::fixed(2))
  }

  @call
  def count(workers: Workers<MyWorker>) -> Result<CallResult<Int, Workers<MyWorker>>> {
    Ok(CallResult::Reply(Workers::size(workers), workers))
  }
}"#,
    )
    .expect("workers creation should typecheck");
    assert!(!typed.nodes.is_empty());
}

fn workers_submit_accepts_worker_message_template() {
    let typed = typecheck_supervisor_pool_fixture(
        r#"defgenserver MyPool {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Workers<MyWorker>
  }

  @init
  def init() -> Result<Workers<MyWorker>> {
    MySup::workers(MyWorker::init(1), WorkerStrategy::fixed(2))
  }

  @call
  def count(workers: Workers<MyWorker>) -> Result<CallResult<Int, Workers<MyWorker>>> {
    Ok(CallResult::Reply(Workers::size(workers), workers))
  }

  @cast
  def submit(workers: Workers<MyWorker>) -> Result<CastResult<Workers<MyWorker>>> {
    _ =? Workers::submit(workers, MyWorker::set(3))
    Ok(CastResult::Next(workers))
  }
}"#,
    )
    .expect("workers submit should accept worker message template");
    assert!(!typed.nodes.is_empty());
}

fn workers_broadcast_accepts_worker_message_template() {
    let typed = typecheck_supervisor_pool_fixture(
        r#"defgenserver MyPool {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Workers<MyWorker>
  }

  @init
  def init() -> Result<Workers<MyWorker>> {
    MySup::workers(MyWorker::init(1), WorkerStrategy::fixed(2))
  }

  @call
  def values(workers: Workers<MyWorker>) -> Result<CallResult<List<Result<Int>>, Workers<MyWorker>>> {
    Ok(CallResult::Reply(Workers::broadcast(workers, MyWorker::get("jobs")), workers))
  }
}"#,
    )
    .expect("workers broadcast should accept worker message template");
    assert!(!typed.nodes.is_empty());
}

fn task_await_accepts_task_handle() {
    let typed = typecheck_with_builtin_prelude(
        r#"task = Task::async({|| Ok("ready")})
value =? Task::await(task)"#,
    );
    assert!(!typed.is_empty());
}

fn workers_reserve_can_flow_into_worker_call() {
    let typed = typecheck_supervisor_pool_fixture(
        r#"defgenserver MyPool {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Workers<MyWorker>
  }

  @init
  def init() -> Result<Workers<MyWorker>> {
    MySup::workers(MyWorker::init(1), WorkerStrategy::fixed(2))
  }

  @call
  def reserve_set(workers: Workers<MyWorker>) -> Result<CallResult<Unit, Workers<MyWorker>>> {
    lease =? Workers::reserve(workers)
    _ =? MyWorker::set(lease, 9)
    Ok(CallResult::Reply((), workers))
  }
}"#,
    )
    .expect("workers reserve should typecheck as worker capability");
    assert!(!typed.nodes.is_empty());
}

fn tap_err_accepts_local_error_observer_binding() {
    let typed = typecheck_with_builtin_prelude(
        r#"handler = {|err| eprint(err)}
value = Result::tap_err(Err(NoneError()), handler)"#,
    );
    assert!(!typed.is_empty());
}

fn tap_err_accepts_error_observer_captures_and_composition() {
    let typed = typecheck_with_builtin_prelude(
        r#"logged = Result::tap_err(Err(NoneError()), &eprint)
named = Result::tap_err(Err(NoneError()), &Error::kind >> &print)"#,
    );
    assert!(!typed.is_empty());
}

fn error_observer_binding_can_escape_as_plain_value() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler = {|err| eprint(err)}
escaped = handler"#,
    );
    typecheck(resolved).expect("Error callbacks follow ordinary callable rules");
}

fn error_observer_binding_can_be_called_directly() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler = {|err| eprint(err)}
value = match Err(NoneError()) {
  Ok(_) => (),
  Err(err) => handler(err),
}"#,
    );
    typecheck(resolved).expect("Error callbacks follow ordinary callable rules");
}

fn error_observer_binding_can_use_error_annotation() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler: (Error -> Unit) = {|err| eprint(err)}
value = Result::tap_err(Err(NoneError()), handler)"#,
    );
    typecheck(resolved).expect("Error callbacks follow ordinary callable rules");
}

fn error_observer_closure_param_can_use_error_annotation() {
    let resolved = resolve_with_builtin_prelude(
        r#"handler = {|err: Error| eprint(err)}
value = Result::tap_err(Err(NoneError()), handler)"#,
    );
    typecheck(resolved).expect("Error callbacks follow ordinary callable rules");
}

fn error_observer_binding_can_flow_through_generic_identity() {
    let resolved = resolve_with_builtin_prelude(
        r#"def id(value: $A) -> $A { value }
handler = {|err| eprint(err)}
value = Result::tap_err(Err(NoneError()), id(handler))"#,
    );
    typecheck(resolved).expect("Error callbacks follow ordinary callable rules");
}

fn explicit_type_arguments_specialize_functions_trait_calls_and_captures() {
    let typed = typecheck_with_builtin_prelude(
        r#"deftrait Transform<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl Transform<Int> for String {
  def convert::<Int>(self: String) -> Int { 1 }
}

converted: Int = Transform::convert::<Int>("")
convert_fn: (String -> Int) = &Transform::convert::<Int>
again: Int = convert_fn("")"#,
    );
    assert!(!typed.is_empty());
}

fn enum_constructor_partial_type_arguments_constrain_only_their_own_slots() {
    typecheck_with_standard_environment(
        r#"defenum FixtureEither<$L, $R> { Left($L), Right($R), Pair($L, $R) }
defenum Maybe<$T> { Some($T), None }
def generic_none::<$T>() -> Maybe<$T> { Maybe<$T>::None }
left_text: FixtureEither<String, Int> = FixtureEither<_, Int>::Left("term")
left_int: FixtureEither<Int, Int> = FixtureEither<_, Int>::Left(1)
none: FixtureEither<Int, String> = FixtureEither<Int, _>::Right("none")
pair: FixtureEither<String, Int> = FixtureEither<_, _>::Pair("pair", 2)
generic: Maybe<String> = generic_none::<String>()"#,
    )
    .expect("payload and expected type should infer only constructor `_` slots");

    let mismatch = typecheck_with_standard_environment(
        r#"defenum FixtureEither<$L, $R> { Left($L), Right($R) }
bad = FixtureEither<String, Int>::Left(1)"#,
    )
    .expect_err("an explicit constructor type argument must remain fixed");
    assert!(mismatch.message.contains("String"), "{mismatch:?}");

    let rigid = typecheck_with_standard_environment(
        r#"defenum Maybe<$T> { Some($T), None }
def bad::<$T>() -> Maybe<$T> { Maybe<$T>::Some(1) }"#,
    )
    .expect_err("a scope type variable supplied explicitly must remain rigid");
    assert!(
        rigid.message.contains("$T") || rigid.message.contains("Int"),
        "{rigid:?}"
    );

    let annotation = typecheck_with_standard_environment(
        r#"defenum FixtureEither<$L, $R> { Left($L), Right($R) }
bad: FixtureEither<_, Int> = FixtureEither::Left("term")"#,
    )
    .expect_err("`_` must remain unavailable in ordinary annotations");
    assert!(
        annotation.message.contains("`_` is only allowed"),
        "{annotation:?}"
    );

    let closure_payload = typecheck_with_builtin_prelude(
        r#"mapper: (Unit -> Option<(Int -> Int)>) = {|_| Option<_>::Some({|x| x + 1})}"#,
    );
    assert!(!closure_payload.is_empty());

    typecheck_with_rules("value = Option<Error>::None", RuntimeSourcePolicy::script())
        .expect("Error is an ordinary enum type argument");

    let result_nodes = typecheck_with_rules(
        r#"ok: Result<Int> = Result<Int>::Ok(1)
err: Result<Int> = Result<Int>::Err(NoneError())"#,
        RuntimeSourcePolicy::script(),
    )
    .expect(
        "qualified Result constructors should retain Result lowering and explicit success type",
    );
    for node in result_nodes.iter().rev().take(2) {
        let TypedInner::Bind(_, rhs) = &node.node else {
            panic!("expected Result constructor binding, got {:?}", node.node);
        };
        let TypedInner::ConstructorCall(_, fields) = &rhs.node else {
            panic!("expected Result constructor lowering, got {:?}", rhs.node);
        };
        assert_eq!(
            fields.len(),
            1,
            "Result runtime representation has one payload"
        );
    }

    let bare_err = typecheck_with_rules("err = Err(NoneError())", RuntimeSourcePolicy::script())
        .expect("a bare Err constructor may leave its success type to surrounding inference");
    assert!(!bare_err.is_empty());

    let invalid_err =
        typecheck_with_rules("err = Result<Int>::Err(1)", RuntimeSourcePolicy::script())
            .expect_err("an explicit Result constructor must retain the concrete Error constraint");
    assert!(
        invalid_err.message.contains("requires an Error value"),
        "{invalid_err:?}"
    );

    let constructor_trait = typecheck_with_rules(
        r#"deftrait FunctorShape
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}
defenum Maybe<$T> { Some($T), None }
value = Maybe<FunctorShape>::None"#,
        RuntimeSourcePolicy::script(),
    )
    .expect_err("a TypeConstructor trait must not become an ordinary enum value type");
    assert!(
        constructor_trait
            .message
            .contains("Unknown type: FunctorShape"),
        "{constructor_trait:?}"
    );
}

fn regular_callable_rejects_undeclared_return_type_arguments() {
    let resolved = resolve_with_builtin_prelude(
        r#"def identity(value: $A) -> $A { value }
bad: Int = identity::<Int>(1)"#,
    );
    let err = typecheck(resolved)
        .expect_err("a regular callable without RTA declarations must reject explicit RTA");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::ReturnTypeArgumentArityMismatch),
        "{err:?}"
    );
}

fn bare_trait_capability_controls_full_parameterized_dispatch() {
    let missing = r#"deftrait FixtureConvert<$To> {
  def convert::<$To>(self: Self) -> $To
}

def hidden(value: $A) -> Int {
  FixtureConvert::convert::<Int>(value)
}"#;
    let err = typecheck_with_standard_environment(missing)
        .expect_err("missing bare capability must be rejected");
    assert!(err.message.contains("MissingGenericBound"), "{err:?}");
    assert!(
        err.message
            .contains("$A must implement FixtureConvert<Int>"),
        "{err:?}"
    );

    let bounded = r#"deftrait FixtureConvert<$To> {
  def convert::<$To>(self: Self) -> $To
}

def hidden(value: $A) -> Int
where
  $A: FixtureConvert
{
  FixtureConvert::convert::<Int>(value)
}"#;
    typecheck_with_standard_environment(bounded)
        .expect("bare capability must permit a full parameterized dispatch");
}

fn trait_heads_and_expression_obligations_retain_nested_arguments() {
    let source = r#"deftrait Marker<$Tag> {
  def mark::<$Tag>(self: Self) -> $Tag
}

impl Marker<List<Int>> for String {
  def mark::<List<Int>>(self: String) -> List<Int> { [1] }
}

def mark_list(value: $A) -> List<Int>
where
  $A: Marker
{
  Marker::mark::<List<Int>>(value)
}

result: List<Int> = mark_list("ok")"#;
    typecheck_with_standard_environment(source)
        .expect("trait-head and expression arguments must stay structural");
}

fn impl_bare_capabilities_emit_full_parameterized_obligations() {
    let satisfied = r#"deftrait Marker<$Tag> {
  def mark::<$Tag>(self: Self) -> $Tag
}

deftrait Use {
  def use(self: Self) -> Int
}

defenum Box<$A> {
  Box($A),
}

impl Marker<Int> for Int {
  def mark::<Int>(self: Int) -> Int { self }
}

impl Use for Box<$A>
where
  $A: Marker
{
  def use(self: Box<$A>) -> Int {
    match self { Box::Box(value) => Marker::mark::<Int>(value) }
  }
}

value: Box<Int> = Box::Box(1)
result = Use::use(value)"#;
    typecheck_with_standard_environment(satisfied)
        .expect("the full expression obligation must be proved");

    let mismatched = r#"deftrait Marker<$Tag> {
  def mark::<$Tag>(self: Self) -> $Tag
}

deftrait Use {
  def use(self: Self) -> Int
}

defenum Box<$A> {
  Box($A),
}

impl Marker<String> for Int {
  def mark::<String>(self: Int) -> String { "string" }
}

impl Use for Box<$A>
where
  $A: Marker
{
  def use(self: Box<$A>) -> Int {
    match self { Box::Box(value) => Marker::mark::<Int>(value) }
  }
}

value: Box<Int> = Box::Box(1)
result = Use::use(value)"#;
    let err = typecheck_with_standard_environment(mismatched)
        .expect_err("a same-name trait with different arguments must not prove an obligation");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::NoApplicableTraitImplementation),
        "{err:?}"
    );
    assert!(err.message.contains("Box<Int>"), "{err:?}");

    let generic = r#"deftrait Marker<$Tag> {
  def mark::<$Tag>(self: Self) -> $Tag
}

deftrait Use {
  def use(self: Self) -> String
}

defenum Box<$A> {
  Box($A),
}

defenum Tagged<$Tag> {
  Tagged($Tag),
}

impl Marker<$Tag> for Tagged<$Tag> {
  def mark::<$Tag>(self: Tagged<$Tag>) -> $Tag {
    match self { Tagged::Tagged(value) => value }
  }
}

impl Use for Box<$A>
where
  $A: Marker
{
  def use(self: Box<$A>) -> String {
    match self { Box::Box(value) => Marker::mark::<String>(value) }
  }
}

value: Box<Tagged<String>> = Box::Box(Tagged::Tagged("generic"))
result = Use::use(value)"#;
    typecheck_with_standard_environment(generic)
        .expect("a generic trait argument must unify with the requested argument");
}

fn explicit_type_arguments_exclude_self_and_enforce_generic_arity() {
    let resolved =
        resolve_with_builtin_prelude(r#"value = Concat::concat::<String>("left", "right")"#);
    let err = typecheck(resolved).expect_err("Self must not be supplied as an explicit type input");
    assert!(
        err.message
            .contains("Concat::concat expects 0 return type argument(s), got 1"),
        "{err:?}"
    );

    let resolved =
        resolve_with_builtin_prelude(r#"value = TryConvert::try_to::<Int, String>("1")"#);
    let err = typecheck(resolved).expect_err("trait generics must use their declared arity");
    assert!(
        err.message
            .contains("TryConvert::try_to expects 1 return type argument(s), got 2"),
        "{err:?}"
    );
}

fn trait_method_type_slots_have_one_input_channel_and_return_type_arguments_flow_to_return() {
    let duplicated = resolve_with_builtin_prelude(
        r#"deftrait DuplicateInput {
  def duplicate::<$A>(value: $A) -> $A
}"#,
    );
    let err = typecheck(duplicated).expect_err("a slot cannot use both input channels");
    assert!(
        err.message
            .contains("type input `$A` is introduced more than once"),
        "{err:?}"
    );

    let unconsumed_return_type_argument = resolve_with_builtin_prelude(
        r#"deftrait UnconsumedReturnTypeArgument<$A> {
  def render::<$A>(self: Self) -> String
}"#,
    );
    let err = typecheck(unconsumed_return_type_argument)
        .expect_err("a ReturnTypeArguments slot must be represented by the return type");
    assert!(
        err.message
            .contains("return type argument `$A` does not appear in the return type"),
        "{err:?}"
    );

    let return_only = resolve_with_builtin_prelude(
        r#"deftrait ReturnOnly {
  def make() -> $A
}"#,
    );
    let err = typecheck(return_only).expect_err("a return-only slot has no input introduction");
    assert!(
        err.message
            .contains("return-only type input `$A` is not declared"),
        "{err:?}"
    );
}

fn trait_impl_return_type_arguments_must_match_the_trait_slots() {
    let matching = resolve_with_builtin_prelude(
        r#"deftrait Transform<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl Transform<Int> for String {
  def convert::<Int>(self: String) -> Int { 1 }
}"#,
    );
    typecheck(matching).expect("the impl must repeat the trait's target slot");

    let omitted = resolve_with_builtin_prelude(
        r#"deftrait Transform<$To> {
  def convert::<$To>(self: Self) -> $To
}

impl Transform<Int> for String {
  def convert(self: String) -> Int { 1 }
}"#,
    );
    let err =
        typecheck(omitted).expect_err("an impl cannot omit a required ReturnTypeArguments slot");
    assert_eq!(
        err.reason(),
        Some(diagnostics::TypeDiagnosticReason::TraitMethodTypeListArityMismatch),
        "{err:?}"
    );
}

fn explicit_function_type_arguments_follow_signature_order() {
    typecheck_with_rules(
        r#"def pair(left: $A, right: $B) -> ($A, $B) {
  (left, right)
}

value: (Int, String) = pair(1, "ok")"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("implicit generic slots should follow their first signature appearance");

    typecheck_with_rules(
        r#"def reversed(left: $A, right: $B) -> ($A, $B) {
  (left, right)
}

value: (String, Int) = reversed("ok", 1)"#,
        RuntimeSourcePolicy::script(),
    )
    .expect("declared generic slots should follow their declaration order");
}

fn match_result_extractor_contract_boundaries() {
    let source = r#"impl Int {
  defextractor value(value: Int) -> MatchResult<Int, Error> { MatchResult::Ok(value) }
  defextractor unit(value: Int) -> MatchResult<Unit> { MatchResult::Ok(()) }
}
match 1 { Int::value(value) => value, _ => 0 }
match 1 { Int::unit(value: Unit) => value, _ => () }
match 1 { Int::unit(_: Unit) => 1, _ => 0 }
match 1 { Int::unit() => 1, _ => 0 }
"#;
    typecheck(resolve_with_builtin_prelude(source)).expect("MatchResult and UnitOnly contract");
}

fn match_result_extractor_rejects_ordinary_value_uses() {
    for source in [
        "impl Int { defextractor invalid(v: Int) -> Option<Int> { Option::Some(v) } }",
        "def invalid(v: Int) -> MatchResult<Int> { MatchResult::Ok(v) }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { saved = MatchResult::Ok(v)\n saved } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { MatchResult::Ok(MatchResult::Ok(v)) } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { match MatchResult::Ok(v) { _ => MatchResult::Ok(v) } } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { f = {|x| MatchResult::Ok(x)}\n MatchResult::Ok(v) } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int, Int> { MatchResult::Ok(v) } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { MatchResult::Err(v) } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { _ =? Ok(MatchResult::Ok(v))\n MatchResult::Ok(v) } }",
        "impl Int { defextractor invalid(v: Int) -> MatchResult<Int> { if(is_match(MatchResult::Ok(v), _), MatchResult::Ok(v), MatchResult::Ok(v)) } }",
    ] {
        let result = resolve_with_builtin_prelude_result(source)
            .map(|resolved| typecheck(resolved));
        assert!(
            result.is_err() || result.expect("resolved source must be typechecked").is_err(),
            "must reject: {source}"
        );
    }

    let resolve_error = resolve_with_builtin_prelude_result("captured = &MatchResult::Ok")
        .expect_err("compiler-managed constructor capture must be rejected during resolution");
    assert_eq!(
        resolve_error.diagnostic.reason,
        sigil::error::ResolveErrorReason::ConstructorCaptureForbidden
    );
}

fn match_result_extractor_uses_own_safebind_target() {
    let source = r#"impl Int {
  defextractor checked(v: Int) -> MatchResult<Int> {
    accepted =? Ok(v)
    MatchResult::Ok(accepted)
  }
}
match 1 { Int::checked(value) => value, _ => 0 }
"#;
    let typed = typecheck(resolve_with_builtin_prelude(source)).expect("Extractor SafeBind target");
    let TypedInner::ExtractorDef(_, _, _, _, _, body, _) = &typed[0].node else {
        panic!("expected Extractor definition: {:?}", typed[0]);
    };
    let TypedInner::Block(items) = &body.node else {
        panic!("expected block")
    };
    assert!(matches!(
        &items[0].node,
        TypedInner::SafeBind(
            _,
            _,
            _,
            SafeBindFailureTarget::EnclosingMatchResultContext { .. }
        )
    ));
}

fn match_result_unitonly_rejects_wrong_child_shapes() {
    let prefix =
        "impl Int { defextractor unit(v: Int) -> MatchResult<Unit> { MatchResult::Ok(()) } }\n";
    for pattern in ["Int::unit(x: Int)", "Int::unit(_: Int)", "Int::unit(x, y)"] {
        let source = format!("{prefix}match 1 {{ {pattern} => 1, _ => 0 }}");
        typecheck(resolve_with_builtin_prelude(&source))
            .expect_err("wrong Unit child must be rejected");
    }
    let source = "impl Int { defextractor pair(v: Int) -> MatchResult<(Int, Unit)> { MatchResult::Ok((v, ())) } }\nmatch 1 { Int::pair(x) => x, _ => 0 }";
    typecheck(resolve_with_builtin_prelude(source)).expect_err("tuple Unit slot cannot be omitted");
}

fn match_result_payload_shape_must_be_resolved_before_execution() {
    let prefix = "impl Int { defextractor trial(v: Int) -> MatchResult<$T> { MatchResult::Err(NoneError()) } }\n";
    let source = format!("{prefix}is_match(1, Int::trial(_))");
    let error = typecheck(resolve_with_builtin_prelude(&source))
        .expect_err("unresolved payload shape must be rejected");
    assert!(error.message.contains("payload"), "{error:?}");
    let source = format!("{prefix}is_match(1, Int::trial(_: Int))");
    typecheck(resolve_with_builtin_prelude(&source))
        .expect("payload annotation connects normal inference");
    for source in [
        "def wrapping(v: List<$A>) -> Boolean { is_match(v, uncons(_, _)) }",
        "impl Int { defextractor pair(v: List<$A>) -> MatchResult<($A, Int)> { MatchResult::Err(NoneError()) } }\ndef wrapping_pair(v: List<$A>) -> Boolean { is_match(v, Int::pair(_, _)) }",
        "impl Int { defextractor list(v: List<$A>) -> MatchResult<List<$A>> { MatchResult::Ok(v) } }\ndef wrapping_list(v: List<$A>) -> Boolean { is_match(v, Int::list(_)) }",
    ] {
        typecheck(resolve_with_builtin_prelude(source)).expect("fixed payload shape permits generic children");
    }
}

fn extractor_prearguments_follow_signature_and_infer_payload_shape() {
    let source = r#"impl Int {
  defextractor choose(left: $A, right: Int, value: Int) -> MatchResult<$A> { MatchResult::Ok(left) }
  defextractor check(limit: Int, value: Int) -> MatchResult<Unit> { MatchResult::Ok(()) }
}
limit = 10
match 5 { Int::choose((1, "one"), limit + 1, number: Int, text: String) => text, _ => "miss" }
match 5 { Int::check(limit) => 1, _ => 0 }
match 5 { Int::check(limit, _: Unit) => 1, _ => 0 }
"#;
    typecheck(resolve_with_builtin_prelude(source))
        .expect("preargument types determine payload shape");

    let source = r#"impl Int {
  defextractor accept(pre: $A, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }
}
def doubled(value: $N) -> Boolean where $N: Add {
  is_match(1, Int::accept(value + value, _))
}
doubled(21)
doubled(1.5)
"#;
    let typed = typecheck(resolve_with_builtin_prelude(source))
        .expect("generic trait calls in prearguments specialize with their enclosing function");
    let specialized = typed
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Def(_, id, _, _, _, _, body, _) if id.name == "doubled" => Some(body),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(specialized.len(), 2);
}

fn extractor_target_requires_concrete_type_head() {
    let resolved = resolve_with_builtin_prelude(
        r#"impl Int {
  defextractor identity(value: $T) -> MatchResult<$T> { MatchResult::Ok(value) }
}"#,
    );
    let error = typecheck(resolved)
        .expect_err("a bare generic type parameter must not be an Extractor target");
    assert!(
        error
            .message
            .contains("Extractor target type must have a concrete head"),
        "{error:?}"
    );
}

fn extractor_target_accepts_generic_arguments_under_concrete_head() {
    typecheck(resolve_with_builtin_prelude(
        r#"impl Int {
  defextractor list(value: List<$T>) -> MatchResult<$T> { MatchResult::Err(NoneError()) }
  defextractor result(value: Result<$T>) -> MatchResult<$T> { MatchResult::Err(NoneError()) }
}"#,
    ))
    .expect("generic arguments under a concrete Extractor target head must remain valid");
}

fn extractor_closure_inference_and_callable_boundaries() {
    let source = r#"limit = 2
pick = *{|value: Int| True =? value > limit; MatchResult::Ok(value) }
match 5 { pick(value: Int) => value, _ => 0 }
"#;
    typecheck(resolve_with_builtin_prelude(source))
        .expect("ExtractorClosure literal and local head");
    for source in [
        r#"ext = *{|value: (Int, Int)| MatchResult::Ok(value)}; match (1, 2) { ext(a, b) | ext(b, a) => a, _ => 0 }"#,
        r#"typed: ExtractorClosure<(Int -> MatchResult<Int>)> = *{|value| MatchResult::Ok(value)}
match 1 { typed(n) => n, _ => 0 }"#,
        r#"def make(limit: Int) -> ExtractorClosure<(Int -> MatchResult<Int>)> {
  *{|value| True =? value > limit; MatchResult::Ok(value)}
}
def use(ext: ExtractorClosure<(Int -> MatchResult<Int>)>, value: Int) -> Int {
  match value { ext(n) => n, _ => 0 }
}
use(make(2), 3)"#,
        r#"value = 9
ext = *{|pre: Int, input: Int| MatchResult::Ok(input)}
match 5 { ext(value, n) => value + n, _ => 0 }
is_match(5, ext(value, _))"#,
        r#"ext = *{|input: Int| MatchResult::Ok(input)}
match 1 { ext(value) | ext(value) => value, _ => 0 }"#,
    ] {
        typecheck(resolve_with_builtin_prelude(source))
            .unwrap_or_else(|error| panic!("{source}\n{error:?}"));
    }
    for source in [
        r#"typed: ExtractorClosure<(Int -> MatchResult<Int, Error>)> = *{|value| MatchResult::Ok(value)}"#,
        r#"typed: ExtractorClosure<(Int -> MatchResult<Int, NoneError>)> = *{|value| MatchResult::Ok(value)}"#,
    ] {
        let error = typecheck(resolve_with_builtin_prelude(source))
            .expect_err("ExtractorClosure annotations must not name an Error type argument");
        assert!(
            error
                .message
                .contains("only allowed in defextractor return signatures"),
            "{source}\n{error:?}"
        );
    }
    for source in [
        r#"ext = *{|value: Int| MatchResult::Ok(value)}; ext(1)"#,
        r#"ext = *{|value: Int| MatchResult::Ok(value)}; is_match(1, ext(bound))"#,
        r#"ext = *{|value: Int| MatchResult::Ok(value)}; match 1 { ext(a) | ext(b) => 0, _ => 1 }"#,
        r#"ext = *{|value: Int| f = {|nested: Int| MatchResult::Ok(nested)}; MatchResult::Ok(value)}"#,
        r#"ext = *{|value: Int| f = {|nested: Int| True =? nested > 0; nested}; MatchResult::Ok(value)}"#,
        r#"ext = *{|value: Int| Ok(value)}"#,
        r#"ext = {|value: Int| value}; match 1 { ext(bound) => bound, _ => 0 }"#,
    ] {
        assert!(
            typecheck(resolve_with_builtin_prelude(source)).is_err(),
            "{source}"
        );
    }
}

fn extractor_closure_direct_argument_uses_expected_type() {
    typecheck(resolve_with_builtin_prelude(
        r#"def accepts(value: Int, ext: ExtractorClosure<(Int -> MatchResult<Int>)>) -> Boolean {
  is_match(value, ext(_))
}
accepted: Boolean = accepts(1, *{|value| MatchResult::Ok(value)})"#,
    ))
    .expect("a direct ExtractorClosure argument must use the higher-order expected type");

    typecheck(resolve_with_builtin_prelude(
        r#"def retain(value: $A, ext: ExtractorClosure<($A -> MatchResult<$A>)>) -> $A { value }
accepted: Int = retain(1, *{|value| MatchResult::Ok(value)})"#,
    ))
    .expect("a preceding argument may concretize a direct generic ExtractorClosure argument");

    let resolved = resolve_with_builtin_prelude(r#"identity = *{|value| MatchResult::Ok(value)}"#);
    let error = typecheck(resolved)
        .expect_err("an untyped ExtractorClosure must not become a polymorphic local value");
    assert!(
        error
            .message
            .contains("Callable binding requires a concrete signature"),
        "{error:?}"
    );
}

fn apply_pattern_projection_types_and_boundaries() {
    let source =
        r#"result: Result<(String, Int)> = apply_pattern((7, "value"), (_2: Int, _1: String))"#;
    let typed = typecheck(resolve_with_builtin_prelude(source))
        .expect("projection output follows number order");
    let TypedInner::ApplyPattern { projections, .. } = &typed_bind_rhs(&typed, "result").node
    else {
        panic!("apply_pattern typed contract");
    };
    assert_eq!(
        projections
            .iter()
            .map(|(_, ty)| ty.clone())
            .collect::<Vec<_>>(),
        vec![Ty::Str, Ty::Int]
    );
    for source in [
        r#"result: Result<Unit> = apply_pattern(3, 3)"#,
        r#"result: Result<Int> = apply_pattern(3, _1)"#,
        r#"result: Result<(Int, List<(Int, Int)>, (Int, Int))> = apply_pattern([(1, 3)], [(_1: Int, 3) @ _3] @ _2)"#,
        r#"result: Result<(Int, List<Int>)> = apply_pattern([1, 2, 3], [_1: Int, .._2: List<Int>])"#,
        r#"whole: Result<Result<Int>> = apply_pattern(Ok(1), _1)
payload: Result<Int> = apply_pattern(Ok(1), Ok(_1))
failed: Result<Result<Int>> = apply_pattern(Err(NoneError()), _1)
constrained: Result<Int> = apply_pattern(Err(NoneError()), Ok(_1: Int))"#,
        r#"ext: ExtractorClosure<((Int, String) -> MatchResult<(Int, String)>)> = *{|value| MatchResult::Ok(value)}
result: Result<(String, Int)> = apply_pattern((3, "text"), ext(_2, _1))"#,
        r#"unknown: ExtractorClosure<(Int -> MatchResult<Int>)> = *{|value: Int| MatchResult::Err(NoneError())}
result: Result<Int> = apply_pattern(1, unknown(_1))"#,
        r#"def ordinary() -> Int { result = apply_pattern(3, _1); 7 }
ordinary()"#,
    ] {
        typecheck(resolve_with_builtin_prelude(source))
            .unwrap_or_else(|error| panic!("{source}\n{error:?}"));
    }
    for source in [
        r#"apply_pattern((1, 2), (_1, _1))"#,
        r#"apply_pattern((1, 2), (_01, _1))"#,
        r#"apply_pattern(1, _2)"#,
        r#"match 1 { _1 => 1 }"#,
    ] {
        let error = typecheck(resolve_with_builtin_prelude(source)).expect_err(source);
        let diagnostic = error.structured.expect("Pattern producer diagnostic");
        assert_eq!(
            diagnostic.reason,
            diagnostics::TypeDiagnosticReason::PatternShapeMismatch
        );
        assert_eq!(diagnostic.origin, diagnostics::DiagnosticOrigin::Pattern);
        assert!(matches!(
            diagnostic.data,
            diagnostics::DiagnosticData::Pattern(_)
        ));
    }
    for source in [
        r#"apply_pattern((1, 2), (_1, _1))"#,
        r#"apply_pattern((1, 2), (_01, _1))"#,
        r#"apply_pattern(1, _2)"#,
        r#"apply_pattern(1, _1: String)"#,
        r#"result: Result<String> = apply_pattern(1, _1)"#,
    ] {
        assert!(
            typecheck(resolve_with_builtin_prelude(source)).is_err(),
            "{source}"
        );
    }
}

fn facet_capture_call_inference_resolves_later_arguments() {
    let typed = typecheck_with_builtin_prelude(
        r#"defrecord User(name: String)
a = Function::apply(&List.[0], [1])
b = Function::apply(&Tuple._0, (1, 2))
c = Function::apply(&HashMap.["a"], HashMap::map_from_entries([("a", 1)]))
d = Function::apply(&Option.Some, Option::Some(1))
e = Function::apply(&User.name, User("alice"))
f = Function::apply(_.[0], [1])
g = Function::apply(_._0, (1, 2))
h = Function::apply(_.name, User("alice"))
i = Function::apply(&List.[0..1], [1, 2])
j = Function::apply(_.[0..1], [1, 2])
k = Function::apply(value: [1], f: &List.[0])
l = Function::apply(value: [1], f: _.[0])
m = Function::apply(_.["a"], HashMap::map_from_entries([("a", 1)]))
n = Function::apply(_.Some, Option::Some(1))
o = Function::apply((&List.[0]), [1])
p = Function::apply((_._0), (1, 2))"#,
    );
    for name in ["a", "c", "d", "f", "k", "l", "m", "n", "o"] {
        assert!(
            matches!(&typed_bind_rhs(&typed, name).ty,
            Ty::Result(ok, _) if matches!(ok.as_ref(), Ty::Int)),
            "{name}"
        );
    }
    for name in ["b", "g", "p"] {
        assert!(matches!(typed_bind_rhs(&typed, name).ty, Ty::Int), "{name}");
    }
    for name in ["e", "h"] {
        assert!(matches!(typed_bind_rhs(&typed, name).ty, Ty::Str), "{name}");
    }
    for name in ["i", "j"] {
        assert!(
            matches!(&typed_bind_rhs(&typed, name).ty,
            Ty::Result(ok, _) if matches!(ok.as_ref(), Ty::List(_))),
            "{name}"
        );
    }
}

fn facet_capture_call_inference_resolves_dependencies_and_return() {
    let typed = typecheck_with_builtin_prelude(
        r#"def chain(outer: ($B -> $C), inner: ($A -> $B), value: $A) -> $C {
  outer(inner(value))
}
def getter(f: ($A -> $B)) -> ($A -> $B) { f }
def empty_after(f: ($A -> $B)) -> List<$A> { [] }
def consume(f: (($A, Int) -> String)) -> Unit { () }
def nested(f: (($A, Int) -> String), value: $A) -> String { f((value, 0)) }
defrecord User(name: String)
a = chain(_.name, &Tuple._0, (User("alice"), 1))
b = chain(&User.name, _._0, (User("bob"), 2))
c: (List<Int> -> Result<Int>) = getter(&List.[0])
d: (List<Int> -> Result<Int>) = getter(_.[0])
f: ((List<Int> -> Result<Int>), List<Int> -> Result<Int>) = &Function::apply
e = f(&List.[0], [1])
list_reader: (List<Int> -> Result<Int>) = &List.[0]
g = Function::apply(list_reader, [1])
h = Facet::view(List.[0], [1])
i = Facet::view(~[1].[0])
j = List::map([(1, [])], &Tuple._0)
k = List::map([(1, [])], _._0)
consume(&Tuple._0)
consume(_._0)
l = nested(_._0.name, User("alice"))
m: List<User> = empty_after(_.name)"#,
    );
    for name in ["a", "b", "l"] {
        assert!(matches!(typed_bind_rhs(&typed, name).ty, Ty::Str), "{name}");
    }
    assert!(
        matches!(&typed_bind_rhs(&typed, "m").ty, Ty::List(inner) if matches!(inner.as_ref(), Ty::Record(_, _)))
    );
    for name in ["c", "d"] {
        assert!(
            matches!(typed_bind_rhs(&typed, name).ty, Ty::Func(_, _)),
            "{name}"
        );
    }
    for name in ["j", "k"] {
        assert!(
            matches!(&typed_bind_rhs(&typed, name).ty, Ty::List(inner) if matches!(inner.as_ref(), Ty::Int)),
            "{name}"
        );
    }
    for name in ["e", "g", "h", "i"] {
        assert!(
            matches!(&typed_bind_rhs(&typed, name).ty,
            Ty::Result(ok, _) if matches!(ok.as_ref(), Ty::Int)),
            "{name}"
        );
    }
}

fn facet_capture_call_inference_rejects_invalid_paths_and_unresolved_source() {
    for (source, message) in [
        (
            r#"Function::apply(&List.[0], "text")"#,
            "List root Facet path requires List<T>",
        ),
        ("Function::apply(&Tuple._2, (1, 2))", "out of bounds"),
        ("Function::apply(_._2, (1, 2))", "out of bounds"),
        (
            r#"Function::apply(&HashMap.[1], HashMap::map_from_entries([("a", 1)]))"#,
            "must be String",
        ),
        (
            "defrecord User(name: String)\nFunction::apply(&User.name, (1, 2))",
            "owner mismatch",
        ),
        ("_.name", "requires expected unary function context"),
        ("def getter(f: ($A -> $B)) -> ($A -> $B) { f }\ngetter(&Int._0)", "not a Facet path root"),

        ("defstruct Secret<$A> { private value: $A }\nimpl Secret { def new(value: $A) -> Secret<$A> { Secret { value: value } } }\ndef consume(f: (Secret<$A> -> String)) -> Unit { () }\nconsume(_.value.name)", "private"),

        (r#"Function::apply(&List.["bad"], [1])"#, "must be Int"),
        (
            "defrecord User(name: String)\nFunction::apply(&User.missing, User(\"alice\"))",
            "missing",
        ),
        (
            "defrecord User(name: String)\nFunction::apply(_.missing, User(\"alice\"))",
            "missing",
        ),
        (
            "def getter(f: ($A -> $B)) -> ($A -> $B) { f }\ngetter(&List.[0])",
            "unresolved source type",
        ),
        (
            "def getter(f: ($A -> $B)) -> ($A -> $B) { f }\ngetter(_.name)",
            "unresolved source type",
        ),
        (
            "def pair(f: ($A -> $B), g: ($B -> $A)) -> Unit { () }\npair(_.name, _.name)",
            "unresolved source type",
        ),
    ] {
        let error = typecheck_with_rules(source, RuntimeSourcePolicy::script()).expect_err(source);
        assert!(
            error.message.contains(message),
            "{source}: {}",
            error.message
        );
    }
}

fn facet_capture_call_inference_preserves_argument_diagnostics() {
    let source = "def f(a: Int, b: Int) -> Unit { () }\nf(a: \"bad\")";
    let error = typecheck_with_rules(source, RuntimeSourcePolicy::script()).expect_err(source);
    assert!(error.message.contains("mismatch"), "{}", error.message);
    assert!(!error.message.contains("Missing argument"));

    let source = "def pair(f: ($A -> $B), g: ($B -> $A)) -> Unit { () }\npair(_.name, _.name)";
    let error = typecheck_with_rules(source, RuntimeSourcePolicy::script()).expect_err(source);
    let start = source.find("_.name").unwrap();
    assert_eq!(
        error.span,
        Span {
            start,
            end: start + "_.name".len()
        }
    );
}

fn error_kind_accepts_user_type_positions() {
    for source in [
        "def expose(kind: ErrorKind) -> Int { 1 }",
        "def expose() -> ErrorKind { NoneError }",
        "value: ErrorKind = NoneError",
        "defstruct Exposed { kind: ErrorKind }\nimpl Exposed { def new(kind: ErrorKind) -> Exposed { Exposed { kind: kind } } }",
        "def expose(values: List<ErrorKind>) -> Int { 1 }",
    ] {
        let resolved = resolve_with_builtin_prelude(source);
        typecheck(resolved).expect("ErrorKind is an ordinary opaque value type");
    }
}

fn recover_kind_rejects_invalid_handlers() {
    for handler in ["{|| Ok(1)}", "{|left, right| Ok(1)}", "{|_| 1}"] {
        let source =
            format!("value = Result::recover_kind(Err(NoneError()), NoneError, {handler})");
        let resolved = resolve_with_builtin_prelude(&source);
        typecheck(resolved).expect_err("recover_kind requires one Error input and a Result output");
    }
    let resolved = resolve_with_builtin_prelude(
        "def call1(f: ($A -> $B), value: $A) -> $B { f(value) }\nvalue = call1(&Result::recover_kind(&1, NoneError, &1), Ok(1))",
    );
    typecheck(resolved).expect_err("one placeholder cannot be both Result value and handler");
}

fn error_contract_surface_is_restricted_to_direct_definition_returns() {
    for source in [
        "ret: Result<Int> = Ok(1)",
        "f: (Int -> (_ -> Int)) = {|value: Int| always(value)}",
        "def make() -> (Int -> (_ -> Int)) { {|value: Int| always(value)} }",
        "def read(value: Result<Int>) -> Result<Int, NoneError> { value }",
        "def read(value: Result<$T>) -> Result<$T, NoneError> { value }",
        "def make() -> (Int -> Result<Int>) { {|value: Int| Ok(value)} }",
        "impl Int { defextractor read(value: Int) -> MatchResult<Int, Error> { MatchResult::Ok(value) } }",
        "def use(ext: ExtractorClosure<(Int -> MatchResult<Int>)>) -> Boolean { is_match(1, ext(_)) }",
    ] {
        typecheck(resolve_with_builtin_prelude(source))
            .unwrap_or_else(|error| panic!("{source}\n{error:?}"));
    }
    for source in [
        "ret: Result<Int, NoneError> = Ok(1)",
        "ret: Result<Int, Error> = Ok(1)",
        "ret: List<Result<Int, NoneError>> = [Ok(1)]",
        "defstruct Invalid { value: Result<Int, NoneError> }",
        "f: (Int -> Result<Int, NoneError>) = {|value: Int| Ok(value)}",
        "def read(value: Result<Int, NoneError>) -> Result<Int> { value }",
        "def read(value: Result<$T, NoneError>) -> Result<$T> { value }",
        "def make() -> (Int -> Result<Int, NoneError>) { {|value: Int| Ok(value)} }",
        "def make() -> List<Result<Int, NoneError>> { [Ok(1)] }",
        "def make() -> ExtractorClosure<(Int -> MatchResult<Int, Error>)> { *{|value: Int| MatchResult::Ok(value)} }",
    ] {
        typecheck(resolve_with_builtin_prelude(source))
            .expect_err(&format!("Error position must be rejected: {source}"));
    }
    let error = typecheck(resolve_with_builtin_prelude(
        "ext: ExtractorClosure<(Int -> MatchResult<Int>)> = {|value: Int| Ok(value)}",
    ))
    .expect_err("ordinary closure cannot implement an ExtractorClosure");
    assert!(
        error
            .message
            .contains("ExtractorClosure<(Int -> MatchResult<Int>)>"),
        "{error:?}"
    );
    assert!(
        !error.message.contains("MatchResult<Int, Error>"),
        "{error:?}"
    );
}

fn trait_result_error_omission_allows_impl_contract() {
    let source = r#"deferror DomainFailure { "domain failure" }
deftrait SafeArithmetic { def compute(self: Self, rhs: Self) -> Result<Self> }
impl SafeArithmetic for Int {
  def compute(self: Int, rhs: Int) -> Result<Int, DomainFailure> { Ok(self + rhs) }
}
SafeArithmetic::compute(1, 2)"#;
    typecheck(resolve_with_builtin_prelude(source))
        .expect("omitted trait error is not a fixed contract");
}

fn trait_result_explicit_error_contract_is_declaration_metadata() {
    let source = r#"deferror DomainFailure { "domain failure" }
deftrait SafeArithmetic { def compute(self: Self, rhs: Self) -> Result<Self, Error> }
impl SafeArithmetic for Int {
  def compute(self: Int, rhs: Int) -> Result<Int, DomainFailure> { Ok(self + rhs) }
}
SafeArithmetic::compute(1, 2)"#;
    typecheck(resolve_with_builtin_prelude(source))
        .expect("error marker does not become a value type argument");
}

fn facet_view_capture_infers_source_from_path() {
    for capture in [
        "&Facet::view(User.name, &1)",
        "&view(User.name, &1)",
        "&User.name",
        "&view(path, &1)",
        "&path",
    ] {
        let source = format!("defrecord User(name: String)\npath = User.name\ngetter = {capture}\ngetter(User(\"alice\"))");
        let typed = typecheck_with_rules(&source, RuntimeSourcePolicy::script())
            .unwrap_or_else(|error| panic!("{capture}: {}", error.message));
        assert!(matches!(typed.last().unwrap().ty, Ty::Str));
    }
}

fn facet_view_capture_preserves_constraints() {
    for annotation in ["Int -> String", "User -> Int"] {
        let source = format!(
            "defrecord User(name: String)\nf: ({annotation}) = &Facet::view(User.name, &1)"
        );
        typecheck_with_rules(&source, RuntimeSourcePolicy::script())
            .expect_err("conflicting source/focus must fail");
    }
    let typed = typecheck_with_rules(
        "defrecord User(name: String)\nf: (Result<User> -> Result<String>) = &Facet::view(User.name, &1)\nf(Ok(User(\"alice\")))",
        RuntimeSourcePolicy::script()).expect("explicit Result source preserves API lift");
    assert!(matches!(typed.last().unwrap().ty, Ty::Result(..)));
}

fn facet_capture_compile_time_scope_boundaries() {
    let bracket_compose = typecheck_with_rules(
        "defrecord Container(values: List<Int>)\nf = &Facet::compose(Container.values, List.[&1])",
        RuntimeSourcePolicy::script(),
    )
    .expect_err("bracket data does not permit returning a FacetPath from a capture");
    assert!(
        bracket_compose
            .message
            .contains("cannot be returned from closures"),
        "{}",
        bracket_compose.message
    );
    for capture in [
        "&Facet::compose",
        "&compose",
        "{|x: User| Facet::compose(p, q)}",
        "{|x: User| compose(p, q)}",
    ] {
        let source = format!("defrecord Inner(name: String)\ndefrecord User(inner: Inner)\np = User.inner\nq = Inner.name\nf = {capture}");
        typecheck_with_rules(&source, RuntimeSourcePolicy::script())
            .expect_err("path transport/return and fixed partial captures stay forbidden");
    }
    let source = "defrecord User(name: String)\np = User.name\nf = {|path: Facet<InfallibleStructural, User, String, _, _>| Facet::view(path, User(\"alice\"))}";
    typecheck_with_rules(source, RuntimeSourcePolicy::script())
        .expect_err("Facet closure parameters stay forbidden");
}

fn pattern_failure_diagnostics_show_target_origins() {
    let closure = typecheck_with_rules(
        "def outer() -> Result<Int> { bad: (Int -> Int) = {|x| 2 =? Ok(x); x}; Ok(1) }",
        RuntimeSourcePolicy::script(),
    )
    .unwrap_err();
    assert_eq!(closure.message, "MonadFail is not implemented.");
    assert!(closure.structured.as_ref().unwrap().related.is_empty());
    let ordinary = typecheck_with_rules(
        "value: Identity<Int> = Alternative::empty()",
        RuntimeSourcePolicy::script(),
    )
    .unwrap_err();
    assert!(matches!(
        ordinary
            .structured
            .as_ref()
            .map(|diagnostic| &diagnostic.data),
        Some(diagnostics::DiagnosticData::TraitDispatch(_))
    ));
    assert!(!ordinary.message.contains("MonadFail is not implemented."));

    for carrier in ["Identity<Int>", "Option<Int>"] {
        let tail = if carrier.starts_with("Identity") {
            "Identity(5)"
        } else {
            "Option::Some(5)"
        };
        let source = format!("def sample() -> {carrier} {{\n  2 =? Ok(3)\n  {tail}\n}}");
        let error = typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_err();
        assert_eq!(error.message, "MonadFail is not implemented.");
        let diagnostic = error.structured.as_ref().unwrap();
        let operator = source.find("=?").unwrap();
        assert_eq!(
            diagnostic.primary.span,
            Span {
                start: operator,
                end: operator + 2
            }
        );
        let target = diagnostic
            .related
            .iter()
            .find(|fact| fact.role.json_name() == "return_type")
            .unwrap();
        let start = source.find(carrier).unwrap();
        assert_eq!(
            target.span,
            Span {
                start,
                end: start + carrier.len()
            }
        );
        assert_eq!(target.ty.as_deref(), Some(carrier));
        let spec = diagnostics::structured_type_error_spec(diagnostic);
        assert_eq!(
            spec.help.as_deref(),
            Some("Implement MonadFail for the return type to handle FailurePattern.")
        );
        assert!(spec
            .labels
            .iter()
            .any(|label| label.message == format!("Return type: {carrier}")));
        assert_eq!(diagnostic.data.to_json_value()["kind"], "PatternFailure");
    }
    for (statement, primary) in [("2 =? Ok(3)", "=?"), ("2 <- Identity(3)", "2")] {
        let source = format!("def sample() -> Result<Int> {{\n  ret: Result<Int> = do {{\n    nested: Identity<Int> = do::<Identity> {{\n      {statement}\n      Identity(5)\n    }}\n    Ok(5)\n  }}\n  ret\n}}");
        let error = typecheck_with_rules(&source, RuntimeSourcePolicy::script()).unwrap_err();
        assert_eq!(
            error.message,
            "Neither MonadFail nor Alternative is implemented."
        );
        let diagnostic = error.structured.as_ref().unwrap();
        let statement_start = source.find(statement).unwrap();
        let primary_start = statement_start + statement.find(primary).unwrap();
        assert_eq!(
            diagnostic.primary.span,
            Span {
                start: primary_start,
                end: primary_start + primary.len()
            }
        );
        let target = diagnostic
            .related
            .iter()
            .find(|fact| fact.role.json_name() == "do_carrier")
            .unwrap();
        let start = source.find("do::<Identity>").unwrap();
        assert_eq!(
            target.span,
            Span {
                start,
                end: start + 2
            }
        );
        assert_eq!(target.ty.as_deref(), Some("Identity<Int>"));
        let spec = diagnostics::structured_type_error_spec(diagnostic);
        assert!(spec.help.as_deref().unwrap().contains("preferred"));
        assert!(spec
            .labels
            .iter()
            .any(|label| label.message == "do_carrier: Identity<Int>"));
        assert_eq!(diagnostic.data.to_json_value()["kind"], "PatternFailure");
    }
}

fn hash_map_pattern_type_boundaries() {
    for source in [
        r#"map = hash!["a" => 2]
answer = match map { hash!["a" => value] => value, hash![] => 0 }"#,
        r#"map = hash!["a" => 2]
hash![] = map"#,
        r#"map = hash!["a" => 2]
answer = apply_pattern(map, hash!["a" => _1])"#,
        r#"map = hash!["a" => Ok(2)]
answer = match map { hash!["a" => value] => value, hash![] => Ok(0) }"#,
    ] {
        typecheck_with_standard_environment(source)
            .expect("HashMap success boundary should typecheck");
    }
    for (source, message) in [
        (
            r#"map = hash!["a" => 2]
answer = match map { hash![1 => _] => True, _ => False }"#,
            "HashMap Pattern key must be String",
        ),
        (
            r#"map = hash!["a" => 2]
hash!["a" => value] = map"#,
            "Only total MatchBlock patterns",
        ),
        (
            r#"map = hash!["a" => 2]
hash![] =? map"#,
            "not a SafeBind target",
        ),
        (
            r#"map = hash!["a" => 2]
answer = match map { hash!["a" => _] => True }"#,
            "exhaustive",
        ),
        (
            r#"answer = match 2 { hash![] => True, _ => False }"#,
            "HashMap",
        ),
    ] {
        let error = typecheck_with_standard_environment(source)
            .expect_err("HashMap rejection boundary should fail");
        assert!(
            error
                .message
                .to_lowercase()
                .contains(&message.to_lowercase()),
            "expected {message}, got {}",
            error.message
        );
    }
}

fn check_facet_specializations(body: &str, values_ty: &str, values: &str, result_ty: &str) {
    let source = format!(
        r#"
defrecord Box(values: List<Int>)
def outer(source: Result<$A>, next: ($A -> Result<Int>), values: {values_ty}) -> {result_ty} {{
  {body}
}}
outer(Ok(1), {{|x: Int| Ok(x)}}, {values})
outer(Ok("hello"), {{|x: String| Ok(0)}}, {values})
outer(Ok(1), {{|x: Int| Ok(x)}}, {values})
"#
    );
    let nodes = support::typecheck_with_builtin_prelude(&source);
    let source_types: Vec<_> = nodes
        .iter()
        .filter_map(|node| match &node.node {
            TypedInner::Def(_, name, _, params, _, _, _, _) if name.name == "outer" => {
                match &params[0].ty {
                    Ty::Result(source, _) => Some(source.as_ref().clone()),
                    _ => panic!("outer source must retain its Result signature"),
                }
            }
            _ => None,
        })
        .collect();
    assert_eq!(
        source_types.len(),
        2,
        "same-type calls should share their specialization"
    );
    assert!(
        source_types.contains(&Ty::Int),
        "Int source specialization missing: {source_types:?}"
    );
    assert!(
        source_types.contains(&Ty::Str),
        "String source specialization missing: {source_types:?}"
    );
}

fn facet_pending_dispatch_collects_path_type_inputs() {
    for (body, values_ty, values, result_ty) in [
        ("Facet::view(List.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }], values)", "List<Int>", "[10, 20]", "Result<Int>"),
        ("values.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }]", "List<Int>", "[10, 20]", "Result<Int>"),
        ("Facet::view(List.[(match Monad::bind(source, next) { Ok(x) => x, _ => 0 })..1], values)", "List<Int>", "[10, 20]", "Result<List<Int>>"),
        ("Facet::view(List.[0..(match Monad::bind(source, next) { Ok(x) => x, _ => 0 })], values)", "List<Int>", "[10, 20]", "Result<List<Int>>"),
        ("Facet::view(HashMap.[match Monad::bind(source, next) { Ok(x) => \"one\", _ => \"none\" }], values)", "HashMap<Int>", "HashMap::map_from_entries([(\"one\", 10)])", "Result<Int>"),
        ("Facet::set(List.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }], values, 99)", "List<Int>", "[10, 20]", "Result<List<Int>>"),
        ("Facet::over(List.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }], values, {|value| Ok(value + 1)})", "List<Int>", "[10, 20]", "Result<List<Int>>"),
        ("path = List.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }]\nFacet::view(path, values)", "List<Int>", "[10, 20]", "Result<Int>"),
        ("Facet::view(List.[0] -> List.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }], values)", "List<List<Int>>", "[[10, 20]]", "Result<Int>"),
        ("Facet::bulk_update(values) { values.[match Monad::bind(source, next) { Ok(x) => x, _ => 0 }] <- set(99) }", "Box", "Box([10, 20])", "Result<Box>"),
    ] {
        check_facet_specializations(body, values_ty, values, result_ty);
    }
}
