use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::collections::HashMap;
use std::fmt;
use std::rc::Rc;
use std::sync::Arc;

use crate::names::{surface_path_eq, surface_path_name};
use crate::primitives::{BuiltinId, FunctionId, RuntimeTag, SurtrInt};

/// Kind of user-defined type at runtime.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypeKind {
    Struct,
    Record,
    EnumVariant,
}

/// Runtime metadata for a tagged type.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TypeEntry {
    pub tag: RuntimeTag,
    pub name: String,
    pub kind: TypeKind,
    pub field_names: Vec<String>,
    #[serde(default)]
    pub private_flags: Vec<bool>,
}

/// Validation error for runtime type metadata.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TypeRegistryError {
    message: String,
}

impl TypeRegistryError {
    fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }

    pub fn message(&self) -> &str {
        &self.message
    }
}

impl fmt::Display for TypeRegistryError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for TypeRegistryError {}

/// Runtime registry of tagged user-defined types in a compiled program.
///
/// This is separate from compile-space `TypeIdentity`. Entry order and tags are
/// validated runtime metadata used for lookup and display; user-visible `Int`
/// values are never used as internal tags.
#[derive(Debug, Clone, PartialEq)]
pub struct TypeRegistry {
    entries: Vec<TypeEntry>,
    tag_to_index: HashMap<RuntimeTag, usize>,
}

impl TypeRegistry {
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
            tag_to_index: HashMap::new(),
        }
    }

    pub fn from_entries(entries: Vec<TypeEntry>) -> Self {
        Self::try_from_entries(entries).expect("invalid TypeRegistry entries")
    }

    pub fn try_from_entries(entries: Vec<TypeEntry>) -> Result<Self, TypeRegistryError> {
        let mut registry = Self::new();
        registry.try_extend(entries)?;
        Ok(registry)
    }

    pub fn register(&mut self, entry: TypeEntry) {
        self.try_register(entry)
            .expect("invalid TypeRegistry entry");
    }

    pub fn try_register(&mut self, entry: TypeEntry) -> Result<(), TypeRegistryError> {
        validate_type_registry_append(&self.entries, std::slice::from_ref(&entry))?;
        self.register_unchecked(entry);
        Ok(())
    }

    fn register_unchecked(&mut self, entry: TypeEntry) {
        self.tag_to_index.insert(entry.tag, self.entries.len());
        self.entries.push(entry);
    }

    pub fn extend<I>(&mut self, entries: I)
    where
        I: IntoIterator<Item = TypeEntry>,
    {
        self.try_extend(entries)
            .expect("invalid TypeRegistry extension");
    }

    pub fn try_extend<I>(&mut self, entries: I) -> Result<(), TypeRegistryError>
    where
        I: IntoIterator<Item = TypeEntry>,
    {
        let entries = entries.into_iter().collect::<Vec<_>>();
        validate_type_registry_append(&self.entries, &entries)?;
        for entry in entries {
            self.register_unchecked(entry);
        }
        Ok(())
    }

    pub fn entries(&self) -> &[TypeEntry] {
        &self.entries
    }

    pub fn truncate(&mut self, len: usize) {
        self.entries.truncate(len);
        self.tag_to_index = self
            .entries
            .iter()
            .enumerate()
            .map(|(idx, entry)| (entry.tag, idx))
            .collect();
    }

    pub fn lookup(&self, tag: RuntimeTag) -> Option<&TypeEntry> {
        self.tag_to_index
            .get(&tag)
            .and_then(|idx| self.entries.get(*idx))
    }

    pub fn lookup_by_name(&self, qualified_name: &str) -> Option<&TypeEntry> {
        self.entries.iter().find(|entry| {
            entry.name == qualified_name || surface_path_eq(&entry.name, qualified_name)
        })
    }

    pub fn tag_by_name(&self, qualified_name: &str) -> Option<RuntimeTag> {
        self.lookup_by_name(qualified_name).map(|entry| entry.tag)
    }
}

impl Default for TypeRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl Serialize for TypeRegistry {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        self.entries.serialize(serializer)
    }
}

impl<'de> Deserialize<'de> for TypeRegistry {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let entries = Vec::<TypeEntry>::deserialize(deserializer)?;
        Self::try_from_entries(entries).map_err(serde::de::Error::custom)
    }
}

pub fn validate_type_registry_append(
    existing: &[TypeEntry],
    entries: &[TypeEntry],
) -> Result<(), TypeRegistryError> {
    let mut by_tag = HashMap::new();
    let mut by_surface_name: HashMap<String, &TypeEntry> = HashMap::new();

    for entry in existing {
        validate_type_entry_shape(entry)?;
        if matches!(entry.tag, 0 | 1) {
            return Err(TypeRegistryError::new(format!(
                "reserved result tag reused in TypeRegistry: {}",
                entry.tag
            )));
        }
        if by_tag.insert(entry.tag, entry).is_some() {
            return Err(TypeRegistryError::new(format!(
                "duplicate type tag in TypeRegistry: {}",
                entry.tag
            )));
        }
        let surface_name = surface_path_name(&entry.name).to_string();
        if let Some(previous) = by_surface_name.insert(surface_name, entry) {
            return Err(TypeRegistryError::new(format!(
                "duplicate type name in TypeRegistry: {} conflicts with {}",
                entry.name, previous.name
            )));
        }
    }

    for entry in entries {
        validate_type_entry_shape(entry)?;
        if matches!(entry.tag, 0 | 1) {
            return Err(TypeRegistryError::new(format!(
                "reserved result tag reused in TypeRegistry: {}",
                entry.tag
            )));
        }
        if by_tag.insert(entry.tag, entry).is_some() {
            return Err(TypeRegistryError::new(format!(
                "duplicate type tag in TypeRegistry: {}",
                entry.tag
            )));
        }
        let surface_name = surface_path_name(&entry.name).to_string();
        if let Some(previous) = by_surface_name.insert(surface_name, entry) {
            return Err(TypeRegistryError::new(format!(
                "duplicate type name in TypeRegistry: {} conflicts with {}",
                entry.name, previous.name
            )));
        }
    }

    Ok(())
}

fn validate_type_entry_shape(entry: &TypeEntry) -> Result<(), TypeRegistryError> {
    if entry.private_flags.len() != entry.field_names.len() {
        return Err(TypeRegistryError::new(format!(
            "TypeRegistry entry {} private_flags length {} does not match field_names length {}",
            entry.name,
            entry.private_flags.len(),
            entry.field_names.len()
        )));
    }
    Ok(())
}

/// Runtime value in the Surtr VM.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Int(SurtrInt),
    Tag(RuntimeTag),
    Float(f64),
    Str(String),
    Bool(bool),
    Unit,
    List(ListHandle),
    HashMap(HashMapHandle),
    Tuple(Vec<Value>),
    Tagged { tag: u32, fields: Vec<Value> },
    Callable(Callable),
    Error(Box<RichError>),
    ErrorKind(String),
    Regex(RegexHandle),
    RegexCaptures(RegexCapturesHandle),
    RegexMatch(RegexMatchHandle),
    RandomGenerator(RandomGeneratorHandle),
    Generator(GeneratorHandle),
    InfiniteGenerator(InfiniteGeneratorHandle),
    Pid(PidHandle),
    FileHandle(FileHandleValue),
    Workers(WorkersHandle),
    WorkerLease(WorkerLeaseHandle),
    TaskHandle(u64),
    PendingFuture(u64),
}

#[derive(Debug, Clone, PartialEq)]
pub struct RegexHandle {
    pub pattern: String,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RegexCapturesHandle {
    pub input: String,
    pub groups: Vec<Option<(usize, usize)>>,
    pub name_to_index: HashMap<String, usize>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RegexMatchHandle {
    pub input: String,
    pub start: usize,
    pub end: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RandomGeneratorHandle {
    pub state: u64,
}

/// Immutable finite producer. Advancing creates a new handle.
#[derive(Debug, Clone, PartialEq)]
pub struct GeneratorHandle(pub Arc<GeneratorProducer>);

#[derive(Debug, Clone, PartialEq)]
pub enum GeneratorProducer {
    Unfold {
        state: Value,
        step: Callable,
    },
    Range {
        current: SurtrInt,
        stop: SurtrInt,
        step: SurtrInt,
    },
    RangeChar {
        current: SurtrInt,
        stop: SurtrInt,
        step: SurtrInt,
    },
    Terminal,
}

/// Immutable infinite producer with an erased internal state type.
#[derive(Debug, Clone, PartialEq)]
pub struct InfiniteGeneratorHandle(pub Arc<InfiniteGeneratorProducer>);

#[derive(Debug, Clone, PartialEq)]
pub enum InfiniteGeneratorProducer {
    Unfold { state: Value, step: Callable },
}

/// Immutable capability category; handler PIDs do not identify processes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PidKind {
    Singleton,
    Worker,
    Handler,
}

/// Shared identity only. It must never retain process state or a VM context.
#[derive(Debug, PartialEq, Eq)]
pub struct PidIdentity {
    pub id: u64,
    pub process_name: String,
    pub kind: PidKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PidHandle {
    identity: Rc<PidIdentity>,
}

impl PidHandle {
    pub fn new(id: u64, process_name: String, kind: PidKind) -> Self {
        Self {
            identity: Rc::new(PidIdentity {
                id,
                process_name,
                kind,
            }),
        }
    }

    pub fn identity(&self) -> &Rc<PidIdentity> {
        &self.identity
    }

    /// Runtime authority is the shared identity, not a coincidentally equal ID.
    pub fn same_identity(&self, other: &Self) -> bool {
        Rc::ptr_eq(&self.identity, &other.identity)
    }
}

impl std::ops::Deref for PidHandle {
    type Target = PidIdentity;

    fn deref(&self) -> &Self::Target {
        &self.identity
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FileHandleValue {
    pub id: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkersHandle {
    pub id: u64,
    pub process_name: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkerLeaseHandle {
    pub workers_id: u64,
    pub pid: PidHandle,
}

/// Shared runtime handle for immutable string-keyed maps.
#[derive(Debug, Clone, PartialEq)]
pub struct HashMapHandle {
    pub entries: HashMap<String, Value>,
}

/// Immutable persistent sequence with a cached logical length.
/// Empty is canonical; Cons and Packed always contain at least one element.
#[derive(Clone)]
pub struct ListHandle {
    repr: ListRepr,
    len: usize,
}

#[derive(Clone)]
enum ListRepr {
    Empty,
    Cons(Rc<ListConsNode>),
    Packed(PackedList),
}

struct ListConsNode {
    value: Value,
    tail: ListHandle,
}

#[derive(Clone)]
struct PackedList {
    items: Rc<Vec<Value>>,
    offset: usize,
}

/// Callable runtime value.
#[derive(Debug, Clone, PartialEq)]
pub struct Callable {
    pub target: CallableTarget,
    pub lexical_captures: Vec<Value>,
    pub metadata: CallableMetadata,
}

/// Callable target reference.
#[derive(Debug, Clone, PartialEq)]
pub enum CallableTarget {
    Builtin(BuiltinId),
    Function(FunctionId),
    Template(u32),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CallableMetadata {
    pub origin: CallableOrigin,
    pub module: Option<String>,
    pub name: Option<String>,
    pub full_signature: Option<String>,
    /// A synthesized callable may explicitly inherit display origin and
    /// identity from one callable-valued lexical capture.
    pub origin_source: Option<usize>,
    /// Direct user-function target of a generated wrapper callable, when one
    /// exists. Runtime process initialization uses this without changing the
    /// wrapper's display origin.
    pub delegate_function: Option<u32>,
}

impl Default for CallableMetadata {
    fn default() -> Self {
        Self {
            origin: CallableOrigin::Unknown,
            module: None,
            name: None,
            full_signature: None,
            origin_source: None,
            delegate_function: None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CallableOrigin {
    Unknown,
    Closure,
    Capture,
}

/// Invalid runtime representation encountered while displaying a value.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ValueDisplayError {
    message: String,
}

impl ValueDisplayError {
    fn new(message: impl Into<String>) -> Self {
        Self {
            message: message.into(),
        }
    }
}

impl fmt::Display for ValueDisplayError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for ValueDisplayError {}

impl TypeRegistry {
    /// Check the shape before either diagnostic display or VM inspect renders fields.
    pub fn validate_display_fields(
        &self,
        tag: RuntimeTag,
        fields: &[Value],
    ) -> Result<(), ValueDisplayError> {
        let expected = match self.lookup(tag) {
            Some(entry) => {
                entry.field_names.len() + usize::from(entry.kind == TypeKind::EnumVariant)
            }
            None if tag == 0 || tag == 1 => 1,
            None => {
                return Err(ValueDisplayError::new(format!(
                    "unknown runtime tag: {tag}"
                )))
            }
        };
        if fields.len() != expected {
            return Err(ValueDisplayError::new(format!(
                "invalid runtime payload for tag {tag}: expected {expected} fields, got {}",
                fields.len()
            )));
        }
        if let Some(entry) = self.lookup(tag) {
            if entry.kind == TypeKind::EnumVariant && !matches!(fields.first(), Some(Value::Int(_)))
            {
                return Err(ValueDisplayError::new(format!(
                    "invalid enum discriminant for tag {tag}"
                )));
            }
        }
        Ok(())
    }
}

impl Value {
    fn render_named_value(
        type_name: &str,
        field_names: &[String],
        fields: &[Value],
        registry: &TypeRegistry,
    ) -> Result<String, ValueDisplayError> {
        let parts = field_names
            .iter()
            .zip(fields.iter())
            .map(|(name, val)| Ok(format!("{}: {}", name, val.to_display_string(registry)?)))
            .collect::<Result<Vec<_>, ValueDisplayError>>()?;

        Ok(format!(
            "{}({})",
            surface_path_name(type_name),
            parts.join(", ")
        ))
    }

    /// Generic value display for runtime diagnostics.
    pub fn to_display_string(&self, registry: &TypeRegistry) -> Result<String, ValueDisplayError> {
        Ok(match self {
            Value::Int(n) => n.to_string(),
            Value::Tag(tag) => format!("<tag:{}>", tag),
            Value::Float(f) => {
                let s = format!("{}", f);
                if s.contains('.') {
                    s
                } else {
                    format!("{}.0", s)
                }
            }
            Value::Str(s) => s.clone(),
            Value::Bool(b) => {
                if *b {
                    "True".to_string()
                } else {
                    "False".to_string()
                }
            }
            Value::Unit => "()".to_string(),
            Value::List(handle) => {
                let inner = handle
                    .iter()
                    .map(|item| item.to_display_string(registry))
                    .collect::<Result<Vec<_>, ValueDisplayError>>()?
                    .join(", ");
                format!("[{}]", inner)
            }
            Value::HashMap(handle) => {
                if handle.entries.is_empty() {
                    return Ok("hash![]".to_string());
                }
                let inner = handle
                    .sorted_entries()
                    .into_iter()
                    .map(|(key, value)| {
                        Ok(format!(
                            "{} => {}",
                            quote_surtr_string_literal(&key),
                            value.to_display_string(registry)?
                        ))
                    })
                    .collect::<Result<Vec<_>, ValueDisplayError>>()?
                    .join(", ");
                format!("hash![{inner}]")
            }
            Value::Tuple(items) => {
                let inner = items
                    .iter()
                    .map(|item| item.to_display_string(registry))
                    .collect::<Result<Vec<_>, ValueDisplayError>>()?
                    .join(", ");
                format!("({inner})")
            }
            Value::Tagged { tag, fields } => {
                registry.validate_display_fields(*tag, fields)?;
                if let Some(entry) = registry.lookup(*tag) {
                    if surface_path_name(&entry.name) == "Duration" {
                        if let Some(Value::Int(ms)) = fields.first() {
                            return Ok(format!("{ms}ms"));
                        }
                    }
                    match entry.kind {
                        TypeKind::Struct | TypeKind::Record => Self::render_named_value(
                            &entry.name,
                            &entry.field_names,
                            fields,
                            registry,
                        )?,
                        TypeKind::EnumVariant => {
                            let payload = fields
                                .iter()
                                .skip(1)
                                .map(|val| val.to_display_string(registry))
                                .collect::<Result<Vec<_>, ValueDisplayError>>()?
                                .join(", ");
                            if payload.is_empty() {
                                surface_path_name(&entry.name).to_string()
                            } else {
                                format!("{}({})", surface_path_name(&entry.name), payload)
                            }
                        }
                    }
                } else {
                    match *tag {
                        0 => format!("Ok({})", fields[0].to_display_string(registry)?),
                        1 => match &fields[0] {
                            Value::Error(rich) => rich.to_result_display_string(),
                            value => format!("Err({})", value.to_display_string(registry)?),
                        },
                        _ => {
                            return Err(ValueDisplayError::new(format!(
                                "unknown runtime tag: {tag}"
                            )))
                        }
                    }
                }
            }
            Value::Callable(callable) => match callable.target {
                CallableTarget::Builtin(id) => format!("<builtin:{}>", id),
                CallableTarget::Function(fun_idx) => {
                    format!(
                        "<function:{}; lexical_captures={}>",
                        fun_idx,
                        callable.lexical_captures.len()
                    )
                }
                CallableTarget::Template(template_id) => {
                    format!(
                        "<template:{}; lexical_captures={}>",
                        template_id,
                        callable.lexical_captures.len()
                    )
                }
            },
            Value::Error(rich) => rich.to_display_string(),
            Value::ErrorKind(kind) => format!("ErrorKind({kind})"),
            Value::Regex(handle) => format!("Regex({:?})", handle.pattern),
            Value::RegexCaptures(handle) => {
                format!("RegexCaptures(groups: {})", handle.groups.len())
            }
            Value::RegexMatch(handle) => format!("RegexMatch({}..{})", handle.start, handle.end),
            Value::RandomGenerator(_) => "RandomGenerator(<opaque>)".to_string(),
            Value::Generator(_) => "Generator(<opaque>)".to_string(),
            Value::InfiniteGenerator(_) => "InfiniteGenerator(<opaque>)".to_string(),
            Value::Pid(handle) => format!(
                "PID({}#{})",
                surface_path_name(&handle.process_name),
                handle.id
            ),
            Value::FileHandle(handle) => format!("FileHandle#{}", handle.id),
            Value::Workers(handle) => format!("Workers<{}>#{}", handle.process_name, handle.id),
            Value::WorkerLease(handle) => {
                format!("WorkerLease<{}>#{}", handle.pid.process_name, handle.pid.id)
            }
            Value::TaskHandle(future_id) => format!("TaskHandle#{future_id}"),
            Value::PendingFuture(future_id) => format!("<pending:future#{future_id}>"),
        })
    }
}

pub fn quote_surtr_string_literal(input: &str) -> String {
    use std::fmt::Write;

    let mut out = String::with_capacity(input.len() + 2);
    out.push('"');
    let mut chars = input.chars().peekable();
    while let Some(ch) = chars.next() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\u{0}'..='\u{1f}' | '\u{7f}'..='\u{9f}' => {
                write!(out, "\\u{{{:x}}}", ch as u32).expect("writing to String cannot fail");
            }
            '#' if chars.peek() == Some(&'{') => out.push_str("\\#"),
            _ => out.push(ch),
        }
    }
    out.push('"');
    out
}

fn visible_runtime_error_message(message: &str) -> &str {
    message
}

impl HashMapHandle {
    pub fn empty() -> Self {
        Self {
            entries: HashMap::new(),
        }
    }

    pub fn from_entries(entries: Vec<(String, Value)>) -> Self {
        let mut map = Self::empty();
        for (key, value) in entries {
            map = map.insert(key, value);
        }
        map
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn contains_key(&self, key: &str) -> bool {
        self.entries.contains_key(key)
    }

    pub fn get(&self, key: &str) -> Option<Value> {
        self.entries.get(key).cloned()
    }

    pub fn insert(&self, key: String, value: Value) -> Self {
        let mut entries = self.entries.clone();
        entries.insert(key, value);
        Self { entries }
    }

    pub fn remove(&self, key: &str) -> Self {
        if !self.entries.contains_key(key) {
            return self.clone();
        }
        let mut entries = self.entries.clone();
        entries.remove(key);
        Self { entries }
    }

    pub fn keys(&self) -> Vec<String> {
        self.sorted_entries()
            .into_iter()
            .map(|(key, _)| key)
            .collect()
    }

    pub fn values(&self) -> Vec<Value> {
        self.sorted_entries()
            .into_iter()
            .map(|(_, value)| value)
            .collect()
    }

    pub fn sorted_entries(&self) -> Vec<(String, Value)> {
        let mut entries = self
            .entries
            .iter()
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect::<Vec<_>>();
        entries.sort_by(|left, right| left.0.cmp(&right.0));
        entries
    }
}

impl ListHandle {
    pub fn empty() -> Self {
        Self {
            repr: ListRepr::Empty,
            len: 0,
        }
    }

    pub fn cons(head: Value, tail: &ListHandle) -> Self {
        let len = tail.len.checked_add(1).expect("List length overflow");
        Self {
            repr: ListRepr::Cons(Rc::new(ListConsNode {
                value: head,
                tail: tail.clone(),
            })),
            len,
        }
    }

    /// Move the buffer into immutable storage without rebuilding its elements.
    pub fn from_items(items: Vec<Value>) -> Self {
        let len = items.len();
        if len == 0 {
            Self::empty()
        } else {
            Self {
                repr: ListRepr::Packed(PackedList {
                    items: Rc::new(items),
                    offset: 0,
                }),
                len,
            }
        }
    }

    pub fn len(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn head_value(&self) -> Option<Value> {
        match &self.repr {
            ListRepr::Empty => None,
            ListRepr::Cons(node) => Some(node.value.clone()),
            ListRepr::Packed(packed) => Some(packed.items[packed.offset].clone()),
        }
    }

    pub fn tail_handle(&self) -> Option<Self> {
        match &self.repr {
            ListRepr::Empty => None,
            ListRepr::Cons(node) => Some(node.tail.clone()),
            ListRepr::Packed(packed) => {
                let len = self
                    .len
                    .checked_sub(1)
                    .expect("nonempty Packed List length");
                Some(if len == 0 {
                    Self::empty()
                } else {
                    Self {
                        repr: ListRepr::Packed(PackedList {
                            items: Rc::clone(&packed.items),
                            offset: packed
                                .offset
                                .checked_add(1)
                                .expect("Packed List offset overflow"),
                        }),
                        len,
                    }
                })
            }
        }
    }

    pub fn iter(&self) -> ListIter {
        ListIter {
            remaining: self.clone(),
        }
    }
}

impl Drop for ListHandle {
    fn drop(&mut self) {
        let mut repr = std::mem::replace(&mut self.repr, ListRepr::Empty);
        while let ListRepr::Cons(node) = repr {
            // A shared tail remains owned by its other handles.
            let Ok(mut node) = Rc::try_unwrap(node) else {
                break;
            };
            // Keep the existing head-before-tail destruction order. Only the
            // tail chain is iterative; nested Values use their own destructors.
            drop(node.value);
            repr = std::mem::replace(&mut node.tail.repr, ListRepr::Empty);
        }
    }
}

impl PartialEq for ListHandle {
    fn eq(&self, other: &Self) -> bool {
        self.len == other.len && self.iter().eq(other.iter())
    }
}

impl fmt::Debug for ListHandle {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

pub struct ListIter {
    remaining: ListHandle,
}

impl Iterator for ListIter {
    type Item = Value;

    fn next(&mut self) -> Option<Self::Item> {
        let value = self.remaining.head_value()?;
        self.remaining = self
            .remaining
            .tail_handle()
            .expect("nonempty List has a tail");
        Some(value)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.remaining.len, Some(self.remaining.len))
    }
}

impl ExactSizeIterator for ListIter {}
impl std::iter::FusedIterator for ListIter {}

/// Rich error value produced by `deferror`.
#[derive(Debug, Clone, PartialEq)]
pub enum RuntimeErrorDiagnostic {
    LiteralPatternMismatch {
        lhs: String,
        rhs: String,
    },
    SafeBindPatternFailure {
        rule: String,
        input_source: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RuntimeExecutionPhase {
    VmInit,
    Runtime,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RuntimeCallKind {
    DirectFunction,
    ClosureFunction,
    Builtin,
    CallableTemplate,
    ProcessMessage,
    Task,
    StandbyInit,
    EagerInit,
}

#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct RuntimeProcessTraceContext {
    pub pid: Option<u64>,
    pub process_name: Option<String>,
    pub trigger: Option<String>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct RuntimeStackFrame {
    pub phase: RuntimeExecutionPhase,
    pub function: Option<String>,
    pub fun_idx: Option<u32>,
    pub call_kind: RuntimeCallKind,
    pub location: Option<Location>,
    pub process: Option<RuntimeProcessTraceContext>,
    pub tco: bool,
}

/// Rich error value produced by `deferror`.
#[derive(Debug, Clone, PartialEq)]
pub struct RichError {
    pub kind: String,
    pub message: String,
    /// Declaration-ordered, heterogeneous Error payload; empty errors use the same representation.
    pub payload: Vec<Value>,
    pub location: Location,
    pub cause: Option<Box<RichError>>,
    pub diagnostic: Option<RuntimeErrorDiagnostic>,
    pub stack_trace: Vec<RuntimeStackFrame>,
}

impl RichError {
    pub fn new(
        kind: impl Into<String>,
        message: impl Into<String>,
        location: Location,
        cause: Option<Box<RichError>>,
    ) -> Self {
        let kind = kind.into();
        Self {
            kind,
            message: message.into(),
            payload: Vec::new(),
            location,
            cause,
            diagnostic: None,
            stack_trace: Vec::new(),
        }
    }

    pub fn with_diagnostic(mut self, diagnostic: RuntimeErrorDiagnostic) -> Self {
        self.diagnostic = Some(diagnostic);
        self
    }

    pub fn with_stack_trace(mut self, stack_trace: Vec<RuntimeStackFrame>) -> Self {
        self.stack_trace = stack_trace;
        self
    }

    pub fn primary_location(&self) -> &Location {
        &self.location
    }

    pub fn visible_message(&self) -> &str {
        visible_runtime_error_message(&self.message)
    }

    pub fn to_display_string(&self) -> String {
        self.to_display_lines().join("\n")
    }

    pub fn to_result_display_string(&self) -> String {
        let lines = self.to_display_lines();
        let Some((head, tail)) = lines.split_first() else {
            return "Err()".to_string();
        };

        let mut rendered = format!("Err({})", head);
        for line in tail {
            rendered.push('\n');
            rendered.push_str(line);
        }
        rendered
    }

    pub fn to_eprint_lines(&self) -> Vec<String> {
        let display_kind = surface_path_name(&self.kind);
        let mut lines = vec![format!(
            "Error: {}: {}",
            display_kind,
            self.visible_message()
        )];
        let mut next = self.cause.as_deref();
        while let Some(cause) = next {
            let cause_kind = surface_path_name(&cause.kind);
            lines.push(format!(
                "Caused by: {}: {}",
                cause_kind,
                cause.visible_message()
            ));
            next = cause.cause.as_deref();
        }
        lines
    }

    pub fn append_cause_tail(&mut self, cause: RichError) {
        match self.cause.as_mut() {
            Some(existing) => existing.append_cause_tail(cause),
            None => self.cause = Some(Box::new(cause)),
        }
    }

    fn to_display_lines(&self) -> Vec<String> {
        let mut lines = Vec::new();
        self.push_display_lines(&mut lines, "", "");
        lines
    }

    fn push_display_lines(&self, lines: &mut Vec<String>, first_prefix: &str, child_prefix: &str) {
        lines.push(format!(
            "{}{}({:?})",
            first_prefix,
            surface_path_name(&self.kind),
            self.visible_message()
        ));
        if let Some(cause) = self.cause.as_deref() {
            cause.push_display_lines(
                lines,
                &format!("{}|_ ", child_prefix),
                &format!("{}   ", child_prefix),
            );
        }
    }
}

/// Source location for error reporting.
#[derive(Debug, Clone, PartialEq)]
pub struct Location {
    pub file: String,
    pub func: String,
    pub line: u32,
    pub column: u32,
    pub span_start: u32,
    pub span_end: u32,
}

#[cfg(test)]
mod tests {
    #[test]
    fn error_kind_display_preserves_canonical_identity_inside_containers() {
        let value = super::Value::Tuple(vec![
            super::Value::ErrorKind("One::Failure".into()),
            super::Value::List(super::ListHandle::from_items(vec![
                super::Value::ErrorKind("Two::Failure".into()),
            ])),
        ]);
        assert_eq!(
            value
                .to_display_string(&super::TypeRegistry::new())
                .unwrap(),
            "(ErrorKind(One::Failure), [ErrorKind(Two::Failure)])"
        );
    }

    #[test]
    fn pid_copy_and_lease_share_identity_without_retaining_process_state() {
        let pid = super::PidHandle::new(7, "Global::Worker".into(), super::PidKind::Worker);
        let weak = std::rc::Rc::downgrade(pid.identity());
        let copy = pid.clone();
        let lease = super::WorkerLeaseHandle {
            workers_id: 2,
            pid: copy,
        };
        assert!(pid.same_identity(&lease.pid));
        assert!(!pid.same_identity(&super::PidHandle::new(
            7,
            "Global::Worker".into(),
            super::PidKind::Worker,
        )));
        drop(pid);
        assert!(weak.upgrade().is_some());
        drop(lease);
        assert!(weak.upgrade().is_none());
    }

    #[test]
    fn pid_identity_distinguishes_process_and_handler_capabilities() {
        let worker = super::PidHandle::new(1, "Global::OutHandler".into(), super::PidKind::Worker);
        let handler =
            super::PidHandle::new(1, "Global::OutHandler".into(), super::PidKind::Handler);
        assert_ne!(worker.kind, handler.kind);
        assert!(!worker.same_identity(&handler));
    }

    use super::{
        quote_surtr_string_literal, Callable, CallableMetadata, CallableTarget, HashMapHandle,
        ListHandle, Location, RichError, RuntimeErrorDiagnostic, TypeEntry, TypeKind, TypeRegistry,
        Value,
    };
    use super::{RuntimeCallKind, RuntimeExecutionPhase, RuntimeStackFrame};
    use crate::primitives::int;

    #[test]
    fn string_literal_quote_canonicalizes_all_terminal_controls() {
        // The expected source spelling is the language contract, independent of
        // the implementation's control-character classification.
        for (input, expected) in [
            ("\0\u{1}\u{8}", r#""\u{0}\u{1}\u{8}""#),
            ("\t\n\u{b}\u{c}\r", r#""\t\n\u{b}\u{c}\u{d}""#),
            (
                "\u{1b}a\u{1f}\u{7f}\u{80}\u{85}\u{9f}",
                r#""\u{1b}a\u{1f}\u{7f}\u{80}\u{85}\u{9f}""#,
            ),
            ("\\\"'#{name}\\u{1b}あ😀", r#""\\\"'\#{name}\\u{1b}あ😀""#),
            ("\\#{name}", r#""\\\#{name}""#),
            ("# #{{ #{#{", r##""# \#{{ \#{\#{""##),
        ] {
            assert_eq!(quote_surtr_string_literal(input), expected);
        }

        let controls: String = (0..=0x1f)
            .chain(0x7f..=0x9f)
            .map(|code| char::from_u32(code).unwrap())
            .collect();
        let quoted = quote_surtr_string_literal(&controls);
        assert!(!quoted.chars().any(char::is_control), "{quoted:?}");
    }

    #[test]
    fn display_rejects_invalid_tagged_values() {
        let registry = TypeRegistry::from_entries(vec![
            TypeEntry {
                tag: 10,
                name: "Row".into(),
                kind: TypeKind::Record,
                field_names: vec!["value".into()],
                private_flags: vec![false],
            },
            TypeEntry {
                tag: 11,
                name: "Box".into(),
                kind: TypeKind::Struct,
                field_names: vec!["value".into()],
                private_flags: vec![false],
            },
            TypeEntry {
                tag: 12,
                name: "Choice::Some".into(),
                kind: TypeKind::EnumVariant,
                field_names: vec!["value".into()],
                private_flags: vec![false],
            },
        ]);
        for (tag, fields) in [
            (0, vec![]),
            (1, vec![]),
            (9999, vec![]),
            (0, vec![Value::Unit, Value::Unit]),
            (10, vec![]),
            (10, vec![Value::Unit, Value::Unit]),
            (11, vec![]),
            (11, vec![Value::Unit, Value::Unit]),
            (12, vec![Value::Int(int(0))]),
            (12, vec![Value::Unit, Value::Unit]),
        ] {
            let value = Value::Tagged { tag, fields };
            assert!(
                value.to_display_string(&registry).is_err(),
                "invalid runtime value must fail display: {value:?}"
            );
        }
        let invalid = Value::Tagged {
            tag: 9999,
            fields: vec![],
        };
        for value in [
            Value::Tuple(vec![invalid.clone()]),
            Value::List(ListHandle::from_items(vec![invalid.clone()])),
            Value::HashMap(HashMapHandle::empty().insert("key".into(), invalid.clone())),
            Value::Tagged {
                tag: 0,
                fields: vec![invalid.clone()],
            },
            Value::Tagged {
                tag: 1,
                fields: vec![invalid.clone()],
            },
            Value::Tagged {
                tag: 10,
                fields: vec![invalid.clone()],
            },
            Value::Tagged {
                tag: 11,
                fields: vec![invalid.clone()],
            },
            Value::Tagged {
                tag: 12,
                fields: vec![Value::Int(int(0)), invalid],
            },
        ] {
            assert_eq!(
                value.to_display_string(&registry).unwrap_err().to_string(),
                "unknown runtime tag: 9999"
            );
        }
        let valid = Value::Tagged {
            tag: 12,
            fields: vec![Value::Int(int(0)), Value::Unit],
        };
        assert_eq!(
            valid.to_display_string(&registry).unwrap(),
            "Choice::Some(())"
        );
    }

    #[test]
    fn display_for_reserved_result_tags() {
        let registry = TypeRegistry::new();
        let ok = Value::Tagged {
            tag: 0,
            fields: vec![Value::Int(int(42))],
        };
        let err = Value::Tagged {
            tag: 1,
            fields: vec![Value::Str("bad".into())],
        };
        assert_eq!(ok.to_display_string(&registry).unwrap(), "Ok(42)");
        assert_eq!(err.to_display_string(&registry).unwrap(), "Err(bad)");
    }

    #[test]
    fn display_for_registered_struct_and_record() {
        let mut registry = TypeRegistry::new();
        registry.register(TypeEntry {
            tag: 10,
            name: "User".into(),
            kind: TypeKind::Struct,
            field_names: vec!["name".into(), "age".into()],
            private_flags: vec![false, false],
        });
        registry.register(TypeEntry {
            tag: 11,
            name: "Pair".into(),
            kind: TypeKind::Record,
            field_names: vec!["left".into(), "right".into()],
            private_flags: vec![false, false],
        });
        registry.register(TypeEntry {
            tag: 12,
            name: "SecretUser".into(),
            kind: TypeKind::Struct,
            field_names: vec!["name".into(), "password".into()],
            private_flags: vec![false, true],
        });

        let user = Value::Tagged {
            tag: 10,
            fields: vec![Value::Str("alice".into()), Value::Int(int(20))],
        };
        let pair = Value::Tagged {
            tag: 11,
            fields: vec![Value::Int(int(1)), Value::Int(int(2))],
        };
        let secret_user = Value::Tagged {
            tag: 12,
            fields: vec![Value::Str("alice".into()), Value::Str("s3cr3t".into())],
        };

        assert_eq!(
            user.to_display_string(&registry).unwrap(),
            "User(name: alice, age: 20)"
        );
        assert_eq!(
            pair.to_display_string(&registry).unwrap(),
            "Pair(left: 1, right: 2)"
        );
        assert_eq!(
            secret_user.to_display_string(&registry).unwrap(),
            "SecretUser(name: alice, password: s3cr3t)"
        );
    }

    #[test]
    fn rich_error_primary_location_keeps_creation_span_with_call_trace() {
        let creation = Location {
            file: "sample.srt".into(),
            func: "Failure".into(),
            line: 2,
            column: 3,
            span_start: 20,
            span_end: 27,
        };
        let mut error = RichError::new("Failure", "failed", creation.clone(), None);
        error.stack_trace.push(RuntimeStackFrame {
            phase: RuntimeExecutionPhase::Runtime,
            function: Some("main".into()),
            fun_idx: Some(0),
            call_kind: RuntimeCallKind::DirectFunction,
            location: Some(Location {
                file: "sample.srt".into(),
                func: "main".into(),
                line: 8,
                column: 1,
                span_start: 80,
                span_end: 86,
            }),
            process: None,
            tco: false,
        });
        assert_eq!(error.primary_location(), &creation);
        assert_eq!(error.stack_trace[0].location.as_ref().unwrap().line, 8);
    }

    #[test]
    fn display_for_rich_error_uses_message() {
        let registry = TypeRegistry::new();
        let value = Value::Error(Box::new(RichError {
            kind: "TestError".into(),
            message: "boom".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        }));
        assert_eq!(
            value.to_display_string(&registry).unwrap(),
            "TestError(\"boom\")"
        );
    }

    #[test]
    fn display_for_rich_error_renders_tree_when_causes_exist() {
        let registry = TypeRegistry::new();
        let mut value = RichError {
            kind: "Outer".into(),
            message: "outer".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        };
        value.append_cause_tail(RichError {
            kind: "Inner".into(),
            message: "inner".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        });
        value.append_cause_tail(RichError {
            kind: "Leaf".into(),
            message: "leaf".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        });

        let rendered = Value::Error(Box::new(value));
        assert_eq!(
            rendered.to_display_string(&registry).unwrap(),
            "Outer(\"outer\")\n|_ Inner(\"inner\")\n   |_ Leaf(\"leaf\")"
        );
    }

    #[test]
    fn list_display_uses_cons_handle_shape() {
        let registry = TypeRegistry::new();
        let value = Value::List(ListHandle::from_items(vec![
            Value::Int(int(1)),
            Value::Int(int(2)),
            Value::Int(int(3)),
        ]));
        assert_eq!(value.to_display_string(&registry).unwrap(), "[1, 2, 3]");
    }

    #[test]
    fn hash_map_handle_insert_overwrite_and_remove_use_sorted_key_order() {
        let empty = HashMapHandle::empty();
        let with_b = empty.insert("b".into(), Value::Int(int(2)));
        let with_ba = with_b.insert("a".into(), Value::Int(int(1)));
        let with_overwrite = with_ba.insert("a".into(), Value::Int(int(3)));

        assert_eq!(with_overwrite.len(), 2);
        assert_eq!(
            with_overwrite.keys(),
            vec!["a".to_string(), "b".to_string()]
        );
        assert_eq!(
            with_overwrite.values(),
            vec![Value::Int(int(3)), Value::Int(int(2))]
        );
        assert_eq!(with_overwrite.get("a"), Some(Value::Int(int(3))));

        let removed = with_overwrite.remove("b");
        assert_eq!(removed.keys(), vec!["a".to_string()]);
        let no_op = removed.remove("missing");
        assert_eq!(no_op, removed);
    }

    #[test]
    fn hash_map_display_uses_named_shape_and_key_escaping() {
        let registry = TypeRegistry::new();
        let value = Value::HashMap(HashMapHandle::from_entries(vec![
            ("line\nfeed".into(), Value::Int(int(1))),
            ("path\\to".into(), Value::Int(int(2))),
            ("say\"hi".into(), Value::Int(int(3))),
            ("tab\tchar".into(), Value::Int(int(4))),
        ]));
        assert_eq!(
            value.to_display_string(&registry).unwrap(),
            "hash![\"line\\nfeed\" => 1, \"path\\\\to\" => 2, \"say\\\"hi\" => 3, \"tab\\tchar\" => 4]"
        );
    }

    #[test]
    fn type_registry_lookup_supports_sparse_tags() {
        let registry = TypeRegistry::from_entries(vec![
            TypeEntry {
                tag: 10,
                name: "Global::User".into(),
                kind: TypeKind::Struct,
                field_names: vec!["name".into()],
                private_flags: vec![false],
            },
            TypeEntry {
                tag: 42,
                name: "Global::Profile".into(),
                kind: TypeKind::Struct,
                field_names: vec!["id".into()],
                private_flags: vec![false],
            },
        ]);

        assert_eq!(
            registry.lookup(10).map(|entry| entry.name.as_str()),
            Some("Global::User")
        );
        assert_eq!(
            registry.lookup(42).map(|entry| entry.name.as_str()),
            Some("Global::Profile")
        );
        assert_eq!(registry.lookup(11), None);
    }

    #[test]
    fn type_registry_extend_preserves_existing_and_new_lookups() {
        let mut registry = TypeRegistry::from_entries(vec![TypeEntry {
            tag: 10,
            name: "Global::User".into(),
            kind: TypeKind::Struct,
            field_names: vec!["name".into()],
            private_flags: vec![false],
        }]);

        registry.extend(vec![TypeEntry {
            tag: 42,
            name: "Global::Profile".into(),
            kind: TypeKind::Struct,
            field_names: vec!["id".into()],
            private_flags: vec![false],
        }]);

        assert_eq!(registry.entries().len(), 2);
        assert_eq!(
            registry.lookup(10).map(|entry| entry.name.as_str()),
            Some("Global::User")
        );
        assert_eq!(
            registry.lookup(42).map(|entry| entry.name.as_str()),
            Some("Global::Profile")
        );
    }

    #[test]
    fn type_registry_try_extend_rejects_reserved_and_duplicate_tags() {
        let mut registry = TypeRegistry::from_entries(vec![TypeEntry {
            tag: 10,
            name: "Global::User".into(),
            kind: TypeKind::Struct,
            field_names: vec!["name".into()],
            private_flags: vec![false],
        }]);

        let reserved = registry.try_register(TypeEntry {
            tag: 0,
            name: "Global::BadOk".into(),
            kind: TypeKind::Struct,
            field_names: Vec::new(),
            private_flags: Vec::new(),
        });
        assert!(reserved
            .expect_err("reserved tags must be rejected")
            .to_string()
            .contains("reserved result tag"));

        let duplicate = registry.try_register(TypeEntry {
            tag: 10,
            name: "Global::OtherUser".into(),
            kind: TypeKind::Struct,
            field_names: vec!["id".into()],
            private_flags: vec![false],
        });
        assert!(duplicate
            .expect_err("duplicate tags must be rejected")
            .to_string()
            .contains("duplicate type tag"));
    }

    #[test]
    fn type_registry_try_register_rejects_incompatible_name_and_privacy_shape() {
        let mut registry = TypeRegistry::from_entries(vec![TypeEntry {
            tag: 10,
            name: "Global::User".into(),
            kind: TypeKind::Struct,
            field_names: vec!["name".into()],
            private_flags: vec![false],
        }]);

        let duplicate_name = registry.try_register(TypeEntry {
            tag: 11,
            name: "Global::User".into(),
            kind: TypeKind::Record,
            field_names: vec!["name".into(), "age".into()],
            private_flags: vec![false, false],
        });
        assert!(duplicate_name
            .expect_err("incompatible duplicate names must be rejected")
            .to_string()
            .contains("duplicate type name"));

        let bad_privacy_shape = registry.try_register(TypeEntry {
            tag: 12,
            name: "Global::Profile".into(),
            kind: TypeKind::Struct,
            field_names: vec!["id".into(), "label".into()],
            private_flags: vec![false],
        });
        assert!(bad_privacy_shape
            .expect_err("privacy flag count must match fields")
            .to_string()
            .contains("private_flags length"));
    }

    #[test]
    fn packed_lists_move_and_share_the_original_buffer_at_every_length() {
        for len in [1, 8, 1024] {
            let items = (0..len).map(|n| Value::Int(int(n))).collect::<Vec<_>>();
            let allocation = items.as_ptr();
            let packed = ListHandle::from_items(items);
            let super::ListRepr::Packed(storage) = &packed.repr else {
                panic!("nonempty from_items must be Packed")
            };
            assert_eq!(storage.items.as_ptr(), allocation);
            assert_eq!(storage.offset, 0);
            assert_eq!(packed.len(), len as usize);
            let with_head = ListHandle::cons(Value::Unit, &packed);
            let super::ListRepr::Cons(node) = &with_head.repr else {
                panic!("cons must allocate one Cons")
            };
            let super::ListRepr::Packed(shared_tail) = &node.tail.repr else {
                panic!("cons must preserve Packed tail")
            };
            assert!(std::rc::Rc::ptr_eq(&storage.items, &shared_tail.items));
            let mut cursor = packed.clone();
            for offset in 0..len {
                let super::ListRepr::Packed(current) = &cursor.repr else {
                    panic!("tail must stay Packed")
                };
                assert!(std::rc::Rc::ptr_eq(&storage.items, &current.items));
                assert_eq!(current.offset, offset as usize);
                assert_eq!(cursor.len(), (len - offset) as usize);
                assert_eq!(cursor.head_value(), Some(Value::Int(int(offset))));
                cursor = cursor.tail_handle().unwrap();
            }
            assert!(matches!(cursor.repr, super::ListRepr::Empty));
            assert_eq!(cursor.len(), 0);
            assert!(matches!(
                ListHandle::from_items(vec![]).repr,
                super::ListRepr::Empty
            ));
        }
    }

    #[test]
    fn cons_drop_releases_unique_nodes_and_preserves_shared_storage() {
        use std::rc::Rc;

        let packed = ListHandle::from_items(vec![Value::Bool(true)]);
        let super::ListRepr::Packed(storage) = &packed.repr else {
            unreachable!()
        };
        let buffer = Rc::downgrade(&storage.items);
        let shared_tail = ListHandle::cons(Value::Bool(false), &packed);
        let super::ListRepr::Cons(node) = &shared_tail.repr else {
            unreachable!()
        };
        let tail_node = Rc::downgrade(node);
        let element_list = ListHandle::cons(Value::Unit, &ListHandle::empty());
        let super::ListRepr::Cons(node) = &element_list.repr else {
            unreachable!()
        };
        let element_node = Rc::downgrade(node);
        let list = ListHandle::cons(Value::List(element_list), &shared_tail);
        let super::ListRepr::Cons(node) = &list.repr else {
            unreachable!()
        };
        let head_node = Rc::downgrade(node);
        drop(packed);
        drop(list);
        assert!(head_node.upgrade().is_none());
        assert!(element_node.upgrade().is_none());
        assert!(tail_node.upgrade().is_some());
        assert!(buffer.upgrade().is_some());
        assert_eq!(
            shared_tail.iter().collect::<Vec<_>>(),
            vec![Value::Bool(false), Value::Bool(true)]
        );
        drop(shared_tail);
        assert!(tail_node.upgrade().is_none());
        assert!(buffer.upgrade().is_none());
    }

    #[test]
    fn mixed_list_iteration_is_ordered_and_persistent() {
        let packed = ListHandle::from_items(vec![Value::Bool(true), Value::Bool(false)]);
        let cons = ListHandle::cons(Value::Unit, &packed);
        let shared = cons.clone();
        let mut iter = cons.iter();
        assert_eq!(iter.len(), 3);
        assert_eq!(iter.next(), Some(Value::Unit));
        assert_eq!(iter.len(), 2);
        assert_eq!(iter.collect::<Vec<_>>(), packed.iter().collect::<Vec<_>>());
        assert_eq!(shared, cons);
        assert_ne!(cons, packed);
        let different = ListHandle::from_items(vec![Value::Bool(false), Value::Bool(true)]);
        assert_ne!(packed, different);
    }

    #[test]
    #[should_panic(expected = "List length overflow")]
    fn cons_rejects_length_overflow_before_allocating() {
        // An impossible public value isolates the checked arithmetic boundary.
        let tail = ListHandle {
            repr: super::ListRepr::Empty,
            len: usize::MAX,
        };
        ListHandle::cons(Value::Unit, &tail);
    }

    #[test]
    fn list_debug_reports_logical_elements_only() {
        let packed = ListHandle::from_items(vec![Value::Bool(true), Value::Bool(false)]);
        let cons = ListHandle::cons(
            Value::Bool(true),
            &ListHandle::cons(Value::Bool(false), &ListHandle::empty()),
        );
        assert_eq!(format!("{packed:?}"), "[Bool(true), Bool(false)]");
        assert_eq!(format!("{cons:?}"), format!("{packed:?}"));
        assert_eq!(format!("{:?}", ListHandle::empty()), "[]");
    }

    #[test]
    fn list_representations_have_equal_nested_values_and_display() {
        let packed = ListHandle::from_items(vec![Value::Int(int(1)), Value::Int(int(2))]);
        let cons = ListHandle::cons(
            Value::Int(int(1)),
            &ListHandle::cons(Value::Int(int(2)), &ListHandle::empty()),
        );
        let mixed = ListHandle::cons(Value::Int(int(1)), &packed.tail_handle().unwrap());
        assert_eq!(packed, cons);
        assert_eq!(packed, mixed);
        let nested = |list| Value::Tagged {
            tag: 12,
            fields: vec![Value::Tuple(vec![Value::List(list)])],
        };
        assert_eq!(nested(packed.clone()), nested(cons.clone()));
        let registry = TypeRegistry::new();
        for list in [packed, cons, mixed] {
            assert_eq!(
                Value::List(list).to_display_string(&registry).unwrap(),
                "[1, 2]"
            );
        }
    }

    #[test]
    fn empty_list_head_and_tail_return_none() {
        let list = ListHandle::empty();
        assert_eq!(list.head_value(), None);
        assert_eq!(list.tail_handle(), None);
    }

    #[test]
    fn single_item_list_head_and_tail_preserve_non_empty_contract() {
        let list = ListHandle::from_items(vec![Value::Int(int(7))]);

        assert_eq!(list.len(), 1);
        assert_eq!(list.head_value(), Some(Value::Int(int(7))));

        let tail = list.tail_handle().expect("single-item list has empty tail");
        assert_eq!(tail.len(), 0);
        assert_eq!(tail.head_value(), None);
        assert!(tail.is_empty());
    }

    #[test]
    fn multi_item_list_head_and_tail_walk_shared_chain() {
        let list = ListHandle::from_items(vec![
            Value::Int(int(1)),
            Value::Int(int(2)),
            Value::Int(int(3)),
        ]);

        assert_eq!(list.len(), 3);
        assert_eq!(list.head_value(), Some(Value::Int(int(1))));

        let tail = list.tail_handle().expect("non-empty list has tail handle");
        assert_eq!(tail.len(), 2);
        assert_eq!(tail.head_value(), Some(Value::Int(int(2))));

        let tail_tail = tail.tail_handle().expect("tail stays non-empty");
        assert_eq!(tail_tail.len(), 1);
        assert_eq!(tail_tail.head_value(), Some(Value::Int(int(3))));
    }

    #[test]
    fn cons_and_tail_update_len_without_mutating_shared_tail() {
        let tail = ListHandle::from_items(vec![Value::Int(int(2)), Value::Int(int(3))]);
        let list = ListHandle::cons(Value::Int(int(1)), &tail);

        assert_eq!(list.len(), 3);
        assert_eq!(list.head_value(), Some(Value::Int(int(1))));

        let derived_tail = list.tail_handle().expect("cons list has tail");
        assert_eq!(derived_tail.len(), 2);
        assert_eq!(derived_tail.head_value(), Some(Value::Int(int(2))));

        assert_eq!(tail.len(), 2);
        assert_eq!(tail.head_value(), Some(Value::Int(int(2))));
    }

    #[test]
    fn display_for_callable_shows_target_and_capture_counts() {
        let registry = TypeRegistry::new();
        let builtin = Value::Callable(Callable {
            target: CallableTarget::Builtin(3),
            lexical_captures: Vec::new(),
            metadata: CallableMetadata::default(),
        });
        let function = Value::Callable(Callable {
            target: CallableTarget::Function(7),
            lexical_captures: vec![Value::Unit],
            metadata: CallableMetadata::default(),
        });
        let template = Value::Callable(Callable {
            target: CallableTarget::Template(11),
            lexical_captures: vec![Value::Unit, Value::Bool(true)],
            metadata: CallableMetadata::default(),
        });
        assert_eq!(builtin.to_display_string(&registry).unwrap(), "<builtin:3>");
        assert_eq!(
            function.to_display_string(&registry).unwrap(),
            "<function:7; lexical_captures=1>"
        );
        assert_eq!(
            template.to_display_string(&registry).unwrap(),
            "<template:11; lexical_captures=2>"
        );
    }

    #[test]
    fn display_result_err_with_rich_error_uses_error_constructor_shape() {
        let registry = TypeRegistry::new();
        let value = Value::Tagged {
            tag: 1,
            fields: vec![Value::Error(Box::new(RichError {
                kind: "NoneError".into(),
                message: "null".into(),
                payload: Vec::new(),
                location: Location {
                    file: "<repl>".into(),
                    func: "f".into(),
                    line: 1,
                    column: 1,
                    span_start: 0,
                    span_end: 1,
                },
                cause: None,
                diagnostic: None,
                stack_trace: Vec::new(),
            }))],
        };
        assert_eq!(
            value.to_display_string(&registry).unwrap(),
            "Err(NoneError(\"null\"))"
        );
    }

    #[test]
    fn display_result_err_with_rich_error_preserves_tree_shape() {
        let registry = TypeRegistry::new();
        let mut rich = RichError {
            kind: "Higher".into(),
            message: "higher".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        };
        rich.append_cause_tail(RichError {
            kind: "Lower".into(),
            message: "lower".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        });

        let value = Value::Tagged {
            tag: 1,
            fields: vec![Value::Error(Box::new(rich))],
        };
        assert_eq!(
            value.to_display_string(&registry).unwrap(),
            "Err(Higher(\"higher\"))\n|_ Lower(\"lower\")"
        );
    }

    #[test]
    fn rich_error_eprint_lines_follow_linear_chain_order() {
        let mut rich = RichError {
            kind: "Higher".into(),
            message: "higher".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        };
        rich.append_cause_tail(RichError {
            kind: "Lower".into(),
            message: "lower".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: None,
            stack_trace: Vec::new(),
        });

        assert_eq!(
            rich.to_eprint_lines(),
            vec![
                "Error: Higher: higher".to_string(),
                "Caused by: Lower: lower".to_string(),
            ]
        );
    }

    #[test]
    fn rich_error_eprint_lines_render_clean_message_with_structured_literal_metadata() {
        let rich = RichError {
            kind: "PatternMismatch".into(),
            message: "Pattern did not match.".into(),
            payload: Vec::new(),
            location: Location {
                file: "<repl>".into(),
                func: "f".into(),
                line: 1,
                column: 1,
                span_start: 0,
                span_end: 1,
            },
            cause: None,
            diagnostic: Some(RuntimeErrorDiagnostic::LiteralPatternMismatch {
                lhs: "1".into(),
                rhs: "2".into(),
            }),
            stack_trace: Vec::new(),
        };

        assert_eq!(
            rich.to_eprint_lines(),
            vec!["Error: PatternMismatch: Pattern did not match.".to_string()]
        );
    }
}
