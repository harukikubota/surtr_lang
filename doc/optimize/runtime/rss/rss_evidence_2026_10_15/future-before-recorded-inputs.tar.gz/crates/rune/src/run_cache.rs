use std::env;
use std::fs;
use std::path::PathBuf;

use forge::bytecode::{stable_hash_hex, Bytecode};

use crate::compile::ScriptCompilePlan;
use crate::error::ExecutionEnv;
use crate::measurement::{elapsed, CacheState, CompileMeasurement};

const CACHE_VERSION: &str = "surtr-run-cache-v2";

pub(crate) fn load_with_status(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
) -> (Option<Bytecode>, CacheState) {
    if !enabled() {
        return (None, CacheState::Disabled);
    }

    let Some(cache_path) = cache_path(env, compile_sources, compile_plan) else {
        return (None, CacheState::Miss);
    };
    if !cache_path.exists() {
        return (None, CacheState::Miss);
    }

    let bytes = match fs::read(&cache_path) {
        Ok(bytes) => bytes,
        Err(_) => return (None, CacheState::Miss),
    };
    match Bytecode::decode(&bytes) {
        Ok(bytecode) => (Some(bytecode), CacheState::Hit),
        Err(_) => {
            let _ = fs::remove_file(cache_path);
            (None, CacheState::Miss)
        }
    }
}

pub(crate) fn store(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
    bytecode: &Bytecode,
    mut measurement: Option<&mut CompileMeasurement>,
) -> CacheState {
    if !enabled() {
        return CacheState::Disabled;
    }

    let Some(cache_path) = cache_path(env, compile_sources, compile_plan) else {
        return CacheState::StoreFailed;
    };
    let Some(parent) = cache_path.parent() else {
        return CacheState::StoreFailed;
    };
    if fs::create_dir_all(parent).is_err() {
        return CacheState::StoreFailed;
    }

    let encode_start = std::time::Instant::now();
    let Ok(bytes) = bytecode.encode() else {
        return CacheState::StoreFailed;
    };
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.bytecode_encode = elapsed(encode_start);
    }
    let temp_path = cache_path.with_extension(format!("{}.tmp", std::process::id()));
    if fs::write(&temp_path, bytes).is_err() {
        let _ = fs::remove_file(&temp_path);
        return CacheState::StoreFailed;
    }
    if fs::rename(&temp_path, &cache_path).is_err() {
        if fs::copy(&temp_path, &cache_path).is_err() {
            let _ = fs::remove_file(&temp_path);
            return CacheState::StoreFailed;
        }
        let _ = fs::remove_file(&temp_path);
    }
    CacheState::Stored
}

fn enabled() -> bool {
    !matches!(
        env::var("SURTR_RUN_CACHE")
            .ok()
            .as_deref()
            .map(str::trim)
            .map(str::to_ascii_lowercase)
            .as_deref(),
        Some("0") | Some("false") | Some("no")
    )
}

fn cache_path(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
) -> Option<PathBuf> {
    Some(cache_root().join(format!(
        "{}.eldr",
        cache_key(env, compile_sources, compile_plan)?
    )))
}

fn cache_root() -> PathBuf {
    if let Some(path) = env::var_os("SURTR_RUN_CACHE_DIR") {
        if !path.to_string_lossy().trim().is_empty() {
            return PathBuf::from(path);
        }
    }

    xldr::target_root_from_current_exe()
        .map(|root| root.join("run-cache").join("eldr"))
        .unwrap_or_else(|| env::temp_dir().join("surtr-run-cache").join("eldr"))
}

fn cache_key(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
) -> Option<String> {
    let user_file_name = compile_sources
        .sources
        .file_name(compile_sources.user_source_id)
        .unwrap_or("<unknown>");
    let user_source = compile_sources
        .sources
        .source(compile_sources.user_source_id)
        .unwrap_or("");

    let mut key = String::new();
    key.push_str(CACHE_VERSION);
    key.push('\x1f');
    key.push_str(&xldr::current_exe_fingerprint().ok()?);
    key.push('\x1f');
    key.push_str(env.command_name());
    key.push('\x1f');
    key.push_str(&format!("{:?}", env.compile_unit_kind()));
    key.push('\x1f');
    key.push_str(compile_plan.selected_entry_name.as_deref().unwrap_or(""));
    key.push('\x1f');
    key.push_str(
        compile_plan
            .normalized_entrypoint
            .as_ref()
            .map(|entry| entry.qualified_symbol.as_str())
            .unwrap_or(""),
    );
    key.push('\x1f');
    key.push_str(user_file_name);
    key.push('\x1f');
    key.push_str(&compile_sources.user_module_path);
    key.push('\x1f');
    key.push_str(&stable_hash_hex(user_source));
    key.push('\x1f');
    push_module_pipeline_key(&mut key, compile_sources);

    Some(stable_hash_hex(&key))
}

fn push_module_pipeline_key(key: &mut String, compile_sources: &xldr::CompileSources) {
    for stage in &compile_sources.module_stages {
        key.push('|');
        for module in stage {
            let file_name = compile_sources
                .sources
                .file_name(module.source_id)
                .unwrap_or("<unknown>");
            let source = compile_sources
                .sources
                .source(module.source_id)
                .unwrap_or("");
            key.push_str(file_name);
            key.push('\x1f');
            key.push_str(&format!("{:?}", module.module_path));
            key.push('\x1f');
            key.push_str(xldr::source_kind_cache_key(module.source_kind));
            key.push('\x1f');
            key.push_str(&stable_hash_hex(source));
            key.push('\x1e');
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{cache_root, enabled};
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};

    fn env_lock() -> &'static Mutex<()> {
        static ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        ENV_LOCK.get_or_init(|| Mutex::new(()))
    }

    #[test]
    fn run_cache_false_env_values_are_trimmed_and_case_insensitive() {
        let _guard = env_lock().lock().expect("env lock");
        let previous = std::env::var("SURTR_RUN_CACHE").ok();
        std::env::set_var("SURTR_RUN_CACHE", " False ");

        assert!(!enabled());

        match previous {
            Some(value) => std::env::set_var("SURTR_RUN_CACHE", value),
            None => std::env::remove_var("SURTR_RUN_CACHE"),
        }
    }

    #[test]
    fn run_cache_empty_dir_env_uses_default_root() {
        let _guard = env_lock().lock().expect("env lock");
        let previous = std::env::var("SURTR_RUN_CACHE_DIR").ok();
        std::env::set_var("SURTR_RUN_CACHE_DIR", " ");

        assert_ne!(cache_root(), PathBuf::from(" "));

        match previous {
            Some(value) => std::env::set_var("SURTR_RUN_CACHE_DIR", value),
            None => std::env::remove_var("SURTR_RUN_CACHE_DIR"),
        }
    }
}
