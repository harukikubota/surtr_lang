use std::collections::HashMap;
use std::env;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};

use diagnostics::{SourceId, SourceRegistry};
use forge::bytecode::{stable_hash_hex, synthesize_source_map, SourceFileEntry};
use sindr::policy::EntryPoint;
use spire::ast::{Ast, Span};
use spire::error::ParseError;

use crate::error::{ExecutionEnv, RuneError, RuneResult};
use crate::measurement::{elapsed, CompileMeasurement};

type SharedScriptCompilePrefix = Arc<xldr::CompilationPrefixSnapshot>;

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ScriptCompilePlan {
    pub(crate) source_for_parse: String,
    pub(crate) selected_entry_name: Option<String>,
    pub(crate) normalized_entrypoint: Option<EntryPoint>,
    pub(crate) include_directives: Vec<xldr::ScriptIncludeDirective>,
    pub(crate) include_modules: Vec<xldr::ModuleInput>,
}

#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ScriptPlanError {
    pub(crate) message: String,
    pub(crate) span: Span,
    pub(crate) parse_error: Option<ParseError>,
}

impl ScriptPlanError {
    fn new(message: impl Into<String>, span: Span) -> Self {
        Self {
            message: message.into(),
            span,
            parse_error: None,
        }
    }

    fn from_parse(error: ParseError) -> Self {
        Self {
            message: error.message(),
            span: error.span().clone(),
            parse_error: Some(error),
        }
    }
}

pub(crate) fn script_plan_error_as_rune_error(
    file_path: &str,
    source: &str,
    error: ScriptPlanError,
) -> RuneError {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register(file_path, source.to_string());
    let spec = match error.parse_error.as_ref() {
        Some(parse_error) => diagnostics::parse_error_spec(source_id, source, parse_error),
        None => diagnostics::simple_error("LoadError", error.message, error.span, None),
    };
    RuneError::diagnostic(1, &sources, source_id, "parse", spec)
}

fn load_error_span(source: &str) -> Span {
    let len = source.chars().count();
    if len == 0 {
        return Span { start: 0, end: 0 };
    }
    let start = source
        .chars()
        .position(|ch| !ch.is_ascii_whitespace())
        .unwrap_or(0);
    Span {
        start,
        end: (start + 1).min(len),
    }
}

fn module_source_collection_error_as_rune_error(
    file_path: &str,
    source: &str,
    message: impl Into<String>,
) -> RuneError {
    let mut sources = SourceRegistry::new();
    let source_id = sources.register(file_path, source.to_string());
    RuneError::diagnostic(
        1,
        &sources,
        source_id,
        "resolve",
        diagnostics::simple_error("LoadError", message, load_error_span(source), None),
    )
}

fn source_id_for_span(compile_sources: &xldr::CompileSources, span: &Span) -> SourceId {
    if let Some(source) = compile_sources
        .sources
        .source(compile_sources.user_source_id)
    {
        if source.chars().count() >= span.end {
            return compile_sources.user_source_id;
        }
    }

    let mut candidates = compile_sources.module_source_ids.clone();
    candidates.push(compile_sources.user_source_id);
    candidates.sort_by_key(|id| id.0);
    candidates.dedup_by_key(|id| id.0);

    let mut best_code: Option<(SourceId, usize)> = None;
    let mut best_any: Option<(SourceId, usize)> = None;

    for source_id in candidates {
        let Some(source) = compile_sources.sources.source(source_id) else {
            continue;
        };
        let chars: Vec<char> = source.chars().collect();
        let len = chars.len();
        if len < span.end {
            continue;
        }
        let is_code = chars
            .get(span.start)
            .is_some_and(|ch| !ch.is_ascii_whitespace());
        if is_code {
            match best_code {
                None => best_code = Some((source_id, len)),
                Some((_, best_len)) if len < best_len => best_code = Some((source_id, len)),
                _ => {}
            }
        }
        match best_any {
            None => best_any = Some((source_id, len)),
            Some((_, best_len)) if len < best_len => best_any = Some((source_id, len)),
            _ => {}
        }
    }

    best_code
        .or(best_any)
        .map(|(source_id, _)| source_id)
        .unwrap_or(compile_sources.user_source_id)
}

fn diagnostic_location_for_span(
    compile_sources: &xldr::CompileSources,
    span: &Span,
) -> (SourceId, Span) {
    if let Some((source_id, local_span)) = xldr::decode_rebased_module_span(span) {
        if compile_sources.sources.get(source_id).is_some() {
            return (source_id, local_span);
        }
    }
    (source_id_for_span(compile_sources, span), span.clone())
}

fn map_resolve_reason(
    reason: &sigil::error::ResolveErrorReason,
) -> Result<diagnostics::ResolveDiagnosticReason, &spire::error::ParseError> {
    use diagnostics::ResolveDiagnosticReason as D;
    use sigil::error::ResolveErrorReason as R;
    Ok(match reason {
        R::NameResolution => D::NameResolution,
        R::Namespace => D::Namespace,
        R::Visibility => D::Visibility,
        R::Import => D::Import,
        R::Capture => D::Capture,
        R::ConstructorCaptureForbidden => D::ConstructorCaptureForbidden,
        R::Pattern => D::Pattern,
        R::Declaration => D::Declaration,
        R::SpecialForm => D::SpecialForm,
        R::SourcePolicy => D::SourcePolicy,
        R::InvalidIntrinsicSurfaceContract => D::InvalidIntrinsicSurfaceContract,
        R::ReservedIntrinsicMarkerDeclaration => D::ReservedIntrinsicMarkerDeclaration,
        R::ReservedIntrinsicMarkerImpl => D::ReservedIntrinsicMarkerImpl,
        R::CompilerInvariant => D::CompilerInvariant,
        R::DeferredParse(error) => return Err(error),
    })
}

fn resolve_spec_for_error(
    compile_sources: &xldr::CompileSources,
    error: &sigil::error::ResolveError,
) -> (SourceId, &'static str, diagnostics::DiagnosticSpec) {
    let (source_id, span) = diagnostic_location_for_span(compile_sources, &error.span);
    let reason = match map_resolve_reason(&error.diagnostic.reason) {
        Ok(reason) => reason,
        Err(parse_error) => {
            let source = compile_sources
                .sources
                .source(source_id)
                .expect("resolved diagnostic source");
            let local_error = parse_error
                .clone()
                .map_spans(|span| diagnostic_location_for_span(compile_sources, span).1);
            return (
                source_id,
                "parse",
                diagnostics::parse_error_spec(source_id, source, &local_error),
            );
        }
    };
    let labels = error
        .related_labels
        .iter()
        .map(|related| {
            let (label_source_id, label_span) =
                diagnostic_location_for_span(compile_sources, &related.span);
            (label_source_id, label_span, related.message.clone())
        })
        .collect::<Vec<_>>();
    let spec = diagnostics::resolve_error_spec(
        source_id,
        &error.message,
        span,
        reason,
        error.diagnostic.subject.clone(),
        &labels,
    );
    (source_id, "resolve", spec)
}

pub(crate) fn collect_default_script_compile_sources(
    env: ExecutionEnv,
    file_path: &str,
    source: &str,
    include_modules: &[xldr::ModuleInput],
    stdlib_variant: xldr::StdlibVariant,
) -> RuneResult<xldr::CompileSources> {
    let base_sources = xldr::cached_default_script_module_sources(stdlib_variant).map_err(|e| {
        module_source_collection_error_as_rune_error(
            file_path,
            source,
            format!(
                "{}: failed to collect definition sources: {}",
                env.command_name(),
                e
            ),
        )
    })?;

    let module_input_stages = include_modules
        .iter()
        .map(|module| vec![module.clone()])
        .collect::<Vec<_>>();

    let module_sources = xldr::extend_module_sources_with_module_stages(
        (*base_sources).clone(),
        &module_input_stages,
    )
    .map_err(|e| {
        module_source_collection_error_as_rune_error(
            file_path,
            source,
            format!(
                "{}: failed to collect definition sources: {}",
                env.command_name(),
                e
            ),
        )
    })?;
    Ok(xldr::compose_script_compile_sources_with_stdlib_variant(
        file_path,
        source,
        module_sources,
        stdlib_variant,
    ))
}

pub(crate) fn load_default_stdlib_snapshot(
    env: ExecutionEnv,
    sources: &xldr::CompileSources,
) -> RuneResult<std::sync::Arc<xldr::DefaultStdlibSnapshot>> {
    let user_source_id = sources.user_source_id;
    let snapshot = match sources.stdlib_variant {
        xldr::StdlibVariant::Default => xldr::default_stdlib_semantic_snapshot(),
        xldr::StdlibVariant::TestEnabled => xldr::test_enabled_stdlib_semantic_snapshot(),
    };
    snapshot.map_err(|e| {
        module_source_collection_error_as_rune_error(
            sources
                .sources
                .file_name(user_source_id)
                .unwrap_or("<script>"),
            sources.sources.source(user_source_id).unwrap_or(""),
            format!(
                "{}: failed to load stdlib snapshot: {}",
                env.command_name(),
                e
            ),
        )
    })
}

fn cached_test_prefix_root() -> PathBuf {
    env::current_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("target")
        .join("surtr-test-cache")
        .join("prefix")
}

fn script_prefix_typecheck_context(
    compile_unit_kind: sindr::policy::CompileUnitKind,
) -> scar::TypecheckContext {
    scar::TypecheckContext::from_source_policy(
        xldr::SourceKind::Script.policy(compile_unit_kind, None),
    )
}

fn build_cached_script_compile_prefix(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    std_snapshot: &xldr::DefaultStdlibSnapshot,
    module_stages: &[Vec<sigil::StagedModuleAst>],
    sources: &SourceRegistry,
) -> RuneResult<SharedScriptCompilePrefix> {
    let cache_key = xldr::test_semantic_prefix_cache_key(env.compile_unit_kind(), compile_sources)
        .map_err(|e| {
            RuneError::message(
                1,
                format!("test: failed to build semantic prefix key: {}", e),
            )
        })?;
    let cache_path = cached_test_prefix_root().join(format!("{cache_key}.semantic"));

    static PREFIX_CACHE: OnceLock<
        Mutex<HashMap<String, Result<SharedScriptCompilePrefix, String>>>,
    > = OnceLock::new();
    let cache = PREFIX_CACHE.get_or_init(|| Mutex::new(HashMap::new()));
    if let Some(cached) = cache
        .lock()
        .expect("script compile prefix cache poisoned")
        .get(&cache_key)
    {
        return cached
            .clone()
            .map_err(|message| RuneError::message(1, message));
    }

    let rebuilt_declaration_index =
        sigil::precollect_declaration_index(module_stages).map_err(|e| {
            let (source_id, phase, spec) = resolve_spec_for_error(compile_sources, &e);
            RuneError::diagnostic(1, sources, source_id, phase, spec)
        })?;
    let mut cached_payload = xldr::load_cached_test_semantic_prefix(&cache_path, &cache_key);
    let _semantic_cache_lock = if cached_payload.is_none() {
        xldr::acquire_semantic_cache_lock(&cache_path)
    } else {
        None
    };
    if cached_payload.is_none() && _semantic_cache_lock.is_some() {
        cached_payload = xldr::load_cached_test_semantic_prefix(&cache_path, &cache_key);
    }

    let prefix = if let Some(payload) = cached_payload {
        Arc::new(xldr::CompilationPrefixSnapshot::from_parts(
            rebuilt_declaration_index.clone(),
            payload.resolve_state,
            payload.scar_checkpoint,
            payload.bytecode,
        ))
    } else {
        let resolved = sigil::resolve_staged_program_from_state(
            module_stages,
            Vec::new(),
            &rebuilt_declaration_index,
            None,
            std_snapshot.default_stage_count,
            std_snapshot.resolve_state(),
        )
        .map_err(|e| {
            let (source_id, phase, spec) = resolve_spec_for_error(compile_sources, &e);
            RuneError::diagnostic(1, sources, source_id, phase, spec)
        })?;
        let resume_state = resolved.resume_state;
        let mut scar_session = std_snapshot.compile_prefix().restored_scar_session();
        let typed = scar_session
            .typecheck_staged_program_in_place_with_context(
                resolved,
                script_prefix_typecheck_context(env.compile_unit_kind()),
            )
            .map_err(|e| {
                let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
                let spec = e
                    .structured
                    .as_ref()
                    .map(|diagnostic| {
                        let diagnostic = diagnostic.clone().map_source_locations(|span| {
                            diagnostic_location_for_span(compile_sources, span)
                        });
                        let source = sources
                            .source(diagnostic.primary.source_id)
                            .expect("compile diagnostic source");
                        diagnostics::structured_compile_error_spec(source, &diagnostic)
                    })
                    .unwrap_or_else(|| {
                        diagnostics::typecheck_invariant_spec_with_display(
                            source_id,
                            span,
                            e.message.clone(),
                            e.hint.clone(),
                        )
                    });
                RuneError::diagnostic(
                    1,
                    sources,
                    source_id,
                    e.structured
                        .as_ref()
                        .map(diagnostics::compile_error_phase)
                        .unwrap_or("typecheck"),
                    spec,
                )
            })?;
        let mut forge_session = std_snapshot.compile_prefix().forge_session();
        let (chunk, _) = forge_session
            .codegen_chunk_typed_program(typed)
            .map_err(|e| {
                let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
                RuneError::diagnostic(
                    1,
                    sources,
                    source_id,
                    "codegen",
                    diagnostics::simple_error("CodegenError", &e.message, span, None),
                )
            })?;
        let bytecode = forge::compose_bytecode_with_chunk(std_snapshot.bytecode().clone(), chunk)
            .map_err(|e| {
            let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
            RuneError::diagnostic(
                1,
                sources,
                source_id,
                "codegen",
                diagnostics::simple_error("CodegenError", &e.message, span, None),
            )
        })?;
        let next_fun_idx = bytecode
            .functions
            .iter()
            .map(|entry| entry.fun_idx.saturating_add(1))
            .max()
            .unwrap_or(0);
        scar_session.ensure_next_fun_idx_at_least(next_fun_idx);
        scar_session.reconcile_function_indices(bytecode.functions.iter().filter_map(|entry| {
            entry
                .qualified_name
                .as_deref()
                .map(|qualified_name| (qualified_name, entry.fun_idx))
        }));
        let resolve_state = sigil::ResolveResumeState {
            next_local_id: resume_state.next_local_id.max(next_fun_idx),
        };
        let prefix = Arc::new(xldr::CompilationPrefixSnapshot::from_parts(
            rebuilt_declaration_index.clone(),
            resolve_state,
            scar_session.checkpoint(),
            bytecode,
        ));
        xldr::store_cached_test_semantic_prefix_snapshot(&cache_path, &cache_key, &prefix);
        prefix
    };

    cache
        .lock()
        .expect("script compile prefix cache poisoned")
        .insert(cache_key, Ok(Arc::clone(&prefix)));
    Ok(prefix)
}

fn parse_program_with_module_sources<'a>(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    std_snapshot: &'a xldr::DefaultStdlibSnapshot,
    mut measurement: Option<&mut CompileMeasurement>,
) -> RuneResult<(
    std::borrow::Cow<'a, [Vec<sigil::StagedModuleAst>]>,
    Vec<spire::ast::Ast>,
)> {
    let compile_unit_kind = env.compile_unit_kind();
    let source_kind = env.source_kind();
    let sources = &compile_sources.sources;
    let user_source_id = compile_sources.user_source_id;
    let parse_modules_start = std::time::Instant::now();
    let expanded =
        xldr::expand_snapshot_module_stages(compile_sources, std_snapshot, compile_unit_kind)
            .map_err(|e| {
                RuneError::diagnostic(1, sources, e.source_id, "parse", e.diagnostic_spec(sources))
            })?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.parse_modules = elapsed(parse_modules_start);
    }

    let user_source = sources.source(user_source_id).unwrap_or("");
    let parse_user_start = std::time::Instant::now();
    let user_ast = parse_script_ast_for_compile(user_source, user_source_id.0, source_kind)
        .and_then(|ast| {
            spire::materialize_reflections(
                ast,
                user_source,
                sources.file_name(user_source_id).map(std::path::Path::new),
            )
        })
        .map_err(|script_err: ParseError| {
            RuneError::diagnostic(
                1,
                sources,
                user_source_id,
                "parse",
                diagnostics::parse_error_spec(user_source_id, user_source, &script_err),
            )
        })?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.parse_user = elapsed(parse_user_start);
    }

    Ok((expanded.module_stages, user_ast))
}

pub(crate) fn compile_source(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
) -> RuneResult<forge::bytecode::Bytecode> {
    compile_source_with_measurement(env, compile_sources, compile_plan, None)
}

pub(crate) fn compile_source_with_measurement(
    env: ExecutionEnv,
    compile_sources: &xldr::CompileSources,
    compile_plan: &ScriptCompilePlan,
    mut measurement: Option<&mut CompileMeasurement>,
) -> RuneResult<forge::bytecode::Bytecode> {
    let compile_unit_kind = env.compile_unit_kind();
    let source_kind = env.source_kind();
    let sources = &compile_sources.sources;
    let user_source_id = compile_sources.user_source_id;
    let user_source = sources.source(user_source_id).unwrap_or("");

    for entry in sources.entries() {
        if entry.source.chars().take(xldr::MODULE_SPAN_STRIDE).count() == xldr::MODULE_SPAN_STRIDE {
            return Err(RuneError::message(1, format!(
                "LoadError: source {} must contain fewer than {} characters for source span encoding",
                entry.file_name, xldr::MODULE_SPAN_STRIDE,
            )));
        }
    }

    let stdlib_load_start = std::time::Instant::now();
    let std_snapshot = load_default_stdlib_snapshot(env, compile_sources)?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.stdlib_load = elapsed(stdlib_load_start);
        measurement.stdlib_cache =
            xldr::stdlib_semantic_snapshot_cache_state(compile_sources.stdlib_variant)
                .map(|state| match state {
                    xldr::StdlibCacheState::Cold => crate::measurement::CacheState::Cold,
                    xldr::StdlibCacheState::ProcessHit => {
                        crate::measurement::CacheState::ProcessHit
                    }
                    xldr::StdlibCacheState::DiskHit => crate::measurement::CacheState::DiskHit,
                })
                .unwrap_or(crate::measurement::CacheState::Cold);
    }
    let (mut module_stages, mut user_ast) = parse_program_with_module_sources(
        env,
        compile_sources,
        &std_snapshot,
        measurement.as_deref_mut(),
    )?;
    let (script_process_stage, script_user_ast) =
        xldr::extract_process_modules_from_user_ast(user_ast);
    let has_script_process_stage = !script_process_stage.is_empty();
    user_ast = script_user_ast;
    if has_script_process_stage {
        module_stages.to_mut().push(script_process_stage);
    }
    if let Some(entry_name) = compile_plan.selected_entry_name.as_deref() {
        user_ast = rewrite_script_ast_for_entry(user_ast, entry_name);
    }
    let suffix_module_stages = if module_stages.len() > std_snapshot.default_stage_count {
        &module_stages[std_snapshot.default_stage_count..]
    } else {
        &[]
    };
    let docs = sigil::collect_doc_entries_with_base(
        &std_snapshot.docs,
        suffix_module_stages,
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );
    let signatures = sigil::collect_signature_entries_with_base(
        &std_snapshot.signatures,
        suffix_module_stages,
        &user_ast,
        Some(compile_sources.user_module_path.as_str()),
    );

    let mut cached_prefix: Option<SharedScriptCompilePrefix> = None;
    let rebuilt_declaration_index;
    let declaration_index = if module_stages.len() == std_snapshot.default_stage_count {
        std_snapshot.declaration_index()
    } else if matches!(env, ExecutionEnv::Test) && !has_script_process_stage {
        cached_prefix = Some(build_cached_script_compile_prefix(
            env,
            compile_sources,
            &std_snapshot,
            &module_stages,
            sources,
        )?);
        let Some(prefix) = cached_prefix.as_ref() else {
            return Err(RuneError::usage("test prefix cache was not built"));
        };
        &prefix.declaration_index
    } else {
        rebuilt_declaration_index =
            sigil::precollect_declaration_index(&module_stages).map_err(|e| {
                let (source_id, phase, spec) = resolve_spec_for_error(compile_sources, &e);
                RuneError::diagnostic(1, sources, source_id, phase, spec)
            })?;
        &rebuilt_declaration_index
    };

    let resolve_start = std::time::Instant::now();
    let resume_state = cached_prefix
        .as_ref()
        .map(|prefix| prefix.resolve_state)
        .unwrap_or(std_snapshot.resolve_state());
    let start_stage_index = if cached_prefix.is_some() {
        module_stages.len()
    } else {
        std_snapshot.default_stage_count
    };
    let resolved = sigil::resolve_staged_program_from_state(
        &module_stages,
        user_ast,
        declaration_index,
        Some(compile_sources.user_module_path.clone()),
        start_stage_index,
        resume_state,
    )
    .map_err(|e| {
        let (source_id, phase, spec) = resolve_spec_for_error(compile_sources, &e);
        RuneError::diagnostic(1, sources, source_id, phase, spec)
    })?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.resolve = elapsed(resolve_start);
    }

    let prefix_bytecode = cached_prefix
        .as_ref()
        .map(|prefix| prefix.bytecode.clone())
        .unwrap_or_else(|| std_snapshot.bytecode().clone());
    let active_prefix = cached_prefix
        .as_ref()
        .map(|prefix| prefix.as_ref())
        .unwrap_or_else(|| std_snapshot.compile_prefix());
    let typecheck_start = std::time::Instant::now();
    let mut scar_session = active_prefix.restored_scar_session();
    let typed = scar_session
        .typecheck_staged_program_in_place_with_context(
            resolved,
            scar::TypecheckContext::from_source_policy(source_kind.policy(
                compile_unit_kind,
                compile_plan.normalized_entrypoint.as_ref(),
            )),
        )
        .map_err(|e| {
            let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
            let spec = e
                .structured
                .as_ref()
                .map(|diagnostic| {
                    let diagnostic = diagnostic.clone().map_source_locations(|span| {
                        diagnostic_location_for_span(compile_sources, span)
                    });
                    let source = sources
                        .source(diagnostic.primary.source_id)
                        .expect("compile diagnostic source");
                    diagnostics::structured_compile_error_spec(source, &diagnostic)
                })
                .unwrap_or_else(|| {
                    diagnostics::typecheck_invariant_spec_with_display(
                        source_id,
                        span,
                        e.message.clone(),
                        e.hint.clone(),
                    )
                });
            RuneError::diagnostic(
                1,
                sources,
                source_id,
                e.structured
                    .as_ref()
                    .map(diagnostics::compile_error_phase)
                    .unwrap_or("typecheck"),
                spec,
            )
        })?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.typecheck = elapsed(typecheck_start);
    }

    let codegen_start = std::time::Instant::now();
    let mut forge_session = active_prefix.forge_session();
    let (chunk, _) = forge_session
        .codegen_chunk_typed_program(typed)
        .map_err(|e| {
            let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
            RuneError::diagnostic(
                1,
                sources,
                source_id,
                "codegen",
                diagnostics::simple_error("CodegenError", &e.message, span, None),
            )
        })?;
    let mut bytecode = forge::compose_bytecode_with_chunk(prefix_bytecode, chunk).map_err(|e| {
        let (source_id, span) = diagnostic_location_for_span(compile_sources, &e.span);
        RuneError::diagnostic(
            1,
            sources,
            source_id,
            "codegen",
            diagnostics::simple_error("CodegenError", &e.message, span, None),
        )
    })?;
    if let Some(measurement) = measurement.as_deref_mut() {
        measurement.codegen = elapsed(codegen_start);
    }

    bytecode.docs = docs;
    bytecode.signatures = signatures;
    bytecode.compile_info.bytecode_version = 1;
    bytecode.compile_info.debug_level = 2;
    bytecode.compile_info.num_locals = bytecode.num_locals;
    bytecode.compile_info.build_profile = Some("full".into());
    bytecode.compile_info.source_hash = Some(stable_hash_hex(user_source));
    bytecode.compile_info.module_hash = Some(stable_hash_hex(&compile_sources.user_module_path));
    bytecode.sources = collect_viewer_sources(compile_sources);
    if bytecode.source_map.is_none() {
        bytecode.source_map = synthesize_source_map(
            &bytecode.opcodes,
            &bytecode.functions,
            &bytecode.error_templates,
            &bytecode.dbg_templates,
            user_source,
            Some(
                compile_sources
                    .sources
                    .file_name(user_source_id)
                    .unwrap_or("<script>"),
            ),
        );
    }
    bytecode.refresh_viewer_metadata();

    Ok(bytecode)
}

fn collect_viewer_sources(compile_sources: &xldr::CompileSources) -> Vec<SourceFileEntry> {
    let mut ids = compile_sources.module_source_ids.clone();
    ids.push(compile_sources.user_source_id);
    ids.sort_by_key(|id| id.0);
    ids.dedup_by_key(|id| id.0);

    ids.into_iter()
        .filter_map(|source_id| {
            let entry = compile_sources.sources.get(source_id)?;
            Some(SourceFileEntry {
                source_id: source_id.0,
                path: entry.file_name.clone(),
                normalized_path: Some(entry.file_name.clone()),
                content_hash: Some(stable_hash_hex(&entry.source)),
                text: Some(entry.source.clone()),
            })
        })
        .collect()
}

pub(crate) fn prepare_script_compile_plan(
    file_path: &str,
    source: &str,
    cli_entry: Option<&str>,
) -> Result<ScriptCompilePlan, ScriptPlanError> {
    let prepared = xldr::prepare_script_sources(file_path, source, xldr::SourceKind::Script)
        .map_err(script_source_prepare_error_to_plan_error)?;

    let selected_entry_name = match cli_entry {
        Some(name) => Some(name.to_string()),
        None => None,
    };

    let normalized_entrypoint = selected_entry_name.as_ref().map(|name| {
        EntryPoint::script_short_name(name, xldr::script_pseudo_module_path(file_path))
    });

    Ok(ScriptCompilePlan {
        source_for_parse: prepared.source_for_parse,
        selected_entry_name,
        normalized_entrypoint,
        include_directives: prepared.include_directives,
        include_modules: prepared.include_modules,
    })
}

fn script_source_prepare_error_to_plan_error(
    error: xldr::ScriptSourcePrepareError,
) -> ScriptPlanError {
    match error {
        xldr::ScriptSourcePrepareError::Parse { error } => ScriptPlanError::from_parse(error),
        xldr::ScriptSourcePrepareError::IncludeRead { message, span } => {
            ScriptPlanError::new(message, span)
        }
    }
}
fn parse_script_ast_for_compile(
    source: &str,
    source_id: u32,
    source_kind: xldr::SourceKind,
) -> Result<Vec<Ast>, ParseError> {
    let strict_context = xldr::derive_parser_context(
        source_id,
        source_kind,
        sindr::policy::CompileUnitKind::Script,
        None,
    );
    spire::parse_with_context(source, strict_context)
}

fn rewrite_script_ast_for_entry(user_ast: Vec<Ast>, entry_name: &str) -> Vec<Ast> {
    let mut out = user_ast
        .into_iter()
        .filter(|stmt| {
            matches!(
                stmt,
                Ast::Def(..)
                    | Ast::ExtractorDef(..)
                    | Ast::TraitDef(..)
                    | Ast::TraitImplDef(..)
                    | Ast::BuiltinDecl(..)
                    | Ast::StructDef(..)
                    | Ast::RecordDef(..)
                    | Ast::DeferrorDef(_, _, _, _, _)
                    | Ast::ImplDef(_, _, _, _, _)
                    | Ast::SupervisorInit(_, _)
                    | Ast::Import(_, _, _)
            )
        })
        .collect::<Vec<_>>();

    let span = Span { start: 0, end: 0 };
    out.push(Ast::App(
        span.clone(),
        Box::new(Ast::Var(span, entry_name.to_string())),
        Vec::new(),
    ));
    out
}

#[cfg(test)]
mod tests {
    use std::fs;

    use super::{
        collect_default_script_compile_sources, compile_source, diagnostic_location_for_span,
        load_error_span, module_source_collection_error_as_rune_error,
        parse_script_ast_for_compile, prepare_script_compile_plan, script_plan_error_as_rune_error,
        source_id_for_span, ScriptPlanError,
    };
    use crate::error::ExecutionEnv;
    use crate::error::RuneError;
    use spire::ast::Span;
    use xldr::{SourceKind, StagedModule};

    #[test]
    fn compile_source_rejects_test_assertion_type_boundaries() {
        const FILE: &str = "lib/tests/local/math.srt";
        let module_sources = xldr::collect_test_module_sources_with_module_stages(&[])
            .expect("Test-enabled standard sources must load");
        for (source, expected, expected_phase) in [
            (
                "assert_cause_chain([\"NoneError\"], Err(NoneError()))",
                "ErrorKind",
                "typecheck",
            ),
            (
                "assert_cause_chain([PayloadFailure(\"x\")], Err(NoneError()))",
                "ErrorKind",
                "typecheck",
            ),
            (
                "assert_cause_chain([Error], Err(NoneError()))",
                "Undefined variable: Error",
                "typecheck",
            ),
            (
                "assert_cause_chain([Int], Err(NoneError()))",
                "Undefined variable: Int",
                "resolve",
            ),
            ("assert_cause_chain([NoneError], 3)", "Result", "typecheck"),
            ("assert_ne({|x: Int| x}, {|x: Int| x})", "Eq", "typecheck"),
            (
                "assert_some_eq({|x: Int| x}, Option::Some({|x: Int| x}))",
                "Eq",
                "typecheck",
            ),
            ("assert_approx(1, 1.0, 0.0)", "Float", "typecheck"),
            ("assert(1, \"message\")", "Boolean", "typecheck"),
            (
                "assert_satisfies(1, \"message\", {|n| n + 1})",
                "Boolean",
                "typecheck",
            ),
            ("assert_lt(1, 2.0)", "Int", "typecheck"),
            (
                "assert_gt({|x: Int| x}, {|x: Int| x})",
                "Compare",
                "typecheck",
            ),
            ("assert_some(Ok(1))", "Option", "typecheck"),
            (
                "assert_err_kind(\"NoneError\", Err(NoneError()))",
                "ErrorKind",
                "typecheck",
            ),
            (
                "assert_err_kind(PayloadFailure(\"x\"), Err(NoneError()))",
                "ErrorKind",
                "typecheck",
            ),
            (
                "assert_err_kind(Int, Err(NoneError()))",
                "Undefined variable: Int",
                "resolve",
            ),
            (
                "assert_err_kind(Error, Err(NoneError()))",
                "Undefined variable: Error",
                "typecheck",
            ),
        ] {
            let source = format!(
                "import Test;\ndeferror PayloadFailure(detail: String) {{ |detail: String| Self(message: detail, detail) }}\n{source}\n"
            );
            let plan = prepare_script_compile_plan(FILE, &source, None)
                .expect("assertion input must have a valid script plan");
            let compile_sources = xldr::compose_script_compile_sources_with_stdlib_variant(
                FILE,
                &plan.source_for_parse,
                module_sources.clone(),
                xldr::StdlibVariant::TestEnabled,
            );
            let error = compile_source(ExecutionEnv::Test, &compile_sources, &plan)
                .expect_err("invalid assertion input must fail before codegen");
            assert_eq!(error.exit_code(), 1, "{source}: {error:?}");
            let RuneError::Diagnostic { diagnostic, .. } = &error else {
                panic!("assertion input must produce a compiler diagnostic: {source}: {error:?}");
            };
            assert_eq!(diagnostic.phase, expected_phase, "{source}: {error:?}");
            assert_eq!(
                diagnostic.source_id, compile_sources.user_source_id,
                "{source}"
            );
            assert_eq!(
                diagnostic.sources.file_name(diagnostic.source_id),
                Some(FILE),
                "{source}"
            );
            assert_eq!(
                diagnostic.sources.source(diagnostic.source_id),
                Some(source.as_str()),
                "{source}"
            );
            let span = &diagnostic.spec.primary_span;
            assert!(
                span.start <= span.end && span.end <= source.chars().count(),
                "{source}: {span:?}"
            );
            let report = error.to_serializable_report();
            assert_eq!(report.errors.len(), 1, "{source}: {report:?}");
            assert!(
                report.errors[0].message.contains(expected),
                "{source}: {report:?}"
            );
        }
    }

    #[test]
    fn compile_source_accepts_dynamic_error_kind_test_arguments() {
        const FILE: &str = "lib/tests/local/math.srt";
        let module_sources = xldr::collect_test_module_sources_with_module_stages(&[]).unwrap();
        for body in [
            "kind = PayloadFailure\nassert_err_kind(kind, Err(PayloadFailure(\"dynamic\")))",
            "kinds = [PayloadFailure, NoneError]\nassert_cause_chain(kinds, Result::cause(Err(NoneError()), PayloadFailure(\"outer\")))",
            "tail = [NoneError]\nassert_cause_chain([PayloadFailure, ..tail], Result::cause(Err(NoneError()), PayloadFailure(\"outer\")))",
            "captured: (ErrorKind, Result<Int> -> Result<()>) = &Test::assert_err_kind(&1, &2)\ncaptured(PayloadFailure, Err(PayloadFailure(\"capture\")))",
            "captured: (List<ErrorKind>, Result<Int> -> Result<()>) = &Test::assert_cause_chain(&1, &2)\ncaptured([NoneError], Err(NoneError()))",
        ] {
            let source = format!("import Test;\ndeferror PayloadFailure(detail: String) {{ |detail: String| Self(message: detail, detail) }}\n{body}\n");
            let plan = prepare_script_compile_plan(FILE, &source, None).unwrap();
            let compile_sources = xldr::compose_script_compile_sources_with_stdlib_variant(
                FILE, &plan.source_for_parse, module_sources.clone(), xldr::StdlibVariant::TestEnabled,
            );
            compile_source(ExecutionEnv::Test, &compile_sources, &plan)
                .unwrap_or_else(|error| panic!("dynamic ErrorKind input must compile: {source}: {error:?}"));
        }
    }

    #[test]
    fn parse_adapter_preserves_the_parser_reason_and_origin() {
        let source = "def f() -> Int { ) }";
        let parse_error = spire::parse(source).expect_err("unexpected token should fail parsing");
        let error = script_plan_error_as_rune_error(
            "structured_parse.srt",
            source,
            ScriptPlanError::from_parse(parse_error),
        );

        let RuneError::Diagnostic { diagnostic, .. } = error else {
            panic!("parser failure should become a diagnostic: {error:?}");
        };
        assert_eq!(diagnostic.phase, "parse");
        let structured = diagnostic
            .spec
            .structured
            .as_ref()
            .expect("parser diagnostics carry typed parser facts");
        assert_eq!(
            structured.reason,
            diagnostics::DiagnosticReason::Parse(
                diagnostics::ParseDiagnosticReason::UnexpectedToken
            )
        );
        assert_eq!(structured.origin, diagnostics::DiagnosticOrigin::Parse);
    }

    #[test]
    fn structured_type_diagnostics_preserve_json_facts_and_source_locations() {
        let cases = [
            (
                "call",
                include_str!(
                    "../../../tests/fixtures/script/fail/typecheck/structured_call_argument.srt"
                ),
                "ArgumentTypeMismatch",
            ),
            (
                "trait",
                include_str!(
                    "../../../tests/fixtures/script/fail/typecheck/structured_trait_dispatch.srt"
                ),
                "NoApplicableTraitImplementation",
            ),
            (
                "carrier",
                include_str!(
                    "../../../tests/fixtures/script/fail/typecheck/structured_carrier_relation.srt"
                ),
                "TypeConstructorFamilyMismatch",
            ),
            (
                "operator",
                include_str!(
                    "../../../tests/fixtures/script/fail/typecheck/structured_operator_relation.srt"
                ),
                "ArgumentTypeMismatch",
            ),
            (
                "branch",
                include_str!(
                    "../../../tests/fixtures/script/fail/typecheck/structured_branch_relation.srt"
                ),
                "CondBranchTypeMismatch",
            ),
        ];
        for (name, source, reason) in cases {
            let path = format!("structured_{name}.srt");
            let sources = collect_default_script_compile_sources(
                ExecutionEnv::Check,
                &path,
                source,
                &[],
                xldr::StdlibVariant::Default,
            )
            .unwrap();
            let plan = prepare_script_compile_plan(&path, source, None).unwrap();
            let error = compile_source(ExecutionEnv::Check, &sources, &plan)
                .expect_err("fixture is rejected");
            let report = error.to_serializable_report();
            let diagnostic = &report.errors[0];
            assert_eq!(
                diagnostic.reason.as_deref(),
                Some(reason),
                "{name}: {diagnostic:?}"
            );
            assert_eq!(diagnostic.phase, "typecheck");
            assert!(diagnostic.span[1] <= source.chars().count() as u32);
            assert!(!diagnostic.related.is_empty(), "{name}: {diagnostic:?}");
            for fact in &diagnostic.related {
                let source = sources
                    .sources
                    .source(diagnostics::SourceId(fact.source_id))
                    .expect("fact source exists");
                assert!(
                    fact.span[1] <= source.chars().count() as u32,
                    "{name}: {fact:?}"
                );
            }
            let primary = &diagnostic.related[0];
            assert_eq!(
                primary.source_id, sources.user_source_id.0,
                "primary belongs to the fixture"
            );
            if name == "operator" {
                assert_eq!(diagnostic.expected.as_deref(), Some("Int"));
                assert_eq!(diagnostic.got.as_deref(), Some("String"));
                assert!(
                    matches!(&diagnostic.origin, Some(diagnostics::DiagnosticOrigin::Operator { operator }) if operator == "+")
                );
            }
            if name == "carrier" {
                assert!(diagnostic.data["family_id"]
                    .as_str()
                    .unwrap()
                    .starts_with("family:"));
            }
        }
    }

    #[test]
    fn do_return_diagnostic_keeps_the_same_source_facts_in_human_and_json() {
        let source = r#"def invalid() -> Result<String> {
  do::<Result> {
    value =? Result::Ok(1)
    Result::Ok(value)
  }
}"#;
        let path = "do_return_mismatch.srt";
        let sources = collect_default_script_compile_sources(
            ExecutionEnv::Check,
            path,
            source,
            &[],
            xldr::StdlibVariant::Default,
        )
        .unwrap();
        let plan = prepare_script_compile_plan(path, source, None).unwrap();
        let error = compile_source(ExecutionEnv::Check, &sources, &plan)
            .expect_err("do result with a different payload type must fail");
        let RuneError::Diagnostic { diagnostic, .. } = &error else {
            panic!("expected structured type diagnostic, got {error:?}");
        };
        let final_start = source.rfind("Result::Ok(value)").unwrap();
        let final_end = final_start + "Result::Ok(value)".len();
        let return_start = source.find("Result<String>").unwrap();
        let return_end = return_start + "Result<String>".len();
        let structured = diagnostic
            .spec
            .structured
            .as_ref()
            .expect("do mismatch has typed diagnostic facts");
        assert_eq!(
            structured.primary.span,
            Span {
                start: final_start,
                end: final_end
            }
        );
        assert!(structured.related.iter().all(|fact| {
            fact.source_id == diagnostic.source_id && fact.span.end <= source.chars().count()
        }));

        let human = diagnostics::render_error_by_id(
            &diagnostic.sources,
            diagnostic.source_id,
            &diagnostic.spec,
        );
        assert!(human.contains("do_return_mismatch.srt:4:5"), "{human}");
        assert!(human.contains("Result<Int>"), "{human}");
        let report = error.to_serializable_report();
        let json = &report.errors[0];
        assert_eq!(json.reason.as_deref(), Some("ReturnTypeMismatch"));
        assert_eq!(json.message, diagnostic.spec.message);
        assert_eq!(json.span, [final_start as u32, final_end as u32]);
        assert!(
            json.related.iter().any(|fact| {
                fact.span == [return_start as u32, return_end as u32]
                    && fact.ty.as_deref() == Some("Result<String>")
                    && fact.source_id == diagnostic.source_id.0
            }),
            "{json:?}"
        );
        assert!(json
            .related
            .iter()
            .all(|fact| fact.span[1] <= source.chars().count() as u32));
    }

    #[test]
    fn script_compile_plan_extracts_include_directives() {
        let temp =
            std::env::temp_dir().join(format!("surtr_script_compile_plan_{}", std::process::id()));
        let fixtures = temp.join("fixtures");
        fs::create_dir_all(&fixtures).expect("test fixture dir should be created");
        fs::write(
            fixtures.join("Helper.srt"),
            r#"
defmod Helper {
  def add(a: Int, b: Int) -> Int { a + b }
}
"#,
        )
        .expect("test include fixture should be written");
        let script_path = temp.join("sample.srt");
        let source = r#"include 'fixtures/Helper.srt'
import Helper::add
print(to_string(add(1, 2)))
"#;

        let plan = prepare_script_compile_plan(
            script_path.to_str().expect("script path must be utf-8"),
            source,
            None,
        )
        .expect("compile plan must succeed");

        assert_eq!(plan.include_directives.len(), 1);
        assert_eq!(plan.include_directives[0].file_path, "fixtures/Helper.srt");
        assert_eq!(plan.include_modules.len(), 1);
        assert_eq!(plan.include_modules[0].module_path, "Global::Helper");
        assert_eq!(plan.source_for_parse.len(), source.len());
        assert!(!plan
            .source_for_parse
            .contains("include 'fixtures/Helper.srt'"));
        assert!(plan.source_for_parse.contains("import Helper::add"));

        let _ = fs::remove_dir_all(temp);
    }

    #[test]
    fn script_compile_plan_rejects_include_non_literal_argument() {
        let source = r#"path = "fixtures/Helper.srt"
include path
"#;

        let err = prepare_script_compile_plan("sample.srt", source, None)
            .expect_err("non-literal include path must fail");
        assert!(err
            .message
            .contains("include expects a string literal path"));
    }

    #[test]
    fn script_compile_plan_rejects_include_in_nested_expression() {
        let source = r#"value = include 'fixtures/Helper.srt'
print(to_string(1))
"#;

        let err = prepare_script_compile_plan("sample.srt", source, None)
            .expect_err("nested include must fail");
        assert!(
            err.message
                .contains("Declarations are only allowed at the top level")
                || err.message.contains("Unexpected token")
        );
    }

    #[test]
    fn parse_script_ast_for_compile_rejects_legacy_definition_after_expression() {
        let err = parse_script_ast_for_compile(
            "print(\"start\")\ndef helper() -> Unit { () }\n",
            0,
            SourceKind::Script,
        )
        .expect_err("legacy script ordering should fail under strict parsing");

        assert!(
            err.message()
                .contains("top-level definition cannot appear after top-level expression"),
            "unexpected error: {}",
            err.message()
        );
    }

    #[test]
    fn load_error_span_uses_first_non_whitespace_character() {
        let span = load_error_span("\n  print(\"ok\")\n");
        assert_eq!(span.start, 3);
        assert_eq!(span.end, 4);
    }

    #[test]
    fn module_source_collection_error_returns_diagnostic_variant() {
        let err = module_source_collection_error_as_rune_error(
            "main.srt",
            "print(\"ok\")\n",
            "run: failed to collect definition sources: broken",
        );
        match err {
            RuneError::Diagnostic { diagnostic, .. } => {
                assert_eq!(diagnostic.phase, "resolve");
                assert_eq!(diagnostic.spec.kind, "LoadError");
                assert!(diagnostic
                    .spec
                    .message
                    .contains("failed to collect definition sources"));
            }
            other => panic!("expected diagnostic error, got {:?}", other),
        }
    }

    #[test]
    fn diagnostic_location_for_span_decodes_rebased_module_span() {
        let module_source = "defmod MahjongCli { def render() -> Unit { () } }";
        let user_source = "MahjongCli::render()";
        let mut sources = diagnostics::SourceRegistry::new();
        let module_source_id = sources.register("examples/mahjong/src/6_cli.srt", module_source);
        let user_source_id = sources.register("examples/mahjong/run.srt", user_source);
        let compile_sources = xldr::CompileSources {
            sources,
            user_source_id,
            user_module_path: "__Script::examples::mahjong::run".into(),
            builtin_source_id: module_source_id,
            builtin_module_path: Some("Bootstrap".into()),
            module_source_ids: vec![module_source_id],
            module_stages: vec![vec![StagedModule {
                source_id: module_source_id,
                module_path: Some("MahjongCli".into()),
                source_kind: SourceKind::DefinitionSource,
            }]],
            stdlib_variant: xldr::StdlibVariant::Default,
        };
        let base = xldr::module_span_base_for_source(module_source_id);
        let span = Span {
            start: base + 12,
            end: base + 18,
        };
        let (source_id, local_span) = diagnostic_location_for_span(&compile_sources, &span);
        assert_eq!(
            compile_sources.sources.file_name(source_id),
            Some("examples/mahjong/src/6_cli.srt")
        );
        assert_eq!(local_span.start, 12);
        assert_eq!(local_span.end, 18);
    }

    #[test]
    fn source_id_for_span_falls_back_to_user_source_when_module_does_not_cover_span() {
        let module_source = "defmod MahjongCli { def render() -> Unit { () } }";
        let user_source =
            "main = \"................................................................\"";
        let mut sources = diagnostics::SourceRegistry::new();
        let module_source_id = sources.register("examples/mahjong/src/6_cli.srt", module_source);
        let user_source_id = sources.register("examples/mahjong/run.srt", user_source);
        let compile_sources = xldr::CompileSources {
            sources,
            user_source_id,
            user_module_path: "__Script::examples::mahjong::run".into(),
            builtin_source_id: module_source_id,
            builtin_module_path: Some("Bootstrap".into()),
            module_source_ids: vec![module_source_id],
            module_stages: vec![vec![StagedModule {
                source_id: module_source_id,
                module_path: Some("MahjongCli".into()),
                source_kind: SourceKind::DefinitionSource,
            }]],
            stdlib_variant: xldr::StdlibVariant::Default,
        };
        let span = Span { start: 50, end: 51 };
        let source_id = source_id_for_span(&compile_sources, &span);
        assert_eq!(
            compile_sources.sources.file_name(source_id),
            Some("examples/mahjong/run.srt")
        );
    }

    #[test]
    fn compile_source_accepts_concrete_pid_annotation_in_script_worker_spawn() {
        let source = r#"defagent MyWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def value(state: Int) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}

defsupervisor MySup {
  meta {
    strategy: OneForOne
    max_restarts: 5
    max_seconds: 10
    child_restart_default: Transient
    allow_adopt: True
  }
}

supervisor_init {
  MySup {}
}

pid: PID<MyWorker> =? MySup::spawn(MyWorker::init(1))
"#;

        let parsed = parse_script_ast_for_compile(source, 0, SourceKind::Script).unwrap();
        let (process_stage, _) = xldr::extract_process_modules_from_user_ast(parsed);
        let declaration_index = sigil::precollect_declaration_index(&[process_stage.clone()])
            .expect("process declarations should precollect");
        assert!(
            declaration_index
                .keys()
                .any(|key| key == "MyWorker::init" || key == "Global::MyWorker::init"),
            "expected process declaration index to expose MyWorker::init, got keys: {:?}",
            declaration_index.keys().collect::<Vec<_>>()
        );

        let plan = prepare_script_compile_plan("process_pid_annotation.srt", source, None).unwrap();
        let compile_sources = collect_default_script_compile_sources(
            ExecutionEnv::Check,
            "process_pid_annotation.srt",
            &plan.source_for_parse,
            &plan.include_modules,
            xldr::StdlibVariant::Default,
        )
        .unwrap();

        let compiled = compile_source(ExecutionEnv::Check, &compile_sources, &plan);
        assert!(
            compiled.is_ok(),
            "expected concrete PID annotation script to compile, got {compiled:?}"
        );
    }
}
