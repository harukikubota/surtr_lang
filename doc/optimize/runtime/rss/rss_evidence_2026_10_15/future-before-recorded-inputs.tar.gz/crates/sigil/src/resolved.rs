use serde::{Deserialize, Serialize};
use sindr::intrinsic::IntrinsicId;
use sindr::names::SymbolIdentityInfo;
use sindr::primitives::SurtrInt;
use spire::ast::{AstTy, BinOp, Lit, ProcessSpec, Span, Symbol, ValueParameterMode, Visibility};
use std::ops::Deref;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedDeclAttrs {
    pub doc: Option<String>,
    pub builtin: bool,
    pub derives: Vec<String>,
    pub facet_path_kind: Option<Vec<String>>,
    pub hidden: bool,
    pub readonly: bool,
    pub visibility: Visibility,
    pub user_importable: bool,
    pub user_callable: bool,
}

impl Default for ResolvedDeclAttrs {
    fn default() -> Self {
        Self {
            doc: None,
            builtin: false,
            derives: Vec::new(),
            facet_path_kind: None,
            hidden: false,
            readonly: false,
            visibility: Visibility::Public,
            user_importable: true,
            user_callable: true,
        }
    }
}

/// A resolved identifier — name + unique id + source location.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedId {
    pub name: Symbol,
    pub qualified_name: Option<Symbol>,
    pub unique_id: u32,
    pub compiler_generated: bool,
    #[serde(default)]
    pub symbol_info: Option<SymbolIdentityInfo>,
    pub span: Span,
}

/// A callable-signature type together with the exact identity of a direct
/// type-constructor Trait occurrence, when the outermost type names one.
///
/// The syntax is preserved for diagnostics and ordinary type resolution.  The
/// identity is resolved by Sigil so later phases never need to rediscover the
/// Trait through short or display-name matching.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedSignatureTy {
    pub syntax: AstTy,
    pub direct_constructor_trait: Option<ResolvedId>,
}

/// Exact Trait identities used by the compiler-owned `do` contract.
///
/// Sigil owns name resolution, so later phases must consume these identities
/// instead of rediscovering canonical Traits from display names.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedDoContract {
    /// Source origin of this do expression, also retained by synthetic continuations.
    pub keyword_span: Span,
    pub monad_fail_trait: Option<ResolvedId>,
    pub monad_trait: Option<ResolvedId>,
    pub alternative_trait: Option<ResolvedId>,
}

impl ResolvedSignatureTy {
    pub fn syntax(&self) -> &AstTy {
        &self.syntax
    }

    pub fn into_syntax(self) -> AstTy {
        self.syntax
    }
}

impl Deref for ResolvedSignatureTy {
    type Target = AstTy;

    fn deref(&self) -> &Self::Target {
        &self.syntax
    }
}

impl AsRef<AstTy> for ResolvedSignatureTy {
    fn as_ref(&self) -> &AstTy {
        &self.syntax
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedProcessSpec {
    pub module_path: String,
    pub process_name: String,
    pub spec: ProcessSpec,
    pub init_uid: u32,
    pub get_uid: u32,
    pub set_uid: Option<u32>,
    pub handler_uids: Vec<ResolvedProcessHandlerUid>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResolvedProcessHandlerUid {
    pub internal_name: Symbol,
    pub uid: u32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedFacetBracketExpr {
    pub expr: Box<Resolved>,
    pub display: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedFacetPathSegment {
    Field { name: Symbol, optional: bool },
    Bracket(ResolvedFacetBracketExpr),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedStructLitField {
    Explicit(Symbol, Resolved),
    Shorthand(Symbol, Resolved),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedHashMapLiteralEntry {
    pub key: Resolved,
    pub value: Resolved,
}

/// Resolved AST — every identifier carries a unique_id.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Resolved {
    ApplyPattern(Span, Box<Resolved>, ResolvedPattern),
    /// Literal value
    Lit(Span, Lit),

    /// Variable reference (resolved)
    Var(Span, ResolvedId),

    /// Function application
    App(Span, Box<Resolved>, Vec<ResolvedRecordLitArg>),

    /// Ordinary declaration call retaining canonical Lazy normalization roles.
    /// Scar normalizes the inputs and emits an ordinary application of `func`.
    LazyApp(Span, LazyCaptureKind, Box<Resolved>, Vec<Resolved>),

    /// Explicit generic-slot application.
    ReturnTypeArgumentApply(Span, Box<Resolved>, Vec<ResolvedReturnTypeArgument>),

    /// Block of statements
    Block(Span, Vec<Resolved>),

    /// Binding: `x = expr`
    Bind(Span, ResolvedPattern, Box<Resolved>),

    /// Safe bind: `x =? expr` — unwrap `Ok(x)`, propagate `Err` early
    /// The final span is the producer-owned failure operator origin.
    SafeBind(Span, ResolvedPattern, Box<Resolved>, Span),

    /// Statement-only `expr?`, retaining its Unit-success constraint for Scar.
    StatementQuestion(Span, Box<Resolved>),

    /// Compiler-owned monadic sequencing expression.
    Do(
        Span,
        IntrinsicId,
        ResolvedDoContract,
        Vec<ResolvedReturnTypeArgument>,
        Vec<ResolvedDoStatement>,
    ),

    /// Binary operation
    BinOp(Span, BinOp, Box<Resolved>, Box<Resolved>),

    /// Value pipe
    Pipe(Span, Box<Resolved>, Box<Resolved>),

    /// Context map
    ContextMap(Span, Box<Resolved>, Box<Resolved>),

    /// Applicative application
    ContextApply(Span, Box<Resolved>, Box<Resolved>),

    /// Context bind
    ContextBind(Span, Box<Resolved>, Box<Resolved>),

    /// Plain function composition
    Compose(Span, Box<Resolved>, Box<Resolved>),

    /// Lifted composition
    LiftedCompose(Span, Box<Resolved>, Box<Resolved>),

    /// Kleisli composition
    KleisliCompose(Span, Box<Resolved>, Box<Resolved>),

    /// Empty list literal
    ListNil(Span),

    /// Cons-style list construction
    ListCons(Span, Box<Resolved>, Box<Resolved>),

    /// Fixed list literal
    ListLiteral(Span, Vec<Resolved>),

    /// Inclusive range literal
    RangeLiteral(Span, Box<Resolved>, Box<Resolved>),

    /// Tuple literal
    TupleLiteral(Span, Vec<Resolved>),

    /// Parenthesized expression preserved for operator RHS disambiguation.
    Grouped(Span, Box<Resolved>),

    /// Ordered cond conditions and bodies; lowered after type checking.
    Cond(Span, Vec<(Resolved, Resolved)>),

    /// Interpolated string
    InterpolatedStr(Span, Vec<ResolvedInterpolatedPart>),

    /// `dbg!(expr1, expr2, ...)` special form
    Dbg(Span, Vec<Resolved>),

    /// Internal conditional for the retained logical builtin paths
    If(Span, Box<Resolved>, Box<Resolved>, Option<Box<Resolved>>),

    /// `Result::cause(value, err)` special form
    Cause(Span, Box<Resolved>, Box<Resolved>),

    /// Bare canonical deferror declaration used as an ordinary opaque value.
    ErrorKind(Span, ResolvedId),

    /// Match expression
    Match(Span, Box<Resolved>, Vec<ResolvedMatchArm>),
    /// Canonical is_match call; preserves the source call boundary for Lazy normalization.
    IsMatch(Span, Box<Resolved>, Vec<ResolvedMatchArm>),
    IfLet(Span, Box<Resolved>, Vec<ResolvedMatchArm>, bool),

    /// Field access: `expr.field`
    FieldAccess(Span, Box<Resolved>, Symbol),

    /// Non-identifier Facet path segment, or an identifier segment with an optional marker.
    FacetSegmentAccess(Span, Box<Resolved>, ResolvedFacetPathSegment),

    /// Inferred field/facet capture: `_.field` / `_.field.subfield`
    InferredFacetCapture(Span, Vec<ResolvedFacetPathSegment>),

    /// Compiler-managed Facet shorthand capture: `~source.path`
    FacetCapture(Span, Box<Resolved>),

    /// Process-local handler dependency access: `ctx.<slot>`.
    ProcessContextHandler(Span, Symbol),

    /// Struct literal: `User { name: "alice", age, active: is_active }`
    StructLit(Span, ResolvedId, Vec<ResolvedStructLitField>),

    /// Constructor call: `Point(1.0, 2.0)`
    ConstructorCall(Span, ResolvedId, Vec<ResolvedRecordLitArg>),

    /// Enum constructor whose owner type arguments were supplied explicitly.
    EnumConstructorCall(Span, ResolvedId, Vec<AstTy>, Vec<ResolvedRecordLitArg>),

    /// Struct definition (passed through for Scar)
    StructDef(
        Span,
        ResolvedId,
        Vec<ResolvedTypeParam>,
        Vec<ResolvedField>,
        ResolvedDeclAttrs,
    ),

    /// Record definition (passed through for Scar)
    RecordDef(Span, ResolvedId, Vec<ResolvedField>, ResolvedDeclAttrs),

    /// Error type definition
    DeferrorDef(Span, ResolvedId, Vec<ResolvedField>, Box<Resolved>),

    /// Enum definition
    EnumDef(
        Span,
        ResolvedId,
        Vec<ResolvedTypeParam>,
        Vec<ResolvedEnumVariant>,
        ResolvedDeclAttrs,
    ),

    /// Function definition
    Def(
        Span,
        ResolvedId,
        Vec<ResolvedReturnTypeArgument>,
        Vec<ResolvedValueParameter>,
        Option<ResolvedSignatureTy>,
        Option<ResolvedWhereClause>,
        Box<Resolved>,
        ResolvedDeclAttrs,
    ),

    /// Top-level constant definition.
    ConstDef(
        Span,
        ResolvedId,
        Option<AstTy>,
        Box<Resolved>,
        ResolvedDeclAttrs,
    ),

    ExtractorDef(
        Span,
        ResolvedId,
        Vec<ResolvedTypeParam>,
        Vec<ResolvedExtractorParam>,
        AstTy,
        Box<Resolved>,
        ResolvedDeclAttrs,
    ),

    /// Trait definition
    TraitDef(
        Span,
        ResolvedId,
        Vec<ResolvedTypeParam>,
        Option<ResolvedWhereClause>,
        Vec<ResolvedTraitMethodSig>,
        ResolvedDeclAttrs,
    ),

    /// Trait impl definition
    TraitImplDef(
        Span,
        u32,
        ResolvedId,
        Vec<AstTy>,
        AstTy,
        Option<ResolvedWhereClause>,
        Vec<ResolvedTraitImplMethod>,
    ),

    /// Builtin declaration
    BuiltinDecl(
        Span,
        ResolvedId,
        Vec<ResolvedReturnTypeArgument>,
        Vec<ResolvedValueParameter>,
        Option<ResolvedSignatureTy>,
        Option<ResolvedWhereClause>,
        ResolvedDeclAttrs,
    ),

    BuiltinExtractorDecl(
        Span,
        ResolvedId,
        Vec<ResolvedExtractorParam>,
        AstTy,
        ResolvedDeclAttrs,
    ),

    /// Builtin type declaration
    BuiltinTypeDecl(Span, ResolvedId, Vec<Symbol>, ResolvedDeclAttrs),

    /// Compile-time-only alias for a function signature.
    TypeAlias(
        Span,
        Symbol,
        Vec<ResolvedTypeParam>,
        AstTy,
        SymbolIdentityInfo,
    ),

    /// Closure literal
    Closure(
        Span,
        Vec<ResolvedClosureParam>,
        Vec<ResolvedId>,
        Box<Resolved>,
    ),

    /// First-class Extractor literal with ordinary lexical capture identities.
    ExtractorClosure(
        Span,
        Vec<ResolvedClosureParam>,
        Vec<ResolvedId>,
        Box<Resolved>,
    ),

    /// Closure generated from a named capture expression. Keeps the source
    /// origin explicit after capture lowering.
    CaptureClosure(
        Span,
        Vec<ResolvedClosureParam>,
        Vec<ResolvedId>,
        Box<Resolved>,
    ),

    /// Captured function value
    Capture(Span, Box<Resolved>, Vec<Resolved>),

    /// Semicolon — explicit Unit coercion
    Semi(Span, Box<Resolved>),

    /// String-keyed HashMap literal
    HashMapLiteral(Span, Vec<ResolvedHashMapLiteralEntry>),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedDoStatement {
    Extract {
        span: Span,
        operator_span: Span,
        pattern_span: Span,
        pattern: ResolvedPattern,
        rhs: Resolved,
    },
    SafeBind {
        span: Span,
        operator_span: Span,
        pattern_span: Span,
        pattern: ResolvedPattern,
        rhs: Resolved,
    },
    Statement(Resolved),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedMatchArm {
    pub pattern: ResolvedPattern,
    pub guard: Option<Resolved>,
    pub body: Resolved,
}

/// Interpolated string fragment (resolved).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedInterpolatedPart {
    Text(String),
    Expr(Box<Resolved>),
}

/// Pattern in a binding (resolved).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedPattern {
    /// Source boundary of structural patterns whose children do not cover their syntax.
    Located(Span, Box<ResolvedPattern>),
    Projection {
        index: u8,
        id: ResolvedId,
        inner: Box<ResolvedPattern>,
        annotation: Option<AstTy>,
    },
    /// Signature-dependent bindings, selected by Scar before checking the continuation.
    Deferred {
        pattern: Box<ResolvedPattern>,
        bindings: Vec<ResolvedPatternBinding>,
        /// False for is_match, whose selected payloads must not introduce names.
        allow_bindings: bool,
    },
    /// A lexical head whose signature determines the argument roles.
    ExtractorApplication {
        head: ResolvedId,
        args: Vec<ResolvedPatternArgument>,
    },
    Var(ResolvedId),
    Annotated(ResolvedId, AstTy),
    Pin(ResolvedId),
    Wildcard(Span),
    AnnotatedWildcard(Span, AstTy),
    ListNil(Span),
    ListCons(Box<ResolvedPattern>, Box<ResolvedPattern>),
    IntLit(Span, SurtrInt),
    StrLit(Span, String),
    BoolLit(Span, bool),
    DurationLit(Span, SurtrInt),
    Constructor(ResolvedId, Vec<ResolvedPattern>),
    /// Ordered lookups with expression keys resolved before pattern bindings.
    HashMap(Span, Vec<(Resolved, ResolvedPattern)>),
    /// Compiler-owned structural Record pattern. Named fields are normalized by Scar.
    Record(ResolvedId, Vec<(Option<Symbol>, ResolvedPattern)>),
    Extractor(ResolvedId, Vec<Resolved>, Vec<ResolvedPattern>),
    Tuple(Vec<ResolvedPattern>),
    Or(Vec<ResolvedPattern>),
    As(Box<ResolvedPattern>, ResolvedId, Option<AstTy>),
}

/// A lexical name provisionally introduced by an unclassified Pattern argument.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedPatternBinding {
    pub proxy: ResolvedId,
    /// Identity to retain when the candidate does not become a payload binding.
    /// Absence is diagnosed only if a continuation actually references the proxy.
    pub outer: Option<ResolvedId>,
}

/// Both legal roles keep their independently resolved identity or original error.
/// Selecting one role never consults or evaluates the other candidate.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedPatternArgument {
    pub span: Span,
    pub expr: Result<Box<Resolved>, crate::error::ResolveError>,
    pub pattern: Result<Box<ResolvedPattern>, crate::error::ResolveError>,
}

/// Record literal argument (resolved).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedRecordLitArg {
    Positional(Resolved),
    Named(Symbol, Resolved),
}

/// Field definition (resolved) — used in StructDef / RecordDef / DeferrorDef.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedField {
    pub id: Option<ResolvedId>,
    pub name: Symbol,
    pub ty: AstTy,
    pub span: Span,
    pub visibility: Visibility,
    pub readonly: bool,
}

/// A resolved declaration or call-site return type argument.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedReturnTypeArgument {
    pub ordinal: u32,
    pub ty: ResolvedSignatureTy,
    pub span: Span,
}

/// A resolved declaration-side value parameter.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedValueParameter {
    pub id: ResolvedId,
    pub mode: ValueParameterMode,
    pub ty: ResolvedSignatureTy,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedExtractorParam {
    pub id: ResolvedId,
    pub ty: Option<AstTy>,
}

/// Closure parameter.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedClosureParam {
    /// Source provenance for optional diagnostics; it does not alter the parameter's type.
    #[serde(default)]
    pub lazy_capture: Option<ResolvedLazyCaptureParam>,
    pub id: ResolvedId,
    pub ty: Option<AstTy>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedEnumVariant {
    pub id: ResolvedId,
    pub payload: Vec<AstTy>,
    pub discriminant: Option<SurtrInt>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedTraitMethodSig {
    pub id: ResolvedId,
    pub return_type_arguments: Vec<ResolvedReturnTypeArgument>,
    pub type_params: Vec<ResolvedTypeParam>,
    pub value_parameters: Vec<ResolvedValueParameter>,
    pub ret_ty: ResolvedSignatureTy,
    pub where_clause: Option<ResolvedWhereClause>,
    pub body: Option<Box<Resolved>>,
    pub attrs: ResolvedDeclAttrs,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedWhereClause {
    pub constraints: Vec<ResolvedWhereConstraint>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedWhereConstraint {
    pub subject: AstTy,
    pub bounds: Vec<ResolvedWhereConstraintRhs>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResolvedWhereConstraintRhs {
    Trait {
        trait_id: ResolvedId,
    },
    TypeConstructor {
        span: Span,
        slots: Vec<AstTy>,
    },
    TraitSlot {
        trait_id: ResolvedId,
        slot_name: Symbol,
        slot_ordinal: u32,
        span: Span,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedTraitImplMethod {
    pub method_name: Symbol,
    pub function_id: ResolvedId,
    pub return_type_arguments: Vec<ResolvedReturnTypeArgument>,
    pub type_params: Vec<ResolvedTypeParam>,
    pub value_parameters: Vec<ResolvedValueParameter>,
    pub ret_ty: Option<ResolvedSignatureTy>,
    pub where_clause: Option<ResolvedWhereClause>,
    pub body: Box<Resolved>,
    pub attrs: ResolvedDeclAttrs,
    pub span: Span,
    pub is_builtin: bool,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedTypeParam {
    pub name: Symbol,
    pub bound: Option<Symbol>,
    pub span: Span,
}

/// Canonical declaration roles used by Lazy call normalization and capture diagnostics.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LazyCaptureKind {
    And,
    Or,
    If,
    IfThen,
    IfLet,
    IfLetThen,
    Require,
    Ensure,
    MapErr,
    Cause,
    OrElse,
}

/// Diagnostic-only roles of one generated capture parameter in a canonical Lazy call.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedLazyCaptureParam {
    pub kind: LazyCaptureKind,
    /// Includes occurrences within ordinary expressions, rather than direct Lazy inputs.
    pub ordinary: bool,
    /// Direct placeholder uses only; expressions containing a placeholder are ordinary inputs.
    /// Each entry contains the zero-based source argument ordinal and the use span,
    /// independently of the generated parameter's position after placeholder ordering.
    pub lazy_uses: Vec<(u32, Span)>,
}

impl ResolvedPattern {
    pub fn unlocated(&self) -> &Self {
        match self {
            Self::Located(_, inner) => inner.unlocated(),
            other => other,
        }
    }
}
