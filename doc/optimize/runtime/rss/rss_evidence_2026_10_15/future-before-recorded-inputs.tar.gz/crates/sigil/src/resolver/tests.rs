use super::*;
use sindr::names::{FacetRootKind, TypeIdentity};
use sindr::primitives::int;
use sindr::warning::WarningKind;
use spire::ast::{AstPath, AstTy, BinOp, ImportSpec, Lit};
use spire::parse;

fn standard_test_stages() -> &'static Vec<Vec<StagedModuleAst>> {
    static STAGES: std::sync::OnceLock<Vec<Vec<StagedModuleAst>>> = std::sync::OnceLock::new();
    STAGES.get_or_init(|| {
        let mut stages = vec![Vec::new(), Vec::new()];
        for (index, spec) in
            sindr::stdlib::stdlib_module_specs(sindr::stdlib::StdlibVariant::Default).enumerate()
        {
            let ast = spire::parse_with_context(
                spec.source,
                spire::ParserContext::module(
                    index as u32 + 1,
                    spec.module_path
                        .filter(|path| *path == "Facet")
                        .map(str::to_owned),
                )
                .with_rules(spire::ParseRules::std_module()),
            )
            .expect("standard source parses");
            let fallback =
                const_only_fallback_module_path(&ast, spec.module_path).map(str::to_owned);
            let stage_index = usize::from(spec.stage != sindr::stdlib::StdlibStage::Bootstrap);
            stages[stage_index].extend(staged_modules_from_source_ast(ast, fallback.as_deref()));
        }
        stages
    })
}

fn standard_test_environment() -> &'static ResolveEnvironment {
    static ENV: std::sync::OnceLock<ResolveEnvironment> = std::sync::OnceLock::new();
    ENV.get_or_init(|| {
        ResolveEnvironment::from_stages(standard_test_stages()).expect("standard environment")
    })
}

fn resolve(ast: Vec<Ast>) -> Result<Vec<Resolved>, ResolveError> {
    super::resolve(ast, standard_test_environment())
}

fn resolve_with_warnings(ast: Vec<Ast>) -> Result<PhaseOutput<Vec<Resolved>>, ResolveError> {
    super::resolve_with_warnings(ast, standard_test_environment())
}

fn test_session() -> SigilSession {
    SigilSession::from_environment(
        standard_test_environment(),
        None,
        ResolveResumeState::default(),
    )
    .unwrap()
}

// Internal declaration tests inspect the resolver directly, after the same import validation.
fn prepare_internal_program(ast: Vec<Ast>) -> super::imports::ImportsResolvedProgram {
    let env = standard_test_environment();
    build_module_scope_with_imports(
        &env.global_scope,
        &env.auto_import_modules,
        &env.declaration_index,
        &env.declaration_uids,
        &ast,
        None,
        env.stage_count,
    )
    .expect("internal program imports")
    .program
}

fn resolve_on_cli_sized_stack(source: String) -> Vec<Resolved> {
    std::thread::Builder::new()
        .stack_size(8 * 1024 * 1024)
        .spawn(move || parse_and_resolve(&source).expect("nested source should resolve"))
        .expect("resolver worker should start")
        .join()
        .expect("resolver worker should finish")
}

#[test]
fn standard_trait_member_imports_use_canonical_owner() {
    assert!(parse_and_resolve("add(1, 2)").is_err());
    for source in ["import Add::add\nadd(1, 2)", "import Add::{add}\nadd(1, 2)"] {
        parse_and_resolve(source).expect("standard trait member import");
        let mut session = test_session();
        session
            .resolve(parse(source).unwrap())
            .expect("session trait member import");
        assert_eq!(session.lookup_uid("add"), session.lookup_uid("Add::add"));
        assert_eq!(session.last_imports().success_labels, vec!["Add::add"]);
        assert!(session.resolve(parse("import Add::add").unwrap()).is_err());
    }
}

#[test]
fn session_imports_are_atomic_and_rollback_with_scope() {
    let mut session = test_session();
    let before = session.checkpoint();
    session.resolve(parse("import Add::add").unwrap()).unwrap();
    assert!(session.lookup_uid("add").is_some());
    assert_eq!(session.last_imports().imported_symbols, vec!["add"]);
    session.rollback(before);
    assert!(session.lookup_uid("add").is_none());
    assert!(session.last_imports().success_labels.is_empty());
    assert!(session
        .resolve(parse("import Add::add\nmissing_name").unwrap())
        .is_err());
    assert!(session.lookup_uid("add").is_none());
    session
        .resolve(parse("import Add::add\nadd(1, 2)").unwrap())
        .unwrap();
    assert!(session.resolve(parse("import Add::add").unwrap()).is_err());
}

#[test]
fn standalone_and_session_reject_unknown_imports() {
    let ast = parse("import MissingModule").expect("import parses");
    assert!(
        resolve(ast.clone()).is_err(),
        "standalone must validate imports"
    );
    let mut session = test_session();
    assert!(
        session.resolve(ast).is_err(),
        "session must validate imports"
    );
}

#[test]
fn special_variants_use_standard_enum_declarations() {
    for source in ["Ok(1)", "Err(1)", "Result::Ok(1)", "Boolean::True"] {
        resolve(parse(source).expect("input parses"))
            .expect("standard enum declaration is available");
    }
}

#[test]
fn compiler_builtin_symbols_use_only_the_registered_allocator_slots() {
    let scope = scope_init::initialize_scope();
    let count = scope.bindings().count();
    assert_eq!(scope.next_id() as usize, count);
    for name in ["Ok", "Err", "True", "False", "Result::Ok", "Boolean::True"] {
        assert_eq!(scope.lookup(name), None);
    }
}

#[test]
fn canonical_special_variants_share_alias_and_capture_targets() {
    let mut session = test_session();

    for meta in sindr::names::SPECIAL_ENUM_VARIANT_METAS {
        assert_eq!(
            session.lookup_uid(meta.bare_alias),
            session.lookup_uid(meta.qualified_name)
        );
        let captures = session
            .resolve(parse(&format!("&{}\n&{}", meta.bare_alias, meta.qualified_name)).unwrap())
            .unwrap();
        let targets = captures
            .iter()
            .map(|node| {
                let Resolved::Capture(_, target, _) = node else {
                    panic!("capture expected: {node:?}")
                };
                let Resolved::Var(_, id) = target.as_ref() else {
                    panic!("variant identity expected")
                };
                id
            })
            .collect::<Vec<_>>();
        assert_eq!(targets[0].unique_id, targets[1].unique_id);
        assert_eq!(targets[0].name, meta.qualified_name);
        assert_eq!(
            targets[0]
                .qualified_name
                .as_deref()
                .map(global_surface_name),
            Some(meta.qualified_name)
        );
        assert_eq!(targets[0].symbol_info, targets[1].symbol_info);
    }
}

#[test]
fn reserved_special_variant_aliases_reject_programmatic_binding_and_argument_shadowing() {
    for meta in sindr::names::SPECIAL_ENUM_VARIANT_METAS {
        let span = Span { start: 0, end: 1 };
        let binding = Ast::Bind(
            span.clone(),
            AstPattern::Var(span.clone(), meta.bare_alias.into()),
            Box::new(Ast::Lit(span.clone(), Lit::Int(int(1)))),
        );
        let error = resolve(vec![binding]).expect_err("reserved binding must reject without std");
        assert!(error.message.contains("reserved"));
        let closure = Ast::Closure(
            span.clone(),
            vec![ClosureParam {
                name: meta.bare_alias.into(),
                ty: None,
                span: span.clone(),
            }],
            Box::new(Ast::Lit(span, Lit::Int(int(1)))),
        );
        let error = resolve(vec![closure]).expect_err("reserved argument must reject without std");
        assert!(error.message.contains("reserved"));
    }
}

// Model an import surface with a bare alias while retaining the real Enum
// declaration identity. Enum members normally live in the flat type namespace.
fn variant_import_path(owner: &str) -> AstPath {
    AstPath {
        span: Span { start: 0, end: 1 },
        segments: vec![owner.into()],
    }
}

fn variant_import_registry(target: &str, include_canonical: bool) -> DeclarationIndex {
    let mut ast = if include_canonical {
        canonical_test_enum_declarations()
    } else {
        Vec::new()
    };
    ast.extend(parse_module_ast(
        "defenum Other { Ok(Int), Err(Int), True, False }\n@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }", ""));
    let mut index = precollect_declaration_index(&[vec![staged_module("", ast)]]).unwrap();
    let (owner, alias) = target.rsplit_once("::").unwrap();
    let entry = index
        .values_mut()
        .find(|entry| global_surface_name(&entry.fq_name) == target)
        .unwrap();
    entry.module_path = owner.into();
    entry.name = alias.into();
    index
}

#[test]
fn special_variant_import_aliases_reject_foreign_enum_identity() {
    for target in [
        "Other::Ok",
        "Other::Err",
        "Other::True",
        "Other::False",
        "MatchResult::Ok",
        "MatchResult::Err",
    ] {
        for include_canonical in [false, true] {
            let index = variant_import_registry(target, include_canonical);
            let uids = assign_declaration_uids(&index);
            let scope = build_global_scope(&index, &uids);
            let (owner, alias) = target.rsplit_once("::").unwrap();
            for spec in [
                ImportSpec::Single(alias.into()),
                ImportSpec::List(vec![alias.into()]),
                ImportSpec::All,
            ] {
                let imports = [Ast::Import(
                    Span { start: 0, end: 1 },
                    variant_import_path(owner),
                    spec,
                )];
                let error =
                    build_module_scope_with_imports(&scope, &[], &index, &uids, &imports, None, 0)
                        .err()
                        .expect("foreign import cannot shadow a reserved variant alias");
                assert_eq!(
                    error.diagnostic.reason,
                    crate::error::ResolveErrorReason::Declaration,
                    "{target}: {error:?}"
                );
                let meta = sindr::names::special_enum_variant_alias_meta(alias).unwrap();
                assert_eq!(
                    error.diagnostic.subject.as_deref(),
                    Some(meta.qualified_name)
                );
                assert!(error.message.contains("reserved"), "{target}: {error:?}");
            }
            let auto_imports = [AutoImportModule {
                name: owner.into(),
                stage_index: 0,
            }];
            let error =
                build_module_scope_with_imports(&scope, &auto_imports, &index, &uids, &[], None, 0)
                    .err()
                    .expect("foreign auto-import cannot shadow a reserved variant alias");
            assert_eq!(
                error.diagnostic.reason,
                crate::error::ResolveErrorReason::Declaration,
                "{target}: {error:?}"
            );
        }
    }
}

#[test]
fn special_variant_import_aliases_preserve_canonical_uid_and_duplicate_rule() {
    let index = variant_import_registry("Result::Ok", true);
    let uids = assign_declaration_uids(&index);
    let scope = build_global_scope(&index, &uids);
    let uid = scope.lookup("Result::Ok").unwrap();
    for spec in [
        ImportSpec::Single("Ok".into()),
        ImportSpec::List(vec!["Ok".into()]),
        ImportSpec::All,
    ] {
        let imports = [Ast::Import(
            Span { start: 0, end: 1 },
            variant_import_path("Result"),
            spec,
        )];
        let imported =
            build_module_scope_with_imports(&scope, &[], &index, &uids, &imports, None, 0)
                .expect("canonical variant may retain its own alias");
        assert_eq!(imported.scope.lookup("Ok"), Some(uid));
        assert_eq!(imported.scope.lookup("Result::Ok"), Some(uid));
        assert_eq!(imported.scope.next_id(), scope.next_id());
    }
    let imports = vec![
        Ast::Import(
            Span { start: 0, end: 1 },
            variant_import_path("Result"),
            ImportSpec::Single("Ok".into())
        );
        2
    ];
    let error = build_module_scope_with_imports(&scope, &[], &index, &uids, &imports, None, 0)
        .err()
        .expect("same target does not bypass explicit duplicate imports");
    assert_eq!(
        error.diagnostic.reason,
        crate::error::ResolveErrorReason::Import
    );
    assert!(error.message.contains("Duplicate import"), "{error:?}");
}

#[test]
fn session_variant_allocation_follows_declaration_order_and_rollback() {
    let mut session = test_session();
    let standard_ok = session.lookup_uid("Result::Ok");
    session
        .resolve(parse("defenum First { Value }").unwrap())
        .unwrap();
    let first = session.lookup_uid("First::Value").unwrap();
    let checkpoint = session.checkpoint();
    session
        .resolve(parse("defenum Second { Value }").unwrap())
        .unwrap();
    let second = session.lookup_uid("Second::Value").unwrap();
    assert!(second > first);
    session.rollback(checkpoint);
    assert_eq!(session.lookup_uid("Second::Value"), None);
    assert_eq!(session.lookup_uid("Result::Ok"), standard_ok);
    session
        .resolve(parse("defenum Second { Value }").unwrap())
        .unwrap();
    assert_eq!(session.lookup_uid("Second::Value"), Some(second));
}

#[test]
fn boolean_owner_type_arguments_use_the_normal_enum_arity_diagnostic() {
    for source in ["Boolean<Int>::True", "&Boolean<Int>::False"] {
        let error = parse_and_resolve(source).expect_err("Boolean has no owner type arguments");
        assert!(
            error.message.contains("expects 0 type argument(s), got 1"),
            "{source}: {error:?}"
        );
    }
}

#[test]
fn compiler_registered_internal_builtins_resolve_only_generated_references() {
    for name in [
        "__process_execute",
        "__process_postprocess",
        "__genserver_call_reply",
        "__task_call_timeout",
        "__task_await_timeout",
        "__workers_submit_timeout",
        "__workers_broadcast_timeout",
    ] {
        let span = Span { start: 0, end: 1 };
        let resolved = resolve(vec![Ast::InternalVar(span.clone(), name.into())])
            .expect("parser-generated runtime helper must have an allocated binding");
        let Resolved::Var(_, id) = &resolved[0] else {
            panic!("expected runtime helper reference");
        };
        let registered = compiler_builtin_bindings()
            .into_iter()
            .find(|(_, meta)| meta.name == name)
            .expect("registered metadata");
        assert_eq!(id.unique_id, registered.0);
        assert!(id.compiler_generated);
        let error = resolve(vec![Ast::Var(span, name.into())])
            .expect_err("generated runtime helper is private");
        assert_eq!(
            error.diagnostic.reason,
            crate::error::ResolveErrorReason::Visibility
        );
    }
}

#[test]
fn staged_builtin_members_keep_their_canonical_declaration_uid() {
    for module_path in ["List", "Global::List"] {
        let stages = vec![vec![
            staged_module(module_path, parse_module_ast(
                "@builtin type List<$A>\nimpl List {\n@builtin def zip(left: List<$A>, right: List<$B>) -> List<($A, $B)>\ndefp saved(values: List<Int>) -> List<(Int, Int)> { zip(values, values) }\ndef collect(values: List<Int>) -> List<(Int, Int)> { saved(values) }\n}", module_path)),
        ]];
        let resolved =
            resolve_user_with_modules("List::collect([1, 2])\nList::zip([1], [2])", &stages)
                .expect("builtin and ordinary members should resolve through the same owner");
        let declaration = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::BuiltinDecl(_, id, ..)
                    if id.qualified_name.as_deref().map(global_surface_name)
                        == Some("List::zip") =>
                {
                    Some(id)
                }
                _ => None,
            })
            .expect("zip declaration");
        let Resolved::App(_, target, _) = resolved.last().unwrap() else {
            panic!("expected user call");
        };
        let Resolved::Var(_, reference) = target.as_ref() else {
            panic!("expected builtin reference");
        };
        assert_eq!(declaration.unique_id, reference.unique_id);
        let body = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::Def(_, id, _, _, _, _, body, _)
                    if id.qualified_name.as_deref().map(global_surface_name)
                        == Some("List::saved") =>
                {
                    Some(body)
                }
                _ => None,
            })
            .expect("private ordinary helper");
        let Resolved::Block(_, statements) = body.as_ref() else {
            panic!("expected helper block");
        };
        let Resolved::App(_, target, _) = statements.last().unwrap() else {
            panic!("expected local call");
        };
        let Resolved::Var(_, reference) = target.as_ref() else {
            panic!("expected local builtin reference");
        };
        assert_eq!(declaration.unique_id, reference.unique_id);
    }
}

#[test]
fn user_declarations_follow_registered_builtin_symbols() {
    let resolved = parse_and_resolve("user_binding = 1").expect("user binding should resolve");
    let Resolved::Bind(_, ResolvedPattern::Var(binding), _) = &resolved[0] else {
        panic!("expected user binding");
    };
    assert!(binding.unique_id as usize >= compiler_builtin_bindings().len());
}

#[test]
fn deep_nested_closure_bodies_resolve_on_cli_sized_stack() {
    let depth = 31;
    let source = format!(
        "outer = 7\nbody = {}outer{}",
        "{ marker = 0\n".repeat(depth),
        "\n}".repeat(depth),
    );
    let resolved = resolve_on_cli_sized_stack(source);
    let Resolved::Bind(_, _, body) = &resolved[1] else {
        panic!("expected outer closure binding");
    };
    let Resolved::Closure(_, _, captures, _) = body.as_ref() else {
        panic!("expected closure body");
    };
    assert_eq!(captures.len(), 1);
    assert_eq!(captures[0].name, "outer");
}

#[test]
fn deep_nested_match_blocks_resolve_on_cli_sized_stack() {
    let depth = 16;
    let source = format!(
        "outer = 7\nactual = {}outer{}",
        "match 1 { _ => { marker = 0\n".repeat(depth),
        "\n} }".repeat(depth),
    );
    let resolved = resolve_on_cli_sized_stack(source);
    let Resolved::Bind(_, _, body) = &resolved[1] else {
        panic!("expected nested match binding");
    };
    assert!(matches!(body.as_ref(), Resolved::Match(..)));
}

#[test]
fn bare_lazy_special_form_captures_reject_before_runtime_with_individual_guidance() {
    let modules = vec![
        staged_auto_import_module("Kernel", parse_module_ast(
            "@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean\n@builtin def or(left: Boolean, right: Lazy<Boolean>) -> Boolean\ndef if(condition: Boolean, yes: Lazy<$A>, no: Lazy<$A>) -> $A { yes() }\ndef if_then(condition: Boolean, yes: Lazy<Unit>) -> Unit { yes() }\ndef require(condition: Boolean, error: Lazy<Error>) -> Result<Unit> { Err(error()) }\ndef ensure(value: $A, pred: ($A -> Boolean), error: Lazy<Error>) -> Result<$A> { Ok(value) }", "Kernel")),
        staged_module("Result", parse_module_ast(
            "def map_err(value: Result<$A>, error: Lazy<Error>) -> Result<$A> { value }\n@builtin def cause(value: Result<$A>, error: Lazy<Error>) -> Result<$A>", "Result")),
    ];
    for function in [
        "and",
        "or",
        "if",
        "if_then",
        "require",
        "ensure",
        "Result::map_err",
        "Result::cause",
    ] {
        let error = resolve_user_with_modules(&format!("f = &{function}"), &[modules.clone()])
            .expect_err("bare Lazy capture must reject");
        assert_eq!(
            error.diagnostic.reason,
            crate::error::ResolveErrorReason::Capture,
            "{error:?}"
        );
        assert!(
            error.message.contains(function)
                && error.message.contains("explicit")
                && error.message.contains("Lazy"),
            "{error:?}"
        );
    }
    resolve_user_with_modules("f = &and(&1, &2)\ng = &f", &[modules])
        .expect("existing function identity capture remains valid");
}

fn permissive_module_rules() -> spire::ParseRules {
    spire::ParseRules::permissive_for_tests()
}

fn parse_module_ast(src: &str, module_path: &str) -> Vec<Ast> {
    let mut ast = spire::parse_with_context(
        src,
        spire::ParserContext::module(0, Some(module_path.to_string()))
            .with_rules(permissive_module_rules()),
    )
    .expect("definition source should parse");
    if module_path == "DynamicSupervisor" {
        // The fixture models the compiler-provided internal runtime declarations,
        // not user-authored source surfaces.
        for statement in &mut ast {
            if let Ast::BuiltinDecl(_, name, _, _, _, _, attrs) = statement {
                if matches!(name.as_str(), "spawn" | "adopt" | "status") {
                    attrs.compiler_generated = true;
                }
            }
        }
    }
    ast
}

fn canonical_test_enum_declarations() -> Vec<Ast> {
    spire::parse_with_context(
        "@builtin defenum Result<$T> { Ok($T), Err(Error) }\n@builtin defenum Boolean { True, False }",
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    ).expect("canonical enum declarations parse")
}

fn parse_and_resolve(src: &str) -> Result<Vec<Resolved>, ResolveError> {
    let ast =
        spire::parse_with_context(src, spire::ParserContext::project(0)).expect("parse failed");
    resolve(ast)
}

fn kernel_pattern_test_module() -> StagedModuleAst {
    staged_auto_import_module("Kernel", parse_module_ast(
        "@builtin def if_let(value: $A, pattern: $Pattern, yes: Lazy<$B>, no: Lazy<$B>) -> $B\n@builtin def if_let_then(value: $A, pattern: $Pattern, yes: Lazy<Unit>) -> Unit\n@builtin def is_match(value: $A, pattern: $Pattern) -> Boolean\n@builtin def apply_pattern(value: $A, pattern: $Pattern) -> Result<$B>", "Kernel"))
}

fn parse_and_resolve_pattern_consumers(src: &str) -> Result<Vec<Resolved>, ResolveError> {
    let user_len = spire::parse_with_context(src, spire::ParserContext::project(0))
        .unwrap()
        .len();
    let mut resolved = resolve_user_with_modules(src, &[vec![kernel_pattern_test_module()]])?;
    Ok(resolved.split_off(resolved.len() - user_len))
}

fn parse_and_resolve_with_warnings(
    src: &str,
) -> Result<sindr::warning::PhaseOutput<Vec<Resolved>>, ResolveError> {
    let ast =
        spire::parse_with_context(src, spire::ParserContext::project(0)).expect("parse failed");
    resolve_with_warnings(ast)
}

#[test]
fn lower_module_source_ast_attaches_namespace_consts_to_fallback_module() {
    let ast = spire::parse_with_context(
        r#"
const APP_NAME: String = "surtr"
defmod App {
  def main() -> Int { 1 }
}
"#,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    )
    .expect("definition source should parse");

    let lowered = lower_module_source_ast(ast, Some("App"));

    assert_eq!(lowered.len(), 1);
    assert_eq!(lowered[0].module_path, "Global::App");
    assert!(matches!(
        lowered[0].ast.first(),
        Some(Ast::ConstDef(_, name, _, _, _)) if name == "APP_NAME"
    ));
}

#[test]
fn staged_modules_from_source_ast_projects_lowered_modules() {
    let ast = spire::parse_with_context(
        r#"
import Helper::help
impl User {
  def use() -> Int { help() }
}
"#,
        spire::ParserContext::module(0, Some("User".to_string()))
            .with_rules(spire::ParseRules::std_module()),
    )
    .expect("definition source should parse");

    let staged = staged_modules_from_source_ast(ast, Some("User"));

    assert_eq!(staged.len(), 1);
    assert_eq!(staged[0].module_path, "Global::User");
    assert!(matches!(staged[0].ast.first(), Some(Ast::Import(_, _, _))));
    assert!(matches!(
        staged[0].ast.get(1),
        Some(Ast::ImplDef(_, _, _, _, _))
    ));
}

#[test]
fn lower_module_source_ast_preserves_explicit_owner_provenance() {
    let ast = spire::parse_with_context(
        "defmod App { def run() { () } }",
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::module_source()),
    )
    .expect("definition source should parse");
    let expected_span = ast[0].span().clone();

    let lowered = lower_module_source_ast(ast, None);
    let owner = lowered[0]
        .owner
        .as_ref()
        .expect("explicit defmod should preserve its owner");

    assert_eq!(owner.canonical_path, "Global::App");
    assert_eq!(owner.span, expected_span);
    assert_eq!(owner.source_form, OwnerSourceForm::Defmod);
}

#[test]
fn extract_process_modules_from_user_ast_hoists_shared_imports_and_removes_process_defs() {
    let ast = spire::parse_with_context(
        r#"
import Helper::help
defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int) -> Result<Int> { Ok(state) }
}

def main() -> Int { help() }
"#,
        spire::ParserContext::script(0).with_rules(permissive_module_rules()),
    )
    .expect("script source should parse");

    let (process_modules, remaining_ast) = extract_process_modules_from_user_ast(ast);

    assert_eq!(process_modules.len(), 1);
    assert_eq!(process_modules[0].module_path, "Global::Counter");
    assert!(matches!(
        process_modules[0].ast.first(),
        Some(Ast::Import(_, _, _))
    ));
    assert!(process_modules[0].process_spec.is_some());
    assert!(remaining_ast
        .iter()
        .all(|stmt| !matches!(stmt, Ast::Defagent(_, _, _, _, _))));
    assert!(remaining_ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::Import(_, _, _))));
    assert!(remaining_ast
        .iter()
        .any(|stmt| matches!(stmt, Ast::Def(..))));
}

#[test]
fn const_only_fallback_module_path_requires_const_only_source() {
    let const_only = parse_module_ast("import Env::env\nconst VERSION: Int = 1", "Config");
    assert_eq!(
        const_only_fallback_module_path(&const_only, Some("Config")),
        Some("Config")
    );

    let with_def = parse_module_ast(
        "const VERSION: Int = 1\ndef version() -> Int { VERSION }",
        "Config",
    );
    assert_eq!(
        const_only_fallback_module_path(&with_def, Some("Config")),
        None
    );
}

#[test]
fn test_dbg_special_form_resolves_without_name_lookup() {
    let resolved = parse_and_resolve(
        r#"dbg = {|x| x}
value = dbg!(dbg(1), 2)"#,
    )
    .expect("dbg special form should resolve");

    let dbg_node = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
                Resolved::Dbg(_, args) => Some(args),
                _ => None,
            },
            Resolved::Dbg(_, args) => Some(args),
            _ => None,
        })
        .expect("expected resolved dbg node");

    assert_eq!(dbg_node.len(), 2);
}

#[test]
fn test_warning_unused_local_binding_warns() {
    let output = parse_and_resolve_with_warnings(
        r#"def main() -> Int {
  unused = 1
  2
}"#,
    )
    .expect("program should resolve");

    let messages = warning_messages(&output, WarningKind::UnusedVariable);
    assert!(
        messages.iter().any(|message| message.contains("unused")),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_warning_used_local_binding_does_not_warn() {
    let output = parse_and_resolve_with_warnings(
        r#"def main() -> Int {
  used = 1
  used
}"#,
    )
    .expect("program should resolve");

    assert!(
        output.warnings.is_empty(),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_warning_function_param_and_match_alias_warn() {
    let output = parse_and_resolve_with_warnings(
        r#"def pick(value: Result<Int>, extra: Int) -> Int {
  match value {
    Ok(x) @ whole => x,
    Err(_) => 0,
  }
}"#,
    )
    .expect("program should resolve");

    let messages = warning_messages(&output, WarningKind::UnusedVariable);
    assert!(
        messages.iter().any(|message| message.contains("extra")),
        "warnings: {:?}",
        output.warnings
    );
    assert!(
        messages.iter().any(|message| message.contains("whole")),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_warning_wildcard_pattern_does_not_warn() {
    let output = parse_and_resolve_with_warnings(
        r#"def ignore(value: Int) -> Int {
  match value {
    _ => 0,
  }
}"#,
    )
    .expect("program should resolve");

    assert!(
        output.warnings.is_empty(),
        "warnings: {:?}",
        output.warnings
    );
}

fn staged_module(module_path: &str, ast: Vec<Ast>) -> StagedModuleAst {
    StagedModuleAst {
        source_index: 0,
        module_path: module_path.to_string(),
        doc_module_path: None,
        ast,
        owner: None,
        module_doc: None,
        auto_import: matches!(module_path, "Bootstrap" | "Kernel" | "Result"),
        process_spec: None,
    }
}

fn staged_do_intrinsic_contract(owner: &str, intrinsic_source: &str) -> Vec<Vec<StagedModuleAst>> {
    let support = staged_module(
        "",
        parse_module_ast(
            r#"@builtin type DoBlock<$Result>
deftrait Monad
where
  Self: Type<$A>
{
  def bind(self: Self<$A>, mapper: ($A -> Self<$B>)) -> Self<$B>
}"#,
            "",
        ),
    );
    let mut surface = staged_module(owner, parse_module_ast(intrinsic_source, owner));
    surface.owner = Some(OwnerDescriptor::new(
        owner.to_string(),
        surface.ast[0].span().clone(),
        OwnerSourceForm::Defmod,
    ));
    vec![vec![support, surface]]
}

fn staged_process_module(ast: Vec<Ast>) -> StagedModuleAst {
    match ast.into_iter().next().expect("process module should exist") {
        Ast::Defagent(span, module_path, ast, process_spec, attrs) => StagedModuleAst {
            source_index: 0,
            owner: Some(OwnerDescriptor {
                canonical_path: module_path.clone(),
                span,
                source_form: OwnerSourceForm::Defagent,
            }),
            module_path,
            doc_module_path: None,
            ast,
            module_doc: attrs.doc,
            auto_import: attrs.auto_import,
            process_spec: Some(process_spec),
        },
        Ast::Defgenserver(span, module_path, ast, process_spec, attrs) => StagedModuleAst {
            source_index: 0,
            owner: Some(OwnerDescriptor {
                canonical_path: module_path.clone(),
                span,
                source_form: OwnerSourceForm::Defgenserver,
            }),
            module_path,
            doc_module_path: None,
            ast,
            module_doc: attrs.doc,
            auto_import: attrs.auto_import,
            process_spec: Some(process_spec),
        },
        Ast::Defsupervisor(span, module_path, ast, process_spec, attrs) => StagedModuleAst {
            source_index: 0,
            owner: Some(OwnerDescriptor {
                canonical_path: module_path.clone(),
                span,
                source_form: OwnerSourceForm::Defsupervisor,
            }),
            module_path,
            doc_module_path: None,
            ast,
            module_doc: attrs.doc,
            auto_import: attrs.auto_import,
            process_spec: Some(process_spec),
        },
        Ast::DefdynamicSupervisor(span, module_path, ast, process_spec, attrs) => StagedModuleAst {
            source_index: 0,
            owner: Some(OwnerDescriptor {
                canonical_path: module_path.clone(),
                span,
                source_form: OwnerSourceForm::DefdynamicSupervisor,
            }),
            module_path,
            doc_module_path: None,
            ast,
            module_doc: attrs.doc,
            auto_import: attrs.auto_import,
            process_spec: Some(process_spec),
        },
        other => panic!("expected process module, got {other:?}"),
    }
}

fn staged_auto_import_module(module_path: &str, ast: Vec<Ast>) -> StagedModuleAst {
    StagedModuleAst {
        source_index: 0,
        module_path: module_path.to_string(),
        doc_module_path: None,
        ast,
        owner: None,
        module_doc: None,
        auto_import: true,
        process_spec: None,
    }
}

fn resolve_user_with_modules(
    user_src: &str,
    module_stages: &[Vec<StagedModuleAst>],
) -> Result<Vec<Resolved>, ResolveError> {
    let user_ast = spire::parse_with_context(user_src, spire::ParserContext::project(0))
        .expect("user script should parse");
    let mut canonical_declarations = canonical_test_enum_declarations();
    canonical_declarations.retain(|candidate| {
        let Ast::EnumDef(_, candidate_name, ..) = candidate else {
            unreachable!()
        };
        !module_stages
            .iter()
            .flatten()
            .flat_map(|module| &module.ast)
            .any(|node| matches!(node, Ast::EnumDef(_, name, ..) if name == candidate_name))
    });
    let mut full_stages = vec![vec![
        staged_module("", canonical_declarations),
        staged_module(
            "Bootstrap",
            parse_module_ast(
                r#"@builtin def print(a: String) -> Unit
@builtin def to_string(a: $A) -> String
@builtin def inspect(a: $A) -> String
@builtin def safe_div(a: $A, b: $A) -> Result<$A, ZeroDivisionError>
@builtin def safe_mod(a: Int, b: Int) -> Result<Int, ZeroDivisionError>
@builtin def eprint(err: Error) -> Unit
@builtin def set_exit_code(code: Int) -> Unit
deferror NoneError { "none" }
deferror ZeroDivisionError { "division by zero" }
deferror EmptyList { "Empty List." }
deferror IndexOutOfBounds(detail: String) { |detail: String| Self(message: detail, detail: detail) }"#,
                "Bootstrap",
            ),
        ),
    ]];
    full_stages.push(vec![
        staged_module(
            "Agent",
            parse_module_ast(
                r#"@hidden
@builtin def pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>
@hidden
@builtin def state(pid: PID<$Process>) -> Result<$State>
@hidden
@builtin def store(pid: PID<$Process>, state: $State) -> Result<Unit>"#,
                "Agent",
            ),
        ),
        staged_module(
            "GenServer",
            parse_module_ast(
                r#"@hidden
@builtin def pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>
@hidden
@builtin def state(pid: PID<$Process>) -> Result<$State>
@hidden
@builtin def store(pid: PID<$Process>, state: $State) -> Result<Unit>"#,
                "GenServer",
            ),
        ),
        staged_module(
            "DynamicSupervisor",
            parse_module_ast(
                r#"@builtin def spawn(worker_init: (-> Result<$State>)) -> Result<PID<$Process>>"#,
                "DynamicSupervisor",
            ),
        ),
    ]);
    full_stages.extend(module_stages.iter().cloned());
    let declaration_index =
        precollect_declaration_index(&full_stages).expect("precollect should succeed");
    resolve_staged_program(
        &full_stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
}

fn resolve_user_with_modules_with_warnings(
    user_src: &str,
    module_stages: &[Vec<StagedModuleAst>],
) -> Result<sindr::warning::PhaseOutput<Vec<Resolved>>, ResolveError> {
    let user_ast = spire::parse_with_context(user_src, spire::ParserContext::project(0))
        .expect("user script should parse");
    let mut canonical_declarations = canonical_test_enum_declarations();
    canonical_declarations.retain(|candidate| {
        let Ast::EnumDef(_, candidate_name, ..) = candidate else {
            unreachable!()
        };
        !module_stages
            .iter()
            .flatten()
            .flat_map(|module| &module.ast)
            .any(|node| matches!(node, Ast::EnumDef(_, name, ..) if name == candidate_name))
    });
    let mut full_stages = vec![vec![
        staged_module("", canonical_declarations),
        staged_module(
            "Bootstrap",
            parse_module_ast(
                r#"@builtin def print(a: String) -> Unit
@builtin def to_string(a: $A) -> String
@builtin def inspect(a: $A) -> String
@builtin def safe_div(a: $A, b: $A) -> Result<$A, ZeroDivisionError>
@builtin def safe_mod(a: Int, b: Int) -> Result<Int, ZeroDivisionError>
@builtin def eprint(err: Error) -> Unit
@builtin def set_exit_code(code: Int) -> Unit
deferror NoneError { "none" }
deferror ZeroDivisionError { "division by zero" }
deferror EmptyList { "Empty List." }
deferror IndexOutOfBounds(detail: String) { |detail: String| Self(message: detail, detail: detail) }"#,
                "Bootstrap",
            ),
        ),
    ]];
    full_stages.push(vec![
        staged_module(
            "Agent",
            parse_module_ast(
                r#"@hidden
@builtin def pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>
@hidden
@builtin def state(pid: PID<$Process>) -> Result<$State>
@hidden
@builtin def store(pid: PID<$Process>, state: $State) -> Result<Unit>"#,
                "Agent",
            ),
        ),
        staged_module(
            "GenServer",
            parse_module_ast(
                r#"@hidden
@builtin def pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>
@hidden
@builtin def state(pid: PID<$Process>) -> Result<$State>
@hidden
@builtin def store(pid: PID<$Process>, state: $State) -> Result<Unit>"#,
                "GenServer",
            ),
        ),
        staged_module(
            "DynamicSupervisor",
            parse_module_ast(
                r#"@builtin def spawn(worker_init: (-> Result<$State>)) -> Result<PID<$Process>>"#,
                "DynamicSupervisor",
            ),
        ),
    ]);
    full_stages.extend(module_stages.iter().cloned());
    let declaration_index =
        precollect_declaration_index(&full_stages).expect("precollect should succeed");
    resolve_staged_program_with_warnings(
        &full_stages,
        user_ast,
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
}

fn warning_messages(
    output: &sindr::warning::PhaseOutput<Vec<Resolved>>,
    kind: WarningKind,
) -> Vec<String> {
    output
        .warnings
        .iter()
        .filter(|warning| warning.kind == kind)
        .map(|warning| warning.message.clone())
        .collect()
}

#[test]
fn test_precollect_declaration_index_succeeds_without_body_resolution() {
    let module_stages = vec![vec![staged_module(
        "Bootstrap",
        parse_module_ast(
            r#"def to_int(x: String) -> Int { unknown_name }
defrecord Pair(left: Int, right: Int)
deferror Oops(reason: String) { |reason: String| Self(message: reason, reason: reason) }"#,
            "Bootstrap",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    assert!(index.contains_key("Bootstrap::to_int"));
    assert!(index.contains_key("Global::Pair"));
    assert!(index.contains_key("Global::Oops"));
}

#[test]
fn test_precollect_builtin_decl_in_module() {
    let module_stages = vec![vec![staged_module(
        "Int",
        parse_module_ast(
            r#"@builtin def shl(value: Int, bits: Int) -> Result<Int, NegativeShiftCount>"#,
            "Int",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    assert!(index.contains_key("Int::shl"));
}

#[test]
fn test_resolve_staged_program_keeps_process_specs() {
    let kernel = staged_module(
        "Agent",
        parse_module_ast(
            r#"@hidden
@builtin def pid(owner: $Owner, init: (-> Result<$State>)) -> PID<$Process>

@hidden
@builtin def state(pid: PID<$Process>) -> Result<$State>

@hidden
@builtin def store(pid: PID<$Process>, state: $State) -> Result<Unit>"#,
            "Agent",
        ),
    );
    let ast = spire::parse_with_context(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { 0 }

  @get
  def get(state: Int, _field: String) -> Result<Int> { state }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { next }
}"#,
        spire::ParserContext::module(0, Some("Counter".to_string()))
            .with_rules(permissive_module_rules()),
    )
    .expect("definition source should parse");

    let module = match ast.into_iter().next().expect("lowered module should exist") {
        Ast::Defagent(span, module_path, ast, process_spec, attrs) => StagedModuleAst {
            source_index: 0,
            owner: Some(OwnerDescriptor {
                canonical_path: module_path.clone(),
                span,
                source_form: OwnerSourceForm::Defagent,
            }),
            module_path,
            doc_module_path: None,
            ast,
            module_doc: attrs.doc,
            auto_import: attrs.auto_import,
            process_spec: Some(process_spec),
        },
        other => panic!("expected defagent, got {other:?}"),
    };
    // Generated getters construct the canonical Result::Ok after postprocessing.
    let standard_stage = canonical_test_enum_declarations()
        .into_iter()
        .flat_map(|declaration| staged_modules_from_source_ast(vec![declaration], None))
        .collect();
    let module_stages = vec![standard_stage, vec![kernel, module]];
    let declaration_index =
        precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let resolved =
        resolve_staged_program_with_state(&module_stages, Vec::new(), &declaration_index, None)
            .expect("resolve should succeed");

    assert_eq!(resolved.process_specs.len(), 1);
    let spec = &resolved.process_specs[0];
    assert_eq!(spec.module_path, "Global::Counter");
    assert_eq!(spec.process_name, "Global::Counter");
}

#[test]
fn test_precollect_declaration_index_rejects_duplicate_fully_qualified_name() {
    let module_stages = vec![vec![
        staged_module(
            "Std::Math",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Std::Math"),
        ),
        staged_module(
            "Std::Math",
            parse_module_ast(r#"def add(a: Int, b: Int) -> Int { a + b }"#, "Std::Math"),
        ),
    ]];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("duplicate fully-qualified declaration must fail");
    assert!(err
        .message
        .contains("Duplicate fully-qualified declaration: Std::Math::add"));
}

#[test]
fn test_precollect_owner_registry_rejects_record_then_module() {
    let ast = spire::parse_with_context(
        r#"defrecord Hoge(a: String)
defmod Hoge { def test() { () } }"#,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::module_source()),
    )
    .expect("definition source should parse");
    let first_span = ast[0].span().clone();
    let conflicting_span = ast[1].span().clone();
    let staged = staged_modules_from_source_ast(ast, None);
    let module_stages = vec![staged];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("record and module owners must share one namespace");

    assert_eq!(err.message, "Duplicate top-level owner: Hoge");
    assert_eq!(err.span, conflicting_span);
    assert!(err.related_labels.iter().any(|label| {
        label.span == first_span
            && label.message.starts_with("first ")
            && label.message.ends_with(" declaration")
    }));
}

#[test]
fn test_precollect_owner_registry_rejects_module_then_record() {
    let ast = spire::parse_with_context(
        r#"defmod Hoge { def test() { () } }
defrecord Hoge(a: String)"#,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::module_source()),
    )
    .expect("definition source should parse");
    let first_span = ast[0].span().clone();
    let conflicting_span = ast[1].span().clone();
    let staged = staged_modules_from_source_ast(ast, None);
    let module_stages = vec![staged];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("module and record owners must share one namespace");

    assert_eq!(err.message, "Duplicate top-level owner: Hoge");
    assert_eq!(err.span, conflicting_span);
    assert!(err.related_labels.iter().any(|label| {
        label.span == first_span
            && label.message.starts_with("first ")
            && label.message.ends_with(" declaration")
    }));
}

fn assert_reverse_owner_collision(src: &str, name: &str) {
    let ast = parse_module_ast(src, "");
    let first_span = ast[0].span().clone();
    let conflicting_span = ast[1].span().clone();
    let module_stages = vec![vec![staged_module("", ast)]];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("top-level owners with the same name must collide");

    assert_eq!(err.message, format!("Duplicate top-level owner: {name}"));
    assert_eq!(err.span, conflicting_span);
    assert!(err.related_labels.iter().any(|label| {
        label.span == first_span
            && label.message.starts_with("first ")
            && label.message.ends_with(" declaration")
    }));
}

#[test]
fn test_precollect_owner_registry_rejects_enum_then_trait() {
    assert_reverse_owner_collision(
        r#"defenum Same { First }
deftrait Same {}"#,
        "Same",
    );
}

fn assert_constructor_trait_collision_labels(
    src: &str,
    first_identity: &str,
    conflicting_identity: &str,
) {
    let ast = spire::parse_with_context(src, spire::ParserContext::project(0))
        .expect("constructor-trait collision source should parse");
    let module_stages = vec![ast
        .into_iter()
        .flat_map(|stmt| staged_modules_from_source_ast(vec![stmt], None))
        .collect::<Vec<_>>()];

    let err = precollect_owner_registry(&module_stages)
        .expect_err("constructor traits must collide in the owner namespace");

    assert_eq!(
        err.related_labels[0].message,
        format!("first {first_identity} declaration")
    );
    assert_eq!(
        err.related_labels[1].message,
        format!("conflicting {conflicting_identity} declaration")
    );
}

#[test]
fn test_precollect_owner_registry_classifies_direct_constructor_trait_before_collision() {
    for (src, first_identity, conflicting_identity) in [
        (
            r#"deftrait Same
where
  Self: Type<$A>
{}
defstruct Same { value: Int }"#,
            "TypeConstructor",
            "Struct",
        ),
        (
            r#"defstruct Same { value: Int }
deftrait Same
where
  Self: Type<$A>
{}"#,
            "Struct",
            "TypeConstructor",
        ),
    ] {
        assert_constructor_trait_collision_labels(src, first_identity, conflicting_identity);
    }
}

#[test]
fn test_precollect_owner_registry_classifies_inherited_constructor_trait_before_collision() {
    for (src, first_identity, conflicting_identity) in [
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
deftrait Same
where
  Self: Constructor
{}
defrecord Same(value: Int)"#,
            "TypeConstructor",
            "Record",
        ),
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
defrecord Same(value: Int)
deftrait Same
where
  Self: Constructor
{}"#,
            "Record",
            "TypeConstructor",
        ),
    ] {
        assert_constructor_trait_collision_labels(src, first_identity, conflicting_identity);
    }
}

#[test]
fn test_precollect_owner_registry_classifies_colliding_direct_traits_independently() {
    for (src, first_identity, conflicting_identity) in [
        (
            r#"deftrait Same {}
deftrait Same
where
  Self: Type<$A>
{}"#,
            "Trait",
            "TypeConstructor",
        ),
        (
            r#"deftrait Same
where
  Self: Type<$A>
{}
deftrait Same {}"#,
            "TypeConstructor",
            "Trait",
        ),
    ] {
        assert_constructor_trait_collision_labels(src, first_identity, conflicting_identity);
    }
}

#[test]
fn test_precollect_owner_registry_classifies_colliding_inherited_traits_independently() {
    for (src, first_identity, conflicting_identity) in [
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
deftrait Same {}
deftrait Same
where
  Self: Constructor
{}"#,
            "Trait",
            "TypeConstructor",
        ),
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
deftrait Same
where
  Self: Constructor
{}
deftrait Same {}"#,
            "TypeConstructor",
            "Trait",
        ),
    ] {
        assert_constructor_trait_collision_labels(src, first_identity, conflicting_identity);
    }
}

#[test]
fn test_precollect_owner_registry_rejects_struct_then_sig() {
    assert_reverse_owner_collision(
        r#"defstruct Same { value: Int }
type Same = ($A -> $A)"#,
        "Same",
    );
}

#[test]
fn test_precollect_owner_registry_rejects_supervisor_then_agent() {
    let first_span = Span { start: 0, end: 1 };
    let conflicting_span = Span { start: 2, end: 3 };
    let staged_owner = |span: Span, source_form| StagedModuleAst {
        source_index: 0,
        module_path: "Global::ProcessName".to_string(),
        doc_module_path: None,
        ast: Vec::new(),
        owner: Some(OwnerDescriptor {
            canonical_path: "Global::ProcessName".to_string(),
            span,
            source_form,
        }),
        module_doc: None,
        auto_import: false,
        process_spec: None,
    };
    let module_stages = vec![vec![
        staged_owner(first_span.clone(), OwnerSourceForm::Defsupervisor),
        staged_owner(conflicting_span.clone(), OwnerSourceForm::Defagent),
    ]];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("supervisor and agent owners must share one namespace");

    assert_eq!(err.message, "Duplicate top-level owner: ProcessName");
    assert_eq!(err.span, conflicting_span);
    assert!(err.related_labels.iter().any(|label| {
        label.span == first_span
            && label.message.starts_with("first ")
            && label.message.ends_with(" declaration")
    }));
}

#[test]
fn test_precollect_owner_registry_maps_direct_and_promoted_identities() {
    let regular_ast = spire::parse_with_context(
        r#"defmod App { def run() { () } }
defstruct User { name: String }
defrecord Pair(left: Int, right: Int)
defenum Choice { First, Second }
deferror Oops { "oops" }
type Mapper<$A, $B> = ($A -> $B)
const FLAG: Int = 1
deftrait Show {
  def show(self: Self) -> String
}

deftrait Applicative
where
  Self: Functor
{
  def pure(value: $A) -> Self<$A>
}
deftrait Functor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
        spire::ParserContext::project(0),
    )
    .expect("project source should parse");
    let standard_ast = spire::parse_with_context(
        r#"@builtin type Int
@builtin type List<$A>
@builtin defenum Option<$T> { Some($T), None }
@builtin defenum Result<$T> { Ok($T), Err(Error) }
@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }
@builtin defenum Boolean { True, False }"#,
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    )
    .expect("standard source should parse");
    let regular_stage = regular_ast
        .into_iter()
        .flat_map(|stmt| staged_modules_from_source_ast(vec![stmt], None))
        .collect::<Vec<_>>();
    let standard_stage = standard_ast
        .into_iter()
        .flat_map(|stmt| staged_modules_from_source_ast(vec![stmt], None))
        .collect::<Vec<_>>();
    let staged_owner = |canonical_path: &str, source_form| StagedModuleAst {
        source_index: 0,
        module_path: canonical_path.to_string(),
        doc_module_path: None,
        ast: Vec::new(),
        owner: Some(OwnerDescriptor {
            canonical_path: canonical_path.to_string(),
            span: Span { start: 0, end: 1 },
            source_form,
        }),
        module_doc: None,
        auto_import: false,
        process_spec: None,
    };
    let process_stage = vec![
        staged_owner("Global::Worker", OwnerSourceForm::Defagent),
        staged_owner("Global::Server", OwnerSourceForm::Defgenserver),
        staged_owner("Global::RootSup", OwnerSourceForm::Defsupervisor),
        staged_owner("Global::DynamicSup", OwnerSourceForm::DefdynamicSupervisor),
    ];
    let all_stages = vec![standard_stage, regular_stage, process_stage];

    let precollected =
        precollect_declarations(&all_stages).expect("distinct owners should precollect");
    let owners = &precollected.owner_registry;

    for (name, identity) in [
        ("Int", TypeIdentity::Type),
        ("List", TypeIdentity::TypeConstructor),
        ("Option", TypeIdentity::TypeConstructor),
        ("Result", TypeIdentity::TypeConstructor),
        ("MatchResult", TypeIdentity::TypeConstructor),
        ("Boolean", TypeIdentity::Enum),
        ("User", TypeIdentity::Struct),
        ("Pair", TypeIdentity::Record),
        ("Choice", TypeIdentity::Enum),
        ("Oops", TypeIdentity::Error),
        ("Mapper", TypeIdentity::Sig),
        ("FLAG", TypeIdentity::Const),
        ("App", TypeIdentity::Mod),
        ("Worker", TypeIdentity::Mod),
        ("Server", TypeIdentity::Mod),
        ("RootSup", TypeIdentity::Supervisor),
        ("DynamicSup", TypeIdentity::Supervisor),
        ("Show", TypeIdentity::Trait),
        ("Functor", TypeIdentity::TypeConstructor),
        ("Applicative", TypeIdentity::TypeConstructor),
    ] {
        assert_eq!(owners.identity_for_owner(name), Some(identity), "{name}");
    }
    assert_eq!(owners.get("Functor").unwrap().kind, OwnerKind::Trait);
    let match_result = user_type_symbol_identity_info(&owners.owner_ref("MatchResult").unwrap())
        .expect("canonical MatchResult owner metadata");
    assert!(!match_result.capabilities.type_annotation);
    assert!(!match_result.capabilities.impl_target);
    assert_eq!(match_result.capabilities.facet_root_path, None);
    assert_eq!(owners.owner_ref("Option").unwrap().canonical_key, "Option");
    let mut resolver = Resolver::new();
    resolver.owner_registry = owners.clone().into();
    assert_eq!(
        resolver.owner_identity_for_declaration("App::run", &DeclarationKind::Def, Some("App"),),
        Some(TypeIdentity::Mod)
    );
    assert!(!precollected.declaration_index.contains_key("Global::App"));
    let scope = build_scope_for_module(&all_stages, None, all_stages.len())
        .expect("owner metadata should not change scope construction");
    assert_eq!(scope.lookup("App"), None);
}

#[test]
fn test_owner_registry_does_not_bind_module_root_in_global_scope() {
    let ast = spire::parse_with_context("defmod Hoge {}", spire::ParserContext::project(0))
        .expect("module owner should parse");
    let module_stages = vec![ast
        .into_iter()
        .flat_map(|stmt| staged_modules_from_source_ast(vec![stmt], None))
        .collect::<Vec<_>>()];
    let precollected =
        precollect_declarations(&module_stages).expect("module owner should precollect");
    assert_eq!(
        precollected.owner_registry.identity_for_owner("Hoge"),
        Some(TypeIdentity::Mod)
    );

    let declaration_uids = assign_declaration_uids(&precollected.declaration_index);
    let scope = build_global_scope(&precollected.declaration_index, &declaration_uids);

    assert_eq!(scope.lookup("Hoge"), None);
}

#[test]
fn test_record_head_remains_bound_in_global_scope() {
    let ast = spire::parse_with_context(
        "defrecord Hoge(value: Int)",
        spire::ParserContext::project(0),
    )
    .expect("record owner should parse");
    let module_stages = vec![staged_modules_from_source_ast(ast, None)];
    let precollected =
        precollect_declarations(&module_stages).expect("record owner should precollect");
    let declaration_uids = assign_declaration_uids(&precollected.declaration_index);
    let expected_uid = declaration_uids
        .get("Global::Hoge")
        .copied()
        .expect("record head should have a declaration UID");

    let scope = build_global_scope(&precollected.declaration_index, &declaration_uids);

    assert_eq!(scope.lookup("Hoge"), Some(expected_uid));
}

#[test]
fn test_empty_module_owner_is_not_importable_from_registry_metadata_alone() {
    let ast = spire::parse_with_context("defmod Hoge {}", spire::ParserContext::project(0))
        .expect("module owner should parse");
    let module_stages = vec![staged_modules_from_source_ast(ast, None)];

    let err = resolve_user_with_modules("import Hoge", &module_stages)
        .expect_err("owner metadata alone must not make an empty module importable");

    assert_eq!(err.message, "Unknown module import: Hoge");
}

#[test]
fn test_precollect_namespaced_types_can_coexist() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"namespace Auth { defrecord User(name: String) }
namespace Billing { defrecord User(name: String) }"#,
            "",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    assert!(index.contains_key("Auth::User"));
    assert!(index.contains_key("Billing::User"));
}

#[test]
fn test_precollect_namespaced_duplicate_type_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"namespace Auth {
  defrecord User(name: String)
  defrecord User(name: String)
}"#,
            "",
        ),
    )]];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("duplicate namespaced type must fail");
    assert_eq!(err.message, "Duplicate top-level owner: Auth::User");
    assert!(err
        .related_labels
        .iter()
        .any(|label| label.message == "first Record declaration"));
}

#[test]
fn test_precollect_declaration_index_preserves_compiler_registration_order() {
    let mod_a = staged_module(
        "Std::A",
        parse_module_ast(r#"def same(x: Int) -> Int { x }"#, "Std::A"),
    );
    let mod_b = staged_module(
        "Std::B",
        parse_module_ast(r#"def same(x: Int) -> Int { x }"#, "Std::B"),
    );

    let index_first = precollect_declaration_index(&[vec![mod_a.clone(), mod_b.clone()]]).unwrap();
    let index_swapped =
        precollect_declaration_index(&[vec![mod_b.clone(), mod_a.clone()]]).unwrap();

    assert_eq!(
        index_first.keys().collect::<Vec<_>>(),
        index_swapped.keys().collect::<Vec<_>>()
    );
    assert_eq!(
        declaration_uid_order(&index_first),
        vec!["Std::A::same", "Std::B::same"]
    );
    assert_eq!(
        declaration_uid_order(&index_swapped),
        vec!["Std::B::same", "Std::A::same"]
    );
    assert_eq!(
        index_first,
        precollect_declaration_index(&[vec![mod_a, mod_b]]).unwrap()
    );
    assert!(index_first.contains_key("Std::A::same"));
    assert!(index_first.contains_key("Std::B::same"));
}

#[test]
fn test_precollect_owner_registry_preserves_cross_file_module_order_over_local_offsets() {
    let first_ast = parse_module_ast(
        r#"

defrecord Shared(value: Int)"#,
        "First",
    );
    let second_ast = parse_module_ast("type Shared = (Int -> Int)", "Second");
    let first_span = first_ast[0].span().clone();
    let conflicting_span = second_ast[0].span().clone();
    assert!(first_span.start > conflicting_span.start);

    let first_module = staged_module("First", first_ast);
    let mut second_module = staged_module("Second", second_ast);
    second_module.source_index = 1;
    let module_stages = vec![vec![first_module, second_module]];
    let err = precollect_owner_registry(&module_stages)
        .expect_err("later source owner must collide with the first source owner");

    assert_eq!(err.span, conflicting_span);
    assert_eq!(err.related_labels[0].span, first_span);
    assert_eq!(err.related_labels[0].message, "first Record declaration");
    assert_eq!(err.related_labels[1].span, conflicting_span);
    assert_eq!(err.related_labels[1].message, "conflicting Sig declaration");
}

#[test]
fn test_precollect_declaration_index_tracks_bootstrap_std_user_stage_split() {
    let module_stages = vec![
        vec![staged_module(
            "Bootstrap",
            parse_module_ast(r#"deferror NoneError { "none" }"#, "Bootstrap"),
        )],
        vec![staged_module(
            "Std::Math",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Std::Math"),
        )],
        vec![staged_module(
            "User::Main",
            parse_module_ast(r#"def main() -> Int { 1 }"#, "User::Main"),
        )],
    ];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    assert_eq!(index["Global::NoneError"].stage_index, 0);
    assert_eq!(index["Std::Math::add"].stage_index, 1);
    assert_eq!(index["User::Main::main"].stage_index, 2);
}

#[test]
fn declaration_uid_order_preserves_stage_registration_order() {
    let module_stages = vec![
        vec![staged_module(
            "User::B",
            parse_module_ast(r#"def beta() -> Int { 1 }"#, "User::B"),
        )],
        vec![
            staged_module(
                "User::Z",
                parse_module_ast(r#"def zeta() -> Int { 1 }"#, "User::Z"),
            ),
            staged_module(
                "User::A",
                parse_module_ast(r#"def alpha() -> Int { 1 }"#, "User::A"),
            ),
        ],
    ];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");

    assert_eq!(
        declaration_uid_order(&index),
        vec![
            "User::B::beta".to_string(),
            "User::Z::zeta".to_string(),
            "User::A::alpha".to_string(),
        ]
    );
}

#[test]
fn declaration_ordering_exposes_stage_metadata() {
    let module_stages = vec![
        vec![staged_module(
            "User::B",
            parse_module_ast(r#"def beta() -> Int { 1 }"#, "User::B"),
        )],
        vec![
            staged_module(
                "User::Z",
                parse_module_ast(r#"def zeta() -> Int { 1 }"#, "User::Z"),
            ),
            staged_module(
                "User::A",
                parse_module_ast(r#"def alpha() -> Int { 1 }"#, "User::A"),
            ),
        ],
    ];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let ordering = declaration_stage_ordering(&index);

    assert_eq!(
        ordering.entries(),
        &[
            StageOrderedDeclaration {
                stage_index: 0,
                fq_name: "User::B::beta".to_string(),
            },
            StageOrderedDeclaration {
                stage_index: 1,
                fq_name: "User::Z::zeta".to_string(),
            },
            StageOrderedDeclaration {
                stage_index: 1,
                fq_name: "User::A::alpha".to_string(),
            },
        ]
    );
    assert_eq!(
        ordering.fq_names(),
        vec![
            "User::B::beta".to_string(),
            "User::Z::zeta".to_string(),
            "User::A::alpha".to_string(),
        ]
    );
}

#[test]
fn test_precollect_impl_methods_as_type_namespace_members() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
    User { name: name, age: age }
  }

  def normalize(self) -> Self {
    self
  }

  defextractor deconstruct(self: Self) -> MatchResult<(String, Int)> {
    MatchResult::Err(NoneError())
  }
}"#,
            "",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let ctor = index
        .get("Global::User::new")
        .expect("new should be indexed");
    assert_eq!(ctor.module_path, "Global::User");
    assert_eq!(ctor.name, "new");
    assert_eq!(ctor.kind, DeclarationKind::ImplCtorNew);

    let normalize = index
        .get("Global::User::normalize")
        .expect("normalize should be indexed");
    assert_eq!(normalize.module_path, "Global::User");
    assert_eq!(normalize.name, "normalize");
    assert_eq!(normalize.kind, DeclarationKind::ImplMethod);

    let deconstruct = index
        .get("Global::User::deconstruct")
        .expect("deconstruct should be indexed");
    assert_eq!(deconstruct.module_path, "Global::User");
    assert_eq!(deconstruct.name, "deconstruct");
    assert_eq!(deconstruct.kind, DeclarationKind::Extractor);
}

#[test]
fn test_precollect_impl_extractors_for_enum_types() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defenum Light {
  Red,
  Green,
}

impl Light {
  defextractor stop_code(self: Self) -> MatchResult<Int> {
    MatchResult::Err(NoneError())
  }
}"#,
            "",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let stop_code = index
        .get("Global::Light::stop_code")
        .expect("enum extractor should be indexed");
    assert_eq!(stop_code.module_path, "Global::Light");
    assert_eq!(stop_code.name, "stop_code");
    assert_eq!(stop_code.kind, DeclarationKind::Extractor);
}

#[test]
fn test_precollect_rejects_multiple_impl_blocks_for_same_type() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}
impl User {
  def normalize(self) -> Self {
    self
  }
}"#,
            "",
        ),
    )]];

    let err = precollect_declaration_index(&module_stages).expect_err("duplicate impl must fail");
    assert!(err
        .message
        .contains("Multiple impl blocks for `User` are not allowed"));
    assert_eq!(err.related_labels.len(), 2);
    assert_eq!(err.related_labels[0].message, "first definition");
    assert_eq!(err.related_labels[1].message, "conflicting definition");
}

#[test]
fn test_precollect_allows_impl_target_defined_in_another_file_same_stage() {
    let module_stages = vec![vec![
        staged_module(
            "",
            parse_module_ast(
                r#"defstruct User {
  name: String,
}"#,
                "",
            ),
        ),
        staged_module(
            "",
            parse_module_ast(
                r#"impl User {
  def normalize(self) -> Self {
    self
  }
}"#,
                "",
            ),
        ),
    ]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let normalize = index
        .get("Global::User::normalize")
        .expect("impl method should be indexed");
    assert_eq!(normalize.module_path, "Global::User");
    assert_eq!(normalize.kind, DeclarationKind::ImplMethod);
}

#[test]
fn test_resolve_allows_impl_target_defined_in_another_file_same_stage() {
    let module_stages = vec![vec![
        staged_module(
            "",
            parse_module_ast(
                r#"defstruct User {
  name: String,
}"#,
                "",
            ),
        ),
        staged_module(
            "",
            parse_module_ast(
                r#"impl User {
  def normalize(self) -> Self {
    self
  }
}"#,
                "",
            ),
        ),
    ]];

    let resolved = resolve_user_with_modules("value = 0", &module_stages)
        .expect("split impl in same stage should resolve");
    assert!(resolved.iter().any(
        |node| matches!(node, Resolved::Def(_, id, ..) if id.name == "Global::User::normalize")
    ));
}

#[test]
fn test_resolve_allows_same_stage_import_independent_of_module_order() {
    let consumer = staged_module(
        "Consumer",
        parse_module_ast(
            r#"import Provider::value;

def use_value() -> Int {
  value()
}"#,
            "Consumer",
        ),
    );
    let provider = staged_module(
        "Provider",
        parse_module_ast(
            r#"def value() -> Int {
  41
}"#,
            "Provider",
        ),
    );

    resolve_user_with_modules(
        "print(to_string(Consumer::use_value()))",
        &[vec![consumer.clone(), provider.clone()]],
    )
    .expect("same-stage forward import should resolve");
    resolve_user_with_modules(
        "print(to_string(Consumer::use_value()))",
        &[vec![provider, consumer]],
    )
    .expect("same-stage backward import should resolve");
}

#[test]
fn test_resolve_allows_same_stage_auto_import() {
    let helper = staged_auto_import_module(
        "Helper",
        parse_module_ast(
            r#"def helper() -> Int {
  7
}"#,
            "Helper",
        ),
    );
    let consumer = staged_module(
        "Consumer",
        parse_module_ast(
            r#"def use_helper() -> Int {
  helper()
}"#,
            "Consumer",
        ),
    );

    resolve_user_with_modules(
        "print(to_string(Consumer::use_helper()))",
        &[vec![consumer, helper]],
    )
    .expect("same-stage auto import should resolve");
}

#[test]
fn test_resolve_rejects_future_stage_import() {
    let consumer = staged_module(
        "Consumer",
        parse_module_ast(
            r#"import Provider::value;

def use_value() -> Int {
  value()
}"#,
            "Consumer",
        ),
    );
    let provider = staged_module(
        "Provider",
        parse_module_ast(
            r#"def value() -> Int {
  41
}"#,
            "Provider",
        ),
    );

    let err = resolve_user_with_modules(
        "print(to_string(Consumer::use_value()))",
        &[vec![consumer], vec![provider]],
    )
    .expect_err("future-stage import should still be rejected");
    assert!(err.message.contains("Provider::value"));
}

#[test]
fn test_parallel_stage_resolve_rebases_local_ids() {
    let left = staged_module(
        "Left",
        parse_module_ast(
            r#"def value() -> Int {
  x = 1
  x
}"#,
            "Left",
        ),
    );
    let right = staged_module(
        "Right",
        parse_module_ast(
            r#"def value() -> Int {
  x = 2
  x
}"#,
            "Right",
        ),
    );

    let resolved = resolve_user_with_modules(
        "print(to_string(Left::value() + Right::value()))",
        &[vec![left, right]],
    )
    .expect("same-stage modules should resolve");
    let local_ids = resolved
        .iter()
        .filter_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) if id.name == "value" => first_bind_id(body),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(local_ids.len(), 2);
    assert_ne!(local_ids[0], local_ids[1]);
}

fn first_bind_id(node: &Resolved) -> Option<u32> {
    match node {
        Resolved::Bind(_, ResolvedPattern::Var(id), _) => Some(id.unique_id),
        Resolved::Block(_, nodes) => nodes.iter().find_map(first_bind_id),
        _ => None,
    }
}

#[test]
fn test_precollect_allows_impl_for_builtin_type_owner() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"impl Int {
  def abs_alias(value: Int) -> Int {
    value
  }
}"#,
            "",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("builtin impl should succeed");
    let method = index
        .get("Global::Int::abs_alias")
        .expect("builtin impl method should be indexed");
    assert_eq!(method.module_path, "Global::Int");
    assert_eq!(method.kind, DeclarationKind::ImplMethod);
}

#[test]
fn test_impl_owner_uses_target_name_not_declaring_module_path() {
    let module_stages = vec![vec![staged_module(
        "Types",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
  def normalize(self) -> Self {
    self
  }
}"#,
            "Types",
        ),
    )]];

    let declaration_index =
        precollect_declaration_index(&module_stages).expect("precollect should succeed");
    assert!(declaration_index.contains_key("Global::User::new"));
    assert!(declaration_index.contains_key("Global::User::normalize"));
    assert!(!declaration_index.contains_key("Types::User::normalize"));

    let resolved = resolve_user_with_modules(
        r#"user = User("alice")
normalized = User::normalize(user)"#,
        &module_stages,
    )
    .expect("qualified impl calls should resolve through type owner");
    assert!(resolved.iter().any(
        |node| matches!(node, Resolved::Def(_, id, ..) if id.name == "Global::User::normalize")
    ));
}

#[test]
fn test_precollect_trait_methods_as_trait_namespace_members() {
    let module_stages = vec![vec![staged_module(
        "Add",
        parse_module_ast(
            r#"deftrait Add {
  def add(self: Self, rhs: Self) -> Self
}"#,
            "Add",
        ),
    )]];

    let index = precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let trait_entry = index.get("Add::Add").expect("trait should be indexed");
    assert_eq!(trait_entry.name, "Add");
    assert_eq!(trait_entry.kind, DeclarationKind::Trait);

    let add = index
        .get("Add::Add::add")
        .expect("trait method should be indexed");
    assert_eq!(add.module_path, "Add");
    assert_eq!(add.name, "Add::add");
    assert_eq!(add.kind, DeclarationKind::TraitMethod);
}

#[test]
fn test_resolve_rejects_multiple_trait_impl_blocks_for_same_pair() {
    let module_stages = vec![vec![staged_module(
        "Metric",
        parse_module_ast(
            r#"deftrait Metric {
  def add(self: Self, rhs: Self) -> Self
}

impl Metric for Int {
  def add(self: Self, rhs: Self) -> Self {
    self + rhs
  }
}

impl Metric for Int {
  def add(self: Self, rhs: Self) -> Self {
    self
  }
}"#,
            "Metric",
        ),
    )]];

    let declaration_index =
        precollect_declaration_index(&module_stages).expect("precollect should succeed");
    let err = resolve_staged_program(
        &module_stages,
        Vec::new(),
        &declaration_index,
        Some("__Script::fixture".to_string()),
    )
    .expect_err("duplicate trait impl pair must fail");
    assert!(err.message.contains("Multiple trait impl blocks for `"));
    assert!(err.message.contains("Metric"));
    assert!(err.message.contains("Int"));
    assert_eq!(err.related_labels.len(), 2);
    assert_eq!(err.related_labels[0].message, "first definition");
    assert_eq!(err.related_labels[1].message, "conflicting definition");
}

#[test]
fn test_resolve_rejects_duplicate_callable_in_trait_impl() {
    let result = parse_and_resolve(
        r#"deftrait Mark {
  def mark(self: Self) -> Int
}

impl Mark for Int {
  def mark(self: Self) -> Int { 1 }
  def mark(self: Self) -> Int { 2 }
}"#,
    );

    let err = result.expect_err("duplicate trait impl method must fail");
    assert!(err.message.contains("Duplicate function `mark`"));
    assert_eq!(err.related_labels.len(), 2);
}

#[test]
fn test_resolve_rejects_public_private_overload_in_inherent_impl() {
    let result = parse_and_resolve(
        r#"defstruct User { name: String }

impl User {
  def name(self: Self) -> String { self.name }
  defp name(self: Self) -> String { self.name }
}"#,
    );

    let err = result.expect_err("def and defp cannot overload each other");
    assert!(err.message.contains("Duplicate function `name`"));
    assert_eq!(err.related_labels.len(), 2);
}

#[test]
fn test_precollect_rejects_impl_target_for_record() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defrecord Pair(first: Int, second: Int)
impl Pair {
  def new(first: Int, second: Int) -> Self {
    Pair(first, second)
  }
}"#,
            "",
        ),
    )]];

    let err =
        precollect_declaration_index(&module_stages).expect_err("record impl should be rejected");
    assert!(err
        .message
        .contains("impl target `Global::Pair` must be a standard type, struct, or enum"));
}

#[test]
fn test_precollect_rejects_impl_target_for_cond_clauses_builtin_type() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"impl CondClauses {
  def noop(self) -> Self { self }
}"#,
            "",
        ),
    )]];

    let err = precollect_declaration_index(&module_stages)
        .expect_err("CondClauses builtin clause type should reject inherent impl");
    assert!(err
        .message
        .contains("impl target `Global::CondClauses` must be a standard type owner or a struct/enum defined in the current stage"));
}

#[test]
fn test_precollect_accepts_canonical_do_intrinsic_surface() {
    let module_stages = staged_do_intrinsic_contract(
        "Bootstrap",
        "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>",
    );

    precollect_declaration_index(&module_stages)
        .expect("canonical Bootstrap::do surface must match compiler metadata");
}

#[test]
fn test_precollect_rejects_noncanonical_do_intrinsic_surfaces() {
    let cases = [
        (
            "Kernel",
            "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Applicative>(block: DoBlock<$Result>) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do(block: DoBlock<$Result>) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Monad, Alternative>(block: DoBlock<$Result>) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Monad>(block: CondClauses<$Result>) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Monad>(block: DoBlock<$Result>, extra: Int) -> Monad<$Result>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Other>",
        ),
        (
            "Bootstrap",
            "@intrinsic def do::<Monad>(block: DoBlock<Int>) -> Monad<Int>",
        ),
    ];

    for (module_path, source) in cases {
        let module_stages = staged_do_intrinsic_contract(module_path, source);
        let err = precollect_declaration_index(&module_stages)
            .expect_err("noncanonical do intrinsic surface must fail closed");
        assert!(
            err.message.contains(
                "the `do` intrinsic declaration does not match its compiler-owned contract"
            ),
            "unexpected error for {source}: {}",
            err.message
        );
        assert_eq!(
            err.diagnostic.reason,
            crate::error::ResolveErrorReason::InvalidIntrinsicSurfaceContract,
            "unexpected reason for {source}"
        );
    }
}

#[test]
fn test_precollect_rejects_do_surface_without_canonical_owner_trait_or_marker() {
    let source = "@intrinsic def do::<Monad>(block: DoBlock<$Result>) -> Monad<$Result>";
    let cases = [
        vec![vec![staged_module(
            "Bootstrap",
            parse_module_ast(source, "Bootstrap"),
        )]],
        {
            let mut bootstrap = staged_module("Bootstrap", parse_module_ast(source, "Bootstrap"));
            bootstrap.owner = Some(OwnerDescriptor::new(
                "Bootstrap".to_string(),
                bootstrap.ast[0].span().clone(),
                OwnerSourceForm::Defmod,
            ));
            vec![vec![bootstrap]]
        },
        {
            let support = staged_module("", parse_module_ast("@builtin type DoBlock<$Result>", ""));
            let mut bootstrap = staged_module("Bootstrap", parse_module_ast(source, "Bootstrap"));
            bootstrap.owner = Some(OwnerDescriptor::new(
                "Bootstrap".to_string(),
                bootstrap.ast[0].span().clone(),
                OwnerSourceForm::Defmod,
            ));
            vec![vec![support, bootstrap]]
        },
        {
            let support = staged_module(
                "",
                parse_module_ast(
                    r#"deftrait Monad
where
  Self: Type<$A>
{
  def bind(self: Self<$A>, mapper: ($A -> Self<$B>)) -> Self<$B>
}"#,
                    "",
                ),
            );
            let mut bootstrap = staged_module("Bootstrap", parse_module_ast(source, "Bootstrap"));
            bootstrap.owner = Some(OwnerDescriptor::new(
                "Bootstrap".to_string(),
                bootstrap.ast[0].span().clone(),
                OwnerSourceForm::Defmod,
            ));
            vec![vec![support, bootstrap]]
        },
        {
            let support = staged_module(
                "",
                parse_module_ast(
                    r#"@builtin type DoBlock<$Result>
defstruct Monad { value: Int }"#,
                    "",
                ),
            );
            let mut bootstrap = staged_module("Bootstrap", parse_module_ast(source, "Bootstrap"));
            bootstrap.owner = Some(OwnerDescriptor::new(
                "Bootstrap".to_string(),
                bootstrap.ast[0].span().clone(),
                OwnerSourceForm::Defmod,
            ));
            vec![vec![support, bootstrap]]
        },
        {
            let support = staged_module(
                "",
                parse_module_ast(
                    r#"@builtin type DoBlock<$Result>
deftrait Monad
where
  Self: Type<$A>
{
  def bind(self: Self<$A>, mapper: ($A -> Self<$B>)) -> Self<$B>
}
defstruct Bootstrap { value: Int }"#,
                    "",
                ),
            );
            let bootstrap = staged_module("Bootstrap", parse_module_ast(source, "Bootstrap"));
            vec![vec![support, bootstrap]]
        },
    ];

    for module_stages in cases {
        let err = precollect_declaration_index(&module_stages)
            .expect_err("do surface requires canonical owner, Monad Trait, and DoBlock marker");
        assert_eq!(
            err.diagnostic.reason,
            crate::error::ResolveErrorReason::InvalidIntrinsicSurfaceContract
        );
    }
}

fn precollect_do_block_error(source: &str) -> ResolveError {
    let module_stages = vec![vec![staged_module("", parse_module_ast(source, ""))]];
    precollect_declaration_index(&module_stages)
        .expect_err("DoBlock declaration and every impl target must be reserved")
}

#[test]
fn test_precollect_rejects_do_block_declaration_at_declaration_span() {
    let source = "defstruct DoBlock { value: Int }";
    let err = precollect_do_block_error(source);
    assert_eq!(
        err.diagnostic.reason,
        crate::error::ResolveErrorReason::ReservedIntrinsicMarkerDeclaration
    );
    assert_eq!(
        err.span,
        Span {
            start: 0,
            end: source.len()
        }
    );
}

#[test]
fn test_precollect_rejects_do_block_inherent_impl_at_target_span() {
    let err = precollect_do_block_error("impl DoBlock { def noop(self: Self) -> Self { self } }");
    assert_eq!(
        err.diagnostic.reason,
        crate::error::ResolveErrorReason::ReservedIntrinsicMarkerImpl
    );
    assert_eq!(err.span, Span { start: 5, end: 12 });
}

#[test]
fn test_precollect_rejects_do_block_trait_impl_at_target_span() {
    let source = r#"deftrait Marker { def mark(self: Self) -> Int }
impl Marker for DoBlock<Int> { def mark(self: Self) -> Int { 1 } }"#;
    let target_start = source.find("DoBlock").expect("DoBlock target");
    let err = precollect_do_block_error(source);
    assert_eq!(
        err.diagnostic.reason,
        crate::error::ResolveErrorReason::ReservedIntrinsicMarkerImpl
    );
    assert_eq!(
        err.span,
        Span {
            start: target_start,
            end: target_start + "DoBlock<Int>".len(),
        }
    );
}

#[test]
fn test_import_new_from_impl_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
  def normalize(self) -> Self {
    self
  }
}"#,
            "",
        ),
    )]];

    let err = resolve_user_with_modules(
        r#"import User::new
User("alice")"#,
        &module_stages,
    )
    .expect_err("new import should fail");
    assert!(err.message.contains("is not importable"));
}

#[test]
fn test_import_root_struct_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}"#,
            "",
        ),
    )]];

    let err = resolve_user_with_modules(
        r#"import User
value = User("alice")"#,
        &module_stages,
    )
    .expect_err("root struct import should fail");
    assert!(err
        .message
        .contains("Import target `User` is not importable"));
}

#[test]
fn test_root_struct_constructor_call_resolves_without_import() {
    let module_stages = vec![vec![staged_module(
        "",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}
impl User {
  def new(name: String) -> Self {
    User { name: name }
  }
}"#,
            "",
        ),
    )]];

    let resolved = resolve_user_with_modules(r#"user = User("alice")"#, &module_stages)
        .expect("root struct constructor should resolve without import");

    let constructor_name = resolved.iter().find_map(|node| match node {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::ConstructorCall(_, rid, _) => Some(rid.name.clone()),
            _ => None,
        },
        _ => None,
    });

    assert_eq!(constructor_name.as_deref(), Some("User::new"));
}

#[test]
fn test_resolve_trait_def_and_impl_preserve_nodes() {
    let ast = parse_module_ast(
        r#"deftrait TestAdd {
  def add(self: Self, rhs: Self) -> Self
}

impl TestAdd for Int {
  def add(self: Self, rhs: Self) -> Self {
    self + rhs
  }
}"#,
        "TestAdd",
    );

    let resolved = resolve(ast).expect("trait nodes should resolve");
    assert!(matches!(
        &resolved[0],
        Resolved::TraitDef(_, id, _, _, methods, _)
            if id.name == "TestAdd"
                && methods.len() == 1
                && methods[0].id.qualified_name.as_deref() == Some("TestAdd::add")
    ));
    assert!(matches!(
        &resolved[1],
        Resolved::TraitImplDef(_, _, id, _, AstTy::Named(_, target), _, methods)
            if id.name == "TestAdd" && target == "Global::Int" && methods.len() == 1
    ));
}

#[test]
fn test_resolved_trait_ids_use_direct_and_inherited_owner_identity() {
    let ast = parse_module_ast(
        r#"deftrait Functor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>) -> Self<$A>
}

deftrait Applicative
where
  Self: Functor
{
  def pure(value: $A) -> Self<$A>
}

deftrait Show {
  def show(self: Self) -> String
}"#,
        "Traits",
    );
    let module_stages = vec![vec![staged_module("Traits", ast)]];
    let precollected = precollect_declarations(&module_stages).expect("traits should precollect");
    let declaration_uids = assign_declaration_uids(&precollected.declaration_index);
    let constructor_slots =
        collect_staged_trait_constructor_slots(&module_stages, &declaration_uids);

    for name in ["Functor", "Applicative"] {
        let uid = declaration_uids
            .get(&format!("Traits::{name}"))
            .copied()
            .expect("trait should have a declaration UID");
        assert_eq!(
            constructor_slots.get(&uid).map(Vec::as_slice),
            Some(["$A".to_string()].as_slice()),
            "{name} should retain its constructor slot"
        );
    }

    let resolved = resolve_staged_program(
        &module_stages,
        Vec::new(),
        &precollected.declaration_index,
        None,
    )
    .expect("traits should resolve");

    for (name, expected_identity) in [
        ("Functor", TypeIdentity::TypeConstructor),
        ("Applicative", TypeIdentity::TypeConstructor),
        ("Show", TypeIdentity::Trait),
    ] {
        let id = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::TraitDef(_, id, ..) if id.name == name => Some(id),
                _ => None,
            })
            .expect("resolved trait should be present");
        assert_eq!(
            id.symbol_info.as_ref().map(|info| info.identity),
            Some(expected_identity),
            "{name} should use its owner registry identity"
        );
    }
}

#[test]
fn test_direct_constructor_signature_identity_is_canonical_and_order_independent() {
    for reverse in [false, true] {
        let definitions = [
            "deftrait SelectedContext where Self: Type<$A> {}",
            "deftrait UnrelatedContext where Self: Type<$A> {}",
        ];
        let order = if reverse { [1, 0] } else { [0, 1] };
        let source = format!(
            "{}\n{}\ndef accept(value: SelectedContext<Int>) -> Unit {{ () }}",
            definitions[order[0]], definitions[order[1]]
        );
        let resolved = parse_and_resolve(&source)
            .expect("direct constructor Trait should resolve independently of declaration order");

        let selected_trait = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::TraitDef(_, id, ..) if id.name == "SelectedContext" => Some(id),
                _ => None,
            })
            .expect("SelectedContext definition");
        let parameter_trait = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::Def(_, id, _, parameters, ..) if id.name == "accept" => parameters
                    .first()
                    .and_then(|parameter| parameter.ty.direct_constructor_trait.as_ref()),
                _ => None,
            })
            .expect("accept direct constructor identity");
        assert_eq!(parameter_trait.unique_id, selected_trait.unique_id);
        assert_eq!(
            parameter_trait.qualified_name,
            selected_trait.qualified_name
        );
    }
}

#[test]
fn test_resolved_type_alias_carries_sig_identity_across_ir_boundary() {
    let resolved = parse_and_resolve("type TestMapper<$A, $B> = ($A -> $B)")
        .expect("signature alias should resolve");
    let alias = resolved
        .iter()
        .find(|node| matches!(node, Resolved::TypeAlias(..)))
        .expect("resolved signature alias should be present");
    let serialized = serde_json::to_value(alias).expect("resolved alias should serialize");
    let fields = serialized
        .get("TypeAlias")
        .and_then(serde_json::Value::as_array)
        .expect("resolved alias should retain its tuple fields");

    assert_eq!(
        fields
            .get(4)
            .and_then(|identity| identity.get("identity"))
            .and_then(serde_json::Value::as_str),
        Some("Sig"),
        "Sig identity must survive after resolver-private registry state is dropped"
    );
}

#[test]
fn test_generic_trait_impl_member_uses_target_head_owner_identity() {
    let ast = parse_module_ast(
        r#"deftrait TestFunctor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>) -> Self<$A>
}

defstruct Boxed<$T> { value: $T }

impl TestFunctor for Boxed<$T> {
  def fmap(self: Self<$A>) -> Self<$A> { self }
}"#,
        "GenericOwners",
    );

    let resolved = resolve(ast).expect("generic trait impl should resolve");
    let method_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, _, _, AstTy::Generic(_, target, _), _, methods)
                if target == "Global::Boxed" =>
            {
                methods.first().map(|method| &method.function_id)
            }
            _ => None,
        })
        .expect("generic trait impl method should be present");

    assert_eq!(method_id.name, "Global::Boxed<$T>::fmap");
    assert_eq!(
        method_id.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Struct),
        "the generic application must resolve through the canonical Boxed owner"
    );
}

#[test]
fn test_trait_impl_declaration_ids_are_unique_and_rebased_across_modules() {
    let module_stages = vec![vec![
        staged_module(
            "Alpha",
            parse_module_ast(
                r#"deftrait ShowAlpha {
  def show(self: Self) -> String
}
defstruct AlphaValue { value: Int }
impl ShowAlpha for AlphaValue {
  def show(self: Self) -> String { "alpha" }
}"#,
                "Alpha",
            ),
        ),
        staged_module(
            "Beta",
            parse_module_ast(
                r#"deftrait ShowBeta {
  def show(self: Self) -> String
}
defstruct BetaValue { value: Int }
impl ShowBeta for BetaValue {
  def show(self: Self) -> String { "beta" }
}"#,
                "Beta",
            ),
        ),
    ]];
    let declaration_index =
        precollect_declaration_index(&module_stages).expect("declarations should precollect");

    let resolve_ids = || {
        resolve_staged_program(&module_stages, Vec::new(), &declaration_index, None)
            .expect("trait impl modules should resolve")
            .into_iter()
            .filter_map(|node| match node {
                Resolved::TraitImplDef(_, declaration_id, trait_id, _, _, _, methods) => Some((
                    trait_id.name,
                    declaration_id,
                    trait_id.unique_id,
                    methods[0].function_id.unique_id,
                )),
                _ => None,
            })
            .collect::<Vec<_>>()
    };

    let first = resolve_ids();
    assert_eq!(first.len(), 2);
    assert_ne!(
        first[0].1, first[1].1,
        "module-local impl IDs must be rebased"
    );
    for (_, declaration_id, trait_id, method_id) in &first {
        assert_ne!(declaration_id, trait_id);
        assert_ne!(declaration_id, method_id);
    }
    assert_eq!(first, resolve_ids(), "impl declaration IDs must be stable");
}

#[test]
fn test_resolved_members_use_enclosing_or_target_owner_identity() {
    let ast = spire::parse_with_context(
        r#"defmod App {
  def run() -> Int { 1 }
}

defenum Choice { First }

deftrait Show {
  def show(self: Self) -> String
}

defstruct Box { value: Int }

impl Box {
  def normalize(self: Self) -> Self { self }
}

impl Show for Box {
  def show(self: Self) -> String { "box" }
}"#,
        spire::ParserContext::project(0),
    )
    .expect("owners and members should parse");
    let module_stages = vec![ast
        .into_iter()
        .flat_map(|stmt| staged_modules_from_source_ast(vec![stmt], None))
        .collect::<Vec<_>>()];
    let precollected =
        precollect_declarations(&module_stages).expect("owners and members should precollect");
    let resolved = resolve_staged_program(
        &module_stages,
        Vec::new(),
        &precollected.declaration_index,
        None,
    )
    .expect("owners and members should resolve");

    let enum_variant = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::EnumDef(_, id, _, variants, _)
                if global_surface_name(&id.name) == "Choice" =>
            {
                variants.first().map(|variant| &variant.id)
            }
            _ => None,
        })
        .expect("enum variant should resolve");
    assert_eq!(
        enum_variant.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Enum)
    );

    let (trait_id, trait_method) = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, methods, _) if id.name == "Show" => {
                Some((id, &methods[0].id))
            }
            _ => None,
        })
        .expect("trait and method should resolve");
    assert_eq!(
        trait_id.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Trait)
    );
    assert_eq!(
        trait_method.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Trait)
    );

    let module_member = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, ..)
                if id.qualified_name.as_deref() == Some("Global::App::run") =>
            {
                Some(id)
            }
            _ => None,
        })
        .expect("module member should resolve");
    assert_eq!(
        module_member.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Mod)
    );

    let inherent_member = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, ..)
                if id.qualified_name.as_deref() == Some("Global::Box::normalize") =>
            {
                Some(id)
            }
            _ => None,
        })
        .expect("inherent impl member should resolve");
    assert_eq!(
        inherent_member
            .symbol_info
            .as_ref()
            .map(|info| info.identity),
        Some(TypeIdentity::Struct)
    );

    let (trait_impl_id, trait_impl_member) = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, AstTy::Named(_, target), _, methods)
                if id.name == "Show" && target == "Global::Box" =>
            {
                Some((id, &methods[0].function_id))
            }
            _ => None,
        })
        .expect("trait impl and member should resolve");
    assert_eq!(
        trait_impl_id.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::Trait)
    );
    assert_eq!(
        trait_impl_member
            .symbol_info
            .as_ref()
            .map(|info| info.identity),
        Some(TypeIdentity::Struct)
    );

    let bare = parse_and_resolve("def helper() -> Int { 1 }")
        .expect("bare top-level definition should resolve");
    let bare_id = match &bare[0] {
        Resolved::Def(_, id, ..) => id,
        other => panic!("expected bare top-level def, got {other:?}"),
    };
    assert_eq!(bare_id.symbol_info, None);
}

#[test]
fn test_resolve_where_clauses_preserve_constraint_kinds_and_trait_ids() {
    let ast = parse_module_ast(
        r#"deftrait Equal {
  def equal(self: Self, rhs: Self) -> Boolean
}

deftrait TestFunctor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
  where
    $A: Equal
}

def identity(value: $A) -> $A
where
  $A: Equal
{
  value
}

defstruct Boxed<$T> {
  value: $T,
}

impl TestFunctor for Boxed<$T>
where
  $T: TestFunctor.$A
{
  def fmap(self: Self, mapper: ($A -> $B)) -> Boxed<$B>
  where
    $B: Equal
  {
    Boxed { value: mapper(self.value) }
  }
}"#,
        "WhereConstraints",
    );

    let resolved = resolve(ast).expect("where clauses should resolve");
    let equal_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, _, _) if id.name == "Equal" => Some(id.clone()),
            _ => None,
        })
        .expect("Equal trait id");

    let functor_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, where_clause, methods, _) if id.name == "TestFunctor" => {
                let clause = where_clause.as_ref().expect("TestFunctor where clause");
                assert!(matches!(
                    clause.constraints[0].bounds.as_slice(),
                    [ResolvedWhereConstraintRhs::TypeConstructor { slots, .. }]
                        if matches!(slots.as_slice(), [AstTy::Named(_, slot)] if slot == "$A")
                ));
                let method_clause = methods[0]
                    .where_clause
                    .as_ref()
                    .expect("trait method where clause");
                assert!(matches!(
                    method_clause.constraints[0].bounds.as_slice(),
                    [ResolvedWhereConstraintRhs::Trait { trait_id: bound_id, .. }]
                        if bound_id.unique_id == equal_id.unique_id
                ));
                Some(id.clone())
            }
            _ => None,
        })
        .expect("TestFunctor trait id");

    let function_clause = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, where_clause, _, _) if id.name == "identity" => {
                where_clause.as_ref()
            }
            _ => None,
        })
        .expect("function where clause");
    assert!(matches!(
        function_clause.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::Trait { trait_id: bound_id, .. }]
            if bound_id.unique_id == equal_id.unique_id
    ));

    let impl_clause = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, _, where_clause, _)
                if id.unique_id == functor_id.unique_id =>
            {
                where_clause.as_ref()
            }
            _ => None,
        })
        .expect("trait impl where clause");
    assert!(matches!(
        impl_clause.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::TraitSlot {
            trait_id,
            slot_name,
            slot_ordinal,
            ..
        }] if trait_id.unique_id == functor_id.unique_id && slot_name == "$A" && *slot_ordinal == 0
    ));

    let impl_method_clause = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, _, _, methods)
                if id.unique_id == functor_id.unique_id =>
            {
                methods[0].where_clause.as_ref()
            }
            _ => None,
        })
        .expect("trait impl method where clause");
    assert!(matches!(
        impl_method_clause.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::Trait { trait_id: bound_id, .. }]
            if bound_id.unique_id == equal_id.unique_id
    ));
}

#[test]
fn test_resolve_rejects_unknown_trait_constructor_slot() {
    let ast = parse_module_ast(
        r#"deftrait TestFunctor
where
  Self: Type<$A>
{
  def fmap(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}

defenum Boxed<$T> {
  Box($T),
}

impl TestFunctor for Boxed<$T>
where
  $T: TestFunctor.$Missing
{
  def fmap(self: Self, mapper: ($A -> $B)) -> Boxed<$B> { self }
}"#,
        "UnknownTraitSlot",
    );
    let err = resolve(ast).expect_err("unknown constructor slots must fail during resolution");
    assert!(err.message.contains("has no constructor slot $Missing"));
}

#[test]
fn test_resolve_bare_bounds_parent_edges_and_constructor_slot_maps() {
    let ast = parse_module_ast(
        r#"deftrait Parent
where
  Self: Type<$A>
{}

deftrait Child
where
  Self: Parent
{}

deftrait Equal {}

def identity(value: $T) -> $T
where
  $T: Equal
{
  value
}

defstruct Boxed<$T> { value: $T }

impl Child for Boxed<$T>
where
  $T: Child.$A
{}"#,
        "BareBounds",
    );

    let resolved = resolve(ast).expect("bare bounds and constructor slot map should resolve");
    let parent_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, _, _) if id.name == "Parent" => Some(id.clone()),
            _ => None,
        })
        .expect("Parent trait id");
    let equal_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, _, _) if id.name == "Equal" => Some(id.clone()),
            _ => None,
        })
        .expect("Equal trait id");

    let child = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, Some(clause), _, _) if id.name == "Child" => {
                Some((id, clause))
            }
            _ => None,
        })
        .expect("Child trait and parent bound");
    assert_eq!(
        child.0.symbol_info.as_ref().map(|info| info.identity),
        Some(TypeIdentity::TypeConstructor),
        "a bare parent edge must promote Child to its parent's constructor identity"
    );
    assert!(matches!(
        child.1.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::Trait { trait_id }]
            if trait_id.unique_id == parent_id.unique_id
    ));

    let identity_clause = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, Some(clause), _, _) if id.name == "identity" => {
                Some(clause)
            }
            _ => None,
        })
        .expect("identity where clause");
    assert!(matches!(
        identity_clause.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::Trait { trait_id }]
            if trait_id.unique_id == equal_id.unique_id
    ));

    let slot_map = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, _, Some(clause), _) if id.name == "Child" => {
                Some(clause)
            }
            _ => None,
        })
        .expect("Child impl slot map");
    assert!(matches!(
        slot_map.constraints[0].bounds.as_slice(),
        [ResolvedWhereConstraintRhs::TraitSlot {
            trait_id,
            slot_name,
            slot_ordinal,
            ..
        }] if trait_id.unique_id == child.0.unique_id && slot_name == "$A" && *slot_ordinal == 0
    ));
}

#[test]
fn test_resolve_rejects_slot_map_for_non_constructor_trait() {
    let ast = parse_module_ast(
        r#"deftrait Plain {}

defenum Boxed<$T> {
  Boxed($T),
}

impl Plain for Boxed<$T>
where
  $T: Plain.$A
{
}"#,
        "NonConstructorSlot",
    );

    let err = resolve(ast).expect_err("a non-constructor trait cannot own a slot map");
    assert!(err.message.contains("not a TypeConstructor trait"));
}

#[test]
fn test_resolve_preserves_full_arguments_for_trait_heads_impl_heads_and_calls() {
    let resolved = parse_and_resolve(
        r#"deftrait TestConvert<$To> {
  def convert(self: Self) -> $To
}

impl TestConvert<String> for Int {
  def convert(self: Self) -> String { "ok" }
}

value = TestConvert::convert::<String>(1)"#,
    )
    .expect("parameterized trait declarations and calls should resolve");

    assert!(matches!(
        &resolved[0],
        Resolved::TraitDef(_, id, type_params, _, _, _)
            if id.name == "TestConvert"
                && matches!(type_params.as_slice(), [ResolvedTypeParam { name, .. }] if name == "$To")
    ));
    assert!(matches!(
        &resolved[1],
        Resolved::TraitImplDef(_, _, id, trait_args, _, _, _)
            if id.name == "TestConvert"
                && matches!(trait_args.as_slice(), [AstTy::Named(_, name)] if name == "String")
    ));
    assert!(matches!(
        &resolved[2],
        Resolved::Bind(_, _, rhs)
            if matches!(rhs.as_ref(), Resolved::App(_, callee, _)
                if matches!(callee.as_ref(), Resolved::ReturnTypeArgumentApply(_, _, args)
                    if matches!(args.as_slice(), [argument] if matches!(argument.ty.syntax, AstTy::Named(_, ref name) if name == "String"))))
    ));
}

#[test]
fn test_resolve_trait_default_method_body_can_reference_later_sibling() {
    let ast = parse_module_ast(
        r#"deftrait Metric {
  @doc """Delegates to abs."""
  def magnitude(self: Self) -> Self {
    abs(self)
  }

  def abs(self: Self) -> Self
}"#,
        "Metric",
    );

    let resolved = resolve(ast).expect("trait default bodies should resolve");

    match &resolved[0] {
        Resolved::TraitDef(_, id, _, _, methods, _) => {
            assert_eq!(id.name, "Metric");
            assert_eq!(methods.len(), 2);
            assert_eq!(methods[0].attrs.doc.as_deref(), Some("Delegates to abs."));
            match methods[0].body.as_deref() {
                Some(Resolved::Block(_, stmts)) => match &stmts[0] {
                    Resolved::App(_, func, args) => {
                        assert_eq!(args.len(), 1);
                        match func.as_ref() {
                            Resolved::Var(_, rid) => {
                                assert_eq!(rid.name, "abs");
                                assert_eq!(rid.qualified_name.as_deref(), Some("Metric::abs"));
                            }
                            other => panic!("expected sibling trait method var, got {other:?}"),
                        }
                    }
                    other => panic!("expected app in default body, got {other:?}"),
                },
                other => panic!("expected resolved default body block, got {other:?}"),
            }
            assert!(methods[1].body.is_none());
        }
        other => panic!("Expected TraitDef, got {other:?}"),
    }
}

#[test]
fn test_resolve_trait_impl_builtin_method_preserves_private_name() {
    let ast = parse_module_ast(
        r#"impl Add for Int {
  @builtin def add(self: Self, rhs: Self) -> Self
}"#,
        "Add",
    );

    let resolved = resolve(ast).expect("trait impl builtin method should resolve");
    assert!(matches!(
        &resolved[0],
        Resolved::TraitImplDef(_, _, id, _, AstTy::Named(_, target), _, methods)
            if id.name == "Add"
                && target == "Global::Int"
                && methods.len() == 1
                && methods[0].is_builtin
                && methods[0].function_id.qualified_name.as_deref().is_some_and(|name| {
                    name.contains("__traitimpl__") && name.contains("Add")
                })
    ));
}

#[test]
fn test_trait_qualified_call_resolves_via_trait_namespace() {
    let module_stages = vec![vec![staged_module(
        "Metric",
        parse_module_ast(
            r#"deftrait Metric {
  def safe_div(self: Self, rhs: Self) -> Result<Self, Error>
}"#,
            "Metric",
        ),
    )]];

    let resolved = resolve_user_with_modules(r#"result = Metric::safe_div(4, 2)"#, &module_stages)
        .expect("trait-qualified path should resolve");

    match &resolved.last().expect("expected bind node") {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => assert_eq!(id.name, "Metric::safe_div"),
                _ => panic!("Expected resolved trait method path"),
            },
            _ => panic!("Expected app"),
        },
        _ => panic!("Expected bind"),
    }
}

#[test]
fn test_constructor_call_sugars_to_type_new_resolution() {
    let resolved = parse_and_resolve(
        r#"defstruct User {
  name: String,
  age: Int,
}
impl User {
  def new(name: String, age: Int) -> Self {
    User { name: name, age: age }
  }
}
user = User("alice", 30)"#,
    )
    .expect("source should resolve");

    let constructor_name = resolved.iter().find_map(|node| match node {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::ConstructorCall(_, rid, _) => Some(rid.name.clone()),
            _ => None,
        },
        _ => None,
    });
    assert_eq!(constructor_name.as_deref(), Some("User::new"));
}

#[test]
fn test_simple_bind() {
    let resolved = parse_and_resolve("x = 10").unwrap();
    assert_eq!(resolved.len(), 1);
    match &resolved[0] {
        Resolved::Bind(_, ResolvedPattern::Var(id), _) => {
            assert_eq!(id.name, "x");
        }
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_builtin_ref() {
    let resolved = parse_and_resolve("print(to_string(42))").unwrap();
    match &resolved[0] {
        Resolved::App(_, func, _) => match func.as_ref() {
            Resolved::Var(_, id) => assert_eq!(id.name, "print"),
            _ => panic!("Expected Var for print"),
        },
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_builtin_decl_resolution() {
    let ast = spire::parse_with_context(
        "@builtin def print(a: String) -> Unit",
        spire::ParserContext::module(0, Some("Bootstrap".into()))
            .with_rules(spire::ParseRules::std_module()),
    )
    .expect("std module should parse builtin declarations");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("builtin declaration should resolve");
    let call = resolver
        .resolve_program(prepare_internal_program(
            spire::parse("print(\"value\")").unwrap(),
        ))
        .expect("declared builtin reference should resolve");
    match &resolved[0] {
        Resolved::BuiltinDecl(_, id, _, params, ret_ty, _, attrs) => {
            assert_eq!(id.name, "print");
            let Resolved::App(_, target, _) = &call[0] else {
                panic!("expected builtin call");
            };
            let Resolved::Var(_, reference) = target.as_ref() else {
                panic!("expected builtin reference");
            };
            assert_eq!(id.unique_id, reference.unique_id);
            assert_eq!(
                sindr::builtin::builtin_runtime_name(&id.name, id.qualified_name.as_deref()),
                "print"
            );
            assert_eq!(params.len(), 1);
            assert_eq!(
                *attrs,
                ResolvedDeclAttrs {
                    builtin: true,
                    ..ResolvedDeclAttrs::default()
                }
            );
            assert!(matches!(
                ret_ty,
                Some(ty) if matches!(&ty.syntax, spire::ast::AstTy::Named(_, name) if name == "Unit")
            ));
        }
        _ => panic!("Expected BuiltinDecl"),
    }
}

#[test]
fn test_hidden_builtin_decl_resolution_preserves_hidden_attr() {
    let ast = spire::parse_with_context(
        "@hidden\n@builtin def __process_sleep(duration: Duration) -> Result<Unit>",
        spire::ParserContext::module(0, Some("Process".into()))
            .with_rules(spire::ParseRules::std_module()),
    )
    .expect("std module should parse hidden builtin declarations");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("hidden builtin declaration should resolve");
    match &resolved[0] {
        Resolved::BuiltinDecl(_, id, _, _, _, _, attrs) => {
            assert_eq!(id.name, "__process_sleep");
            assert!(attrs.hidden);
        }
        _ => panic!("Expected BuiltinDecl"),
    }
}

#[test]
fn test_private_builtin_impl_member_is_private_surface() {
    let module_stages = vec![vec![staged_module(
        "List",
        parse_module_ast(
            r#"@builtin type List<$A>
impl List {
  @builtin defp zip(left: List<$A>, right: List<$B>) -> List<($A, $B)>
  def paired() -> List<(Int, Int)> {
    zip([1], [2])
  }
}"#,
            "List",
        ),
    )]];

    resolve_user_with_modules("values = List::paired()", &module_stages)
        .expect("public wrapper should resolve private builtin within the same impl");

    let err = resolve_user_with_modules("values = List::zip([1], [2])", &module_stages)
        .expect_err("private builtin direct call should fail");

    assert!(err.message.contains("List::zip/2"));
    assert!(
        err.message.contains("is private"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_private_builtin_impl_member_import_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "List",
        parse_module_ast(
            r#"@builtin type List<$A>
impl List {
  @builtin defp zip(left: List<$A>, right: List<$B>) -> List<($A, $B)>
}"#,
            "List",
        ),
    )]];

    let err = resolve_user_with_modules("import List::zip", &module_stages)
        .expect_err("private builtin import should fail");

    assert!(
        err.message.contains("Import target `List::zip` is private"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_duration_literal_resolves_as_compiler_generated_struct_lit() {
    let ast = spire::parse_with_context(
        r#"defstruct Duration { private millis: Int }
100ms"#,
        spire::ParserContext::project(0),
    )
    .expect("duration literal should parse");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("duration literal should resolve");
    let lowered = resolved
        .iter()
        .find(|node| matches!(node, Resolved::StructLit(_, id, _) if id.compiler_generated))
        .expect("expected compiler-generated Duration struct literal");
    match lowered {
        Resolved::StructLit(_, id, fields) => {
            assert_eq!(id.name, "Duration");
            assert!(id.compiler_generated);
            assert!(matches!(
                fields.as_slice(),
                [ResolvedStructLitField::Explicit(name, Resolved::Lit(_, spire::ast::Lit::Int(value)))]
                    if name == "millis" && *value == sindr::primitives::int(100)
            ));
        }
        other => panic!(
            "Expected compiler-generated Duration struct literal, got {:?}",
            other
        ),
    }
}

#[test]
fn test_struct_literal_shorthand_resolves_to_same_named_local() {
    let ast = spire::parse_with_context(
        r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name, age }
  }
}"#,
        spire::ParserContext::module(0, None),
    )
    .expect("struct shorthand should parse");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("struct shorthand should resolve");
    let lowered = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _)
                if id.qualified_name.as_deref() == Some("Global::User::new") =>
            {
                Some(body.as_ref())
            }
            _ => None,
        })
        .expect("expected impl method body");

    let Resolved::Block(_, stmts) = lowered else {
        panic!("expected block body");
    };
    let Resolved::StructLit(_, _, fields) = &stmts[0] else {
        panic!("expected struct literal");
    };
    assert!(matches!(
        fields.as_slice(),
        [
            ResolvedStructLitField::Shorthand(name, Resolved::Var(_, id1)),
            ResolvedStructLitField::Shorthand(age, Resolved::Var(_, id2))
        ] if name == "name" && age == "age" && id1.name == "name" && id2.name == "age"
    ));
}

#[test]
fn test_builtin_type_decl_resolution() {
    let ast = spire::parse_with_context(
        "@builtin type Int",
        spire::ParserContext::module(0, Some("Bootstrap".into()))
            .with_rules(spire::ParseRules::std_module()),
    )
    .expect("std module should parse builtin type declarations");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("builtin type declaration should resolve");
    match &resolved[0] {
        Resolved::BuiltinTypeDecl(_, id, params, attrs) => {
            assert_eq!(id.name, "Int");
            assert!(params.is_empty());
            assert_eq!(
                *attrs,
                ResolvedDeclAttrs {
                    builtin: true,
                    ..ResolvedDeclAttrs::default()
                }
            );
        }
        _ => panic!("Expected BuiltinTypeDecl"),
    }
}

#[test]
fn test_struct_readonly_metadata_and_fields_resolve() {
    let ast = spire::parse_with_context(
        "@readonly\ndefstruct User { private password: String, name: String }",
        spire::ParserContext::project(0),
    )
    .expect("readonly struct should parse");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("readonly struct should resolve");

    match &resolved[0] {
        Resolved::StructDef(_, id, type_params, fields, attrs) => {
            assert_eq!(id.name, "Global::User");
            assert!(type_params.is_empty());
            assert!(attrs.readonly);
            assert_eq!(fields[0].name, "password");
            assert_eq!(fields[0].visibility, spire::ast::Visibility::Private);
            assert!(fields[0].readonly);
            assert_eq!(fields[1].name, "name");
            assert_eq!(fields[1].visibility, spire::ast::Visibility::Public);
            assert!(fields[1].readonly);
        }
        other => panic!("Expected StructDef, got {other:?}"),
    }
}

#[test]
fn test_generic_struct_type_params_and_fields_resolve() {
    let ast = spire::parse_with_context(
        "defstruct Pair<$A, $B> { left: $A, right: $B }",
        spire::ParserContext::project(0),
    )
    .expect("generic struct should parse");
    let mut resolver = Resolver::new();
    let resolved = resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("generic struct should resolve");

    match &resolved[0] {
        Resolved::StructDef(_, id, type_params, fields, attrs) => {
            assert_eq!(id.name, "Global::Pair");
            assert_eq!(type_params.len(), 2);
            assert_eq!(type_params[0].name, "$A");
            assert_eq!(type_params[1].name, "$B");
            assert_eq!(fields[0].name, "left");
            assert!(matches!(fields[0].ty, spire::ast::AstTy::Named(_, ref ty) if ty == "$A"));
            assert_eq!(fields[1].name, "right");
            assert!(matches!(fields[1].ty, spire::ast::AstTy::Named(_, ref ty) if ty == "$B"));
            assert_eq!(*attrs, ResolvedDeclAttrs::default());
        }
        other => panic!("Expected StructDef, got {other:?}"),
    }
}

#[test]
fn test_module_builtin_can_be_resolved_by_qualified_name() {
    let module_stages = vec![vec![staged_module(
        "Int",
        parse_module_ast(
            r#"@builtin def shl(value: Int, bits: Int) -> Result<Int, NegativeShiftCount>"#,
            "Int",
        ),
    )]];

    let resolved = resolve_user_with_modules("value = Int::shl(2, 3)", &module_stages)
        .expect("qualified builtin should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("expected bind in resolved output");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => {
                    assert_eq!(id.name, "Int::shl");
                    assert_eq!(id.qualified_name.as_deref(), Some("Int::shl"));
                }
                _ => panic!("Expected builtin var"),
            },
            _ => panic!("Expected app"),
        },
        _ => panic!("Expected bind"),
    }
}

#[test]
fn test_impl_method_in_canonical_module_keeps_same_uid_for_qualified_calls() {
    let module_stages = vec![vec![staged_module(
        "Global::Int",
        parse_module_ast(
            r#"defenum IntBase {
  Dec,
}

impl IntBase {
  def radix(self: Self) -> Int {
    10
  }
}

def parse_base(base: IntBase) -> Int {
  IntBase::radix(base)
}"#,
            "Global::Int",
        ),
    )]];

    let resolved =
        resolve_user_with_modules("", &module_stages).expect("impl method module should resolve");

    let decl_uid = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, _, _)
                if id.qualified_name.as_deref() == Some("Global::IntBase::radix") =>
            {
                Some(id.unique_id)
            }
            _ => None,
        })
        .expect("expected impl method declaration");

    let call_uid = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) if id.name == "parse_base" => {
                assert_eq!(
                    id.qualified_name.as_deref(),
                    Some("Global::Int::parse_base")
                );
                match body.as_ref() {
                    Resolved::Block(_, stmts) => stmts.iter().find_map(|stmt| match stmt {
                        Resolved::App(_, func, _) => match func.as_ref() {
                            Resolved::Var(_, id)
                                if id.name == "IntBase::radix"
                                    && id.qualified_name.as_deref()
                                        == Some("Global::IntBase::radix") =>
                            {
                                Some(id.unique_id)
                            }
                            _ => None,
                        },
                        _ => None,
                    }),
                    Resolved::App(_, func, _) => match func.as_ref() {
                        Resolved::Var(_, id)
                            if id.name == "IntBase::radix"
                                && id.qualified_name.as_deref()
                                    == Some("Global::IntBase::radix") =>
                        {
                            Some(id.unique_id)
                        }
                        _ => None,
                    },
                    _ => None,
                }
            }
            _ => None,
        })
        .expect("expected qualified impl method call");

    assert_eq!(call_uid, decl_uid);
}

#[test]
fn test_qualified_func_literal_path_resolves_via_module_namespace() {
    let module_stages = vec![vec![staged_module(
        "Boolean",
        parse_module_ast(
            r#"def same(lhs: Boolean, rhs: Boolean) -> Boolean { lhs }"#,
            "Boolean",
        ),
    )]];

    let resolved = resolve_user_with_modules("value = True `Boolean::same` False", &module_stages)
        .expect("qualified func literal path should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("expected bind");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert!(matches!(
                    func.as_ref(),
                    Resolved::Var(_, id)
                        if id.name == "Boolean::same"
                            && id.qualified_name.as_deref() == Some("Boolean::same")
                ));
                assert_eq!(args.len(), 2);
            }
            other => panic!("Expected app, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_named_args_resolution() {
    let resolved = parse_and_resolve(
        r#"def add(x: Int, y: Int) -> Int { x + y }
result = add(y: 2, x: 1)"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, _, args) => {
                assert!(matches!(&args[0], ResolvedRecordLitArg::Named(n, _) if n == "y"));
                assert!(matches!(&args[1], ResolvedRecordLitArg::Named(n, _) if n == "x"));
            }
            _ => panic!("Expected App"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_function_def_resolution() {
    let resolved = parse_and_resolve(
        r#"def add(x: Int, y: Int) -> Int { x + y }
print(to_string(1))"#,
    )
    .unwrap();
    match &resolved[0] {
        Resolved::Def(_, id, type_params, params, ret_ty, _, body, attrs) => {
            assert_eq!(id.name, "add");
            assert!(type_params.is_empty());
            assert_eq!(params.len(), 2);
            assert_eq!(*attrs, ResolvedDeclAttrs::default());
            assert!(
                matches!(ret_ty, Some(ty) if matches!(&ty.syntax, spire::ast::AstTy::Named(_, name) if name == "Int"))
            );
            assert!(
                matches!(body.as_ref(), Resolved::Block(_, stmts) if matches!(stmts.as_slice(), [Resolved::BinOp(_, _, _, _)]))
            );
        }
        _ => panic!("Expected Def"),
    }
    match &resolved[1] {
        Resolved::App(_, func, _) => match func.as_ref() {
            Resolved::Var(_, id) => assert_eq!(id.name, "print"),
            _ => panic!("Expected Var"),
        },
        _ => panic!("Expected App"),
    }
}

#[test]
fn test_undefined_var() {
    let result = parse_and_resolve("print(unknown_var)");
    assert!(result.is_err());
}

#[test]
fn test_undefined_function_call_uses_callable_message() {
    let err = parse_and_resolve("print(missing_func(1))").expect_err("call to missing function");
    assert!(err.message.contains("Undefined function missing_func/1"));
}

#[test]
fn test_if_conversion() {
    let resolved = parse_and_resolve("x = if(True, 1, 2)").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Resolved::LazyApp(_, LazyCaptureKind::If, _, _)
            ));
        }
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_if_then_conversion() {
    let resolved = parse_and_resolve("x = if_then(True, 1)").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Resolved::LazyApp(_, LazyCaptureKind::IfThen, _, _)
            ));
        }
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_if_let_conversion() {
    let resolved = parse_and_resolve_pattern_consumers("x = if_let(Ok(1), Ok(v), v, 0)").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::IfLet(_, _, arms, _) => {
                assert_eq!(arms.len(), 2);
                assert!(matches!(
                    &arms[0].pattern,
                    ResolvedPattern::Constructor(_, _)
                ));
                assert!(matches!(&arms[1].pattern, ResolvedPattern::Wildcard(_)));
            }
            other => panic!("Expected Match for if_let(...), got {:?}", other),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_if_let_then_conversion() {
    let resolved =
        parse_and_resolve_pattern_consumers("x = if_let_then(Ok(1), Ok(v), print(\"ok\"))")
            .unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::IfLet(_, _, arms, then_only) => {
                assert!(*then_only);
                assert_eq!(arms.len(), 2);
                assert!(matches!(&arms[0].body, Resolved::App(_, _, _)));
                assert!(matches!(&arms[1].body, Resolved::Lit(_, Lit::Unit)));
            }
            other => panic!("Expected IfLet for if_let_then(...), got {:?}", other),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_if_let_or_alternatives_share_one_binding_identity() {
    let resolved = parse_and_resolve_pattern_consumers(
        "result = if_let((1, 2), (1, value) | (value, 2), value, 0)",
    )
    .expect("both alternatives bind the same name");
    let Resolved::Bind(_, _, rhs) = &resolved[0] else {
        panic!("expected result binding");
    };
    let Resolved::IfLet(_, _, arms, _) = rhs.as_ref() else {
        panic!("expected if_let, got {rhs:?}");
    };
    let ResolvedPattern::Or(alternatives) = arms[0].pattern.unlocated() else {
        panic!("expected one OR pattern in the success arm");
    };
    let alternatives = alternatives
        .iter()
        .map(ResolvedPattern::unlocated)
        .collect::<Vec<_>>();
    let [ResolvedPattern::Tuple(first), ResolvedPattern::Tuple(second)] = alternatives.as_slice()
    else {
        panic!("expected tuple alternatives");
    };
    let ResolvedPattern::Var(first_id) = &first[1] else {
        panic!("expected first binding");
    };
    let ResolvedPattern::Var(second_id) = &second[0] else {
        panic!("expected second binding");
    };
    let Resolved::Var(_, body_id) = &arms[0].body else {
        panic!("expected bound value in then branch");
    };
    assert_eq!(first_id.unique_id, second_id.unique_id);
    assert_eq!(first_id.unique_id, body_id.unique_id);
}

#[test]
fn test_if_let_nested_or_alternatives_share_one_binding_identity() {
    let resolved = parse_and_resolve_pattern_consumers(
        "result = if_let((1, (2, 3)), (1, (value, 3) | (2, value)), value, 0)",
    )
    .expect("nested alternatives bind the same name");
    let Resolved::Bind(_, _, rhs) = &resolved[0] else {
        panic!("expected result binding");
    };
    let Resolved::IfLet(_, _, arms, _) = rhs.as_ref() else {
        panic!("expected if_let, got {rhs:?}");
    };
    let ResolvedPattern::Tuple(outer) = arms[0].pattern.unlocated() else {
        panic!("expected outer tuple");
    };
    let ResolvedPattern::Or(alternatives) = outer[1].unlocated() else {
        panic!("expected nested OR");
    };
    let alternatives = alternatives
        .iter()
        .map(ResolvedPattern::unlocated)
        .collect::<Vec<_>>();
    let [ResolvedPattern::Tuple(first), ResolvedPattern::Tuple(second)] = alternatives.as_slice()
    else {
        panic!("expected tuple alternatives");
    };
    let ResolvedPattern::Var(first_id) = &first[0] else {
        panic!("expected first binding");
    };
    let ResolvedPattern::Var(second_id) = &second[1] else {
        panic!("expected second binding");
    };
    let Resolved::Var(_, body_id) = &arms[0].body else {
        panic!("expected bound value in then branch");
    };
    assert_eq!(first_id.unique_id, second_id.unique_id);
    assert_eq!(first_id.unique_id, body_id.unique_id);
}

#[test]
fn test_if_let_then_or_binding_is_visible_in_success_block() {
    let resolved = parse_and_resolve_pattern_consumers(
        "result = if_let_then((1, 2), (1, value) | (value, 2), print(value))",
    )
    .expect("if_let_then should resolve the common binding");
    let Resolved::Bind(_, _, rhs) = &resolved[0] else {
        panic!("expected result binding");
    };
    let Resolved::IfLet(_, _, arms, _) = rhs.as_ref() else {
        panic!("expected lowered if_let");
    };
    let ResolvedPattern::Or(alternatives) = arms[0].pattern.unlocated() else {
        panic!("expected OR in the success arm");
    };
    let ResolvedPattern::Tuple(first) = alternatives[0].unlocated() else {
        panic!("expected first tuple");
    };
    let ResolvedPattern::Var(bound_id) = &first[1] else {
        panic!("expected bound value");
    };
    let Resolved::App(_, _, args) = &arms[0].body else {
        panic!("expected print call");
    };
    let ResolvedRecordLitArg::Positional(Resolved::Var(_, used_id)) = &args[0] else {
        panic!("expected bound value argument");
    };
    assert_eq!(bound_id.unique_id, used_id.unique_id);
}

#[test]
fn test_if_let_or_alternatives_require_same_binding_names() {
    for pattern in ["(1, left) | (right, 2)"] {
        let source = format!("result = if_let((1, 2), {pattern}, 1, 0)");
        let error = parse_and_resolve_pattern_consumers(&source).expect_err(&source);
        assert!(error.message.contains("same binding names"), "{error:?}");
    }
}

#[test]
fn test_if_let_or_alternatives_accept_reordered_binding_names() {
    parse_and_resolve_pattern_consumers(
        "result = if_let((1, 2), (left, right) | (right, left), left + right, 0)",
    )
    .unwrap();
}

#[test]
fn test_or_alternatives_do_not_resolve_pins_from_previous_alternative() {
    let error = parse_and_resolve(
        "result = match (1, 2) { (value, 1) | (^value, value) => value, _ => 0 }",
    )
    .expect_err("a pin may not see another alternative's binding");
    assert!(
        error
            .message
            .contains("Pinned pattern requires an existing value"),
        "{error:?}"
    );
}

#[test]
fn test_or_duplicate_binding_in_one_alternative_keeps_related_labels() {
    let error =
        parse_and_resolve("result = match (1, 2) { (value, value) | (value, 2) => 0, _ => 0 }")
            .expect_err("duplicate binding within one alternative must fail");
    assert!(error
        .message
        .contains("Duplicate binding in pattern: value"));
    assert_eq!(error.related_labels.len(), 2);
}

#[test]
fn test_is_match_conversion() {
    let resolved = parse_and_resolve_pattern_consumers("x = is_match(Ok(1), Ok(_))").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::IsMatch(_, _, arms) => {
                assert_eq!(arms.len(), 2);
                assert!(matches!(&arms[0].body, Resolved::Lit(_, Lit::Bool(true))));
                assert!(matches!(&arms[1].body, Resolved::Lit(_, Lit::Bool(false))));
            }
            other => panic!("Expected Match for is_match(...), got {:?}", other),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_is_match_rejects_binding_variable_pattern() {
    for source in [
        "x = is_match(Ok(1), Ok(v))",
        "x = is_match(Ok(1), Ok(v) | Ok(v))",
        "x = is_match(Ok(1), Ok(_) @ value)",
    ] {
        let err = parse_and_resolve_pattern_consumers(source)
            .expect_err("must fail after argument roles are known");
        assert!(
            err.message.contains("does not allow binding variables"),
            "{source}: {err:?}"
        );
    }
}

#[test]
fn test_require_conversion() {
    let resolved = parse_and_resolve(
        r#"deferror SomeError { "boom" }
x = require(True, SomeError)"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Resolved::LazyApp(_, LazyCaptureKind::Require, _, _)
            ));
        }
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_ensure_conversion() {
    let resolved = parse_and_resolve(
        r#"def is_even(n: Int) -> Boolean { True }
deferror SomeError { "boom" }
x = ensure(1, &is_even, SomeError)"#,
    )
    .unwrap();
    match &resolved[2] {
        Resolved::Bind(_, _, rhs) => {
            assert!(matches!(
                rhs.as_ref(),
                Resolved::LazyApp(_, LazyCaptureKind::Ensure, _, _)
            ));
        }
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_and_conversion() {
    let resolved = parse_and_resolve(
        r#"def rhs() -> Boolean { True }
x = and(False, rhs())"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::If(_, cond, then_branch, Some(else_branch)) => {
                assert!(
                    matches!(cond.as_ref(), Resolved::ConstructorCall(_, id, args) if id.name == "Boolean::False" && args.is_empty())
                );
                assert!(matches!(then_branch.as_ref(), Resolved::App(_, _, _)));
                assert!(matches!(
                    else_branch.as_ref(),
                    Resolved::Lit(_, Lit::Bool(false))
                ));
            }
            other => panic!("Expected If for and(...), got {:?}", other),
        },
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_or_conversion() {
    let resolved = parse_and_resolve(
        r#"def rhs() -> Boolean { False }
x = or(True, rhs())"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::If(_, cond, then_branch, Some(else_branch)) => {
                assert!(
                    matches!(cond.as_ref(), Resolved::ConstructorCall(_, id, args) if id.name == "Boolean::True" && args.is_empty())
                );
                assert!(matches!(
                    then_branch.as_ref(),
                    Resolved::Lit(_, Lit::Bool(true))
                ));
                assert!(matches!(else_branch.as_ref(), Resolved::App(_, _, _)));
            }
            other => panic!("Expected If for or(...), got {:?}", other),
        },
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_symbolic_and_conversion() {
    let resolved = parse_and_resolve(
        r#"def rhs() -> Boolean { True }
x = False && rhs()"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::If(_, cond, then_branch, Some(else_branch)) => {
                assert!(
                    matches!(cond.as_ref(), Resolved::ConstructorCall(_, id, args) if id.name == "Boolean::False" && args.is_empty())
                );
                assert!(matches!(then_branch.as_ref(), Resolved::App(_, _, _)));
                assert!(matches!(
                    else_branch.as_ref(),
                    Resolved::Lit(_, Lit::Bool(false))
                ));
            }
            other => panic!("Expected If for &&, got {:?}", other),
        },
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_symbolic_or_conversion() {
    let resolved = parse_and_resolve(
        r#"def rhs() -> Boolean { False }
x = True || rhs()"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::If(_, cond, then_branch, Some(else_branch)) => {
                assert!(
                    matches!(cond.as_ref(), Resolved::ConstructorCall(_, id, args) if id.name == "Boolean::True" && args.is_empty())
                );
                assert!(matches!(
                    then_branch.as_ref(),
                    Resolved::Lit(_, Lit::Bool(true))
                ));
                assert!(matches!(else_branch.as_ref(), Resolved::App(_, _, _)));
            }
            other => panic!("Expected If for ||, got {:?}", other),
        },
        _ => panic!("Expected Bind with canonical Lazy declaration call"),
    }
}

#[test]
fn test_reserved_logical_declarations_are_rejected_before_calls() {
    for source in [
        "def and(left: Boolean, right: Boolean) -> Boolean { right }\nx = False && True",
        "def or(left: Boolean, right: Boolean) -> Boolean { right }\nx = True || False",
        "def and(left: Boolean, right: Boolean) -> Boolean { right }\nx = and(False, True)",
    ] {
        let error = parse_and_resolve(source).expect_err(source);
        assert!(error
            .message
            .contains("reserved for its standard declaration"));
    }
}

#[test]
fn test_eq_helper_resolves_via_autoimport_trait() {
    let resolved = parse_and_resolve("x = eq(1, 2)").expect("standard helper resolves");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "eq");
                        assert_eq!(id.qualified_name.as_deref(), Some("Eq::eq"));
                    }
                    other => panic!("expected helper var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn derive_expands_struct_into_trait_impl_nodes() {
    let resolved = parse_and_resolve(
        r#"@derive Eq
defstruct User { name: String }
"#,
    )
    .expect("derive should resolve");

    assert!(matches!(resolved[0], Resolved::StructDef(..)));
    assert!(matches!(
        resolved[1],
        Resolved::TraitImplDef(_, _, ref trait_id, _, _, _, _)
            if trait_id.name == "Eq"
    ));
}

#[test]
fn test_neq_helper_resolves_via_autoimport_trait() {
    let resolved = parse_and_resolve("x = neq(1, 2)").expect("standard helper resolves");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "neq");
                        assert_eq!(id.qualified_name.as_deref(), Some("Eq::neq"));
                    }
                    other => panic!("expected helper var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_compare_helper_resolves_via_autoimport_trait() {
    let module_stages = vec![vec![
        staged_module(
            "Ordering",
            parse_module_ast(
                r#"defenum Ordering {
  Less,
  Equal,
  Greater,
}"#,
                "Ordering",
            ),
        ),
        staged_module(
            "Compare",
            parse_module_ast(
                r#"@autoimport
deftrait Compare {
  def compare(self: Self, rhs: Self) -> Ordering
}"#,
                "Compare",
            ),
        ),
    ]];

    let resolved = resolve_user_with_modules("x = compare(1, 2)", &module_stages)
        .expect("compare helper should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "compare");
                        assert_eq!(
                            id.qualified_name.as_deref(),
                            Some("Compare::Compare::compare")
                        );
                    }
                    other => panic!("expected helper var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_lt_helper_resolves_via_autoimport_trait() {
    let resolved = parse_and_resolve("x = lt(1, 2)").expect("standard helper resolves");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "lt");
                        assert_eq!(id.qualified_name.as_deref(), Some("Compare::lt"));
                    }
                    other => panic!("expected helper var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_concat_helper_resolves_via_autoimport_trait() {
    let module_stages = vec![vec![staged_module(
        "Concat",
        parse_module_ast(
            r#"@autoimport
deftrait Concat {
  def concat(self: Self, rhs: Self) -> Self
}"#,
            "Concat",
        ),
    )]];

    let resolved = resolve_user_with_modules(r#"x = concat("a", "b")"#, &module_stages)
        .expect("concat helper should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "concat");
                        assert_eq!(id.qualified_name.as_deref(), Some("Concat::Concat::concat"));
                    }
                    other => panic!("expected helper var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_and_named_arg_is_error() {
    let err =
        parse_and_resolve("x = and(left: True, right: False)").expect_err("named args must fail");
    assert!(err.message.contains("and does not accept named argument"));
}

#[test]
fn test_eq_wrong_arity_resolves_as_regular_app() {
    let resolved = parse_and_resolve("x = eq(1)").expect("standard helper resolves");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, _, args) => assert_eq!(args.len(), 1),
            other => panic!("expected app, got {:?}", other),
        },
        other => panic!("expected bind, got {:?}", other),
    }
}

#[test]
fn test_concat_named_arg_resolves_as_regular_app() {
    let module_stages = vec![vec![staged_module(
        "Concat",
        parse_module_ast(
            r#"@autoimport
deftrait Concat {
  def concat(self: Self, rhs: Self) -> Self
}"#,
            "Concat",
        ),
    )]];

    let resolved =
        resolve_user_with_modules(r#"x = concat(left: "a", right: "b")"#, &module_stages)
            .expect("concat call should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, _, args) => assert!(matches!(
                args.as_slice(),
                [
                    ResolvedRecordLitArg::Named(_, _),
                    ResolvedRecordLitArg::Named(_, _)
                ]
            )),
            other => panic!("expected app, got {:?}", other),
        },
        other => panic!("expected bind, got {:?}", other),
    }
}

#[test]
fn test_duplicate_top_level_def_is_error() {
    let result = parse_and_resolve("def f() -> Int { 1 }\ndef f() -> Int { 2 }");
    let err = result.expect_err("duplicate def must fail");
    assert!(err.message.contains("Duplicate top-level definition: f"));
}

#[test]
fn test_forward_reference_to_function_resolves_to_same_unique_id() {
    let resolved = parse_and_resolve(
        r#"result = add(1, 2)
def add(x: Int, y: Int) -> Int { x + y }"#,
    )
    .unwrap();

    let call_id = match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => id.unique_id,
                _ => panic!("Expected function variable in App"),
            },
            _ => panic!("Expected App on forward function reference"),
        },
        _ => panic!("Expected Bind"),
    };

    let def_id = match &resolved[1] {
        Resolved::Def(_, id, _, _, _, _, _, _) => id.unique_id,
        _ => panic!("Expected Def"),
    };

    assert_eq!(call_id, def_id);
}

#[test]
fn test_forward_reference_to_struct_literal_resolves_to_same_unique_id() {
    let resolved = parse_and_resolve(
        r#"user = User { name: "alice", age: 30 }
defstruct User {
  name: String,
  age: Int,
}"#,
    )
    .unwrap();

    let lit_id = match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::StructLit(_, id, _) => id.unique_id,
            _ => panic!("Expected StructLit"),
        },
        _ => panic!("Expected Bind"),
    };

    let def_id = match &resolved[1] {
        Resolved::StructDef(_, id, ..) => id.unique_id,
        _ => panic!("Expected StructDef"),
    };

    assert_eq!(lit_id, def_id);
}

#[test]
fn test_forward_reference_to_record_constructor_resolves_to_same_unique_id() {
    let resolved = parse_and_resolve(
        r#"point = Point(1.0, 2.0)
defrecord Point(x: Float, y: Float)"#,
    )
    .unwrap();

    let ctor_id = match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::ConstructorCall(_, id, _) => id.unique_id,
            _ => panic!("Expected ConstructorCall"),
        },
        _ => panic!("Expected Bind"),
    };

    let def_id = match &resolved[1] {
        Resolved::RecordDef(_, id, _, _) => id.unique_id,
        _ => panic!("Expected RecordDef"),
    };

    assert_eq!(ctor_id, def_id);
}

#[test]
fn test_forward_reference_to_deferror_constructor_resolves_to_same_unique_id() {
    let resolved = parse_and_resolve(
        r#"err = PageNotFound("404")
deferror PageNotFound(html: String) { |html: String| Self(message: "Page Not Found. #{html}", html: html) }"#,
    )
    .unwrap();

    let ctor_id = match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::ConstructorCall(_, id, _) => id.unique_id,
            _ => panic!("Expected ConstructorCall"),
        },
        _ => panic!("Expected Bind"),
    };

    let def_id = match &resolved[1] {
        Resolved::DeferrorDef(_, id, _, _) => id.unique_id,
        _ => panic!("Expected DeferrorDef"),
    };

    assert_eq!(ctor_id, def_id);
}

#[test]
fn test_forward_reference_unique_ids_are_deterministic_across_runs() {
    let source = r#"result = build_user("alice")
point = Point(1, 2)
err = NotFound("404")

def build_user(name: String) -> String { name }
defrecord Point(x: Int, y: Int)
deferror NotFound(code: String) { |code: String| Self(message: "missing #{code}", code: code) }"#;

    let first = parse_and_resolve(source).unwrap();
    let second = parse_and_resolve(source).unwrap();

    fn collect_top_level_ids(nodes: &[Resolved]) -> Vec<u32> {
        nodes
            .iter()
            .flat_map(|node| match node {
                Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
                    Resolved::App(_, func, _) => match func.as_ref() {
                        Resolved::Var(_, id) => vec![id.unique_id],
                        _ => Vec::new(),
                    },
                    Resolved::ConstructorCall(_, id, _) | Resolved::StructLit(_, id, _) => {
                        vec![id.unique_id]
                    }
                    _ => Vec::new(),
                },
                Resolved::Def(_, id, _, _, _, _, _, _)
                | Resolved::RecordDef(_, id, _, _)
                | Resolved::StructDef(_, id, ..)
                | Resolved::DeferrorDef(_, id, _, _) => vec![id.unique_id],
                _ => Vec::new(),
            })
            .collect()
    }

    assert_eq!(
        collect_top_level_ids(&first),
        collect_top_level_ids(&second)
    );
}

#[test]
fn test_unresolved_forward_constructor_is_error() {
    let result = parse_and_resolve(r#"value = MissingType(1)"#);
    let err = result.expect_err("unknown forward constructor must fail");
    assert!(err.message.contains("Undefined type: MissingType"));
}

#[test]
fn test_duplicate_top_level_struct_is_error() {
    let result = parse_and_resolve(
        r#"defstruct User { name: String }
defstruct User { name: String }"#,
    );
    let err = result.expect_err("duplicate struct must fail");
    assert_eq!(err.message, "Duplicate top-level owner: User");
    assert!(err
        .related_labels
        .iter()
        .any(|label| label.message == "first Struct declaration"));
}

#[test]
fn test_shadowing() {
    let resolved = parse_and_resolve("x = 1\nx = x + 1").unwrap();
    // The second x should have a different unique_id
    match (&resolved[0], &resolved[1]) {
        (
            Resolved::Bind(_, ResolvedPattern::Var(id1), _),
            Resolved::Bind(_, ResolvedPattern::Var(id2), _),
        ) => {
            assert_ne!(id1.unique_id, id2.unique_id);
        }
        _ => panic!("Expected two Binds"),
    }
}

#[test]
fn test_top_level_def_cannot_capture_top_level_value_binding() {
    let err = parse_and_resolve("x = 1\ndef f() -> Int { x }")
        .expect_err("top-level def capture must fail");
    assert!(
        err.message
            .contains("Top-level definition `f` cannot reference value binding `x`"),
        "{}",
        err.message
    );
}

#[test]
fn test_top_level_def_param_shadowing_still_resolves() {
    parse_and_resolve("x = 1\ndef f(x: Int) -> Int { x }")
        .expect("function params should shadow top-level bindings");
}

#[test]
fn test_match_wildcard_and_literals() {
    let resolved = parse_and_resolve(
        r#"s = "a"
x = match s {
  "a" => 1,
  2 => 2,
  _ => 0,
}"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    ResolvedPattern::StrLit(_, s) if s == "a"
                ));
                assert!(matches!(
                    &arms[1].pattern,
                    ResolvedPattern::IntLit(_, n) if n == &int(2)
                ));
                assert!(matches!(&arms[2].pattern, ResolvedPattern::Wildcard(_)));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_match_qualified_boolean_constructor_patterns_resolve() {
    let resolved = parse_and_resolve(
        r#"flag = True
x = match flag {
  Boolean::True => 1,
  Boolean::False => 0,
}"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => {
                assert!(matches!(
                    &arms[0].pattern,
                    ResolvedPattern::Constructor(ctor, inner)
                        if ctor.name == "Boolean::True" && inner.is_empty()
                ));
                assert!(matches!(
                    &arms[1].pattern,
                    ResolvedPattern::Constructor(ctor, inner)
                        if ctor.name == "Boolean::False" && inner.is_empty()
                ));
            }
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind with Match"),
    }
}

#[test]
fn test_closure_and_capture_resolution() {
    let resolved = parse_and_resolve(
        r#"x = 1
f = {|y| x + y}
g = &print"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Closure(_, params, captures, body) => {
                assert_eq!(params.len(), 1);
                assert_eq!(captures.len(), 1);
                assert!(matches!(
                    body.as_ref(),
                    Resolved::BinOp(_, BinOp::Add, _, _)
                ));
            }
            _ => panic!("Expected Closure"),
        },
        _ => panic!("Expected Bind"),
    }
    match &resolved[2] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Capture(_, target, args) => {
                assert!(args.is_empty());
                assert!(matches!(target.as_ref(), Resolved::Var(_, id) if id.name == "print"));
            }
            _ => panic!("Expected Capture"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn canonical_pattern_consumers_cannot_be_values_or_captures() {
    for consumer in sindr::pattern::PatternConsumer::ALL {
        for source in [
            format!("f = Kernel::{}", consumer.name()),
            format!("f = &Kernel::{}", consumer.name()),
        ] {
            let error = parse_and_resolve_pattern_consumers(&source)
                .expect_err("canonical Pattern consumers are syntax, not callable values");
            assert!(
                error
                    .message
                    .contains("cannot be used as a value or capture"),
                "{source}: {error:?}"
            );
        }
    }
}

#[test]
fn capture_placeholders_inside_pattern_consumers_are_rewritten() {
    for source in [
        "g = &inspect(apply_pattern(&1, _1))",
        "g = &inspect(apply_pattern(1, Bounds::offset(&1, _1: Int)))",
    ] {
        let resolved = resolve_user_with_modules(source, &preargument_test_modules())
            .expect("outer capture placeholders must traverse consumer arguments");
        assert!(matches!(resolved.last(), Some(Resolved::Bind(_, _, rhs))
            if matches!(rhs.as_ref(), Resolved::CaptureClosure(_, params, _, _) if params.len() == 1)));
    }
}

#[test]
fn regex_matches_keeps_expression_calls_and_captures() {
    let modules = vec![vec![
        kernel_pattern_test_module(),
        staged_module(
            "Regex",
            parse_module_ast(
                "@builtin def matches(re: Regex, text: String) -> Boolean",
                "Regex",
            ),
        ),
    ]];
    for source in [
        "f = &Regex::matches",
        "f = &Regex::matches(&1, \"text\")",
        "f = &inspect(Regex::matches(&1, \"text\"))",
    ] {
        resolve_user_with_modules(source, &modules)
            .expect("Regex builtin remains a normal callable");
    }
}

#[test]
fn test_capture_placeholder_lowers_to_capture_closure() {
    let resolved =
        parse_and_resolve("def add(x: Int, y: Int) -> Int { x + y }\ninc = &add(&1, 1)").unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::CaptureClosure(_, params, _, body) => {
                assert_eq!(params.len(), 1);
                assert!(matches!(body.as_ref(), Resolved::App(_, _, _)));
            }
            other => panic!("Expected lowered capture closure, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_backtick_name_capture_resolves_like_plain_capture() {
    let resolved =
        parse_and_resolve("captured = &`print`").expect("backtick capture should resolve");
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Capture(_, target, args) => {
                assert!(args.is_empty());
                assert!(matches!(target.as_ref(), Resolved::Var(_, id) if id.name == "print"));
            }
            other => panic!("Expected capture, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_backtick_qualified_capture_resolves_like_plain_capture() {
    let module_stages = vec![vec![staged_module(
        "Boolean",
        parse_module_ast(r#"def not(value: Boolean) -> Boolean { value }"#, "Boolean"),
    )]];

    let resolved = resolve_user_with_modules("captured = &`Boolean::not`", &module_stages)
        .expect("qualified backtick capture should resolve");
    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("expected bind");
    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Capture(_, target, args) => {
                assert!(args.is_empty());
                assert!(matches!(
                    target.as_ref(),
                    Resolved::Var(_, id)
                        if id.name == "Boolean::not"
                            && id.qualified_name.as_deref() == Some("Boolean::not")
                ));
            }
            other => panic!("Expected capture, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_backtick_operator_capture_preserves_capture_origin() {
    let resolved =
        parse_and_resolve("inc = &`+`(&1, 1)\nadd = &`+`").expect("operator capture should lower");

    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::CaptureClosure(_, params, _, body) => {
                assert_eq!(params.len(), 1);
                assert!(matches!(
                    body.as_ref(),
                    Resolved::BinOp(_, BinOp::Add, _, _)
                ));
            }
            other => panic!("Expected capture closure, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::CaptureClosure(_, params, _, body) => {
                assert_eq!(params.len(), 2);
                assert!(matches!(
                    body.as_ref(),
                    Resolved::BinOp(_, BinOp::Add, _, _)
                ));
            }
            other => panic!("Expected capture closure, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_backtick_pair_capture_preserves_origin_and_pipeline_remains_closure() {
    let resolved = parse_and_resolve(
        "pair = &`(,)`\npiped = 1 |> `(,)`(\"one\")\nmapped = [1] |*> `(,)`(\"tag\")\nbound = Ok(1) |>= `(,)`(\"tag\")",
    )
    .expect("quoted pair constructor forms should resolve");

    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::CaptureClosure(_, params, _, body) => {
                assert_eq!(params.len(), 2);
                assert!(
                    matches!(body.as_ref(), Resolved::TupleLiteral(_, items) if items.len() == 2)
                );
            }
            other => panic!("Expected pair capture closure, got {other:?}"),
        },
        other => panic!("Expected pair bind, got {other:?}"),
    }

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Pipe(_, _, right) => match right.as_ref() {
                Resolved::Closure(_, params, _, body) => {
                    assert_eq!(params.len(), 1);
                    assert!(
                        matches!(body.as_ref(), Resolved::TupleLiteral(_, items) if items.len() == 2)
                    );
                }
                other => panic!("Expected pipeline pair closure, got {other:?}"),
            },
            other => panic!("Expected pair pipeline, got {other:?}"),
        },
        other => panic!("Expected pipeline bind, got {other:?}"),
    }

    for node in &resolved[2..] {
        let Resolved::Bind(_, _, rhs) = node else {
            panic!("Expected contextual pipeline bind, got {node:?}");
        };
        let right = match rhs.as_ref() {
            Resolved::ContextMap(_, _, right) | Resolved::ContextBind(_, _, right) => right,
            other => panic!("Expected contextual pipeline, got {other:?}"),
        };
        assert!(
            matches!(right.as_ref(), Resolved::Closure(_, params, _, body)
            if params.len() == 1
                && matches!(body.as_ref(), Resolved::TupleLiteral(_, items) if items.len() == 2))
        );
    }
}

#[test]
fn test_pipe_slot_lowers_to_closure() {
    let resolved =
        parse_and_resolve("def add(x: Int, y: Int) -> Int { x + y }\nout = 1 |> add(10, _1)")
            .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Pipe(_, _, right) => {
                assert!(matches!(right.as_ref(), Resolved::Closure(_, params, _, _)
                    if params.len() == 1));
            }
            other => panic!("Expected pipe, got {:?}", other),
        },
        other => panic!("Expected bind, got {:?}", other),
    }
}

#[test]
fn test_nested_capture_argument_block_is_rejected_inside_placeholder_capture() {
    let err = parse_and_resolve("bad = &outer(&1, &inner(1))")
        .expect_err("nested capture argument block must fail");
    assert!(err
        .message
        .contains("nested capture argument blocks are not allowed"));
}

#[test]
fn test_pipe_slot_cannot_be_used_more_than_once() {
    let err = parse_and_resolve("def add(x: Int, y: Int) -> Int { x + y }\nbad = 1 |> add(_1, _1)")
        .expect_err("duplicate pipe slot must fail");
    assert!(err.message.contains("can only be used once"));
}

#[test]
fn test_grouped_pipe_rhs_resolution_preserves_call_marker() {
    let resolved = parse_and_resolve(
        r#"def mk() -> (Int -> Int) { {|x| x} }
out = 1 |> (mk())"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Pipe(_, _, right) => assert!(matches!(
                right.as_ref(),
                Resolved::Grouped(_, inner) if matches!(inner.as_ref(), Resolved::App(_, _, _))
            )),
            other => panic!("Expected Pipe, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

#[test]
fn test_safebind_resolution() {
    let resolved = parse_and_resolve("num =? Ok(1)").unwrap();
    match &resolved[0] {
        Resolved::SafeBind(_, ResolvedPattern::Var(id), rhs, _) => {
            assert_eq!(id.name, "num");
            assert!(matches!(rhs.as_ref(), Resolved::ConstructorCall(_, _, _)));
        }
        _ => panic!("Expected SafeBind"),
    }
}

#[test]
fn test_underscore_prefixed_pattern_does_not_bind() {
    let err = parse_and_resolve("_discard = 1\n_discard")
        .expect_err("underscore-prefixed patterns must not introduce a name");

    assert!(err.message.contains("Undefined variable: _discard"));
}

#[test]
fn test_safebind_constructor_pattern_resolution() {
    let resolved = parse_and_resolve(
        r#"value: Result<Result<Int>> = Ok(Ok(1))
Ok(num) =? value"#,
    )
    .unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, _) => {}
        _ => panic!("Expected prelude bind"),
    }
    match &resolved[1] {
        Resolved::SafeBind(_, ResolvedPattern::Constructor(ctor, inner), rhs, _) => {
            assert_eq!(ctor.name, "Result::Ok");
            assert!(matches!(inner.as_slice(), [ResolvedPattern::Var(id)] if id.name == "num"));
            assert!(matches!(rhs.as_ref(), Resolved::Var(_, id) if id.name == "value"));
        }
        _ => panic!("Expected SafeBind with constructor pattern"),
    }
}

#[test]
fn test_safebind_list_with_constructor_literal_pattern_resolution() {
    let resolved = parse_and_resolve(
        r#"lr: Result<List<Result<Int>>> = Ok([Ok(1), Ok(2)])
[Ok(1), ..tail] =? lr"#,
    )
    .unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, _) => {}
        _ => panic!("Expected prelude bind"),
    }
    match &resolved[1] {
        Resolved::SafeBind(_, pattern, rhs, _) => {
            let ResolvedPattern::ListCons(head, tail) = pattern.unlocated() else {
                panic!("list pattern");
            };
            assert!(matches!(
                head.as_ref(),
                ResolvedPattern::Constructor(ctor, inner)
                    if ctor.name == "Result::Ok"
                    && matches!(inner.as_slice(), [ResolvedPattern::IntLit(_, n)] if n == &int(1))
            ));
            assert!(matches!(tail.as_ref(), ResolvedPattern::Var(id) if id.name == "tail"));
            assert!(matches!(rhs.as_ref(), Resolved::Var(_, id) if id.name == "lr"));
        }
        _ => panic!("Expected SafeBind list constructor pattern"),
    }
}

#[test]
fn test_as_pattern_resolution() {
    let resolved = parse_and_resolve(
        r#"value: Result<List<Int>> = Ok([1, 2, 3])
[head, ..tail] @ list_dup: List<Int> =? value"#,
    )
    .unwrap();
    match &resolved[1] {
        Resolved::SafeBind(_, ResolvedPattern::As(inner, alias, Some(_)), rhs, _) => {
            assert_eq!(alias.name, "list_dup");
            assert!(matches!(inner.unlocated(), ResolvedPattern::ListCons(_, _)));
            assert!(matches!(rhs.as_ref(), Resolved::Var(_, id) if id.name == "value"));
        }
        _ => panic!("Expected SafeBind with as-pattern"),
    }
}

#[test]
fn test_duplicate_binding_in_pattern_is_error() {
    let err = parse_and_resolve(
        r#"value: Result<List<Int>> = Ok([1, 2, 3])
[head, ..tail] @ head =? value"#,
    )
    .expect_err("duplicate pattern binding should fail");
    assert!(err.message.contains("Duplicate binding in pattern: head"));
}

#[test]
fn test_duplicate_binding_collects_occurrences_in_preorder_up_to_five() {
    let err = parse_and_resolve("(x, x, x, x, x, x) = (1, 2, 3, 4, 5, 6)")
        .expect_err("duplicate pattern bindings should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| label.message.as_str())
            .collect::<Vec<_>>(),
        ["first", "second", "third", "fourth", "fifth"]
    );
    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [(1, 2), (4, 5), (7, 8), (10, 11), (13, 14)]
    );
}

#[test]
fn test_duplicate_binding_uses_binding_detection_order() {
    let err = parse_and_resolve("((s, s) @ s, s) @ s = ((1, 3), 2)")
        .expect_err("duplicate pattern bindings should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.message.as_str(), label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [
            ("first", 13, 14),
            ("second", 18, 19),
            ("third", 2, 3),
            ("fourth", 5, 6),
            ("fifth", 10, 11),
        ]
    );
}

#[test]
fn test_duplicate_binding_orders_enum_constructor_like_tuple_children() {
    let source = r#"defenum Pair { Pair(Int, Int), }
Pair(x @ x, x) @ x = Pair(1, 2)"#;
    let err = parse_and_resolve(source).expect_err("duplicate pattern bindings should fail");
    let spans = source
        .match_indices('x')
        .map(|(start, _)| (start, start + 1))
        .collect::<Vec<_>>();

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [spans[0], spans[2], spans[3], spans[1]],
    );
}

#[test]
fn test_duplicate_binding_moves_outer_as_after_left_as_inner_binding() {
    let err = parse_and_resolve("(s @ s, (s, s)) @ s = (1, (2, 3))")
        .expect_err("duplicate pattern bindings should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.message.as_str(), label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [
            ("first", 1, 2),
            ("second", 18, 19),
            ("third", 5, 6),
            ("fourth", 9, 10),
            ("fifth", 12, 13),
        ]
    );
}

#[test]
fn test_duplicate_binding_applies_same_order_to_list_cons_elements() {
    let err = parse_and_resolve("[s, ..s @ s] @ s =? [1, 2]")
        .expect_err("duplicate list pattern bindings should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.message.as_str(), label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [
            ("first", 1, 2),
            ("second", 6, 7),
            ("third", 15, 16),
            ("fourth", 10, 11),
        ]
    );
}

#[test]
fn test_duplicate_binding_flattens_list_children_before_parent_alias() {
    let source = "[x, ..[y, ..x]] @ x =? [1, 2]";
    let err = parse_and_resolve(source).expect_err("duplicate list pattern bindings should fail");
    let spans = source
        .match_indices('x')
        .map(|(start, _)| (start, start + 1))
        .collect::<Vec<_>>();

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        spans,
    );
}

#[test]
fn test_duplicate_binding_keeps_recursive_detection_order_without_outer_as_pattern() {
    let err = parse_and_resolve("((s, s) @ s, s) = ((1, 3), 2)")
        .expect_err("duplicate pattern bindings should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.message.as_str(), label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [
            ("first", 2, 3),
            ("second", 5, 6),
            ("third", 10, 11),
            ("fourth", 13, 14),
        ]
    );
}

#[test]
fn test_as_pattern_duplicate_uses_alias_token_span() {
    let err = parse_and_resolve("(x @ x) = (1, 2)")
        .expect_err("duplicate as-pattern binding should fail");

    assert_eq!(
        err.related_labels
            .iter()
            .map(|label| (label.message.as_str(), label.span.start, label.span.end))
            .collect::<Vec<_>>(),
        [("first", 1, 2), ("second", 5, 6)]
    );
}

#[test]
fn test_block_binding_does_not_escape() {
    let result = parse_and_resolve(
        r#"{
  x = 1
  x
}
x"#,
    );
    let err = result.expect_err("block-local binding must not escape");
    assert!(err.message.contains("Undefined variable: x"));
}

#[test]
fn test_match_arm_binding_does_not_escape() {
    let result = parse_and_resolve(
        r#"value: Result<Int> = Ok(1)
match value {
  Ok(x) => x,
  Err(e) => 0,
}
x"#,
    );
    let err = result.expect_err("match-arm binding must not escape");
    assert!(err.message.contains("Undefined variable: x"));
}

#[test]
fn test_match_arm_binding_does_not_leak_to_other_arms() {
    let result = parse_and_resolve(
        r#"value: Result<Int> = Ok(1)
match value {
  Ok(x) => x,
  Err(e) => x,
}"#,
    );
    let err = result.expect_err("match-arm binding must stay within its own arm");
    assert!(err.message.contains("Undefined variable: x"));
}

#[test]
fn test_nested_closure_does_not_overcapture_outer_local() {
    let resolved = parse_and_resolve(r#"f = {|x| {|y| x + y}}"#).unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Closure(_, outer_params, outer_captures, outer_body) => {
                assert_eq!(outer_params.len(), 1);
                assert!(outer_captures.is_empty());
                match outer_body.as_ref() {
                    Resolved::Closure(_, inner_params, inner_captures, inner_body) => {
                        assert_eq!(inner_params.len(), 1);
                        assert_eq!(inner_captures.len(), 1);
                        assert_eq!(inner_captures[0].name, "x");
                        assert!(matches!(
                            inner_body.as_ref(),
                            Resolved::BinOp(_, BinOp::Add, _, _)
                        ));
                    }
                    _ => panic!("Expected inner Closure"),
                }
            }
            _ => panic!("Expected outer Closure"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_closure_param_annotations_are_preserved() {
    let resolved = parse_and_resolve(r#"f = {|x: Int, y| x}"#).unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Closure(_, params, captures, _) => {
                assert!(captures.is_empty());
                assert_eq!(params.len(), 2);
                assert!(matches!(
                    params[0].ty.as_ref(),
                    Some(AstTy::Named(_, name)) if name == "Int"
                ));
                assert_eq!(params[1].ty, None);
            }
            _ => panic!("Expected Closure"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_std_module_is_auto_imported_from_module_attribute() {
    let module_stages = vec![vec![staged_auto_import_module(
        "Prelude",
        parse_module_ast(r#"def greet() -> String { "hi" }"#, "Prelude"),
    )]];

    let resolved = resolve_user_with_modules(r#"value = greet()"#, &module_stages)
        .expect("auto-import module should inject members");

    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");

    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => {
                    assert_eq!(id.name, "greet");
                    assert_eq!(id.qualified_name.as_deref(), Some("Prelude::greet"));
                }
                other => panic!("expected imported function var, got {:?}", other),
            },
            other => panic!("expected app, got {:?}", other),
        },
        other => panic!("expected bind, got {:?}", other),
    }
}

#[test]
fn test_impl_type_helpers_are_auto_imported_from_owner_surface() {
    let module_stages = vec![vec![staged_auto_import_module(
        "User",
        parse_module_ast(
            r#"defstruct User {
  name: String,
}

impl User {
  def greet() -> String { "hi" }
}"#,
            "User",
        ),
    )]];

    let resolved = resolve_user_with_modules(r#"value = greet()"#, &module_stages)
        .expect("auto-import impl owner surface should inject helpers");

    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");

    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => {
                    assert_eq!(id.name, "greet");
                    assert_eq!(id.qualified_name.as_deref(), Some("Global::User::greet"));
                }
                other => panic!("expected imported impl helper var, got {:?}", other),
            },
            other => panic!("expected app, got {:?}", other),
        },
        other => panic!("expected bind, got {:?}", other),
    }
}

#[test]
fn explicit_imports_of_autoimport_module_are_duplicates() {
    let module_stages = vec![vec![staged_auto_import_module(
        "Prelude",
        parse_module_ast(r#"def greet() -> String { "hi" }"#, "Prelude"),
    )]];
    for source in [
        "import Prelude",
        "import Prelude::greet",
        "import Prelude::{greet}",
    ] {
        let error = resolve_user_with_modules(source, &module_stages)
            .expect_err("file-start autoimport already imported the module");
        assert!(
            error.message.contains("Duplicate import"),
            "{source}: {error:?}"
        );
        assert!(error.message.contains("autoimport"), "{source}: {error:?}");
        assert_eq!(
            error.diagnostic.reason,
            crate::error::ResolveErrorReason::Import
        );
        assert_eq!(
            error.span,
            Span {
                start: 0,
                end: source.len()
            }
        );
    }
}

#[test]
fn test_std_trait_method_is_auto_imported_from_trait_attribute() {
    let module_stages = vec![vec![staged_module(
        "Metric",
        parse_module_ast(
            r#"@autoimport
deftrait Metric {
  def add(self: Self, rhs: Self) -> Self
}"#,
            "Metric",
        ),
    )]];

    let resolved = resolve_user_with_modules("value = add(1, 2)", &module_stages)
        .expect("std trait method should auto-import");

    let declaration_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, methods, _) if id.name == "Metric" => {
                methods.first().map(|method| &method.id)
            }
            _ => None,
        })
        .expect("trait method declaration should exist");

    let bind = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Bind(_, _, _)))
        .expect("user bind should exist");

    match bind {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, func, args) => {
                assert_eq!(args.len(), 2);
                match func.as_ref() {
                    Resolved::Var(_, id) => {
                        assert_eq!(id.name, "add");
                        assert!(id
                            .qualified_name
                            .as_deref()
                            .is_some_and(|name| name.ends_with("::add")));
                        assert_eq!(id.unique_id, declaration_id.unique_id);
                        assert_eq!(
                            id.symbol_info.as_ref().map(|info| info.identity),
                            Some(TypeIdentity::Trait),
                            "a bare auto-import alias must retain its canonical trait owner"
                        );
                    }
                    other => panic!("expected trait method var, got {:?}", other),
                }
            }
            other => panic!("expected app, got {:?}", other),
        },
        other => panic!("expected bind, got {:?}", other),
    }
}

#[test]
fn explicit_imports_of_autoimport_trait_are_duplicates() {
    let module_stages = vec![vec![staged_module(
        "Metric",
        parse_module_ast(
            "@autoimport\ndeftrait Metric { def add(self: Self, rhs: Self) -> Self }",
            "Metric",
        ),
    )]];
    for source in [
        "import Metric",
        "import Metric::add",
        "import Metric::{add}",
    ] {
        let error = resolve_user_with_modules(source, &module_stages)
            .expect_err("file-start autoimport already imported the trait");
        assert!(
            error.message.contains("Duplicate import"),
            "{source}: {error:?}"
        );
        assert!(error.message.contains("autoimport"), "{source}: {error:?}");
    }
}

#[test]
fn test_autoimport_trait_helper_conflict_is_rejected() {
    let module_stages = vec![vec![
        staged_module(
            "Concat",
            parse_module_ast(
                r#"@autoimport
deftrait Concat {
  def concat(self: Self, rhs: Self) -> Self
}"#,
                "Concat",
            ),
        ),
        staged_module(
            "Fake",
            parse_module_ast(
                r#"@autoimport
deftrait Fake {
  def concat(self: Self) -> Self
}"#,
                "Fake",
            ),
        ),
    ]];

    let err = resolve_user_with_modules("value = 1", &module_stages)
        .expect_err("conflicting auto-import trait helpers must fail");
    assert!(err.message.contains("Auto-import conflict"));
    assert!(err.message.contains("concat"));
    assert!(err.message.contains("Concat"));
    assert!(err.message.contains("Fake"));
}

#[test]
fn test_effective_auto_import_entries_include_autoimport_trait_methods_only() {
    let module_stages = vec![vec![staged_module(
        "Show",
        parse_module_ast(
            r#"@autoimport
deftrait Show {
  def to_string(self: Self) -> String
}"#,
            "Show",
        ),
    )]];

    let entries = crate::effective_auto_import_entries(&module_stages, None, 0)
        .expect("effective auto-import query should succeed");
    let names = entries
        .into_iter()
        .map(|entry| entry.name)
        .collect::<Vec<_>>();

    assert!(
        names.iter().any(|name| name == "Show::to_string"),
        "actual entries: {names:?}"
    );
    assert!(
        names.iter().all(|name| name != "Show"),
        "trait owner should not be reported as imported member: {names:?}"
    );
}

#[test]
fn test_effective_visible_entries_include_explicit_imported_short_name() {
    let module_stages = vec![vec![staged_module(
        "Global::Helper",
        parse_module_ast(
            r#"def helper(value: Int) -> String { "" }"#,
            "Global::Helper",
        ),
    )]];
    let ast = parse("import Helper::helper\nhe").expect("parse should succeed");

    let visible = crate::effective_visible_entries(&module_stages, &ast, None, 0)
        .expect("effective visible query should succeed");
    let imported = visible
        .iter()
        .find(|entry| entry.visible_name == "helper")
        .expect("explicit import should expose short name");

    assert_eq!(imported.entry.name, "helper");
    assert!(imported.via_import);
    assert!(!imported.via_auto_import);
    assert!(imported.importable);
    assert!(imported.callable);
}

#[test]
fn test_effective_visible_entries_reject_explicit_import_conflicting_with_auto_import() {
    let module_stages = vec![vec![
        staged_auto_import_module(
            "Kernel",
            parse_module_ast(r#"def helper() -> Int { 1 }"#, "Kernel"),
        ),
        staged_module(
            "UserHelpers",
            parse_module_ast(r#"def helper() -> Int { 2 }"#, "UserHelpers"),
        ),
    ]];
    let ast = parse("import UserHelpers::helper\nhelper").expect("parse should succeed");

    let error = crate::effective_visible_entries(&module_stages, &ast, None, 0)
        .expect_err("explicit import must reject auto-import conflicts");
    assert!(error.message.contains("Import conflict"), "{error:?}");
}

#[test]
fn test_duplicate_module_import_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let err = resolve_user_with_modules(
        r#"import Helper;
import Helper;
print(to_string(add(1, 2)))"#,
        &module_stages,
    )
    .expect_err("duplicate module import must fail");
    assert!(
        err.message.contains("Duplicate import"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Helper"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_duplicate_module_then_member_import_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let err = resolve_user_with_modules(
        r#"import Helper;
import Helper::add;
print(to_string(add(1, 2)))"#,
        &module_stages,
    )
    .expect_err("module followed by member import must fail");
    assert!(
        err.message.contains("Duplicate import"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Helper::add"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_duplicate_member_then_module_import_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let err = resolve_user_with_modules(
        r#"import Helper::add;
import Helper;
print(to_string(add(1, 2)))"#,
        &module_stages,
    )
    .expect_err("member followed by module import must fail");
    assert!(
        err.message.contains("Duplicate import"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Helper"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_duplicate_member_import_is_rejected() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let err = resolve_user_with_modules(
        r#"import Helper::add;
import Helper::add;
print(to_string(add(1, 2)))"#,
        &module_stages,
    )
    .expect_err("duplicate member import must fail");
    assert!(
        err.message.contains("Duplicate import"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Helper::add"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn imported_normal_function_can_be_shadowed_by_module_definition() {
    for auto_import in [false, true] {
        let prelude_ast = parse_module_ast("def helper() -> Int { 1 }", "Prelude");
        let prelude = if auto_import {
            staged_auto_import_module("Prelude", prelude_ast)
        } else {
            staged_module("Prelude", prelude_ast)
        };
        let source = if auto_import {
            "def helper() -> Int { 2 }\ndef run() -> Int { helper() }"
        } else {
            "import Prelude\ndef helper() -> Int { 2 }\ndef run() -> Int { helper() }"
        };
        let modules = vec![
            vec![prelude],
            vec![staged_module("Local", parse_module_ast(source, "Local"))],
        ];
        let resolved = resolve_user_with_modules("Local::run()", &modules)
            .expect("module definitions may shadow imported normal functions");
        let body = resolved
            .iter()
            .find_map(|node| match node {
                Resolved::Def(_, id, _, _, _, _, body, _)
                    if id.qualified_name.as_deref() == Some("Local::run") =>
                {
                    Some(body)
                }
                _ => None,
            })
            .expect("run body");
        let Resolved::Block(_, nodes) = body.as_ref() else {
            panic!("expected block")
        };
        assert!(matches!(&nodes[0], Resolved::App(_, callee, _)
            if matches!(callee.as_ref(), Resolved::Var(_, id)
                if id.qualified_name.as_deref() == Some("Local::helper"))));
    }
}

#[test]
fn test_explicit_import_conflicts_with_auto_imported_kernel_function() {
    let module_stages = vec![
        vec![staged_module(
            "Kernel",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Kernel"),
        )],
        vec![staged_module(
            "Helper",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x - y }"#, "Helper"),
        )],
    ];

    let error = resolve_user_with_modules(
        r#"import Helper::add;
print(to_string(add(7, 3)))"#,
        &module_stages,
    )
    .expect_err("explicit import must reject auto-import conflicts");
    assert!(error.message.contains("Import conflict"), "{error:?}");
}

fn extractor_import_forms(owner: &str) -> [String; 3] {
    [
        format!("import {owner}"),
        format!("import {owner}::unique_ext"),
        format!("import {owner}::{{unique_ext}}"),
    ]
}

fn extractor_import_environment(
    left: &str,
    right: &str,
    auto_import_left: bool,
) -> ResolveEnvironment {
    let mut stages = standard_test_stages().clone();
    let mut left = staged_module("ExtractorLeft", parse_module_ast(left, "ExtractorLeft"));
    left.auto_import = auto_import_left;
    stages.push(vec![
        left,
        staged_module("ExtractorRight", parse_module_ast(right, "ExtractorRight")),
    ]);
    ResolveEnvironment::from_stages(&stages).expect("Extractor import environment")
}

#[test]
fn extractor_import_forms_preserve_selected_declaration_and_pattern_uid() {
    let environment = extractor_import_environment(
        "defextractor unique_ext(limit: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "defextractor unique_ext(value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
        false,
    );
    let declared = environment
        .global_scope
        .lookup("ExtractorLeft::unique_ext")
        .unwrap();
    let other = environment
        .global_scope
        .lookup("ExtractorRight::unique_ext")
        .unwrap();
    assert_ne!(declared, other);
    assert_eq!(
        environment.declaration_uid_kinds[&declared],
        DeclarationKind::Extractor
    );
    for import in extractor_import_forms("ExtractorLeft") {
        let mut session =
            SigilSession::from_environment(&environment, None, ResolveResumeState::default())
                .unwrap();
        let source = format!("{import}\nmatch (1, 1) {{ (unique_ext(2, left), ExtractorLeft::unique_ext(2, right)) => (left, right), _ => (0, 0) }}");
        let resolved = session.resolve(parse(&source).unwrap()).expect(&source);
        assert_eq!(session.lookup_uid("unique_ext"), Some(declared), "{import}");
        assert_eq!(
            session.lookup_uid("ExtractorLeft::unique_ext"),
            Some(declared)
        );
        assert_eq!(
            session.lookup_uid("ExtractorRight::unique_ext"),
            Some(other)
        );
        let Resolved::Match(_, _, arms) = resolved.last().unwrap() else {
            panic!("expected match: {resolved:?}")
        };
        let ResolvedPattern::Tuple(items) = arms[0].pattern.unlocated() else {
            panic!("expected tuple Pattern")
        };
        for item in items {
            let ResolvedPattern::Extractor(head, pre_args, children) = item.unlocated() else {
                panic!("expected selected named Extractor: {item:?}")
            };
            assert_eq!(head.unique_id, declared, "{import}");
            assert_eq!(
                head.qualified_name.as_deref().map(global_surface_name),
                Some("ExtractorLeft::unique_ext")
            );
            assert_eq!(pre_args.len(), 1);
            assert_eq!(children.len(), 1);
        }
    }
}

#[test]
fn extractor_import_conflicts_do_not_overload_by_type_or_preargument_count() {
    let extractor = "defextractor unique_ext(limit: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }";
    for other in [
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "defextractor unique_ext(value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
        "def unique_ext(value: Int) -> Int { value }",
    ] {
        let environment = extractor_import_environment(extractor, other, false);
        for (first, second) in [
            ("ExtractorLeft", "ExtractorRight"),
            ("ExtractorRight", "ExtractorLeft"),
        ] {
            for first_import in extractor_import_forms(first) {
                for second_import in extractor_import_forms(second) {
                    let source = format!("{first_import}\n{second_import}");
                    let error =
                        super::resolve(parse(&source).unwrap(), &environment).expect_err(&source);
                    assert_eq!(
                        error.diagnostic.reason,
                        crate::error::ResolveErrorReason::Import,
                        "{source}: {error:?}"
                    );
                    assert!(
                        error.message.contains("Import conflict")
                            && error.message.contains("unique_ext"),
                        "{source}: {error:?}"
                    );
                }
            }
        }
    }
}

#[test]
fn extractor_file_imports_keep_if_let_heads_and_success_binding_uids_independent() {
    let providers = vec![
        staged_module(
            "ExtractorLeft",
            parse_module_ast(
                "defextractor unique_ext(limit: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
                "ExtractorLeft",
            ),
        ),
        staged_module(
            "ExtractorRight",
            parse_module_ast(
                "defextractor unique_ext(value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
                "ExtractorRight",
            ),
        ),
    ];
    let consumers = vec![
        staged_module(
            "ExtractorIntConsumer",
            parse_module_ast(
                "import ExtractorLeft::unique_ext\ndef run(value: Int) -> (Int, Int) { (if_let(value, unique_ext(10, selected), selected, 0), if_let(value, ExtractorLeft::unique_ext(20, selected), selected, 0)) }",
                "ExtractorIntConsumer",
            ),
        ),
        staged_module(
            "ExtractorStringConsumer",
            parse_module_ast(
                "import ExtractorRight\ndef run(value: String) -> (String, String) { (if_let(value, unique_ext(selected), selected, \"failure\"), if_let(value, ExtractorRight::unique_ext(selected), selected, \"failure\")) }",
                "ExtractorStringConsumer",
            ),
        ),
    ];
    for reverse in [false, true] {
        let mut stages = standard_test_stages().clone();
        stages.push(providers.clone());
        let mut ordered_consumers = consumers.clone();
        if reverse {
            ordered_consumers.reverse();
        }
        stages.push(ordered_consumers);
        let index = precollect_declaration_index(&stages).unwrap();
        let resolved = resolve_staged_program(&stages, Vec::new(), &index, None)
            .expect("file-local Extractor imports resolve in either module order");
        let declarations = resolved
            .iter()
            .filter_map(|node| match node {
                Resolved::ExtractorDef(_, id, ..) => Some((
                    global_surface_name(id.qualified_name.as_deref().unwrap()).to_string(),
                    id.unique_id,
                )),
                _ => None,
            })
            .collect::<HashMap<_, _>>();
        let mut binding_ids = HashSet::new();
        let mut consumer_count = 0;
        for node in &resolved {
            let Resolved::Def(_, id, _, _, _, _, body, _) = node else {
                continue;
            };
            let Some(name) = id.qualified_name.as_deref().map(global_surface_name) else {
                continue;
            };
            let (extractor_name, pre_arity) = match name {
                "ExtractorIntConsumer::run" => ("ExtractorLeft::unique_ext", 1),
                "ExtractorStringConsumer::run" => ("ExtractorRight::unique_ext", 0),
                _ => continue,
            };
            consumer_count += 1;
            let Resolved::Block(_, nodes) = body.as_ref() else {
                panic!("expected consumer block")
            };
            let [Resolved::TupleLiteral(_, calls)] = nodes.as_slice() else {
                panic!("expected consumer tuple")
            };
            assert_eq!(calls.len(), 2);
            for call in calls {
                let Resolved::IfLet(_, _, arms, false) = call else {
                    panic!("expected if_let")
                };
                let ResolvedPattern::Extractor(head, pre_args, children) =
                    arms[0].pattern.unlocated()
                else {
                    panic!("expected named Extractor")
                };
                assert_eq!(
                    head.unique_id, declarations[extractor_name],
                    "{name}, reverse={reverse}"
                );
                assert_eq!(pre_args.len(), pre_arity);
                let [child] = children.as_slice() else {
                    panic!("expected one payload binding")
                };
                let ResolvedPattern::Var(binding) = child.unlocated() else {
                    panic!("expected success binding")
                };
                assert_eq!(binding.name, "selected");
                let Resolved::Var(_, reference) = &arms[0].body else {
                    panic!("expected success reference")
                };
                assert_eq!(
                    reference.unique_id, binding.unique_id,
                    "{name}, reverse={reverse}"
                );
                assert!(
                    binding_ids.insert(binding.unique_id),
                    "success bindings must be independent: {name}, reverse={reverse}"
                );
            }
        }
        assert_eq!(consumer_count, 2);
        assert_eq!(binding_ids.len(), 4);
    }
}

#[test]
fn extractor_duplicate_imports_reject_every_module_member_list_pair() {
    let environment = extractor_import_environment(
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "def unrelated() -> Int { 0 }",
        false,
    );
    for first in extractor_import_forms("ExtractorLeft") {
        for second in extractor_import_forms("ExtractorLeft") {
            let source = format!("{first}\n{second}");
            let error = super::resolve(parse(&source).unwrap(), &environment).expect_err(&source);
            assert_eq!(
                error.diagnostic.reason,
                crate::error::ResolveErrorReason::Import,
                "{source}: {error:?}"
            );
            assert!(
                error.message.contains("Duplicate import")
                    && error.message.contains("ExtractorLeft"),
                "{source}: {error:?}"
            );
        }
    }
}

#[test]
fn extractor_autoimport_keeps_uid_and_rejects_explicit_duplicates_and_conflicts() {
    let environment = extractor_import_environment(
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "defextractor unique_ext(limit: String, value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
        true,
    );
    let declared = environment
        .global_scope
        .lookup("ExtractorLeft::unique_ext")
        .unwrap();
    let mut session =
        SigilSession::from_environment(&environment, None, ResolveResumeState::default()).unwrap();
    assert_eq!(session.lookup_uid("unique_ext"), Some(declared));
    let resolved = session
        .resolve(parse("match 1 { unique_ext(value) => value, _ => 0 }").unwrap())
        .unwrap();
    let Resolved::Match(_, _, arms) = &resolved[0] else {
        panic!("expected match")
    };
    let ResolvedPattern::Extractor(head, _, _) = arms[0].pattern.unlocated() else {
        panic!("expected Extractor")
    };
    assert_eq!(head.unique_id, declared);
    for (owner, message) in [
        ("ExtractorLeft", "Duplicate import"),
        ("ExtractorRight", "Import conflict"),
    ] {
        for import in extractor_import_forms(owner) {
            let error = session.resolve(parse(&import).unwrap()).expect_err(&import);
            assert_eq!(
                error.diagnostic.reason,
                crate::error::ResolveErrorReason::Import,
                "{import}: {error:?}"
            );
            assert!(error.message.contains(message), "{import}: {error:?}");
            assert_eq!(session.lookup_uid("unique_ext"), Some(declared));
        }
    }
}

#[test]
fn extractor_duplicate_qualified_declarations_reject_extractors_and_functions() {
    let extractor =
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }";
    let other_extractor = "defextractor unique_ext(limit: String, value: String) -> MatchResult<String> { MatchResult::Ok(value) }";
    let function = "def unique_ext(value: Int) -> Int { value }";
    for (first, second) in [
        (extractor, extractor),
        (extractor, other_extractor),
        (other_extractor, extractor),
        (extractor, function),
        (function, extractor),
    ] {
        let mut stages = standard_test_stages().clone();
        stages.push(vec![
            staged_module(
                "ExtractorDuplicate",
                parse_module_ast(first, "ExtractorDuplicate"),
            ),
            staged_module(
                "ExtractorDuplicate",
                parse_module_ast(second, "ExtractorDuplicate"),
            ),
        ]);
        let error =
            ResolveEnvironment::from_stages(&stages).expect_err("duplicate callable identity");
        assert!(
            error
                .message
                .contains("Duplicate fully-qualified declaration")
                && error.message.contains("ExtractorDuplicate::unique_ext"),
            "{first}\n{second}: {error:?}"
        );
    }
}

#[test]
fn extractor_autoimport_conflicts_reject_type_prearity_and_function_overloads() {
    let extractor = "defextractor unique_ext(limit: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }";
    for other in [
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "defextractor unique_ext(value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
        "def unique_ext(value: Int) -> Int { value }",
    ] {
        for reverse in [false, true] {
            let mut modules = vec![
                staged_auto_import_module(
                    "ExtractorLeft",
                    parse_module_ast(extractor, "ExtractorLeft"),
                ),
                staged_auto_import_module(
                    "ExtractorRight",
                    parse_module_ast(other, "ExtractorRight"),
                ),
            ];
            if reverse {
                modules.reverse();
            }
            let mut stages = standard_test_stages().clone();
            stages.push(modules);
            let environment = ResolveEnvironment::from_stages(&stages).unwrap();
            let error = super::resolve(parse("0").unwrap(), &environment)
                .expect_err("conflicting autoimport declarations must fail before application");
            assert_eq!(
                error.diagnostic.reason,
                crate::error::ResolveErrorReason::Import
            );
            assert!(
                error.message.contains("Auto-import conflict")
                    && error.message.contains("unique_ext")
                    && error.message.contains("ExtractorLeft")
                    && error.message.contains("ExtractorRight"),
                "{other}, reverse={reverse}: {error:?}"
            );
        }
    }
}

#[test]
fn extractor_session_import_failures_and_rollback_preserve_identity() {
    let environment = extractor_import_environment(
        "defextractor unique_ext(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }",
        "defextractor unique_ext(value: String) -> MatchResult<String> { MatchResult::Ok(value) }",
        false,
    );
    let declared = environment
        .global_scope
        .lookup("ExtractorLeft::unique_ext")
        .unwrap();
    let mut session =
        SigilSession::from_environment(&environment, None, ResolveResumeState::default()).unwrap();
    for source in [
        "import ExtractorLeft::unique_ext\nimport ExtractorRight::unique_ext",
        "import ExtractorLeft::unique_ext\nmissing_after_extractor_import",
        "import ExtractorLeft::unique_ext\nimport ExtractorLeft::unique_ext",
    ] {
        session.resolve(parse(source).unwrap()).expect_err(source);
        assert_eq!(session.lookup_uid("unique_ext"), None, "{source}");
        assert!(session.last_imports().success_labels.is_empty());
    }
    let before = session.checkpoint();
    session
        .resolve(parse("import ExtractorLeft::unique_ext").unwrap())
        .unwrap();
    assert_eq!(session.lookup_uid("unique_ext"), Some(declared));
    let labels = session.last_imports().success_labels.clone();
    assert_eq!(labels, vec!["ExtractorLeft::unique_ext"]);
    let error = session
        .resolve(parse("import ExtractorRight::unique_ext").unwrap())
        .expect_err("conflicting session import");
    assert!(error.message.contains("Import conflict"));
    assert_eq!(session.lookup_uid("unique_ext"), Some(declared));
    assert_eq!(session.last_imports().success_labels, labels);
    session.rollback(before);
    assert_eq!(session.lookup_uid("unique_ext"), None);
    assert!(session.last_imports().success_labels.is_empty());
    session
        .resolve(parse("import ExtractorLeft::{unique_ext}").unwrap())
        .unwrap();
    assert_eq!(session.lookup_uid("unique_ext"), Some(declared));
}

#[test]
fn test_warning_explicit_unused_function_import_warns() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let output = resolve_user_with_modules_with_warnings(
        r#"import Helper::add;
print("ok")"#,
        &module_stages,
    )
    .expect("program should resolve");

    let messages = warning_messages(&output, WarningKind::UnusedImportFunction);
    assert!(
        messages
            .iter()
            .any(|message| message.contains("Helper::add")),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_warning_auto_imported_function_does_not_warn() {
    let module_stages = vec![vec![staged_auto_import_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let output = resolve_user_with_modules_with_warnings(r#"print("ok")"#, &module_stages)
        .expect("program should resolve");

    assert!(
        !output
            .warnings
            .iter()
            .any(|warning| warning.kind == WarningKind::UnusedImportFunction),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_warning_qualified_call_does_not_consume_explicit_short_import() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let output = resolve_user_with_modules_with_warnings(
        r#"import Helper::add;
print(to_string(Helper::add(1, 2)))"#,
        &module_stages,
    )
    .expect("program should resolve");

    let messages = warning_messages(&output, WarningKind::UnusedImportFunction);
    assert!(
        messages
            .iter()
            .any(|message| message.contains("Helper::add")),
        "warnings: {:?}",
        output.warnings
    );
}

#[test]
fn test_staged_resolution_keeps_local_binder_ids_distinct_from_user_defs() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def keep(x: Int) -> Int { x }"#, "Helper"),
    )]];

    let resolved = resolve_user_with_modules(
        r#"def add1(x: Int) -> Int { x + 1 }
value = add1(41)"#,
        &module_stages,
    )
    .expect("script module should resolve");

    let mut helper_param_uid = None;
    let mut user_def_uid = None;
    let mut user_param_uid = None;
    for node in &resolved {
        if let Resolved::Def(_, id, _, params, _, _, _, _) = node {
            match id.qualified_name.as_deref() {
                Some("Helper::keep") => {
                    helper_param_uid = params.first().map(|param| param.id.unique_id);
                }
                Some("__Script::fixture::add1") => {
                    user_def_uid = Some(id.unique_id);
                    user_param_uid = params.first().map(|param| param.id.unique_id);
                }
                _ => {}
            }
        }
    }

    let helper_param_uid = helper_param_uid.expect("helper param should exist");
    let user_def_uid = user_def_uid.expect("user def should exist");
    let user_param_uid = user_param_uid.expect("user param should exist");
    assert_ne!(helper_param_uid, user_def_uid);
    assert_ne!(helper_param_uid, user_param_uid);
    assert_ne!(user_def_uid, user_param_uid);

    let call_uid = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
                Resolved::App(_, func, _) => match func.as_ref() {
                    Resolved::Var(_, id) if id.name == "add1" => Some(id.unique_id),
                    _ => None,
                },
                _ => None,
            },
            _ => None,
        })
        .expect("user call should resolve to add1");
    assert_eq!(call_uid, user_def_uid);
}

#[test]
fn test_capture_prefers_shadowed_local_function_name() {
    let resolved = parse_and_resolve(
        r#"print = {|x| x}
captured = &print"#,
    )
    .expect("shadowing + capture should resolve");

    let local_print_id = match &resolved[0] {
        Resolved::Bind(_, ResolvedPattern::Var(id), _) => id.unique_id,
        _ => panic!("Expected local print binding"),
    };

    let captured_target_id = match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Capture(_, target, _) => match target.as_ref() {
                Resolved::Var(_, id) => id.unique_id,
                _ => panic!("Expected captured var target"),
            },
            _ => panic!("Expected capture expression"),
        },
        _ => panic!("Expected captured binding"),
    };

    assert_eq!(captured_target_id, local_print_id);
}

// --- SigilSession tests ---

#[test]
fn test_sigil_session_basic_resolve() {
    let mut session = test_session();
    let ast = spire::parse("x = 1").expect("parse failed");
    let resolved = session.resolve(ast).expect("resolve failed");
    assert_eq!(resolved.len(), 1);
    assert!(
        matches!(&resolved[0], Resolved::Bind(_, ResolvedPattern::Var(id), _) if id.name == "x")
    );
}

#[test]
fn test_sigil_session_scope_persists_across_calls() {
    let mut session = test_session();

    let ast1 = spire::parse("x = 1").expect("parse failed");
    session.resolve(ast1).expect("first resolve failed");

    // x must be in scope for the second call
    let ast2 = spire::parse("y = x + 1").expect("parse failed");
    let resolved = session.resolve(ast2).expect("second resolve failed");
    assert!(
        matches!(&resolved[0], Resolved::Bind(_, ResolvedPattern::Var(id), _) if id.name == "y")
    );
}

#[test]
fn test_sigil_session_assigns_fresh_ids_to_empty_impls_across_chunks() {
    let mut session = test_session();
    let first = spire::parse(
        r#"deftrait Marker {}
defstruct FirstMarker {}
defstruct SecondMarker {}
impl Marker for FirstMarker {}"#,
    )
    .expect("first marker chunk should parse");
    let first = session
        .resolve(first)
        .expect("first marker chunk should resolve");
    let (first_impl_id, trait_id) = first
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, declaration_id, trait_id, _, _, _, methods) => {
                assert!(methods.is_empty());
                Some((*declaration_id, trait_id.unique_id))
            }
            _ => None,
        })
        .expect("first empty impl should be retained");

    let second =
        spire::parse("impl Marker for SecondMarker {}").expect("second marker chunk should parse");
    let second = session
        .resolve(second)
        .expect("second marker chunk should resolve");
    let second_impl_id = second
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, declaration_id, _, _, _, _, methods) => {
                assert!(methods.is_empty());
                Some(*declaration_id)
            }
            _ => None,
        })
        .expect("second empty impl should be retained");

    assert_ne!(first_impl_id, trait_id);
    assert_ne!(first_impl_id, second_impl_id);
    assert!(second_impl_id > first_impl_id);
}

#[test]
fn test_sigil_session_top_level_def_cannot_capture_prior_value_binding() {
    let mut session = SigilSession::from_environment(
        standard_test_environment(),
        Some("__Repl::Session".to_string()),
        ResolveResumeState::default(),
    )
    .unwrap();
    let first = spire::parse("x = 1").expect("parse failed");
    session.resolve(first).expect("bind should resolve");

    let second = spire::parse("def f() -> Int { x }").expect("parse failed");
    let err = session
        .resolve(second)
        .expect_err("top-level def capture must fail across session chunks");
    assert!(
        err.message
            .contains("Top-level definition `f` cannot reference value binding `x`"),
        "{}",
        err.message
    );
}

#[test]
fn test_sigil_session_lookup_uid_returns_bound_id() {
    let mut session = test_session();
    let ast = spire::parse("answer = 42").expect("parse failed");
    let resolved = session.resolve(ast).expect("resolve failed");

    let expected_id = match &resolved[0] {
        Resolved::Bind(_, ResolvedPattern::Var(id), _) => id.unique_id,
        _ => panic!("Expected Bind"),
    };

    assert_eq!(session.lookup_uid("answer"), Some(expected_id));
}

#[test]
fn test_sigil_session_checkpoint_rollback_removes_later_bindings() {
    let mut session = test_session();

    // Define x
    let ast1 = spire::parse("x = 1").expect("parse failed");
    session.resolve(ast1).expect("first resolve failed");
    let x_id = session
        .lookup_uid("x")
        .expect("x should be defined after first resolve");

    // Save checkpoint before defining y
    let checkpoint = session.checkpoint();

    // Define y
    let ast2 = spire::parse("y = 2").expect("parse failed");
    session.resolve(ast2).expect("second resolve failed");
    assert!(
        session.lookup_uid("y").is_some(),
        "y should be visible before rollback"
    );

    // Rollback to before y was added
    session.rollback(checkpoint);

    assert!(
        session.lookup_uid("y").is_none(),
        "y should be gone after rollback"
    );
    assert_eq!(
        session.lookup_uid("x"),
        Some(x_id),
        "x should remain after rollback"
    );
}

#[test]
fn test_sigil_session_checkpoint_rollback_restores_owner_registry() {
    let mut session = test_session();
    let checkpoint = session.checkpoint();

    session
        .resolve(spire::parse("defrecord Saved(value: Int)").expect("parse failed"))
        .expect("owner declaration should resolve");
    assert_eq!(
        session.owner_registry().identity_for_owner("Saved"),
        Some(TypeIdentity::Record)
    );

    session.rollback(checkpoint);
    assert_eq!(session.owner_registry().identity_for_owner("Saved"), None);
    session
        .resolve(spire::parse("defrecord Saved(value: Int)").expect("parse failed"))
        .expect("rolled-back owner should be declarable again");
}

#[test]
fn test_sigil_session_rejects_cross_chunk_owner_collision() {
    let mut session = test_session();
    session
        .resolve(spire::parse("defrecord Shared(value: Int)").expect("parse failed"))
        .expect("first owner should resolve");

    let err = session
        .resolve(spire::parse("type Shared = (Int -> Int)").expect("parse failed"))
        .expect_err("signature alias must collide with the existing record owner");
    assert_eq!(err.message, "Duplicate top-level owner: Shared");
    assert!(err
        .related_labels
        .iter()
        .any(|label| label.message == "first Record declaration"));
}

fn assert_cross_session_trait_collision(
    first_chunk: &str,
    conflicting_chunk: &str,
    first_identity: &str,
    conflicting_identity: &str,
) {
    let mut session = test_session();
    session
        .resolve(spire::parse(first_chunk).expect("first trait chunk should parse"))
        .expect("first trait chunk should resolve");
    let registry_before_collision = session.owner_registry().clone();

    let err = session
        .resolve(spire::parse(conflicting_chunk).expect("conflicting trait chunk should parse"))
        .expect_err("same-name trait declarations must collide across chunks");

    assert_eq!(
        err.related_labels[0].message,
        format!("first {first_identity} declaration")
    );
    assert_eq!(
        err.related_labels[1].message,
        format!("conflicting {conflicting_identity} declaration")
    );
    assert_eq!(session.owner_registry(), &registry_before_collision);
}

#[test]
fn test_sigil_session_classifies_trait_collision_candidates_and_rolls_back_merge() {
    for (first_chunk, conflicting_chunk, first_identity, conflicting_identity) in [
        (
            "deftrait Same {}",
            r#"deftrait Same
where
  Self: Type<$A>
{}"#,
            "Trait",
            "TypeConstructor",
        ),
        (
            r#"deftrait Same
where
  Self: Type<$A>
{}"#,
            "deftrait Same {}",
            "TypeConstructor",
            "Trait",
        ),
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
deftrait Same {}"#,
            r#"deftrait Same
where
  Self: Constructor
{}"#,
            "Trait",
            "TypeConstructor",
        ),
        (
            r#"deftrait Constructor
where
  Self: Type<$A>
{}
deftrait Same
where
  Self: Constructor
{}"#,
            "deftrait Same {}",
            "TypeConstructor",
            "Trait",
        ),
    ] {
        assert_cross_session_trait_collision(
            first_chunk,
            conflicting_chunk,
            first_identity,
            conflicting_identity,
        );
    }
}

#[test]
fn test_sigil_session_promotes_inherited_constructor_traits_across_chunks() {
    let mut session = test_session();
    session
        .resolve(
            spire::parse(
                r#"deftrait RootConstructor
where
  Self: Type<$A>
{
  def map_root(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
            )
            .expect("root trait should parse"),
        )
        .expect("root constructor trait should resolve");

    session
        .resolve(
            spire::parse(
                r#"deftrait MiddleConstructor
where
  Self: RootConstructor
{
  def map_middle(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
            )
            .expect("middle trait should parse"),
        )
        .expect("middle constructor trait should resolve");
    assert_eq!(
        session
            .owner_registry()
            .identity_for_owner("MiddleConstructor"),
        Some(TypeIdentity::TypeConstructor)
    );

    session
        .resolve(
            spire::parse(
                r#"deftrait LeafConstructor
where
  Self: MiddleConstructor
{
  def map_leaf(self: Self<$A>, mapper: ($A -> $B)) -> Self<$B>
}"#,
            )
            .expect("leaf trait should parse"),
        )
        .expect("leaf constructor trait should resolve");
    assert_eq!(
        session
            .owner_registry()
            .identity_for_owner("LeafConstructor"),
        Some(TypeIdentity::TypeConstructor)
    );
}

#[test]
fn test_sigil_session_failed_resolve_does_not_pollute_scope() {
    let mut session = test_session();

    // Define x
    let ast1 = spire::parse("x = 1").expect("parse failed");
    session.resolve(ast1).expect("first resolve failed");
    let x_id = session.lookup_uid("x").expect("x should be defined");

    // Attempt to resolve something with an undefined variable — must fail
    let ast_fail = spire::parse("y = undefined_name + 1").expect("parse failed");
    assert!(
        session.resolve(ast_fail).is_err(),
        "resolve of undefined var must fail"
    );

    // x should survive; y must not be committed to scope
    assert_eq!(
        session.lookup_uid("x"),
        Some(x_id),
        "x should remain after failed resolve"
    );
    assert!(
        session.lookup_uid("y").is_none(),
        "y must not be in scope after a failed resolve"
    );
}

#[test]
fn test_sigil_session_allows_top_level_shadowing_of_imported_name() {
    let mut session = test_session();
    session.define_with_id("add", 99);

    let ast = spire::parse("def add(x: Int, y: Int) -> Int { x + y }").expect("parse failed");
    let resolved = session.resolve(ast).expect("resolve failed");

    let def_id = match &resolved[0] {
        Resolved::Def(_, id, _, _, _, _, _, _) => id.unique_id,
        other => panic!("Expected Def, got {:?}", other),
    };

    assert_eq!(session.lookup_uid("add"), Some(def_id));
    assert_ne!(def_id, 99);
}

#[test]
fn test_sigil_session_visible_entries_filter_hidden_surfaces_and_keep_visible_aliases() {
    let mut declaration_index = DeclarationIndex::new();
    declaration_index.insert(
        "Global::Helper::helper".to_string(),
        DeclarationEntry {
            registration_order: declaration_index.len(),
            value_parameter_count: None,
            lazy_parameters: Vec::new(),
            module_path: "Global::Helper".to_string(),
            name: "helper".to_string(),
            fq_name: "Global::Helper::helper".to_string(),
            kind: DeclarationKind::Def,
            stage_index: 0,
            auto_import: false,
            hidden: false,
            visibility: Visibility::Public,
            user_importable: true,
            user_callable: true,
        },
    );
    declaration_index.insert(
        "Global::Kernel::hidden_pid".to_string(),
        DeclarationEntry {
            registration_order: declaration_index.len(),
            value_parameter_count: None,
            lazy_parameters: Vec::new(),
            module_path: "Global::Kernel".to_string(),
            name: "hidden_pid".to_string(),
            fq_name: "Global::Kernel::hidden_pid".to_string(),
            kind: DeclarationKind::Def,
            stage_index: 0,
            auto_import: false,
            hidden: true,
            visibility: Visibility::Public,
            user_importable: true,
            user_callable: true,
        },
    );

    let mut precollected = precollect_declarations(standard_test_stages()).unwrap();
    precollected.declaration_index.extend(declaration_index);
    let environment = ResolveEnvironment::from_precollected(standard_test_stages(), &precollected);
    let mut session =
        SigilSession::from_environment(&environment, None, ResolveResumeState::default()).unwrap();
    session.define_with_id(
        "helper",
        environment.declaration_uids["Global::Helper::helper"],
    );
    session.define_with_id(
        "hidden_pid",
        environment.declaration_uids["Global::Kernel::hidden_pid"],
    );

    let visible = session.visible_declaration_entries();

    assert!(
        visible.iter().any(|entry| {
            entry.visible_name == "helper" && entry.entry.fq_name == "Global::Helper::helper"
        }),
        "visible entries should preserve the visible alias: {visible:?}"
    );
    assert!(
        visible
            .iter()
            .all(|entry| entry.entry.fq_name != "Global::Kernel::hidden_pid"),
        "hidden surfaces should not be exposed: {visible:?}"
    );
}

// --- Expression resolution tests ---

#[test]
fn test_interpolated_string_resolves_embedded_variable() {
    let resolved = parse_and_resolve(
        r#"name = "alice"
greeting = "Hello #{name}!""#,
    )
    .unwrap();

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::InterpolatedStr(_, parts) => {
                let has_text = parts
                    .iter()
                    .any(|p| matches!(p, ResolvedInterpolatedPart::Text(s) if s.contains("Hello")));
                let has_name_var = parts.iter().any(|p| {
                    matches!(p, ResolvedInterpolatedPart::Expr(e)
                            if matches!(e.as_ref(), Resolved::Var(_, id) if id.name == "name"))
                });
                assert!(
                    has_text,
                    "expected 'Hello' text part in interpolated string"
                );
                assert!(
                    has_name_var,
                    "expected resolved `name` variable in interpolated string"
                );
            }
            _ => panic!("Expected InterpolatedStr, got {:?}", rhs),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_field_access_resolves_correct_target() {
    let resolved = parse_and_resolve(
        r#"defstruct Point { x: Int, y: Int }
p = Point { x: 1, y: 2 }
val = p.x"#,
    )
    .unwrap();

    match &resolved[2] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::FieldAccess(_, expr, field) => {
                assert_eq!(field, "x");
                assert!(
                    matches!(expr.as_ref(), Resolved::Var(_, id) if id.name == "p"),
                    "field access target should be `p`"
                );
            }
            _ => panic!("Expected FieldAccess"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_tuple_type_root_resolves_in_field_access() {
    let resolved = parse_and_resolve("facet = Tuple._0").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::FieldAccess(_, expr, field) => {
                assert_eq!(field, "_0");
                let id = resolved_var_id(expr.as_ref());
                assert_eq!(id.name, "Tuple");
                assert_symbol_info_facet_root(id, Some(FacetRootKind::Tuple));
            }
            other => panic!("Expected FieldAccess, got {:?}", other),
        },
        other => panic!("Expected Bind, got {:?}", other),
    }
}

fn bind_rhs(node: &Resolved) -> &Resolved {
    match node {
        Resolved::Bind(_, _, rhs) => rhs.as_ref(),
        other => panic!("Expected Bind, got {:?}", other),
    }
}

fn resolved_var_id(node: &Resolved) -> &ResolvedId {
    match node {
        Resolved::Var(_, id) => id,
        other => panic!("Expected Var, got {:?}", other),
    }
}

fn assert_symbol_info_facet_root(id: &ResolvedId, expected: Option<FacetRootKind>) {
    let info = id
        .symbol_info
        .as_ref()
        .expect("resolved id should carry symbol identity info");
    assert_eq!(info.capabilities.facet_root_path, expected);
}

#[test]
fn test_container_facet_roots_carry_symbol_identity_info() {
    let resolved = parse_and_resolve(
        r#"tuple_facet = Tuple._0
list_facet = List.[0]
map_facet = HashMap.["k"]"#,
    )
    .unwrap();

    match bind_rhs(&resolved[0]) {
        Resolved::FieldAccess(_, expr, field) => {
            assert_eq!(field, "_0");
            assert_symbol_info_facet_root(resolved_var_id(expr), Some(FacetRootKind::Tuple));
        }
        other => panic!("Expected Tuple FieldAccess, got {:?}", other),
    }

    match bind_rhs(&resolved[1]) {
        Resolved::FacetSegmentAccess(_, expr, ResolvedFacetPathSegment::Bracket(_)) => {
            assert_symbol_info_facet_root(resolved_var_id(expr), Some(FacetRootKind::List));
        }
        other => panic!("Expected List FacetSegmentAccess, got {:?}", other),
    }

    match bind_rhs(&resolved[2]) {
        Resolved::FacetSegmentAccess(_, expr, ResolvedFacetPathSegment::Bracket(_)) => {
            assert_symbol_info_facet_root(resolved_var_id(expr), Some(FacetRootKind::HashMap));
        }
        other => panic!("Expected HashMap FacetSegmentAccess, got {:?}", other),
    }
}

#[test]
fn test_primitive_facet_roots_carry_symbol_identity_info_without_facet_path() {
    let resolved = parse_and_resolve("string_facet = String.len").unwrap();

    match bind_rhs(&resolved[0]) {
        Resolved::FieldAccess(_, expr, field) => {
            assert_eq!(field, "len");
            assert_symbol_info_facet_root(resolved_var_id(expr), None);
        }
        other => panic!("Expected String FieldAccess, got {:?}", other),
    }
}

#[test]
fn test_boolean_variant_facet_root_carries_type_root_symbol_identity_info() {
    let resolved = parse_and_resolve("true_facet = Boolean.True").unwrap();

    match bind_rhs(&resolved[0]) {
        Resolved::FieldAccess(_, expr, field) => {
            assert_eq!(field, "True");
            assert_symbol_info_facet_root(resolved_var_id(expr), Some(FacetRootKind::TypeRoot));
        }
        other => panic!("Expected Boolean FieldAccess, got {:?}", other),
    }
}

#[test]
fn test_user_type_declarations_carry_symbol_identity_info() {
    let resolved = parse_and_resolve(
        r#"defstruct User { name: String }
defrecord Pair(left: Int, right: Int)
defenum Light {
  Red,
  Green,
}
deferror Oops(reason: String) { |reason: String| Self(message: reason, reason: reason) }"#,
    )
    .unwrap();

    match &resolved[0] {
        Resolved::StructDef(_, id, ..) => {
            let info = id.symbol_info.as_ref().expect("struct should carry info");
            assert_eq!(info.identity, TypeIdentity::Struct);
            assert!(info.capabilities.type_annotation);
            assert!(info.capabilities.module_owner);
            assert!(info.capabilities.impl_target);
            assert_eq!(
                info.capabilities.facet_root_path,
                Some(FacetRootKind::TypeRoot)
            );
        }
        other => panic!("Expected StructDef, got {:?}", other),
    }

    match &resolved[1] {
        Resolved::RecordDef(_, id, _, _) => {
            let info = id.symbol_info.as_ref().expect("record should carry info");
            assert_eq!(info.identity, TypeIdentity::Record);
            assert!(info.capabilities.type_annotation);
            assert!(info.capabilities.module_owner);
            assert!(info.capabilities.impl_target);
            assert_eq!(
                info.capabilities.facet_root_path,
                Some(FacetRootKind::TypeRoot)
            );
        }
        other => panic!("Expected RecordDef, got {:?}", other),
    }

    match &resolved[2] {
        Resolved::EnumDef(_, id, ..) => {
            let info = id.symbol_info.as_ref().expect("enum should carry info");
            assert_eq!(info.identity, TypeIdentity::Enum);
            assert!(info.capabilities.type_annotation);
            assert!(info.capabilities.module_owner);
            assert!(info.capabilities.impl_target);
            assert_eq!(
                info.capabilities.facet_root_path,
                Some(FacetRootKind::TypeRoot)
            );
        }
        other => panic!("Expected EnumDef, got {:?}", other),
    }

    match &resolved[3] {
        Resolved::DeferrorDef(_, id, _, _) => {
            let info = id.symbol_info.as_ref().expect("deferror should carry info");
            assert_eq!(info.identity, TypeIdentity::Error);
            assert!(info.capabilities.type_annotation);
            assert!(!info.capabilities.module_owner);
            assert!(!info.capabilities.impl_target);
            assert_eq!(info.capabilities.facet_root_path, None);
        }
        other => panic!("Expected DeferrorDef, got {:?}", other),
    }
}

#[test]
fn test_builtin_special_variant_aliases_cannot_be_declared_as_owners() {
    for alias in ["Ok", "Err", "True", "False"] {
        let module_path = format!("Global::{alias}");
        let err = precollect_declaration_index(&[vec![staged_module(&module_path, Vec::new())]])
            .expect_err("builtin-special variant alias should not be usable as a module owner");
        assert!(
            err.message
                .contains("reserved for canonical enum variant aliases"),
            "{alias}: {}",
            err.message
        );

        let err = precollect_declaration_index(&[vec![staged_module(
            "User",
            vec![Ast::EnumDef(
                Span { start: 0, end: 0 },
                format!("Global::{alias}"),
                Vec::new(),
                vec![spire::ast::EnumVariant {
                    name: "Value".to_string(),
                    payload: Vec::new(),
                    discriminant: None,
                    span: Span { start: 0, end: 0 },
                }],
                DeclAttrs::default(),
            )],
        )]])
        .expect_err("builtin-special variant alias should not be usable as a type owner");
        assert!(
            err.message
                .contains("reserved for canonical enum variant aliases"),
            "{alias}: {}",
            err.message
        );
    }
}

#[test]
fn resolves_inferred_facet_capture_with_map_key() {
    let resolved = parse_and_resolve(
        r#"users = []
names = users |*> _.score.["talk"]"#,
    )
    .unwrap();
    let rendered = format!("{resolved:?}");
    assert!(rendered.contains("InferredFacetCapture"), "{rendered}");
    assert!(rendered.contains("Bracket"), "{rendered}");
}

#[test]
fn resolves_container_root_facet_paths() {
    let module_stages = vec![vec![staged_module(
        "Facet",
        parse_module_ast(
            r#"@builtin def view(facet: Facet<ReadablePath, $S, $A, _, _>, source: $S) -> Result<$A>"#,
            "Facet",
        ),
    )]];

    let resolved = resolve_user_with_modules(
        r#"map = ()
value = Facet::view(HashMap.["taro"], map)"#,
        &module_stages,
    )
    .unwrap();
    let rendered = format!("{resolved:?}");
    assert!(rendered.contains("HashMap"), "{rendered}");
    assert!(rendered.contains("Bracket"), "{rendered}");

    let resolved = resolve_user_with_modules(
        r#"values = []
value = Facet::view(List.[0], values)"#,
        &module_stages,
    )
    .unwrap();
    let rendered = format!("{resolved:?}");
    assert!(rendered.contains("List"), "{rendered}");
    assert!(rendered.contains("Bracket"), "{rendered}");
}

#[test]
fn resolves_bulk_update_case_actions_as_facet_calls() {
    let module_stages = vec![vec![staged_module(
        "Facet",
        parse_module_ast(
            r#"@builtin def case_set(facet: Facet<CasePath, $S, $A, $T, $B>, source: $S, value: $B) -> Result<$T>
@builtin def set(facet: Facet<WritablePath, $S, $A, $T, $B>, source: $S, value: $B) -> Result<$T>"#,
            "Facet",
        ),
    )]];
    let resolved = resolve_user_with_modules(
        r#"user = ()
user2 =? Facet::bulk_update(user) {
  nickname.Some <- case_set("alice")
  scores.[1] <- set(500)
}"#,
        &module_stages,
    )
    .unwrap();
    let rendered = format!("{resolved:?}");
    assert!(
        rendered.contains("Facet::case_set") || rendered.contains("case_set"),
        "{rendered}"
    );
    assert!(rendered.contains("FacetCapture"), "{rendered}");
}

#[test]
fn test_list_literal_resolves_all_elements() {
    let resolved = parse_and_resolve("items = [1, 2, 3]").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::ListLiteral(_, elems) => {
                assert_eq!(elems.len(), 3);
                assert!(matches!(&elems[0], Resolved::Lit(_, Lit::Int(n)) if n == &int(1)));
                assert!(matches!(&elems[1], Resolved::Lit(_, Lit::Int(n)) if n == &int(2)));
                assert!(matches!(&elems[2], Resolved::Lit(_, Lit::Int(n)) if n == &int(3)));
            }
            _ => panic!("Expected ListLiteral"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_range_literal_resolves_endpoints() {
    let resolved = parse_and_resolve("items = [1..3]").unwrap();
    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::RangeLiteral(_, start, stop) => {
                assert!(matches!(start.as_ref(), Resolved::Lit(_, Lit::Int(n)) if *n == int(1)));
                assert!(matches!(stop.as_ref(), Resolved::Lit(_, Lit::Int(n)) if *n == int(3)));
            }
            other => panic!("Expected RangeLiteral, got {other:?}"),
        },
        other => panic!("Expected Bind, got {other:?}"),
    }
}

#[test]
fn test_semicolon_expression_wraps_inner_node() {
    let resolved = parse_and_resolve(r#"print("hello");"#).unwrap();
    match &resolved[0] {
        Resolved::Semi(_, inner) => match inner.as_ref() {
            Resolved::App(_, func, _) => match func.as_ref() {
                Resolved::Var(_, id) => assert_eq!(id.name, "print"),
                _ => panic!("Expected Var(print) inside Semi"),
            },
            _ => panic!("Expected App inside Semi"),
        },
        _ => panic!("Expected Semi at top level"),
    }
}

// --- Import error tests ---

#[test]
fn test_unknown_import_member_is_error() {
    let module_stages = vec![vec![staged_module(
        "Helper",
        parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Helper"),
    )]];

    let err = resolve_user_with_modules(
        r#"import Helper::nonexistent;
print("ok")"#,
        &module_stages,
    )
    .expect_err("importing a non-existent member must fail");

    assert!(
        err.message.contains("Unknown import member"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Helper::nonexistent"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_import_list_groups_private_not_importable_and_unknown_members() {
    let module_stages = vec![vec![
        staged_module(
            "User",
            parse_module_ast(
                r#"defstruct User { name: String }
impl User {
  def new(name: String) -> Self { User(name: name) }
  defextractor deconstruct(self: Self) -> User { self }
}"#,
                "User",
            ),
        ),
        staged_module(
            "Secrets",
            parse_module_ast(
                r#"defp secret_suffix() -> String { "::private" }
def public_secret() -> String { "module" ++ secret_suffix() }"#,
                "Secrets",
            ),
        ),
    ]];

    let err = resolve_user_with_modules(
        r#"import User::{new, deconstruct}
import Secrets::{secret_suffix, missing_fun}
print("ok")"#,
        &module_stages,
    )
    .expect_err("invalid list import should fail");

    assert!(
        err.message.contains("Invalid import members in `User`."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: not importable members."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("User::new"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("User::deconstruct"),
        "actual error: {}",
        err.message
    );

    let err = resolve_user_with_modules(
        r#"import Secrets::{secret_suffix, missing_fun}
print("ok")"#,
        &module_stages,
    )
    .expect_err("private and unknown list import should fail");

    assert!(
        err.message.contains("Invalid import members in `Secrets`."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: private functions."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Secrets::secret_suffix"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: unknown import members."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Secrets::missing_fun"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_import_list_groups_hidden_builtin_members() {
    let module_stages = vec![vec![staged_module(
        "Process",
        parse_module_ast(
            r#"@hidden
@builtin def __process_self() -> PID<$Process>

def visible() -> Int { 1 }"#,
            "Process",
        ),
    )]];

    let err = resolve_user_with_modules(
        r#"import Process::{visible, __process_self}
print("ok")"#,
        &module_stages,
    )
    .expect_err("hidden builtin in list import should fail");

    assert!(
        err.message.contains("Invalid import members in `Process`."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: hidden builtins."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Process::__process_self"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_import_list_groups_future_stage_members() {
    let consumer = staged_module(
        "Consumer",
        parse_module_ast(
            r#"import Provider::{value, missing};

def use_value() -> Int {
  value()
}"#,
            "Consumer",
        ),
    );
    let provider = staged_module(
        "Provider",
        parse_module_ast(
            r#"def value() -> Int {
  41
}"#,
            "Provider",
        ),
    );

    let err = resolve_user_with_modules(
        "print(to_string(Consumer::use_value()))",
        &[vec![consumer], vec![provider]],
    )
    .expect_err("future-stage list import should fail");

    assert!(
        err.message
            .contains("Invalid import members in `Provider`."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: unavailable import members."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Provider::value"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Error: unknown import members."),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Provider::missing"),
        "actual error: {}",
        err.message
    );
}

// --- Match arm binding tests ---

#[test]
fn test_match_arm_constructor_binding_resolves_to_same_uid_in_body() {
    let resolved = parse_and_resolve(
        r#"value: Result<Int> = Ok(42)
result = match value {
  Ok(x) => x,
  Err(e) => 0,
}"#,
    )
    .unwrap();

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => match &arms[0] {
                ResolvedMatchArm {
                    pattern: ResolvedPattern::Constructor(ctor_id, inner),
                    guard: None,
                    body,
                } => {
                    assert_eq!(ctor_id.name, "Result::Ok");
                    let binding_id = match inner.as_slice() {
                        [ResolvedPattern::Var(binding_id)] => binding_id,
                        _ => panic!("Expected constructor inner var binding"),
                    };
                    assert_eq!(binding_id.name, "x");
                    // The arm body `x` must refer to the same uid as the pattern binding
                    match body {
                        Resolved::Var(_, var_id) => {
                            assert_eq!(
                                var_id.unique_id, binding_id.unique_id,
                                "body var uid must match pattern binding uid"
                            );
                        }
                        _ => panic!("Expected Var as match arm body"),
                    }
                }
                _ => panic!("Expected Constructor arm pattern with binding"),
            },
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_match_first_binding_pattern_binds_and_is_visible_in_body() {
    let resolved = parse_and_resolve(
        r#"result = match 42 {
  fallback => fallback,
  _ => 0,
}"#,
    )
    .unwrap();

    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => match &arms[0] {
                ResolvedMatchArm {
                    pattern: ResolvedPattern::Var(binding_id),
                    guard: None,
                    body: Resolved::Var(_, body_id),
                } => {
                    assert_eq!(binding_id.name, "fallback");
                    assert_eq!(binding_id.unique_id, body_id.unique_id);
                }
                _ => panic!("Expected first arm to be a binding pattern"),
            },
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_match_as_pattern_and_annotation_resolve_end_to_end() {
    let resolved = parse_and_resolve(
        r#"value = [1, 2]
result = match value {
  [head, ..tail] @ whole: List<Int> => head,
  _ => 0,
}"#,
    )
    .unwrap();

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => match &arms[0] {
                ResolvedMatchArm {
                    pattern:
                        ResolvedPattern::As(inner, alias, Some(AstTy::Generic(_, ty_name, ty_args))),
                    guard: None,
                    body,
                } => {
                    assert_eq!(alias.name, "whole");
                    assert_eq!(ty_name, "List");
                    assert_eq!(ty_args.len(), 1);
                    assert!(matches!(inner.unlocated(), ResolvedPattern::ListCons(_, _)));
                    assert!(matches!(body, Resolved::Var(_, id) if id.name == "head"));
                }
                _ => panic!("Expected as-pattern with generic annotation"),
            },
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind"),
    }
}

#[test]
fn test_match_guard_can_reference_pattern_binding() {
    let resolved = parse_and_resolve(
        r#"result = match 5 {
  num when num `==` 5 => num,
  _ => 0,
}"#,
    )
    .unwrap();

    match &resolved[0] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Match(_, _, arms) => match &arms[0] {
                ResolvedMatchArm {
                    pattern: ResolvedPattern::Var(binding_id),
                    guard: Some(Resolved::BinOp(_, _, left, _)),
                    body: Resolved::Var(_, body_id),
                } => {
                    let Resolved::Var(_, guard_left_id) = left.as_ref() else {
                        panic!("Expected guard left operand to be bound variable");
                    };
                    assert_eq!(binding_id.unique_id, guard_left_id.unique_id);
                    assert_eq!(binding_id.unique_id, body_id.unique_id);
                }
                _ => panic!("Expected guarded variable arm"),
            },
            _ => panic!("Expected Match"),
        },
        _ => panic!("Expected Bind"),
    }
}

// --- build_scope_for_module tests ---

#[test]
fn test_build_scope_for_module_includes_prior_stage_declarations() {
    let module_stages = vec![
        vec![staged_module(
            "Util",
            parse_module_ast(r#"def helper(x: Int) -> Int { x }"#, "Util"),
        )],
        vec![staged_module(
            "App",
            parse_module_ast(r#"def main() -> Int { 0 }"#, "App"),
        )],
    ];

    // Stage index 1 (App) — Util::helper from stage 0 should appear by fully-qualified name
    let scope = build_scope_for_module(&module_stages, Some("App"), 1)
        .expect("build_scope_for_module should succeed");

    assert!(
        scope.lookup("Util::helper").is_some(),
        "Util::helper should be accessible by qualified name in App's scope"
    );
}

#[test]
fn test_build_scope_for_module_includes_qualified_public_const() {
    let module_stages = vec![
        vec![staged_module(
            "AppConfig",
            parse_module_ast(r#"const APP_NAME = "surtr""#, "AppConfig"),
        )],
        vec![staged_module(
            "App",
            parse_module_ast(r#"def main() -> Int { 0 }"#, "App"),
        )],
    ];

    let scope = build_scope_for_module(&module_stages, Some("App"), 1)
        .expect("build_scope_for_module should succeed");

    assert!(
        scope.lookup("AppConfig::APP_NAME").is_some(),
        "AppConfig::APP_NAME should be accessible by qualified name in App's scope"
    );
    assert!(
        scope.lookup("APP_NAME").is_some(),
        "APP_NAME should remain accessible by bare public-const name"
    );
}

#[test]
fn test_nested_import_inside_defmod_resolves_within_module_scope() {
    let module_stages = vec![vec![
        staged_module(
            "String",
            parse_module_ast(r#"def trim(text: String) -> String { text }"#, "String"),
        ),
        staged_module(
            "Parser",
            parse_module_ast(
                r#"import String;
def parse(line: String) -> String { trim(line) }"#,
                "Parser",
            ),
        ),
    ]];

    let resolved = resolve_user_with_modules("print(Parser::parse(\" ok \"))", &module_stages)
        .expect("nested defmod import should resolve");
    assert!(!resolved.is_empty());
}

#[test]
fn test_nested_import_inside_inherent_impl_resolves_without_leaking() {
    let module_stages = vec![vec![
        staged_module(
            "String",
            parse_module_ast(r#"def trim(text: String) -> String { text }"#, "String"),
        ),
        staged_module(
            "User",
            parse_module_ast(
                r#"import String;
defstruct User { name: String }
impl User {
  def normalize(self: Self, name: String) -> String { trim(name) }
}"#,
                "User",
            ),
        ),
    ]];

    let ok = resolve_user_with_modules(
        r#"print(User::normalize(User(name: "x"), " ok "))"#,
        &module_stages,
    )
    .expect("impl-local import should resolve inside impl methods");
    assert!(!ok.is_empty());

    let leak_err = resolve_user_with_modules(
        r#"def helper(name: String) -> String { trim(name) }
print(helper("ok"))"#,
        &module_stages,
    )
    .expect_err("impl-local import must not leak to sibling top-level defs");
    assert!(
        leak_err.message.contains("Undefined function trim/1")
            || leak_err.message.contains("Undefined variable: trim"),
        "actual error: {}",
        leak_err.message
    );
}

#[test]
fn test_nested_import_inside_trait_impl_resolves() {
    let module_stages = vec![vec![
        staged_module(
            "String",
            parse_module_ast(r#"def trim(text: String) -> String { text }"#, "String"),
        ),
        staged_module(
            "Show",
            parse_module_ast(
                r#"deftrait Show {
  def to_string(self: Self) -> String
}"#,
                "Show",
            ),
        ),
        staged_module(
            "User",
            parse_module_ast(
                r#"import String;
defstruct User { name: String }
impl Show::Show for User {
  def to_string(self: Self) -> String { trim(self.name) }
}"#,
                "User",
            ),
        ),
    ]];

    let resolved = resolve_user_with_modules(
        r#"value = User(name: "ok")
print(Show::Show::to_string(value))"#,
        &module_stages,
    )
    .expect("trait-impl-local import should resolve inside trait impl methods");
    assert!(!resolved.is_empty());
}

#[test]
fn test_private_function_direct_qualified_call_reports_private() {
    let module_stages = vec![vec![staged_module(
        "OuterMod",
        parse_module_ast(r#"defp priv_fun(x: Int) -> Int { x }"#, "OuterMod"),
    )]];

    let err = resolve_user_with_modules("print(OuterMod::priv_fun(1))", &module_stages)
        .expect_err("qualified private function call should fail");

    assert!(err.message.contains("OuterMod::priv_fun/1"));
    assert!(
        err.message.contains("is private"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_private_function_from_imported_module_suggests_private_candidate() {
    let module_stages = vec![vec![staged_module(
        "OuterMod",
        parse_module_ast(
            r#"def keep(x: Int) -> Int { x }
defp priv_fun(x: Int) -> Int { x }"#,
            "OuterMod",
        ),
    )]];

    let err = resolve_user_with_modules(
        r#"import OuterMod
print(priv_fun(1))"#,
        &module_stages,
    )
    .expect_err("bare private function call should fail with guidance");

    assert!(err.message.contains("Undefined function priv_fun/1"));
    assert!(
        err.message
            .contains("Help: `OuterMod::priv_fun/1` is private"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_process_helpers_are_owner_local_and_generated_api_stays_public() {
    let stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent Counter {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }
  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }
  @get
  def read(state: Int) -> Result<Int> { Ok(helper(state)) }
  @set
  def write(_state: Int, next: Int) -> Result<Int> { Ok(next) }
  defp helper(state: Int) -> Int { hidden(state) }
  defp hidden(state: Int) -> Int { state }
}"#,
        "Counter",
    ))]];
    let external = crate::effective_visible_entries(&stages, &[], None, 0).unwrap();
    assert!(external
        .iter()
        .all(|visible| !["helper", "hidden"].contains(&visible.entry.name.as_str())));
    let internal =
        crate::effective_visible_entries(&stages, &[], Some(&stages[0][0].module_path), 0).unwrap();
    for name in ["helper", "hidden"] {
        assert!(internal.iter().any(|visible| visible.entry.name == name));
    }
    resolve_user_with_modules("pid =? Counter::init(1)\nCounter::read(pid)", &stages)
        .expect("handler calls may use local helpers and expose only their generated API");
    for source in [
        "Counter::helper(1)",
        "f = &Counter::helper",
        "f = Counter::helper",
        "import Counter::helper",
        "Counter::hidden(1)",
        "f = &Counter::hidden",
        "import Counter::hidden",
    ] {
        let error = resolve_user_with_modules(source, &stages)
            .expect_err("helpers cannot be accessed outside the process owner");
        if source.starts_with("import") || source.contains("(1)") {
            assert_eq!(
                error.diagnostic.reason,
                crate::error::ResolveErrorReason::Visibility,
                "{source}: {error:?}"
            );
        }
    }
}

#[test]
fn test_worker_process_init_surface_is_importable() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent FibWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "FibWorker",
    ))]];

    resolve_user_with_modules(
        r#"import FibWorker::init
worker =? init(1)
print(inspect(worker))"#,
        &module_stages,
    )
    .expect("worker init route should be importable");
}

#[test]
fn test_singleton_agent_pid_surface_is_visible_to_user_code() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "Counter",
    ))]];

    resolve_user_with_modules("pid = Counter::pid()", &module_stages)
        .expect("singleton agent pid surface should resolve");
}

#[test]
fn test_singleton_agent_pid_surface_can_be_imported() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "Counter",
    ))]];

    resolve_user_with_modules(
        r#"import Counter::pid
handle = pid()"#,
        &module_stages,
    )
    .expect("singleton agent pid surface should be importable");
}

#[test]
fn test_singleton_process_init_surface_is_not_importable() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "Counter",
    ))]];

    let err = resolve_user_with_modules(
        r#"import Counter::init
print("ok")"#,
        &module_stages,
    )
    .expect_err("singleton init route import should fail");

    assert!(
        err.message.contains("Counter::init"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("cannot be imported"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_compiler_generated_spawn_surface_is_not_exposed_to_user_imports() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent FibWorker {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def init(seed: Int) -> Result<Int> { Ok(seed) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "FibWorker",
    ))]];

    let err = resolve_user_with_modules(
        r#"import FibWorker::spawn
print("ok")"#,
        &module_stages,
    )
    .expect_err("compiler-generated spawn should not be exposed for import");

    assert!(
        err.message.contains("FibWorker::spawn"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("Unknown import member"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_worker_genserver_init_surface_is_importable() {
    let module_stages = vec![vec![
        staged_module(
            "ProcessTypes",
            parse_module_ast(
                r#"defenum CallResult<$Reply, $State> {
  Reply($Reply, $State),
  ReplyLater($State, (-> Result<$Reply>)),
  Stop(StopReply<$Reply>),
}

defenum StopReply<$Reply> {
  Normal($Reply),
  Error(Error),
}

defenum CastResult<$State> {
  Next($State),
  Stop(StopReason),
}

defenum StopReason {
  Normal,
  Error(Error),
}"#,
                "ProcessTypes",
            ),
        ),
        staged_process_module(parse_module_ast(
            r#"defgenserver QueueServer {
  meta {
    instance: Worker
    init_policy: Eager
    state: Int
  }

  @init
  def boot(seed: Int) -> Result<Int> { Ok(seed) }

  @call
  def size(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}"#,
            "QueueServer",
        )),
    ]];

    resolve_user_with_modules(
        r#"import QueueServer::boot
pid =? boot(1)
print(inspect(pid))"#,
        &module_stages,
    )
    .expect("worker genserver init route should be importable");
}

#[test]
fn test_singleton_genserver_pid_surface_is_visible_to_user_code() {
    let module_stages = vec![vec![
        staged_module(
            "ProcessTypes",
            parse_module_ast(
                r#"defenum CallResult<$Reply, $State> {
  Reply($Reply, $State),
  ReplyLater($State, (-> Result<$Reply>)),
  Stop(StopReply<$Reply>),
}

defenum StopReply<$Reply> {
  Normal($Reply),
  Error(Error),
}"#,
                "ProcessTypes",
            ),
        ),
        staged_process_module(parse_module_ast(
            r#"defgenserver QueueServer {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def size(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}"#,
            "QueueServer",
        )),
    ]];

    resolve_user_with_modules("pid = QueueServer::pid()", &module_stages)
        .expect("singleton genserver pid surface should resolve");
}

#[test]
fn test_singleton_genserver_pid_surface_can_be_imported() {
    let module_stages = vec![vec![
        staged_module(
            "ProcessTypes",
            parse_module_ast(
                r#"defenum CallResult<$Reply, $State> {
  Reply($Reply, $State),
  ReplyLater($State, (-> Result<$Reply>)),
  Stop(StopReply<$Reply>),
}

defenum StopReply<$Reply> {
  Normal($Reply),
  Error(Error),
}"#,
                "ProcessTypes",
            ),
        ),
        staged_process_module(parse_module_ast(
            r#"defgenserver QueueServer {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def size(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}"#,
            "QueueServer",
        )),
    ]];

    resolve_user_with_modules(
        r#"import QueueServer::pid
handle = pid()"#,
        &module_stages,
    )
    .expect("singleton genserver pid surface should be importable");
}

#[test]
fn test_singleton_process_init_surface_is_not_callable_from_user_code() {
    let module_stages = vec![vec![staged_process_module(parse_module_ast(
        r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, _field: String) -> Result<Int> { Ok(state) }

  @set
  def set(_state: Int, next: Int) -> Result<Int> { Ok(next) }
}"#,
        "Counter",
    ))]];

    let err = resolve_user_with_modules("print(inspect(Counter::init()))", &module_stages)
        .expect_err("singleton init route call should fail");

    assert!(
        err.message.contains("Counter::init/0"),
        "actual error: {}",
        err.message
    );
    assert!(
        err.message.contains("cannot be called"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_nested_import_duplicate_conflict_still_errors() {
    let module_stages = vec![vec![
        staged_module(
            "String",
            parse_module_ast(r#"def trim(text: String) -> String { text }"#, "String"),
        ),
        staged_module(
            "Names",
            parse_module_ast(r#"def trim(text: String) -> String { text }"#, "Names"),
        ),
        staged_module(
            "Parser",
            parse_module_ast(
                r#"import String;
import Names;
def parse(line: String) -> String { trim(line) }"#,
                "Parser",
            ),
        ),
    ]];

    let err = resolve_user_with_modules("print(Parser::parse(\"ok\"))", &module_stages)
        .expect_err("conflicting nested imports should fail");
    assert!(
        err.message.contains("Import conflict") || err.message.contains("Duplicate import"),
        "actual error: {}",
        err.message
    );
}

#[test]
fn test_nested_import_conflicts_with_auto_import_within_body() {
    let module_stages = vec![
        vec![staged_module(
            "Kernel",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x + y }"#, "Kernel"),
        )],
        vec![staged_module(
            "Helper",
            parse_module_ast(r#"def add(x: Int, y: Int) -> Int { x - y }"#, "Helper"),
        )],
        vec![staged_module(
            "Parser",
            parse_module_ast(
                r#"import Helper::add;
def parse() -> Int { add(7, 3) }"#,
                "Parser",
            ),
        )],
    ];

    let error = resolve_user_with_modules(r#"print(to_string(Parser::parse()))"#, &module_stages)
        .expect_err("nested imports must reject auto-import conflicts");
    assert!(error.message.contains("Import conflict"), "{error:?}");
}

#[test]
fn test_pipeline_rhs_desugars_partial_special_forms_into_closures() {
    let resolved = resolve_user_with_modules(
        r#"deferror GuardError { "guard" }

def pred(n: Int) -> Boolean {
  n > 0
}

checked = Ok(3) |>= ensure(&pred, GuardError())
flagged = True |> and(False)
verified = Ok(True) |>= require(GuardError())
replaced = Err(GuardError()) |> map_err(GuardError())
wrapped = Err(GuardError()) |> cause(GuardError())"#,
        &[vec![
            staged_auto_import_module("Kernel", parse_module_ast(
                "def ensure(value: $A, pred: ($A -> Boolean), error: Lazy<Error>) -> Result<$A> { Ok(value) }\n@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean\ndef require(condition: Boolean, error: Lazy<Error>) -> Result<Unit> { Err(error()) }", "Kernel")),
            staged_module("Result", parse_module_ast(
                "def map_err(value: Result<$A>, error: Lazy<Error>) -> Result<$A> { value }\n@builtin def cause(value: Result<$A>, error: Lazy<Error>) -> Result<$A>", "Result")),
        ]],
    )
    .expect("pipeline partial special forms should resolve");

    let mut checked_ok = false;
    let mut flagged_ok = false;
    let mut verified_ok = false;
    let mut replaced_ok = false;
    let mut wrapped_ok = false;

    for node in resolved {
        let Resolved::Bind(_, pat, rhs) = node else {
            continue;
        };
        let ResolvedPattern::Var(id) = pat else {
            continue;
        };
        match id.name.as_str() {
            "checked" => match rhs.as_ref() {
                Resolved::ContextBind(_, _, right) => match right.as_ref() {
                    Resolved::Closure(_, params, _, body) => {
                        assert_eq!(params.len(), 1, "partial ensure must become unary closure");
                        assert!(
                            matches!(
                                body.as_ref(),
                                Resolved::LazyApp(_, LazyCaptureKind::Ensure, _, _)
                            ),
                            "partial ensure closure body must retain the ensure callee"
                        );
                        checked_ok = true;
                    }
                    other => panic!("expected closure on checked rhs, got {:?}", other),
                },
                other => panic!("expected context bind for checked, got {:?}", other),
            },
            "flagged" => match rhs.as_ref() {
                Resolved::Pipe(_, _, right) => match right.as_ref() {
                    Resolved::Closure(_, params, _, body) => {
                        assert_eq!(params.len(), 1, "partial and must become unary closure");
                        assert!(
                            matches!(body.as_ref(), Resolved::If(_, _, _, _)),
                            "partial and closure body must resolve to If"
                        );
                        flagged_ok = true;
                    }
                    other => panic!("expected closure on flagged rhs, got {:?}", other),
                },
                other => panic!("expected pipe for flagged, got {:?}", other),
            },
            "verified" => match rhs.as_ref() {
                Resolved::ContextBind(_, _, right) => match right.as_ref() {
                    Resolved::Closure(_, params, _, body) => {
                        assert_eq!(params.len(), 1, "partial require must become unary closure");
                        assert!(
                            matches!(
                                body.as_ref(),
                                Resolved::LazyApp(_, LazyCaptureKind::Require, _, _)
                            ),
                            "partial require closure body must retain the require callee"
                        );
                        verified_ok = true;
                    }
                    other => panic!("expected closure on verified rhs, got {:?}", other),
                },
                other => panic!("expected context bind for verified, got {:?}", other),
            },
            "replaced" => match rhs.as_ref() {
                Resolved::Pipe(_, _, right) => match right.as_ref() {
                    Resolved::Closure(_, params, _, body) => {
                        assert_eq!(params.len(), 1, "partial map_err must become unary closure");
                        assert!(
                            matches!(
                                body.as_ref(),
                                Resolved::LazyApp(_, LazyCaptureKind::MapErr, _, _)
                            ),
                            "partial map_err closure body must retain the map_err callee"
                        );
                        replaced_ok = true;
                    }
                    other => panic!("expected closure on replaced rhs, got {:?}", other),
                },
                other => panic!("expected pipe for replaced, got {:?}", other),
            },
            "wrapped" => match rhs.as_ref() {
                Resolved::Pipe(_, _, right) => match right.as_ref() {
                    Resolved::Closure(_, params, _, body) => {
                        assert_eq!(params.len(), 1, "partial cause must become unary closure");
                        assert!(
                            matches!(body.as_ref(), Resolved::Cause(_, _, _)),
                            "partial cause closure body must resolve to Cause"
                        );
                        wrapped_ok = true;
                    }
                    other => panic!("expected closure on wrapped rhs, got {:?}", other),
                },
                other => panic!("expected pipe for wrapped, got {:?}", other),
            },
            _ => {}
        }
    }

    assert!(checked_ok, "missing checked bind assertion");
    assert!(flagged_ok, "missing flagged bind assertion");
    assert!(verified_ok, "missing verified bind assertion");
    assert!(replaced_ok, "missing replaced bind assertion");
    assert!(wrapped_ok, "missing wrapped bind assertion");
}

#[test]
fn test_pipeline_partial_special_form_does_not_trigger_for_shadowed_local_binding() {
    let resolved = parse_and_resolve(
        r#"map_err = {|value: Int, suffix: Int| value + suffix}
out = 1 |> map_err(2)"#,
    )
    .expect("shadowed local map_err should resolve like an ordinary pipe call");

    match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::Pipe(_, _, right) => match right.as_ref() {
                Resolved::App(_, func, args) => {
                    assert!(matches!(func.as_ref(), Resolved::Var(_, id) if id.name == "map_err"));
                    assert_eq!(
                        args.len(),
                        1,
                        "ordinary shadowed call should keep its explicit arg"
                    );
                }
                other => panic!("expected ordinary app on shadowed rhs, got {:?}", other),
            },
            other => panic!("expected pipe on shadowed binding, got {:?}", other),
        },
        other => panic!("expected bind for shadowed pipeline, got {:?}", other),
    }
}

#[test]
fn test_pipeline_partial_special_form_does_not_trigger_for_shadowed_parameter() {
    fn find_pipe_rhs(node: &Resolved) -> Option<&Resolved> {
        match node {
            Resolved::Pipe(_, _, right) => Some(right.as_ref()),
            Resolved::Block(_, nodes) => nodes.iter().find_map(find_pipe_rhs),
            Resolved::Bind(_, _, rhs) | Resolved::SafeBind(_, _, rhs, _) => find_pipe_rhs(rhs),
            _ => None,
        }
    }

    let resolved = parse_and_resolve(
        r#"def apply(map_err: (Int -> Int)) -> Int {
  1 |> map_err(2)
}"#,
    )
    .expect("shadowed parameter map_err should resolve like an ordinary pipe call");

    let pipe_rhs = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) if id.name == "apply" => find_pipe_rhs(body),
            _ => None,
        })
        .expect("expected pipe rhs inside apply body");

    match pipe_rhs {
        Resolved::App(_, func, args) => {
            assert!(matches!(func.as_ref(), Resolved::Var(_, id) if id.name == "map_err"));
            assert_eq!(
                args.len(),
                1,
                "ordinary shadowed parameter call should keep its explicit arg"
            );
        }
        other => panic!(
            "expected ordinary app on shadowed parameter rhs, got {:?}",
            other
        ),
    }
}

#[test]
fn explicit_return_type_argument_apply_resolves_callable_identity_and_type_arguments() {
    let resolved = parse_and_resolve(
        r#"def identity(value: $A) -> $A { value }
value = identity::<Int>(1)
fn = &identity::<Int>"#,
    )
    .expect("explicit type application should resolve");

    let def_id = match &resolved[0] {
        Resolved::Def(_, id, ..) => id.unique_id,
        other => panic!("expected definition, got {other:?}"),
    };
    for node in [&resolved[1], &resolved[2]] {
        let Resolved::Bind(_, _, rhs) = node else {
            panic!("expected binding, got {node:?}");
        };
        let applied = match rhs.as_ref() {
            Resolved::App(_, callee, _) => callee.as_ref(),
            Resolved::Capture(_, target, _) => target.as_ref(),
            other => panic!("expected call or capture, got {other:?}"),
        };
        assert!(matches!(
            applied,
            Resolved::ReturnTypeArgumentApply(_, target, args)
                if matches!(target.as_ref(), Resolved::Var(_, id) if id.unique_id == def_id)
                    && matches!(args.as_slice(), [argument] if matches!(argument.ty.syntax, AstTy::Named(_, ref name) if name == "Int"))
        ));
    }
}

#[test]
fn enum_constructor_type_arguments_resolve_only_for_the_declared_variant_owner() {
    parse_and_resolve(
        r#"defenum TestEither<$L, $R> { Left($L), Right($R) }
left = TestEither<_, Int>::Left("term")"#,
    )
    .expect("an enum owner and its declared variant should resolve");

    let arity = parse_and_resolve(
        r#"defenum TestEither<$L, $R> { Left($L), Right($R) }
left = TestEither<Int>::Left(1)"#,
    )
    .expect_err("enum constructor type arguments must match the owner arity");
    assert!(arity.message.contains("expects 2 type argument(s), got 1"));

    let non_enum = parse_and_resolve(
        r#"defstruct Box { value: Int }
value = Box<Int>::new(1)"#,
    )
    .expect_err("struct constructors must not use enum constructor type arguments");
    assert!(non_enum.message.contains("is not an enum type"));

    let error = parse_and_resolve(
        r#"defenum TestEither<$L, $R> { Left($L), Right($R) }
impl TestEither { def is_left(value: TestEither<$L, $R>) -> Boolean { True } }
value = TestEither<_, Int>::is_left(TestEither::Left("term"))"#,
    )
    .expect_err("an enum method must not be accepted as a constructor variant");
    assert!(error.message.contains("enum variant"), "{error:?}");
}

#[test]
fn canonical_return_type_arguments_and_value_parameters_resolve() {
    let resolved = parse_and_resolve(
        r#"def identity::<$A>(value: $A) -> $A { value }
call = identity::<Int>(1)"#,
    )
    .expect("canonical signature roles should resolve");

    match resolved.as_slice() {
        [Resolved::Def(_, _, return_type_arguments, value_parameters, ..), ..] => {
            assert_eq!(return_type_arguments.len(), 1);
            assert_eq!(value_parameters.len(), 1);
        }
        other => panic!("expected resolved definition with canonical parameter roles: {other:?}"),
    }

    let call = match &resolved[1] {
        Resolved::Bind(_, _, rhs) => match rhs.as_ref() {
            Resolved::App(_, callee, _) => callee.as_ref(),
            other => panic!("expected resolved call expression, got {other:?}"),
        },
        other => panic!("expected resolved call binding, got {other:?}"),
    };
    assert!(matches!(
        call,
        Resolved::ReturnTypeArgumentApply(_, _, ref args) if args.len() == 1
    ));
}

#[test]
fn ordinary_definition_rejects_a_concrete_named_return_type_argument() {
    let error = parse_and_resolve(r#"def bad::<Int>() -> Int { 0 }"#)
        .expect_err("a concrete named type must not introduce a return type argument");

    assert!(
        error
            .message
            .contains("return type arguments must declare abstract type inputs"),
        "{}",
        error.message
    );
}

#[test]
fn direct_type_constructor_trait_return_type_argument_preserves_source_shape_and_origin() {
    let resolved = parse_and_resolve(
        r#"deftrait TestAlternative
where
  Self: Type<$A>
{}

def guard::<TestAlternative>(condition: Boolean) -> TestAlternative<Unit> {
  ()
}

def accept_context(value: TestAlternative<Int>) -> Unit {
  ()
}"#,
    )
    .expect("a direct TypeConstructor trait RTA should resolve");

    let definition = resolved
        .iter()
        .find(|node| matches!(node, Resolved::Def(_, id, ..) if id.name == "guard"))
        .expect("guard definition");
    let Resolved::Def(_, _, return_type_arguments, _, Some(return_type), None, _, _) = definition
    else {
        panic!("expected resolved guard signature, got {definition:?}");
    };
    let [return_type_argument] = return_type_arguments.as_slice() else {
        panic!("expected one return type argument");
    };
    let AstTy::Generic(_, return_head, _) = &return_type.syntax else {
        panic!("expected direct constructor Trait return");
    };
    let AstTy::Named(type_span, direct_trait_name) = &return_type_argument.ty.syntax else {
        panic!("expected a direct constructor trait name");
    };
    assert_eq!(direct_trait_name, "TestAlternative");
    assert_eq!(return_head, "TestAlternative");
    assert_eq!(return_type_argument.ordinal, 0);
    assert_eq!(return_type_argument.span, *type_span);
    let rta_trait = return_type_argument
        .ty
        .direct_constructor_trait
        .as_ref()
        .expect("RTA keeps canonical Trait identity");
    let return_trait = return_type
        .direct_constructor_trait
        .as_ref()
        .expect("return keeps canonical Trait identity");
    assert_eq!(rta_trait.unique_id, return_trait.unique_id);
    assert_eq!(rta_trait.qualified_name, return_trait.qualified_name);
    let trait_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, ..) if id.name == "TestAlternative" => Some(id),
            _ => None,
        })
        .expect("TestAlternative Trait definition");
    assert_eq!(rta_trait.unique_id, trait_id.unique_id);

    let parameter_trait = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, parameters, ..) if id.name == "accept_context" => parameters
                .first()
                .and_then(|parameter| parameter.ty.direct_constructor_trait.as_ref()),
            _ => None,
        })
        .expect("direct value parameter keeps canonical Trait identity");
    assert_eq!(parameter_trait.unique_id, trait_id.unique_id);
    assert_eq!(parameter_trait.qualified_name, trait_id.qualified_name);
}

#[test]
fn value_parameter_names_do_not_shadow_constructor_trait_signature_identity() {
    let resolved = parse_and_resolve(
        r#"deftrait TestFunctor
where
  Self: Type<$A>
{}

def accept_context(
  TestFunctor: TestFunctor<Int>,
  later: TestFunctor<String>,
) -> Unit {
  ()
}"#,
    )
    .expect("value bindings must not affect signature type resolution");

    let trait_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, ..) if id.name == "TestFunctor" => Some(id),
            _ => None,
        })
        .expect("TestFunctor Trait definition");
    let parameters = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, parameters, ..) if id.name == "accept_context" => {
                Some(parameters)
            }
            _ => None,
        })
        .expect("accept_context definition");
    assert_eq!(parameters.len(), 2);
    for parameter in parameters {
        let direct_trait = parameter
            .ty
            .direct_constructor_trait
            .as_ref()
            .expect("parameter type keeps canonical Trait identity");
        assert_eq!(direct_trait.unique_id, trait_id.unique_id);
        assert_eq!(direct_trait.qualified_name, trait_id.qualified_name);
    }
}

#[test]
fn impl_method_value_scope_does_not_shadow_constructor_trait_signature_identity() {
    let resolved = parse_and_resolve(
        r#"deftrait TestFunctor
where
  Self: Type<$A>
{}

deftrait TestConvert {
  def convert(value: Int) -> Int
}

impl TestConvert for Int {
  def convert(TestFunctor: TestFunctor<Int>) -> TestFunctor<String>
  where
    $F: TestFunctor
  {
    shadow = TestFunctor
    shadow
  }
}"#,
    )
    .expect("impl method value scope must not affect its declaration signature");

    let trait_id = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, ..) if id.name == "TestFunctor" => Some(id),
            _ => None,
        })
        .expect("TestFunctor Trait definition");
    let method = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, _, _, _, _, methods) => methods.first(),
            _ => None,
        })
        .expect("TestConvert implementation method");
    let parameter_trait = method.value_parameters[0]
        .ty
        .direct_constructor_trait
        .as_ref()
        .expect("impl parameter keeps canonical Trait identity");
    let return_trait = method
        .ret_ty
        .as_ref()
        .and_then(|ty| ty.direct_constructor_trait.as_ref())
        .expect("impl return keeps canonical Trait identity");
    assert_eq!(parameter_trait.unique_id, trait_id.unique_id);
    assert_eq!(return_trait.unique_id, trait_id.unique_id);
    let where_trait = method
        .where_clause
        .as_ref()
        .and_then(|clause| clause.constraints.first())
        .and_then(|constraint| constraint.bounds.first())
        .and_then(|bound| match bound {
            ResolvedWhereConstraintRhs::Trait { trait_id } => Some(trait_id),
            _ => None,
        })
        .expect("impl method where clause keeps canonical Trait identity");
    assert_eq!(where_trait.unique_id, trait_id.unique_id);
}

fn trait_impl_self_call_id(body: &Resolved) -> &ResolvedId {
    let Resolved::Block(_, expressions) = body else {
        panic!("method block")
    };
    let Resolved::App(_, target, _) = expressions.last().expect("call expression") else {
        panic!("method call")
    };
    let target = match target.as_ref() {
        Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
        target => target,
    };
    let Resolved::Var(_, id) = target else {
        panic!("named call")
    };
    id
}

#[test]
fn trait_impl_self_call_resolves_contract_instead_of_concrete_method() {
    let resolved = parse_and_resolve(
        r#"
deftrait TestConvert<$To> { def convert::<$To>(self: Self) -> $To }
impl TestConvert<Int> for String {
  def convert::<Int>(self: Self) -> Int { convert::<Int>(1) }
}
"#,
    )
    .expect("trait implementation resolves");
    let Resolved::TraitDef(_, _, _, _, contract, _) = &resolved[0] else {
        panic!("trait")
    };
    let Resolved::TraitImplDef(_, _, _, _, _, _, methods) = &resolved[1] else {
        panic!("impl")
    };
    let callee = trait_impl_self_call_id(&methods[0].body);
    assert_eq!(callee.unique_id, contract[0].id.unique_id);
    assert_eq!(callee.qualified_name, contract[0].id.qualified_name);
    assert_ne!(callee.unique_id, methods[0].function_id.unique_id);
}

#[test]
fn trait_impl_self_call_respects_parameter_shadowing() {
    let resolved = parse_and_resolve(
        r#"
deftrait Apply { def apply(self: Self, apply: (Int -> Int)) -> Int }
impl Apply for String {
  def apply(self: Self, apply: (Int -> Int)) -> Int { apply(1) }
}
"#,
    )
    .expect("local parameter shadows method alias");
    let Resolved::TraitImplDef(_, _, _, _, _, _, methods) = &resolved[1] else {
        panic!("impl")
    };
    let callee = trait_impl_self_call_id(&methods[0].body);
    assert_eq!(
        callee.unique_id,
        methods[0].value_parameters[1].id.unique_id
    );
    assert!(callee.qualified_name.is_none());
}

#[test]
fn trait_impl_self_call_keeps_private_contract_identity() {
    let resolved = parse_and_resolve(
        r#"
deftrait Hidden {
  def expose(self: Self) -> Int { hidden(self) }
  defp hidden(self: Self) -> Int { hidden(self) }
}
impl Hidden for Int {
  defp hidden(self: Self) -> Int { hidden(self) }
}
"#,
    )
    .expect("private helper stays available in its implementation");
    let Resolved::TraitDef(_, _, _, _, contract, _) = &resolved[0] else {
        panic!("trait")
    };
    let Resolved::TraitImplDef(_, _, _, _, _, _, methods) = &resolved[1] else {
        panic!("impl")
    };
    let callee = trait_impl_self_call_id(&methods[0].body);
    assert_eq!(contract[1].attrs.visibility, Visibility::Private);
    assert_eq!(methods[0].attrs.visibility, Visibility::Private);
    assert_eq!(callee.unique_id, contract[1].id.unique_id);
}

#[test]
fn trait_impl_self_call_does_not_change_function_or_inherent_recursion() {
    let resolved = parse_and_resolve(
        r#"
def repeat(value: Int) -> Int { repeat(value) }
impl Int { def bounce(self: Self) -> Int { Int::bounce(self) } }
"#,
    )
    .expect("ordinary and inherent recursion resolve");
    let definitions = resolved
        .iter()
        .filter_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) => Some((id, body)),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(definitions.len(), 2);
    for (id, body) in definitions {
        assert_eq!(trait_impl_self_call_id(body).unique_id, id.unique_id);
    }
}

#[test]
fn trait_impl_self_call_overrides_unrelated_autoimport_alias() {
    let modules = vec![vec![staged_module(
        "Other",
        parse_module_ast(
            r#"
@autoimport
deftrait Other { def convert(self: Self) -> Int }
"#,
            "Other",
        ),
    )]];
    let resolved = resolve_user_with_modules(
        r#"
deftrait Convert { def convert(self: Self) -> Int }
impl Convert for String { def convert(self: Self) -> Int { convert(1) } }
"#,
        &modules,
    )
    .expect("own trait method wins over unrelated file alias");
    let contract = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitDef(_, id, _, _, methods, _) if id.name.ends_with("Convert") => {
                Some(&methods[0].id)
            }
            _ => None,
        })
        .expect("own contract");
    let method = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::TraitImplDef(_, _, id, _, _, _, methods) if id.name.ends_with("Convert") => {
                Some(&methods[0])
            }
            _ => None,
        })
        .expect("own implementation");
    assert_eq!(
        trait_impl_self_call_id(&method.body).unique_id,
        contract.unique_id
    );
}

#[test]
fn trait_impl_self_call_does_not_expose_private_contract_externally() {
    let modules = vec![vec![staged_module(
        "Secret",
        parse_module_ast(
            r#"
deftrait Hidden {
  def expose(self: Self) -> Int { hidden(self) }
  defp hidden(self: Self) -> Int { 0 }
}
"#,
            "Secret",
        ),
    )]];
    let error = resolve_user_with_modules("Secret::Hidden::hidden(1)", &modules)
        .expect_err("private trait helper cannot be called from outside");
    assert!(error.message.contains("private"), "{error:?}");
}

#[test]
fn trait_impl_self_call_respects_local_callable_shadowing() {
    let resolved = parse_and_resolve(
        r#"
deftrait Apply { def apply(self: Self) -> Int }
impl Apply for String {
  def apply(self: Self) -> Int {
    apply = {|value| value}
    apply(1)
  }
}
"#,
    )
    .expect("local callable shadows method alias");
    let Resolved::TraitImplDef(_, _, _, _, _, _, methods) = &resolved[1] else {
        panic!("impl")
    };
    let Resolved::Block(_, expressions) = methods[0].body.as_ref() else {
        panic!("method block")
    };
    let Resolved::Bind(_, ResolvedPattern::Var(id), _) = &expressions[0] else {
        panic!("local callable")
    };
    assert_eq!(
        trait_impl_self_call_id(&methods[0].body).unique_id,
        id.unique_id
    );
}

#[test]
fn do_resolver_exposes_extract_and_safebind_bindings_only_to_following_statements() {
    let source = r#"
source = 1
parse = {|value| value}
result = do::<Option> {
  value <- source
  parsed =? parse(value)
  value = parsed
  value
}
"#;
    let resolved = parse_and_resolve(source).expect("do scopes should resolve");

    let Resolved::Bind(_, _, rhs) = &resolved[2] else {
        panic!("expected result binding");
    };
    let Resolved::Do(_, intrinsic_id, _, return_type_arguments, statements) = rhs.as_ref() else {
        panic!("expected resolved do expression");
    };
    assert_eq!(*intrinsic_id, sindr::intrinsic::IntrinsicId::Do);
    assert_eq!(return_type_arguments.len(), 1);
    let [ResolvedDoStatement::Extract {
        operator_span: extract_operator_span,
        pattern: ResolvedPattern::Var(extracted),
        rhs: extract_rhs,
        ..
    }, ResolvedDoStatement::SafeBind {
        operator_span: safe_bind_operator_span,
        pattern: ResolvedPattern::Var(parsed),
        rhs: safe_rhs,
        ..
    }, ResolvedDoStatement::Statement(Resolved::Bind(_, ResolvedPattern::Var(shadowed), bind_rhs)), ResolvedDoStatement::Statement(Resolved::Var(_, final_id))] =
        statements.as_slice()
    else {
        panic!("unexpected resolved do statements: {statements:?}");
    };

    let Resolved::Var(_, extract_rhs_id) = extract_rhs else {
        panic!("extract RHS should resolve to the outer source");
    };
    assert_eq!(extract_rhs_id.name, "source");
    assert_ne!(extract_rhs_id.unique_id, extracted.unique_id);
    assert_eq!(
        &source[extract_operator_span.start..extract_operator_span.end],
        "<-"
    );
    assert_eq!(
        &source[safe_bind_operator_span.start..safe_bind_operator_span.end],
        "=?"
    );
    let Resolved::App(_, _, safe_args) = safe_rhs else {
        panic!("safe-bind RHS should be a resolved call");
    };
    assert!(
        matches!(safe_args.as_slice(), [ResolvedRecordLitArg::Positional(Resolved::Var(_, id))] if id.unique_id == extracted.unique_id)
    );
    assert!(matches!(bind_rhs.as_ref(), Resolved::Var(_, id) if id.unique_id == parsed.unique_id));
    assert_eq!(final_id.unique_id, shadowed.unique_id);
}

#[test]
fn do_resolver_does_not_leak_pattern_bindings_outside_the_block() {
    let error = parse_and_resolve(
        r#"
source = 1
result = do { value <- source
  source }
value
"#,
    )
    .expect_err("do-local binding must not escape");
    assert!(
        error.message.contains("Undefined variable: value"),
        "{error:?}"
    );
}

#[test]
fn do_resolver_does_not_expose_a_pattern_to_its_own_rhs() {
    let error = parse_and_resolve("do { value <- value\nfinish() }")
        .expect_err("the new pattern binding must not be visible in its own RHS");
    assert!(
        error.message.contains("Undefined variable: value"),
        "{error:?}"
    );
}

#[test]
fn do_resolver_rewrites_capture_placeholders_inside_do_items() {
    let resolved = parse_and_resolve(
        r#"
wrap = {|value| value}
finish = {|value| value}
captured = &wrap(do { finish(&1) })
"#,
    )
    .expect("capture placeholders inside do should be collected and rewritten");
    assert!(matches!(
        &resolved[2],
        Resolved::Bind(_, _, rhs) if matches!(rhs.as_ref(), Resolved::CaptureClosure(..))
    ));
}

#[test]
fn do_resolver_captures_outer_values_referenced_by_pin_patterns() {
    let resolved = parse_and_resolve(
        r#"
expected = 1
run = {|source| do { ^expected <- source
  source }}
"#,
    )
    .expect("a do pin should capture its referenced outer value");
    let Resolved::Bind(_, _, rhs) = &resolved[1] else {
        panic!("expected run binding");
    };
    let Resolved::Closure(_, _, captures, _) = rhs.as_ref() else {
        panic!("expected run closure, got {rhs:?}");
    };
    assert!(
        matches!(captures.as_slice(), [id] if id.name == "expected"),
        "{captures:?}"
    );
}

#[test]
fn do_resolver_finds_misplaced_pipe_slots_inside_do_items() {
    let error = parse_and_resolve(
        r#"
consume = {|value| value}
finish = {|value| value}
bad = 1 |> consume(do { finish(_1) })
"#,
    )
    .expect_err("nested pipe slot inside do must not bypass the direct-argument rule");
    assert!(
        error.message.contains("pipe placeholder `_1`")
            && !error.message.contains("Undefined variable"),
        "{error:?}"
    );
}

#[test]
fn do_resolver_preserves_pattern_identities_and_nested_scope() {
    let module_stages = vec![vec![staged_module(
        "Matchers",
        parse_module_ast("defextractor never(term: Int) -> Int { term }", "Matchers"),
    )]];
    let resolved = resolve_user_with_modules(
        r#"
import Matchers::never
source = Ok(1)
result = do::<Result> {
  Ok(value) @ whole <- source
  never(extracted) <- value
  ^whole =? source
  extracted
}
"#,
        &module_stages,
    )
    .expect("constructor, Extractor, as-pattern, and pin identities should resolve");

    let Resolved::Bind(_, _, rhs) = resolved.last().expect("result binding") else {
        panic!("expected result binding");
    };
    let Resolved::Do(_, _, _, _, statements) = rhs.as_ref() else {
        panic!("expected resolved do");
    };
    let [ResolvedDoStatement::Extract {
        pattern: ResolvedPattern::As(constructor, whole, None),
        ..
    }, ResolvedDoStatement::Extract {
        pattern: ResolvedPattern::Extractor(extractor, _, extracted_items),
        ..
    }, ResolvedDoStatement::SafeBind {
        pattern: ResolvedPattern::Pin(pinned),
        ..
    }, ResolvedDoStatement::Statement(Resolved::Var(_, final_id))] = statements.as_slice()
    else {
        panic!("unexpected do patterns: {statements:?}");
    };
    let ResolvedPattern::Constructor(constructor_id, constructor_items) = constructor.as_ref()
    else {
        panic!("expected constructor inside as-pattern: {constructor:?}");
    };
    let [ResolvedPattern::Var(value)] = constructor_items.as_slice() else {
        panic!("expected constructor payload binding: {constructor_items:?}");
    };
    let [ResolvedPattern::Var(extracted)] = extracted_items.as_slice() else {
        panic!("expected extractor payload binding: {extracted_items:?}");
    };
    assert_eq!(constructor_id.name, "Result::Ok");
    assert_eq!(extractor.name, "never");
    assert_eq!(pinned.unique_id, whole.unique_id);
    assert_eq!(final_id.unique_id, extracted.unique_id);
    assert_ne!(value.unique_id, extracted.unique_id);
}

#[test]
fn match_result_owner_is_reserved_for_the_standard_definition() {
    let error = parse_and_resolve("defenum MatchResult<$T> { Ok($T), Err(String) }")
        .expect_err("a user enum must not replace canonical MatchResult");
    assert!(error.message.contains("reserved"));
    assert!(error.message.contains("MatchResult"));
}

#[test]
fn match_result_constructors_keep_qualified_identity_without_bare_aliases() {
    let ast = spire::parse_with_context(
        "@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }",
        spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
    )
    .unwrap();
    let mut resolver = Resolver::new();
    resolver
        .resolve_program(prepare_internal_program(ast))
        .expect("standard enum should resolve");
    let ok = resolver
        .scope
        .lookup("MatchResult::Ok")
        .expect("qualified Ok");
    let err = resolver
        .scope
        .lookup("MatchResult::Err")
        .expect("qualified Err");
    assert_eq!(
        resolver.declaration_uid_kinds.get(&ok),
        Some(&DeclarationKind::EnumVariant)
    );
    assert_eq!(
        resolver.declaration_uid_kinds.get(&err),
        Some(&DeclarationKind::EnumVariant)
    );
    assert_ne!(resolver.scope.lookup("Ok"), Some(ok));
    assert_ne!(resolver.scope.lookup("Err"), Some(err));
}

fn preargument_test_modules() -> Vec<Vec<StagedModuleAst>> {
    vec![vec![
        kernel_pattern_test_module(),
        staged_module("", parse_module_ast("@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }", "")),
        staged_module("Bounds", parse_module_ast("defextractor offset(amount: Int, value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }\ndefextractor unit(value: Int) -> MatchResult<Unit> { MatchResult::Ok(()) }", "Bounds")),
    ]]
}

#[test]
fn extractor_prearguments_and_pins_keep_outer_binding_identity() {
    let resolved = resolve_user_with_modules(
        "amount = 10\nresult = match (2, 3, 10) { (amount, Bounds::offset(amount, adjusted), ^amount) => (amount, adjusted), _ => (0, 0) }",
        &preargument_test_modules()).unwrap();
    let outer = resolved
        .iter()
        .find_map(|node| match node {
            Resolved::Bind(_, ResolvedPattern::Var(id), _) if id.name == "amount" => {
                Some(id.unique_id)
            }
            _ => None,
        })
        .unwrap();
    let Resolved::Bind(_, _, rhs) = resolved.last().unwrap() else {
        panic!("result binding");
    };
    let Resolved::Match(_, _, arms) = rhs.as_ref() else {
        panic!("match");
    };
    let ResolvedPattern::Tuple(items) = arms[0].pattern.unlocated() else {
        panic!("tuple");
    };
    let [ResolvedPattern::Var(shadow), ResolvedPattern::Extractor(_, args, children), ResolvedPattern::Pin(pin)] =
        items.as_slice()
    else {
        panic!("pattern contract");
    };
    assert_ne!(shadow.unique_id, outer);
    assert_eq!(pin.unique_id, outer);
    assert!(matches!(args.as_slice(), [Resolved::Var(_, id)] if id.unique_id == outer));
    assert!(matches!(children.as_slice(), [ResolvedPattern::Var(id)] if id.name == "adjusted"));
}

#[test]
fn extractor_prearguments_do_not_count_as_predicate_or_or_bindings() {
    for source in [
        "amount = 10\nis_match(1, Bounds::offset(amount, _))",
        "amount = 10\nmatch 1 { Bounds::offset(amount, value) | Bounds::offset(0, value) => value, _ => 0 }",
    ] {
        resolve_user_with_modules(source, &preargument_test_modules()).expect(source);
    }
}

#[test]
fn extractor_preargument_and_pin_cannot_read_new_pattern_bindings() {
    for source in [
        "match (1, 2) { (fresh, Bounds::offset(fresh, _)) => 1, _ => 0 }",
        "match (1, 2) { (fresh, ^fresh) => 1, _ => 0 }",
    ] {
        let error =
            resolve_user_with_modules(source, &preargument_test_modules()).expect_err(source);
        assert!(error.message.contains("fresh"), "{error:?}");
    }
}

#[test]
fn extractor_payload_unit_keeps_deferred_parser_error() {
    let error = resolve_user_with_modules(
        "match 1 { Bounds::unit(()) => 1, _ => 0 }",
        &preargument_test_modules(),
    )
    .expect_err("Unit is not a Pattern");
    let crate::error::ResolveErrorReason::DeferredParse(parser_error) = error.diagnostic.reason
    else {
        panic!("expected deferred parser error: {error:?}");
    };
    assert_eq!(
        parser_error.reason(),
        spire::error::ParseErrorReason::PatternSyntax
    );
    assert!(parser_error.message().contains("Unit type has no pattern"));
}

#[test]
fn extractor_prearguments_capture_outer_values_in_closures() {
    for body in [
        "Bounds::offset(amount, out) =? Ok(value)\n Ok(out)",
        "match value { Bounds::offset(amount, out) => out, _ => 0 }",
        "if_let(value, Bounds::offset(amount, out), out, 0)",
    ] {
        let source = format!("amount = 10\nf = {{|value: Int| {body}}}");
        let resolved = resolve_user_with_modules(&source, &preargument_test_modules()).expect(body);
        let Resolved::Bind(_, _, rhs) = resolved.last().unwrap() else {
            panic!("closure binding");
        };
        let Resolved::Closure(_, _, captures, _) = rhs.as_ref() else {
            panic!("closure");
        };
        assert!(
            matches!(captures.as_slice(), [id] if id.name == "amount"),
            "{body}: {captures:?}"
        );
    }
}

#[test]
fn local_extractor_argument_candidates_preserve_outer_and_provisional_identities() {
    let resolved = parse_and_resolve("amount = 10\ne = *{|limit: Int, value: Int| value}\nmatch 1 { e(amount, out) => (amount, out), _ => (0, 0) }").unwrap();
    let Resolved::Bind(_, ResolvedPattern::Var(outer), _) = &resolved[0] else {
        panic!("outer binding");
    };
    let Resolved::Match(_, _, arms) = resolved.last().unwrap() else {
        panic!("match");
    };
    let ResolvedPattern::Deferred {
        pattern,
        bindings,
        allow_bindings,
    } = &arms[0].pattern
    else {
        panic!("deferred Pattern");
    };
    assert!(*allow_bindings);
    let ResolvedPattern::ExtractorApplication { args, .. } = pattern.as_ref() else {
        panic!("local application");
    };
    let amount = bindings
        .iter()
        .find(|binding| binding.proxy.name == "amount")
        .unwrap();
    assert_eq!(amount.outer.as_ref().unwrap().unique_id, outer.unique_id);
    assert_ne!(amount.proxy.unique_id, outer.unique_id);
    assert!(
        matches!(args[0].expr.as_deref(), Ok(Resolved::Var(_, id)) if id.unique_id == outer.unique_id)
    );
    assert!(
        matches!(args[0].pattern.as_deref(), Ok(ResolvedPattern::Var(id)) if id.unique_id == amount.proxy.unique_id)
    );
    assert!(
        args[1].expr.is_err(),
        "undefined Expr is retained until role selection"
    );
    assert!(args[1].pattern.is_ok());
    let Resolved::TupleLiteral(_, values) = &arms[0].body else {
        panic!("tuple body");
    };
    assert!(matches!(&values[0], Resolved::Var(_, id) if id.unique_id == amount.proxy.unique_id));
}

#[test]
fn local_extractor_predicate_defers_its_binding_prohibition() {
    let resolved =
        parse_and_resolve_pattern_consumers("e = {|value| value}\nis_match(1, e(candidate))")
            .unwrap();
    let Resolved::IsMatch(_, _, arms) = resolved.last().unwrap() else {
        panic!("predicate match");
    };
    assert!(matches!(
        &arms[0].pattern,
        ResolvedPattern::Deferred {
            allow_bindings: false,
            ..
        }
    ));
}

#[test]
fn complete_pattern_consumer_captures_preserve_pattern_scope() {
    for source in [
        "f = &is_match(&1, Ok(_))",
        "f = &Kernel::is_match(&1, Ok(_))",
        "f = &apply_pattern(&1, [_1, .._])",
        "f = &if_let(&1, Ok(x), x + &2, 0)",
        "f = &if_let_then(&1, Ok(x), print(x))",
    ] {
        let resolved = parse_and_resolve_pattern_consumers(source).expect(source);
        assert!(matches!(resolved.last(), Some(Resolved::Bind(_, _, body))
            if matches!(body.as_ref(), Resolved::CaptureClosure(..))));
    }
}

#[test]
fn if_let_eager_boundary_resolves_before_binding_scope() {
    let error = parse_and_resolve_pattern_consumers("if_let(Ok(1), Ok(x), (x + 1), 0)")
        .expect_err("eager boundary must not see pattern binding");
    assert!(
        error.message.contains("Undefined variable") || error.message.contains("UndefinedVariable"),
        "{error:?}"
    );
    parse_and_resolve_pattern_consumers("x = 10\nf = &if_let(&1, Ok(x), (x + 1), 0)")
        .expect("outer binding belongs to eager boundary");
}

#[test]
fn lazy_eager_expression_rejects_capture_parameter_references() {
    let modules = vec![
        staged_module("", parse_module_ast("@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }", "")),
        staged_auto_import_module("Kernel", parse_module_ast(
            "@builtin def and(left: Boolean, right: Lazy<Boolean>) -> Boolean\n@builtin def or(left: Boolean, right: Lazy<Boolean>) -> Boolean\ndef if(condition: Boolean, yes: Lazy<$A>, no: Lazy<$A>) -> $A { yes() }\ndef if_then(condition: Boolean, yes: Lazy<Unit>) -> Unit { yes() }\ndef require(condition: Boolean, error: Lazy<Error>) -> Result<Unit> { Err(error()) }\ndef ensure(value: $A, pred: ($A -> Boolean), error: Lazy<Error>) -> Result<$A> { Ok(value) }", "Kernel")),
        kernel_pattern_test_module(),
        staged_module("Result", parse_module_ast(
            "def map_err(value: Result<$A>, error: Lazy<Error>) -> Result<$A> { value }\n@builtin def cause(value: Result<$A>, error: Lazy<Error>) -> Result<$A>", "Result")),
    ];
    for source in [
        "f = &if(&1, (1 + &2), 0)",
        "f = &Kernel::if(&1, 0, (1 + &2))",
        "f = &if_then(&1, (print(to_string(&2))))",
        "f = &and(&1, (True == &2))",
        "f = &or(&1, (True == &2))",
        "f = &require(&1, (inspect(&2)))",
        "f = &ensure(&1, &inspect, (inspect(&2)))",
        "f = &Result::map_err(&1, (inspect(&2)))",
        "f = &Result::cause(&1, (inspect(&2)))",
        "x = 10\nf = &if_let(&1, Ok(x), (x + &2), 0)",
        "f = &Kernel::if_let(&1, Ok(_), (1 + &2), 0)",
        "f = &if_let(&1, Ok(x), x, (1 + &2))",
        "f = &if_let_then(&1, Ok(x), (print(to_string(&2))))",
        "f = &if_let_then(&1, Ok(_), (print(to_string(&2))))",
        "f = &inspect(if(True, (1 + &1), 0))",
        "x = 10\nf = &inspect(if_let(Ok(1), Ok(x), (x + &1), 0))",
        "f = &if(&1, (if(True, &2, 0)), 0)",
        "e = *{|limit: Int, value: Int| MatchResult::Ok(value)}\nf = &if(&1, (is_match(1, e(&2, _))), False)",
        "e = *{|limit: Int, value: Int| MatchResult::Ok(value)}\nf = &if(&1, (if_let(1, e(&2, x), x, 0)), 0)",
    ] {
        let error = resolve_user_with_modules(source, &[modules.clone()])
            .err()
            .unwrap_or_else(|| panic!("Lazy eager expression must reject: {source}"));
        assert_eq!(
            error.diagnostic.reason,
            crate::error::ResolveErrorReason::Capture,
            "{source}: {error:?}"
        );
        assert!(
            error.message.contains("Lazy eager expression"),
            "{source}: {error:?}"
        );
        assert!(
            matches!(&source[error.span.start..error.span.end], "&1" | "&2"),
            "{source}: {error:?}"
        );
    }
}

#[test]
fn lazy_eager_scope_preserves_direct_parameters_and_ordinary_grouping() {
    for source in [
        "f = &if_let(&1, Ok(x), &2, 0)",
        "f = &if_let(&1, Ok(x), ((&2)), 0)",
        "f = &if_let(&1, Ok(x), x + &2, 0)",
        "f = &if_let(&1, Ok(x), x + (&2 + 1), 0)",
        "f = &if_let(&1, Ok(x), match x { _ => (&2 + 1) }, 0)",
        "x = 10\nf = &if_let(&1, Ok(x), (x + 1), 0)",
    ] {
        parse_and_resolve_pattern_consumers(source).expect(source);
    }
    // Ordinary function arguments have grouping, without a Lazy eager boundary.
    parse_and_resolve("def add(x: Int, y: Int) -> Int { x + y }\nf = &add(&1, (1 + &2))")
        .expect("ordinary grouped argument keeps its capture placeholders");
    resolve_user_with_modules(
        "e = *{|limit: Int, value: Int| MatchResult::Ok(value)}\nf = &if_let(&1, e(&2, x), x, 0)",
        &[vec![
            kernel_pattern_test_module(),
            staged_module(
                "",
                parse_module_ast(
                    "@builtin defenum MatchResult<$T> { Ok($T), Err(Error) }",
                    "",
                ),
            ),
        ]],
    )
    .expect("Pattern pre-argument outside a Lazy eager boundary keeps its placeholder");
}

#[test]
fn capture_placeholder_references_have_generated_identity() {
    let resolved = parse_and_resolve_pattern_consumers("f = &if_let(&1, Ok(x), &2, 0)").unwrap();
    let Resolved::Bind(_, _, body) = &resolved[0] else {
        panic!("bind")
    };
    let Resolved::CaptureClosure(_, params, _, body) = body.as_ref() else {
        panic!("capture")
    };
    let Resolved::IfLet(_, _, arms, _) = body.as_ref() else {
        panic!("consumer")
    };
    let Resolved::Var(_, id) = &arms[0].body else {
        panic!("parameter")
    };
    assert!(id.compiler_generated);
    assert_eq!(id.unique_id, params[1].id.unique_id);
}

#[test]
fn autoimport_provenance_covers_own_file_namespaced_owners_and_empty_modules() {
    let own = staged_auto_import_module(
        "Prelude",
        parse_module_ast("import Prelude::greet\ndef greet() -> Int { 1 }", "Prelude"),
    );
    let error = resolve_user_with_modules("1", &[vec![own]])
        .expect_err("own module also has file-start autoimport provenance");
    assert!(
        error.message.contains("Duplicate import") && error.message.contains("autoimport"),
        "{error:?}"
    );

    let namespaced = staged_auto_import_module(
        "Global::Domain::Prelude",
        parse_module_ast("def greet() -> Int { 1 }", "Global::Domain::Prelude"),
    );
    let error = resolve_user_with_modules("import Domain::Prelude::{greet}", &[vec![namespaced]])
        .expect_err("surface owner must match canonical autoimport metadata");
    assert!(
        error.message.contains("Duplicate import") && error.message.contains("Domain::Prelude"),
        "{error:?}"
    );

    let empty = staged_auto_import_module("Empty", Vec::new());
    let error = resolve_user_with_modules("import Empty", &[vec![empty]])
        .expect_err("an empty autoimport module is still already imported");
    assert!(
        error.message.contains("Duplicate import") && error.message.contains("autoimport"),
        "{error:?}"
    );
}

#[test]
fn autoimport_provenance_is_available_in_each_file_but_not_future_stages() {
    let prelude = staged_auto_import_module(
        "Prelude",
        parse_module_ast("def greet() -> Int { 1 }", "Prelude"),
    );
    for owner in ["Left", "Right"] {
        let consumer = staged_module(
            owner,
            parse_module_ast(
                "import Prelude::greet\ndef use_greet() -> Int { greet() }",
                owner,
            ),
        );
        let error = resolve_user_with_modules("1", &[vec![prelude.clone(), consumer]])
            .expect_err("every file begins with the same available autoimports");
        assert!(
            error.message.contains("Duplicate import") && error.message.contains("autoimport"),
            "{owner}: {error:?}"
        );
    }

    let earlier = staged_module(
        "Earlier",
        parse_module_ast(
            "import Prelude::greet\ndef use_greet() -> Int { greet() }",
            "Earlier",
        ),
    );
    let error = resolve_user_with_modules("1", &[vec![earlier], vec![prelude]])
        .expect_err("future-stage autoimport is not visible yet");
    assert!(
        error.message.contains("not available in the current stage"),
        "{error:?}"
    );
    assert!(!error.message.contains("Duplicate import"), "{error:?}");
}

#[test]
fn autoimport_trait_container_selection_rejects_only_the_imported_trait_surface() {
    for module_name in ["Domain", "Global::Domain"] {
        let modules = vec![vec![staged_module(module_name, parse_module_ast(
            "@autoimport deftrait Metric { def add(self: Self, rhs: Self) -> Self }\ndef ordinary() -> Int { 1 }",
            module_name,
        ))]];
        resolve_user_with_modules("value = add(1, 2)", &modules)
            .expect("autoimport must provide the canonical trait helper");
        for source in [
            "import Domain::Metric",
            "import Domain::{Metric}",
            "import Domain",
            "import Domain::Metric::add",
            "import Domain::Metric::{add}",
        ] {
            let error = resolve_user_with_modules(source, &modules)
                .err()
                .expect("the selected autoimported trait surface is a duplicate");
            assert!(
                error.message.contains("Duplicate import") && error.message.contains("autoimport"),
                "{module_name} {source}: {error:?}"
            );
        }
        for source in [
            "import Domain::ordinary\nvalue = ordinary()",
            "import Domain::{ordinary}\nvalue = ordinary()",
        ] {
            resolve_user_with_modules(source, &modules)
                .expect("ordinary members of a nonautoimport container remain importable");
        }
    }

    let domain = staged_module(
        "Domain",
        parse_module_ast(
            "@autoimport deftrait Metric { def add(self: Self, rhs: Self) -> Self }",
            "Domain",
        ),
    );
    for source in [
        "import Domain::Metric",
        "import Domain::{Metric}",
        "import Domain",
    ] {
        let earlier = staged_module("Earlier", parse_module_ast(source, "Earlier"));
        let error = resolve_user_with_modules("1", &[vec![earlier], vec![domain.clone()]])
            .err()
            .expect("a future-stage trait is not already autoimported");
        assert!(
            error.message.contains("not available in the current stage")
                || error.message.contains("unavailable import members"),
            "{source}: {error:?}"
        );
        assert!(
            !error.message.contains("Duplicate import"),
            "{source}: {error:?}"
        );
    }
}

#[test]
fn autoimport_provenance_does_not_match_only_the_owner_tail() {
    let modules = vec![vec![
        staged_auto_import_module(
            "Global::Domain::Prelude",
            parse_module_ast("def greet() -> Int { 1 }", "Global::Domain::Prelude"),
        ),
        staged_module(
            "Other::Prelude",
            parse_module_ast("def farewell() -> Int { 2 }", "Other::Prelude"),
        ),
    ]];
    resolve_user_with_modules(
        "import Other::Prelude::{farewell}\nvalue = farewell()",
        &modules,
    )
    .expect("an unrelated owner with the same terminal name remains importable");
}

#[test]
fn facet_path_capture_arguments_allow_bracket_data_but_reject_path_placeholders() {
    let declarations = [
        "view",
        "preview",
        "put",
        "set",
        "over",
        "over_result",
        "case_set",
        "case_over",
    ]
    .into_iter()
    .map(|name| format!("@builtin def {name}(facet: $P, source: $S, value: $A) -> $S"))
    .chain(std::iter::once(
        "@builtin def compose(outer: $P, inner: $Q) -> $R".into(),
    ))
    .collect::<Vec<_>>()
    .join("\n");
    let facet = staged_auto_import_module("Facet", parse_module_ast(&declarations, "Facet"));
    for call in [
        "Facet::view(&1, 0)",
        "Facet::view(&1 -> p, &2)",
        "Facet::view(p -> &1, &2)",
        "Facet::put((&1), &2, &3)",
        "Facet::set(&1, &2, &3)",
        "Facet::over(p -> &1, &2, &3)",
        "Facet::case_set(&1, &2, &3)",
        "Facet::case_over(&1, &2, &3)",
        "Facet::compose(&1, p)",
        "Facet::compose(p, &1)",
        "Facet::view((&1).name, &2)",
        "Facet::view((&1).[0], &2)",
        "Facet::view((&1).[&1], &2)",
        "Facet::view(List.[&1] -> &1, &2)",
        "Facet::view(List.[Facet::view(&1, &2)], &3)",
    ] {
        let source = format!("p = Tuple._0\nf = &{call}");
        let error = resolve_user_with_modules(&source, &[vec![facet.clone()]])
            .expect_err("FacetPath argument placeholders must reject by position");
        assert!(
            error
                .message
                .contains("capture placeholders cannot replace a FacetPath or its root"),
            "{call}: {error:?}"
        );
        assert_eq!(
            error.diagnostic.reason,
            crate::error::ResolveErrorReason::Capture
        );
        assert_eq!(&source[error.span.start..error.span.end], "&1", "{call}");
        if call == "Facet::view(List.[&1] -> &1, &2)" {
            assert_eq!(error.span.start, source.rfind("&1").unwrap());
        }
        if call == "Facet::view((&1).[&1], &2)" {
            assert_eq!(error.span.start, source.find("&1").unwrap());
        }
    }
    for source in [
        "p = Tuple._0\nf = &Facet::view(p, &1)",
        "f = &Facet::view(List.[&1], &2)",
        "f = &Facet::view(List.[&1 + 1], &2)",
        "f = &Facet::view(_.[&1], &2)",
        "f = &Facet::view(List.[&1..&2], &3)",
        "f = &Facet::view(HashMap.[&1], &2)",
        "f = &Facet::preview(List.[&1], &2)",
        "f = &Facet::put(List.[&1], &2, &3)",
        "f = &Facet::over_result(List.[&1], &2, &3)",
        "p = Tuple._0\nf = &Facet::view(Facet::compose(p, List.[&1]), &2)",
        "p = Tuple._0\nf = &Facet::compose(p, List.[&1])",
        "p = Tuple._0\nf = &Facet::put(p, &1, &2)",
        "def view(path: Int, source: Int) -> Int { path }\nf = &view(&1, &2)",
        "def compose(outer: Int, inner: Int) -> Int { outer }\nf = &compose(&1, &2)",
    ] {
        resolve_user_with_modules(source, &[vec![facet.clone()]]).expect(
            "bracket data, source/value placeholders and shadowed ordinary callables remain valid",
        );
    }
}

#[test]
fn statement_question_retains_constraint_and_resolves_captured_rhs() {
    let resolved = parse_and_resolve("operation = {|| ()}\ncall = {|| operation()?; ()}")
        .expect("question statement should resolve");
    let Resolved::Bind(_, ResolvedPattern::Var(operation), _) = &resolved[0] else {
        panic!("operation binding");
    };
    let Resolved::Bind(_, _, rhs) = &resolved[1] else {
        panic!("closure binding");
    };
    let Resolved::Closure(_, _, captures, body) = rhs.as_ref() else {
        panic!("closure");
    };
    assert!(captures
        .iter()
        .any(|capture| capture.unique_id == operation.unique_id));
    let Resolved::Block(_, statements) = body.as_ref() else {
        panic!("closure block");
    };
    let Resolved::Semi(_, node) = &statements[0] else {
        panic!("semicolon statement");
    };
    let Resolved::StatementQuestion(_, rhs) = node.as_ref() else {
        panic!("must retain the question constraint before Scar");
    };
    let Resolved::App(_, target, _) = rhs.as_ref() else {
        panic!("call");
    };
    assert!(matches!(target.as_ref(), Resolved::Var(_, id) if id.unique_id == operation.unique_id));
}

#[test]
fn statement_question_retains_do_local_statement_and_semicolon() {
    for source in [
        "operation = {|| ()}\nresult = do::<Result> { operation()?\n () }",
        "operation = {|| ()}\nresult = do::<Result> { operation()?; () }",
    ] {
        let resolved = parse_and_resolve(source).expect("do question statement should resolve");
        let Resolved::Bind(_, _, rhs) = &resolved[1] else {
            panic!("result binding");
        };
        let Resolved::Do(_, _, _, _, statements) = rhs.as_ref() else {
            panic!("do");
        };
        let ResolvedDoStatement::Statement(node) = &statements[0] else {
            panic!("ordinary do statement");
        };
        let node = match node {
            Resolved::Semi(_, node) => node.as_ref(),
            node => node,
        };
        assert!(matches!(node, Resolved::StatementQuestion(..)));
    }
}

#[test]
fn named_infix_requires_selected_function_declaration() {
    for source in [
        "combine = {|a: Int, b: Int| a + b}\n2 `combine` 3",
        "def add(a: Int, b: Int) -> Int { a + b }\ncombine = &add\n2 `combine` 3",
        "def combine(a: Int, b: Int) -> Int { a + b }\ncombine = {|a: Int, b: Int| a - b}\n2 `combine` 3",
        "def apply(combine: (Int, Int -> Int)) -> Int { 2 `combine` 3 }",
        "combine = 5\n2 `combine` 3",
    ] {
        let error = parse_and_resolve(source).expect_err(source);
        assert!(error.message.contains("Named infix requires a function declaration"), "{error:?}");
    }
    for source in [
        "def combine(a: Int, b: Int) -> Int { a + b }\n2 `combine` 3",
        "combine = {|a: Int, b: Int| a + b}\ncombine(2, 3)",
        "combine = {|a: Int, b: Int| a + b}\n`combine`(2, 3)",
    ] {
        parse_and_resolve(source).expect(source);
    }
}

#[test]
fn reserved_callable_declarations_require_standard_identity() {
    for kind in sindr::names::ReservedCallName::ALL {
        for source in [
            format!("def {}(a: Int, b: Int) -> Int {{ a + b }}", kind.name()),
            format!("deftrait Custom {{ def {}(self: Self, other: Self) -> Boolean }}", kind.name()),
            format!("defstruct Custom {{ value: Int }}\nimpl Custom {{ def {}(self: Custom) -> Int {{ 1 }} }}", kind.name()),
        ] {
            let error = parse_and_resolve(&source).expect_err(&source);
            assert!(error.message.contains("reserved for its standard declaration"), "{error:?}");
        }
    }
    for kind in sindr::names::ReservedCallName::ALL {
        let source = format!(
            "defmod Custom {{ def {}(a: Int, b: Int) -> Int {{ a + b }} }}",
            kind.name()
        );
        let ast = spire::parse_with_context(&source, spire::ParserContext::project(0)).unwrap();
        let stages = vec![staged_modules_from_source_ast(ast, None)];
        let error = precollect_declaration_index(&stages).expect_err(&source);
        assert!(
            error
                .message
                .contains("reserved for its standard declaration"),
            "{error:?}"
        );
    }
    parse_and_resolve("defstruct Item { value: Int }\nimpl Eq for Item { def eq(self: Item, other: Item) -> Boolean { True } }").expect("canonical trait implementation remains available");
}

#[test]
fn named_infix_imports_and_qualified_declarations_keep_identity() {
    let stages = vec![vec![staged_module(
        "Combiner",
        parse_module_ast(
            "def combine(left: Int, right: Int) -> Int { left + right }",
            "Combiner",
        ),
    )]];
    for source in [
        "2 `Combiner::combine` 3",
        "import Combiner::combine\n2 `combine` 3",
    ] {
        resolve_user_with_modules(source, &stages).expect(source);
    }
}

#[test]
fn reserved_standard_compare_implementation_and_infix_logic_are_preserved() {
    parse_and_resolve("defstruct Item { value: Int }\nimpl Compare for Item { def compare(self: Item, other: Item) -> Ordering { Ordering::Equal }\n def lt(self: Item, other: Item) -> Boolean { False } }")
        .expect("standard Compare methods can be implemented");
    for source in [
        "True `and` False",
        "True `Kernel::and` False",
        "False `or` True",
        "False `Kernel::or` True",
    ] {
        let resolved = parse_and_resolve(source).expect(source);
        assert!(
            matches!(&resolved[0], Resolved::If(..)),
            "{source}: {resolved:?}"
        );
    }
    let error = parse_and_resolve("deftrait Custom { def choose(self: Self) -> Boolean }\ndefstruct Item { value: Int }\nimpl Custom for Item { def eq(self: Item, other: Item) -> Boolean { True } }")
        .expect_err("a method spelling cannot grant a custom trait the standard contract");
    assert!(
        error
            .message
            .contains("reserved for its standard declaration"),
        "{error:?}"
    );
}

#[test]
fn named_infix_keeps_undefined_callable_diagnostic() {
    let error = parse_and_resolve("1 `missing_combine` 2").expect_err("missing declaration");
    assert_eq!(error.message, "Undefined function missing_combine/2");
}

#[test]
fn pattern_consumer_builtin_declarations_require_kernel_identity() {
    for consumer in sindr::pattern::PatternConsumer::ALL {
        for owner in ["Regex", "Custom", "Nested::Kernel"] {
            let source = format!(
                "@builtin def {}(value: $A, pattern: $Pattern) -> Boolean",
                consumer.name()
            );
            let stages = vec![vec![staged_module(owner, parse_module_ast(&source, owner))]];
            let error = precollect_declaration_index(&stages).expect_err(owner);
            assert!(
                error
                    .message
                    .contains("reserved for the canonical Kernel consumer"),
                "{owner}: {error:?}"
            );
        }
    }
    precollect_declaration_index(&[vec![kernel_pattern_test_module()]])
        .expect("canonical consumer declarations remain available");
}

#[test]
fn child_resolvers_share_read_only_declaration_metadata() {
    let mut resolver = Resolver::new();
    resolver.declaration_hidden_by_uid = HashMap::from([(17, true)]).into();
    resolver.owner_registry = standard_test_environment().owner_registry.clone().into();
    resolver.current_stage_impl_targets = Some(
        HashMap::from([(
            "Marker".to_string(),
            declarations::ImplTargetResolution::Unique(DeclarationKind::Struct),
        )])
        .into(),
    );
    let hidden = std::ptr::from_ref(resolver.declaration_hidden_by_uid.get(&17).unwrap());
    let owner = std::ptr::from_ref(resolver.owner_registry.get("Int").unwrap());
    let target = std::ptr::from_ref(
        resolver
            .current_stage_impl_targets
            .as_ref()
            .unwrap()
            .get("Marker")
            .unwrap(),
    );
    resolver
        .with_child_scope(|child| {
            assert_eq!(
                std::ptr::from_ref(child.declaration_hidden_by_uid.get(&17).unwrap()),
                hidden
            );
            assert_eq!(
                std::ptr::from_ref(child.owner_registry.get("Int").unwrap()),
                owner
            );
            assert_eq!(
                std::ptr::from_ref(
                    child
                        .current_stage_impl_targets
                        .as_ref()
                        .unwrap()
                        .get("Marker")
                        .unwrap()
                ),
                target
            );
            Ok(())
        })
        .unwrap();
}

#[test]
fn parallel_stage_resolution_preserves_order_visibility_and_unique_local_ids() {
    let modules = (0..16).map(|index| {
        let next = (index + 1) % 16;
        let name = format!("Stage{index}");
        let source = format!("import Stage{next}::item{next}\ndef item{index}() -> Int {{\n  local = item{next}()\n  local\n}}");
        staged_module(&name, parse_module_ast(&source, &name))
    }).collect::<Vec<_>>();
    let resolved = resolve_user_with_modules("", &[modules.clone()]).unwrap();
    let definitions = resolved
        .iter()
        .filter_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) if id.name.starts_with("item") => {
                Some((id.name.clone(), first_bind_id(body).unwrap()))
            }
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(
        definitions
            .iter()
            .map(|(name, _)| name.clone())
            .collect::<Vec<_>>(),
        (0..16)
            .map(|index| format!("item{index}"))
            .collect::<Vec<_>>()
    );
    assert_eq!(
        definitions
            .iter()
            .map(|(_, id)| *id)
            .collect::<HashSet<_>>()
            .len(),
        16
    );

    let error =
        resolve_user_with_modules("", &[modules[..8].to_vec(), modules[8..].to_vec()]).unwrap_err();
    assert!(error.message.contains("Stage8::item8"), "{error:?}");
}

#[test]
fn child_scope_preserves_parent_bindings_and_id_commit_rules() {
    let mut resolver = Resolver::new();
    let span = Span { start: 0, end: 1 };
    let outer_id = resolver.scope.define("outer", span.clone());
    let initial_next = resolver.scope.next_id();
    let error = resolver
        .with_child_scope(|child| {
            child.scope.define("outer", span.clone());
            child.reserve_declaration_uid("Child::failed");
            child.resolve_node(Ast::Var(span.clone(), "unknown_child_name".into()))
        })
        .unwrap_err();
    assert!(error.message.contains("unknown_child_name"));
    assert_eq!(resolver.scope.lookup("outer"), Some(outer_id));
    assert_eq!(resolver.scope.next_id(), initial_next);
    assert!(!resolver.declaration_uids.contains_key("Child::failed"));

    let child_id = resolver
        .with_child_scope(|child| {
            let id = child.scope.define("outer", span.clone());
            child.reserve_declaration_uid("Child::success");
            assert_eq!(child.scope.lookup("outer"), Some(id));
            Ok(id)
        })
        .unwrap();
    assert_eq!(child_id, initial_next);
    assert_eq!(resolver.scope.lookup("outer"), Some(outer_id));
    assert_eq!(resolver.scope.next_id(), initial_next + 2);
    assert!(!resolver.declaration_uids.contains_key("Child::success"));
}

#[test]
fn child_resolvers_share_unchanged_declaration_metadata() {
    let mut resolver = Resolver::new();
    let entry = standard_test_environment()
        .declaration_index
        .values()
        .next()
        .unwrap()
        .clone();
    resolver.declaration_entries = HashMap::from([("Marker".into(), entry)]).into();
    resolver.declaration_uids = HashMap::from([("Marker".into(), 17)]).into();
    resolver.declaration_uid_kinds = HashMap::from([(17, DeclarationKind::Def)]).into();
    resolver.trait_constructor_slots = HashMap::from([(17, vec!["A".into()])]).into();
    let entry = std::ptr::from_ref(resolver.declaration_entries.get("Marker").unwrap());
    let uid = std::ptr::from_ref(resolver.declaration_uids.get("Marker").unwrap());
    let kind = std::ptr::from_ref(resolver.declaration_uid_kinds.get(&17).unwrap());
    let slots = std::ptr::from_ref(resolver.trait_constructor_slots.get(&17).unwrap());
    resolver
        .with_child_scope(|child| {
            assert_eq!(
                std::ptr::from_ref(child.declaration_entries.get("Marker").unwrap()),
                entry
            );
            assert_eq!(
                std::ptr::from_ref(child.declaration_uids.get("Marker").unwrap()),
                uid
            );
            assert_eq!(
                std::ptr::from_ref(child.declaration_uid_kinds.get(&17).unwrap()),
                kind
            );
            assert_eq!(
                std::ptr::from_ref(child.trait_constructor_slots.get(&17).unwrap()),
                slots
            );
            child.reserve_declaration_uid("Child::new");
            assert_eq!(child.declaration_uids.get("Marker"), Some(&17));
            Ok(())
        })
        .unwrap();
    assert!(!resolver.declaration_uids.contains_key("Child::new"));
}

#[test]
fn test_deferror_self_resolves_to_its_declaration_identity() {
    let resolved = parse_and_resolve(
        r#"deferror Trouble(code: Int) { |input: Int| Self(message: "trouble", code: input) }"#,
    )
    .unwrap();
    let Resolved::DeferrorDef(_, definition, _, block) = &resolved[0] else {
        panic!("expected Error declaration")
    };
    let Resolved::Closure(_, _, _, body) = block.as_ref() else {
        panic!("expected constructor block")
    };
    let constructor = match body.as_ref() {
        Resolved::ConstructorCall(_, constructor, _) => constructor,
        Resolved::Block(_, statements) => match statements.last().unwrap() {
            Resolved::ConstructorCall(_, constructor, _) => constructor,
            other => panic!("expected internal construction, got {other:?}"),
        },
        other => panic!("expected body, got {other:?}"),
    };
    assert_eq!(constructor.unique_id, definition.unique_id);
    assert_eq!(constructor.qualified_name, definition.qualified_name);
}

#[test]
fn inherent_impl_sibling_calls_share_script_and_module_scope() {
    let source = r#"defstruct User { age: Int }
impl User {
  def first(self: Self) -> Int { second(self) }
  def second(self: Self) -> Int { self.age }
  def shadow(self: Self, second: (User -> Int)) -> Int { second(self) }
}"#;
    let nodes = resolve(parse(source).unwrap()).expect("script impl siblings resolve");
    let first = nodes
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, _, _, _, _, body, _) if id.name == "Global::User::first" => {
                Some(body)
            }
            _ => None,
        })
        .unwrap();
    let second_uid = nodes
        .iter()
        .find_map(|node| match node {
            Resolved::Def(_, id, ..) if id.name == "Global::User::second" => Some(id.unique_id),
            _ => None,
        })
        .unwrap();
    let Resolved::Block(_, body) = first.as_ref() else {
        panic!("expected body block")
    };
    let Resolved::App(_, callee, _) = &body[0] else {
        panic!("expected call: {first:?}")
    };
    let Resolved::Var(_, callee) = callee.as_ref() else {
        panic!("expected function: {callee:?}")
    };
    assert_eq!(callee.unique_id, second_uid);
    let module_stages = vec![staged_modules_from_source_ast(parse(source).unwrap(), None)];
    resolve_user_with_modules("", &module_stages).expect("module impl siblings resolve");
    let outside = format!("{source}\ndef outside(user: User) -> Int {{ second(user) }}");
    assert!(resolve(parse(&outside).unwrap())
        .unwrap_err()
        .message
        .contains("Undefined function second/1"));
}

#[test]
fn hashmap_pattern_keys_keep_outer_binding_identity() {
    let resolved = parse_and_resolve("key = \"a\"\nmap = hash![\"a\" => 1]\nmatch map { hash![\"a\" => key, key => x, ^key => _] => x, _ => 0 }").unwrap();
    let Resolved::Bind(_, ResolvedPattern::Var(outer), _) = &resolved[0] else {
        panic!("outer binding")
    };
    let Resolved::Match(_, _, arms) = resolved.last().unwrap() else {
        panic!("match")
    };
    let ResolvedPattern::HashMap(_, entries) = arms[0].pattern.unlocated() else {
        panic!("HashMap")
    };
    let ResolvedPattern::Var(shadow) = &entries[0].1 else {
        panic!("shadow binding")
    };
    assert_ne!(shadow.unique_id, outer.unique_id);
    for (key, _) in &entries[1..] {
        assert!(matches!(key, Resolved::Var(_, id) if id.unique_id == outer.unique_id));
    }
}

#[test]
fn hashmap_pattern_keys_cannot_reference_new_bindings() {
    for key in ["key", "^key"] {
        let source = format!(
            "map = hash![\"a\" => 1]\nmatch map {{ hash![\"a\" => key, {key} => _] => 0, _ => 1 }}"
        );
        assert!(parse_and_resolve(&source).is_err());
    }
    let error = parse_and_resolve(
        "map = hash![\"a\" => 1]\nmatch map { hash![\"a\" => x, \"b\" => x] => 0, _ => 1 }",
    )
    .unwrap_err();
    assert!(error.message.contains("Duplicate"), "{}", error.message);
}

#[test]
fn source_reflections_require_canonical_and_unique_builtin_declarations() {
    let parse_std = |source| {
        spire::parse_with_context(
            source,
            spire::ParserContext::module(0, None).with_rules(spire::ParseRules::std_module()),
        )
        .unwrap()
    };
    for (owner, source, expected) in [
        (
            "Other",
            "@builtin def __FILE__() -> String",
            "canonical Bootstrap",
        ),
        (
            "Bootstrap",
            "@builtin def __LINE__() -> Int\n@builtin def __LINE__() -> Int",
            "Duplicate builtin reflection function",
        ),
    ] {
        let stages = vec![vec![staged_module(owner, parse_std(source))]];
        let error = precollect_declarations(&stages).expect_err("invalid builtin declaration");
        assert!(error.message.contains(expected), "{}", error.message);
    }
    let error =
        resolve(spire::parse("__LINE__").unwrap()).expect_err("source context must be supplied");
    assert!(error.message.contains("not materialized"));
}

#[test]
fn bare_deferror_is_a_kind_and_capture_stays_a_constructor_reference() {
    let resolved = parse_and_resolve(
        "deferror Trouble(code: Int) { |code: Int| Self(message: \"trouble\", code: code) }\nkind = Trouble\nerror = Trouble(1)\nfactory = &Trouble\npath = Trouble.code",
    ).expect("canonical deferror roles should resolve");
    assert!(
        matches!(&resolved[1], Resolved::Bind(_, _, rhs) if matches!(rhs.as_ref(), Resolved::ErrorKind(_, id) if id.qualified_name.as_deref() == Some("Global::Trouble")))
    );
    assert!(
        matches!(&resolved[2], Resolved::Bind(_, _, rhs) if matches!(rhs.as_ref(), Resolved::ConstructorCall(..)))
    );
    assert!(
        matches!(&resolved[3], Resolved::Bind(_, _, rhs) if matches!(rhs.as_ref(), Resolved::Capture(_, target, _) if matches!(target.as_ref(), Resolved::Var(..))))
    );
    assert!(
        matches!(&resolved[4], Resolved::Bind(_, _, rhs) if matches!(rhs.as_ref(), Resolved::FieldAccess(_, target, _) if matches!(target.as_ref(), Resolved::Var(..))))
    );
}

#[test]
fn qualified_bare_deferror_is_a_kind_without_nullary_constructor_lowering() {
    let modules = vec![vec![staged_module(
        "Failures",
        parse_module_ast(
            "deferror Trouble(code: Int) { |code: Int| Self(message: \"trouble\", code: code) }",
            "Failures",
        ),
    )]];
    let resolved = resolve_user_with_modules(
        "kind = Global::Trouble\nfactory = &Global::Trouble\npath = Global::Trouble.code",
        &modules,
    )
    .expect("qualified deferror roles should resolve");
    for node in &resolved {
        if let Resolved::Bind(_, ResolvedPattern::Var(id), rhs) = node {
            if id.name == "kind" {
                assert!(
                    matches!(rhs.as_ref(), Resolved::ErrorKind(_, id) if id.qualified_name.as_deref() == Some("Global::Trouble"))
                );
            }
        }
    }
}

#[test]
fn ordinary_lazy_calls_retain_selected_declaration_identity() {
    let mut stages = vec![vec![staged_module(
        "Result",
        parse_module_ast(
            "def or_else(value: Result<$T>, next: Lazy<Result<$T>>) -> Result<$T> { value }",
            "Result",
        ),
    )]];
    stages[0][0].auto_import = false;
    for source in [
        "Result::or_else(1, (2))",
        "import Result::or_else\nor_else(1, (2))",
    ] {
        let nodes = resolve_user_with_modules(source, &stages).expect(source);
        let Resolved::LazyApp(_, LazyCaptureKind::OrElse, callee, args) = nodes.last().unwrap()
        else {
            panic!("expected ordinary canonical Lazy call: {nodes:?}");
        };
        assert!(
            matches!(callee.as_ref(), Resolved::Var(_, id) if id.qualified_name.as_deref().is_some_and(|name| global_surface_name(name) == "Result::or_else"))
        );
        assert!(matches!(&args[1], Resolved::Grouped(..)));
    }
}

#[test]
fn ordinary_lazy_declaration_metadata_checks_eager_capture_scope() {
    let mut stages = vec![vec![staged_module(
        "Kernel",
        parse_module_ast(
            "def lazy_probe(value: Lazy<Int>) -> Int { value() }",
            "Kernel",
        ),
    )]];
    stages[0][0].auto_import = false;
    for source in [
        "f = &Kernel::lazy_probe((&1 + 1))",
        "import Kernel::lazy_probe\nf = &lazy_probe((&1 + 1))",
    ] {
        let error = resolve_user_with_modules(source, &stages).expect_err(source);
        assert!(
            error
                .message
                .contains("capture placeholder is not available in a Lazy eager expression"),
            "{source}: {error:?}"
        );
    }
    resolve_user_with_modules("f = &Kernel::lazy_probe((&1))", &stages)
        .expect("grouped direct placeholder keeps its Lazy role");
}

#[test]
fn ordinary_lazy_declaration_metadata_survives_function_body_scope() {
    let stages = vec![vec![staged_module(
        "Kernel",
        parse_module_ast("def lazy_probe(value: Lazy<Int>) -> Int { value() }\ndef make_probe() -> (Int -> Int) { &lazy_probe((&1 + 1)) }", "Kernel"),
    )]];
    let error = resolve_user_with_modules("Kernel::make_probe()", &stages)
        .expect_err("eager checks must remain in function bodies");
    assert!(
        error
            .message
            .contains("capture placeholder is not available in a Lazy eager expression"),
        "{error:?}"
    );
}

#[test]
fn ordinary_lazy_declaration_identity_rejects_bare_capture() {
    let stages = vec![vec![staged_module(
        "Kernel",
        parse_module_ast(
            "def lazy_probe(value: Lazy<Int>) -> Int { value() }",
            "Kernel",
        ),
    )]];
    let error = resolve_user_with_modules("f = &Kernel::lazy_probe", &stages)
        .expect_err("bare capture would erase the declaration Lazy contract");
    assert!(
        error
            .message
            .contains("has Lazy arguments and cannot be captured without explicit arguments"),
        "{error:?}"
    );
}
