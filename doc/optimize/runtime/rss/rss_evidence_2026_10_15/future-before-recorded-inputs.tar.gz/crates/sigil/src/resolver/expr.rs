use super::captures::collect_captures;
use super::declarations::{ast_ty_key, trait_instance_key};
use super::scope_init::{
    is_doc_only_builtin_decl, is_runtime_builtin_decl, is_special_form_builtin_decl,
    resolve_decl_attrs,
};
use super::special_forms::{IfKind, LogicKind};
use super::*;
use sindr::names::{surface_path_name, ConstructorCapturePolicy, TypeIdentity};
use spire::ast::{
    AstPath, BinOp, BulkUpdateEntry, BulkUpdateEntryKind, BulkUpdatePath, DbgArg, FacetPathSegment,
    HashMapLiteralEntry, InterpolatedPart,
};

// Pattern candidates may contain Expr pre-arguments even when their enclosing
// syntax has no Expr interpretation (for example an annotated projection).
pub(super) fn visit_pattern_expressions(
    pattern: &AstPattern,
    visit: &mut impl FnMut(&Ast) -> Result<(), ResolveError>,
) -> Result<(), ResolveError> {
    match pattern {
        AstPattern::HashMap(_, entries) => {
            for (key, child) in entries {
                visit(key)?;
                visit_pattern_expressions(child, visit)?;
            }
        }
        AstPattern::Call(_, _, args) => {
            for arg in args {
                if let Some(expr) = &arg.expression {
                    visit(expr)?;
                }
                if let Some(pattern) = &arg.pattern {
                    visit_pattern_expressions(pattern, visit)?;
                }
            }
        }
        AstPattern::Projection { inner, .. } | AstPattern::As(_, inner, ..) => {
            visit_pattern_expressions(inner, visit)?
        }
        AstPattern::Constructor(_, _, children)
        | AstPattern::Tuple(_, children)
        | AstPattern::Or(_, children) => {
            for child in children {
                visit_pattern_expressions(child, visit)?;
            }
        }
        AstPattern::ListCons(_, head, tail) => {
            visit_pattern_expressions(head, visit)?;
            visit_pattern_expressions(tail, visit)?;
        }
        _ => {}
    }
    Ok(())
}

fn rewrite_pattern_expressions(
    pattern: &mut AstPattern,
    rewrite: &mut impl FnMut(Ast) -> Result<Ast, ResolveError>,
) -> Result<(), ResolveError> {
    match pattern {
        AstPattern::HashMap(_, entries) => {
            for (key, child) in entries {
                *key = rewrite(key.clone())?;
                rewrite_pattern_expressions(child, rewrite)?;
            }
        }
        AstPattern::Call(_, _, args) => {
            for arg in args {
                if let Some(expr) = arg.expression.take() {
                    arg.expression = Some(Box::new(rewrite(*expr)?));
                }
                if let Some(pattern) = &mut arg.pattern {
                    rewrite_pattern_expressions(pattern, rewrite)?;
                }
            }
        }
        AstPattern::Projection { inner, .. } | AstPattern::As(_, inner, ..) => {
            rewrite_pattern_expressions(inner, rewrite)?
        }
        AstPattern::Constructor(_, _, children)
        | AstPattern::Tuple(_, children)
        | AstPattern::Or(_, children) => {
            for child in children {
                rewrite_pattern_expressions(child, rewrite)?;
            }
        }
        AstPattern::ListCons(_, head, tail) => {
            rewrite_pattern_expressions(head, rewrite)?;
            rewrite_pattern_expressions(tail, rewrite)?;
        }
        _ => {}
    }
    Ok(())
}

const TUPLE_TYPE_ROOT_UID: u32 = u32::MAX - 7;
const LIST_TYPE_ROOT_UID: u32 = u32::MAX - 8;
const HASH_MAP_TYPE_ROOT_UID: u32 = u32::MAX - 9;
const STRING_PRIMITIVE_ROOT_UID: u32 = u32::MAX - 10;
const INT_PRIMITIVE_ROOT_UID: u32 = u32::MAX - 11;
const FLOAT_PRIMITIVE_ROOT_UID: u32 = u32::MAX - 12;
const BOOLEAN_PRIMITIVE_ROOT_UID: u32 = u32::MAX - 13;
const FUNCTION_PRIMITIVE_ROOT_UID: u32 = u32::MAX - 14;
const ERROR_TYPE_ROOT_UID: u32 = u32::MAX - 15;

fn ast_ty_owner_head(ty: &AstTy) -> Option<&str> {
    match ty {
        AstTy::Named(_, name) | AstTy::ImplTrait(_, name) | AstTy::Generic(_, name, _) => {
            Some(name)
        }
        AstTy::Tuple(..) | AstTy::Func(..) => None,
    }
}

fn do_pattern_span(pattern: &AstPattern) -> Span {
    match pattern {
        AstPattern::Projection { span, .. } => span.clone(),
        AstPattern::Annotated(span, _, ty) | AstPattern::AnnotatedWildcard(span, ty) => Span {
            start: span.start,
            end: match ty {
                AstTy::Named(ty_span, _)
                | AstTy::ImplTrait(ty_span, _)
                | AstTy::Generic(ty_span, _, _)
                | AstTy::Tuple(ty_span, _)
                | AstTy::Func(ty_span, _, _) => ty_span.end,
            },
        },
        AstPattern::Var(span, _)
        | AstPattern::Pin(span, _)
        | AstPattern::Wildcard(span)
        | AstPattern::HashMap(span, _)
        | AstPattern::ListNil(span)
        | AstPattern::ListCons(span, _, _)
        | AstPattern::IntLit(span, _)
        | AstPattern::StrLit(span, _)
        | AstPattern::BoolLit(span, _)
        | AstPattern::DurationLit(span, _)
        | AstPattern::Constructor(span, _, _)
        | AstPattern::Call(span, _, _)
        | AstPattern::Tuple(span, _)
        | AstPattern::Or(span, _)
        | AstPattern::As(span, _, _, _, _) => span.clone(),
    }
}

fn synthetic_builtin_symbol_uid(name: &str, info: &SymbolIdentityInfo) -> Option<u32> {
    let name = global_surface_name(name);
    match (name, info.capabilities.facet_root_path) {
        ("Tuple", Some(FacetRootKind::Tuple)) => Some(TUPLE_TYPE_ROOT_UID),
        ("List", Some(FacetRootKind::List)) => Some(LIST_TYPE_ROOT_UID),
        ("HashMap", Some(FacetRootKind::HashMap)) => Some(HASH_MAP_TYPE_ROOT_UID),
        ("String", None) if info.capabilities.module_owner => Some(STRING_PRIMITIVE_ROOT_UID),
        ("Int", None) if info.capabilities.module_owner => Some(INT_PRIMITIVE_ROOT_UID),
        ("Float", None) if info.capabilities.module_owner => Some(FLOAT_PRIMITIVE_ROOT_UID),
        ("Boolean", Some(FacetRootKind::TypeRoot)) if info.capabilities.module_owner => {
            Some(BOOLEAN_PRIMITIVE_ROOT_UID)
        }
        ("Function", None) if info.capabilities.module_owner => Some(FUNCTION_PRIMITIVE_ROOT_UID),
        ("Error", Some(FacetRootKind::TypeRoot)) if info.capabilities.module_owner => {
            Some(ERROR_TYPE_ROOT_UID)
        }
        _ => None,
    }
}

fn synthetic_facet_root_uid(name: &str) -> Option<u32> {
    let info = builtin_symbol_identity_info(name)?;
    info.capabilities.facet_root_path?;
    synthetic_builtin_symbol_uid(name, &info)
}

fn synthetic_member_root(name: &str) -> Option<(u32, SymbolIdentityInfo)> {
    let info = builtin_symbol_identity_info(name)?;
    if !info.capabilities.module_owner {
        return None;
    }
    synthetic_builtin_symbol_uid(name, &info).map(|uid| (uid, info))
}

fn is_synthetic_builtin_symbol_uid(uid: u32) -> bool {
    matches!(
        uid,
        TUPLE_TYPE_ROOT_UID
            | LIST_TYPE_ROOT_UID
            | HASH_MAP_TYPE_ROOT_UID
            | STRING_PRIMITIVE_ROOT_UID
            | INT_PRIMITIVE_ROOT_UID
            | FLOAT_PRIMITIVE_ROOT_UID
            | BOOLEAN_PRIMITIVE_ROOT_UID
            | FUNCTION_PRIMITIVE_ROOT_UID
            | ERROR_TYPE_ROOT_UID
    )
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum CanonicalSpecialForm {
    If(IfKind),
    Require,
    Ensure,
    MapErr,
    Cause,
    OrElse,
    Logic(LogicKind),
}

impl Resolver {
    fn canonical_special_form_from_qname(qualified_name: &str) -> Option<CanonicalSpecialForm> {
        match global_surface_name(qualified_name) {
            "Kernel::if" => Some(CanonicalSpecialForm::If(IfKind::If3)),
            "Kernel::if_then" => Some(CanonicalSpecialForm::If(IfKind::IfThen2)),
            "Kernel::require" => Some(CanonicalSpecialForm::Require),
            "Kernel::ensure" => Some(CanonicalSpecialForm::Ensure),
            "Kernel::and" => Some(CanonicalSpecialForm::Logic(LogicKind::And)),
            "Kernel::or" => Some(CanonicalSpecialForm::Logic(LogicKind::Or)),
            "Result::map_err" => Some(CanonicalSpecialForm::MapErr),
            "Result::cause" => Some(CanonicalSpecialForm::Cause),
            "Result::or_else" => Some(CanonicalSpecialForm::OrElse),
            _ => None,
        }
    }

    pub(super) fn classify_canonical_special_form_callee(
        &self,
        resolved_func: &Resolved,
    ) -> Option<CanonicalSpecialForm> {
        let selected = match resolved_func {
            Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
            other => other,
        };
        let Resolved::Var(_, id) = selected else {
            return None;
        };
        // The resolver stamps the selected declaration identity onto the callee.
        // Generated closures retain it even when they do not carry a declaration registry.
        Self::canonical_special_form_from_qname(id.qualified_name.as_deref()?)
    }

    fn resolve_canonical_special_form_call(
        &mut self,
        span: Span,
        args: Vec<RecordLitArg>,
        kind: CanonicalSpecialForm,
        func: Resolved,
    ) -> Result<Resolved, ResolveError> {
        match kind {
            CanonicalSpecialForm::If(IfKind::If3) => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::If)
            }
            CanonicalSpecialForm::If(IfKind::IfThen2) => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::IfThen)
            }
            CanonicalSpecialForm::Require => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::Require)
            }
            CanonicalSpecialForm::Ensure => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::Ensure)
            }
            CanonicalSpecialForm::MapErr => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::MapErr)
            }
            CanonicalSpecialForm::Cause => self.resolve_cause(span, args),
            CanonicalSpecialForm::OrElse => {
                self.resolve_lazy_declaration_call(span, func, args, LazyCaptureKind::OrElse)
            }
            CanonicalSpecialForm::Logic(logic_kind) => {
                self.resolve_logic_call(span, args, logic_kind)
            }
        }
    }

    fn capture_placeholder_param_name(span: &Span, index: usize) -> String {
        format!("__cap_{}_{}_{}", span.start, span.end, index)
    }

    pub(super) fn pipe_slot_param_name(span: &Span) -> String {
        format!("__pipe_slot_{}_{}", span.start, span.end)
    }

    fn make_closure_from_call(
        &self,
        span: &Span,
        params: Vec<ClosureParam>,
        func: Ast,
        args: Vec<Ast>,
    ) -> Ast {
        Ast::Closure(
            span.clone(),
            params,
            Box::new(Ast::App(
                span.clone(),
                Box::new(func),
                args.into_iter().map(RecordLitArg::Positional).collect(),
            )),
        )
    }

    fn capture_policy_for_ast_target(
        &self,
        target: &Ast,
    ) -> Option<(ConstructorCapturePolicy, String)> {
        let (name, kind) = match target {
            Ast::Var(_, name) => {
                let uid = self.scope.lookup(name)?;
                (name.clone(), self.declaration_uid_kinds.get(&uid)?)
            }
            Ast::Path(_, path) => {
                let name = path.segments.join("::");
                let uid = self.scope.lookup(&name)?;
                (name, self.declaration_uid_kinds.get(&uid)?)
            }
            Ast::EnumConstructorCall(_, owner, _, _, _) => {
                let owner_ref = self.owner_registry.owner_ref(owner)?;
                let info = super::user_type_symbol_identity_info(&owner_ref)?;
                return info
                    .capabilities
                    .constructor_capture
                    .map(|policy| (policy, owner.clone()));
            }
            _ => return None,
        };
        if !matches!(
            kind,
            DeclarationKind::Struct
                | DeclarationKind::Record
                | DeclarationKind::Deferror
                | DeclarationKind::Enum
                | DeclarationKind::EnumVariant
        ) {
            return None;
        }
        let uid = self.scope.lookup(&name)?;
        let info = self.symbol_info_for_uid(&name, uid)?;
        info.capabilities
            .constructor_capture
            .map(|policy| (policy, name))
    }

    fn lower_constructor_capture_expr(
        &self,
        span: Span,
        target: Ast,
        args: Vec<Ast>,
    ) -> Result<Ast, ResolveError> {
        let max_index = self.validate_capture_placeholders(&span, &args)?;
        let rewritten_args = args
            .into_iter()
            .map(|arg| self.rewrite_capture_placeholders(arg, &span, true, true))
            .collect::<Result<Vec<_>, _>>()?;
        let constructor_args = rewritten_args
            .into_iter()
            .map(RecordLitArg::Positional)
            .collect::<Vec<_>>();
        let body = match target {
            Ast::Var(_, name) => Ast::ConstructorCall(span.clone(), name, constructor_args),
            Ast::Path(_, path) => {
                Ast::ConstructorCall(span.clone(), path.segments.join("::"), constructor_args)
            }
            Ast::EnumConstructorCall(owner_span, owner, type_args, variant, _) => {
                Ast::EnumConstructorCall(owner_span, owner, type_args, variant, constructor_args)
            }
            other => {
                return Err(ResolveError {
                    message: "constructor capture target has no nominal constructor identity"
                        .into(),
                    span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::CompilerInvariant,
                        subject: Some(format!("{:?}", other)),
                    },
                    related_labels: Vec::new(),
                })
            }
        };
        let params = (1..=max_index)
            .map(|index| ClosureParam {
                name: Self::capture_placeholder_param_name(&span, index),
                ty: None,
                span: span.clone(),
            })
            .collect();
        Ok(Ast::Closure(span, params, Box::new(body)))
    }

    fn make_operator_capture_body(
        &self,
        span: &Span,
        body: &str,
        left: Ast,
        right: Ast,
    ) -> Result<Ast, ResolveError> {
        if body == "(,)" {
            return Ok(Ast::TupleLiteral(span.clone(), vec![left, right]));
        }
        let op = match body {
            "+" => BinOp::Add,
            "-" => BinOp::Sub,
            "*" => BinOp::Mul,
            "/" => BinOp::Div(span.clone()),
            "%" => BinOp::Mod(span.clone()),
            "++" => BinOp::Concat,
            "==" => BinOp::Eq,
            "!=" => BinOp::Neq,
            "<" => BinOp::Lt,
            ">" => BinOp::Gt,
            "<=" => BinOp::Lte,
            ">=" => BinOp::Gte,
            _ => {
                return Err(ResolveError {
                    message: format!("unsupported operator capture target `{}`", body),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Capture,
                        subject: None,
                    },
                    related_labels: Vec::new(),
                });
            }
        };
        Ok(Ast::BinOp(
            span.clone(),
            op,
            Box::new(left),
            Box::new(right),
        ))
    }

    fn validate_capture_placeholders(
        &self,
        span: &Span,
        args: &[Ast],
    ) -> Result<usize, ResolveError> {
        let mut used = HashSet::new();
        for arg in args {
            self.collect_capture_placeholders(arg, true, true, &mut used)?;
        }
        if used.is_empty() {
            return Err(ResolveError {
                message: "capture call is missing placeholder arguments".into(),
                span: span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::Capture,
                    subject: None,
                },
                related_labels: Vec::new(),
            });
        }

        let Some(max_index) = used.iter().max().copied() else {
            return Err(ResolveError {
                message: "capture call is missing placeholder arguments".into(),
                span: span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::Capture,
                    subject: None,
                },
                related_labels: Vec::new(),
            });
        };
        for index in 1..=max_index {
            if !used.contains(&index) {
                return Err(ResolveError {
                    message: format!("capture placeholder &{} is missing", index),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Capture,
                        subject: None,
                    },
                    related_labels: Vec::new(),
                });
            }
        }
        Ok(max_index)
    }

    fn collect_capture_placeholders(
        &self,
        expr: &Ast,
        allow_placeholders: bool,
        inside_placeholder_capture: bool,
        used: &mut HashSet<usize>,
    ) -> Result<(), ResolveError> {
        fn walk_bulk_entries(
            resolver: &Resolver,
            entries: &[BulkUpdateEntry],
            allow_placeholders: bool,
            inside_placeholder_capture: bool,
            used: &mut HashSet<usize>,
        ) -> Result<(), ResolveError> {
            for entry in entries {
                match &entry.kind {
                    BulkUpdateEntryKind::Set(expr)
                    | BulkUpdateEntryKind::Over(expr)
                    | BulkUpdateEntryKind::OverResult(expr)
                    | BulkUpdateEntryKind::CaseSet(expr)
                    | BulkUpdateEntryKind::CaseOver(expr) => {
                        resolver.collect_capture_placeholders(
                            expr,
                            allow_placeholders,
                            inside_placeholder_capture,
                            used,
                        )?;
                    }
                    BulkUpdateEntryKind::Nested(entries) => walk_bulk_entries(
                        resolver,
                        entries,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?,
                }
            }
            Ok(())
        }

        match expr {
            Ast::NumberedPlaceholder(..) => Ok(()),
            Ast::PatternConsumerCall(_, callee, args) => {
                let kind = match callee.as_ref() {
                    Ast::Var(_, name) => sindr::pattern::PatternConsumer::from_name(name),
                    Ast::Path(_, path)
                        if path.segments.len() == 2 && path.segments[0] == "Kernel" =>
                    {
                        sindr::pattern::PatternConsumer::from_name(&path.segments[1])
                    }
                    _ => None,
                };
                fn direct_placeholder(expression: &Ast) -> bool {
                    match expression {
                        Ast::CapturePlaceholder(..) => true,
                        Ast::Grouped(_, inner) => direct_placeholder(inner),
                        _ => false,
                    }
                }
                if let Some(argument) = kind.and_then(|kind| args.get(kind.pattern_index())) {
                    if argument
                        .expression
                        .as_deref()
                        .is_some_and(direct_placeholder)
                    {
                        return Err(ResolveError {
                            message: "Pattern argument cannot be a capture placeholder".into(),
                            span: argument.span.clone(),
                            related_labels: Vec::new(),
                            diagnostic: crate::error::ResolveErrorDiagnostic {
                                reason: crate::error::ResolveErrorReason::Capture,
                                subject: None,
                            },
                        });
                    }
                }
                self.collect_capture_placeholders(
                    callee,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                for arg in args {
                    let mut visit = |expr: &Ast| {
                        self.collect_capture_placeholders(
                            expr,
                            allow_placeholders,
                            inside_placeholder_capture,
                            used,
                        )
                    };
                    if let Some(expr) = &arg.expression {
                        visit(expr)?;
                    }
                    if let Some(pattern) = &arg.pattern {
                        visit_pattern_expressions(pattern, &mut visit)?;
                    }
                }
                Ok(())
            }
            Ast::CapturePlaceholder(span, index) => {
                if !allow_placeholders {
                    return Err(ResolveError {
                        message: "capture placeholders are only valid in the outer capture body"
                            .into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::Capture,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                }
                used.insert(*index);
                Ok(())
            }
            Ast::App(_, func, args) => {
                self.collect_capture_placeholders(
                    func,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                for arg in args {
                    match arg {
                        RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => {
                            self.collect_capture_placeholders(
                                expr,
                                allow_placeholders,
                                inside_placeholder_capture,
                                used,
                            )?;
                        }
                    }
                }
                Ok(())
            }
            Ast::EnumConstructorCall(_, _, _, _, args) => {
                for arg in args {
                    match arg {
                        RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => {
                            self.collect_capture_placeholders(
                                expr,
                                allow_placeholders,
                                inside_placeholder_capture,
                                used,
                            )?;
                        }
                    }
                }
                Ok(())
            }
            Ast::ReturnTypeArgumentApply(_, target, _) => self.collect_capture_placeholders(
                target,
                allow_placeholders,
                inside_placeholder_capture,
                used,
            ),
            Ast::Do(_, _, statements, _) => {
                for statement in statements {
                    let node = match statement {
                        AstDoStatement::Extract { rhs, .. }
                        | AstDoStatement::SafeBind { rhs, .. } => rhs,
                        AstDoStatement::Statement(statement) => statement,
                    };
                    self.collect_capture_placeholders(
                        node,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::Block(_, stmts) | Ast::ListLiteral(_, stmts) | Ast::TupleLiteral(_, stmts) => {
                for stmt in stmts {
                    self.collect_capture_placeholders(
                        stmt,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::HashMapLiteral(_, entries) => {
                for entry in entries {
                    self.collect_capture_placeholders(
                        &entry.key,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                    self.collect_capture_placeholders(
                        &entry.value,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::RangeLiteral(_, start, stop) => {
                self.collect_capture_placeholders(
                    start,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                self.collect_capture_placeholders(
                    stop,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )
            }
            Ast::Bind(_, _, rhs)
            | Ast::SafeBind(_, _, rhs, _)
            | Ast::StatementQuestion(_, rhs)
            | Ast::Grouped(_, rhs)
            | Ast::Semi(_, rhs)
            | Ast::FieldAccess(_, rhs, _)
            | Ast::FacetCapture(_, rhs) => self.collect_capture_placeholders(
                rhs,
                allow_placeholders,
                inside_placeholder_capture,
                used,
            ),
            Ast::FacetSegmentAccess(_, root, segment) => {
                self.collect_capture_placeholders(
                    root,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                if let FacetPathSegment::Bracket(index) = segment {
                    self.collect_capture_placeholders(
                        &index.expr,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::BinOp(_, _, left, right)
            | Ast::Pipe(_, left, right)
            | Ast::ContextMap(_, left, right)
            | Ast::ContextApply(_, left, right)
            | Ast::ContextBind(_, left, right)
            | Ast::Compose(_, left, right)
            | Ast::LiftedCompose(_, left, right)
            | Ast::KleisliCompose(_, left, right)
            | Ast::ListCons(_, left, right) => {
                self.collect_capture_placeholders(
                    left,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                self.collect_capture_placeholders(
                    right,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )
            }
            Ast::InterpolatedStr(_, parts) => {
                for part in parts {
                    if let InterpolatedPart::Expr(expr) = part {
                        self.collect_capture_placeholders(
                            expr,
                            allow_placeholders,
                            inside_placeholder_capture,
                            used,
                        )?;
                    }
                }
                Ok(())
            }
            Ast::Dbg(_, args) => {
                for arg in args {
                    self.collect_capture_placeholders(
                        &arg.expr,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::Cond(_, clauses) => {
                for (condition, body) in clauses {
                    self.collect_capture_placeholders(
                        condition,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                    self.collect_capture_placeholders(
                        body,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::Match(_, scrutinee, arms) => {
                self.collect_capture_placeholders(
                    scrutinee,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                for arm in arms {
                    if let Some(guard) = &arm.guard {
                        self.collect_capture_placeholders(
                            guard,
                            allow_placeholders,
                            inside_placeholder_capture,
                            used,
                        )?;
                    }
                    self.collect_capture_placeholders(
                        &arm.body,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::BulkUpdate(_, source, entries) => {
                self.collect_capture_placeholders(
                    source,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                walk_bulk_entries(
                    self,
                    entries,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )
            }
            Ast::StructLit(_, _, fields) | Ast::InternalStructLit(_, _, fields) => {
                for field in fields {
                    match field {
                        StructLitField::Explicit(_, expr) => {
                            self.collect_capture_placeholders(
                                expr,
                                allow_placeholders,
                                inside_placeholder_capture,
                                used,
                            )?;
                        }
                        StructLitField::Shorthand(_) => {}
                    }
                }
                Ok(())
            }
            Ast::ConstructorCall(_, _, args) => {
                for arg in args {
                    match arg {
                        RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => {
                            self.collect_capture_placeholders(
                                expr,
                                allow_placeholders,
                                inside_placeholder_capture,
                                used,
                            )?;
                        }
                    }
                }
                Ok(())
            }
            Ast::Closure(_, _, body) | Ast::ExtractorClosure(_, _, body) => {
                self.collect_capture_placeholders(body, false, true, used)
            }
            Ast::Capture(span, target, args) => {
                if inside_placeholder_capture && !args.is_empty() {
                    return Err(ResolveError {
                        message: "outer capture placeholders are only valid in the outer capture body; nested capture argument blocks are not allowed".into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic { reason: crate::error::ResolveErrorReason::Capture, subject: None },
                        related_labels: Vec::new(),
                    });
                }
                self.collect_capture_placeholders(
                    target,
                    allow_placeholders,
                    inside_placeholder_capture,
                    used,
                )?;
                for arg in args {
                    self.collect_capture_placeholders(
                        arg,
                        allow_placeholders,
                        inside_placeholder_capture,
                        used,
                    )?;
                }
                Ok(())
            }
            Ast::Lit(_, _)
            | Ast::Var(_, _)
            | Ast::InternalVar(_, _)
            | Ast::Path(_, _)
            | Ast::FuncLiteralRef(_, _)
            | Ast::NamedInfixRef(_, _)
            | Ast::ListNil(_)
            | Ast::StructDef(..)
            | Ast::RecordDef(..)
            | Ast::DeferrorDef(_, _, _, _, _)
            | Ast::EnumDef(_, _, _, _, _)
            | Ast::Def(..)
            | Ast::ConstDef(_, _, _, _, _)
            | Ast::SupervisorInit(_, _)
            | Ast::ExtractorDef(_, _, _, _, _, _, _)
            | Ast::BuiltinDecl(..)
            | Ast::BuiltinReflectionDecl(..)
            | Ast::Reflection(..)
            | Ast::IntrinsicDecl(_, _, _, _)
            | Ast::BuiltinExtractorDecl(_, _, _, _, _)
            | Ast::BuiltinTypeDecl(_, _, _)
            | Ast::TypeAlias(_, _, _, _)
            | Ast::Defmod(_, _, _, _)
            | Ast::Defagent(_, _, _, _, _)
            | Ast::Defgenserver(_, _, _, _, _)
            | Ast::Defsupervisor(_, _, _, _, _)
            | Ast::DefdynamicSupervisor(_, _, _, _, _)
            | Ast::Namespace(_, _, _)
            | Ast::ImplDef(_, _, _, _, _)
            | Ast::TraitDef(..)
            | Ast::TraitImplDef(..)
            | Ast::Import(_, _, _)
            | Ast::Include(_, _) => Ok(()),
        }
    }

    fn rewrite_capture_placeholders(
        &self,
        expr: Ast,
        capture_span: &Span,
        allow_placeholders: bool,
        inside_placeholder_capture: bool,
    ) -> Result<Ast, ResolveError> {
        match expr {
            Ast::PatternConsumerCall(span, callee, mut args) => {
                let mut rewrite = |expr| {
                    self.rewrite_capture_placeholders(
                        expr,
                        capture_span,
                        allow_placeholders,
                        inside_placeholder_capture,
                    )
                };
                let callee = Box::new(rewrite(*callee)?);
                for arg in &mut args {
                    if let Some(expr) = arg.expression.take() {
                        arg.expression = Some(Box::new(rewrite(*expr)?));
                    }
                    if let Some(pattern) = &mut arg.pattern {
                        rewrite_pattern_expressions(pattern, &mut rewrite)?;
                    }
                }
                Ok(Ast::PatternConsumerCall(span, callee, args))
            }
            Ast::FacetSegmentAccess(span, root, segment) => {
                let root = self.rewrite_capture_placeholders(
                    *root,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?;
                let segment = match segment {
                    FacetPathSegment::Bracket(mut index) => {
                        index.expr = Box::new(self.rewrite_capture_placeholders(
                            *index.expr,
                            capture_span,
                            allow_placeholders,
                            inside_placeholder_capture,
                        )?);
                        FacetPathSegment::Bracket(index)
                    }
                    field => field,
                };
                Ok(Ast::FacetSegmentAccess(span, Box::new(root), segment))
            }
            Ast::FacetCapture(span, root) => Ok(Ast::FacetCapture(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *root,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::CapturePlaceholder(span, index) => {
                if !allow_placeholders {
                    return Err(ResolveError {
                        message: "capture placeholders are only valid in the outer capture body"
                            .into(),
                        span,
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::Capture,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                }
                Ok(Ast::InternalVar(
                    span.clone(),
                    Self::capture_placeholder_param_name(capture_span, index),
                ))
            }
            Ast::App(span, func, args) => Ok(Ast::App(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *func,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                args.into_iter()
                    .map(|arg| match arg {
                        RecordLitArg::Positional(expr) => Ok(RecordLitArg::Positional(
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                        RecordLitArg::Named(name, expr) => Ok(RecordLitArg::Named(
                            name,
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::Block(span, stmts) => Ok(Ast::Block(
                span,
                stmts
                    .into_iter()
                    .map(|stmt| {
                        self.rewrite_capture_placeholders(
                            stmt,
                            capture_span,
                            allow_placeholders,
                            inside_placeholder_capture,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::Do(span, return_type_arguments, statements, keyword_span) => Ok(Ast::Do(
                span,
                return_type_arguments,
                statements
                    .into_iter()
                    .map(|statement| match statement {
                        AstDoStatement::Extract {
                            span,
                            operator_span,
                            pattern,
                            rhs,
                        } => Ok(AstDoStatement::Extract {
                            span,
                            operator_span,
                            pattern,
                            rhs: self.rewrite_capture_placeholders(
                                rhs,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        }),
                        AstDoStatement::SafeBind {
                            span,
                            operator_span,
                            pattern,
                            rhs,
                        } => Ok(AstDoStatement::SafeBind {
                            span,
                            operator_span,
                            pattern,
                            rhs: self.rewrite_capture_placeholders(
                                rhs,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        }),
                        AstDoStatement::Statement(statement) => Ok(AstDoStatement::Statement(
                            self.rewrite_capture_placeholders(
                                statement,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
                keyword_span,
            )),
            Ast::Bind(span, pat, rhs) => Ok(Ast::Bind(
                span,
                pat,
                Box::new(self.rewrite_capture_placeholders(
                    *rhs,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::SafeBind(span, pat, rhs, operator_span) => Ok(Ast::SafeBind(
                span,
                pat,
                Box::new(self.rewrite_capture_placeholders(
                    *rhs,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                operator_span,
            )),
            Ast::StatementQuestion(span, rhs) => Ok(Ast::StatementQuestion(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *rhs,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::BinOp(span, op, left, right) => Ok(Ast::BinOp(
                span,
                op,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::Pipe(span, left, right) => Ok(Ast::Pipe(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::ContextMap(span, left, right) => Ok(Ast::ContextMap(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::ContextBind(span, left, right) => Ok(Ast::ContextBind(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::Compose(span, left, right) => Ok(Ast::Compose(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::LiftedCompose(span, left, right) => Ok(Ast::LiftedCompose(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::KleisliCompose(span, left, right) => Ok(Ast::KleisliCompose(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::ListCons(span, left, right) => Ok(Ast::ListCons(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *left,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *right,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::ListLiteral(span, elems) => Ok(Ast::ListLiteral(
                span,
                elems
                    .into_iter()
                    .map(|elem| {
                        self.rewrite_capture_placeholders(
                            elem,
                            capture_span,
                            allow_placeholders,
                            inside_placeholder_capture,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::HashMapLiteral(span, entries) => Ok(Ast::HashMapLiteral(
                span,
                entries
                    .into_iter()
                    .map(|entry| {
                        Ok(HashMapLiteralEntry {
                            key: self.rewrite_capture_placeholders(
                                entry.key,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                            value: self.rewrite_capture_placeholders(
                                entry.value,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::RangeLiteral(span, start, stop) => Ok(Ast::RangeLiteral(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *start,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                Box::new(self.rewrite_capture_placeholders(
                    *stop,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::TupleLiteral(span, elems) => Ok(Ast::TupleLiteral(
                span,
                elems
                    .into_iter()
                    .map(|elem| {
                        self.rewrite_capture_placeholders(
                            elem,
                            capture_span,
                            allow_placeholders,
                            inside_placeholder_capture,
                        )
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::Grouped(span, inner) => Ok(Ast::Grouped(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *inner,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
            )),
            Ast::InterpolatedStr(span, parts) => Ok(Ast::InterpolatedStr(
                span,
                parts
                    .into_iter()
                    .map(|part| match part {
                        InterpolatedPart::Text(text) => Ok(InterpolatedPart::Text(text)),
                        InterpolatedPart::Expr(expr) => Ok(InterpolatedPart::Expr(Box::new(
                            self.rewrite_capture_placeholders(
                                *expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        ))),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::Dbg(span, args) => Ok(Ast::Dbg(
                span,
                args.into_iter()
                    .map(|arg| {
                        let expr = self.rewrite_capture_placeholders(
                            arg.expr,
                            capture_span,
                            allow_placeholders,
                            inside_placeholder_capture,
                        )?;
                        Ok(DbgArg {
                            span: expr.span().clone(),
                            expr,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::Cond(span, clauses) => Ok(Ast::Cond(
                span,
                clauses
                    .into_iter()
                    .map(|(condition, body)| {
                        Ok((
                            self.rewrite_capture_placeholders(
                                condition,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                            self.rewrite_capture_placeholders(
                                body,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        ))
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::Match(span, scrutinee, arms) => Ok(Ast::Match(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *scrutinee,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                arms.into_iter()
                    .map(|arm| {
                        Ok(AstMatchArm {
                            pattern: arm.pattern,
                            guard: arm
                                .guard
                                .map(|guard| {
                                    self.rewrite_capture_placeholders(
                                        guard,
                                        capture_span,
                                        allow_placeholders,
                                        inside_placeholder_capture,
                                    )
                                })
                                .transpose()?,
                            body: self.rewrite_capture_placeholders(
                                arm.body,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::FieldAccess(span, expr, field) => Ok(Ast::FieldAccess(
                span,
                Box::new(self.rewrite_capture_placeholders(
                    *expr,
                    capture_span,
                    allow_placeholders,
                    inside_placeholder_capture,
                )?),
                field,
            )),
            Ast::StructLit(span, name, fields) => Ok(Ast::StructLit(
                span,
                name,
                fields
                    .into_iter()
                    .map(|field| match field {
                        StructLitField::Explicit(name, expr) => Ok(StructLitField::Explicit(
                            name,
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                        StructLitField::Shorthand(name) => Ok(StructLitField::Shorthand(name)),
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::InternalStructLit(span, name, fields) => Ok(Ast::InternalStructLit(
                span,
                name,
                fields
                    .into_iter()
                    .map(|field| match field {
                        StructLitField::Explicit(name, expr) => Ok(StructLitField::Explicit(
                            name,
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                        StructLitField::Shorthand(name) => Ok(StructLitField::Shorthand(name)),
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::ConstructorCall(span, name, args) => Ok(Ast::ConstructorCall(
                span,
                name,
                args.into_iter()
                    .map(|arg| match arg {
                        RecordLitArg::Positional(expr) => Ok(RecordLitArg::Positional(
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                        RecordLitArg::Named(name, expr) => Ok(RecordLitArg::Named(
                            name,
                            self.rewrite_capture_placeholders(
                                expr,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )?,
                        )),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
            )),
            Ast::EnumConstructorCall(span, owner, type_args, variant, args) => {
                Ok(Ast::EnumConstructorCall(
                    span,
                    owner,
                    type_args,
                    variant,
                    args.into_iter()
                        .map(|arg| match arg {
                            RecordLitArg::Positional(expr) => Ok(RecordLitArg::Positional(
                                self.rewrite_capture_placeholders(
                                    expr,
                                    capture_span,
                                    allow_placeholders,
                                    inside_placeholder_capture,
                                )?,
                            )),
                            RecordLitArg::Named(name, expr) => Ok(RecordLitArg::Named(
                                name,
                                self.rewrite_capture_placeholders(
                                    expr,
                                    capture_span,
                                    allow_placeholders,
                                    inside_placeholder_capture,
                                )?,
                            )),
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                ))
            }
            Ast::Closure(span, params, body) => Ok(Ast::Closure(
                span,
                params,
                Box::new(self.rewrite_capture_placeholders(*body, capture_span, false, true)?),
            )),
            Ast::ExtractorClosure(span, params, body) => Ok(Ast::ExtractorClosure(
                span,
                params,
                Box::new(self.rewrite_capture_placeholders(*body, capture_span, false, true)?),
            )),
            Ast::Capture(span, target, args) => {
                if inside_placeholder_capture && !args.is_empty() {
                    return Err(ResolveError {
                        message: "outer capture placeholders are only valid in the outer capture body; nested capture argument blocks are not allowed".into(),
                        span,
                        diagnostic: crate::error::ResolveErrorDiagnostic { reason: crate::error::ResolveErrorReason::Capture, subject: None },
                        related_labels: Vec::new(),
                    });
                }
                Ok(Ast::Capture(
                    span,
                    Box::new(self.rewrite_capture_placeholders(
                        *target,
                        capture_span,
                        allow_placeholders,
                        inside_placeholder_capture,
                    )?),
                    args.into_iter()
                        .map(|arg| {
                            self.rewrite_capture_placeholders(
                                arg,
                                capture_span,
                                allow_placeholders,
                                inside_placeholder_capture,
                            )
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                ))
            }
            other => Ok(other),
        }
    }

    fn lower_capture_expr(
        &self,
        span: Span,
        target: Ast,
        args: Vec<Ast>,
    ) -> Result<Ast, ResolveError> {
        if let Ast::FuncLiteralRef(_, func) = target {
            if args.is_empty() {
                let left_name = Self::capture_placeholder_param_name(&span, 1);
                let right_name = Self::capture_placeholder_param_name(&span, 2);
                let body = self.make_operator_capture_body(
                    &span,
                    &func.body,
                    Ast::Var(span.clone(), left_name.clone()),
                    Ast::Var(span.clone(), right_name.clone()),
                )?;
                return Ok(Ast::Closure(
                    span.clone(),
                    vec![
                        ClosureParam {
                            name: left_name,
                            ty: None,
                            span: span.clone(),
                        },
                        ClosureParam {
                            name: right_name,
                            ty: None,
                            span: span.clone(),
                        },
                    ],
                    Box::new(body),
                ));
            }

            if args.len() != 2 {
                return Err(ResolveError {
                    message: format!(
                        "operator capture `{}` expects exactly 2 argument expressions",
                        func.body
                    ),
                    span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Capture,
                        subject: None,
                    },
                    related_labels: Vec::new(),
                });
            }

            let max_index = self.validate_capture_placeholders(&span, &args)?;
            let rewritten_args = args
                .into_iter()
                .map(|arg| self.rewrite_capture_placeholders(arg, &span, true, true))
                .collect::<Result<Vec<_>, _>>()?;
            let [left, right]: [Ast; 2] = rewritten_args.try_into().map_err(|_| ResolveError {
                message: format!(
                    "operator capture `{}` expects exactly 2 argument expressions",
                    func.body
                ),
                span: span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::Capture,
                    subject: None,
                },
                related_labels: Vec::new(),
            })?;
            let body = self.make_operator_capture_body(&span, &func.body, left, right)?;
            let params = (1..=max_index)
                .map(|index| ClosureParam {
                    name: Self::capture_placeholder_param_name(&span, index),
                    ty: None,
                    span: span.clone(),
                })
                .collect();
            return Ok(Ast::Closure(span, params, Box::new(body)));
        }

        if args.is_empty() {
            return Ok(Ast::Capture(span, Box::new(target), args));
        }

        let max_index = self.validate_capture_placeholders(&span, &args)?;

        let rewritten_args = args
            .into_iter()
            .map(|arg| self.rewrite_capture_placeholders(arg, &span, true, true))
            .collect::<Result<Vec<_>, _>>()?;
        let params = (1..=max_index)
            .map(|index| ClosureParam {
                name: Self::capture_placeholder_param_name(&span, index),
                ty: None,
                span: span.clone(),
            })
            .collect();
        Ok(self.make_closure_from_call(&span, params, target, rewritten_args))
    }

    /// Check the original capture positions using resolved placeholder identities.
    /// Imported and qualified Facet calls share this path; ordinary same-name
    /// functions do not acquire compile-time Facet argument restrictions.
    /// Bracket operands accept placeholders as ordinary data; nested calls
    /// enforce their own path positions during normal call resolution.
    fn reject_facet_path_placeholders(
        &self,
        callee: &Resolved,
        args: &[ResolvedRecordLitArg],
    ) -> Result<(), ResolveError> {
        let Resolved::Var(_, id) = callee else {
            return Ok(());
        };
        let Some(qualified) = id.qualified_name.as_deref() else {
            return Ok(());
        };
        let count = match surface_path_name(qualified) {
            "Facet::compose" => 2,
            "Facet::view" | "Facet::preview" | "Facet::put" | "Facet::set" | "Facet::over"
            | "Facet::over_result" | "Facet::case_set" | "Facet::case_over" => 1,
            _ => return Ok(()),
        };
        for argument in args.iter().take(count) {
            let expression = match argument {
                ResolvedRecordLitArg::Positional(expr) | ResolvedRecordLitArg::Named(_, expr) => {
                    expr
                }
            };
            if let Some(placeholder) = super::captures::collect_facet_path_references(expression)
                .into_iter()
                .find(|reference| self.capture_placeholder_ids.contains(&reference.unique_id))
            {
                return Err(ResolveError {
                    message: "capture placeholders cannot replace a FacetPath or its root".into(),
                    span: placeholder.span,
                    related_labels: Vec::new(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Capture,
                        subject: None,
                    },
                });
            }
        }
        Ok(())
    }

    fn inferred_facet_capture_segments(expr: &Ast) -> Option<Vec<FacetPathSegment>> {
        let mut segments = Vec::new();
        let mut current = expr;
        loop {
            match current {
                Ast::FieldAccess(_, inner, field) => {
                    segments.push(FacetPathSegment::field(field.clone()));
                    current = inner.as_ref();
                }
                Ast::FacetSegmentAccess(_, inner, segment) => {
                    segments.push(segment.clone());
                    current = inner.as_ref();
                }
                Ast::Grouped(_, inner) => {
                    current = inner.as_ref();
                }
                Ast::Var(_, name) if name == "_" => {
                    segments.reverse();
                    return (!segments.is_empty()).then_some(segments);
                }
                _ => return None,
            }
        }
    }

    fn resolve_facet_path_segment(
        &mut self,
        segment: FacetPathSegment,
    ) -> Result<ResolvedFacetPathSegment, ResolveError> {
        Ok(match segment {
            FacetPathSegment::Field { name, optional } => {
                ResolvedFacetPathSegment::Field { name, optional }
            }
            FacetPathSegment::Bracket(expr) => {
                ResolvedFacetPathSegment::Bracket(ResolvedFacetBracketExpr {
                    expr: Box::new(self.resolve_node(*expr.expr)?),
                    display: expr.display,
                })
            }
        })
    }

    fn resolve_facet_path_segments(
        &mut self,
        segments: Vec<FacetPathSegment>,
    ) -> Result<Vec<ResolvedFacetPathSegment>, ResolveError> {
        segments
            .into_iter()
            .map(|segment| self.resolve_facet_path_segment(segment))
            .collect()
    }

    fn pipe_slot_span(expr: &Ast) -> Option<Span> {
        match expr {
            Ast::NumberedPlaceholder(span, _) => Some(span.clone()),
            Ast::App(_, func, args) => Self::pipe_slot_span(func).or_else(|| {
                args.iter().find_map(|arg| match arg {
                    RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => {
                        Self::pipe_slot_span(expr)
                    }
                })
            }),
            Ast::Block(_, stmts) | Ast::ListLiteral(_, stmts) | Ast::TupleLiteral(_, stmts) => {
                stmts.iter().find_map(Self::pipe_slot_span)
            }
            Ast::Do(_, _, statements, _) => {
                statements.iter().find_map(|statement| match statement {
                    AstDoStatement::Extract { rhs, .. } | AstDoStatement::SafeBind { rhs, .. } => {
                        Self::pipe_slot_span(rhs)
                    }
                    AstDoStatement::Statement(statement) => Self::pipe_slot_span(statement),
                })
            }
            Ast::HashMapLiteral(_, entries) => entries.iter().find_map(|entry| {
                Self::pipe_slot_span(&entry.key).or_else(|| Self::pipe_slot_span(&entry.value))
            }),
            Ast::RangeLiteral(_, start, stop) => {
                Self::pipe_slot_span(start).or_else(|| Self::pipe_slot_span(stop))
            }
            Ast::Bind(_, _, rhs)
            | Ast::SafeBind(_, _, rhs, _)
            | Ast::StatementQuestion(_, rhs)
            | Ast::Grouped(_, rhs)
            | Ast::Semi(_, rhs)
            | Ast::FieldAccess(_, rhs, _)
            | Ast::FacetSegmentAccess(_, rhs, _) => Self::pipe_slot_span(rhs),
            Ast::BinOp(_, _, left, right)
            | Ast::Pipe(_, left, right)
            | Ast::ContextMap(_, left, right)
            | Ast::ContextBind(_, left, right)
            | Ast::Compose(_, left, right)
            | Ast::LiftedCompose(_, left, right)
            | Ast::KleisliCompose(_, left, right)
            | Ast::ListCons(_, left, right) => {
                Self::pipe_slot_span(left).or_else(|| Self::pipe_slot_span(right))
            }
            Ast::InterpolatedStr(_, parts) => parts.iter().find_map(|part| match part {
                InterpolatedPart::Text(_) => None,
                InterpolatedPart::Expr(expr) => Self::pipe_slot_span(expr),
            }),
            Ast::Cond(_, clauses) => clauses.iter().find_map(|(condition, body)| {
                Self::pipe_slot_span(condition).or_else(|| Self::pipe_slot_span(body))
            }),
            Ast::Match(_, scrutinee, arms) => Self::pipe_slot_span(scrutinee).or_else(|| {
                arms.iter().find_map(|arm| {
                    arm.guard
                        .as_ref()
                        .and_then(Self::pipe_slot_span)
                        .or_else(|| Self::pipe_slot_span(&arm.body))
                })
            }),
            Ast::StructLit(_, _, fields) | Ast::InternalStructLit(_, _, fields) => {
                fields.iter().find_map(|field| match field {
                    StructLitField::Explicit(_, expr) => Self::pipe_slot_span(expr),
                    StructLitField::Shorthand(_) => None,
                })
            }
            Ast::ConstructorCall(_, _, args) | Ast::EnumConstructorCall(_, _, _, _, args) => {
                args.iter().find_map(|arg| match arg {
                    RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => {
                        Self::pipe_slot_span(expr)
                    }
                })
            }
            Ast::Closure(_, _, body) | Ast::ExtractorClosure(_, _, body) => {
                Self::pipe_slot_span(body)
            }
            Ast::Capture(_, target, args) => {
                Self::pipe_slot_span(target).or_else(|| args.iter().find_map(Self::pipe_slot_span))
            }
            Ast::FuncLiteralRef(_, _) => None,
            _ => None,
        }
    }

    /// Choose insertion solely from direct argument slots, before arity or
    /// parameter-role validation. Pattern nodes are not searched for pipe slots.
    pub(super) fn pipe_argument_slot<'a>(
        span: &Span,
        arguments: impl Iterator<Item = Option<&'a Ast>>,
    ) -> Result<Option<usize>, ResolveError> {
        let mut slot = None;
        for (index, expression) in arguments.enumerate() {
            let Some(expression) = expression else {
                continue;
            };
            if let Ast::NumberedPlaceholder(argument_span, number) = expression {
                if *number != 1 {
                    return Err(Self::pipe_argument_error(
                        "pipe placeholder must be `_1`",
                        argument_span.clone(),
                    ));
                }
                if slot.replace(index).is_some() {
                    return Err(Self::pipe_argument_error(
                        "pipe placeholder `_1` can only be used once",
                        span.clone(),
                    ));
                }
            } else if let Some(argument_span) = Self::pipe_slot_span(expression) {
                return Err(Self::pipe_argument_error(
                    "pipe placeholder `_1` cannot be used as an expression",
                    argument_span,
                ));
            }
        }
        Ok(slot)
    }

    fn pipe_argument_error(message: &str, span: Span) -> ResolveError {
        ResolveError {
            message: message.into(),
            span,
            diagnostic: crate::error::ResolveErrorDiagnostic {
                reason: crate::error::ResolveErrorReason::SpecialForm,
                subject: None,
            },
            related_labels: Vec::new(),
        }
    }

    pub(super) fn insert_pipe_argument<T>(
        arguments: &mut Vec<T>,
        slot: Option<usize>,
        argument: T,
    ) {
        if let Some(index) = slot {
            arguments[index] = argument;
        } else {
            arguments.insert(0, argument);
        }
    }

    pub(super) fn prepare_pipe_rhs(&mut self, rhs: Ast) -> Result<Ast, ResolveError> {
        let (span, callee, mut arguments) = match rhs {
            Ast::PatternConsumerCall(span, callee, arguments) => {
                return self.prepare_pattern_consumer_pipe(span, callee, arguments);
            }
            Ast::App(span, callee, arguments) => (span, callee, arguments),
            other => {
                if let Some(span) = Self::pipe_slot_span(&other) {
                    return Err(Self::pipe_argument_error(
                        "pipe placeholder `_1` is only allowed as a direct argument of the outermost call on the right-hand side", span));
                }
                return Ok(other);
            }
        };
        let slot = Self::pipe_argument_slot(
            &span,
            arguments.iter().map(|argument| {
                Some(match argument {
                    RecordLitArg::Positional(expr) | RecordLitArg::Named(_, expr) => expr,
                })
            }),
        )?;
        if slot.is_some()
            && arguments
                .iter()
                .any(|argument| matches!(argument, RecordLitArg::Named(..)))
        {
            return Err(Self::pipe_argument_error(
                "pipe placeholder `_1` does not support named arguments",
                span,
            ));
        }
        let pair = matches!(callee.as_ref(), Ast::FuncLiteralRef(_, pair) if pair.body == "(,)");
        let special = if pair {
            true
        } else if matches!(
            callee.as_ref(),
            Ast::Var(..) | Ast::InternalVar(..) | Ast::Path(..) | Ast::NamedInfixRef(..)
        ) {
            let resolved = match callee.as_ref() {
                Ast::Var(span, name) | Ast::InternalVar(span, name) => {
                    self.resolve_var_like(span.clone(), name.clone(), false)?
                }
                Ast::Path(span, path) => {
                    self.resolve_var_like(span.clone(), path.segments.join("::"), false)?
                }
                Ast::NamedInfixRef(..) => self.resolve_node(*callee.clone())?,
                _ => unreachable!(),
            };
            self.classify_canonical_special_form_callee(&resolved)
                .is_some()
        } else {
            false
        };
        // Ordinary first insertion stays in Scar's InjectCall representation:
        // explicit arguments are evaluated once when the callable is formed.
        if slot.is_none() && !special {
            return Ok(Ast::App(span, callee, arguments));
        }
        let param_name = Self::pipe_slot_param_name(&span);
        Self::insert_pipe_argument(
            &mut arguments,
            slot,
            RecordLitArg::Positional(Ast::Var(span.clone(), param_name.clone())),
        );
        let body = if pair {
            let [RecordLitArg::Positional(left), RecordLitArg::Positional(right)]: [RecordLitArg;
                2] = arguments.try_into().map_err(|_| {
                Self::pipe_argument_error(
                    "quoted pair constructor pipeline call expects exactly one positional argument",
                    span.clone(),
                )
            })?
            else {
                return Err(Self::pipe_argument_error(
                    "quoted pair constructor pipeline call expects exactly one positional argument",
                    span,
                ));
            };
            Ast::TupleLiteral(span.clone(), vec![left, right])
        } else {
            Ast::App(span.clone(), callee, arguments)
        };
        Ok(Ast::Closure(
            span.clone(),
            vec![ClosureParam {
                name: param_name,
                ty: None,
                span,
            }],
            Box::new(body),
        ))
    }

    fn undefined_callable_arity_message(func: &Ast, arity: usize) -> Option<String> {
        match func {
            Ast::Var(_, name) => Some(format!("Undefined function {}/{}", name, arity)),
            Ast::Path(_, path) => Some(format!(
                "Undefined function {}/{}",
                path.segments.join("::"),
                arity
            )),
            _ => None,
        }
    }

    fn callable_entry_for_name(&self, name: &str) -> Option<&DeclarationEntry> {
        self.declaration_entries.get(name).filter(|entry| {
            matches!(
                entry.kind,
                DeclarationKind::Def
                    | DeclarationKind::Extractor
                    | DeclarationKind::TraitMethod
                    | DeclarationKind::ImplMethod
            )
        })
    }

    fn private_callable_error_message(&self, fq_name: &str, arity: usize) -> String {
        format!("Function `{fq_name}/{arity}` is private")
    }

    fn restricted_callable_error_message(&self, fq_name: &str, arity: usize) -> String {
        format!("Function `{fq_name}/{arity}` cannot be called from user code")
    }

    fn private_callable_error_for_candidate(&self, fq_name: &str, arity: usize) -> Option<String> {
        let mut candidates = vec![fq_name.to_string()];
        if !fq_name.starts_with("Global::") {
            candidates.push(format!("Global::{fq_name}"));
        }
        candidates.into_iter().find_map(|candidate| {
            self.callable_entry_for_name(&candidate)
                .is_some_and(|entry| entry.visibility == Visibility::Private)
                .then(|| self.private_callable_error_message(surface_path_name(&candidate), arity))
        })
    }

    pub(super) fn declaration_entry_for_uid(&self, uid: u32) -> Option<&DeclarationEntry> {
        self.declaration_uids
            .iter()
            .find_map(|(fq_name, entry_uid)| (*entry_uid == uid).then_some(fq_name))
            .and_then(|fq_name| self.declaration_entries.get(fq_name))
    }

    fn ensure_user_callable_surface(
        &self,
        resolved_func: &Resolved,
        span: &Span,
        arity: usize,
    ) -> Result<(), ResolveError> {
        let Resolved::Var(_, id) = resolved_func else {
            return Ok(());
        };
        if id.compiler_generated {
            return Ok(());
        }
        let Some(entry) = self.declaration_entry_for_uid(id.unique_id) else {
            return Ok(());
        };
        if entry.user_callable {
            return Ok(());
        }
        Err(ResolveError {
            message: self.restricted_callable_error_message(&entry.fq_name, arity),
            span: span.clone(),
            diagnostic: crate::error::ResolveErrorDiagnostic {
                reason: crate::error::ResolveErrorReason::Visibility,
                subject: Some(entry.fq_name.clone()),
            },
            related_labels: Vec::new(),
        })
    }

    fn private_callable_hint_for_bare_name(&self, name: &str, arity: usize) -> Option<String> {
        let matches = self
            .explicit_module_imports
            .iter()
            .filter_map(|module_name| {
                let fq_name = format!("{module_name}::{name}");
                self.callable_entry_for_name(&fq_name)
                    .and_then(|entry| (entry.visibility == Visibility::Private).then_some(fq_name))
            })
            .collect::<Vec<_>>();
        if matches.len() == 1 {
            Some(format!(" Help: `{}/{}` is private.", matches[0], arity))
        } else {
            None
        }
    }

    fn map_undefined_callable_error(
        &self,
        err: ResolveError,
        func: &Ast,
        arity: usize,
    ) -> ResolveError {
        if let Ast::NamedInfixRef(span, path) = func {
            let callee = if path.segments.len() == 1 {
                Ast::Var(span.clone(), path.segments[0].clone())
            } else {
                Ast::Path(span.clone(), path.clone())
            };
            return self.map_undefined_callable_error(err, &callee, arity);
        }
        if let Ast::Var(_, name) = func {
            if let Some(message) = self.private_callable_error_for_candidate(name, arity) {
                return ResolveError {
                    message,
                    span: err.span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Visibility,
                        subject: Some(name.clone()),
                    },
                    related_labels: Vec::new(),
                };
            }
        }
        if let Ast::Path(_, path) = func {
            let fq_name = path.segments.join("::");
            if let Some(message) = self.private_callable_error_for_candidate(&fq_name, arity) {
                return ResolveError {
                    message,
                    span: err.span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::Visibility,
                        subject: Some(fq_name),
                    },
                    related_labels: Vec::new(),
                };
            }
        }
        match func {
            Ast::Var(_, name) if err.message == format!("Undefined variable: {}", name) => {
                let message = Self::undefined_callable_arity_message(func, arity)
                    .unwrap_or_else(|| format!("Undefined variable or function: {}", name));
                ResolveError {
                    message: match self.private_callable_hint_for_bare_name(name, arity) {
                        Some(hint) => format!("{message}{hint}"),
                        None => message,
                    },
                    span: err.span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: Some(name.clone()),
                    },
                    related_labels: Vec::new(),
                }
            }
            Ast::Path(_, path)
                if err.message == format!("Undefined variable: {}", path.segments.join("::")) =>
            {
                ResolveError {
                    message: Self::undefined_callable_arity_message(func, arity).unwrap_or_else(
                        || {
                            format!(
                                "Undefined variable or function: {}",
                                path.segments.join("::")
                            )
                        },
                    ),
                    span: err.span,
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: Some(path.segments.join("::")),
                    },
                    related_labels: Vec::new(),
                }
            }
            _ => err,
        }
    }

    #[cfg(test)]
    pub(super) fn new() -> Self {
        Self {
            scope: super::scope_init::initialize_scope(),
            capture_placeholder_ids: HashSet::new(),
            pattern_proxies: None,
            predeclared_ids: HashMap::new(),
            impl_member_scopes: HashMap::new(),
            declaration_entries: Arc::new(HashMap::new()),
            declaration_uids: Arc::new(HashMap::new()),
            declaration_uid_kinds: Arc::new(HashMap::new()),
            declaration_hidden_by_uid: Arc::new(HashMap::new()),
            trait_constructor_slots: Arc::new(HashMap::new()),
            owner_registry: Arc::new(OwnerRegistry::default()),
            explicit_module_imports: HashSet::new(),
            current_module_path: None,
            current_stage_impl_targets: None,
            allow_top_level_shadowing: false,
            forbidden_top_level_value_bindings: HashMap::new(),
            current_top_level_def_name: None,
        }
    }

    pub(super) fn with_scope(scope: Scope) -> Self {
        Self {
            scope,
            capture_placeholder_ids: HashSet::new(),
            pattern_proxies: None,
            predeclared_ids: HashMap::new(),
            impl_member_scopes: HashMap::new(),
            declaration_entries: Arc::new(HashMap::new()),
            declaration_uids: Arc::new(HashMap::new()),
            declaration_uid_kinds: Arc::new(HashMap::new()),
            declaration_hidden_by_uid: Arc::new(HashMap::new()),
            trait_constructor_slots: Arc::new(HashMap::new()),
            owner_registry: Arc::new(OwnerRegistry::default()),
            explicit_module_imports: HashSet::new(),
            current_module_path: None,
            current_stage_impl_targets: None,
            allow_top_level_shadowing: false,
            forbidden_top_level_value_bindings: HashMap::new(),
            current_top_level_def_name: None,
        }
    }

    pub(super) fn into_scope(self) -> Scope {
        self.scope
    }

    pub(super) fn qualify_current_declaration_name(&self, name: &str) -> String {
        if name.contains("::") {
            return name.to_string();
        }
        match self.current_module_path.as_deref() {
            Some(module_path) if !module_path.is_empty() => format!("{module_path}::{name}"),
            _ => name.to_string(),
        }
    }

    pub(super) fn symbol_info_for_uid(&self, name: &str, uid: u32) -> Option<SymbolIdentityInfo> {
        if is_synthetic_builtin_symbol_uid(uid) {
            return builtin_symbol_identity_info(name);
        }
        let kind = self.declaration_uid_kinds.get(&uid)?;
        let entry = self.declaration_entry_for_uid(uid);
        let direct_owner_name = if matches!(kind, DeclarationKind::Const) {
            entry
                .filter(|entry| entry.fq_name.contains("::__const__::"))
                .map(|entry| entry.fq_name.as_str())
                .or_else(|| entry.map(|entry| entry.name.as_str()))
                .unwrap_or(name)
        } else {
            entry.map(|entry| entry.name.as_str()).unwrap_or(name)
        };
        let inferred_owner = match kind {
            DeclarationKind::EnumVariant | DeclarationKind::TraitMethod => {
                let canonical_member_name = entry
                    .map(|entry| entry.name.as_str())
                    .filter(|entry_name| entry_name.contains("::"))
                    .or_else(|| entry.map(|entry| entry.fq_name.as_str()))
                    .unwrap_or(name);
                canonical_member_name
                    .rsplit_once("::")
                    .map(|(owner, _)| owner.to_string())
            }
            _ => entry.and_then(|entry| {
                let module_path = entry
                    .module_path
                    .strip_suffix("::__traitimpl__")
                    .unwrap_or(&entry.module_path);
                (!module_path.is_empty() && module_path != "__traitimpl__")
                    .then(|| module_path.to_string())
            }),
        };
        declaration_symbol_identity_info(
            &self.owner_registry,
            direct_owner_name,
            kind,
            inferred_owner.as_deref(),
        )
    }

    fn inherent_impl_body_scope(&self, name: &str, span: &Span) -> Result<Scope, ResolveError> {
        let mut scope = self.scope.child();
        if let Some(members) = self.impl_member_scopes.get(name) {
            for (member, lowered_name) in members {
                let uid = self
                    .scope
                    .lookup(lowered_name)
                    .ok_or_else(|| ResolveError {
                        message: format!("Missing predeclared impl member: {lowered_name}"),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::CompilerInvariant,
                            subject: Some(lowered_name.clone()),
                        },
                        related_labels: Vec::new(),
                    })?;
                scope.define_with_id(member, uid);
            }
        }
        Ok(scope)
    }

    fn symbol_info_for_declaration(
        &self,
        name: &str,
        kind: &DeclarationKind,
        enclosing_owner: Option<&str>,
    ) -> Option<SymbolIdentityInfo> {
        declaration_symbol_identity_info(&self.owner_registry, name, kind, enclosing_owner)
    }

    fn body_declaration_entries(&self) -> Arc<HashMap<String, DeclarationEntry>> {
        Arc::new(
            self.declaration_entries
                .iter()
                .filter(|(_, entry)| {
                    matches!(entry.kind, DeclarationKind::Extractor)
                        || !entry.lazy_parameters.is_empty()
                })
                .map(|(key, entry)| (key.clone(), entry.clone()))
                .collect(),
        )
    }

    pub(super) fn with_child_scope<T>(
        &mut self,
        f: impl FnOnce(&mut Resolver) -> Result<T, ResolveError>,
    ) -> Result<T, ResolveError> {
        let mut child = Resolver::with_scope(self.scope.child());
        child.capture_placeholder_ids = self.capture_placeholder_ids.clone();
        child.pattern_proxies = self.pattern_proxies.clone();
        child.declaration_uids = self.declaration_uids.clone();
        child.declaration_uid_kinds = self.declaration_uid_kinds.clone();
        child.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
        child.trait_constructor_slots = self.trait_constructor_slots.clone();
        child.declaration_entries = self.declaration_entries.clone();
        child.owner_registry = self.owner_registry.clone();
        child.explicit_module_imports = self.explicit_module_imports.clone();
        child.current_module_path = self.current_module_path.clone();
        child.current_stage_impl_targets = self.current_stage_impl_targets.clone();
        child.allow_top_level_shadowing = self.allow_top_level_shadowing;
        child.forbidden_top_level_value_bindings = self.forbidden_top_level_value_bindings.clone();
        child.current_top_level_def_name = self.current_top_level_def_name.clone();
        let out = f(&mut child)?;
        self.scope.advance_next_id_to(child.scope.next_id());
        Ok(out)
    }

    fn top_level_value_bindings(&self) -> HashMap<u32, String> {
        let builtin_ids = compiler_builtin_bindings()
            .into_iter()
            .map(|(uid, _)| uid)
            .collect::<HashSet<_>>();
        self.scope
            .bindings()
            .filter(|(_, uid)| {
                !self.declaration_uid_kinds.contains_key(uid) && !builtin_ids.contains(uid)
            })
            .map(|(name, uid)| (uid, name.to_string()))
            .collect()
    }

    fn forbids_top_level_value_capture_in_defs(&self) -> bool {
        match self.current_module_path.as_deref() {
            None => true,
            Some("__Repl::Session") => true,
            Some(path) if path.starts_with("__Script::") => true,
            _ => false,
        }
    }

    pub(super) fn is_constructor_style_head(name: &str) -> bool {
        name.rsplit("::")
            .next()
            .and_then(|segment| segment.chars().next())
            .is_some_and(|ch| ch.is_uppercase())
    }

    pub(super) fn declaration_fq_name_for_uid(&self, uid: u32) -> Option<String> {
        self.declaration_uids
            .iter()
            .find_map(|(fq_name, entry_uid)| (*entry_uid == uid).then(|| fq_name.clone()))
    }

    fn hidden_builtin_message(name: &str) -> String {
        let display_name = match name {
            "Agent::pid"
            | "Agent::spawn"
            | "Agent::state"
            | "Agent::store"
            | "Agent::self"
            | "Agent::context_handler"
            | "GenServer::pid"
            | "GenServer::spawn"
            | "GenServer::state"
            | "GenServer::store"
            | "GenServer::self"
            | "GenServer::context_handler"
            | "Supervisor::spawn"
            | "Supervisor::adopt"
            | "Supervisor::status"
            | "Supervisor::workers" => name,
            _ => name.rsplit("::").next().unwrap_or(name),
        };
        let guidance = match name {
            "Agent::pid"
            | "Agent::spawn"
            | "Agent::state"
            | "Agent::store"
            | "Agent::self"
            | "Agent::context_handler" => {
                "This Agent module surface is compiler-managed; use `defagent` or generated owner helpers instead."
            }
            "GenServer::pid"
            | "GenServer::spawn"
            | "GenServer::state"
            | "GenServer::store"
            | "GenServer::self"
            | "GenServer::context_handler" => {
                "This GenServer module surface is compiler-managed; use `defagent`, `defgenserver`, or generated owner helpers instead."
            }
            "Supervisor::spawn" => {
                "This Supervisor module surface is compiler-managed; use `DynamicSupervisor::spawn(...)` or a generated `SupName::spawn(...)` wrapper instead."
            }
            "Supervisor::adopt" => {
                "This Supervisor module surface is compiler-managed; use `DynamicSupervisor::adopt(...)` or a generated `SupName::adopt(...)` wrapper instead."
            }
            "Supervisor::status" => {
                "This Supervisor module surface is compiler-managed; use `DynamicSupervisor::status()` or a generated `SupName::status()` wrapper instead."
            }
            "Supervisor::workers" => {
                "This Supervisor module surface is compiler-managed; use a generated `SupName::workers(...)` wrapper or the public Workers API instead."
            }
            _ => match display_name {
                "__process_self" => "Use `Process::self()` instead.",
                "__process_sleep" => "Use `Process::sleep(...)` instead.",
                "__task_call" => "Use `Task::call(...)` instead.",
                "__task_async" => "Use `Task::async(...)` instead.",
                "__task_await" => "Use `Task::await(...)` instead.",
                "__task_launch" => "Use `Task::launch(...)` instead.",
                "__task_cast" => "Use `Task::cast(...)` instead.",
                "__task_call_timeout"
                | "__task_async_timeout"
                | "__task_await_timeout"
                | "__task_launch_timeout"
                | "__task_cast_timeout"
                | "__workers_submit_timeout"
                | "__workers_broadcast_timeout" => {
                    "Use the public Task/Workers API with `@timeout(...)` instead."
                }
                "__process_pid" | "__process_spawn" | "__process_state" | "__process_store" => {
                    "This helper is compiler-managed; use `defagent`, `defgenserver`, or the public process surface instead."
                }
                "__supervisor_spawn" => {
                    "Use `DynamicSupervisor::spawn(...)` or a generated Supervisor `spawn` wrapper instead."
                }
                "__supervisor_adopt" => {
                    "Use `DynamicSupervisor::adopt(...)` or a generated Supervisor `adopt` wrapper instead."
                }
                "__supervisor_status" => {
                    "Use `DynamicSupervisor::status()` or a generated Supervisor `status` wrapper instead."
                }
                "__supervisor_workers" => {
                    "Use a generated Supervisor `workers` wrapper or the public Workers surface instead."
                }
                _ => "Use the public standard-library surface instead.",
            },
        };
        format!("hidden builtin `{display_name}` is compiler-internal. {guidance}")
    }

    fn hidden_builtin_error(&self, name: &str, span: Span) -> ResolveError {
        ResolveError {
            message: Self::hidden_builtin_message(name),
            span,
            diagnostic: crate::error::ResolveErrorDiagnostic {
                reason: crate::error::ResolveErrorReason::Visibility,
                subject: Some(name.to_string()),
            },
            related_labels: Vec::new(),
        }
    }

    fn resolve_value_var_like(
        &self,
        span: Span,
        name: String,
        compiler_generated: bool,
    ) -> Result<Resolved, ResolveError> {
        let resolved = self.resolve_declaration_var_like(span.clone(), name, compiler_generated)?;
        if let Resolved::Var(_, id) = &resolved {
            if self.declaration_uid_kinds.get(&id.unique_id) == Some(&DeclarationKind::Deferror) {
                if id.qualified_name.is_none() {
                    return Err(ResolveError {
                        message: "ErrorKind identity has no canonical declaration name".into(),
                        span,
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::CompilerInvariant,
                            subject: Some(id.name.clone()),
                        },
                        related_labels: Vec::new(),
                    });
                }
                return Ok(Resolved::ErrorKind(span, id.clone()));
            }
        }
        Ok(resolved)
    }

    fn resolve_facet_root_node(&mut self, expr: Ast) -> Result<Resolved, ResolveError> {
        let reference = match &expr {
            Ast::Var(span, name) => {
                Some(self.resolve_declaration_var_like(span.clone(), name.clone(), false)?)
            }
            Ast::Path(span, path) => Some(self.resolve_declaration_var_like(
                span.clone(),
                path.segments.join("::"),
                false,
            )?),
            _ => None,
        };
        if let Some(Resolved::Var(_, id)) = &reference {
            if self.declaration_uid_kinds.get(&id.unique_id) == Some(&DeclarationKind::Deferror) {
                return Ok(reference.expect("checked declaration reference"));
            }
        }
        self.resolve_node(expr)
    }

    fn resolve_declaration_var_like(
        &self,
        span: Span,
        name: String,
        compiler_generated: bool,
    ) -> Result<Resolved, ResolveError> {
        let resolved = self.resolve_var_like(span.clone(), name, compiler_generated)?;
        if let Resolved::Var(_, id) = &resolved {
            let qualified = id.qualified_name.as_deref().or_else(|| {
                self.declaration_entry_for_uid(id.unique_id)
                    .map(|entry| entry.fq_name.as_str())
            });
            if let Some(kind) =
                qualified.and_then(sindr::pattern::PatternConsumer::from_canonical_name)
            {
                return Err(ResolveError {
                    message: format!("Pattern consumer `{}::{}` cannot be used as a value or capture; use its complete call syntax", sindr::pattern::PatternConsumer::OWNER, kind.name()),
                    span, related_labels: Vec::new(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::SpecialForm, subject: Some(id.name.clone()),
                    },
                });
            }
        }
        Ok(resolved)
    }

    pub(super) fn resolve_var_like(
        &self,
        span: Span,
        name: String,
        compiler_generated: bool,
    ) -> Result<Resolved, ResolveError> {
        let name = sindr::names::special_enum_variant_surface_meta(&name)
            .map(|meta| meta.qualified_name.to_string())
            .unwrap_or(name);
        let uid = self
            .scope
            .lookup(&name)
            .or_else(|| synthetic_facet_root_uid(&name))
            .ok_or_else(|| ResolveError {
                message: format!("Undefined variable: {}", name),
                span: span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::NameResolution,
                    subject: Some(name.clone()),
                },
                related_labels: Vec::new(),
            })?;
        let qualified_name = (!is_synthetic_builtin_symbol_uid(uid))
            .then(|| self.declaration_fq_name_for_uid(uid))
            .flatten();
        let symbol_info = self.symbol_info_for_uid(&name, uid);
        if self
            .declaration_uid_kinds
            .get(&uid)
            .is_some_and(|kind| matches!(kind, DeclarationKind::Extractor))
        {
            return Err(ResolveError {
                message: format!(
                    "Extractor '{}' can only be used in Pattern positions. Use it as a Pattern head in match, apply_pattern, or on the left side of =?. If you need a value-level API, write a normal def that returns Result or Option explicitly.",
                    name
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::SpecialForm,
                    subject: Some(name.clone()),
                },
                related_labels: Vec::new(),
            });
        }
        if let Some(binding_name) = self.forbidden_top_level_value_bindings.get(&uid) {
            let def_name = self
                .current_top_level_def_name
                .as_deref()
                .unwrap_or("<top-level>");
            return Err(ResolveError {
                message: format!(
                    "Top-level definition `{def_name}` cannot reference value binding `{binding_name}`"
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::SourcePolicy,
                    subject: Some(binding_name.clone()),
                },
                related_labels: Vec::new(),
            });
        }
        if !compiler_generated
            && (self.declaration_hidden_by_uid.get(&uid) == Some(&true)
                || scope_init::is_compiler_runtime_builtin(&name))
        {
            return Err(self.hidden_builtin_error(&name, span));
        }
        Ok(Resolved::Var(
            span.clone(),
            ResolvedId {
                name,
                qualified_name,
                unique_id: uid,
                compiler_generated,
                symbol_info,
                span,
            },
        ))
    }

    pub(super) fn attached_extractor_for_struct(
        &self,
        struct_uid: u32,
        surface_head: &str,
    ) -> Option<(Option<String>, u32, DeclarationKind)> {
        // Struct heads are resolved by declaration name, not by `import`.
        // In MatchBlock, `User(...)` is sugar for `User::deconstruct(...)`.
        let surface_extractor_name = format!("{}::deconstruct", surface_head);
        if let Some(extractor_uid) = self.scope.lookup(&surface_extractor_name) {
            let extractor_kind = self.declaration_uid_kinds.get(&extractor_uid).cloned()?;
            let qualified_name = self.declaration_fq_name_for_uid(extractor_uid);
            return Some((qualified_name, extractor_uid, extractor_kind));
        }

        let struct_fq_name = self.declaration_fq_name_for_uid(struct_uid)?;
        let extractor_fq_name = format!("{}::deconstruct", struct_fq_name);
        let extractor_uid = *self.declaration_uids.get(&extractor_fq_name)?;
        let extractor_kind = self.declaration_uid_kinds.get(&extractor_uid).cloned()?;
        Some((Some(extractor_fq_name), extractor_uid, extractor_kind))
    }

    pub(super) fn resolve_program(
        &mut self,
        program: super::imports::ImportsResolvedProgram,
    ) -> Result<Vec<Resolved>, ResolveError> {
        let stmts = super::derive::expand_derive_annotations(program.into_statements())?;
        self.impl_member_scopes.clear();
        let stmts = self.lower_impl_defs(stmts)?;
        self.explicit_module_imports = Self::collect_explicit_module_imports(&stmts);
        self.validate_auto_import_conflicts(&stmts)?;
        self.predeclare_functions(&stmts)?;
        self.inherit_trait_constructor_slots(&stmts);
        let mut resolved = Vec::new();
        for stmt in stmts {
            if matches!(stmt, Ast::Import(_, _, _))
                || matches!(stmt, Ast::SupervisorInit(_, _))
                || matches!(
                    stmt,
                    Ast::BuiltinReflectionDecl(..) | Ast::IntrinsicDecl(_, _, _, _)
                )
                || matches!(&stmt, Ast::BuiltinDecl(_, name, _, _, _, _, _) if is_doc_only_builtin_decl(name))
            {
                // ImportsResolvedProgram guarantees file imports were applied before resolution.
                // Import declarations do not emit value IR.
                continue;
            }
            resolved.push(self.resolve_node(stmt)?);
        }
        validate_trait_impl_pairs_in_nodes(&resolved)?;
        self.predeclared_ids.clear();
        Ok(resolved)
    }

    fn inherit_trait_constructor_slots(&mut self, stmts: &[Ast]) {
        let mut parents = Vec::new();
        for stmt in stmts {
            let Ast::TraitDef(_, name, _, Some(clause), _, _) = stmt else {
                continue;
            };
            let Some(child_uid) = self.scope.lookup(name) else {
                continue;
            };
            for constraint in &clause.constraints {
                if !matches!(&constraint.subject, AstTy::Named(_, subject) if subject == "Self") {
                    continue;
                }
                for bound in &constraint.bounds {
                    let spire::ast::WhereConstraintRhs::Trait(_, parent_name) = bound else {
                        continue;
                    };
                    if let Some(parent_uid) = self.scope.lookup(parent_name) {
                        parents.push((child_uid, parent_uid));
                    }
                }
            }
        }
        loop {
            let mut changed = false;
            for (child, parent) in &parents {
                if self.trait_constructor_slots.contains_key(child) {
                    continue;
                }
                if let Some(slots) = self.trait_constructor_slots.get(parent).cloned() {
                    Arc::make_mut(&mut self.trait_constructor_slots).insert(*child, slots);
                    changed = true;
                }
            }
            if !changed {
                break;
            }
        }
    }

    fn collect_explicit_module_imports(stmts: &[Ast]) -> HashSet<String> {
        stmts
            .iter()
            .filter_map(|stmt| match stmt {
                Ast::Import(_, path, spire::ast::ImportSpec::All) => Some(path.segments.join("::")),
                _ => None,
            })
            .collect()
    }
}

impl Resolver {
    fn flatten_bulk_update_entries(
        prefix: Option<BulkUpdatePath>,
        entries: Vec<BulkUpdateEntry>,
        out: &mut Vec<(Span, BulkUpdatePath, BulkUpdateEntryKind)>,
    ) {
        for entry in entries {
            let path = match &prefix {
                Some(prefix) => {
                    let span = Span {
                        start: prefix.span().start,
                        end: entry.path.span().end,
                    };
                    BulkUpdatePath::Chain(span, Box::new(prefix.clone()), Box::new(entry.path))
                }
                None => entry.path,
            };
            match entry.kind {
                BulkUpdateEntryKind::Nested(children) => {
                    Self::flatten_bulk_update_entries(Some(path), children, out);
                }
                kind => out.push((entry.span, path, kind)),
            }
        }
    }

    fn make_bulk_update_capture_path(
        span: &Span,
        root_name: &str,
        path: &[FacetPathSegment],
    ) -> Result<Ast, ResolveError> {
        let mut expr = Ast::Var(span.clone(), root_name.to_string());
        for segment in path {
            expr = match segment {
                FacetPathSegment::Field {
                    name,
                    optional: false,
                } => Ast::FieldAccess(span.clone(), Box::new(expr), name.clone()),
                other => Ast::FacetSegmentAccess(span.clone(), Box::new(expr), other.clone()),
            };
        }
        Ok(Ast::FacetCapture(span.clone(), Box::new(expr)))
    }

    fn static_bulk_update_segments(
        path: &BulkUpdatePath,
    ) -> Result<Option<Vec<FacetPathSegment>>, ResolveError> {
        match path {
            BulkUpdatePath::Segments(_, segments) => Ok(Some(segments.clone())),
            BulkUpdatePath::Pin(_, _) => Ok(None),
            BulkUpdatePath::Chain(_, left, right) => {
                let Some(mut left_segments) = Self::static_bulk_update_segments(left)? else {
                    return Ok(None);
                };
                let Some(right_segments) = Self::static_bulk_update_segments(right)? else {
                    return Ok(None);
                };
                left_segments.extend(right_segments);
                Ok(Some(left_segments))
            }
            BulkUpdatePath::StripLeft(span, inner, count) => {
                let Some(segments) = Self::static_bulk_update_segments(inner)? else {
                    return Err(ResolveError {
                        message:
                            "bulk_update path strip operations require a concrete DSL path fragment"
                                .into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::SpecialForm,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                };
                if *count >= segments.len() {
                    return Err(ResolveError {
                        message: "bulk_update target path cannot be empty".into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::SpecialForm,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                }
                Ok(Some(segments.into_iter().skip(*count).collect()))
            }
            BulkUpdatePath::StripRight(span, inner, count) => {
                let Some(mut segments) = Self::static_bulk_update_segments(inner)? else {
                    return Err(ResolveError {
                        message:
                            "bulk_update path strip operations require a concrete DSL path fragment"
                                .into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::SpecialForm,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                };
                if *count >= segments.len() {
                    return Err(ResolveError {
                        message: "bulk_update target path cannot be empty".into(),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::SpecialForm,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                }
                let keep = segments.len() - *count;
                segments.truncate(keep);
                Ok(Some(segments))
            }
        }
    }

    fn make_bulk_update_path_expr(
        span: &Span,
        root_name: &str,
        path: &BulkUpdatePath,
    ) -> Result<Ast, ResolveError> {
        if let Some(segments) = Self::static_bulk_update_segments(path)? {
            if segments.is_empty() {
                return Err(ResolveError {
                    message: "bulk_update target path cannot be empty".into(),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::SpecialForm,
                        subject: None,
                    },
                    related_labels: Vec::new(),
                });
            }
            return Self::make_bulk_update_capture_path(span, root_name, &segments);
        }

        match path {
            BulkUpdatePath::Pin(pin_span, name) => Ok(Ast::Var(pin_span.clone(), name.clone())),
            BulkUpdatePath::Chain(chain_span, left, right) => {
                let left_expr = Self::make_bulk_update_path_expr(chain_span, root_name, left)?;
                let right_expr = Self::make_bulk_update_path_expr(chain_span, root_name, right)?;
                Ok(Ast::App(
                    chain_span.clone(),
                    Box::new(Ast::Path(
                        chain_span.clone(),
                        AstPath {
                            span: chain_span.clone(),
                            segments: vec!["Facet".into(), "compose".into()],
                        },
                    )),
                    vec![
                        RecordLitArg::Positional(left_expr),
                        RecordLitArg::Positional(right_expr),
                    ],
                ))
            }
            BulkUpdatePath::Segments(path_span, _)
            | BulkUpdatePath::StripLeft(path_span, _, _)
            | BulkUpdatePath::StripRight(path_span, _, _) => Err(ResolveError {
                message: "bulk_update static path could not be lowered".into(),
                span: path_span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::SpecialForm,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
        }
    }

    fn make_facet_intrinsic_call(
        span: &Span,
        method: &str,
        path_expr: Ast,
        source_expr: Option<Ast>,
        value_expr: Ast,
    ) -> Ast {
        let mut args = vec![RecordLitArg::Positional(path_expr)];
        if let Some(source_expr) = source_expr {
            args.push(RecordLitArg::Positional(source_expr));
        }
        args.push(RecordLitArg::Positional(value_expr));
        Ast::App(
            span.clone(),
            Box::new(Ast::Path(
                span.clone(),
                AstPath {
                    span: span.clone(),
                    segments: vec!["Facet".into(), method.into()],
                },
            )),
            args,
        )
    }

    fn lower_bulk_update_special_form(
        &mut self,
        span: Span,
        source: Ast,
        entries: Vec<BulkUpdateEntry>,
    ) -> Result<Resolved, ResolveError> {
        let mut flat_entries = Vec::new();
        Self::flatten_bulk_update_entries(None, entries, &mut flat_entries);

        let mut expr = Ast::ConstructorCall(
            source.span().clone(),
            "Result::Ok".into(),
            vec![RecordLitArg::Positional(source)],
        );

        for (index, entry_span, path, kind) in flat_entries
            .into_iter()
            .enumerate()
            .map(|(index, (span, path, kind))| (index, span, path, kind))
        {
            let param_name = format!("__bulk_state_{}_{}", span.start, index);
            let capture = Self::make_bulk_update_path_expr(&entry_span, &param_name, &path)?;
            let source_expr = if matches!(capture, Ast::FacetCapture(_, _)) {
                None
            } else {
                Some(Ast::Var(entry_span.clone(), param_name.clone()))
            };
            let body = match kind {
                BulkUpdateEntryKind::Set(value) => {
                    Self::make_facet_intrinsic_call(&entry_span, "set", capture, source_expr, value)
                }
                BulkUpdateEntryKind::Over(update_fun) => Self::make_facet_intrinsic_call(
                    &entry_span,
                    "over",
                    capture,
                    source_expr,
                    update_fun,
                ),
                BulkUpdateEntryKind::OverResult(update_fun) => Self::make_facet_intrinsic_call(
                    &entry_span,
                    "over_result",
                    capture,
                    source_expr,
                    update_fun,
                ),
                BulkUpdateEntryKind::CaseSet(value) => Self::make_facet_intrinsic_call(
                    &entry_span,
                    "case_set",
                    capture,
                    source_expr,
                    value,
                ),
                BulkUpdateEntryKind::CaseOver(update_fun) => Self::make_facet_intrinsic_call(
                    &entry_span,
                    "case_over",
                    capture,
                    source_expr,
                    update_fun,
                ),
                BulkUpdateEntryKind::Nested(_) => {
                    return Err(ResolveError {
                        message: "nested bulk_update entries must be flattened before lowering"
                            .into(),
                        span: entry_span,
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::CompilerInvariant,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    });
                }
            };
            let closure = Ast::Closure(
                entry_span.clone(),
                vec![ClosureParam {
                    name: param_name,
                    ty: None,
                    span: entry_span.clone(),
                }],
                Box::new(body),
            );
            expr = Ast::ContextBind(
                Span {
                    start: span.start,
                    end: entry_span.end,
                },
                Box::new(expr),
                Box::new(closure),
            );
        }

        self.resolve_node(expr)
    }

    fn resolve_literal_closure(
        &mut self,
        span: Span,
        params: Vec<ClosureParam>,
        body: Box<Ast>,
        extractor: bool,
        capture: bool,
    ) -> Result<Resolved, ResolveError> {
        let mut closure_scope = self.scope.child();
        let mut resolved_params = Vec::new();
        for param in params {
            reject_special_variant_binding(&param.name, &param.span)?;
            let uid = closure_scope.define(&param.name, param.span.clone());
            resolved_params.push(ResolvedClosureParam {
                lazy_capture: None,
                id: ResolvedId {
                    name: param.name,
                    qualified_name: None,
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info: None,
                    span: param.span,
                },
                ty: param.ty,
            });
        }

        let mut body_resolver = Resolver::with_scope(closure_scope);
        body_resolver.capture_placeholder_ids = self.capture_placeholder_ids.clone();
        if capture {
            body_resolver
                .capture_placeholder_ids
                .extend(resolved_params.iter().map(|param| param.id.unique_id));
        }
        body_resolver.declaration_uids = self.declaration_uids.clone();
        body_resolver.declaration_entries = self.body_declaration_entries();
        body_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
        body_resolver.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
        body_resolver.owner_registry = self.owner_registry.clone();
        body_resolver.current_module_path = self.current_module_path.clone();
        body_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
        let resolved_body = body_resolver.resolve_node(*body)?;
        self.scope.advance_next_id_to(body_resolver.scope.next_id());

        let captures = collect_captures(&resolved_body, &resolved_params);

        Ok(if extractor {
            Resolved::ExtractorClosure(span, resolved_params, captures, Box::new(resolved_body))
        } else {
            Resolved::Closure(span, resolved_params, captures, Box::new(resolved_body))
        })
    }

    // Keep declaration temporaries out of recursive expression frames. The
    // exhaustive dispatch also requires every new Ast variant to choose a path.
    pub(super) fn resolve_node(&mut self, node: Ast) -> Result<Resolved, ResolveError> {
        match node {
            node @ (Ast::PatternConsumerCall(..)
            | Ast::NumberedPlaceholder(..)
            | Ast::Reflection(..)
            | Ast::Lit(..)
            | Ast::Var(..)
            | Ast::InternalVar(..)
            | Ast::Path(..)
            | Ast::FuncLiteralRef(..)
            | Ast::NamedInfixRef(..)
            | Ast::ReturnTypeArgumentApply(..)
            | Ast::App(..)
            | Ast::Bind(..)
            | Ast::SafeBind(..)
            | Ast::StatementQuestion(..)
            | Ast::Do(..)
            | Ast::BinOp(..)
            | Ast::Pipe(..)
            | Ast::ContextMap(..)
            | Ast::ContextApply(..)
            | Ast::ContextBind(..)
            | Ast::Compose(..)
            | Ast::LiftedCompose(..)
            | Ast::KleisliCompose(..)
            | Ast::ListNil(..)
            | Ast::ListCons(..)
            | Ast::ListLiteral(..)
            | Ast::HashMapLiteral(..)
            | Ast::RangeLiteral(..)
            | Ast::TupleLiteral(..)
            | Ast::Grouped(..)
            | Ast::InterpolatedStr(..)
            | Ast::Dbg(..)
            | Ast::BulkUpdate(..)
            | Ast::FieldAccess(..)
            | Ast::FacetSegmentAccess(..)
            | Ast::FacetCapture(..)
            | Ast::Semi(..)
            | Ast::Cond(..)
            | Ast::Match(..)
            | Ast::Namespace(..)
            | Ast::SupervisorInit(..)) => self.resolve_expression_node(node),
            node @ (Ast::StructDef(..)
            | Ast::RecordDef(..)
            | Ast::DeferrorDef(..)
            | Ast::EnumDef(..)
            | Ast::Def(..)
            | Ast::ConstDef(..)
            | Ast::ExtractorDef(..)
            | Ast::TraitDef(..)
            | Ast::TraitImplDef(..)
            | Ast::BuiltinDecl(..)
            | Ast::BuiltinReflectionDecl(..)
            | Ast::IntrinsicDecl(..)
            | Ast::BuiltinExtractorDecl(..)
            | Ast::BuiltinTypeDecl(..)
            | Ast::TypeAlias(..)
            | Ast::Defmod(..)
            | Ast::Defagent(..)
            | Ast::Defgenserver(..)
            | Ast::Defsupervisor(..)
            | Ast::DefdynamicSupervisor(..)
            | Ast::Import(..)
            | Ast::Include(..)
            | Ast::ImplDef(..)) => self.resolve_declaration_node(node),
            node @ (Ast::Capture(..)
            | Ast::CapturePlaceholder(..)
            | Ast::StructLit(..)
            | Ast::InternalStructLit(..)
            | Ast::ConstructorCall(..)
            | Ast::EnumConstructorCall(..)) => self.resolve_callable_node(node),
            Ast::Block(span, statements) => self.resolve_block(span, statements),
            Ast::Closure(span, params, body) => {
                self.resolve_literal_closure(span, params, body, false, false)
            }
            Ast::ExtractorClosure(span, params, body) => {
                self.resolve_literal_closure(span, params, body, true, false)
            }
        }
    }

    #[inline(never)]
    fn resolve_block(
        &mut self,
        span: Span,
        statements: Vec<Ast>,
    ) -> Result<Resolved, ResolveError> {
        let resolved = self.with_child_scope(|child| {
            statements
                .into_iter()
                .map(|statement| child.resolve_node(statement))
                .collect::<Result<Vec<_>, _>>()
        })?;
        Ok(Resolved::Block(span, resolved))
    }

    #[inline(never)]
    fn resolve_expression_node(&mut self, node: Ast) -> Result<Resolved, ResolveError> {
        match node {
            Ast::PatternConsumerCall(span, callee, args) => self.resolve_pattern_consumer_call(span, callee, args),
            Ast::NumberedPlaceholder(span, _) => Err(ResolveError {
                message: "numbered placeholders are only valid as Pattern projections in apply_pattern or a direct pipe argument".into(), span,
                diagnostic: crate::error::ResolveErrorDiagnostic { reason: crate::error::ResolveErrorReason::SpecialForm, subject: None }, related_labels: Vec::new(),
            }),
            Ast::Reflection(span, value) => Err(ResolveError {
                message: format!("{} was not materialized from its source before resolution", value.name()),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant, subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::Lit(span, lit) => Ok(Resolved::Lit(span, lit)),

            Ast::Var(span, name) => self.resolve_value_var_like(span, name, false),
            Ast::InternalVar(span, name) => self.resolve_value_var_like(span, name, true),
            Ast::Path(span, path) => {
                let name = path.segments.join("::");
                let resolved = self.resolve_value_var_like(span.clone(), name.clone(), false)?;
                if matches!(resolved, Resolved::ErrorKind(..)) {
                    return Ok(resolved);
                }
                if path.segments.last().and_then(|segment| segment.chars().next())
                    .is_some_and(char::is_uppercase) {
                    return self.resolve_node(Ast::ConstructorCall(span, name, Vec::new()));
                }
                Ok(resolved)
            }
            Ast::FuncLiteralRef(span, func) => Err(ResolveError {
                message: format!(
                    "standalone func literal ref `{}` must be lowered before resolution",
                    func.body
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),

            Ast::ReturnTypeArgumentApply(span, target, args) => {
                let resolved_target = self.resolve_node(*target)?;
                self.ensure_user_callable_surface(&resolved_target, &span, 0)?;
                let resolved_args = args
                    .into_iter()
                    .map(|argument| self.resolve_return_type_argument(argument))
                    .collect::<Result<Vec<_>, _>>()?;
                Ok(Resolved::ReturnTypeArgumentApply(
                    span,
                    Box::new(resolved_target),
                    resolved_args,
                ))
            }

            Ast::NamedInfixRef(span, path) => {
                let callee = if path.segments.len() == 1 {
                    Ast::Var(span.clone(), path.segments[0].clone())
                } else {
                    Ast::Path(span.clone(), path)
                };
                let resolved = self.resolve_node(callee)?;
                if matches!(&resolved, Resolved::Var(_, id)
                    if self.declaration_uid_kinds.get(&id.unique_id).is_some_and(|kind|
                        matches!(kind, DeclarationKind::Def | DeclarationKind::TraitMethod | DeclarationKind::ImplMethod))) {
                    Ok(resolved)
                } else {
                    Err(ResolveError {
                        message: "Named infix requires a function declaration; the selected reference is a value binding".into(),
                        span,
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: None,
                        },
                        related_labels: Vec::new(),
                    })
                }
            }

            Ast::App(span, func, args) => {
                if let Ast::Var(_, ref name) = *func {
                    if name == "&&" {
                        return self.resolve_logic_call(span, args, LogicKind::And);
                    }
                    if name == "||" {
                        return self.resolve_logic_call(span, args, LogicKind::Or);
                    }
                }

                let resolved_func = match self.resolve_node(*func.clone()) {
                    Ok(resolved_func) => {
                        if let Some(kind) =
                            self.classify_canonical_special_form_callee(&resolved_func)
                        {
                            return self.resolve_canonical_special_form_call(span, args, kind, resolved_func);
                        }
                        resolved_func
                    }
                    Err(err) => {
                        return Err(self.map_undefined_callable_error(err, &func, args.len()));
                    }
                };
                self.ensure_user_callable_surface(&resolved_func, &span, args.len())?;
                let selected = match &resolved_func {
                    Resolved::ReturnTypeArgumentApply(_, target, _) => target.as_ref(),
                    other => other,
                };
                let lazy_parameters = match selected {
                    Resolved::Var(_, id) => self.declaration_entry_for_uid(id.unique_id)
                        .map(|entry| entry.lazy_parameters.clone()).unwrap_or_default(),
                    _ => Vec::new(),
                };
                let resolved_args = args
                    .into_iter()
                    .enumerate()
                    .map(|(ordinal, arg)| match arg {
                        RecordLitArg::Positional(expr) => {
                            let value = if lazy_parameters.iter().any(|(position, _)| *position == ordinal) {
                                self.resolve_lazy_input(expr)?
                            } else {
                                self.resolve_node(expr)?
                            };
                            Ok(ResolvedRecordLitArg::Positional(value))
                        }
                        RecordLitArg::Named(name, expr) => {
                            let value = if lazy_parameters.iter().any(|(_, parameter)| *parameter == name) {
                                self.resolve_lazy_input(expr)?
                            } else {
                                self.resolve_node(expr)?
                            };
                            Ok(ResolvedRecordLitArg::Named(name, value))
                        }
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                self.reject_facet_path_placeholders(&resolved_func, &resolved_args)?;
                Ok(Resolved::App(span, Box::new(resolved_func), resolved_args))
            }

            Ast::Bind(span, pat, rhs) => {
                // Resolve RHS first (before defining the new binding for shadowing)
                let resolved_rhs = self.resolve_node(*rhs)?;
                let resolved_pat = self.resolve_pattern(pat)?;
                Ok(Resolved::Bind(span, resolved_pat, Box::new(resolved_rhs)))
            }

            Ast::SafeBind(span, pat, rhs, operator_span) => {
                // Resolve RHS first (before defining the new binding for shadowing)
                let resolved_rhs = self.resolve_node(*rhs)?;
                let resolved_pat = self.resolve_pattern(pat)?;
                Ok(Resolved::SafeBind(
                    span,
                    resolved_pat,
                    Box::new(resolved_rhs),
                 operator_span))
            }

            Ast::StatementQuestion(span, rhs) => Ok(Resolved::StatementQuestion(
                span,
                Box::new(self.resolve_node(*rhs)?),
            )),

            Ast::Do(span, return_type_arguments, statements, keyword_span) => {
                let resolved_contract = self.resolve_do_contract(&span, &keyword_span);
                let resolved_return_type_arguments = return_type_arguments
                    .into_iter()
                    .map(|argument| self.resolve_return_type_argument(argument))
                    .collect::<Result<Vec<_>, _>>()?;
                let resolved_statements = self.with_child_scope(|child| {
                    statements
                        .into_iter()
                        .map(|statement| match statement {
                            AstDoStatement::Extract {
                                span,
                                operator_span,
                                pattern,
                                rhs,
                            } => {
                                let pattern_span = do_pattern_span(&pattern);
                                let resolved_rhs = child.resolve_node(rhs)?;
                                let resolved_pattern = child.resolve_pattern(pattern)?;
                                Ok(ResolvedDoStatement::Extract {
                                    span,
                                    operator_span,
                                    pattern_span,
                                    pattern: resolved_pattern,
                                    rhs: resolved_rhs,
                                })
                            }
                            AstDoStatement::SafeBind {
                                span,
                                operator_span,
                                pattern,
                                rhs,
                            } => {
                                let pattern_span = do_pattern_span(&pattern);
                                let resolved_rhs = child.resolve_node(rhs)?;
                                let resolved_pattern = child.resolve_pattern(pattern)?;
                                Ok(ResolvedDoStatement::SafeBind {
                                    span,
                                    operator_span,
                                    pattern_span,
                                    pattern: resolved_pattern,
                                    rhs: resolved_rhs,
                                })
                            }
                            AstDoStatement::Statement(statement) => Ok(
                                ResolvedDoStatement::Statement(child.resolve_node(statement)?),
                            ),
                        })
                        .collect::<Result<Vec<_>, ResolveError>>()
                })?;
                Ok(Resolved::Do(
                    span,
                    sindr::intrinsic::do_intrinsic_contract().identity,
                    resolved_contract,
                    resolved_return_type_arguments,
                    resolved_statements,
                ))
            }

            Ast::BinOp(span, op, left, right) => {
                let l = self.resolve_node(*left)?;
                let r = self.resolve_node(*right)?;
                Ok(Resolved::BinOp(span, op, Box::new(l), Box::new(r)))
            }

            Ast::Pipe(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let rhs = self.prepare_pipe_rhs(*right)?;
                let r = self.resolve_node(rhs)?;
                Ok(Resolved::Pipe(span, Box::new(l), Box::new(r)))
            }

            Ast::ContextMap(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let rhs = self.prepare_pipe_rhs(*right)?;
                let r = self.resolve_node(rhs)?;
                Ok(Resolved::ContextMap(span, Box::new(l), Box::new(r)))
            }

            Ast::ContextApply(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let r = self.resolve_node(*right)?;
                Ok(Resolved::ContextApply(span, Box::new(l), Box::new(r)))
            }

            Ast::ContextBind(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let rhs = self.prepare_pipe_rhs(*right)?;
                let r = self.resolve_node(rhs)?;
                Ok(Resolved::ContextBind(span, Box::new(l), Box::new(r)))
            }

            Ast::Compose(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let r = self.resolve_node(*right)?;
                Ok(Resolved::Compose(span, Box::new(l), Box::new(r)))
            }

            Ast::LiftedCompose(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let r = self.resolve_node(*right)?;
                Ok(Resolved::LiftedCompose(span, Box::new(l), Box::new(r)))
            }

            Ast::KleisliCompose(span, left, right) => {
                let l = self.resolve_node(*left)?;
                let r = self.resolve_node(*right)?;
                Ok(Resolved::KleisliCompose(span, Box::new(l), Box::new(r)))
            }

            Ast::ListNil(span) => Ok(Resolved::ListNil(span)),

            Ast::ListCons(span, head, tail) => {
                let head = self.resolve_node(*head)?;
                let tail = self.resolve_node(*tail)?;
                Ok(Resolved::ListCons(span, Box::new(head), Box::new(tail)))
            }

            Ast::ListLiteral(span, elems) => {
                let resolved = elems
                    .into_iter()
                    .map(|e| self.resolve_node(e))
                    .collect::<Result<Vec<_>, _>>()?;
                Ok(Resolved::ListLiteral(span, resolved))
            }

            Ast::HashMapLiteral(span, entries) => {
                let resolved = entries
                    .into_iter()
                    .map(|entry| {
                        Ok(crate::resolved::ResolvedHashMapLiteralEntry {
                            key: self.resolve_node(entry.key)?,
                            value: self.resolve_node(entry.value)?,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::HashMapLiteral(span, resolved))
            }

            Ast::RangeLiteral(span, start, stop) => {
                let start = self.resolve_node(*start)?;
                let stop = self.resolve_node(*stop)?;
                Ok(Resolved::RangeLiteral(
                    span,
                    Box::new(start),
                    Box::new(stop),
                ))
            }

            Ast::TupleLiteral(span, elems) => {
                let resolved = elems
                    .into_iter()
                    .map(|e| self.resolve_node(e))
                    .collect::<Result<Vec<_>, _>>()?;
                Ok(Resolved::TupleLiteral(span, resolved))
            }

            Ast::Grouped(span, inner) => {
                let inner = self.resolve_node(*inner)?;
                Ok(Resolved::Grouped(span, Box::new(inner)))
            }

            Ast::InterpolatedStr(span, parts) => {
                let mut resolved_parts = Vec::new();
                for part in parts {
                    match part {
                        spire::ast::InterpolatedPart::Text(s) => {
                            resolved_parts.push(ResolvedInterpolatedPart::Text(s));
                        }
                        spire::ast::InterpolatedPart::Expr(expr) => {
                            let resolved_expr = self.resolve_node(*expr)?;
                            resolved_parts
                                .push(ResolvedInterpolatedPart::Expr(Box::new(resolved_expr)));
                        }
                    }
                }
                Ok(Resolved::InterpolatedStr(span, resolved_parts))
            }
            Ast::Dbg(span, args) => Ok(Resolved::Dbg(
                span,
                args.into_iter()
                    .map(|arg| self.resolve_node(arg.expr))
                    .collect::<Result<Vec<_>, _>>()?,
            )),

            Ast::BulkUpdate(span, source, entries) => {
                self.lower_bulk_update_special_form(span, *source, entries)
            }

            Ast::FieldAccess(span, expr, field) => {
                let original = Ast::FieldAccess(span.clone(), expr.clone(), field.clone());
                if let Some(segments) = Self::inferred_facet_capture_segments(&original) {
                    return Ok(Resolved::InferredFacetCapture(
                        span,
                        self.resolve_facet_path_segments(segments)?,
                    ));
                }
                if matches!(expr.as_ref(), Ast::Var(_, name) if name == "ctx") {
                    return Ok(Resolved::ProcessContextHandler(span, field));
                }
                if let Ast::Var(root_span, name) = expr.as_ref() {
                    if let Some((unique_id, symbol_info)) = synthetic_member_root(name) {
                        let root = Resolved::Var(
                            root_span.clone(),
                            ResolvedId {
                                name: name.clone(),
                                qualified_name: None,
                                unique_id,
                                compiler_generated: true,
                                symbol_info: Some(symbol_info),
                                span: root_span.clone(),
                            },
                        );
                        return Ok(Resolved::FieldAccess(span, Box::new(root), field));
                    }
                }
                let resolved_expr = self.resolve_facet_root_node(*expr)?;
                Ok(Resolved::FieldAccess(span, Box::new(resolved_expr), field))
            }
            Ast::FacetSegmentAccess(span, expr, segment) => {
                let original = Ast::FacetSegmentAccess(span.clone(), expr.clone(), segment.clone());
                if let Some(segments) = Self::inferred_facet_capture_segments(&original) {
                    return Ok(Resolved::InferredFacetCapture(
                        span,
                        self.resolve_facet_path_segments(segments)?,
                    ));
                }
                let resolved_expr = self.resolve_node(*expr)?;
                Ok(Resolved::FacetSegmentAccess(
                    span,
                    Box::new(resolved_expr),
                    self.resolve_facet_path_segment(segment)?,
                ))
            }
            Ast::FacetCapture(span, expr) => {
                let resolved_expr = self.resolve_node(*expr)?;
                Ok(Resolved::FacetCapture(span, Box::new(resolved_expr)))
            }

            Ast::Semi(span, inner) => {
                let resolved = self.resolve_node(*inner)?;
                Ok(Resolved::Semi(span, Box::new(resolved)))
            }

            Ast::Cond(span, clauses) => Ok(Resolved::Cond(
                span,
                clauses
                    .into_iter()
                    .map(|(condition, body)| {
                        Ok((self.resolve_node(condition)?, self.resolve_node(body)?))
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            Ast::Match(span, scrutinee, arms) => {
                let resolved_scrut = self.resolve_node(*scrutinee)?;
                let resolved_arms = arms
                    .into_iter()
                    .map(|arm| self.resolve_match_arm(arm))
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::Match(
                    span,
                    Box::new(resolved_scrut),
                    resolved_arms,
                ))
            }
            Ast::Namespace(span, _, _) => Err(ResolveError {
                message: "namespace declarations must be lowered before name resolution".into(),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::SupervisorInit(span, _) => Err(ResolveError {
                message: "supervisor_init must be collected before name resolution".into(),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            _ => unreachable!("resolve_node dispatched a non-expression node"),
        }
    }

    #[inline(never)]
    fn resolve_declaration_node(&mut self, node: Ast) -> Result<Resolved, ResolveError> {
        match node {
            // Struct/Record/Deferror definitions — reuse predeclared IDs
            Ast::StructDef(span, name, type_params, fields, attrs) => {
                let uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, uid);
                define_global_surface_alias(&mut self.scope, &name, uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                let symbol_info =
                    self.symbol_info_for_declaration(&name, &DeclarationKind::Struct, None);
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_type_params = self.resolve_type_params(type_params)?;
                let rfields = fields
                    .into_iter()
                    .map(|f| {
                        Ok(ResolvedField {
                            id: None,
                            name: f.name,
                            ty: self.resolve_type_annotation(f.ty)?,
                            span: f.span,
                            visibility: f.visibility,
                            readonly: f.readonly || attrs.readonly,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::StructDef(
                    span,
                    rid,
                    resolved_type_params,
                    rfields,
                    resolve_decl_attrs(&attrs),
                ))
            }

            Ast::RecordDef(span, name, fields, attrs) => {
                let uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, uid);
                define_global_surface_alias(&mut self.scope, &name, uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                let symbol_info =
                    self.symbol_info_for_declaration(&name, &DeclarationKind::Record, None);
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let rfields = fields
                    .into_iter()
                    .map(|f| {
                        Ok(ResolvedField {
                            id: None,
                            name: f.name,
                            ty: self.resolve_type_annotation(f.ty)?,
                            span: f.span,
                            visibility: f.visibility,
                            readonly: f.readonly,
                        })
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::RecordDef(
                    span,
                    rid,
                    rfields,
                    resolve_decl_attrs(&attrs),
                ))
            }

            Ast::DeferrorDef(span, name, fields, show_expr, _) => {
                let uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, uid);
                define_global_surface_alias(&mut self.scope, &name, uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                let symbol_info =
                    self.symbol_info_for_declaration(&name, &DeclarationKind::Deferror, None);
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let mut error_scope = self.scope.child();
                error_scope.define_with_id("Self", uid);
                let mut rfields = Vec::new();
                for f in fields {
                    reject_special_variant_binding(&f.name, &f.span)?;
                    let uid = error_scope.reserve_id();
                    rfields.push(ResolvedField {
                        id: Some(ResolvedId {
                            name: f.name.clone(),
                            qualified_name: None,
                            unique_id: uid,
                            compiler_generated: false,
                            symbol_info: None,
                            span: f.span.clone(),
                        }),
                        name: f.name,
                        ty: self.resolve_type_annotation(f.ty)?,
                        span: f.span,
                        visibility: f.visibility,
                        readonly: f.readonly,
                    });
                }
                let mut show_resolver = Resolver::with_scope(error_scope);
                show_resolver.declaration_uids = self.declaration_uids.clone();
                show_resolver.declaration_entries = self.body_declaration_entries();
                show_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                show_resolver.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
                show_resolver.owner_registry = self.owner_registry.clone();
                show_resolver.current_module_path = self.current_module_path.clone();
                show_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                let resolved_show = show_resolver.resolve_node(*show_expr)?;
                self.scope.advance_next_id_to(show_resolver.scope.next_id());
                Ok(Resolved::DeferrorDef(
                    span,
                    rid,
                    rfields,
                    Box::new(resolved_show),
                ))
            }

            Ast::EnumDef(span, name, type_params, variants, attrs) => {
                let uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, uid);
                define_global_surface_alias(&mut self.scope, &name, uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                let symbol_info =
                    self.symbol_info_for_declaration(&name, &DeclarationKind::Enum, None);
                let rid = ResolvedId {
                    name: name.clone(),
                    qualified_name: Some(qualified_name),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_type_params = type_params
                    .into_iter()
                    .map(|param| self.resolve_type_param(param))
                    .collect::<Result<Vec<_>, ResolveError>>()?;

                let mut resolved_variants = Vec::new();
                for variant in variants {
                    let ctor_name = format!("{}::{}", name, variant.name);
                    let ctor_uid = self
                        .take_predeclared_id(&ctor_name)
                        .or_else(|| self.scope.lookup(&ctor_name))
                        .unwrap_or_else(|| self.scope.reserve_id());
                    self.scope.define_with_id(&ctor_name, ctor_uid);
                    define_global_surface_alias(&mut self.scope, &ctor_name, ctor_uid);
                    let qualified_ctor_name = self.qualify_current_declaration_name(&ctor_name);
                    let symbol_info = self.symbol_info_for_declaration(
                        &ctor_name,
                        &DeclarationKind::EnumVariant,
                        Some(&name),
                    );
                    resolved_variants.push(ResolvedEnumVariant {
                        id: ResolvedId {
                            name: ctor_name,
                            qualified_name: Some(qualified_ctor_name),
                            unique_id: ctor_uid,
                            compiler_generated: false,
                            symbol_info,
                            span: variant.span.clone(),
                        },
                        payload: variant
                            .payload
                            .into_iter()
                            .map(|ty| self.resolve_type_annotation(ty))
                            .collect::<Result<Vec<_>, ResolveError>>()?,
                        discriminant: variant.discriminant,
                        span: variant.span,
                    });
                }

                Ok(Resolved::EnumDef(
                    span,
                    rid,
                    resolved_type_params,
                    resolved_variants,
                    resolve_decl_attrs(&attrs),
                ))
            }

            Ast::Def(
                span,
                name,
                return_type_arguments,
                params,
                ret_ty,
                where_clause,
                body,
                attrs,
            ) => {
                let fun_uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                let mut body_scope = self.inherent_impl_body_scope(&name, &span)?;
                // Ensure self-recursion inside this definition binds to this declaration,
                // not to a newer same-name declaration predeclared later in the chunk.
                body_scope.define_with_id(&name, fun_uid);
                let mut body_resolver = Resolver::with_scope(body_scope);
                body_resolver.declaration_uids = self.declaration_uids.clone();
                body_resolver.declaration_entries = self.body_declaration_entries();
                body_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                body_resolver.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
                body_resolver.trait_constructor_slots = self.trait_constructor_slots.clone();
                body_resolver.owner_registry = self.owner_registry.clone();
                body_resolver.current_module_path = self.current_module_path.clone();
                body_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                if self.forbids_top_level_value_capture_in_defs() {
                    body_resolver.forbidden_top_level_value_bindings =
                        self.top_level_value_bindings();
                    body_resolver.current_top_level_def_name = Some(name.clone());
                }
                let resolved_return_type_arguments = return_type_arguments
                    .into_iter()
                    .map(|argument| self.resolve_return_type_argument(argument))
                    .collect::<Result<Vec<_>, _>>()?;
                let resolved_params = body_resolver.resolve_value_parameters(params)?;
                let resolved_body = body_resolver.resolve_node(*body)?;

                self.scope.advance_next_id_to(body_resolver.scope.next_id());
                self.scope.define_with_id(&name, fun_uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                define_global_surface_alias(&mut self.scope, &qualified_name, fun_uid);
                let symbol_info = self.symbol_info_for_declaration(
                    &name,
                    &DeclarationKind::Def,
                    self.current_module_path.as_deref(),
                );
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: fun_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };

                Ok(Resolved::Def(
                    span,
                    rid,
                    resolved_return_type_arguments,
                    resolved_params,
                    ret_ty
                        .map(|ty| self.resolve_signature_type(ty))
                        .transpose()?,
                    where_clause
                        .map(|clause| self.resolve_where_clause(clause))
                        .transpose()?,
                    Box::new(resolved_body),
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::ConstDef(span, name, ty, value, attrs) => {
                let uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                let resolved_value = self.resolve_node(*value)?;
                self.scope.define_with_id(&name, uid);
                let qualified_name = if attrs.visibility == Visibility::Public {
                    Some(self.qualify_current_declaration_name(&name))
                } else {
                    Some(self.qualify_current_declaration_name(&format!("__const__::{}", name)))
                };
                if let Some(qualified_name) = qualified_name.as_deref() {
                    define_global_surface_alias(&mut self.scope, qualified_name, uid);
                }
                let owner_name = if attrs.visibility == Visibility::Public {
                    name.as_str()
                } else {
                    qualified_name.as_deref().unwrap_or(&name)
                };
                let symbol_info =
                    self.symbol_info_for_declaration(owner_name, &DeclarationKind::Const, None);
                let rid = ResolvedId {
                    name,
                    qualified_name,
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                Ok(Resolved::ConstDef(
                    span,
                    rid,
                    ty.map(|ty| self.resolve_type_annotation(ty)).transpose()?,
                    Box::new(resolved_value),
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::ExtractorDef(span, name, type_params, param, ret_ty, body, attrs) => {
                let fun_uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                let mut body_scope = self.inherent_impl_body_scope(&name, &span)?;
                body_scope.define_with_id(&name, fun_uid);
                let mut body_resolver = Resolver::with_scope(body_scope);
                body_resolver.declaration_uids = self.declaration_uids.clone();
                body_resolver.declaration_entries = self.body_declaration_entries();
                body_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                body_resolver.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
                body_resolver.owner_registry = self.owner_registry.clone();
                body_resolver.current_module_path = self.current_module_path.clone();
                body_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                let resolved_type_params = self.resolve_type_params(type_params)?;
                let resolved_param = param
                    .into_iter()
                    .map(|param| body_resolver.resolve_extractor_param(param))
                    .collect::<Result<Vec<_>, _>>()?;
                let resolved_body = body_resolver.resolve_node(*body)?;

                self.scope.advance_next_id_to(body_resolver.scope.next_id());
                self.scope.define_with_id(&name, fun_uid);
                let qualified_name = self.qualify_current_declaration_name(&name);
                define_global_surface_alias(&mut self.scope, &qualified_name, fun_uid);
                let symbol_info = self.symbol_info_for_declaration(
                    &name,
                    &DeclarationKind::Extractor,
                    self.current_module_path.as_deref(),
                );
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: fun_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };

                Ok(Resolved::ExtractorDef(
                    span,
                    rid,
                    resolved_type_params,
                    resolved_param,
                    self.resolve_type_annotation(ret_ty)?,
                    Box::new(resolved_body),
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::TraitDef(span, name, type_params, where_clause, methods, attrs) => {
                let qualified_trait_name = self.qualify_current_declaration_name(&name);
                let trait_uid = self
                    .take_predeclared_id(&name)
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, trait_uid);
                let symbol_info =
                    self.symbol_info_for_declaration(&name, &DeclarationKind::Trait, None);
                let rid = ResolvedId {
                    name: name.clone(),
                    qualified_name: Some(qualified_trait_name.clone()),
                    unique_id: trait_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_type_params = self.resolve_type_params(type_params)?;
                let mut method_headers = Vec::new();
                for method in &methods {
                    let method_alias = trait_method_qualified_name(&name, &method.name);
                    let qualified_method =
                        trait_method_qualified_name(&qualified_trait_name, &method.name);
                    let method_uid = self
                        .take_predeclared_id(&method_alias)
                        .or_else(|| self.scope.lookup(&method_alias))
                        .unwrap_or_else(|| self.scope.reserve_id());
                    self.scope.define_with_id(&method_alias, method_uid);
                    method_headers.push((method.name.clone(), method_uid, qualified_method));
                }

                let mut trait_method_scope = self.scope.child();
                for (method_name, method_uid, _) in &method_headers {
                    trait_method_scope.define_with_id(method_name, *method_uid);
                }

                let mut resolved_methods = Vec::new();
                for (method, (_, method_uid, qualified_method)) in
                    methods.into_iter().zip(method_headers.into_iter())
                {
                    let spire::ast::TraitMethodSig {
                        name: method_name,
                        return_type_arguments,
                        type_params,
                        value_parameters: params,
                        ret_ty,
                        where_clause,
                        body,
                        attrs,
                        span: method_span,
                    } = method;
                    let mut method_resolver = Resolver::with_scope(trait_method_scope.child());
                    method_resolver.declaration_uids = self.declaration_uids.clone();
                    method_resolver.declaration_entries = self.body_declaration_entries();
                    method_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                    method_resolver.declaration_hidden_by_uid =
                        self.declaration_hidden_by_uid.clone();
                    method_resolver.trait_constructor_slots = self.trait_constructor_slots.clone();
                    method_resolver.owner_registry = self.owner_registry.clone();
                    method_resolver.current_module_path = self.current_module_path.clone();
                    method_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                    let resolved_params = method_resolver.resolve_value_parameters(params)?;
                    let resolved_body = body
                        .map(|body| method_resolver.resolve_node(*body).map(Box::new))
                        .transpose()?;
                    self.scope
                        .advance_next_id_to(method_resolver.scope.next_id());
                    let symbol_info = self.symbol_info_for_declaration(
                        &qualified_method,
                        &DeclarationKind::TraitMethod,
                        Some(&name),
                    );
                    resolved_methods.push(ResolvedTraitMethodSig {
                        id: ResolvedId {
                            name: method_name,
                            qualified_name: Some(qualified_method),
                            unique_id: method_uid,
                            compiler_generated: false,
                            symbol_info,
                            span: method_span.clone(),
                        },
                        return_type_arguments: return_type_arguments
                            .into_iter()
                            .map(|argument| self.resolve_return_type_argument(argument))
                            .collect::<Result<Vec<_>, _>>()?,
                        type_params: self.resolve_type_params(type_params)?,
                        value_parameters: resolved_params,
                        ret_ty: self.resolve_signature_type(ret_ty)?,
                        where_clause: where_clause
                            .map(|clause| self.resolve_where_clause(clause))
                            .transpose()?,
                        body: resolved_body,
                        attrs: resolve_decl_attrs(&attrs),
                        span: method_span,
                    });
                }
                Ok(Resolved::TraitDef(
                    span,
                    rid,
                    resolved_type_params,
                    where_clause
                        .map(|clause| self.resolve_where_clause(clause))
                        .transpose()?,
                    resolved_methods,
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::TraitImplDef(
                span,
                trait_name,
                trait_args,
                target_ty,
                where_clause,
                methods,
                attrs,
            ) => {
                let impl_declaration_name = trait_impl_declaration_qualified_name(
                    self.current_module_path.as_deref(),
                    &trait_name,
                    &trait_args,
                    &target_ty,
                    span.start,
                );
                let impl_declaration_id = self
                    .take_predeclared_id(&impl_declaration_name)
                    .unwrap_or_else(|| self.reserve_declaration_uid(&impl_declaration_name));
                validate_unique_callable_names(
                    &format!(
                        "impl `{}` for `{}`",
                        trait_instance_key(&trait_name, &trait_args),
                        ast_ty_key(&target_ty)
                    ),
                    &methods,
                )?;
                let (trait_uid, qualified_trait_name) =
                    self.resolve_trait_reference(&trait_name, &span)?;
                let trait_symbol_info =
                    self.symbol_info_for_declaration(&trait_name, &DeclarationKind::Trait, None);
                let trait_id = ResolvedId {
                    name: trait_name.clone(),
                    qualified_name: Some(qualified_trait_name.clone()),
                    unique_id: trait_uid,
                    compiler_generated: attrs.compiler_generated,
                    symbol_info: trait_symbol_info,
                    span: span.clone(),
                };
                for method in &methods {
                    if let Ast::Def(method_span, method_name, ..)
                    | Ast::BuiltinDecl(method_span, method_name, ..) = method
                    {
                        super::declarations::validate_reserved_trait_method(
                            &qualified_trait_name,
                            method_name,
                            method_span,
                        )?;
                    }
                }
                let resolved_target_ty = self.resolve_type_annotation(target_ty)?;
                let target_key = ast_ty_key(&resolved_target_ty);
                let target_owner_key =
                    ast_ty_owner_head(&resolved_target_ty).unwrap_or(target_key.as_str());
                let mut resolved_methods = Vec::new();
                for method in methods {
                    let (
                        method_span,
                        method_name,
                        type_params,
                        return_type_arguments,
                        params,
                        ret_ty,
                        method_where_clause,
                        body,
                        attrs,
                        is_builtin,
                    ) = match method {
                        Ast::Def(
                            method_span,
                            method_name,
                            return_type_arguments,
                            params,
                            ret_ty,
                            method_where_clause,
                            body,
                            attrs,
                        ) => (
                            method_span,
                            method_name,
                            Vec::new(),
                            return_type_arguments,
                            params,
                            ret_ty,
                            method_where_clause,
                            Some(body),
                            attrs,
                            false,
                        ),
                        Ast::BuiltinDecl(
                            method_span,
                            method_name,
                            return_type_arguments,
                            params,
                            ret_ty,
                            method_where_clause,
                            attrs,
                        ) => (
                            method_span,
                            method_name,
                            Vec::new(),
                            return_type_arguments,
                            params,
                            ret_ty,
                            method_where_clause,
                            None,
                            attrs,
                            true,
                        ),
                        _ => {
                            return Err(ResolveError {
                                message:
                                    "trait impl body may only contain `def` / `@builtin def` declarations"
                                        .to_string(),
                                span: span.clone(),
                                diagnostic: crate::error::ResolveErrorDiagnostic { reason: crate::error::ResolveErrorReason::Declaration, subject: None },
                                related_labels: Vec::new(),
                            });
                        }
                    };
                    // Surface `::<...>` slots live on the declaration itself.
                    // Compiler-generated impls retain their slots in declaration
                    // attributes, so use those only when no surface list exists.
                    let return_type_arguments = if return_type_arguments.is_empty() {
                        attrs
                            .return_type_arguments
                            .clone()
                            .into_iter()
                            .map(|mut argument| {
                                if matches!(&argument.ty, AstTy::Named(_, name) if name == "Self") {
                                    argument.ty = resolved_target_ty.clone();
                                }
                                argument
                            })
                            .collect()
                    } else {
                        return_type_arguments
                    };
                    let return_type_arguments = return_type_arguments
                        .into_iter()
                        .map(|argument| self.resolve_return_type_argument(argument))
                        .collect::<Result<Vec<_>, _>>()?;
                    let qualified_function_name = trait_impl_method_qualified_name(
                        self.current_module_path.as_deref(),
                        &trait_name,
                        &trait_args,
                        &resolved_target_ty,
                        &method_name,
                        method_span.start,
                    );
                    let method_uid = self
                        .declaration_uids
                        .get(&qualified_function_name)
                        .copied()
                        .unwrap_or_else(|| self.scope.reserve_id());
                    let mut method_scope = self.scope.child();
                    // A trait method's bare self-name denotes its contract,
                    // just as in a default body. The call's types select the
                    // implementation; binding the concrete method here would
                    // prevent nested calls from selecting another receiver or
                    // return type argument. Parameters/local bindings can still
                    // shadow this lexical alias below.
                    let contract_name =
                        trait_method_qualified_name(&qualified_trait_name, &method_name);
                    if let Some(contract_uid) = self.declaration_uids.get(&contract_name) {
                        method_scope.define_with_id(&method_name, *contract_uid);
                    }
                    // Only declared trait members introduce a self-name alias.
                    let mut method_resolver = Resolver::with_scope(method_scope);
                    method_resolver.declaration_uids = self.declaration_uids.clone();
                    method_resolver.declaration_entries = self.body_declaration_entries();
                    method_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                    method_resolver.declaration_hidden_by_uid =
                        self.declaration_hidden_by_uid.clone();
                    method_resolver.trait_constructor_slots = self.trait_constructor_slots.clone();
                    method_resolver.owner_registry = self.owner_registry.clone();
                    method_resolver.current_module_path = self.current_module_path.clone();
                    method_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                    // Resolve the entire declaration signature before introducing
                    // value bindings or walking the executable body. A value or
                    // local named like a Trait must not affect type-position
                    // canonical identity.
                    let resolved_ret_ty = ret_ty
                        .map(|ty| method_resolver.resolve_signature_type(ty))
                        .transpose()?;
                    let resolved_method_where_clause = method_where_clause
                        .map(|clause| method_resolver.resolve_where_clause(clause))
                        .transpose()?;
                    let resolved_params = method_resolver.resolve_value_parameters(params)?;
                    let resolved_body = if let Some(body) = body {
                        method_resolver.resolve_node(*body)?
                    } else {
                        Resolved::Lit(method_span.clone(), spire::ast::Lit::Unit)
                    };
                    self.scope
                        .advance_next_id_to(method_resolver.scope.next_id());
                    let local_function_name = if trait_args.is_empty() {
                        format!("{}::{}", target_key, method_name)
                    } else {
                        format!(
                            "{}::{}::{}",
                            trait_instance_key(&qualified_trait_name, &trait_args),
                            target_key,
                            method_name
                        )
                    };
                    let symbol_info = self.symbol_info_for_declaration(
                        &local_function_name,
                        &DeclarationKind::ImplMethod,
                        Some(target_owner_key),
                    );

                    resolved_methods.push(ResolvedTraitImplMethod {
                        method_name: method_name.clone(),
                        function_id: ResolvedId {
                            name: local_function_name,
                            qualified_name: Some(qualified_function_name),
                            unique_id: method_uid,
                            compiler_generated: attrs.compiler_generated,
                            symbol_info,
                            span: method_span.clone(),
                        },
                        return_type_arguments,
                        type_params: self.resolve_type_params(type_params)?,
                        value_parameters: resolved_params,
                        ret_ty: resolved_ret_ty,
                        where_clause: resolved_method_where_clause,
                        body: Box::new(resolved_body),
                        attrs: resolve_decl_attrs(&attrs),
                        span: method_span,
                        is_builtin,
                    });
                }

                Ok(Resolved::TraitImplDef(
                    span,
                    impl_declaration_id,
                    trait_id,
                    trait_args
                        .into_iter()
                        .map(|arg| self.resolve_type_annotation(arg))
                        .collect::<Result<Vec<_>, _>>()?,
                    resolved_target_ty,
                    where_clause
                        .map(|clause| self.resolve_where_clause(clause))
                        .transpose()?,
                    resolved_methods,
                ))
            }

            Ast::BuiltinDecl(
                span,
                name,
                return_type_arguments,
                params,
                ret_ty,
                where_clause,
                attrs,
            ) => {
                let qualified_name = self.qualify_current_declaration_name(&name);
                super::declarations::validate_reserved_callable_declaration(
                    &qualified_name,
                    &span,
                )?;
                let declared_name = name.rsplit("::").next().unwrap_or(&name);
                let is_surface_builtin =
                    sindr::builtin::builtin_meta_for_decl(declared_name, Some(&qualified_name))
                        .is_some();
                let is_generated_runtime_builtin = attrs.compiler_generated
                    && sindr::builtin::builtin_meta_for_compiler_generated_decl(
                        declared_name,
                        &qualified_name,
                    )
                    .is_some();
                if !is_runtime_builtin_decl(&name)
                    && !is_special_form_builtin_decl(&name, &qualified_name)
                    && !is_surface_builtin
                    && !is_generated_runtime_builtin
                {
                    return Err(ResolveError {
                        message: format!("Unknown builtin declaration: {}", name),
                        span,
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::Declaration,
                            subject: Some(name.clone()),
                        },
                        related_labels: Vec::new(),
                    });
                }

                let builtin_uid = self
                    .take_predeclared_id(&qualified_name)
                    .or_else(|| self.take_predeclared_id(&name))
                    .or_else(|| self.declaration_uids.get(&qualified_name).copied())
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                let mut decl_resolver = Resolver::with_scope(self.scope.child());
                decl_resolver.declaration_uids = self.declaration_uids.clone();
                decl_resolver.declaration_entries = self.body_declaration_entries();
                decl_resolver.declaration_uid_kinds = self.declaration_uid_kinds.clone();
                decl_resolver.declaration_hidden_by_uid = self.declaration_hidden_by_uid.clone();
                decl_resolver.trait_constructor_slots = self.trait_constructor_slots.clone();
                decl_resolver.owner_registry = self.owner_registry.clone();
                decl_resolver.current_module_path = self.current_module_path.clone();
                decl_resolver.allow_top_level_shadowing = self.allow_top_level_shadowing;
                let resolved_params = decl_resolver.resolve_value_parameters(params)?;
                self.scope.advance_next_id_to(decl_resolver.scope.next_id());
                self.scope.define_with_id(&name, builtin_uid);
                define_global_surface_alias(&mut self.scope, &qualified_name, builtin_uid);
                let symbol_info = self.symbol_info_for_declaration(
                    &name,
                    &DeclarationKind::Def,
                    self.current_module_path.as_deref(),
                );
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: builtin_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_return_type_arguments = return_type_arguments
                    .into_iter()
                    .map(|argument| self.resolve_return_type_argument(argument))
                    .collect::<Result<Vec<_>, _>>()?;
                Ok(Resolved::BuiltinDecl(
                    span,
                    rid,
                    resolved_return_type_arguments,
                    resolved_params,
                    ret_ty
                        .map(|ty| self.resolve_signature_type(ty))
                        .transpose()?,
                    where_clause
                        .map(|clause| self.resolve_where_clause(clause))
                        .transpose()?,
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::BuiltinReflectionDecl(span, value, _) => Err(ResolveError {
                message: format!(
                    "builtin value declaration {} must not reach resolution",
                    value.name()
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::IntrinsicDecl(span, name, _, _) => Err(ResolveError {
                message: format!(
                    "Intrinsic declaration `{name}` is docs-only and should not reach resolution"
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::BuiltinExtractorDecl(span, name, param, ret_ty, attrs) => {
                let qualified_name = self.qualify_current_declaration_name(&name);
                let uid = self
                    .take_predeclared_id(&qualified_name)
                    .or_else(|| self.take_predeclared_id(&name))
                    .or_else(|| self.declaration_uids.get(&qualified_name).copied())
                    .or_else(|| self.scope.lookup(&name))
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&name, uid);
                let symbol_info = self.symbol_info_for_declaration(
                    &name,
                    &DeclarationKind::Extractor,
                    self.current_module_path.as_deref(),
                );
                let rid = ResolvedId {
                    name,
                    qualified_name: Some(qualified_name),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_param = param
                    .into_iter()
                    .map(|param| self.resolve_extractor_param(param))
                    .collect::<Result<Vec<_>, _>>()?;
                Ok(Resolved::BuiltinExtractorDecl(
                    span,
                    rid,
                    resolved_param,
                    self.resolve_type_annotation(ret_ty)?,
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::BuiltinTypeDecl(span, head, attrs) => {
                let builtin_type_uid = self
                    .take_predeclared_id(&head.name)
                    .unwrap_or_else(|| self.scope.reserve_id());
                self.scope.define_with_id(&head.name, builtin_type_uid);
                define_global_surface_alias(&mut self.scope, &head.name, builtin_type_uid);
                let qualified_name = self.qualify_current_declaration_name(&head.name);
                let symbol_info = self.symbol_info_for_declaration(
                    &head.name,
                    &DeclarationKind::BuiltinType,
                    None,
                );
                let rid = ResolvedId {
                    name: head.name,
                    qualified_name: Some(qualified_name),
                    unique_id: builtin_type_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                Ok(Resolved::BuiltinTypeDecl(
                    span,
                    rid,
                    head.params,
                    resolve_decl_attrs(&attrs),
                ))
            }
            Ast::TypeAlias(span, name, type_params, rhs) => {
                let symbol_info = self
                    .owner_registry
                    .owner_ref(&name)
                    .and_then(|owner| user_type_symbol_identity_info(&owner))
                    .expect("type aliases must have precollected owner metadata");
                Ok(Resolved::TypeAlias(
                    span,
                    name,
                    type_params
                        .into_iter()
                        .map(|param| ResolvedTypeParam {
                            name: param.name,
                            bound: param.bound,
                            span: param.span,
                        })
                        .collect(),
                    rhs,
                    symbol_info,
                ))
            }
            Ast::Defmod(span, name, _, _) => Err(ResolveError {
                message: format!("Module resolution is not implemented yet: {}", name),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::Defagent(span, name, _, _, _)
            | Ast::Defgenserver(span, name, _, _, _)
            | Ast::Defsupervisor(span, name, _, _, _)
            | Ast::DefdynamicSupervisor(span, name, _, _, _) => Err(ResolveError {
                message: format!("Process module resolution is not implemented yet: {}", name),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::Import(span, _, _) => Err(ResolveError {
                message: "Import resolution is not implemented yet".to_string(),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::Include(span, _) => Err(ResolveError {
                message: "include directives must be resolved before name resolution".to_string(),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),
            Ast::ImplDef(span, target, _, _, _) => Err(ResolveError {
                message: format!("impl lowering failed for target `{}`", target),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::CompilerInvariant,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),

            _ => unreachable!("resolve_node dispatched a non-declaration node"),
        }
    }

    #[inline(never)]
    fn resolve_callable_node(&mut self, node: Ast) -> Result<Resolved, ResolveError> {
        match node {
            Ast::Capture(span, target, args) => {
                let lazy_capture = self.lazy_capture_source(&target, &args)?;
                if matches!(target.as_ref(), Ast::PatternConsumerCall(..)) {
                    let max_index = self.validate_capture_placeholders(
                        &span,
                        std::slice::from_ref(target.as_ref()),
                    )?;
                    let body = self.rewrite_capture_placeholders(*target, &span, true, true)?;
                    let params = (1..=max_index)
                        .map(|index| ClosureParam {
                            name: Self::capture_placeholder_param_name(&span, index),
                            ty: None,
                            span: span.clone(),
                        })
                        .collect();
                    return match self.resolve_literal_closure(
                        span,
                        params,
                        Box::new(body),
                        false,
                        true,
                    )? {
                        Resolved::Closure(span, params, captures, body) => {
                            Ok(Resolved::CaptureClosure(
                                span,
                                Self::annotate_lazy_capture_params(params, lazy_capture.as_ref()),
                                captures,
                                body,
                            ))
                        }
                        _ => unreachable!("capture lowering must resolve to a closure"),
                    };
                }
                if let Some((policy, constructor_name)) =
                    self.capture_policy_for_ast_target(target.as_ref())
                {
                    match policy {
                        ConstructorCapturePolicy::Forbidden => {
                            return Err(ResolveError {
                                message: format!(
                                    "constructor capture is forbidden for `{constructor_name}`"
                                ),
                                span,
                                diagnostic: crate::error::ResolveErrorDiagnostic {
                                    reason: crate::error::ResolveErrorReason::ConstructorCaptureForbidden,
                                    subject: Some(constructor_name),
                                },
                                related_labels: Vec::new(),
                            });
                        }
                        ConstructorCapturePolicy::Ordinary if !args.is_empty() => {
                            let lowered =
                                self.lower_constructor_capture_expr(span.clone(), *target, args)?;
                            let Ast::Closure(closure_span, params, body) = lowered else {
                                unreachable!("constructor capture lowering must produce a closure")
                            };
                            return match self.resolve_literal_closure(
                                closure_span,
                                params,
                                body,
                                false,
                                true,
                            )? {
                                Resolved::Closure(closure_span, params, captures, body) => Ok(
                                    Resolved::CaptureClosure(closure_span, params, captures, body),
                                ),
                                other => Ok(other),
                            };
                        }
                        ConstructorCapturePolicy::Ordinary
                        | ConstructorCapturePolicy::CompilerManaged => {}
                    }
                }
                match self.lower_capture_expr(span.clone(), *target, args)? {
                    Ast::Capture(_, target, args) => {
                        let resolved_target = match *target {
                            Ast::Var(target_span, name) => {
                                self.resolve_declaration_var_like(target_span, name, false)?
                            }
                            Ast::Path(path_span, path) => self.resolve_declaration_var_like(
                                path_span,
                                path.segments.join("::"),
                                false,
                            )?,
                            target => self.resolve_node(target)?,
                        };
                        if args.is_empty() {
                            self.reject_bare_lazy_capture(&resolved_target, &span)?;
                        }
                        let resolved_args = args
                            .into_iter()
                            .map(|arg| self.resolve_node(arg))
                            .collect::<Result<Vec<_>, _>>()?;
                        Ok(Resolved::Capture(
                            span,
                            Box::new(resolved_target),
                            resolved_args,
                        ))
                    }
                    Ast::Closure(closure_span, params, body) => {
                        match self.resolve_literal_closure(
                            closure_span,
                            params,
                            body,
                            false,
                            true,
                        )? {
                            Resolved::Closure(span, params, captures, body) => {
                                Ok(Resolved::CaptureClosure(
                                    span,
                                    Self::annotate_lazy_capture_params(
                                        params,
                                        lazy_capture.as_ref(),
                                    ),
                                    captures,
                                    body,
                                ))
                            }
                            other => Ok(other),
                        }
                    }
                    lowered => self.resolve_node(lowered),
                }
            }

            Ast::CapturePlaceholder(span, index) => Err(ResolveError {
                message: format!(
                    "capture placeholder &{} must appear inside a capture call",
                    index
                ),
                span,
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::Capture,
                    subject: None,
                },
                related_labels: Vec::new(),
            }),

            Ast::StructLit(span, type_name, field_vals) => {
                let uid = self.scope.lookup(&type_name).ok_or_else(|| ResolveError {
                    message: format!("Undefined type: {}", type_name),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: Some(type_name.clone()),
                    },
                    related_labels: Vec::new(),
                })?;
                let symbol_info = self.symbol_info_for_uid(&type_name, uid);
                let rid = ResolvedId {
                    name: type_name,
                    qualified_name: None,
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_fields = field_vals
                    .into_iter()
                    .map(|field| match field {
                        StructLitField::Explicit(name, expr) => Ok(
                            ResolvedStructLitField::Explicit(name, self.resolve_node(expr)?),
                        ),
                        StructLitField::Shorthand(name) => Ok(ResolvedStructLitField::Shorthand(
                            name.clone(),
                            self.resolve_node(Ast::Var(span.clone(), name))?,
                        )),
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::StructLit(span, rid, resolved_fields))
            }

            Ast::InternalStructLit(span, type_name, field_vals) => {
                let uid = self.scope.lookup(&type_name).ok_or_else(|| ResolveError {
                    message: format!("Undefined type: {}", type_name),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: Some(type_name.clone()),
                    },
                    related_labels: Vec::new(),
                })?;
                let symbol_info = self.symbol_info_for_uid(&type_name, uid);
                let rid = ResolvedId {
                    name: type_name,
                    qualified_name: None,
                    unique_id: uid,
                    compiler_generated: true,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_fields = field_vals
                    .into_iter()
                    .map(|field| match field {
                        StructLitField::Explicit(name, expr) => Ok(
                            ResolvedStructLitField::Explicit(name, self.resolve_node(expr)?),
                        ),
                        StructLitField::Shorthand(name) => Ok(ResolvedStructLitField::Shorthand(
                            name.clone(),
                            self.resolve_node(Ast::Var(span.clone(), name))?,
                        )),
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::StructLit(span, rid, resolved_fields))
            }

            Ast::ConstructorCall(span, type_name, args) => {
                let type_name = sindr::names::special_enum_variant_surface_meta(&type_name)
                    .map(|meta| meta.qualified_name.to_string())
                    .unwrap_or(type_name);
                let normalized_name = {
                    // In ExprBlock, a struct head like `User(...)` dispatches to
                    // `User::new(...)` when that constructor exists.
                    let sugared = format!("{}::new", type_name);
                    if self.scope.lookup(&sugared).is_some() {
                        sugared
                    } else {
                        type_name
                    }
                };
                if let Some(uid) = self.scope.lookup(&normalized_name) {
                    if self
                        .declaration_uid_kinds
                        .get(&uid)
                        .is_some_and(|kind| matches!(kind, DeclarationKind::Const))
                    {
                        let qualified_name = self.declaration_fq_name_for_uid(uid);
                        let symbol_info = self.symbol_info_for_uid(&normalized_name, uid);
                        let rid = ResolvedId {
                            name: normalized_name,
                            qualified_name,
                            unique_id: uid,
                            compiler_generated: false,
                            symbol_info,
                            span: span.clone(),
                        };
                        if args.is_empty() {
                            return Ok(Resolved::Var(span, rid));
                        }
                        let resolved_args = args
                            .into_iter()
                            .map(|arg| match arg {
                                spire::ast::RecordLitArg::Positional(e) => {
                                    Ok(ResolvedRecordLitArg::Positional(self.resolve_node(e)?))
                                }
                                spire::ast::RecordLitArg::Named(name, e) => {
                                    Ok(ResolvedRecordLitArg::Named(name, self.resolve_node(e)?))
                                }
                            })
                            .collect::<Result<Vec<_>, ResolveError>>()?;
                        return Ok(Resolved::App(
                            span.clone(),
                            Box::new(Resolved::Var(span, rid)),
                            resolved_args,
                        ));
                    }
                }
                let uid = self
                    .scope
                    .lookup(&normalized_name)
                    .ok_or_else(|| ResolveError {
                        message: format!("Undefined type: {}", normalized_name),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: Some(normalized_name.clone()),
                        },
                        related_labels: Vec::new(),
                    })?;
                let symbol_info = self.symbol_info_for_uid(&normalized_name, uid);
                let rid = ResolvedId {
                    name: normalized_name,
                    qualified_name: self.declaration_fq_name_for_uid(uid),
                    unique_id: uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                // Only the selected Record declaration admits shorthand. Keep the
                // source expression shape until this point so qualified paths and
                // other expressions cannot be mistaken for bare variables.
                let named_record = self
                    .declaration_uid_kinds
                    .get(&uid)
                    .is_some_and(|kind| matches!(kind, DeclarationKind::Record))
                    && args
                        .iter()
                        .any(|arg| matches!(arg, RecordLitArg::Named(..)));
                let resolved_args = args
                    .into_iter()
                    .map(|arg| match arg {
                        RecordLitArg::Positional(Ast::Var(span, name)) if named_record => {
                            RecordLitArg::Named(name.clone(), Ast::Var(span, name))
                        }
                        other => other,
                    })
                    .map(|arg| match arg {
                        spire::ast::RecordLitArg::Positional(e) => {
                            Ok(ResolvedRecordLitArg::Positional(self.resolve_node(e)?))
                        }
                        spire::ast::RecordLitArg::Named(name, e) => {
                            Ok(ResolvedRecordLitArg::Named(name, self.resolve_node(e)?))
                        }
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::ConstructorCall(span, rid, resolved_args))
            }

            Ast::EnumConstructorCall(span, owner_name, type_args, variant_name, args) => {
                let _owner_uid = self.scope.lookup(&owner_name).ok_or_else(|| ResolveError {
                    message: format!("Undefined enum type: {owner_name}"),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: Some(owner_name.clone()),
                    },
                    related_labels: Vec::new(),
                })?;
                let owner = self
                    .owner_registry
                    .get(&owner_name)
                    .ok_or_else(|| ResolveError {
                        message: format!("{owner_name} is not a declared enum type"),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: Some(owner_name.clone()),
                        },
                        related_labels: Vec::new(),
                    })?;
                if owner.kind != OwnerKind::Enum {
                    return Err(ResolveError {
                        message: format!("{owner_name} is not an enum type"),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: Some(owner_name.clone()),
                        },
                        related_labels: Vec::new(),
                    });
                }
                let expected_arity = self
                    .owner_registry
                    .enum_type_parameter_arity(&owner.canonical_key)
                    .unwrap_or(0);
                if type_args.len() != expected_arity {
                    return Err(ResolveError {
                        message: format!(
                            "Enum constructor {owner_name} expects {expected_arity} type argument(s), got {}",
                            type_args.len()
                        ),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: Some(owner_name.clone()),
                        },
                        related_labels: Vec::new(),
                    });
                }

                let constructor_name = format!("{owner_name}::{variant_name}");
                let constructor_uid =
                    self.scope
                        .lookup(&constructor_name)
                        .ok_or_else(|| ResolveError {
                            message: format!(
                                "{variant_name} is not a declared enum variant of {owner_name}"
                            ),
                            span: span.clone(),
                            diagnostic: crate::error::ResolveErrorDiagnostic {
                                reason: crate::error::ResolveErrorReason::NameResolution,
                                subject: Some(constructor_name.clone()),
                            },
                            related_labels: Vec::new(),
                        })?;
                if self.declaration_uid_kinds.get(&constructor_uid)
                    != Some(&DeclarationKind::EnumVariant)
                {
                    return Err(ResolveError {
                        message: format!(
                            "{variant_name} is not a declared enum variant of {owner_name}"
                        ),
                        span: span.clone(),
                        diagnostic: crate::error::ResolveErrorDiagnostic {
                            reason: crate::error::ResolveErrorReason::NameResolution,
                            subject: Some(constructor_name.clone()),
                        },
                        related_labels: Vec::new(),
                    });
                }
                let symbol_info = self.symbol_info_for_uid(&constructor_name, constructor_uid);
                let constructor_id = ResolvedId {
                    name: constructor_name,
                    qualified_name: self.declaration_fq_name_for_uid(constructor_uid),
                    unique_id: constructor_uid,
                    compiler_generated: false,
                    symbol_info,
                    span: span.clone(),
                };
                let resolved_type_args = type_args
                    .into_iter()
                    .map(|ty| self.resolve_type_annotation(ty))
                    .collect::<Result<Vec<_>, _>>()?;
                let resolved_args = args
                    .into_iter()
                    .map(|arg| match arg {
                        spire::ast::RecordLitArg::Positional(expr) => {
                            Ok(ResolvedRecordLitArg::Positional(self.resolve_node(expr)?))
                        }
                        spire::ast::RecordLitArg::Named(name, expr) => {
                            Ok(ResolvedRecordLitArg::Named(name, self.resolve_node(expr)?))
                        }
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(Resolved::EnumConstructorCall(
                    span,
                    constructor_id,
                    resolved_type_args,
                    resolved_args,
                ))
            }

            _ => unreachable!("resolve_node dispatched a non-callable node"),
        }
    }

    pub(super) fn resolve_value_parameters(
        &mut self,
        params: Vec<ValueParameter>,
    ) -> Result<Vec<ResolvedValueParameter>, ResolveError> {
        let resolved_types = params
            .iter()
            .map(|param| self.resolve_signature_type(param.ty.clone()))
            .collect::<Result<Vec<_>, _>>()?;
        for param in &params {
            reject_special_variant_binding(&param.name, &param.span)?;
        }
        Ok(params
            .into_iter()
            .zip(resolved_types)
            .map(|(param, ty)| {
                let uid = self.scope.define(&param.name, param.span.clone());
                ResolvedValueParameter {
                    id: ResolvedId {
                        name: param.name,
                        qualified_name: None,
                        unique_id: uid,
                        compiler_generated: false,
                        symbol_info: None,
                        span: param.span.clone(),
                    },
                    mode: param.mode,
                    ty,
                    span: param.span,
                }
            })
            .collect())
    }

    fn resolve_return_type_argument(
        &self,
        argument: ReturnTypeArgument,
    ) -> Result<ResolvedReturnTypeArgument, ResolveError> {
        Ok(ResolvedReturnTypeArgument {
            ordinal: argument.ordinal,
            ty: self.resolve_signature_type(argument.ty)?,
            span: argument.span,
        })
    }

    pub(super) fn resolve_type_params(
        &self,
        type_params: Vec<spire::ast::TypeParam>,
    ) -> Result<Vec<ResolvedTypeParam>, ResolveError> {
        type_params
            .into_iter()
            .map(|param| self.resolve_type_param(param))
            .collect()
    }

    pub(super) fn resolve_extractor_param(
        &mut self,
        param: ExtractorParam,
    ) -> Result<ResolvedExtractorParam, ResolveError> {
        reject_special_variant_binding(&param.name, &param.span)?;
        let uid = self.scope.define(&param.name, param.span.clone());
        Ok(ResolvedExtractorParam {
            id: ResolvedId {
                name: param.name,
                qualified_name: None,
                unique_id: uid,
                compiler_generated: false,
                symbol_info: None,
                span: param.span,
            },
            ty: param
                .ty
                .map(|ty| self.resolve_type_annotation(ty))
                .transpose()?,
        })
    }

    fn resolve_type_param(
        &self,
        param: spire::ast::TypeParam,
    ) -> Result<ResolvedTypeParam, ResolveError> {
        Ok(ResolvedTypeParam {
            name: param.name,
            bound: param
                .bound
                .map(|bound| self.resolve_trait_bound_name(&bound, &param.span))
                .transpose()?,
            span: param.span,
        })
    }

    fn resolve_type_annotation(&self, ty: AstTy) -> Result<AstTy, ResolveError> {
        match ty {
            AstTy::Named(span, name) => Ok(AstTy::Named(span, name)),
            AstTy::ImplTrait(span, name) => Ok(AstTy::ImplTrait(
                span.clone(),
                self.resolve_trait_bound_name(&name, &span)?,
            )),
            AstTy::Generic(span, name, args) => Ok(AstTy::Generic(
                span,
                name,
                args.into_iter()
                    .map(|arg| self.resolve_type_annotation(arg))
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            AstTy::Tuple(span, items) => Ok(AstTy::Tuple(
                span,
                items
                    .into_iter()
                    .map(|item| self.resolve_type_annotation(item))
                    .collect::<Result<Vec<_>, ResolveError>>()?,
            )),
            AstTy::Func(span, params, ret) => Ok(AstTy::Func(
                span,
                params
                    .into_iter()
                    .map(|param| self.resolve_type_annotation(param))
                    .collect::<Result<Vec<_>, ResolveError>>()?,
                Box::new(self.resolve_type_annotation(*ret)?),
            )),
        }
    }

    fn resolve_signature_type(&self, ty: AstTy) -> Result<ResolvedSignatureTy, ResolveError> {
        let syntax = self.resolve_type_annotation(ty)?;
        let direct_constructor_trait = self.direct_constructor_trait_for_signature_type(&syntax);
        Ok(ResolvedSignatureTy {
            syntax,
            direct_constructor_trait,
        })
    }

    fn resolve_do_contract(&self, span: &Span, keyword_span: &Span) -> ResolvedDoContract {
        let resolve_trait = |identity: sindr::intrinsic::CanonicalTraitIdentity| {
            let name = identity.surface_name();
            let unique_id = self.declaration_uids.get(name).copied()?;
            if !matches!(
                self.declaration_uid_kinds.get(&unique_id),
                Some(DeclarationKind::Trait)
            ) {
                return None;
            }
            let qualified_name = self
                .declaration_fq_name_for_uid(unique_id)
                .unwrap_or_else(|| name.to_string());
            Some(ResolvedId {
                name: name.to_string(),
                qualified_name: Some(qualified_name),
                unique_id,
                compiler_generated: true,
                symbol_info: self.symbol_info_for_declaration(name, &DeclarationKind::Trait, None),
                span: span.clone(),
            })
        };
        ResolvedDoContract {
            keyword_span: keyword_span.clone(),
            monad_fail_trait: resolve_trait(sindr::intrinsic::CanonicalTraitIdentity::MonadFail),
            monad_trait: resolve_trait(sindr::intrinsic::CanonicalTraitIdentity::Monad),
            alternative_trait: resolve_trait(sindr::intrinsic::CanonicalTraitIdentity::Alternative),
        }
    }

    fn direct_constructor_trait_for_signature_type(&self, ty: &AstTy) -> Option<ResolvedId> {
        let (span, name) = match ty {
            AstTy::Named(span, name) | AstTy::Generic(span, name, _) => (span, name),
            AstTy::ImplTrait(_, _) | AstTy::Tuple(_, _) | AstTy::Func(_, _, _) => return None,
        };
        let unique_id = self.scope.lookup(name)?;
        if !matches!(
            self.declaration_uid_kinds.get(&unique_id),
            Some(DeclarationKind::Trait)
        ) || !self.trait_constructor_slots.contains_key(&unique_id)
        {
            return None;
        }
        let qualified_name = self
            .declaration_fq_name_for_uid(unique_id)
            .unwrap_or_else(|| name.clone());
        Some(ResolvedId {
            name: name.clone(),
            qualified_name: Some(qualified_name),
            unique_id,
            compiler_generated: false,
            symbol_info: self.symbol_info_for_declaration(name, &DeclarationKind::Trait, None),
            span: span.clone(),
        })
    }

    fn resolve_where_clause(
        &self,
        clause: spire::ast::WhereClause,
    ) -> Result<ResolvedWhereClause, ResolveError> {
        let constraints = clause
            .constraints
            .into_iter()
            .map(|constraint| {
                let subject = self.resolve_type_annotation(constraint.subject)?;
                let bounds = constraint
                    .bounds
                    .into_iter()
                    .map(|bound| match bound {
                        spire::ast::WhereConstraintRhs::Trait(span, name) => {
                            let (unique_id, qualified_name) =
                                self.resolve_trait_reference(&name, &span)?;
                            let symbol_info = self.symbol_info_for_declaration(
                                &name,
                                &DeclarationKind::Trait,
                                None,
                            );
                            Ok(ResolvedWhereConstraintRhs::Trait {
                                trait_id: ResolvedId {
                                    name,
                                    qualified_name: Some(qualified_name),
                                    unique_id,
                                    compiler_generated: false,
                                    symbol_info,
                                    span,
                                },
                            })
                        }
                        spire::ast::WhereConstraintRhs::TypeConstructor(span, slots) => {
                            Ok(ResolvedWhereConstraintRhs::TypeConstructor {
                                span,
                                slots: slots
                                    .into_iter()
                                    .map(|slot| self.resolve_type_annotation(slot))
                                    .collect::<Result<Vec<_>, _>>()?,
                            })
                        }
                        spire::ast::WhereConstraintRhs::TraitSlot(span, owner, slot_name) => {
                            let (unique_id, qualified_name) =
                                self.resolve_trait_reference(&owner, &span)?;
                            let symbol_info = self.symbol_info_for_declaration(
                                &owner,
                                &DeclarationKind::Trait,
                                None,
                            );
                            if symbol_info.as_ref().map(|info| info.identity)
                                != Some(TypeIdentity::TypeConstructor)
                            {
                                return Err(ResolveError {
                                    message: format!(
                                        "Trait {} is not a TypeConstructor trait",
                                        owner
                                    ),
                                    span,
                                    diagnostic: crate::error::ResolveErrorDiagnostic {
                                        reason: crate::error::ResolveErrorReason::NameResolution,
                                        subject: None,
                                    },
                                    related_labels: Vec::new(),
                                });
                            }
                            let slot_ordinal = self
                                .trait_constructor_slots
                                .get(&unique_id)
                                .and_then(|slots| slots.iter().position(|slot| slot == &slot_name))
                                .ok_or_else(|| ResolveError {
                                    message: format!(
                                        "Trait {} has no constructor slot {}",
                                        owner, slot_name
                                    ),
                                    span: span.clone(),
                                    diagnostic: crate::error::ResolveErrorDiagnostic {
                                        reason: crate::error::ResolveErrorReason::NameResolution,
                                        subject: None,
                                    },
                                    related_labels: Vec::new(),
                                })? as u32;
                            Ok(ResolvedWhereConstraintRhs::TraitSlot {
                                trait_id: ResolvedId {
                                    name: owner,
                                    qualified_name: Some(qualified_name),
                                    unique_id,
                                    compiler_generated: false,
                                    symbol_info,
                                    span: span.clone(),
                                },
                                slot_name,
                                slot_ordinal,
                                span,
                            })
                        }
                    })
                    .collect::<Result<Vec<_>, ResolveError>>()?;
                Ok(ResolvedWhereConstraint {
                    subject,
                    bounds,
                    span: constraint.span,
                })
            })
            .collect::<Result<Vec<_>, ResolveError>>()?;
        Ok(ResolvedWhereClause {
            constraints,
            span: clause.span,
        })
    }

    fn resolve_trait_reference(
        &self,
        trait_name: &str,
        span: &Span,
    ) -> Result<(u32, String), ResolveError> {
        let trait_uid = self.scope.lookup(trait_name).ok_or_else(|| ResolveError {
            message: format!("Undefined trait: {}", trait_name),
            span: span.clone(),
            diagnostic: crate::error::ResolveErrorDiagnostic {
                reason: crate::error::ResolveErrorReason::NameResolution,
                subject: None,
            },
            related_labels: Vec::new(),
        })?;
        match self.declaration_uid_kinds.get(&trait_uid) {
            Some(DeclarationKind::Trait) => {}
            _ => {
                return Err(ResolveError {
                    message: format!("{} is not a trait", trait_name),
                    span: span.clone(),
                    diagnostic: crate::error::ResolveErrorDiagnostic {
                        reason: crate::error::ResolveErrorReason::NameResolution,
                        subject: None,
                    },
                    related_labels: Vec::new(),
                });
            }
        }
        let qualified_name = self
            .declaration_fq_name_for_uid(trait_uid)
            .unwrap_or_else(|| trait_name.to_string());
        Ok((trait_uid, qualified_name))
    }

    fn resolve_trait_bound_name(
        &self,
        trait_name: &str,
        span: &Span,
    ) -> Result<String, ResolveError> {
        self.resolve_trait_reference(trait_name, span)
            .map(|(_, qualified_name)| qualified_name)
    }
}

pub(super) fn validate_trait_impl_pairs_in_nodes(
    resolved: &[Resolved],
) -> Result<(), ResolveError> {
    let mut seen_pairs: HashMap<String, (Span, bool)> = HashMap::new();
    for node in resolved {
        let Resolved::TraitImplDef(span, _, trait_id, trait_args, target_ty, _, _) = node else {
            continue;
        };
        let trait_name = trait_instance_key(
            trait_id.qualified_name.as_deref().unwrap_or(&trait_id.name),
            trait_args,
        );
        let pair_key = format!("{} for {}", trait_name, ast_ty_key(target_ty));
        if let Some((first_span, first_generated)) = seen_pairs.get(&pair_key) {
            return Err(ResolveError {
                message: if *first_generated || trait_id.compiler_generated {
                    format!("DerivedImplConflict: multiple trait impl blocks for `{pair_key}`")
                } else {
                    format!("Multiple trait impl blocks for `{pair_key}` are not allowed")
                },
                span: span.clone(),
                diagnostic: crate::error::ResolveErrorDiagnostic {
                    reason: crate::error::ResolveErrorReason::Declaration,
                    subject: None,
                },
                related_labels: vec![
                    ResolveErrorLabel {
                        span: first_span.clone(),
                        message: "first definition".to_string(),
                        source: None,
                    },
                    ResolveErrorLabel {
                        span: span.clone(),
                        message: "conflicting definition".to_string(),
                        source: None,
                    },
                ],
            });
        } else {
            seen_pairs.insert(
                pair_key.clone(),
                (span.clone(), trait_id.compiler_generated),
            );
        }
    }
    Ok(())
}

#[cfg(test)]
mod special_form_identity_tests {
    use super::*;

    #[test]
    fn autoimport_does_not_grant_special_form_identity() {
        let mut resolver = Resolver::new();
        let name = "Global::User::map_err".to_string();
        let uid = resolver.scope.define("map_err", Span { start: 0, end: 7 });
        Arc::make_mut(&mut resolver.declaration_uids).insert(name.clone(), uid);
        Arc::make_mut(&mut resolver.declaration_entries).insert(
            name.clone(),
            DeclarationEntry {
                module_path: "Global::User".into(),
                name: "map_err".into(),
                fq_name: name.clone(),
                kind: DeclarationKind::Def,
                stage_index: 0,
                registration_order: 0,
                auto_import: true,
                hidden: false,
                visibility: spire::ast::Visibility::Public,
                user_importable: true,
                user_callable: true,
                value_parameter_count: Some(2),
                lazy_parameters: Vec::new(),
            },
        );
        let callee = Resolved::Var(
            Span { start: 0, end: 7 },
            ResolvedId {
                name: "map_err".into(),
                qualified_name: Some(name),
                unique_id: uid,
                compiler_generated: false,
                symbol_info: None,
                span: Span { start: 0, end: 7 },
            },
        );
        assert!(resolver
            .classify_canonical_special_form_callee(&callee)
            .is_none());
    }

    #[test]
    fn missing_special_form_identity_keeps_the_callee_error() {
        let span = Span { start: 0, end: 2 };
        let mut resolver = Resolver::new();
        let call = Ast::App(
            span.clone(),
            Box::new(Ast::Var(span.clone(), "if".into())),
            (1..=3)
                .map(|value| {
                    RecordLitArg::Positional(Ast::Lit(
                        span.clone(),
                        spire::ast::Lit::Int(value.into()),
                    ))
                })
                .collect(),
        );
        let error = resolver
            .resolve_node(call)
            .expect_err("an unresolved callee must not become a special form");
        assert!(error.message.contains("Undefined"), "{}", error.message);
        assert_eq!(error.span, span);
    }
}

#[cfg(test)]
mod child_entry_tests {
    use super::*;

    #[test]
    fn body_declaration_entries_keep_extractors_and_lazy_contracts_and_isolate_updates() {
        let mut resolver = Resolver::new();
        let make_entry = |name: &str, kind| DeclarationEntry {
            module_path: "Test".into(),
            name: name.into(),
            fq_name: format!("Test::{name}"),
            kind,
            stage_index: 0,
            registration_order: 0,
            auto_import: false,
            hidden: false,
            visibility: spire::ast::Visibility::Public,
            user_importable: true,
            user_callable: true,
            value_parameter_count: None,
            lazy_parameters: Vec::new(),
        };
        resolver.declaration_entries = Arc::new(HashMap::from([
            (
                "Test::Match".into(),
                make_entry("Match", DeclarationKind::Extractor),
            ),
            (
                "Test::function".into(),
                make_entry("function", DeclarationKind::Def),
            ),
        ]));
        let mut lazy = make_entry("lazy", DeclarationKind::Def);
        lazy.lazy_parameters.push((0, "value".into()));
        Arc::make_mut(&mut resolver.declaration_entries).insert("Test::lazy".into(), lazy);
        let mut body = resolver.body_declaration_entries();
        assert_eq!(body.len(), 2);
        assert!(body.contains_key("Test::lazy"));
        assert!(body.contains_key("Test::Match"));
        assert!(!body.contains_key("Test::function"));
        Arc::make_mut(&mut body).insert(
            "Test::Nested".into(),
            make_entry("Nested", DeclarationKind::Extractor),
        );
        assert!(!resolver.declaration_entries.contains_key("Test::Nested"));
        assert_eq!(resolver.declaration_entries.len(), 3);
    }
}
