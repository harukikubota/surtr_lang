use sindr::ir::{DocEntry, DocKind, SignatureEntry};
use sindr::names::surface_path_name;
use spire::ast::{
    Ast, AstTy, BuiltinTypeHead, EnumVariant, ExtractorParam, RecordField, TraitMethodSig,
    TypeParam, ValueParameter, WhereClause, WhereConstraintRhs,
};

use crate::StagedModuleAst;

fn format_ast_ty(ty: &AstTy) -> String {
    match ty {
        AstTy::Named(_, name) => surface_path_name(name).to_string(),
        AstTy::ImplTrait(_, name) => format!("impl {}", surface_path_name(name)),
        AstTy::Generic(_, name, args) => {
            let args = args
                .iter()
                .map(format_ast_ty)
                .collect::<Vec<_>>()
                .join(", ");
            format!("{}<{args}>", surface_path_name(name))
        }
        AstTy::Tuple(_, items) => {
            let items = items
                .iter()
                .map(format_ast_ty)
                .collect::<Vec<_>>()
                .join(", ");
            format!("({items})")
        }
        AstTy::Func(_, params, ret) => {
            if params.is_empty() {
                format!("(-> {})", format_ast_ty(ret))
            } else {
                let params = params
                    .iter()
                    .map(format_ast_ty)
                    .collect::<Vec<_>>()
                    .join(", ");
                format!("({params} -> {})", format_ast_ty(ret))
            }
        }
    }
}

fn rewrite_self_ast_ty(ty: &AstTy, self_ty: &AstTy) -> AstTy {
    match ty {
        AstTy::Named(_, name) if name == "Self" => self_ty.clone(),
        AstTy::Named(_, _) | AstTy::ImplTrait(_, _) => ty.clone(),
        AstTy::Generic(span, name, args) => AstTy::Generic(
            span.clone(),
            name.clone(),
            args.iter()
                .map(|arg| rewrite_self_ast_ty(arg, self_ty))
                .collect(),
        ),
        AstTy::Tuple(span, items) => AstTy::Tuple(
            span.clone(),
            items
                .iter()
                .map(|item| rewrite_self_ast_ty(item, self_ty))
                .collect(),
        ),
        AstTy::Func(span, params, ret) => AstTy::Func(
            span.clone(),
            params
                .iter()
                .map(|param| rewrite_self_ast_ty(param, self_ty))
                .collect(),
            Box::new(rewrite_self_ast_ty(ret, self_ty)),
        ),
    }
}

fn format_type_params(type_params: &[TypeParam]) -> String {
    if type_params.is_empty() {
        String::new()
    } else {
        let params = type_params
            .iter()
            .map(|param| match &param.bound {
                Some(bound) => format!("{}: {}", param.name, bound),
                None => param.name.clone(),
            })
            .collect::<Vec<_>>()
            .join(", ");
        format!("<{params}>")
    }
}

fn format_fun_signature(
    name: &str,
    _type_params: &[TypeParam],
    params: &[ValueParameter],
    ret_ty: &Option<AstTy>,
) -> String {
    let params = params
        .iter()
        .map(|param| format!("{}: {}", param.name, format_ast_ty(&param.ty)))
        .collect::<Vec<_>>()
        .join(", ");
    match ret_ty {
        Some(ret) => format!("{name}({params}) -> {}", format_ast_ty(ret)),
        None => format!("{name}({params})"),
    }
}

fn format_extractor_signature(
    name: &str,
    _type_params: &[TypeParam],
    params: &[ExtractorParam],
    ret_ty: &AstTy,
) -> String {
    let param = params
        .iter()
        .map(|param| match &param.ty {
            Some(ty) => format!("{}: {}", param.name, format_ast_ty(ty)),
            None => param.name.clone(),
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("{name}({param}) -> {}", format_ast_ty(ret_ty))
}

fn format_builtin_type_signature(head: &BuiltinTypeHead) -> String {
    if head.params.is_empty() {
        format!("type {}", surface_path_name(&head.name))
    } else {
        format!(
            "type {}<{}>",
            surface_path_name(&head.name),
            head.params.join(", ")
        )
    }
}

fn format_deferror_signature(name: &str, fields: &[RecordField], body: &Ast) -> String {
    let header = if fields.is_empty() {
        format!("deferror {}", surface_path_name(name))
    } else {
        let fields = fields
            .iter()
            .map(|field| format!("{}: {}", field.name, format_ast_ty(&field.ty)))
            .collect::<Vec<_>>()
            .join(", ");
        format!("deferror {}({fields})", surface_path_name(name))
    };
    let Ast::Closure(_, parameters, _) = body else {
        unreachable!("deferror body is a block");
    };
    if parameters.is_empty() {
        return header;
    }
    let inputs = parameters
        .iter()
        .map(|parameter| match &parameter.ty {
            Some(ty) => format!("{}: {}", parameter.name, format_ast_ty(ty)),
            None => parameter.name.clone(),
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("{header} {{ |{inputs}| ... }}")
}

fn format_defenum_signature(name: &str, variants: &[EnumVariant]) -> String {
    if variants.is_empty() {
        return format!("defenum {}", surface_path_name(name));
    }
    let variants = variants
        .iter()
        .map(|variant| {
            if variant.payload.is_empty() {
                variant.name.clone()
            } else {
                let payload = variant
                    .payload
                    .iter()
                    .map(format_ast_ty)
                    .collect::<Vec<_>>()
                    .join(", ");
                format!("{}({payload})", variant.name)
            }
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("defenum {} {{ {variants} }}", surface_path_name(name))
}

fn builtin_special_enum_variant_signature(
    enum_name: &str,
    type_params: &[TypeParam],
    variant: &EnumVariant,
) -> Option<String> {
    let qualified_name = format!("{enum_name}::{}", variant.name);
    if let Some(meta) = sindr::names::special_enum_variant_meta(&qualified_name) {
        if variant.payload.len() != meta.payload_arity {
            return None;
        }
        use sindr::names::SpecialEnumVariantLowering;
        return match meta.lowering {
            SpecialEnumVariantLowering::ResultOk | SpecialEnumVariantLowering::ResultErr => {
                let [param] = type_params else { return None };
                let [payload] = variant.payload.as_slice() else {
                    return None;
                };
                Some(format!(
                    "{}({}) -> Result<{}>",
                    meta.qualified_name,
                    format_ast_ty(payload),
                    param.name
                ))
            }
            SpecialEnumVariantLowering::Boolean(_) if type_params.is_empty() => {
                Some(format!("{}() -> Boolean", meta.qualified_name))
            }
            SpecialEnumVariantLowering::Boolean(_) => None,
        };
    }
    match (surface_path_name(enum_name), variant.name.as_str()) {
        ("MatchResult", "Ok") => {
            let [payload] = variant.payload.as_slice() else {
                return None;
            };
            let payload = format_ast_ty(payload);
            Some(format!(
                "MatchResult::Ok({payload}) -> MatchResult<{payload}>"
            ))
        }
        ("MatchResult", "Err") => {
            let [param] = type_params else {
                return None;
            };
            Some(format!(
                "MatchResult::Err(Error) -> MatchResult<{}>",
                param.name
            ))
        }
        _ => None,
    }
}

fn format_generic_struct_signature(name: &str, type_params: &[TypeParam]) -> String {
    let type_params = format_type_params(type_params);
    format!("defstruct {}{type_params}", surface_path_name(name))
}

fn format_record_signature(name: &str) -> String {
    format!("defrecord {}", surface_path_name(name))
}

fn format_impl_method_signature(
    target: &str,
    name: &str,
    type_params: &[TypeParam],
    params: &[ValueParameter],
    ret_ty: &Option<AstTy>,
) -> String {
    let self_ty = AstTy::Named(spire::ast::Span { start: 0, end: 0 }, target.to_string());
    let params = params
        .iter()
        .map(|param| {
            format!(
                "{}: {}",
                param.name,
                format_ast_ty(&rewrite_self_ast_ty(&param.ty, &self_ty))
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    let type_params = format_type_params(type_params);
    let signature = match ret_ty {
        Some(ret) => format!(
            "{name}{type_params}({params}) -> {}",
            format_ast_ty(&rewrite_self_ast_ty(ret, &self_ty))
        ),
        None => format!("{name}{type_params}({params})"),
    };
    if let Some(rest) = signature.strip_prefix(name) {
        format!("{}::{name}{rest}", surface_path_name(target))
    } else {
        signature
    }
}

fn format_impl_extractor_signature(
    target: &str,
    name: &str,
    type_params: &[TypeParam],
    params: &[ExtractorParam],
    ret_ty: &AstTy,
) -> String {
    let self_ty = AstTy::Named(spire::ast::Span { start: 0, end: 0 }, target.to_string());
    let type_params = format_type_params(type_params);
    let param = params
        .iter()
        .map(|param| match &param.ty {
            Some(ty) => format!(
                "{}: {}",
                param.name,
                format_ast_ty(&rewrite_self_ast_ty(ty, &self_ty))
            ),
            None => param.name.clone(),
        })
        .collect::<Vec<_>>()
        .join(", ");
    let signature = format!(
        "{name}{type_params}({param}) -> {}",
        format_ast_ty(&rewrite_self_ast_ty(ret_ty, &self_ty))
    );
    if let Some(rest) = signature.strip_prefix(name) {
        format!("{}::{name}{rest}", surface_path_name(target))
    } else {
        signature
    }
}

fn format_trait_method_signature(trait_name: &str, method: &TraitMethodSig) -> String {
    let signature = format_fun_signature(
        &method.name,
        &method.type_params,
        &method.value_parameters,
        &Some(method.ret_ty.clone()),
    );
    if let Some(rest) = signature.strip_prefix(&method.name) {
        format!("{}::{}{}", surface_path_name(trait_name), method.name, rest)
    } else {
        signature
    }
}

fn format_trait_impl_signature(
    trait_name: &str,
    trait_args: &[AstTy],
    target_ty: &AstTy,
) -> String {
    if trait_args.is_empty() {
        format!("impl {trait_name} for {}", format_ast_ty(target_ty))
    } else {
        let args = trait_args
            .iter()
            .map(format_ast_ty)
            .collect::<Vec<_>>()
            .join(", ");
        format!("impl {trait_name}<{args}> for {}", format_ast_ty(target_ty))
    }
}

fn format_trait_impl_method_signature(
    trait_name: &str,
    trait_args: &[AstTy],
    target_ty: &AstTy,
    method_name: &str,
    type_params: &[TypeParam],
    params: &[ValueParameter],
    ret_ty: &Option<AstTy>,
    where_clause: Option<&WhereClause>,
) -> String {
    let params = params
        .iter()
        .map(|param| {
            format!(
                "{}: {}",
                param.name,
                format_ast_ty(&rewrite_self_ast_ty(&param.ty, target_ty))
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    let type_params = format_type_params(type_params);
    let method_sig = match ret_ty {
        Some(ret) => format!(
            "{method_name}{type_params}({params}) -> {}",
            format_ast_ty(&rewrite_self_ast_ty(ret, target_ty))
        ),
        None => format!("{method_name}{type_params}({params})"),
    };
    let impl_sig = format_trait_impl_signature(trait_name, trait_args, target_ty);
    format!(
        "{impl_sig}::{method_sig}{}",
        format_where_clause(where_clause)
    )
}

fn format_where_clause(where_clause: Option<&WhereClause>) -> String {
    let Some(where_clause) = where_clause else {
        return String::new();
    };
    let constraints = where_clause
        .constraints
        .iter()
        .map(|constraint| {
            let bounds = constraint
                .bounds
                .iter()
                .map(|bound| match bound {
                    WhereConstraintRhs::Trait(_, name) => name.clone(),
                    WhereConstraintRhs::TypeConstructor(_, slots) => format!(
                        "Type<{}>",
                        slots
                            .iter()
                            .map(format_ast_ty)
                            .collect::<Vec<_>>()
                            .join(", ")
                    ),
                    WhereConstraintRhs::TraitSlot(_, owner, slot) => {
                        format!("{owner}.{slot}")
                    }
                })
                .collect::<Vec<_>>()
                .join(" + ");
            format!("{}: {bounds}", format_ast_ty(&constraint.subject))
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!(" where {constraints}")
}

fn qualified_name(module_path: &str, name: &str) -> String {
    let module_path = surface_path_name(module_path);
    let name = surface_path_name(name);
    if module_path.is_empty() {
        name.to_string()
    } else if name
        .strip_prefix(module_path)
        .is_some_and(|rest| rest.starts_with("::"))
    {
        name.to_string()
    } else {
        format!("{module_path}::{name}")
    }
}

fn collect_doc_entries_for_ast(ast: &[Ast], module_path: &str, out: &mut Vec<DocEntry>) {
    for stmt in ast {
        match stmt {
            Ast::Def(_, name, _return_type_arguments, params, ret_ty, _, _, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_fun_signature(name, &[], params, ret_ty)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::BuiltinDecl(_, name, _, params, ret_ty, _, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_fun_signature(name, &[], params, ret_ty)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::BuiltinReflectionDecl(_, value, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, value.name()),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(value.signature()),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::IntrinsicDecl(_, name, signature, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(signature.raw.clone()),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::ExtractorDef(_, name, type_params, param, ret_ty, _, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_extractor_signature(
                            name,
                            type_params,
                            param,
                            ret_ty,
                        )),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::BuiltinExtractorDecl(_, name, param, ret_ty, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Function,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_extractor_signature(name, &[], param, ret_ty)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::TraitDef(_, name, _type_params, _, methods, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format!(
                            "trait {} {{ {} }}",
                            surface_path_name(name),
                            methods
                                .iter()
                                .map(|method| format_fun_signature(
                                    &method.name,
                                    &method.type_params,
                                    &method.value_parameters,
                                    &Some(method.ret_ty.clone()),
                                ))
                                .collect::<Vec<_>>()
                                .join(", ")
                        )),
                        doc: doc.clone(),
                    });
                }
                for method in methods {
                    if let Some(doc) = &method.attrs.doc {
                        out.push(DocEntry {
                            qualified_name: qualified_name(
                                module_path,
                                &format!("{name}::{}", method.name),
                            ),
                            kind: DocKind::Function,
                            module_path: surface_path_name(module_path).to_string(),
                            signature: Some(format_trait_method_signature(name, method)),
                            doc: doc.clone(),
                        });
                    }
                }
            }
            Ast::StructDef(_, name, type_params, _fields, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_generic_struct_signature(name, type_params)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::RecordDef(_, name, _, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_record_signature(name)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::ImplDef(_, target, _, methods, _attrs) => {
                for method in methods {
                    match method {
                        Ast::Def(_, name, _return_type_arguments, params, ret_ty, _, _, attrs) => {
                            if let Some(doc) = &attrs.doc {
                                let qualified_method_name =
                                    format!("{}::{name}", surface_path_name(target));
                                out.push(DocEntry {
                                    qualified_name: qualified_method_name,
                                    kind: DocKind::Function,
                                    module_path: surface_path_name(module_path).to_string(),
                                    signature: Some(format_impl_method_signature(
                                        target,
                                        name,
                                        &[],
                                        params,
                                        ret_ty,
                                    )),
                                    doc: doc.clone(),
                                });
                            }
                        }
                        Ast::BuiltinDecl(_, name, _, params, ret_ty, _, attrs) => {
                            if let Some(doc) = &attrs.doc {
                                let qualified_method_name =
                                    format!("{}::{name}", surface_path_name(target));
                                out.push(DocEntry {
                                    qualified_name: qualified_method_name,
                                    kind: DocKind::Function,
                                    module_path: surface_path_name(module_path).to_string(),
                                    signature: Some(format_impl_method_signature(
                                        target,
                                        name,
                                        &[],
                                        params,
                                        ret_ty,
                                    )),
                                    doc: doc.clone(),
                                });
                            }
                        }
                        Ast::ExtractorDef(_, name, type_params, param, ret_ty, _, attrs) => {
                            if let Some(doc) = &attrs.doc {
                                let qualified_method_name =
                                    format!("{}::{name}", surface_path_name(target));
                                out.push(DocEntry {
                                    qualified_name: qualified_method_name,
                                    kind: DocKind::Function,
                                    module_path: surface_path_name(module_path).to_string(),
                                    signature: Some(format_impl_extractor_signature(
                                        target,
                                        name,
                                        type_params,
                                        param,
                                        ret_ty,
                                    )),
                                    doc: doc.clone(),
                                });
                            }
                        }
                        Ast::BuiltinExtractorDecl(_, name, param, ret_ty, attrs) => {
                            if let Some(doc) = &attrs.doc {
                                let qualified_method_name =
                                    format!("{}::{name}", surface_path_name(target));
                                out.push(DocEntry {
                                    qualified_name: qualified_method_name,
                                    kind: DocKind::Function,
                                    module_path: surface_path_name(module_path).to_string(),
                                    signature: Some(format_impl_extractor_signature(
                                        target,
                                        name,
                                        &[],
                                        param,
                                        ret_ty,
                                    )),
                                    doc: doc.clone(),
                                });
                            }
                        }
                        _ => {}
                    }
                }
            }
            Ast::BuiltinTypeDecl(_, head, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, &head.name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_builtin_type_signature(head)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::DeferrorDef(_, name, fields, body, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_deferror_signature(name, fields, body)),
                        doc: doc.clone(),
                    });
                }
            }
            Ast::EnumDef(_, name, type_params, variants, attrs) => {
                if let Some(doc) = &attrs.doc {
                    out.push(DocEntry {
                        qualified_name: qualified_name(module_path, name),
                        kind: DocKind::Type,
                        module_path: surface_path_name(module_path).to_string(),
                        signature: Some(format_defenum_signature(name, variants)),
                        doc: doc.clone(),
                    });
                }
                if attrs.builtin {
                    for variant in variants {
                        let Some(signature) =
                            builtin_special_enum_variant_signature(name, type_params, variant)
                        else {
                            continue;
                        };
                        out.push(DocEntry {
                            qualified_name: qualified_name(
                                module_path,
                                &format!("{name}::{}", variant.name),
                            ),
                            kind: DocKind::Function,
                            module_path: surface_path_name(module_path).to_string(),
                            signature: Some(signature),
                            doc: String::new(),
                        });
                    }
                }
            }
            _ => {}
        }
    }
}

fn push_signature_entry(
    out: &mut Vec<SignatureEntry>,
    module_path: &str,
    qualified_name: String,
    kind: DocKind,
    signature: String,
) {
    out.push(SignatureEntry {
        qualified_name,
        kind,
        module_path: surface_path_name(module_path).to_string(),
        signature,
    });
}

fn collect_signature_entries_for_ast(
    ast: &[Ast],
    module_path: &str,
    out: &mut Vec<SignatureEntry>,
) {
    for stmt in ast {
        match stmt {
            Ast::Def(_, name, _return_type_arguments, params, ret_ty, _, _, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Function,
                    format_fun_signature(name, &[], params, ret_ty),
                );
            }
            Ast::BuiltinDecl(_, name, _, params, ret_ty, _, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Function,
                    format_fun_signature(name, &[], params, ret_ty),
                );
            }
            Ast::BuiltinReflectionDecl(_, reflection, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, reflection.name()),
                    DocKind::Function,
                    reflection.signature(),
                );
            }
            Ast::IntrinsicDecl(_, name, signature, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Function,
                    signature.raw.clone(),
                );
            }
            Ast::ExtractorDef(_, name, type_params, param, ret_ty, _, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Function,
                    format_extractor_signature(name, type_params, param, ret_ty),
                );
            }
            Ast::BuiltinExtractorDecl(_, name, param, ret_ty, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Function,
                    format_extractor_signature(name, &[], param, ret_ty),
                );
            }
            Ast::TraitDef(_, name, _type_params, _, methods, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Type,
                    format!(
                        "trait {} {{ {} }}",
                        surface_path_name(name),
                        methods
                            .iter()
                            .map(|method| format_fun_signature(
                                &method.name,
                                &method.type_params,
                                &method.value_parameters,
                                &Some(method.ret_ty.clone()),
                            ))
                            .collect::<Vec<_>>()
                            .join(", ")
                    ),
                );
                for method in methods {
                    push_signature_entry(
                        out,
                        module_path,
                        qualified_name(module_path, &format!("{name}::{}", method.name)),
                        DocKind::Function,
                        format_trait_method_signature(name, method),
                    );
                }
            }
            Ast::StructDef(_, name, type_params, _fields, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Type,
                    format_generic_struct_signature(name, type_params),
                );
            }
            Ast::RecordDef(_, name, _, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Type,
                    format_record_signature(name),
                );
            }
            Ast::ImplDef(_, target, _, methods, _) => {
                for method in methods {
                    match method {
                        Ast::Def(_, name, _return_type_arguments, params, ret_ty, _, _, _) => {
                            let qualified_method_name =
                                format!("{}::{name}", surface_path_name(target));
                            push_signature_entry(
                                out,
                                module_path,
                                qualified_method_name,
                                DocKind::Function,
                                format_impl_method_signature(target, name, &[], params, ret_ty),
                            );
                        }
                        Ast::BuiltinDecl(_, name, _, params, ret_ty, _, _) => {
                            let qualified_method_name =
                                format!("{}::{name}", surface_path_name(target));
                            push_signature_entry(
                                out,
                                module_path,
                                qualified_method_name,
                                DocKind::Function,
                                format_impl_method_signature(target, name, &[], params, ret_ty),
                            );
                        }
                        Ast::ExtractorDef(_, name, type_params, param, ret_ty, _, _) => {
                            let qualified_method_name =
                                format!("{}::{name}", surface_path_name(target));
                            push_signature_entry(
                                out,
                                module_path,
                                qualified_method_name,
                                DocKind::Function,
                                format_impl_extractor_signature(
                                    target,
                                    name,
                                    type_params,
                                    param,
                                    ret_ty,
                                ),
                            );
                        }
                        Ast::BuiltinExtractorDecl(_, name, param, ret_ty, _) => {
                            let qualified_method_name =
                                format!("{}::{name}", surface_path_name(target));
                            push_signature_entry(
                                out,
                                module_path,
                                qualified_method_name,
                                DocKind::Function,
                                format_impl_extractor_signature(target, name, &[], param, ret_ty),
                            );
                        }
                        _ => {}
                    }
                }
            }
            Ast::TraitImplDef(_, trait_name, trait_args, target_ty, _, methods, _) => {
                let rendered = format_trait_impl_signature(trait_name, trait_args, target_ty);
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, &rendered),
                    DocKind::Type,
                    rendered.clone(),
                );
                for method in methods {
                    let method_parts = match method {
                        Ast::Def(
                            _,
                            name,
                            _return_type_arguments,
                            params,
                            ret_ty,
                            where_clause,
                            _,
                            _,
                        ) => Some((
                            name,
                            [].as_slice(),
                            params.as_slice(),
                            ret_ty,
                            where_clause.as_ref(),
                        )),
                        Ast::BuiltinDecl(_, name, _, params, ret_ty, _, _) => {
                            Some((name, [].as_slice(), params.as_slice(), ret_ty, None))
                        }
                        _ => None,
                    };
                    if let Some((name, type_params, params, ret_ty, where_clause)) = method_parts {
                        let rendered = format_trait_impl_method_signature(
                            trait_name,
                            trait_args,
                            target_ty,
                            name,
                            type_params,
                            params,
                            ret_ty,
                            where_clause,
                        );
                        push_signature_entry(
                            out,
                            module_path,
                            qualified_name(
                                module_path,
                                &format!(
                                    "{}::{}",
                                    format_trait_impl_signature(trait_name, trait_args, target_ty),
                                    name
                                ),
                            ),
                            DocKind::Function,
                            rendered,
                        );
                    }
                }
            }
            Ast::BuiltinTypeDecl(_, head, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, &head.name),
                    DocKind::Type,
                    format_builtin_type_signature(head),
                );
            }
            Ast::DeferrorDef(_, name, fields, body, _) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Type,
                    format_deferror_signature(name, fields, body),
                );
            }
            Ast::EnumDef(_, name, type_params, variants, attrs) => {
                push_signature_entry(
                    out,
                    module_path,
                    qualified_name(module_path, name),
                    DocKind::Type,
                    format_defenum_signature(name, variants),
                );
                if attrs.builtin {
                    for variant in variants {
                        let Some(signature) =
                            builtin_special_enum_variant_signature(name, type_params, variant)
                        else {
                            continue;
                        };
                        push_signature_entry(
                            out,
                            module_path,
                            qualified_name(module_path, &format!("{name}::{}", variant.name)),
                            DocKind::Function,
                            signature,
                        );
                    }
                }
            }
            _ => {}
        }
    }
}

fn collect_doc_entries_into(
    docs: &mut Vec<DocEntry>,
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) {
    for stage in module_stages {
        for module in stage {
            let doc_module_path = module
                .doc_module_path
                .as_deref()
                .unwrap_or(module.module_path.as_str());
            if let Some(doc) = &module.module_doc {
                docs.push(DocEntry {
                    qualified_name: doc_module_path.to_string(),
                    kind: DocKind::Module,
                    module_path: doc_module_path.to_string(),
                    signature: None,
                    doc: doc.clone(),
                });
            }
            collect_doc_entries_for_ast(&module.ast, doc_module_path, docs);
        }
    }

    collect_doc_entries_for_ast(user_ast, user_module_path.unwrap_or_default(), docs);
}

fn collect_signature_entries_into(
    signatures: &mut Vec<SignatureEntry>,
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) {
    for stage in module_stages {
        for module in stage {
            let doc_module_path = module
                .doc_module_path
                .as_deref()
                .unwrap_or(module.module_path.as_str());
            collect_signature_entries_for_ast(&module.ast, doc_module_path, signatures);
        }
    }

    collect_signature_entries_for_ast(user_ast, user_module_path.unwrap_or_default(), signatures);
}

pub fn collect_doc_entries(
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) -> Vec<DocEntry> {
    let mut docs = Vec::new();
    collect_doc_entries_into(&mut docs, module_stages, user_ast, user_module_path);
    docs
}

pub fn collect_signature_entries(
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) -> Vec<SignatureEntry> {
    let mut signatures = Vec::new();
    collect_signature_entries_into(&mut signatures, module_stages, user_ast, user_module_path);
    signatures
}

pub fn collect_doc_entries_with_base(
    base_docs: &[DocEntry],
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) -> Vec<DocEntry> {
    let mut docs = base_docs.to_vec();
    collect_doc_entries_into(&mut docs, module_stages, user_ast, user_module_path);
    docs
}

pub fn collect_signature_entries_with_base(
    base_signatures: &[SignatureEntry],
    module_stages: &[Vec<StagedModuleAst>],
    user_ast: &[Ast],
    user_module_path: Option<&str>,
) -> Vec<SignatureEntry> {
    let mut signatures = base_signatures.to_vec();
    collect_signature_entries_into(&mut signatures, module_stages, user_ast, user_module_path);
    signatures
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse_doc_fixture(source: &str) -> Vec<Ast> {
        spire::parse_with_context(source, spire::ParserContext::module(0, None)).unwrap()
    }

    #[test]
    fn trait_body_and_method_docs_are_independent() {
        for (body_doc, method_doc) in [
            (None, None),
            (Some("body"), None),
            (None, Some("method")),
            (Some("body"), Some("method")),
        ] {
            let attribute = |doc: Option<&str>| {
                doc.map(|text| format!("@doc \"\"\"{text}\"\"\"\n"))
                    .unwrap_or_default()
            };
            let ast = parse_doc_fixture(&format!(
                "{}deftrait Describable {{ {}def describe(self: Self) -> String }}",
                attribute(body_doc),
                attribute(method_doc)
            ));
            let docs = collect_doc_entries(&[], &ast, None);
            assert_eq!(
                docs.len(),
                usize::from(body_doc.is_some()) + usize::from(method_doc.is_some())
            );
            assert_eq!(
                docs.iter()
                    .find(|entry| entry.qualified_name == "Describable")
                    .map(|entry| entry.doc.as_str()),
                body_doc
            );
            assert_eq!(
                docs.iter()
                    .find(|entry| entry.qualified_name == "Describable::describe")
                    .map(|entry| entry.doc.as_str()),
                method_doc
            );
            assert_eq!(collect_signature_entries(&[], &ast, None).len(), 2);
        }
    }

    #[test]
    fn trait_impl_docs_remain_in_ast_but_are_not_collected() {
        let ast = parse_doc_fixture(
            r#"@doc """implementation body"""
impl Describable for User {
  @doc """implementation method"""
  def describe(self: Self) -> String { "user" }
}"#,
        );
        let Ast::TraitImplDef(_, _, _, _, _, methods, attrs) = &ast[0] else {
            panic!("trait impl");
        };
        assert_eq!(attrs.doc.as_deref(), Some("implementation body"));
        let Ast::Def(_, _, _, _, _, _, _, method_attrs) = &methods[0] else {
            panic!("impl method");
        };
        assert_eq!(method_attrs.doc.as_deref(), Some("implementation method"));
        assert!(collect_doc_entries(&[], &ast, None).is_empty());
        let signatures = collect_signature_entries(&[], &ast, None);
        assert_eq!(signatures.len(), 2);
        assert!(signatures
            .iter()
            .any(|entry| entry.signature.contains("describe(")));
    }

    #[test]
    fn error_signature_distinguishes_payload_and_constructor_input() {
        let ast = spire::parse_with_context(
            "deferror Negative(num: Int) { |value: Int| Self(message: \"negative\", num: value) }",
            spire::ParserContext::project(0),
        )
        .unwrap();
        let signatures = collect_signature_entries(&[], &ast, None);
        let error = signatures
            .iter()
            .find(|entry| entry.qualified_name.ends_with("Negative"))
            .unwrap();
        assert_eq!(
            error.signature,
            "deferror Negative(num: Int) { |value: Int| ... }"
        );
    }

    #[test]
    fn malformed_special_variant_does_not_invent_a_signature_payload() {
        let variant = EnumVariant {
            span: spire::ast::Span { start: 0, end: 0 },
            name: "Ok".into(),
            payload: Vec::new(),
            discriminant: None,
        };
        assert_eq!(
            builtin_special_enum_variant_signature("Result", &[], &variant),
            None
        );
    }

    #[test]
    fn extractor_signature_preserves_written_error_parameter() {
        let ast = spire::parse_with_context(
            "defextractor identity(value: Int) -> MatchResult<Int> { MatchResult::Ok(value) }\ndefextractor detailed(value: Int) -> MatchResult<Int, Error> { MatchResult::Ok(value) }",
            spire::ParserContext::module(0, Some("Checked".to_string()))
                .with_rules(spire::ParseRules::permissive_for_tests()),
        )
        .unwrap();
        let signatures = collect_signature_entries(&[], &ast, None);
        let extractor = signatures
            .iter()
            .find(|entry| entry.qualified_name.ends_with("identity"))
            .expect("extractor signature");
        assert_eq!(
            extractor.signature,
            "identity(value: Int) -> MatchResult<Int>"
        );
        let detailed = signatures
            .iter()
            .find(|entry| entry.qualified_name.ends_with("detailed"))
            .expect("explicit extractor signature");
        assert_eq!(
            detailed.signature,
            "detailed(value: Int) -> MatchResult<Int, Error>"
        );
    }
}
