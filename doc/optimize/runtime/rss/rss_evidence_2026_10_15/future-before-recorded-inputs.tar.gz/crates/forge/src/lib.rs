pub mod bytecode;
pub mod codegen;
pub mod error;
pub mod opcode;
pub mod registry;

pub use codegen::{
    codegen, codegen_typed_program, compose_bytecode_with_chunk, repl_facet_info_for_node,
    BindingInfo, ChunkMeta, ForgeCheckpoint, ForgeSession, ReplCallableDisplay, ReplCallableKind,
    ReplFacetInfo, ReplFacetOperation, ReplFacetSegmentInfo, ReplFacetStage, ReplTypeKind,
    TypeDefDisplay,
};

#[cfg(test)]
mod tests {
    #![deny(dead_code)]

    use std::collections::HashSet;
    use std::sync::OnceLock;

    use super::{codegen, codegen_typed_program, compose_bytecode_with_chunk, ForgeSession};
    use crate::bytecode::Constant;
    use crate::opcode::Opcode;
    use crate::registry::TypeKind;
    use scar::typed::{
        ComposeFlavor, TypedClosureParam, TypedInner, TypedMatchArm, TypedMatchPattern, TypedNode,
        TypedPattern, TypedValueParameter,
    };
    use scar::types::Ty;
    use scar::{ScarCheckpoint, ScarSession, TypecheckContext};
    use sigil::resolved::ResolvedId;
    use sindr::builtin::builtin_id_by_name;
    use sindr::ir::{CallableTemplateComposeFlavor, CallableTemplateKind};
    use sindr::primitives::int;
    use spire::ast::{Ast, BinOp, Lit, Span, Visibility};

    #[test]
    fn concrete_trait_target_does_not_admit_pending_type_inputs() {
        use scar::typed::{TraitCallOrigin, TraitDispatch, TraitDispatchTarget, TraitObligation};
        let span = Span { start: 0, end: 1 };
        for (result, receiver, obligation_arg) in [
            (Ty::Var(91), Ty::Int, Ty::Int),
            (Ty::Int, Ty::List(Box::new(Ty::Var(92))), Ty::Int),
            (Ty::Int, Ty::Int, Ty::SelfApp(vec![Ty::Int])),
        ] {
            let node = TypedNode {
                ty: result,
                span: span.clone(),
                node: TypedInner::TraitCall {
                    trait_name: "Add".into(),
                    method_name: "add".into(),
                    receiver_ty: receiver.clone(),
                    obligation: TraitObligation {
                        trait_id: "Add".into(),
                        trait_args: vec![obligation_arg],
                        receiver,
                    },
                    dispatch: TraitDispatch::Static(TraitDispatchTarget::BinOp(BinOp::Add)),
                    origin: TraitCallOrigin::Explicit,
                    args: vec![
                        TypedNode {
                            ty: Ty::Int,
                            span: span.clone(),
                            node: TypedInner::Lit(Lit::Int(int(1)))
                        };
                        2
                    ],
                },
            };
            let error = codegen(vec![node])
                .expect_err("pending trait input must be rejected at the Forge boundary");
            assert!(
                error.message.contains("UnresolvedTraitMethodInstantiation"),
                "{error:?}"
            );
        }
    }

    fn parse_std_module_stage(
        source: &str,
        module_path: Option<&str>,
    ) -> Vec<sigil::StagedModuleAst> {
        let ast = spire::parse_with_context(
            source,
            spire::ParserContext::module(
                0,
                module_path
                    .filter(|path| *path == "Facet")
                    .map(str::to_owned),
            )
            .with_rules(spire::ParseRules::std_module()),
        )
        .unwrap_or_else(|error| panic!("standard source {module_path:?} should parse: {error:?}"));
        let fallback = sigil::const_only_fallback_module_path(&ast, module_path);
        sigil::staged_modules_from_source_ast(ast, fallback)
    }

    fn std_module_stages() -> Vec<Vec<sigil::StagedModuleAst>> {
        use sindr::stdlib::{stdlib_module_specs, StdlibStage, StdlibVariant};
        let mut stages = vec![Vec::new(), Vec::new()];
        for spec in stdlib_module_specs(StdlibVariant::TestEnabled) {
            let stage_index = match spec.stage {
                StdlibStage::Bootstrap => 0,
                StdlibStage::Main | StdlibStage::TestExtension => 1,
            };
            stages[stage_index].extend(parse_std_module_stage(spec.source, spec.module_path));
        }
        stages
    }

    struct CachedStdCompilePrefix {
        module_stages: Vec<Vec<sigil::StagedModuleAst>>,
        declaration_index: sigil::DeclarationIndex,
        resolve_state: sigil::ResolveResumeState,
        scar_checkpoint: ScarCheckpoint,
        bytecode: sindr::ir::Bytecode,
    }

    fn next_fun_idx(bytecode: &sindr::ir::Bytecode) -> u32 {
        bytecode
            .functions
            .iter()
            .map(|entry| entry.fun_idx.saturating_add(1))
            .max()
            .unwrap_or(0)
    }

    fn cached_std_compile_prefix() -> &'static CachedStdCompilePrefix {
        static CACHE: OnceLock<CachedStdCompilePrefix> = OnceLock::new();

        CACHE.get_or_init(|| {
            let module_stages = std_module_stages();
            let declaration_index = sigil::precollect_declaration_index(&module_stages)
                .expect("std modules should precollect");
            let resolved = sigil::resolve_staged_program_with_state(
                &module_stages,
                Vec::new(),
                &declaration_index,
                None,
            )
            .expect("std modules should resolve");
            let resolve_state = resolved.resume_state;
            let mut scar_session = ScarSession::new();
            let typed = scar_session
                .typecheck_staged_program_with_context(
                    resolved,
                    TypecheckContext {
                        runtime_policy: sindr::policy::RuntimeSourcePolicy::std_module(),
                        enforce_builtin_type_contracts: true,
                        allow_private_facet_inspection: false,
                    },
                )
                .expect("std modules should typecheck");
            let bytecode = codegen_typed_program(typed).expect("std modules should codegen");
            scar_session.ensure_next_fun_idx_at_least(next_fun_idx(&bytecode));
            scar_session.reconcile_function_indices(bytecode.functions.iter().filter_map(
                |entry| {
                    entry
                        .qualified_name
                        .as_deref()
                        .map(|qualified_name| (qualified_name, entry.fun_idx))
                },
            ));
            let scar_checkpoint = scar_session.checkpoint();
            CachedStdCompilePrefix {
                module_stages,
                declaration_index,
                resolve_state,
                scar_checkpoint,
                bytecode,
            }
        })
    }

    fn typed_with_builtin_prelude(source: &str) -> scar::typed::TypedProgram {
        let prelude = cached_std_compile_prefix();
        let user_ast = spire::parse_with_context(source, spire::ParserContext::project(0))
            .expect("source should parse");
        let resolved = sigil::resolve_staged_program_from_state(
            &prelude.module_stages,
            user_ast,
            &prelude.declaration_index,
            None,
            prelude.module_stages.len(),
            prelude.resolve_state,
        )
        .expect("source should resolve");
        let mut scar_session = ScarSession::new();
        scar_session.rollback(prelude.scar_checkpoint.clone());
        scar_session
            .typecheck_staged_program_in_place_with_context(resolved, TypecheckContext::default())
            .expect("source should typecheck")
    }

    fn typed_module_program_with_builtin_prelude(source: &str) -> scar::typed::TypedProgram {
        let prelude = cached_std_compile_prefix();
        let ast = spire::parse_with_context(source, spire::ParserContext::project(0))
            .expect("source should parse");
        let shared_imports = ast
            .iter()
            .filter_map(|stmt| match stmt {
                Ast::Import(_, _, _) => Some(stmt.clone()),
                _ => None,
            })
            .collect::<Vec<_>>();
        let mut boot_ast = Vec::new();
        let lowered = ast
            .into_iter()
            .filter_map(|stmt| match stmt {
                Ast::Defmod(span, module_path, body, attrs) => {
                    let mut module_ast = shared_imports.clone();
                    module_ast.extend(body);
                    Some(sigil::StagedModuleAst {
                        source_index: 0,
                        owner: Some(sigil::OwnerDescriptor::new(
                            module_path.clone(),
                            span,
                            sigil::OwnerSourceForm::Defmod,
                        )),
                        module_path,
                        doc_module_path: None,
                        ast: module_ast,
                        module_doc: attrs.doc,
                        auto_import: attrs.auto_import,
                        process_spec: None,
                    })
                }
                Ast::Defagent(span, module_path, body, process_spec, attrs)
                | Ast::Defgenserver(span, module_path, body, process_spec, attrs)
                | Ast::Defsupervisor(span, module_path, body, process_spec, attrs)
                | Ast::DefdynamicSupervisor(span, module_path, body, process_spec, attrs) => {
                    let source_form = match process_spec.kind {
                        spire::ast::ProcessKind::Agent => sigil::OwnerSourceForm::Defagent,
                        spire::ast::ProcessKind::GenServer => sigil::OwnerSourceForm::Defgenserver,
                        spire::ast::ProcessKind::DynamicSupervisor => {
                            sigil::OwnerSourceForm::DefdynamicSupervisor
                        }
                        spire::ast::ProcessKind::Supervisor
                        | spire::ast::ProcessKind::RuntimeSupervisor => {
                            sigil::OwnerSourceForm::Defsupervisor
                        }
                        spire::ast::ProcessKind::Task => sigil::OwnerSourceForm::Defagent,
                    };
                    let mut module_ast = shared_imports.clone();
                    module_ast.extend(body);
                    Some(sigil::StagedModuleAst {
                        source_index: 0,
                        owner: Some(sigil::OwnerDescriptor::new(
                            module_path.clone(),
                            span,
                            source_form,
                        )),
                        module_path,
                        doc_module_path: None,
                        ast: module_ast,
                        module_doc: attrs.doc,
                        auto_import: attrs.auto_import,
                        process_spec: Some(process_spec),
                    })
                }
                other @ Ast::SupervisorInit(_, _) => {
                    boot_ast.push(other);
                    None
                }
                _ => None,
            })
            .collect::<Vec<_>>();

        let mut all_stages = prelude.module_stages.clone();
        all_stages.push(lowered);
        let declaration_index = sigil::precollect_declaration_index(&all_stages)
            .expect("module stages should precollect");
        let resolved = sigil::resolve_staged_program_from_state(
            &all_stages,
            boot_ast,
            &declaration_index,
            None,
            prelude.module_stages.len(),
            prelude.resolve_state,
        )
        .expect("definition source should resolve");
        let mut scar_session = ScarSession::new();
        scar_session.rollback(prelude.scar_checkpoint.clone());
        scar_session
            .typecheck_staged_program_in_place_with_context(resolved, TypecheckContext::default())
            .expect("definition source should typecheck")
    }

    fn codegen_source(source: &str) -> sindr::ir::Bytecode {
        let typed = typed_with_builtin_prelude(source);
        let prelude = cached_std_compile_prefix();
        let mut forge_session = ForgeSession::from_bytecode(&prelude.bytecode);
        let (chunk, _) = forge_session
            .codegen_chunk_typed_program(typed)
            .expect("codegen should succeed");
        compose_bytecode_with_chunk(prelude.bytecode.clone(), chunk)
            .expect("bytecode should compose")
    }

    fn codegen_module_source_with_builtin_prelude(
        source: &str,
    ) -> Result<sindr::ir::Bytecode, crate::error::CodegenError> {
        let typed = typed_module_program_with_builtin_prelude(source);
        let prelude = cached_std_compile_prefix();
        let mut forge_session = ForgeSession::from_bytecode(&prelude.bytecode);
        let (chunk, _) = forge_session.codegen_chunk_typed_program(typed)?;
        compose_bytecode_with_chunk(prelude.bytecode.clone(), chunk)
    }

    fn codegen_rejects_call_arity_above_u8_limit() {
        fn source_with_arity(arity: usize) -> String {
            let params = (0..arity)
                .map(|index| format!("a{index}: Int"))
                .collect::<Vec<_>>()
                .join(", ");
            let args = vec!["1"; arity].join(", ");
            format!(
                "defmod Main {{\n def wide({params}) -> Int {{ a0 }}\n def main() -> Int {{ wide({args}) }}\n }}"
            )
        }

        codegen_module_source_with_builtin_prelude(&source_with_arity(255))
            .expect("255 arguments fit the bytecode arity");
        let error = match codegen_module_source_with_builtin_prelude(&source_with_arity(256)) {
            Ok(_) => panic!("256 arguments must not wrap to zero"),
            Err(error) => error,
        };
        assert!(
            error.message.contains("arity exceeds 255"),
            "unexpected codegen error: {error:?}"
        );
    }

    #[test]
    fn codegen_rejects_oversize_callable_operands() {
        let params = (0..256)
            .map(|index| closure_param(&format!("a{index}"), index as u32 + 1, Ty::Int))
            .collect::<Vec<_>>();
        let closure = TypedNode {
            ty: Ty::Func(vec![Ty::Int; 256], Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::Closure(params, Vec::new(), Box::new(int_lit(1))),
        };
        let closure_error = match codegen(vec![closure]) {
            Ok(_) => panic!("256 closure parameters must not wrap to zero"),
            Err(error) => error,
        };
        assert!(closure_error.message.contains("arity exceeds 255"));

        let callable = TypedNode {
            ty: Ty::Func(vec![Ty::Int; 256], Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::Var(resolved_id("callable", 1000)),
        };
        let call = TypedNode {
            ty: Ty::Int,
            span: test_span(),
            node: TypedInner::App(Box::new(callable), vec![int_lit(1); 256]),
        };
        let call_error = match codegen(vec![call]) {
            Ok(_) => panic!("256 call operands must not wrap to zero"),
            Err(error) => error,
        };
        assert!(call_error.message.contains("arity exceeds 255"));

        let injected = TypedNode {
            ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::InjectCall(
                Box::new(TypedNode {
                    ty: Ty::Func(vec![Ty::Int; 255], Box::new(Ty::Int)),
                    span: test_span(),
                    node: TypedInner::Var(resolved_id("callable", 1001)),
                }),
                vec![int_lit(1); 254],
            ),
        };
        let inject_error = match codegen(vec![injected]) {
            Ok(_) => panic!("generated wrapper arity must include hidden arguments"),
            Err(error) => error,
        };
        assert!(inject_error.message.contains("arity exceeds 255"));

        let debug = TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Dbg(
                (0..256)
                    .map(|_| scar::typed::TypedDbgArg {
                        span: test_span(),
                        ty_name: "Int".to_string(),
                        expr: int_lit(1),
                    })
                    .collect(),
            ),
        };
        let debug_error = match codegen(vec![debug]) {
            Ok(_) => panic!("256 debug arguments must not wrap to zero"),
            Err(error) => error,
        };
        assert!(debug_error
            .message
            .contains("debug argument count exceeds 255"));
    }

    macro_rules! semantic_prefix_case {
        ($case:ident) => {
            (stringify!($case), $case as fn())
        };
    }

    const SEMANTIC_PREFIX_BUCKET_COUNT: usize = 4;

    const SEMANTIC_PREFIX_CASES: &[(&str, fn())] = &[
        semantic_prefix_case!(function_table_preserves_fun_idx_index_invariant),
        semantic_prefix_case!(field_access_emits_getfield_with_resolved_index),
        semantic_prefix_case!(type_registry_reserves_result_tags_and_starts_user_tags_from_two),
        semantic_prefix_case!(concrete_numeric_helpers_lower_to_existing_targets),
        semantic_prefix_case!(facet_set_and_over_are_lowered_without_runtime_builtin_calls),
        semantic_prefix_case!(facet_container_segments_lower_without_public_facet_builtin_calls),
        semantic_prefix_case!(facet_bindings_are_erased_and_only_viewed_values_are_captured),
        semantic_prefix_case!(facet_variant_mismatch_detail_includes_segment_context),
        semantic_prefix_case!(bounded_add_generic_helpers_emit_specialized_functions),
        semantic_prefix_case!(compare_bound_list_helpers_emit_specialized_functions),
        semantic_prefix_case!(codegen_typed_program_embeds_runtime_process_specs),
        semantic_prefix_case!(codegen_typed_program_embeds_runtime_boot_plan),
        semantic_prefix_case!(codegen_rejects_boot_plan_handler_override_for_unknown_slot),
        semantic_prefix_case!(codegen_typed_program_embeds_genserver_runtime_handler_specs),
        semantic_prefix_case!(codegen_typed_program_emits_v2_process_spec_for_standby_process_init),
        semantic_prefix_case!(codegen_rejects_call_arity_above_u8_limit),
        semantic_prefix_case!(special_enum_captures_use_normal_constructor_lowering),
        semantic_prefix_case!(safe_mod_trait_call_preserves_builtin_source_context),
        semantic_prefix_case!(facet_api_capture_preserves_resolved_callable_metadata),
    ];

    #[test]
    fn semantic_prefix_case_inventory_is_complete() {
        for bucket in 0..SEMANTIC_PREFIX_BUCKET_COUNT {
            assert!(
                SEMANTIC_PREFIX_CASES.get(bucket).is_some(),
                "empty semantic prefix bucket: {bucket}"
            );
        }

        let source = include_str!("lib.rs");
        let mut names = HashSet::new();
        let mut functions = HashSet::new();

        for &(name, case) in SEMANTIC_PREFIX_CASES {
            assert!(names.insert(name), "duplicate semantic prefix case: {name}");
            assert!(
                functions.insert(case as usize),
                "duplicate semantic prefix case function: {name}"
            );
            assert!(
                !source.contains(&format!("#[test]\n    fn {name}(")),
                "semantic prefix case must run only through a bucket: {name}"
            );
        }
    }

    macro_rules! semantic_prefix_bucket_test {
        ($name:ident, $bucket:expr) => {
            #[test]
            fn $name() {
                for &(case_name, case) in SEMANTIC_PREFIX_CASES
                    .iter()
                    .skip($bucket)
                    .step_by(SEMANTIC_PREFIX_BUCKET_COUNT)
                {
                    eprintln!("Forge semantic prefix case: {case_name}");
                    case();
                }
            }
        };
    }

    semantic_prefix_bucket_test!(semantic_prefix_bucket_0, 0);
    semantic_prefix_bucket_test!(semantic_prefix_bucket_1, 1);
    semantic_prefix_bucket_test!(semantic_prefix_bucket_2, 2);
    semantic_prefix_bucket_test!(semantic_prefix_bucket_3, 3);

    fn test_span() -> Span {
        Span { start: 0, end: 0 }
    }

    fn resolved_id(name: &str, unique_id: u32) -> ResolvedId {
        ResolvedId {
            name: name.to_string(),
            qualified_name: None,
            unique_id,
            compiler_generated: false,
            symbol_info: None,
            span: test_span(),
        }
    }

    fn value_parameter(name: &str, unique_id: u32, ty: Ty) -> TypedValueParameter {
        TypedValueParameter {
            id: resolved_id(name, unique_id),
            mode: spire::ast::ValueParameterMode::PositionalOrNamed,
            ty,
            span: test_span(),
        }
    }

    fn closure_param(name: &str, unique_id: u32, ty: Ty) -> TypedClosureParam {
        TypedClosureParam {
            id: resolved_id(name, unique_id),
            ty,
        }
    }

    fn local_var(name: &str, unique_id: u32, ty: Ty) -> TypedNode {
        TypedNode {
            ty,
            span: test_span(),
            node: TypedInner::Var(resolved_id(name, unique_id)),
        }
    }

    fn user_func_var(
        name: &str,
        unique_id: u32,
        fun_idx: u32,
        params: Vec<Ty>,
        ret: Ty,
    ) -> TypedNode {
        TypedNode {
            ty: Ty::UserFunc {
                fun_idx,
                type_params: Vec::new(),
                call_substitution: Vec::new(),
                params,
                ret: Box::new(ret),
            },
            span: test_span(),
            node: TypedInner::Var(resolved_id(name, unique_id)),
        }
    }

    fn builtin_func_var(name: &str, unique_id: u32, params: Vec<Ty>, ret: Ty) -> TypedNode {
        TypedNode {
            ty: Ty::BuiltinFunc {
                name: name.to_string(),
                params,
                ret: Box::new(ret),
            },
            span: test_span(),
            node: TypedInner::Var(resolved_id(name, unique_id)),
        }
    }

    fn builtin_app(name: &str, args: Vec<TypedNode>, ret: Ty) -> TypedNode {
        let params = args.iter().map(|arg| arg.ty.clone()).collect::<Vec<_>>();
        TypedNode {
            ty: ret.clone(),
            span: test_span(),
            node: TypedInner::App(Box::new(builtin_func_var(name, 9_000, params, ret)), args),
        }
    }

    fn user_capture(
        name: &str,
        unique_id: u32,
        fun_idx: u32,
        params: Vec<Ty>,
        ret: Ty,
    ) -> TypedNode {
        TypedNode {
            ty: Ty::Func(params.clone(), Box::new(ret.clone())),
            span: test_span(),
            node: TypedInner::Capture(
                Box::new(user_func_var(name, unique_id, fun_idx, params, ret)),
                Vec::new(),
            ),
        }
    }

    fn builtin_capture(name: &str, unique_id: u32, params: Vec<Ty>, ret: Ty) -> TypedNode {
        TypedNode {
            ty: Ty::Func(params.clone(), Box::new(ret.clone())),
            span: test_span(),
            node: TypedInner::Capture(
                Box::new(builtin_func_var(name, unique_id, params, ret)),
                Vec::new(),
            ),
        }
    }

    fn identity_def(name: &str, fun_idx: u32, fun_uid: u32, param_uid: u32, ty: Ty) -> TypedNode {
        let param = value_parameter("value", param_uid, ty.clone());
        TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Def(
                fun_idx,
                resolved_id(name, fun_uid),
                Vec::new(),
                vec![param.clone()],
                ty.clone(),
                None,
                Box::new(local_var("value", param.id.unique_id, ty)),
                Visibility::Public,
            ),
        }
    }

    fn binary_first_def(name: &str, fun_idx: u32, fun_uid: u32) -> TypedNode {
        let left = value_parameter("left", fun_uid + 1, Ty::Int);
        let right = value_parameter("right", fun_uid + 2, Ty::Int);
        TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Def(
                fun_idx,
                resolved_id(name, fun_uid),
                Vec::new(),
                vec![left.clone(), right],
                Ty::Int,
                None,
                Box::new(local_var("left", left.id.unique_id, Ty::Int)),
                Visibility::Public,
            ),
        }
    }

    fn top_level_opcodes(bytecode: &sindr::ir::Bytecode) -> Vec<&Opcode> {
        bytecode
            .opcodes
            .iter()
            .take_while(|opcode| !matches!(opcode, Opcode::Halt))
            .collect()
    }

    fn function_body_opcodes<'a>(
        bytecode: &'a sindr::ir::Bytecode,
        fun_idx: u32,
    ) -> Vec<&'a Opcode> {
        let entry_pc = bytecode.functions[fun_idx as usize].entry_pc as usize;
        let end_pc = bytecode
            .functions
            .iter()
            .filter_map(|entry| {
                let pc = entry.entry_pc as usize;
                (pc > entry_pc).then_some(pc)
            })
            .min()
            .unwrap_or(bytecode.opcodes.len());
        bytecode.opcodes[entry_pc..end_pc].iter().collect()
    }

    fn int_lit(value: i64) -> TypedNode {
        TypedNode {
            ty: Ty::Int,
            span: test_span(),
            node: TypedInner::Lit(Lit::Int(int(value))),
        }
    }

    fn str_lit(value: &str) -> TypedNode {
        TypedNode {
            ty: Ty::Str,
            span: test_span(),
            node: TypedInner::Lit(Lit::Str(value.to_string())),
        }
    }

    fn list_lit_int(values: impl IntoIterator<Item = i64>) -> TypedNode {
        TypedNode {
            ty: Ty::List(Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::ListLiteral(values.into_iter().map(int_lit).collect()),
        }
    }

    fn hash_map_lit_int(entries: impl IntoIterator<Item = (&'static str, i64)>) -> TypedNode {
        TypedNode {
            ty: Ty::Enum("HashMap".into(), vec![Ty::Int]),
            span: test_span(),
            node: TypedInner::HashMapLiteral(
                entries
                    .into_iter()
                    .map(|(key, value)| (str_lit(key), int_lit(value)))
                    .collect(),
            ),
        }
    }

    fn assert_no_call_builtin(bytecode: &sindr::ir::Bytecode, builtin_name: &str) {
        let builtin_id = builtin_id_by_name(builtin_name)
            .unwrap_or_else(|| panic!("{builtin_name} builtin metadata must exist"));
        assert!(!bytecode.opcodes.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id: id,
                    ..
                } if *id == builtin_id
            )
        }));
    }

    fn unit_lit() -> TypedNode {
        TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Lit(Lit::Unit),
        }
    }

    fn list_nil() -> TypedNode {
        TypedNode {
            ty: Ty::List(Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::ListNil,
        }
    }

    fn list_cons_expr(depth: usize) -> TypedNode {
        let mut node = list_nil();
        for value in (0..depth).rev() {
            node = TypedNode {
                ty: Ty::List(Box::new(Ty::Int)),
                span: test_span(),
                node: TypedInner::ListCons(Box::new(int_lit(value as i64)), Box::new(node)),
            };
        }
        node
    }

    fn list_cons_bind_pattern(depth: usize) -> TypedPattern {
        let mut pat = TypedPattern::ListNil(Ty::List(Box::new(Ty::Int)));
        for _ in 0..depth {
            pat = TypedPattern::ListCons(
                Ty::List(Box::new(Ty::Int)),
                Box::new(TypedPattern::Wildcard(Ty::Int)),
                Box::new(pat),
            );
        }
        pat
    }

    fn list_cons_match_pattern(depth: usize) -> TypedMatchPattern {
        let mut pat = TypedMatchPattern::ListNil;
        for _ in 0..depth {
            pat = TypedMatchPattern::ListCons(Box::new(TypedMatchPattern::Wildcard), Box::new(pat));
        }
        pat
    }

    fn nested_tail_blocks(depth: usize, leaf: TypedNode) -> TypedNode {
        let mut node = leaf;
        for _ in 0..depth {
            node = TypedNode {
                ty: node.ty.clone(),
                span: test_span(),
                node: TypedInner::Block(vec![node]),
            };
        }
        node
    }

    fn codegen_typed(stmts: Vec<TypedNode>) -> sindr::ir::Bytecode {
        codegen(stmts).expect("typed codegen should succeed")
    }

    #[test]
    fn deep_list_cons_expression_codegen_uses_normal_test_stack() {
        let bytecode = codegen_typed(vec![list_cons_expr(512)]);
        let cons_count = bytecode
            .opcodes
            .iter()
            .filter(|op| matches!(op, Opcode::ListCons))
            .count();

        assert_eq!(cons_count, 512);
    }

    #[test]
    fn deep_list_cons_bind_pattern_codegen_uses_normal_test_stack() {
        let node = TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Bind(list_cons_bind_pattern(512), Box::new(list_cons_expr(512))),
        };
        let bytecode = codegen_typed(vec![node]);
        let list_head_count = bytecode
            .opcodes
            .iter()
            .filter(|op| matches!(op, Opcode::ListHead))
            .count();

        assert_eq!(list_head_count, 512);
    }

    #[test]
    fn deep_list_cons_match_pattern_codegen_uses_normal_test_stack() {
        let node = TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Match(
                Box::new(list_cons_expr(512)),
                vec![TypedMatchArm {
                    direct_expression: false,
                    pattern: list_cons_match_pattern(512),
                    guard: None,
                    body: unit_lit(),
                }],
            ),
        };
        let bytecode = codegen_typed(vec![node]);
        let list_head_count = bytecode
            .opcodes
            .iter()
            .filter(|op| matches!(op, Opcode::ListHead))
            .count();

        assert_eq!(list_head_count, 512);
    }

    #[test]
    fn deep_tail_block_function_codegen_uses_normal_test_stack() {
        let body = nested_tail_blocks(512, int_lit(1));
        let node = TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Def(
                0,
                resolved_id("deep", 1),
                Vec::new(),
                Vec::<TypedValueParameter>::new(),
                Ty::Int,
                None,
                Box::new(body),
                Visibility::Public,
            ),
        };
        let bytecode = codegen_typed(vec![node]);

        assert_eq!(bytecode.functions.len(), 1);
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::Return)));
    }

    #[test]
    fn function_calls_compile_under_current_opcode_set() {
        let bytecode = codegen_typed(vec![
            TypedNode {
                ty: Ty::Unit,
                span: test_span(),
                node: TypedInner::Def(
                    0,
                    resolved_id("add", 1),
                    Vec::new(),
                    vec![
                        value_parameter("x", 2, Ty::Int),
                        value_parameter("y", 3, Ty::Int),
                    ],
                    Ty::Int,
                    None,
                    Box::new(TypedNode {
                        ty: Ty::Int,
                        span: test_span(),
                        node: TypedInner::BinOp(
                            BinOp::Add,
                            Box::new(local_var("x", 2, Ty::Int)),
                            Box::new(local_var("y", 3, Ty::Int)),
                        ),
                    }),
                    Visibility::Public,
                ),
            },
            TypedNode {
                ty: Ty::Int,
                span: test_span(),
                node: TypedInner::App(
                    Box::new(user_func_var("add", 4, 0, vec![Ty::Int, Ty::Int], Ty::Int)),
                    vec![int_lit(1), int_lit(2)],
                ),
            },
        ]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::Call { arity: 2, .. })));
    }

    fn function_table_preserves_fun_idx_index_invariant() {
        let baseline = codegen_source(r#"print("baseline")"#);
        let bytecode = codegen_source(
            r#"def add(x: Int, y: Int) -> Int { x + y }
deferror Oops {
  "oops"
}
print(to_string(add(1, 2)))"#,
        );

        assert_eq!(bytecode.functions.len(), baseline.functions.len() + 2);
        for (idx, entry) in bytecode.functions.iter().enumerate() {
            assert_eq!(entry.fun_idx as usize, idx);
        }
    }

    #[test]
    fn zero_capture_closure_literal_omits_capture_closure_zero() {
        let x = closure_param("x", 10, Ty::Int);
        let bytecode = codegen_typed(vec![TypedNode {
            ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
            span: test_span(),
            node: TypedInner::Closure(
                vec![x.clone()],
                Vec::new(),
                Box::new(TypedNode {
                    ty: Ty::Int,
                    span: test_span(),
                    node: TypedInner::BinOp(
                        BinOp::Add,
                        Box::new(local_var("x", x.id.unique_id, Ty::Int)),
                        Box::new(int_lit(1)),
                    ),
                }),
            ),
        }]);

        assert!(!bytecode
            .opcodes
            .windows(2)
            .any(|ops| matches!(ops, [Opcode::LoadFunctionRef(_), Opcode::CaptureClosure(0)])));
    }

    #[test]
    fn capturing_closure_literal_still_emits_capture_closure() {
        let base = resolved_id("base", 20);
        let x = closure_param("x", 21, Ty::Int);
        let bytecode = codegen_typed(vec![
            TypedNode {
                ty: Ty::Unit,
                span: test_span(),
                node: TypedInner::Bind(
                    TypedPattern::Var(Ty::Int, base.clone()),
                    Box::new(int_lit(10)),
                ),
            },
            TypedNode {
                ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
                span: test_span(),
                node: TypedInner::Closure(
                    vec![x.clone()],
                    vec![base.clone()],
                    Box::new(TypedNode {
                        ty: Ty::Int,
                        span: test_span(),
                        node: TypedInner::BinOp(
                            BinOp::Add,
                            Box::new(local_var("x", x.id.unique_id, Ty::Int)),
                            Box::new(local_var("base", base.unique_id, Ty::Int)),
                        ),
                    }),
                ),
            },
        ]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::CaptureClosure(count) if *count > 0)));
    }

    #[test]
    fn tail_closure_call_lowers_to_fused_tail_opcode() {
        let f = value_parameter("f", 30, Ty::Func(vec![Ty::Int], Box::new(Ty::Int)));
        let value = value_parameter("value", 31, Ty::Int);
        let bytecode = codegen_typed(vec![TypedNode {
            ty: Ty::Unit,
            span: test_span(),
            node: TypedInner::Def(
                0,
                resolved_id("apply_tail", 32),
                Vec::new(),
                vec![f.clone(), value.clone()],
                Ty::Int,
                None,
                Box::new(TypedNode {
                    ty: Ty::Int,
                    span: test_span(),
                    node: TypedInner::App(
                        Box::new(local_var("f", f.id.unique_id, f.ty.clone())),
                        vec![local_var("value", value.id.unique_id, Ty::Int)],
                    ),
                }),
                Visibility::Public,
            ),
        }]);
        let apply_tail = bytecode
            .functions
            .iter()
            .find(|entry| {
                entry
                    .qualified_name
                    .as_deref()
                    .is_some_and(|name| name.ends_with("apply_tail"))
            })
            .expect("apply_tail function should be present");
        let body = function_body_opcodes(&bytecode, apply_tail.fun_idx);

        assert!(body
            .iter()
            .any(|opcode| matches!(opcode, Opcode::TailCallClosure { arity: 1, .. })));
        assert!(!body
            .windows(2)
            .any(|ops| { matches!(ops, [Opcode::CallClosure { .. }, Opcode::Return]) }));
    }

    #[test]
    fn pipe_direct_user_capture_lowers_to_call_without_callclosure() {
        let bytecode = codegen_typed(vec![
            identity_def("id_int", 0, 10, 11, Ty::Int),
            TypedNode {
                ty: Ty::Int,
                span: test_span(),
                node: TypedInner::Pipe(
                    Box::new(int_lit(7)),
                    Box::new(user_capture("id_int", 12, 0, vec![Ty::Int], Ty::Int)),
                ),
            },
        ]);
        let top_level = top_level_opcodes(&bytecode);

        assert!(top_level.iter().any(|op| matches!(
            op,
            Opcode::Call {
                fun_idx: 0,
                arity: 1,
                ..
            }
        )));
        assert!(!top_level
            .iter()
            .any(|op| matches!(op, Opcode::CallClosure { .. })));
    }

    #[test]
    fn pipe_direct_builtin_capture_lowers_to_callbuiltin_without_callclosure() {
        let builtin_id = builtin_id_by_name("to_string").expect("to_string builtin exists");
        let bytecode = codegen_typed(vec![TypedNode {
            ty: Ty::Str,
            span: test_span(),
            node: TypedInner::Pipe(
                Box::new(int_lit(7)),
                Box::new(builtin_capture("to_string", 12, vec![Ty::Int], Ty::Str)),
            ),
        }]);
        let top_level = top_level_opcodes(&bytecode);

        assert!(top_level.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id: id,
                    arity: 1,
                    ..
                } if *id == builtin_id
            )
        }));
        assert!(!top_level
            .iter()
            .any(|op| matches!(op, Opcode::CallClosure { .. })));
    }

    #[test]
    fn hash_map_literal_lowers_to_map_from_entries_builtin() {
        let bytecode = codegen_typed(vec![hash_map_lit_int([("b", 2), ("a", 1)])]);
        let map_from_entries_id =
            builtin_id_by_name("map_from_entries").expect("map_from_entries builtin exists");
        let top_level = top_level_opcodes(&bytecode);

        assert!(top_level.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id,
                    arity: 1,
                    ..
                } if *builtin_id == map_from_entries_id
            )
        }));
        assert!(top_level
            .iter()
            .any(|op| matches!(op, Opcode::TupleNew { len: 2 })));
        assert!(top_level
            .iter()
            .any(|op| matches!(op, Opcode::ListFromItems { len: 2 })));
    }

    #[test]
    fn pipe_direct_injected_user_call_lowers_without_partial_wrapper() {
        let bytecode = codegen_typed(vec![
            binary_first_def("first_int", 0, 20),
            TypedNode {
                ty: Ty::Int,
                span: test_span(),
                node: TypedInner::Pipe(
                    Box::new(int_lit(7)),
                    Box::new(TypedNode {
                        ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
                        span: test_span(),
                        node: TypedInner::InjectCall(
                            Box::new(user_func_var(
                                "first_int",
                                23,
                                0,
                                vec![Ty::Int, Ty::Int],
                                Ty::Int,
                            )),
                            vec![int_lit(9)],
                        ),
                    }),
                ),
            },
        ]);
        let top_level = top_level_opcodes(&bytecode);

        assert!(top_level.iter().any(|op| matches!(
            op,
            Opcode::Call {
                fun_idx: 0,
                arity: 2,
                ..
            }
        )));
        assert!(!bytecode
            .functions
            .iter()
            .any(|entry| entry.flags.partial_apply_wrapper));
        assert!(!top_level
            .iter()
            .any(|op| matches!(op, Opcode::CallClosure { .. } | Opcode::CaptureClosure(_))));
    }

    #[test]
    fn direct_compose_uses_callable_template_without_generated_wrapper() {
        let bytecode = codegen_typed(vec![
            identity_def("left_int", 0, 30, 31, Ty::Int),
            identity_def("right_int", 1, 32, 33, Ty::Int),
            TypedNode {
                ty: Ty::Func(vec![Ty::Int], Box::new(Ty::Int)),
                span: test_span(),
                node: TypedInner::Compose(
                    ComposeFlavor::Plain,
                    Box::new(user_capture("left_int", 34, 0, vec![Ty::Int], Ty::Int)),
                    Box::new(user_capture("right_int", 35, 1, vec![Ty::Int], Ty::Int)),
                ),
            },
        ]);
        let top_level = top_level_opcodes(&bytecode);

        assert!(bytecode.callable_templates.iter().any(|template| matches!(
            template.kind,
            CallableTemplateKind::ComposeDirect {
                flavor: CallableTemplateComposeFlavor::Plain,
            }
        )));
        assert!(!bytecode
            .functions
            .iter()
            .any(|entry| entry.flags.generated && !entry.flags.closure && entry.arity == 1));
        assert!(top_level
            .iter()
            .any(|op| matches!(op, Opcode::LoadCallableTemplateRef(_))));
        assert!(top_level
            .iter()
            .any(|op| matches!(op, Opcode::CaptureClosure(2))));
    }

    fn field_access_emits_getfield_with_resolved_index() {
        let bytecode = codegen_source(
            r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name: name, age: age }
  }
}

user: User = User("alice", 30)
print(to_string(user.age))"#,
        );

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::GetField { field_index: 1 })));
    }

    fn type_registry_reserves_result_tags_and_starts_user_tags_from_two() {
        let baseline = codegen_source(r#"print("baseline")"#);
        let bytecode = codegen_source(
            r#"defstruct User {
  name: String,
  age: Int,
}

impl User {
  def new(name: String, age: Int) -> Self {
    User { name: name, age: age }
  }
}

defrecord Point(x: Float, y: Float)
print("ok")"#,
        );

        assert_eq!(
            bytecode.type_registry.entries().len(),
            baseline.type_registry.entries().len() + 2
        );

        let user = &bytecode.type_registry.entries()[baseline.type_registry.entries().len()];
        assert!(user.tag >= 2);
        assert_eq!(user.name, "Global::User");
        assert_eq!(user.kind, TypeKind::Struct);

        let point = &bytecode.type_registry.entries()[baseline.type_registry.entries().len() + 1];
        assert_eq!(point.tag, user.tag + 1);
        assert_eq!(point.name, "Global::Point");
        assert_eq!(point.kind, TypeKind::Record);
    }

    #[test]
    fn direct_int_bitwise_builtin_calls_lower_to_specialized_opcodes() {
        let bytecode = codegen_typed(vec![
            builtin_app("bit_not", vec![int_lit(6)], Ty::Int),
            builtin_app("bit_and", vec![int_lit(6), int_lit(3)], Ty::Int),
            builtin_app("bit_or", vec![int_lit(6), int_lit(3)], Ty::Int),
            builtin_app("bit_xor", vec![int_lit(6), int_lit(3)], Ty::Int),
        ]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::BitNotInt)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::BitAndInt)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::BitOrInt)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::BitXorInt)));

        for name in ["bit_not", "bit_and", "bit_or", "bit_xor"] {
            assert_no_call_builtin(&bytecode, name);
        }
    }

    #[test]
    fn direct_string_len_builtin_call_lowers_to_specialized_opcode() {
        let bytecode = codegen_typed(vec![builtin_app(
            "string_len",
            vec![str_lit("あb")],
            Ty::Int,
        )]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::StringLen)));

        assert_no_call_builtin(&bytecode, "string_len");
    }

    #[test]
    fn direct_list_len_builtin_call_lowers_to_specialized_opcode() {
        let bytecode = codegen_typed(vec![builtin_app(
            "len",
            vec![list_lit_int([1, 2, 3])],
            Ty::Int,
        )]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::ListLen)));

        assert_no_call_builtin(&bytecode, "len");
    }

    fn special_enum_captures_use_normal_constructor_lowering() {
        let bytecode = codegen_source(
            "yes: (-> Boolean) = &True\nno: (-> Boolean) = &Boolean::False\nwrap: (Int -> Result<Int>) = &Result<_>::Ok\n(yes(), no(), wrap(3))",
        );
        assert!(bytecode.functions.iter().all(|entry| {
            !matches!(
                entry.qualified_name.as_deref(),
                Some("Ok" | "Err" | "print")
            )
        }));
        let mut ids = bytecode
            .functions
            .iter()
            .map(|entry| entry.fun_idx)
            .collect::<Vec<_>>();
        ids.sort_unstable();
        assert_eq!(ids, (0..ids.len() as u32).collect::<Vec<_>>());
    }

    fn safe_mod_trait_call_preserves_builtin_source_context() {
        let bytecode = codegen_source("remainder = Mod::safe_mod(7, 3)");
        let id = sindr::builtin::builtin_id_by_name("safe_mod").unwrap();
        assert!(bytecode.opcodes.iter().any(|op|matches!(op,Opcode::CallBuiltin{builtin_id,arity:2,span_start,span_end} if *builtin_id==id && span_end>span_start)));
    }

    #[test]
    fn direct_string_predicate_builtin_calls_lower_to_specialized_opcodes() {
        let bytecode = codegen_typed(vec![
            builtin_app(
                "string_contains",
                vec![str_lit("surtr"), str_lit("urt")],
                Ty::Bool,
            ),
            builtin_app(
                "string_starts_with",
                vec![str_lit("surtr"), str_lit("sur")],
                Ty::Bool,
            ),
            builtin_app(
                "string_ends_with",
                vec![str_lit("surtr"), str_lit("tr")],
                Ty::Bool,
            ),
        ]);

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::StringContains)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::StringStartsWith)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::StringEndsWith)));

        for name in ["string_contains", "string_starts_with", "string_ends_with"] {
            assert_no_call_builtin(&bytecode, name);
        }
    }

    #[test]
    fn direct_string_split_and_replace_stay_as_builtin_calls() {
        let bytecode = codegen_typed(vec![
            builtin_app(
                "string_split",
                vec![str_lit("a,b"), str_lit(",")],
                Ty::List(Box::new(Ty::Str)),
            ),
            builtin_app(
                "string_replace",
                vec![str_lit("banana"), str_lit("na"), str_lit("NA")],
                Ty::Str,
            ),
        ]);

        for (name, arity) in [("string_split", 2), ("string_replace", 3)] {
            let builtin_id = builtin_id_by_name(name)
                .unwrap_or_else(|| panic!("{name} builtin metadata must exist"));
            assert!(bytecode.opcodes.iter().any(|op| {
                matches!(
                    op,
                    Opcode::CallBuiltin {
                        builtin_id: id,
                        arity: actual_arity,
                        ..
                    } if *id == builtin_id && *actual_arity == arity
                )
            }));
        }
    }

    #[test]
    fn fallible_shift_and_bit_index_builtins_preserve_call_continuations() {
        let bytecode = codegen_typed(vec![
            builtin_app(
                "shl",
                vec![int_lit(1), int_lit(3)],
                Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error)),
            ),
            builtin_app(
                "shr",
                vec![int_lit(8), int_lit(1)],
                Ty::Result(Box::new(Ty::Int), Box::new(Ty::Error)),
            ),
            builtin_app("test_bit", vec![int_lit(5), int_lit(0)], Ty::Bool),
            builtin_app("set_bit", vec![int_lit(0), int_lit(1)], Ty::Int),
            builtin_app("clear_bit", vec![int_lit(7), int_lit(1)], Ty::Int),
            builtin_app("toggle_bit", vec![int_lit(5), int_lit(0)], Ty::Int),
        ]);

        for name in [
            "shl",
            "shr",
            "test_bit",
            "set_bit",
            "clear_bit",
            "toggle_bit",
        ] {
            let id = sindr::builtin::builtin_id_by_name(name).unwrap();
            assert!(bytecode
                .opcodes
                .iter()
                .any(|op| matches!(op,Opcode::CallBuiltin{builtin_id,..} if *builtin_id==id)));
        }
    }

    fn concrete_numeric_helpers_lower_to_existing_targets() {
        let bytecode = codegen_source(
            r#"sum = 1 + 2
quot = Div::safe_div(8.0, 2.0)
largest = Float::max(1.5, 2.5)"#,
        );

        let safe_div_id =
            builtin_id_by_name("safe_div").expect("safe_div builtin metadata must exist");

        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::AddInt)));
        assert!(bytecode.opcodes.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id,
                    arity: 2,
                    ..
                } if *builtin_id == safe_div_id
            )
        }));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::Call { arity: 2, .. })));
    }

    fn facet_set_and_over_are_lowered_without_runtime_builtin_calls() {
        let bytecode = codegen_source(
            r#"defrecord User(name: String)
user = User("alice")
user2 = Facet::set(User.name, user, "bob")
user3 = Facet::over(User.name, user2, {|name| Ok(name ++ "!")})"#,
        );

        let facet_set_id = builtin_id_by_name("set").expect("set builtin metadata must exist");
        let facet_over_id = builtin_id_by_name("over").expect("over builtin metadata must exist");

        assert!(!bytecode.opcodes.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id,
                    ..
                } if *builtin_id == facet_set_id || *builtin_id == facet_over_id
            )
        }));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::CallClosure { arity: 1, .. })));
    }

    fn facet_container_segments_lower_without_public_facet_builtin_calls() {
        let bytecode = codegen_source(
            r#"defrecord User(scores: List<Int>, score: HashMap<Int>)
user = User([10, 20], HashMap::map_from_entries([("talk", 80)]))
value1 =? Facet::view(List.[1], user.scores)
value2 =? Facet::view(HashMap.["talk"], user.score)
value3 =? Facet::view(User.scores.[1], user)
value4 =? Facet::set(User.score.["talk"], user, 90)"#,
        );

        for name in ["view", "set"] {
            let facet_id = builtin_id_by_name(name).expect("facet builtin metadata must exist");
            assert!(!bytecode.opcodes.iter().any(|op| {
                matches!(
                    op,
                    Opcode::CallBuiltin {
                        builtin_id,
                        ..
                    } if *builtin_id == facet_id
                )
            }));
        }
        for name in [
            "__facet_list_get",
            "__facet_map_get",
            "__facet_map_set_existing",
        ] {
            let helper_id = builtin_id_by_name(name).expect("facet helper metadata must exist");
            assert!(
                bytecode.opcodes.iter().any(|op| {
                    matches!(
                        op,
                        Opcode::CallBuiltin {
                            builtin_id,
                            ..
                        } if *builtin_id == helper_id
                    )
                }),
                "expected helper call {name}"
            );
        }
    }

    fn facet_api_capture_preserves_resolved_callable_metadata() {
        let bytecode = codegen_source(
            r#"defrecord User(name: String)
defrecord Score(value: Result<Int>)
defenum Slot { Some(Int), None }
read: (User -> String) = &Facet::view(User.name, &1)
put: (User -> User) = &Facet::put(User.name, &1, "bob")
set: (User -> Result<User>) = &Facet::set(User.name, &1, "bob")
preview: (Slot -> Result<Int>) = &Facet::preview(Slot.Some, &1)
over: (User -> Result<User>) = &Facet::over(User.name, &1, {|name: String| Ok(name)})
over_result: (Score -> Result<Score>) = &Facet::over_result(Score.value, &1, {|value: Result<Int>| Ok(value)})
case_set: (Slot -> Result<Slot>) = &Facet::case_set(Slot.Some, &1, 2)
case_over: (Slot -> Result<Slot>) = &Facet::case_over(Slot.Some, &1, {|value: Int| Ok(value)})
literal = {|user: User| Facet::view(User.name, user)}"#,
        );
        for (name, signature) in [
            ("view", "(User -> String)"),
            ("put", "(User -> User)"),
            ("set", "(User -> Result<User>)"),
            ("preview", "(Slot -> Result<Int>)"),
            ("over", "(User -> Result<User>)"),
            ("over_result", "(Score -> Result<Score>)"),
            ("case_set", "(Slot -> Result<Slot>)"),
            ("case_over", "(Slot -> Result<Slot>)"),
        ] {
            let qualified = format!("Facet::{name}");
            assert!(
                bytecode.functions.iter().any(|entry| entry.flags.closure
                    && entry.qualified_name.as_deref() == Some(qualified.as_str())
                    && entry.signature.as_deref() == Some(signature)),
                "missing {qualified} capture metadata"
            );
        }
        assert!(
            bytecode.functions.iter().any(|entry| entry.flags.closure
                && entry.qualified_name.is_none()
                && entry.signature.as_deref() == Some("(User -> String)")),
            "literal closure must retain its closure identity"
        );
    }

    fn facet_bindings_are_erased_and_only_viewed_values_are_captured() {
        let bytecode = codegen_source(
            r#"defrecord User(name: String)
facet = User.name
name = Facet::view(facet, User("alice"))
getter = {|| name}
result = getter()"#,
        );

        let facet_view_id = builtin_id_by_name("view").expect("view builtin metadata must exist");
        let facet_compose_id = builtin_id_by_name("__facet_compose")
            .expect("facet compose builtin metadata must exist");

        assert!(!bytecode.opcodes.iter().any(|op| {
            matches!(
                op,
                Opcode::CallBuiltin {
                    builtin_id,
                    ..
                } if *builtin_id == facet_view_id || *builtin_id == facet_compose_id
            )
        }));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::CallClosure { .. })));
    }

    fn facet_variant_mismatch_detail_includes_segment_context() {
        let bytecode = codegen_source(
            r#"defenum Expr {
  Add(Int, Int),
  Halt,
}
expr = Expr::Halt
Facet::view(Expr.Add, expr)"#,
        );

        assert!(bytecode
            .constants
            .iter()
            .any(|constant| matches!(constant,Constant::Str(segment) if segment==".Add")));
        let definition = bytecode
            .error_templates
            .iter()
            .find(|definition| definition.kind == "Global::FacetReadVariantMismatch")
            .unwrap();
        assert!(bytecode.opcodes.iter().any(|opcode|matches!(opcode,Opcode::Call{fun_idx,arity:5,..} if *fun_idx==definition.constructor_fun_idx)));
    }

    fn bounded_add_generic_helpers_emit_specialized_functions() {
        let bytecode = codegen_source(
            r#"def double(x: $N) -> $N where $N: Add { x + x }
a = double(21)
b = double(1.5)"#,
        );

        let double_entries = bytecode
            .functions
            .iter()
            .filter(|entry| entry.qualified_name.as_deref() == Some("double"))
            .count();

        assert_eq!(double_entries, 2);
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::AddInt)));
        assert!(bytecode
            .opcodes
            .iter()
            .any(|op| matches!(op, Opcode::AddFloat)));
    }

    fn compare_bound_list_helpers_emit_specialized_functions() {
        let bytecode = codegen_source(
            r#"largest = List::max([1, 3, 2])
smallest = List::min([1.5, 3.25, 2.0])
sorted = List::sort([3.25, 1.5, 2.0, 1.5])"#,
        );

        let function_names = bytecode
            .functions
            .iter()
            .filter_map(|entry| entry.qualified_name.as_deref())
            .collect::<Vec<_>>();

        assert!(function_names.contains(&"Global::List::max"));
        assert!(function_names.contains(&"Global::List::min"));
        assert!(function_names.contains(&"Global::List::sort"));
    }

    fn codegen_typed_program_embeds_runtime_process_specs() {
        let bytecode = codegen_module_source_with_builtin_prelude(
            r#"defagent Counter {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
    handlers {
      out: OutHandler = StdOut
    }
  }

  @init
  def init() -> Result<Int> { Ok(41) }

  @get
  def get(state: Int, label: String) -> Result<String> {
    Ok(label ++ ":" ++ to_string(state + 1))
  }

  @set
  def set(state: Int, next: Int) -> Result<Int> {
    Ok(next)
  }
}"#,
        )
        .expect("codegen should succeed");
        assert_eq!(bytecode.runtime_process_specs.entries.len(), 2);
        let spec = bytecode
            .runtime_process_specs
            .entries
            .iter()
            .find(|entry| entry.type_name == "Global::Counter")
            .expect("Counter runtime process spec");
        assert_eq!(spec.type_name, "Global::Counter");
        assert_eq!(spec.state.state_type.name, "Int");
        assert_eq!(spec.init.policy, sindr::ir::RuntimeInitPolicy::Eager);
        assert_eq!(spec.handlers.len(), 3);
        assert_eq!(spec.dependencies.handlers.len(), 1);
        assert_eq!(spec.dependencies.handlers[0].slot, "out");
        assert_eq!(spec.dependencies.handlers[0].capability, "OutHandler");
        assert_eq!(spec.dependencies.handlers[0].default_target.name, "StdOut");
    }

    fn codegen_typed_program_embeds_runtime_boot_plan() {
        let bytecode = codegen_module_source_with_builtin_prelude(
            r#"defagent Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
    handlers {
      out: OutHandler = StdOut
    }
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, label: String) -> Result<String> { Ok(label) }
}

supervisor_init {
  Logger {
    timeout: 5s
    handlers {
      out: FileOutHandler(path: "./logs/app.log")
    }
  }

  DynamicSupervisor {
    max_restarts: 10
    allow_adopt: True
  }
}"#,
        )
        .expect("codegen should succeed");
        assert_eq!(bytecode.runtime_boot_plan.singletons.len(), 1);
        let entry = &bytecode.runtime_boot_plan.singletons[0];
        assert_eq!(entry.process_name, "Global::Logger");
        assert_eq!(entry.init_timeout_ms, 5_000);
        assert_eq!(bytecode.runtime_boot_plan.handler_overrides.len(), 1);
        let handler = &bytecode.runtime_boot_plan.handler_overrides[0];
        assert_eq!(handler.target_process, "Global::Logger");
        assert_eq!(handler.slot, "out");
        assert_eq!(handler.handler_target.name, "FileOutHandler");
        assert_eq!(handler.handler_target.named_args[0].name, "path");
        assert_eq!(handler.handler_target.named_args[0].value, "./logs/app.log");
        assert_eq!(bytecode.runtime_boot_plan.supervisor_overrides.len(), 1);
        let supervisor = &bytecode.runtime_boot_plan.supervisor_overrides[0];
        assert_eq!(supervisor.process_name, "Global::DynamicSupervisor");
        assert_eq!(supervisor.policy.max_restarts, 10);
        assert!(supervisor.policy.allow_adopt);
    }

    fn codegen_rejects_boot_plan_handler_override_for_unknown_slot() {
        let err = codegen_module_source_with_builtin_prelude(
            r#"defagent Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
    handlers {
      out: OutHandler = StdOut
    }
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @get
  def get(state: Int, label: String) -> Result<String> { Ok(label) }
}

supervisor_init {
  Logger {
    handlers {
      missing: NullOutHandler
    }
  }
}"#,
        )
        .expect_err("unknown handler slot should fail");
        assert!(err
            .message
            .contains("handler slot is not declared by the target process"));
    }

    fn codegen_typed_program_embeds_genserver_runtime_handler_specs() {
        let bytecode = codegen_module_source_with_builtin_prelude(
            r#"defgenserver Logger {
  meta {
    instance: Singleton
    init_policy: Eager
    state: Int
  }

  @init
  def init() -> Result<Int> { Ok(0) }

  @call
  def info(state: Int, message: String) -> Result<CallResult<String, Int>> {
    Ok(CallResult::Reply(message, state))
  }

  @cast
  def reset(_state: Int, next: Int) -> Result<CastResult<Int>> { Ok(CastResult::Next(next)) }
}"#,
        )
        .expect("codegen should succeed");
        assert_eq!(bytecode.runtime_process_specs.entries.len(), 2);
        let spec = bytecode
            .runtime_process_specs
            .entries
            .iter()
            .find(|entry| entry.type_name == "Global::Logger")
            .expect("Logger runtime process spec");
        assert_eq!(spec.kind, sindr::ir::RuntimeProcessKind::GenServer);
        assert_eq!(spec.handlers.len(), 3);
        assert_eq!(spec.handlers[0].handler_id, 0);
        assert_eq!(spec.handlers[0].name, "init");
        assert_eq!(spec.handlers[0].kind, sindr::ir::RuntimeHandlerKind::Init);
        assert_eq!(spec.handlers[0].fun_idx, spec.init.callable.fun_idx);
        assert_eq!(spec.handlers[1].handler_id, 1);
        assert_eq!(spec.handlers[1].name, "info");
        assert_eq!(spec.handlers[1].kind, sindr::ir::RuntimeHandlerKind::Call);
        assert_eq!(spec.handlers[2].handler_id, 2);
        assert_eq!(spec.handlers[2].name, "reset");
        assert_eq!(spec.handlers[2].kind, sindr::ir::RuntimeHandlerKind::Cast);
    }

    fn codegen_typed_program_emits_v2_process_spec_for_standby_process_init() {
        let bytecode = codegen_module_source_with_builtin_prelude(
            r#"defgenserver StandbyCache {
  meta {
    instance: Singleton
    init_policy: Standby
    state: Int
  }

  @init
  def init() -> Result<StandbyInit<Int>> {
    Ok(Ready(0))
  }

  @call
  def value(state: Int) -> Result<CallResult<Int, Int>> {
    Ok(CallResult::Reply(state, state))
  }
}"#,
        )
        .expect("codegen should succeed");
        assert_eq!(bytecode.runtime_process_specs.entries.len(), 2);
        let spec = bytecode
            .runtime_process_specs
            .entries
            .iter()
            .find(|entry| entry.type_name == "Global::StandbyCache")
            .expect("StandbyCache runtime process spec");
        assert_eq!(spec.type_name, "Global::StandbyCache");
        assert_eq!(spec.state.state_type.name, "Int");
        assert_eq!(spec.init.policy, sindr::ir::RuntimeInitPolicy::Standby);
        assert!(matches!(
            spec.init.result_shape,
            sindr::ir::RuntimeInitResultShape::StandbyProcessInit { .. }
        ));
        assert_eq!(spec.dependencies.handlers.len(), 0);
        assert!(spec.lifecycle.owner.is_none());
        assert_eq!(
            spec.supervision.parent.as_deref(),
            Some("RuntimeSupervisor")
        );
    }
}
